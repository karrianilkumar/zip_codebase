"use client";
import React, { lazy, useEffect, useRef, useState } from "react";
import Select from "react-select";
import {
  PencilIcon,
  TrashIcon,
  InformationCircleIcon,NoSymbolIcon, CheckIcon, 
  ArrowPathIcon,
  CreditCardIcon,
  XMarkIcon,
  XCircleIcon
} from "@heroicons/react/24/outline";
import { CopyOutlined, CreditCardOutlined, DownloadOutlined, EyeOutlined, TagOutlined, WalletOutlined } from "@ant-design/icons";
import EditPopup from "./editpopup"
import { StatusCellRenderer } from "@/components/data-grid-cell-renderers/status-cell-renderer";
import { StatusHistoryCellRenderer } from "@/app/components/inventoryTableComponent/data-grid-cell-renderers/status-history-cell-renderer";

import { Modal, Checkbox, notification, Spin, Tooltip, Button, Input, DatePicker, message, Radio } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import {
  ArrowUpOutlined,
  ArrowDownOutlined
} from "@ant-design/icons";
import StatusIndicator from "@/app/components/TableComponent/data-grid-cell-renderers/status-indicator";

import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import BillingPagination from "./pagination__";
import CopyPackageModal from "./copypackage";
import { exportLoadingStore } from "../../stores/ExportLoadingStore";
import ChargesPopup from "./chargespopup";
import { useSearchStore } from "@/app/stores/searchStore";
import { useKillBillStore } from "../killbill_stores/activeStore";
import { useRouter } from "next/navigation";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import PackageModal from "./customerProfilesProductsList";
import EditServiceLocationModal from "../customer_profiles/billings_collections/billing_collections_sub_tabs/services-action-items/edit-service-location";
import PackageListModal from "./product_list";
// import { useLogoStore } from "../killbill_stores/logo_store";
import { useLogoStore } from "@/app/stores/logoStore";
import CustomerProfilesEditModal from "./customerProfilesEditProducts";
import { error } from "console";
import EditCollectionModal from "./edit_collectionsPopup";
import StepModal from "../collections/editStepModal";
import { useDateRangeStore } from "../killbill_stores/dateStoreReports";
import CustomerProfilesEditNewServiceModal from "./customerProfilesEditNewServiceModal";
import { DropdownStyles } from "@/app/components/css/dropdown";
import dayjs from "dayjs";
import { delay, initial } from "lodash";
import RepostMRC from "../customer_profiles/billings_collections/billing_collections_sub_tabs/bills_repost_MRC";
import RowDetailsModal from "@/app/components/rowDetailsModal"
import TaxesModal from "./taxesModal";
import CollectionsStepModal from "./collectionsStepModal";
import { useChargesModalDataStore } from "../killbill_stores/chargesModalData_store";
import ProgressBar from "@/app/components/optimizationTableComponent/cell-renderers/progressBar";
import QuantityCell , {STATUS_TYPE }from "@/app/components/TableComponent/data-grid-cell-renderers/quantity-cell-renderer";
import { BillingInfoDetailCellRenderer } from "../killbill_components/billing_info_details_cell_renderer";
import { fireSideCannons } from "@/app/components/confetti";

const DownloadPDFBill = lazy(() => import("./downloadPDFBill"));
const MultiDownloadPDFBill = lazy(() => import('./multiDownloadPDFBill'))
interface KillbillTableComponentProps {
  headers: string[];
  initialData: { [key: string]: any }[];  
  searchQuery?: string;
  visibleColumns: string[];
  itemsPerPage: number;
  allowedActions?: (
    | "edit"
    | "delete"
    | "info"
    | "copy"
    | "deactivate"
    | "copyPackage"
    | "editPackage"
    | "adjust"
    | "paynow"
    | "downloadbill"
    | "editCollection"
    | "editStep"
    | 'preview'
    | 'editServiceLocation' 
    | 'editNewService'
    | 'cancel-payment'
    | 'chargeback'
    | 'downloadreceipt'
    | 'disconnectService'
  )[];
  popupHeading: string;
  advancedFilters?: any;
  modalData?: any[];
  createModalData?: any;
  generalFields?: any;
  isSelectRowVisible?: boolean;
  headerMap?: any;
  pagination: any;
  height?: any;
  setReverseRowData?: any;
  onTabsClose?: any;
  setCallFetchdata?: any;
  setHeaders?: (headers: string[]) => void;
  setHeaderMap?: (map: Record<string, string[]>) => void;
  setTableData?: (data: any[]) => void;
  tableData?: any[];
  onTableDataUpdate?:any;
  ReportsData?:any;
  reportType?:any;
  repostedFields?:any;
  setAdvancedPage?: (value: boolean) => void;
  registerCloseAdvancedTabs?: (fn: () => void) => void;
 selectedSubPartner?: any;
  selectedPartner?: any;
  BPDashboardStartDate?: any;
  BPDashboardEndDate?: any;
  highlightedRowId?:any;
  AccountStatus?: boolean | false;
  eligibleAccounts?: string[];
  onDisconnectService?: (row: any) => void;
  isChargesModalOpen?: boolean;
}
type FormData = {
  item_amount: any | null;
  reason: any | null;
  comment: any | null;
  fee: any | null;
  reference_no: any | null;
  payment_method: any | null;
  agent: any | null;
  received_date: any | null;
  transaction_id: any | null;
  apply_fee ?: any |null;
  charge_back_fee ? : any | null;
  isChargeBack?: Boolean | false;
  credit_card_fee?:boolean | false;
};
const formatColumnName = (name: string) => {
  return name
    .replace(/_/g, " ") // Replace underscores with spaces
    .split(" ") // Split the string into words
    .map(
      (
        word // Capitalize each word
      ) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    )
    .join(" "); // Join the words back into a single string
};


const colorMap = {
  active:'#12E620',
  activated: "#12E620",
  activate: "#12E620",
  deactivated: "#E61224",
  // suspended: "#E61224",
  pending: "#A9A9A9",
  // Add more statuses and colors as needed
};
const messageStyle = {
  fontSize: "14px",
  fontWeight: "normal",
  padding: "16px",
};
const KillbillTableComponent: React.FC<KillbillTableComponentProps> = ({
  headers,
  initialData = [],
  searchQuery,
  visibleColumns,
  itemsPerPage,
  allowedActions,
  popupHeading,
  createModalData,
  modalData,
  generalFields,
  advancedFilters,
  isSelectRowVisible = true,
  headerMap,
  pagination,
  height,
  setReverseRowData,
  onTabsClose, setCallFetchdata, setHeaders,
  setHeaderMap,
  setTableData, tableData, onTableDataUpdate, ReportsData,
  reportType,repostedFields,setAdvancedPage,
   selectedSubPartner,
  selectedPartner,
  BPDashboardStartDate,
  BPDashboardEndDate,
  highlightedRowId,AccountStatus,eligibleAccounts = [],
  onDisconnectService,isChargesModalOpen
  
}) => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const router = useRouter();
  const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData || []);
  const [currentPage, setCurrentPage] = useState(1);
  const isFirstRender = useRef(true);
  const isFirstSearchRender = useRef(true);
  const isFirstAdvancedSearchRender = useRef(true);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
  const [editRowIndex, setEditRowIndex] = useState<number | null>(null);
  const [repostModalIndex, setRepostModalIndex] = useState<number | null>(null)
  const [isEditable, setIsEditable] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [repostModalOpen, setRepostModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [ProcessPaymentOpen, setProcessPaymentOpen] = useState(false);
  const [adjustInvoiceOpen, setAdjustInvoiceOpen] = useState(false);
  const [ProcessPaymentOpenRowIndex, setProcessPaymentOpenRowIndex] = useState<number | null>(null);
  const [adjustInvoiceOpenRowIndex, setadjustInvoiceOpenRowIndex] = useState<number | null>(null);
  const [PreviewModalRowIndex, setPreviewModalRowIndex] = useState<number | null>(null);
  const [deleteRowIndex, setDeleteRowIndex] = useState<number | null>(null);
  const [isCopyRowIndex, setCopyRowIndex] = useState<number | null>(null);
  const [isCopyModal, setCopyModal] = useState(false);
  const [isCopyPackageModal, setCopyPackageModal] = useState(false);
  const [isCopyPackageRowIndex, setCopyPackageRowIndex] = useState<number | null>(null);
  const [isEditPackageModal, setEditPackageModal] = useState(false);
  const [isCollectionModal, setCollectionModal] = useState(false);
  const [isCollectionModalRowIndex, setCollectionModalRowIndex] = useState<number | null>(null);
  const [isStepModal, setEditStepModal] = useState(false);
  const [isCancelPaymentModal , setCancelPaymentModal] = useState(false)
  const [isCancelPaymentModalRowIndex, setCancelPaymentModalRowIndex] = useState<number | null>(null);
  const [isStepModalRowIndex, setEditStepModalRowIndex] = useState<number | null>(null);
  const [isTaxesModalOpen, setTaxesModalOpen] = useState(false);
  const [isEditPackageRowIndex, setEditPackageRowIndex] = useState<number | null>(null);
  const [actionType, setActionType] = useState<string>("");
  const [caseType, setCaseType] = useState<string>("");
  const [PreviewModal, setPreviewModal] = useState(false);

  const [statusType, setStatusType] = useState<string>("");
  const [selectedRow, setSelectedRow] = useState(null);
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
  const [showNewPage, setShowNewPage] = useState(false);
  // const [showChargesPage, setChargesPage] = useState(false);
  const { searchData, advancedSearchData, combineAdnvaceSearchData ,glCodeTableData, chargesDetailsPagination,chargeDetailsTableData,chargeDetailsSearchData, setChargesDetailsPagination} = useSearchStore();
  const [isOpen, setIsOpen] = useState<Record<number, boolean>>({});
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const { addExport, removeExport } = exportLoadingStore();
  const { serviceShowActive, productTypeShowActive, packageActive ,productShowActive , servicesActive , customerProfilesActive} = useKillBillStore();
  const { setBillId, BillId, serviceDropdownValues,setUserProfileDetails , setSinglePaymentModalOpen, isSinglePaymentModalOpen,setMultiPaymentModalOpen,setBillingAndCollectionsActiveTab ,setSummaryExportData,setIsSelectAllChecked,isSelectAllChecked ,setShowChargesPage,showChargesPage , setSearchIdsforSelectAll} = useCustomerProfileStore();
  
    const accountNumber = useCustomerProfileStore((state) => state.accountNumber);
    const setAccountNumber = useCustomerProfileStore((state) => state.setAccountNumber);
  
  // console.log("tableData...", tableData);
  const {
    username,
    tenantNames,
    role,
    partner,
    selectedPartnerModule,
    Environment,
    tabledata,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    token,
    // selectedDb,
    sessionId,
    serviceProviderList,
    selectedServiceProvider,
    setAdvancedStoredPagination,
    setStoredPagination,
    setCombineAdnvaceStoredpagination,
    firstLastName,metaData,
    selectedDb,selectedBillingDb
  } = useAuth();
  const [totalPages, setTotalPages] = useState(1);
  const [lastPageWithData, setLastPageWithData] = useState(1);
  const { bulkRow, features: moduleFeatures } = useFeatureStore();
  const [loading, setLoading] = useState(false);
  const [formErrors, setFormErrors] = useState({ item_amount: "" });
   const [formData, setFormData] = useState<FormData>({
        item_amount: '',
        credit_card_fee: true,
        fee: '',
        reason: '',
        comment: '',
        reference_no: '',
        payment_method: '',
        agent: '',
        received_date: '',
        transaction_id:'',
        apply_fee:''
      });
  const [creditCardFee , setCreditCardFee] = useState<number>(0)    
  // Assuming you have a state to manage selected rows
  const [selectedRows, setSelectedRows] = useState<number[]>([]); 
  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [remainingAmount,setRemainingAmount] = useState<number>(0);
  const [showPackageModal, setShowPackageModal] = useState(false);
  const [ProductOrPackage, setProductOrPackage] = useState<string>('');
  const [showServicePackageDetails, setShowServicePackageDetails] = useState([]);
  const [serviceProductModal, setServiceProductModal] = useState(false);
  const [editServiceModalOpen, setEditServiceModalOpen] = useState(false);
  const [downloadPDFBill, setDownloadPDFBill] = useState(false);
  const [editServiceProductModalOpen, setEditServiceProductModalOpen] = useState(false);
  const [isEditServiceProductRowIndex, setEditServiceProductRowIndex] = useState<number | null>(null);
  const [editNewServiceModalOpen, setEditNewServiceModalOpen] = useState(false);
  const [isEditNewServiceRowIndex, setEditNewServiceRowIndex] = useState<number | null>(null);
  const [serviceSelectedRow, setServiceSelectedRow] = useState<{ [key: string]: any; } | null>(null);
  const [productDetails, setProductDetails] = useState<any[]>([]);
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);
  const [prevTitle, setPrevTitle] = useState(""); // Store previous title
  const [selctedProductServiceRow, setSelctedProductServiceRow] = useState(null);
  const [selectedProductsServiceRowData, setSelectedProductsServiceRowData] = useState<any[]>([]);
  const popupRef = useRef<HTMLDivElement | null>(null); // Type the ref as HTMLDivElement
  const [selectedPaymentMode, setSelectedPaymentMode] = useState<string>("");
  const [selectedPaymentAccountNumber, setSelectedPaymentMethodAccountNumber] = useState<string>("");
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isMoveDownConfirmModalOpen, setMoveDownConfirmModalOpen] = useState(false);
  const [isMoveDownRowIndex, setMoveDownModalRowIndex] = useState<number | null>(null);
  const [isMoveUpConfirmModalOpen, setMoveUpConfirmModalOpen] = useState(false);
  const [isMoveUpRowIndex, setMoveUpModalRowIndex] = useState<number | null>(null);


  const [isAmountModalOpen, setIsAmountModalOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [agentOptions, setAgentOptions] = useState<any[]>([]);
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [isAllSelected, setIsAllSelected] = useState(false); // State to track if all rows are selected
  const [quillValue, setQuillValue] = useState("");
  const [iframeUrl , setIframeUrl] = useState("")
// const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
const [paymentFormloading, setPaymentFormLoading] = useState(true);
  const [showStepsHeader, setShowStepsHeader] = useState(false);
  const {startDateDailyReport,endDateDailyReport,setCustomRange,weekStartDate} = useDateRangeStore();
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const [showRowModal, setShowRowModal] = useState<boolean>(false);
  const [showRowModalData, setShowRowModalData] = useState<any>(null);
  // Add these state variables with your other state declarations
const [isCollectionStepsModal, setIsCollectionStepsModal] = useState(false);
const [collectionStepsRowData, setCollectionStepsRowData] = useState<any>(null);

  const { setChargesTableData,setUsageDetailsTableData, setChargeByServiceTableData,usageDetailsTableData,chargeByServiceTableData , chargesTableData} = useChargesModalDataStore();
  const paymentModeOptions = [
    { value: "Money Order", label: "Money Order" },
    { value: "Paper Check", label: "Paper Check" },
    { value: "Card Payment", label: "Card Payment" },
    { value: "Inbound ACH", label: "Inbound ACH" },
  ];
    const parseAmount = (value: any) => Number(String(value).replace(/,/g, ""));

      useEffect(()=>{
      if(popupHeading === "Reversals" )
          {
            setIsSelectAllChecked(isAllSelected)
          }
      },[isAllSelected]);
useEffect(() => {
  if (!isSelectAllChecked || rowData.length === 0) return;
  console.clear()
  console.log("tabledata",rowData);
  
  setSelectedRows(prevSelected => {
    const newIds = rowData
      .map(row => row.id)
      .filter(id => !prevSelected.includes(id));

    return [...prevSelected, ...newIds];
  });

  // setReverseRowData((prev: any[]) => {
  //   const newRows = rowData.filter(
  //     row => !prev.some((r: any) => r.id === row.id)
  //   );
  //   return [...prev, ...newRows];
  // });
}, [rowData, isSelectAllChecked]);

  useEffect(() => {
    async function handlePaymentMessage(event: MessageEvent) {
      if (event.origin !== "https://pay.trxservices.net") return;

      const { action, url } = event.data;

      if (action === "navigate" && url) {
        try {
          // Parse the URL
          const parsedUrl = new URL(url);
          // Extract the Reference query param
          const reference = parsedUrl.searchParams.get("Reference");

          if (reference) {
            const newBillId: number = Number(localStorage.getItem("bill_id")) || 0;
            const batch_id :number = Number(localStorage.getItem("batch_id")) || 0;
            // Store bill_id as an array of numbers
            // const billIdArray: number[] = newBillId ? [newBillId] : [];
            try {

              // console.log("row",row)     
              let data;
              const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
              data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/fetch_transaction_status",
                role_name: role,
                reference: reference,
                parent_module: "Billing Platform",
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
        billing_db_name: selectedBillingDb,
                request_received_at: getCurrentDateTime(),
                sessionID: sessionId,
                action: "create",
                modified_by: firstLastName,
                account_number: accountNumber,
                // bill_id: billIdArray,
                batch_id:batch_id
              };

              const response = await axios.post(url, { data });
              const resp = JSON.parse(response.data.body);
              // console.log(resp, "show the response");

              if (response.data.statusCode === 200 && resp.flag === true) {
                setSinglePaymentModalOpen(false)
                setMultiPaymentModalOpen(false)
                setCallFetchdata(true)
                setBillingAndCollectionsActiveTab("paymentHistory")
                  Modal.success({
                   title:"Success",
                   content:resp.message || "Payment Success",
                   centered:true
                 })
              }
               else{
                 setSinglePaymentModalOpen(false)
                 setMultiPaymentModalOpen(false)
                 setBillingAndCollectionsActiveTab("bills")
                  Modal.error({
                  title:resp.failed_data.ResponseText || "Error",
                  content:resp.failed_data.DebugInfo || "Payment Failed",
                  centered:true
                })
                }
            } catch (error) {
              console.error("Error fetching data:", error);
              Modal.error({
                title: 'Error',
                content: 'Missing Payment Token',
                centered: true,
              });
              handleCancel()
              // setLoading(false);

            } finally {
              // setLoading(false);
            }
          }
        } catch (error) {
          console.error("Error verifying payment reference:", error);
          setPaymentFormLoading(false);
        }
      }
    }

    window.addEventListener("message", handlePaymentMessage);

    return () => {
      window.removeEventListener("message", handlePaymentMessage);
    };
  }, []);
 
useEffect(() => {
  const itemAmount = parseAmount(formData.item_amount);

  if (itemAmount <= 0) {
    setTotalAmount(0);
    return;
  }

  const isACH =
    formData.payment_method?.toLowerCase() === "inbound ach";

  let calculatedTotal = itemAmount;

  if (!isACH && formData.credit_card_fee && creditCardFee > 0) {
    const feeAmount = (itemAmount * creditCardFee) / 100;
    calculatedTotal += feeAmount;
  }

  setTotalAmount(Number(calculatedTotal.toFixed(2)));
}, [
  formData.item_amount,
  formData.credit_card_fee,
  formData.payment_method,
  creditCardFee,
]);




  useEffect(() => {
  if (iframeUrl) {
    setPaymentFormLoading(true);
  }
}, [iframeUrl]);

  // Check for small screen on component mount and window resize
    useEffect(() => {
        const checkScreenSize = () => {
            setIsSmallScreen(window.innerWidth < 700);
        };
        
        // Initial check
        checkScreenSize();
        
        // Add event listener for window resize
        window.addEventListener('resize', checkScreenSize);
        
        // Clean up
        return () => window.removeEventListener('resize', checkScreenSize);
    }, []);

  useEffect(() => {
    setAdvancedStoredPagination(null)
    setStoredPagination(null)
    setCombineAdnvaceStoredpagination(null)
    setChargesDetailsPagination(null)
      const handleResize = () => {
      setViewportHeight(window.innerHeight);
    };

    // Add event listener for window resize
    window.addEventListener("resize", handleResize);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };

  }, []);
 
  useEffect(() => {
    if (!router) {
      // console.error("NextRouter is not available.");
    }
  }, [router]);

  // useEffect(() => {
  //   const newRowData = tabledata?.length > 0 ? tabledata : initialData||[];
  //   setRowData(newRowData);
  // }, [tabledata, initialData]);
  const checkIfAnyStepsExist = () => {
    const hasSteps = rowData.some(row => row.closure_step || row.promise_step);

    // Only update the state if it actually changes
    // console.log("hasSteps,showStepsHeader",hasSteps,showStepsHeader)
    if (hasSteps !== showStepsHeader) {
        setShowStepsHeader(hasSteps);

    }
};

useEffect(() => {
    if (popupHeading === "Collections Steps" || popupHeading === "Create Collections") {
        // console.log("rowData updating...");
        checkIfAnyStepsExist();
    }
}, [rowData]);
useEffect(() => {
  if (generalFields?.dropdown?.sales_person) {
    setAgentOptions(generalFields.dropdown.sales_person);
  }
}, [generalFields?.dropdown?.sales_person]);
// useEffect(() => {
//   console.log("Updating header key...");
//   setRenderKey((prev) => prev + 1);
// }, [showStepsHeader]);
useEffect(() => {

  // ✅ Case 1: GL CODE — Highest Priority
  if (popupHeading === "GL Code" || popupHeading === "Charge By Service") {
    const newRowData = glCodeTableData.length > 0 
      ? glCodeTableData :
       initialData || [];

    setRowData(newRowData);
    return; // 🔥 stop here, do NOT run below logic
  }
  if(popupHeading === "Charge Details"){
    console.log("chargeDetailsTableData",chargeDetailsTableData)
    const newRowData = chargeDetailsTableData?.length > 0 
      ? chargeDetailsTableData :
       initialData || []; 
    setRowData(newRowData);
    return;
  }

  // ✅ Case 2: Collections Steps / Create Collections
  if (popupHeading === "Collections Steps" || popupHeading === "Create Collections") {
    const activeRows = Array.isArray(initialData)
      ? initialData.filter(row => !row.is_deleted)
      : [];

    let cumulativeDay = 0;

    const updatedRowData = activeRows.map((row, index) => {
      const gracePeriod = parseInt(row.grace_period, 10) || 0;

      if (index === 0) {
        row.day = gracePeriod.toString();
        cumulativeDay = gracePeriod;
      } else {
        cumulativeDay += gracePeriod;
        row.day = cumulativeDay.toString();
      }

      return row;
    });

    setRowData(updatedRowData);
    return; // ✅ stop here too
  }

  // ✅ Case 3: Default Case (All Other Popups)
  const newRowData =
    tabledata.length > 0
      ? tabledata
      : initialData || [];

  setRowData(newRowData);

}, [popupHeading, initialData, tabledata, glCodeTableData, chargeDetailsTableData]);


  useEffect(() => {
    setCurrentPage(1);
    }, [tabledata,sortConfig]);

  useEffect(() => {
    setCurrentPage(1);
  }, [totalPages]);

  //To manage the pagination routes
  useEffect(() => {
    let pagination_;
    if (popupHeading === "Charge Details") {
            pagination_ = chargesDetailsPagination ? chargesDetailsPagination : pagination
        }
        else{
          if(combineAdnvaceStoredpagination){
      pagination_=combineAdnvaceStoredpagination

    }
    else if (advancedStoredpagination && !storedpagination) {
      pagination_=advancedStoredpagination

    }
    else if (storedpagination && !advancedStoredpagination) {
      pagination_=storedpagination

    }
  else{
      pagination_=pagination
    }
        }
    
    // const pagination_ =combineAdnvaceStoredpagination? storedpagination ? storedpagination : advancedStoredpagination ? advancedStoredpagination : pagination
    // const pagination_ = pagination;
    const start = pagination_?.start || 1;
    const total = pagination_?.total || 1;
    const end = pagination_?.end || 1;
    const lastPageWithData_ = Math.floor(end / itemsPerPage);
    const totalPages_ = Math.ceil(total / itemsPerPage);
    const currentPage_ = Math.floor(start / itemsPerPage) + 1;
    setTotalPages(totalPages_);
    // setCurrentPage(currentPage_);
    setLastPageWithData(lastPageWithData_);
  }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, combineAdnvaceStoredpagination , sortConfig,chargesDetailsPagination]);
  useEffect(() => {
    if(popupHeading === "Bills"){
      // Select all rows by default when popupHeading is "Service Product"
      const allRowIds = initialData.map(row => row.id);
      // console.log(initialData,"Show initial Data")
      setSelectedRows(allRowIds);
      setIsAllSelected(true); // Set all selected to true
      if (typeof setReverseRowData === 'function') {
        setReverseRowData(initialData);
      }
    }
    if (popupHeading === "Service Product") {
      // Select all rows by default when popupHeading is "Service Product"
      const allRowIds = initialData?.map(row => row.id);
      setSelectedRows(allRowIds);
      setIsAllSelected(true); // Set all selected to true
      if (typeof setReverseRowData === 'function') {
        setReverseRowData(allRowIds);
      }
    }
    else {
      // Clear selected rows if the popupHeading changes
      setSelectedRows([]);
      setIsAllSelected(false); // Reset all selected state
      if (typeof setReverseRowData === 'function') {
        setReverseRowData([]);
      }
    }
  }, [popupHeading, initialData]);
  // Effect to update rowData based on tabledata and initialData


      const updatePaginator = async () => {
        setSearchIdsforSelectAll([])
        // console.log(serviceShowActive,"Show Service Active")
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        try {
          const colSortKey=sortConfig?sortConfig.key:""
          const colSortDirection=sortConfig?sortConfig.direction:""
          const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";

          // if (currentPage !== 1) {
          setLoading(true);
          // }
          if (popupHeading === "Service Type") {
            try{
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;

              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/services_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Billing Services",
                feature_module_name: "Billing Services",
                mod_pages: {
                  start: start_,
                  end: end_,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
                tenant_id:tenant_id_,
                status: serviceShowActive?"true":"false",
                main_module_name: "Service Types",
                sessionID: sessionId,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                  : {}),
              };

              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              const serviceTypeData = parsedData?.data?.billing_services || [];
              setRowData(serviceTypeData);
            }
            catch (err) {
              // console.error("Error fetching data:", err);
              Modal.error({
                title: "Data Fetch Error",
                content:
                  err instanceof Error
                    ? err.message
                    : "An unexpected error occurred while fetching data. Please try again.",
                centered: true,
              });
            } finally {
              // setLoading(false);
            }
          }
          if (popupHeading === "Product") {
            const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/products_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Products",
              feature_module_name: "Billing Products",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              status: productShowActive?"true":"false",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
              sessionID: sessionId,
            main_module_name: "Products",
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const productsData =
                parsedData?.data?.billing_products || [];
              setRowData(productsData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Product Type") {
            const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/product_type_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Product Types",
              feature_module_name: "Billing Product Types",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
            main_module_name: "Products",
              status: productTypeShowActive?"true":"false",
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ProductTypeData =
                parsedData?.data?.billing_product_types || [];
              setRowData(ProductTypeData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Packages") {
            const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/services_product_package_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Packages",
              feature_module_name: "Billing Packages",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
            main_module_name: "Products",
              status: packageActive?"true":"false",
              sessionID: sessionId,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const PackagesData =
                parsedData?.data?.billing_packages || [];
              setRowData(PackagesData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Customer Profiles") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/customer_profiles_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Customer Profiles",
              sub_module:"Customer Profiles",
              feature_module_name: "Billing Customer Profiles",
              main_module_name: "Customer Profiles",
              mod_pages: {
                start: start_,
                end: end_,
              },
              // account_number:accountNumber,
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              status: customerProfilesActive?"true":"false",
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const CustomersData =
                parsedData?.data?.billing_customer_profiles || [];
              setRowData(CustomersData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Bills") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/billing_collections_bills_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing and Collections Bills",
              feature_module_name: "Billing and Collections Bills",
              main_module_name: "Customer Profiles",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const BillsData =
                parsedData?.data?.billing_and_collections_bills || [];
              setRowData(BillsData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "RepostMRCs") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_reposted_mrcs",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing and Collections Reposted",
              feature_module_name: "Billing and Collections Reposted",
              main_module_name: "Customer Profiles",
              mod_pages: {
                start: start_,
                end: end_,
              },
              current_cycle : repostedFields.current_cycle.map((date: { format: (arg0: string) => any; }) => date ? date.format("MM-DD-YY") : null),
              prorated_flag : repostedFields.include_proration,
              bill_id : repostModalIndex !== null ? rowData[repostModalIndex].id : null,
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const RepostedData =
                parsedData?.data?.billing_collections_reposted || [];
              setRowData(RepostedData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Charge By Service") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/charge_by_service_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Charge By Service",
              feature_module_name: "Charge By Service",
              mod_pages: {
                start: start_,
                end: end_,
              },
              bill_id: BillId,
              request_received_at: getCurrentDateTime(),
              main_module_name: "Customer Profiles",
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const chargebyserviceData =
                parsedData?.data?.charge_by_service || [];
              setRowData(chargebyserviceData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Charge Details") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/charge_overview_account_charges",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Charge Overview",
              // sub_module: "Charge Overview",
              mod_pages: {
                start: start_,
                end: end_,
              },
              bill_id: BillId,
              accoun_number: accountNumber,
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              main_module_name: "Customer Profiles",
              feature_module_name: "Charge Overview",
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const chargebyserviceData = parsedData?.data || [];
              setChargesTableData(parsedData?.data || []);
              setRowData(chargebyserviceData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Billing Charge By Service") {
            const url = ENV_ROUTES.BP_BILLING_PAYMENTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/charge_by_service_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Charge By Service",
              feature_module_name: "Billing Charge By Service",
              mod_pages: {
                start: start_,
                end: end_,
              },
              bill_id: BillId,
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              main_module_name: "Billing",
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const billingchargesData =
                parsedData?.data?.billing_charge_by_service || [];
              setRowData(billingchargesData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Ledger") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/billing_collections_ledger_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing and Collections Ledger",
              feature_module_name: "Billing and Collections Ledger",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              tenant_id:tenant_id_,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              main_module_name: "Customer Profiles",
              sessionID: sessionId,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const Ledgerdata =
                parsedData?.data?.billing_and_collections_ledger || [];
              setRowData(Ledgerdata);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Unposted") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/unposted_bills_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing and Collections Unposted",
              feature_module_name: "Billing and Collections Unposted",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              table_name: "customer_charges",
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,
              main_module_name: "Customer Profiles",
              sessionID: sessionId,
              tenant_id:tenant_id_,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const UnpostedData =
                parsedData?.data?.billing_and_collections_unposted || [];
              setRowData(UnpostedData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Upload Tracking") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/unposted_upload_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Unposted Upload Status",
              feature_module_name: "Unposted Upload Status",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              table_name: "customer_charges",
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,
              main_module_name: "Customer Profiles",
              sessionID: sessionId,
              tenant_id:tenant_id_,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const UnpostedUploadData =
                parsedData?.data?.unposted_upload_list_view || [];
              setRowData(UnpostedUploadData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Reversals") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/bill_reversal_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing and Collections Reversals",
              table_name: "customer_reversal_bills",
              feature_module_name: "Billing and Collections Reversals",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              main_module_name: "Customer Profiles",
              sessionID: sessionId,
              tenant_id:tenant_id_,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching  data. Please try again.",
                centered: true,
              });
            } else {
              const UnpostedData =
                parsedData?.data?.billing_collections_reversals || [];
              setRowData(UnpostedData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Payment History") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/payment_history_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Payment History",
              feature_module_name: "Payment History",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
              main_module_name: "Customer Profiles",
              sessionID: sessionId,
              tenant_id:tenant_id_,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching  data. Please try again.",
                centered: true,
              });
            } else {
              const HistoryData =
                parsedData?.data?.payment_history || [];
              setRowData(HistoryData);
              setUserProfileDetails(parsedData?.data?.user_profile_details || {})

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Services") {
            try{
              const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
              
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/customer_services_list_view",
                role_name: role,
                    account_number:accountNumber,
                parent_module: "Billing Platform",
                module_name: "Customer Services",
                table_name: "customer_services",
                mod_pages: {
                  start: start_,
                  end: end_,
                },
                request_received_at: getCurrentDateTime(),
              main_module_name: "Customer Profiles",
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
                tenant_id:tenant_id_,
                sessionID: sessionId,
                status: servicesActive ? "true" : "false",
                feature_module_name: "Customer Services",
                    ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                  : {}),
              };

              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              const serviceTypeData = parsedData?.data?.customer_services || [];
              setRowData(serviceTypeData);
            }
            catch (err) {
              // console.error("Error fetching data:", err);
              Modal.error({
                title: "Data Fetch Error",
                content:
                  err instanceof Error
                    ? err.message
                    : "An unexpected error occurred while fetching data. Please try again.",
                centered: true,
              });
            } finally {
              // setLoading(false);
            }
          }
          if (popupHeading === "Billing") {
            const url = ENV_ROUTES.BP_BILLING_PAYMENTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/billing_payments_bills_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing and Payments Billing",
              feature_module_name: "Billing and Payments Billing",
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              // account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              main_module_name: "Billing",
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const HistoryData =
                parsedData?.data?.billing_and_payments_billing || [];
              setRowData(HistoryData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Chargebacks & Returns") {
            const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/charge_back_exceptions_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Chargeback Exceptions",
              feature_module_name: "Cancel Payment History",
              table_name: "cancel_payment_history",
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              // account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              main_module_name: 'Payments',
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const HistoryData =
                parsedData?.data?.exceptions || [];
              setRowData(HistoryData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Payments") {
            const url = ENV_ROUTES.BP_BILLING_PAYMENTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/all_payment_history_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing and Payments-Payment History",
              feature_module_name: "Billing and Payments-Payment History",
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              tenant_id:tenant_id_,
              // account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              main_module_name: "Payments",
              sessionID: sessionId,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const HistoryData =
                parsedData?.data?.payment_history || [];
              setRowData(HistoryData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Collections") {
            const url = ENV_ROUTES.BP_COLLECTIONS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/collections_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Collection Templates",
              feature_module_name: "Collection Templates",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              // account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
              sessionID: sessionId,
            main_module_name: 'Collections',
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const collectionData =
                parsedData?.data?.collection_templates || [];
              setRowData(collectionData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Billing Reports") {
            const url = ENV_ROUTES.BP_REPORTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/reports_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Reports",
              feature_module_name: "Billing Reports",
              table_name: "reports",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              // account_number:accountNumber,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,          
              tenant_id:tenant_id_,
              sessionID: sessionId,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const reportsData =
                parsedData?.data?.reports_data || [];
              setRowData(reportsData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Reports") {
            const url = ENV_ROUTES.BP_REPORTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/generate_report",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              feature_module_name: "Billing Platform",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,          
              report_name: reportType,
              table_name: reportType === "Payment Details By Date Range" ? "vw_payment_history"
                : reportType === "Altaworx Billing Report" ? "billing_report_view" :
                  reportType === "Unposted Items By Customer" ? "customer_charges" :
                    reportType === "Transaction Analysis" ? "customer_charges" : 
                    reportType === "A/R Aging"?"ar_aging_view":"",
              main_module_name: reportType === "Payment Details By Date Range" ? "Payment Details By Date Range"
                : reportType === "Altaworx Billing Report" ? "Altaworx Billing" :
                  reportType === "Unposted Items By Customer" ? "Unposted Items by Customer" :
                    reportType === "Transaction Analysis" ? "Transaction Analysis" : 
                    reportType === "A/R Aging"?"A/R Aging":"",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              report_flag: "view",
              modified_by: firstLastName,
              changed_data: { ...ReportsData},
              tenant_id:tenant_id_,
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);

              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Billing Report w/_City_County_Country") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/altaworx_billing_report_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              feature_module_name: "Billing Report w/_City_County_Country",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name: "billing_report_view",
              request_received_at: getCurrentDateTime(),
              module_name: "Billing Report w/_City_County_Country",
              main_module_name: "Billing Report w/_City_County_Country",
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.altaworx_billing_report || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Transaction Analysis") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/transcation_analysis_report_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              feature_module_name: "Transaction Report",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name: "customer_charges",
              main_module_name: "Transaction Analysis",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              modified_by: firstLastName,
              tenant_id:tenant_id_,
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.transaction_report || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "A/R Aging") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/ar_aging_report_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              feature_module_name: "AR Aging Report",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name: "ar_aging_view",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
            main_module_name: "A/R Aging",
              modified_by: firstLastName,
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination;
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Product Level Tax Mapping"){
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/product_level_tax_mapping_report_list_view",
              role_name: role,
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              parent_module: "Billing Platform",
              module_name: "Product Level Tax Mapping",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id: tenant_id_,
              feature_module_name: "Product Level Tax Mapping",
              main_module_name: "Product Level Tax Mapping",
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination;
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }

          }
          if (popupHeading === "Unposted Items") {
            const url = ENV_ROUTES.BP_REPORTS;
            
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/unposted_items_report_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              feature_module_name: "Unposted Items",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name: "unposted_items_view",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              main_module_name: "Unposted Items by Customer",
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.unposted_items || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Payment Details") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/payment_details_report_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              feature_module_name: "Payment Details Report",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name: "vw_payment_history",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              main_module_name: "Payment Details By Date Range",
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Export Cycle Date") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/export_cycle_date_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              feature_module_name: "Export Cycle Date",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name: "customer_profiles",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              main_module_name: "Export Cycle Date",
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Billed Through Date Report") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/billed_through_date_report_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              feature_module_name: "Billed Through Date Report",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              // table_name: "customer_profiles",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              main_module_name: "Billed Through Date Report",
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Billing report by day with OCC") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/altaworx_billing_report_by_day_report_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              feature_module_name: "Billing report by day with OCC",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              // table_name: "customer_profiles",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              main_module_name: "Billing report by day with OCC",
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Export Variance Billing") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/export_variance_billing_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              feature_module_name: "Export Variance Billing",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              // table_name: "customer_profiles",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              week_start:weekStartDate,
              main_module_name: "Export Variance Billing",
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Total MRC for Sales Person: Catapult") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/total_mrc_bill_profiles_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              feature_module_name: "Total MRC for Sales Person: Catapult",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
            billing_db_name: selectedBillingDb,
              report_name: reportType,
              // table_name: "customer_profiles",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              main_module_name: "Total MRC for Sales Person: Catapult",
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.reports_data || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          if (popupHeading === "Bill Template Management") {
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/bill_template_management_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              
              parent_module: "Super Admin",
              module_name: "Bill Template Management",
              main_module_name: "Customer Profiles",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name : 'bill_templates',
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              modified_by: firstLastName,
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.bill_template_management || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "GL Code") {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;

            const data = {
            tenant_name: partner || "default_value",
                  username: username,
                  firstLastName: firstLastName,
                  path: "/glcode_list_view",
                  role_name: role,
                  parent_module: "Partner Info",
                  module_name: "Billing GL Code",
                  Selected_Partner: selectedPartner,
                  sub_partner: selectedSubPartner,
                  request_received_at: getCurrentDateTime(),
                  access_token: token,
                  db_name: selectedDb,
              ...metaData,
    billing_db_name: selectedBillingDb,
                  sessionID: sessionId,
                  ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
                  mod_pages: {
                    start: start_,
                    end: end_,
                  },
                };
                const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed...", parsedData);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const ReportsData =
                parsedData?.data?.billing_gl_code || [];
              setRowData(ReportsData);
              pagination = parsedData?.pages || pagination
            }
                
            }
          if (popupHeading === "Collections Summary") {
            const url = ENV_ROUTES.BP_DASHBOARDS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/collections_summary",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              parent_module: "Billing Platform",
              module_name: "Collections Dashboard",
              feature_module_name: "Collections Dashboard",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name: "collections_view",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              action: "view",
              main_module_name:"Collections Summary",
              modified_by: firstLastName,
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
              start_date: BPDashboardStartDate,
              end_date: BPDashboardEndDate,
                      
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const DashboardCollectionSummaryData =
                parsedData?.data?.collections_summary || [];
              setRowData(DashboardCollectionSummaryData);
              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "Export FCC") {
            const url = ENV_ROUTES.BP_REPORTS;

            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/fcc_report_list_view",
              role_name: role,
              mod_pages: {
                start: start_,
                end: end_,
              },
              parent_module: "Billing Platform",
              module_name: "Export FCC",
              feature_module_name: "Export FCC",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name: selectedBillingDb,
              report_name: reportType,
              table_name: "vw_fcc_report",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              tenant_id:tenant_id_,
              main_module_name:"Export FCC",
              start_date:startDateDailyReport,
              end_date:endDateDailyReport,
              modified_by: firstLastName,
              ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                : {}),
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const DashboardCollectionSummaryData =
                parsedData?.data?.reports_data || [];
              setRowData(DashboardCollectionSummaryData);
              pagination = parsedData?.pages || pagination
              const summary_ = parsedData?.summary || {};
              const mappedSummary: Record<string, number> = {};

              // Loop through summary keys and map to headerMap display name
              Object.entries(summary_).forEach(([key, value]) => {
                const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
                mappedSummary[displayName] = value as number;
              });

              console.log("Mapped Summary:", mappedSummary);
              setSummaryExportData(mappedSummary);
            }
          }
          
        } catch (err) {
          console.error("Error fetching data:", err);
        } finally {
          setLoading(false);
        }
        // }
      };
  const updateSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...popupHeading === "Charge Details"?{...chargeDetailsSearchData}:{...searchData}, username: username, }
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      // console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table || [];
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {};
        if(popupHeading === "Charge Details"){
          setChargesDetailsPagination(pagination_)
        }
        setStoredPagination(pagination_);
        setAdvancedStoredPagination(null);
        setCombineAdnvaceStoredpagination(null)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      // console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  const updateAdvancedSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...popupHeading === "Charge Details"?{...chargeDetailsSearchData}:{...advancedSearchData}, username: username, }
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      // console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {}
        setStoredPagination(null)
        setAdvancedStoredPagination(pagination_)
        if(popupHeading === "Charge Details"){
          setChargesDetailsPagination(pagination_)
        }
        setCombineAdnvaceStoredpagination(null)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  const updateCombinedSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...popupHeading === "Charge Details"?{...chargeDetailsSearchData}:{...combineAdnvaceSearchData}, username: username, }
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {}
        setStoredPagination(null)
        setAdvancedStoredPagination(null)
        if(popupHeading === "Charge Details"){
          setChargesDetailsPagination(pagination_)
        }
        setCombineAdnvaceStoredpagination(pagination_)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  useEffect(() => {
    if (!isFirstRender.current) {

      if (combineAdnvaceStoredpagination) {
        updateCombinedSearchPaginator()
      }
      else if (storedpagination && !advancedStoredpagination) {
        updateSearchPaginator()
      }
      else if (advancedStoredpagination && !storedpagination) {
        updateAdvancedSearchPaginator()
      }
      else {
        updatePaginator();
      }

     }  else { isFirstRender.current = false }
  }, [currentPage, sortConfig]);

  useEffect(() => {
    console.log("popupheading",popupHeading)
    console.log("isChargesModalOpen",isChargesModalOpen)

    if(!isChargesModalOpen && showChargesPage) return;
    if (!isFirstSearchRender.current) {
        if (searchQuery==="") {
        // console.log("searchQuery",isFirstRender)
        if (storedpagination) {
          updateSearchPaginator()
        }
        else if (advancedStoredpagination) {
          updateAdvancedSearchPaginator()
        }
        else {
          // console.log("advancedStoredpagination",advancedStoredpagination)
          updatePaginator();
        }
      }
    } else { isFirstSearchRender.current = false }
  }, [searchQuery]);

  useEffect(() => {
    // console.log("advancedFilters",advancedFilters)
    if (!isFirstAdvancedSearchRender.current) {
      if (advancedFilters) {
        const allEmpty = Object.values(advancedFilters).every(
          (value) => Array.isArray(value) && value.length === 0
        );

        if (allEmpty) {
          // console.log("advancedFilters",advancedFilters)
          if (storedpagination) {
            updateSearchPaginator()
          }
          else if (advancedStoredpagination) {
            updateAdvancedSearchPaginator()
          }
          else {
            updatePaginator();
          }
        }
      }
    } else { isFirstAdvancedSearchRender.current = false }

  }, [advancedFilters]);
  const handleDelete = async (rowIndex: number, actionType: string, statusType: string) => {
    if (rowIndex >= 0 && rowIndex < rowData.length) {
      const updatedData: any = [...rowData];
      const row = updatedData[rowIndex];
      console.log(row);
      if (actionType === "delete") {
        row["deleted_by"] = firstLastName;
        row["is_deleted"] = true;
        row["is_active"] = false;
      } else if (actionType === "deactivate") {
        row["is_active"] = false;
      }
      else {
        row["is_active"] = true;
      }
      updatedData[rowIndex] = row;
      if (popupHeading === "Collections Steps" || popupHeading === "Create Collections") {
        const updatedRowData = rowData.filter((r) => r !== row);
        let cumulativeDay = 0;
        const recalculatedData = updatedData.map((r:any) => {
          if (!r.is_deleted) {
            const gracePeriod = parseInt(r.grace_period, 10) || 0;
            cumulativeDay += gracePeriod;
            r.day = cumulativeDay.toString();
          }
          return r;
        });

        const activeRows = recalculatedData.filter((r:any) => !r.is_deleted);

        // Only active rows for UI
        setRowData(activeRows);
  
        // All rows (active + deleted) for internal update
        onTableDataUpdate(recalculatedData);
  
        console.log("Active Rows (UI):", activeRows);
        console.log("All Rows (Export/API):", recalculatedData);
      }
    else{

        try {
          let url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
          let url2 = ENV_ROUTES.BP_COLLECTIONS;
          let url3 = ENV_ROUTES.BP_CUSTOMER_PROFILES;
          let url4 = ENV_ROUTES.MODULE_MANAGEMENT;

          let data;
          if (popupHeading === "Service Type") {
            if (row) {
              row["modified_by"] = firstLastName;
              row["modified_date"] = getCurrentDateTime();
            }

            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/update_service_type_status",
              role_name: role,
              module_name: "Service Types",
              table_name: "services",
              action: actionType,
              changed_data: row,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              tenant_id:tenant_id_,
              db_name: selectedDb,
              ...metaData,
              billing_db_name:selectedBillingDb,
              sessionID: sessionId,
              main_module_name: "Service Types",
            };

          }
          if (popupHeading === "Product") {
            if (row) {
              row["modified_by"] = firstLastName;
              row["modified_date"] = getCurrentDateTime();
            }

            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/update_product_status",
              role_name: role,
              module_name: "Billing Products",
              table_name: "products",
              action: actionType,
              changed_data: row,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              status: productShowActive?"true":"false",
              access_token: token,
              tenant_id:tenant_id_,
              db_name: selectedDb,
              ...metaData,
              billing_db_name:selectedBillingDb,
              sessionID: sessionId,
              main_module_name: "Products",
              
            };

          }
          if (popupHeading === "Product Type") {
            if (row) {
              row["modified_by"] = firstLastName;
              row["modified_date"] = getCurrentDateTime();
            }

            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/update_product_type_status",
              role_name: role,
              module_name: "Billing Product Types",
              table_name: "product_types",
              action: actionType,
              changed_data: row,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name:selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
            status:productTypeShowActive?"true":"false",
            };
          }
          if (popupHeading === "Packages") {
            if (row) {
              row["modified_by"] = firstLastName;
              row["modified_date"] = getCurrentDateTime();
            }

            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/update_package_status",
              role_name: role,
              module_name: "Billing Packages",
              table_name: "packages",
              action: actionType,
              changed_data: row,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name:selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
            status:packageActive?"true":"false",
            };
          }
          if (popupHeading === "Collections") {
            if (row) {
              row["modified_by"] = firstLastName;
              row["modified_date"] = getCurrentDateTime();
            }

            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/delete_collection_template",
              role_name: role,
              module_name: "Collection Templates",
              action: actionType,
              changed_data: row,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name:selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              table_name: "collection_templates",
              flag: "Template"
            };
          }
           if (popupHeading === "Bill Template Management") {
            if (row) {
              row["modified_by"] = firstLastName;
              row["modified_date"] = getCurrentDateTime();
            }

            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/delete_bill_template",
              role_name: role,
              module_name: "Bill Template Management",
              action: actionType,
              changed_data: row,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              billing_db_name:selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              table_name: "bill_templates",
            };
          }
           if (popupHeading === "GL Code") {
            if (row) {
              row["modified_by"] = firstLastName;
              row["modified_date"] = getCurrentDateTime();
            }

            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/deactivate_glcode",
              role_name: role,
               parent_module: "Partner Info",
              module_name: "Billing GL Code",
              Selected_Partner: selectedPartner,
              sub_partner: selectedSubPartner,
              action: actionType,
              changed_data: row,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              status: productShowActive?"true":"false",
              access_token: token,
              tenant_id:tenant_id_,
              db_name: selectedDb,
              ...metaData,
              billing_db_name:selectedBillingDb,
              sessionID: sessionId,              
            };

          }


          // console.log("deleteIndex", url2);
          // const response = await axios.post(
          //   popupHeading.includes("Collection") ? url2 : popupHeading.includes('Bill Template Management') ? url3 : url,
          //   { data }
          // );
        let postUrl;
          if (popupHeading === "Collections") {
            postUrl = url2;
          } else if (popupHeading === "Bill Template Management") {
            postUrl = ENV_ROUTES.BP_CUSTOMER_PROFILES;
          }else if (popupHeading === "GL Code") {
            postUrl = ENV_ROUTES.MODULE_MANAGEMENT;
            }
           else {
            postUrl = url;
          }

        const response = await axios.post(postUrl, { data });
          const parsedData = JSON.parse(response.data.body);
          if (response && response.status === 200) {
            notification.success({
              message: "Success",
              description: parsedData.message || "Data Modified Successfully!",
              // style: messageStyle,
              placement: "top",
            });
            fireSideCannons();
            if (popupHeading === "Service Type") {
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/services_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Service Types",
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                tenant_id:tenant_id_,
                feature_module_name: "Billing Services",
                status: serviceShowActive?"true":"false",
                main_module_name: "Service Types",
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Customer groups data. Please try again.",
                  centered: true,
                });
              } else {

                setRowData(parsedData?.data?.billing_services || []);
              }
            }
            if (popupHeading === "Packages") {
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/services_product_package_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Billing Packages",
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
                sessionID: sessionId,
              tenant_id:tenant_id_,
                feature_module_name: "Billing Packages",
              status:packageActive?"true":"false",
              main_module_name: "Products",
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Customer groups data. Please try again.",
                  centered: true,
                });
              } else {

                setRowData(parsedData?.data?.billing_packages || []);
              }
            }
            if (popupHeading === "Products") {
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/products_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Billing Products",
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                request_received_at: getCurrentDateTime(),
                status: productShowActive?"true":"false",
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
                sessionID: sessionId,
                feature_module_name: "Billing Products",
                main_module_name: "Products",
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Customer groups data. Please try again.",
                  centered: true,
                });
              } else {

                setRowData(parsedData?.data?.billing_products || []);
              }
            }
            if (popupHeading === "Product Types") {
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/product_type_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Billing Product Types",
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
                sessionID: sessionId,
                feature_module_name: "Billing Product Type",
              status:productTypeShowActive?"true":"false",
              main_module_name: "Products",
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Customer groups data. Please try again.",
                  centered: true,
                });
              } else {

                setRowData(parsedData?.data?.billing_product_types || []);
              }
            }
            if (popupHeading === "Collections") {
              const url = ENV_ROUTES.BP_COLLECTIONS;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/collections_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Collection Templates",
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
                sessionID: sessionId,
                feature_module_name: "Collection Templates",
                table_name: "collection_templates",
                main_module_name: 'Collections',

              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Customer groups data. Please try again.",
                  centered: true,
                });
              } else {

                setRowData(parsedData?.data?.collection_templates || []);
              }
            }
            if (popupHeading === "Bill Template Management") {
              const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/bill_template_management_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Bill Template Management",
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
                sessionID: sessionId,
                feature_module_name: "Bill Template Managemen",
          main_module_name: "Customer Profiles",
                table_name: "bill_templates",

              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Customer groups data. Please try again.",
                  centered: true,
                });
              } else {

                setRowData(parsedData?.data?.bill_template_management || []);
              }
            }
             if (popupHeading === "GL Code") {
              const url = ENV_ROUTES.MODULE_MANAGEMENT;
               const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/glcode_list_view",
              role_name: role,
              parent_module: "Partner Info",
              module_name: "Billing GL Code",
              Selected_Partner: selectedPartner,
              sub_partner: selectedSubPartner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              mod_pages: {
                start: 0,
                end: 100,
              },
            };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Customer groups data. Please try again.",
                  centered: true,
                });
              } else {

                setRowData(parsedData?.data?.billing_gl_code || []);
              }
            }



          } else {
            const errorMsg = JSON.parse(response.data.body).message;
            Modal.error({
              title: "Saving Error",
              content: errorMsg,
              centered: true,
            });
          }
        } catch (err) {
          // console.error("Error fetching data:", err);
          notification.error({
            message: "Error",
            description: "Failed to Deleted the record. Please try again.",
            style: messageStyle,
            placement: "top", // Apply custom styles here
          }); //// place it after you make the call to load the table data
        }
      }

      // setRowData(updatedData);
    }
  };
  const confirmDelete = (actionType: any, statusType?: any) => {
    if (deleteRowIndex !== null) {
      handleDelete(deleteRowIndex, actionType, statusType);
    }
    setDeleteModalOpen(false);
    setDeleteRowIndex(null);
  };

  //For sorting the table
  // const handleSort = (key: string) => {
  //   let direction: "ascending" | "descending" = "ascending";
  //   if (
  //     sortConfig &&
  //     sortConfig.key === key &&
  //     sortConfig.direction === "ascending"
  //   ) {
  //     direction = "descending";
  //   }

  //   const sortedData = [...rowData].sort((a, b) => {
  //     let aValue = a[key];
  //     let bValue = b[key];

  //     // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
  //     if (key === "carrier_rate_plans") {
  //       aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
  //       bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
  //     }

  //     // Convert 'None' to null for easier comparison
  //     const normalizeValue = (value: any) => {
  //       if (value === 'None') return null;
  //       return value;
  //     };

  //     aValue = normalizeValue(aValue);
  //     bValue = normalizeValue(bValue);

  //     // Function to split a string into alphabetical and numeric segments
  //     const splitIntoSegments = (str: string) => {
  //       return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
  //     };

  //     // Split values into segments
  //     const aSegments = typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
  //     const bSegments = typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

  //     // Compare each segment one by one
  //     for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
  //       const aSegment = aSegments[i];
  //       const bSegment = bSegments[i];

  //       // If one segment is undefined, consider it smaller
  //       if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
  //       if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

  //       // Compare numeric segments numerically, and character segments lexicographically
  //       const isANumber = !isNaN(Number(aSegment));
  //       const isBNumber = !isNaN(Number(bSegment));

  //       if (isANumber && isBNumber) {
  //         // Both segments are numbers; compare them numerically
  //         const numA = Number(aSegment);
  //         const numB = Number(bSegment);
  //         if (numA < numB) return direction === "ascending" ? -1 : 1;
  //         if (numA > numB) return direction === "ascending" ? 1 : -1;
  //       } else {
  //         // At least one segment is not a number; compare them as strings
  //         if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
  //         if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
  //       }
  //     }

  //     return 0;
  //   });

  //   setSortConfig({ key, direction });
  //   setRowData(sortedData);
  // };

  const handleSort = (key: string) => {
    let direction: "ascending" | "descending" = "ascending";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "ascending"
    ) {
      direction = "descending";
    }
    setCurrentPage(1)
    setSortConfig({ key, direction });
  };

  //for services product/packeage column

const renderCustomProducts = (value: any, header: any) => {
  let processedValue = "";

  const cleanItem = (item: string) => {
    let parts = item.split(" - ");
    if (parts.length === 1) {
      parts = item.split("-");
    }
    return parts.length > 1 ? parts.slice(1).join("-").trim() : item.trim();
  };

  if (value && value !== "None") {
    if (Array.isArray(value)) {
      // Already a real array
      processedValue = value
        .map((item) => (typeof item === "string" ? cleanItem(item) : item))
        .join(", ");
    } else if (typeof value === "string") {
      try {
        // Convert fake array string to valid JSON
        const fixedValue = value.replace(/'/g, '"');
        const parsed = JSON.parse(fixedValue);

        if (Array.isArray(parsed)) {
          processedValue = parsed
            .map((item) => (typeof item === "string" ? cleanItem(item) : item))
            .join(", ");
        } else {
          processedValue = cleanItem(parsed);
        }
      } catch (e) {
        // Still a fallback if nothing works
        processedValue = cleanItem(value);
      }
    } else {
      processedValue = cleanItem(value.toString());
    }

    // Remove leftover characters
    processedValue = processedValue.replace(/[\{\}\[\]"']/g, "");
  }

  return (
    // <Tooltip
    //   title={processedValue}
    //   placement="topLeft"
    //   overlayStyle={{
    //     whiteSpace: "normal",
    //     maxWidth: "60vw",
    //     wordWrap: "break-word",
    //     zIndex: 50,
    //   }}
    //   getPopupContainer={() => document.body}
    // >
      <span>{processedValue}</span>
    // </Tooltip>
  );
};



  //For custom cell rendering
  const renderCell = (cellData: any, column: string, rowIndex: number) => {

    if (headerMap &&
      headerMap?.[column]?.[0] === "SIM Status") {
      return <StatusCellRenderer
        record={rowData[rowIndex]}
        value={cellData || "None"}
        index={rowIndex}
        colorMap={colorMap}
      />
    }
    if (moduleFeatures.includes("Action history-Inventory") &&
      (headerMap?.[column]?.[0] === "Action History" || column === "Action History")) {
      return <StatusHistoryCellRenderer row={rowData[rowIndex]} />
    }

    if (column.toLowerCase() === "status" ||
      (headerMap && headerMap?.[column]?.[0] === "Status")) {
      return <StatusIndicator
        row={rowData[rowIndex]}
        status={cellData === true || cellData === "True" ? "Active" : cellData === false || cellData === "False" ? "Inactive" : cellData}
        heading={popupHeading}
      />

    }
    if (headerMap && headerMap[column]?.[0] === "Type") {

      return (
        <Tooltip
          title={`${cellData}`}
          placement="topLeft"
          overlayStyle={{
            whiteSpace: "normal",
            maxWidth: "60vw",
            wordWrap: "break-word",
          }}
          getPopupContainer={(triggerNode) =>
            (triggerNode.parentNode as HTMLElement) || document.body
          }
        >
          <span style={{ display: "flex", alignItems: "center", gap: "5px" }}>
            {cellData === "Payment" && (
              <i className="fi fi-rr-expense" style={{ marginTop: "2px" }}></i>
            )}
            {cellData === "Bill" && (
              <i className="fi fi-rr-file-invoice-dollar" style={{ marginTop: "2px" }}></i>
            )}
            {cellData === "Charge" && (
              <i className="fi fi-rr-receipt" style={{ marginTop: "2px" }}></i>
            )}
            {cellData === "Credit" && (
              <i className="fi fi-rr-credit-card" style={{ marginTop: "4px" }}></i>
            )}
            {cellData === "Balance Transfer" && (
              <i className="fi fi-rr-money-coin-transfer" style={{ marginTop: "2px" }}></i>
            )}
            {cellData === "Deposit" && (
             <i className="fi fi-rr-deposit" style={{ marginTop: "2px" }}></i>
            )}
            {cellData === "Refund" && (
              <i className="fi fi-rr-refund-alt" style={{ marginTop: "2px" }}></i>
            )}
            {cellData === "MRC" && (
              <i className="fi fi-rr-rotate-reverse"style={{ marginTop: "2px" }}></i>
            )}
            {cellData === "Reverse Bill" && (
              <i className="fi fi-rr-undo-alt" style={{ marginTop: "2px" }}></i>
            )}
            {cellData === "Chargeback" && (
              <i className="fi fi-rr-refund-alt" style={{ marginTop: "2px" }}></i>
            )}
            {cellData}
          </span>
        </Tooltip>


      );
    }
     if (popupHeading === "Service Product" && (column === "itemize" || column === "tax_incl" || column === "group" || column === "prorate")) {

      if (cellData === "True" || cellData === true) {
        return <span className="text-green-500">True</span>;
      } else if (cellData === "False" || cellData === false) {
        return <span className="text-red-500">False</span>;
      } else {
        return <span>{cellData}</span>;
      }
    }
   let displayValue = cellData;
    try {
      if (Array.isArray(cellData)) {
        // Properly join array values with comma + space
        displayValue = cellData.join(", ");
      } else if (typeof cellData === "string") {
        // Handle strings that look like arrays: "[A, B, C]"
        if (cellData.startsWith("[") && cellData.endsWith("]")) {
          displayValue = cellData
            .slice(1, -1) // remove brackets
            .split(",")
            .map((s) => s.trim().replace(/^['"]|['"]$/g, "")) // trim + remove quotes
            .join(", ");
        }
      }
    } catch (e) {
      displayValue = cellData;
    }
    return (
      <Tooltip
        title={`${cellData}`}
        placement="topLeft"
        overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' , zIndex:9999}}
        // getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body} // Fallback to document.body
        getPopupContainer={() => document.body}
      >
         <span>{displayValue?.toString()}</span>
      </Tooltip>
    ); cellData;
  };

  const handleActionClick = (action: string, rowIndex: number, title?: any,isActive?: boolean  ) => {

    switch (action) {
      case "preview":
        setPreviewModal(true)
        setPreviewModalRowIndex(rowIndex);

        break;

      case "adjust":
        setCaseType("adjust");
        setadjustInvoiceOpenRowIndex(rowIndex);
        setAdjustInvoiceOpen(true);

        if (rowIndex !== null && rowData[rowIndex]) {
          // console.log("row at adjust", rowData[rowIndex]);

          setFormData((prev) => ({
            ...prev,
            item_amount:  String(rowData[rowIndex].total) || "", // Set item_amount to total by default
          }));
        }
        break;

      case "paynow":
        setCaseType("paynow")
        setProcessPaymentOpenRowIndex(rowIndex);
        // console.log("rowIndex..........", rowIndex);
        setProcessPaymentOpen(true);
        if (rowIndex !== null && rowData[rowIndex]) {
          setSelectedPaymentMode(rowData[rowIndex].payment_mode)
          // console.log("row at paynow",rowData[rowIndex])
          if (rowData[rowIndex].id) {
            const newBillId = rowData[rowIndex].id;
            localStorage.setItem("bill_id", newBillId);
            setBillId(newBillId);  // Update state immediately
            // console.log("Updated Bill ID in localStorage:", newBillId);
            const rawAmountDue = rowData[rowIndex].amount_due || "0";

            const amountDue = Number(rawAmountDue.toString().replace(/,/g, ""));
            console.log("Amount Due:", amountDue);
            const creditCardFeePercent = generalFields?.dropdown?.credit_card_fee || 0;

            // ✅ Calculate fee as a percentage of amountDue
            const creditCardFeeAmount = (amountDue * creditCardFeePercent) / 100;

            // ✅ Add it to total
            const totalAmountWithFee = amountDue + creditCardFeeAmount;
            setRemainingAmount(parseAmount(rowData[rowIndex].remaining))
            // setTotalAmount(totalAmountWithFee || 0);
            setFormData({
              credit_card_fee: true,
              item_amount: String(rowData[rowIndex].amount_due) || "",
              reason: "",
              comment: "",
              fee: creditCardFeePercent,
              reference_no: "",
              payment_method: "Card Payment",
              agent: "",
              received_date: dayjs().format("MM-DD-YYYY"),
              transaction_id: ""
            });
            if(popupHeading === "Billing"){
              // console.log("account number",rowData[rowIndex].account_number)
              console.log("generalFiedls",generalFields.credit_card_fee)
              const account_number_ = rowData[rowIndex].account_number
              const credit_card_fee_ = generalFields.credit_card_fee[account_number_]
              setCreditCardFee(credit_card_fee_)
            }
            else{
              setCreditCardFee(generalFields?.dropdown?.credit_card_fee)            
            }
            setSelectedRow(rowData[rowIndex].id);

          }
          else{
            console.log("Id is not found in the row ")
          }
        }
        break;
      case "repostMRC":
        setRepostModalIndex(rowIndex)
        setRepostModalOpen(true);
        break
      case "edit":
        setEditRowIndex(rowIndex);
        setIsEditable(true);
        setEditModalOpen(true);
        // console.log(editModalOpen);
        break;
      case "delete":
        setActionType("delete")
        setDeleteRowIndex(rowIndex);
        setDeleteModalOpen(true);
        break;
      // case "deactivate":
      //   setActionType(title === "Active" ? "deactivate" : "activate")
      //   setStatusType(title === "Active" ? "Deactivate" : "Activate")
      //   setDeleteRowIndex(rowIndex);
      //   setDeleteModalOpen(true);
      //   break;
      case "deactivate":
      const shouldDeactivate = isActive === true || title === "Active";
      setActionType(shouldDeactivate ? "deactivate" : "activate");
      setStatusType(shouldDeactivate ? "Deactivate" : "Activate");
      setDeleteRowIndex(rowIndex);
      setDeleteModalOpen(true);
      break;

      case "info":
        setEditRowIndex(rowIndex);
        setIsEditable(false);
        setEditModalOpen(true);
        break;
      case "copy":
        setIsEditable(true);
        setCopyModal(true);
        setCopyRowIndex(rowIndex);
        break;
      case "copyPackage":
        setIsEditable(true);
        setCopyPackageModal(true);
        setCopyPackageRowIndex(rowIndex);
        break;
      case "editPackage":
        setIsEditable(true);
        setEditPackageModal(true);
        setEditPackageRowIndex(rowIndex);
        break;
      case "downloadbill":
        handleOptionClick("downloadbill", rowIndex)
        // handleToggleDropdown(rowIndex);
        break
      case "editCollection":
        setCollectionModal(true)
        setCollectionModalRowIndex(rowIndex)
        break
      case "editStep":
        setEditStepModal(true)
        setEditStepModalRowIndex(rowIndex)
        break
      case "cancel-payment":
         setFormData({
              item_amount:  String(rowData[rowIndex].amount).replace(/,/g, "") || "",
              reason: "",
              comment: "",
              fee: "",
              reference_no: "",
              payment_method: "Card Payment",
              agent: "",
              received_date: dayjs().format("MM-DD-YYYY"),
              transaction_id:rowData[rowIndex].ref,
              isChargeBack: false
            });
        setCancelPaymentModal(true);
        setCancelPaymentModalRowIndex(rowIndex);
        break;
      case "chargeback":
        setFormData({
              item_amount:  String(rowData[rowIndex].amount).replace(/,/g, "") || "",
              reason: "",
              comment: "",
              fee: "",
              reference_no: "",
              payment_method: "Card Payment",
              agent: "",
              received_date: dayjs().format("MM-DD-YYYY"),
              transaction_id:rowData[rowIndex].ref,
              apply_fee:rowData[rowIndex].charge_back_fee,
              charge_back_fee : '',
              isChargeBack: true
            });
        setCancelPaymentModal(true);
        setCancelPaymentModalRowIndex(rowIndex);
        break;
      case "downloadreceipt":
        handleDownloadReceipt("payment","Payment",rowData[rowIndex])
      default:
        break;
    }
  };
  const handleCloseModal = () => {
    setEditModalOpen(false);
    setDeleteModalOpen(false);
    setCopyModal(false);
    setCopyPackageModal(false)
    setEditPackageModal(false)
    setCollectionModal(false)
    setEditStepModal(false)
    setPreviewModal(false)
    setRepostModalOpen(false)
  }
  const handleSaveModal = (
    updatedRow?: { [key: string]: any },
    tableData?: any
  ) => {
    if (editRowIndex !== null) {
      // const updatedData = [...rowData];
      // updatedData[editRowIndex] = updatedRow;
      // setRowData(updatedData);
      handleCloseModal();
      setReverseRowData?.()
      // setRowData(tableData)
    }
  };

  useEffect(() => {
    const storedAccountNumber = sessionStorage.getItem("accountNumber");
    if (storedAccountNumber) {
      setAccountNumber(storedAccountNumber);
    }
  }, [setAccountNumber]);
  useEffect(() => {
    const storedBillId = localStorage.getItem("bill_id");
    if (storedBillId) {
      setBillId(storedBillId);
      console.log("Stored Bill ID from localStorage:", storedBillId);
    }
  }, [localStorage.getItem("bill_id")]);

        const customerLinkReports = [
          "A/R Aging",
          "Billing Report w/_City_County_Country",
          "Transaction Analysis",
          "Payment Details",
          "Billed Through Date Report",
          "Export Variance Billing",
          "Total MRC for Sales Person: Catapult",
          "Product Level Tax Mapping"
        ];
        
  const handleRowClick = (row: any, header: string) => {

    if (headerMap[header][0] === "Products / Packages" && popupHeading === "Services") {
      // console.log("Row Products: listtttt", row.products);
      // Debug the data
      setSelctedProductServiceRow(row?.id);
      setSelectedProductsServiceRowData(row);
      setProductDetails(row?.products); // Ensure productDetails is always an array
      setShowPackageModal(true);
      setProductOrPackage(row?.product_name );
    }
    else if (headerMap[header][0] === "Package" && popupHeading === "Services") {
      console.log("Row Products:", row.packages); // Debug the data
      setShowServicePackageDetails(row.packages|| []); // Ensure productDetails is always an array
      setServiceProductModal(true);
      setProductOrPackage(row?.product_name );
    }
   
    else if (headerMap[header][0] === "Account ID" && popupHeading === 'Customer Profiles') {
      const accountNumber = row.account_number;
      const accountName = row.customer_name;
      sessionStorage.setItem("accountNumber", accountNumber);
      sessionStorage.setItem("CustomerName", accountName);

      setAccountNumber(accountNumber);
      setSelectedRow(row.id); // Set the clicked row
      setShowNewPage(true)
      setAdvancedPage?.(true)
        setReverseRowData(row)
        console.log("row", row)
      sessionStorage.setItem("prevTitle", title);
      setPrevTitle(title);

      // Set new title
      const newTitle = accountName
        ? `${title} - ${accountName} (${accountNumber})`
        : `${title} - ${accountNumber}`;

      console.log("title", newTitle);
      setTitle(newTitle);
      sessionStorage.setItem("title", newTitle);
    } 
    else if (
      customerLinkReports.includes(popupHeading) &&
      (headerMap?.[header]?.[0] === "Customer ID" ||
        headerMap?.[header]?.[0] === "Account Number" || headerMap?.[header]?.[0] === "Account ID")
    ) {
      const accountNumber = row.account_number || row.customer_id;

      const accountName = row.customer_name;

      if (!accountNumber) return;

      // store data
      sessionStorage.setItem("accountNumber", accountNumber);
      sessionStorage.setItem("CustomerNumber", accountNumber);
      if (accountName) {
        sessionStorage.setItem("customer_name", accountName);
      }

      // redirect
      setAccountNumber(accountNumber);
      router.push("/billing/customer_profiles");

      sessionStorage.setItem("isCustomerProfileNav", "false");
      sessionStorage.setItem("is_redirected", "true");

      return;
    } else if (
      headerMap[header][0] === "Customer ID" &&
      popupHeading === "Chargebacks & Returns"
    ) {
      const accountNumber = row.account_number;
      const accountName = row.customer_name;
      sessionStorage.setItem("accountNumber", accountNumber);
      sessionStorage.setItem("CustomerNumber", accountNumber);
      sessionStorage.setItem("customer_name", accountName);

      setAccountNumber(accountNumber);
      router.push("/billing/customer_profiles");
      // setIsCustomerProfilesNav(false)
      sessionStorage.setItem("isCustomerProfileNav","false")
      
      // setSelectedRow(row.id); // Set the clicked row
      // setShowNewPage(true)
      // setAdvancedPage?.(true)
      // setReverseRowData(row)
      // console.log("row", row)

      sessionStorage.setItem("is_redirected", "true");
      // // setPrevTitle(title);

      // Set new title
      // const newTitle = accountName
      //   ? `${"Customer Profiles"} - ${accountName} (${accountNumber})`
      //   : `${"Customer Profiles"} - ${accountNumber}`;

      // console.log("title", newTitle);
      // setTitle(newTitle);
      // sessionStorage.setItem("title", newTitle);
    }
   else if (headerMap[header][0] === "Account ID" && popupHeading === 'Customer Profiles1') {
  // Clear previous account info
  sessionStorage.removeItem("accountNumber");
  sessionStorage.removeItem("title");
  setAccountNumber('');

  const accountNewNumber = row.account_number;
  const accountNewName = row.customer_name;

  sessionStorage.setItem("accountNumber", accountNewNumber);
  console.log("New Account Number:", accountNewNumber);
  setAccountNumber(accountNewNumber);
  setSelectedRow(row.id); // Set the clicked row
  const title1 = sessionStorage.getItem("prevTitle");
  // Set new title
  const newTitle = accountNewName
    ? `${title1} - ${accountNewName} (${accountNewNumber})`
    : `${title1} - ${accountNewName}`;

  setTitle(newTitle);
  sessionStorage.setItem("title", newTitle);
  onTabsClose(accountNewNumber) 
    }
    else if (header === "bill_id") {
      setShowChargesPage(true)
      setSelectedRow(row.id);
      // localStorage.setItem("acountNumber", row.account_number);
      localStorage.setItem("bill_id", row.id);
      // setAccountNumber(row.account_number);
      setBillId(row.id);
    }
    else if (headerMap[header][0] === "Tax" && popupHeading === "Unposted"){
      setTaxesModalOpen(true);
      setSelectedRow(row);
    }
     else if (popupHeading === "A/R Aging" && headerMap[header][0] === "Collection Step") {
      console.log("Collection Step clicked for row:", row);
  setCollectionStepsRowData(row);
  setIsCollectionStepsModal(true);
    }
  };
  const closeAdvancedTabs = () => {
    // console.log("closing all the tabs")
    setShowNewPage(false);
    setAdvancedPage?.(false)
    setSelectedRow(null);
    setUserProfileDetails({});
    // Retrieve and restore the previous title

    const storedPrevTitle = sessionStorage.getItem("prevTitle") || "";
  if(storedPrevTitle){
      setTitle(storedPrevTitle);
    }
    sessionStorage.setItem("title", storedPrevTitle);
    onTabsClose()// Close the AdvancedTab and show the Actions button
  };
  const handleChargesModalClose = () => {
    setShowChargesPage(false);
  }
  const handleToggleDropdown = (index: number) => {
    setOpenIndex((prevIndex) => (prevIndex === index ? null : index)); // Toggle the dropdown state
  };
  const handleClickOutside = (event: MouseEvent) => {
    if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
      setOpenIndex(null); // Close dropdown if clicked outside
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);

    // Cleanup event listener on component unmount
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
const DownloadBillPdf = async (key: string, heading: string, row: any) => {
  addExport(key, heading);
  // setLoading(true);

  const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;

  const baseData = {
    tenant_name: partner || "default_value",
    username,
    role_name: role,
    parent_module: "Billing Platform",
    module_name: "Billing and Collections Bills",
    feature_module_name: "Customer Services",
    main_module_name: "Customer Profiles",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    billing_db_name: selectedBillingDb,
    sessionID: sessionId,
    tenant_id: tenant_id_,
    start_date: getFirstDayOfCurrentMonth(),
    end_date: getLastDayOfCurrentMonth(),
    killbill_flag: "True",
    account_number: accountNumber,
    id: row.id,
    ...metaData,
  };

  try {
    axios.post(url, {
      data: {
        ...baseData,
        path: "/generate_bill_pdf",
      },
    }).catch(() => {
      // Ignore errors – polling will handle final status
      console.warn("generate_bill_pdf request failed or timed out");
    });
    const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

    const pollExportStatus = async (): Promise<boolean> => {
       await delay(5000);
      const res = await axios.post(url, {
        data: {
          ...baseData,
          module_name :"Bill PDF",
          path: "/get_export_status",
        },
      });

      const parsed = JSON.parse(res.data.body);

      if (parsed?.flag && parsed?.export_status_data?.status_flag === "Success") {
        const s3Url = parsed?.export_status_data?.url;
        if (!s3Url) throw new Error("Download URL missing");

        const blob = await fetch(s3Url).then((r) => r.blob());
        const downloadUrl = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = downloadUrl;
        a.download = `${row.bill_id}.pdf`;
        a.click();
        a.remove();

        window.URL.revokeObjectURL(downloadUrl);

        notification.success({
          message: "Success",
          description: parsed.message || "Bill downloaded successfully",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons()
        return true; // stop polling
      }

      if (
        parsed?.export_status_data?.status_flag === "Failure" ||
        parsed?.export_status_data?.status_flag === "No Data Found for export"
      ) {
        Modal.error({
          title: "Export Error",
          content: parsed.message || "Failed to generate bill PDF",
          centered: true,
        });
        return true; // stop polling
      }

      return false; // continue polling
    };

    let completed = false;
    while (!completed) {
      completed = await pollExportStatus();
      if (!completed) {
        await new Promise((resolve) => setTimeout(resolve, 5000));
      }
    }

  } catch (error) {
    Modal.error({
      title: "Export Error",
      content:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred. Please try again.",
      centered: true,
    });
  } finally {
    removeExport(key);
    // setLoading(false);
  }
};


const handleDownloadReceipt= async (key: string, heading: string, row:any) => {
  try {
    addExport(key, heading);
    // setLoading(true)
    const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;

    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/generate_payment_receipt",
      role_name: role,
      parent_module: "Billing Platform",
      module_name: "Payment History",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
      sessionID: sessionId,
      tenant_id: tenant_id_,
      id: row.id,
      feature_module_name: "Payment History",
      start_date: getFirstDayOfCurrentMonth(),
      end_date: getLastDayOfCurrentMonth(),
      killbill_flag: "True",
      table_name:"payment_history",
      account_number: accountNumber,
      main_module_name: "Customer Profiles",
    };

    // Normal API call (no timeout, no polling)
    const response = await axios.post(url, { data });

    // Parse API response
    const parsed = JSON.parse(response.data.body);
    const s3Url = parsed?.download_url;

    if (parsed.flag && s3Url) {
          // setLoading(false)
      const res = await fetch(s3Url);
      const blob = await res.blob();
      const downloadUrl = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = downloadUrl;
      a.download = `Bill_${row.id}.pdf`;
      a.click();
      a.remove();

      window.URL.revokeObjectURL(downloadUrl);

      notification.success({
        message: "Success",
        description: parsed.message || "Successfully downloaded the record!",
        style: messageStyle,
        placement: "top",
      });
      fireSideCannons();
    } else {
      Modal.error({
        title: "Export Error",
        content: parsed?.message || "An error occurred while exporting data. Please try again.",
        centered: true,
      });
    }
  } catch (error) {
    Modal.error({
      title: "Export Error",
      content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      centered: true,
    });
  } finally {
    removeExport(key);
    setLoading(false)
  }
};

  const handleOptionClick = (action: string, index: number) => {
    setIsOpen((prev) => ({ ...prev, [index]: false })); // Close the menu for the specific row
    // console.log(action,"Show action");
    // console.log(index,"show index")
    // console.log(rowData[index],"show the rowdataaaa.....")
    const selectedRowData = rowData[index];
    const updatedTableData = [...rowData];

    setServiceSelectedRow(selectedRowData);
    // Add your logic for each action
    switch (action) {
      case "downloadbill":
        DownloadBillPdf("PDF","PDF",selectedRowData)
        break;
      case "downloadExcel":
        ExportWithoutSearch("EXCEL", "EXCEL", rowData[index])
        break;
      case "emailBill":
        console.log("Emailing bill...");
        break;
      case "editServiceLocation":
        console.log(rowData, "Show rowData");
        // Set the selected row data
        setEditServiceModalOpen(true); // Open the edit service modal
        console.log("Editing service...");
        break;
      case "disconnectService":
        console.log(rowData[index], "Show rowData for disconnect");
        onDisconnectService?.(rowData[index]); // Pass the row data to the disconnect handler
        setOpenIndex(null); // Close the dropdown menu
        break;
      case "editProduct":
        console.log("Editing product...");
        setEditServiceProductModalOpen(true);
        setIsEditable(true);
        setEditServiceProductRowIndex(index);
        break;
        case "editNewService":
          console.log("Editing New service...");
          setEditNewServiceModalOpen(true);
          setIsEditable(true);
          setEditNewServiceRowIndex(index);
          break;
      case "editStep":
        setEditStepModal(true)
        setEditStepModalRowIndex(index)
        break
      case "movedown":
        setMoveDownConfirmModalOpen(true)
        console.log(rowData, "Show rowData");
        setMoveDownModalRowIndex(index)
        break
      case "moveup":
        setMoveUpConfirmModalOpen(true)
        console.log(rowData, "Show rowData");
        setMoveUpModalRowIndex(index)
        break
      case "closureStep":

        updatedTableData[index].closure_step = !updatedTableData[index].closure_step;  // Toggle boolean

        setRowData(updatedTableData);
        break
      case "removeClosureStep":
        updatedTableData[index].closure_step = false;
        setRowData(updatedTableData);
        break;
      case "promiseFailureStep":

      updatedTableData[index].promise_step = !updatedTableData[index].promise_step;  // Toggle boolean

        setRowData(updatedTableData);
        break
      case "removePromiseStep":
        updatedTableData[index].promise_step = false;
        setRowData(updatedTableData);
        break;
      default:
        console.log("Unknown action");
    }
  };
  // console.log("Show products details",productDetails);

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }
  const ExportWithoutSearch = async (key: string, heading: string, id: any) => {
      try {
      // Add the export to the store
      addExport(key, heading);

      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };

      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/generate_bill_excel",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Bill EXCEL",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        account_number:accountNumber? accountNumber:id?.account_number,
        id:id.id,
        access_token: token,
        db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Generate Bill",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag: "True",
          main_module_name: "Customer Profiles",
      };

      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      // await new Promise((resolve) => setTimeout(resolve, 20000));

      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        module_name:"Bill EXCEL",
        path: "/get_export_status",
      };

      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);

          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              const invoiceId = id?.id || "INV"; // fallback safety
              const response = await fetch(s3Url);
              const blob = await response.blob();
              const downloadUrl = window.URL.createObjectURL(blob);
              const paddedInvoiceId = String(invoiceId).padStart(4, "0");
              const a = document.createElement("a");
              a.href = downloadUrl;
              a.download = `INV${paddedInvoiceId}.xlsx`;
              document.body.appendChild(a);
              a.click();
              a.remove();

              window.URL.revokeObjectURL(downloadUrl);
              notification.success({
                message: "Success",
                description: "Successfully exported the  record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons();
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }

          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }

          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };

      const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key); // Remove the export from the store
    }
  };

// const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, row: any) => {
  
//   const isChecked = event.target.checked;

//   // Since the checkbox is disabled for these conditions, this check is redundant but kept for safety
//   if (popupHeading === "Unposted" && (row.from_customer_service === true || row.from_customer_service === "true")) {
//     console.warn(`Cannot select row ${row.id}: from_customer_service is true for Unposted`);
//     return;
//   }

//   setSelectedRows((prevSelected) => {
//       if (isChecked) {
//         // Add the row to selectedRows
//         setReverseRowData((prev: any) => [...prev, row]);
//         return [...prevSelected, row];
//       } else {
//         // Remove the row from selectedRows
//         setReverseRowData((prev: any[]) => prev.filter((r: any) => r !== row));
//         return prevSelected.filter((r) => r !== row);
//       }
//     });

//     console.log("Selected Row Data:", setReverseRowData); // Might not immediately show the latest state due to React's batching
//     console.log("Selected Rows:", selectedRows);
//   };
 const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, row: any) => {
  console.log("isselectallchecked",isSelectAllChecked)
  const isChecked = event.target.checked;

  // Check if the checkbox should be disabled
  if (popupHeading === "Unposted" && (row.from_customer_service === true || row.from_customer_service === "true")) {
    console.warn(`Cannot select row ${row.id}: from_customer_service is true for Unposted`);
    return;
  }
   if (popupHeading === "Billing" && !eligibleAccounts.includes(row.account_number)) {
     console.warn(`Cannot select row ${row.id}: account_number ${row.account_number} is not in eligible accounts`);
     return;
   }
  setSelectedRows((prevSelected) => {
     let updatedSelectedRows: any[];
    if (isChecked) {
      // Add the row ID to selectedRows
      setReverseRowData((prev: any) => [...prev, row]);
      // return [...prevSelected, row.id]; // Store only the ID
      updatedSelectedRows = [...prevSelected, row.id];
    } else {
      // Remove the row ID from selectedRows
      setReverseRowData((prev: any[]) => prev.filter((r: any) => r.id !== row.id));
      // return prevSelected.filter((id) => id !== row.id); // Store only the ID
        updatedSelectedRows = prevSelected.filter((id) => id !== row.id);
    }
    setIsAllSelected(
      updatedSelectedRows.length === initialData.length &&
      initialData.length > 0
    );

    return updatedSelectedRows;
  });

  // console.log("Selected Row Data:", setReverseRowData); // Might not immediately show the latest state due to React's batching
  // console.log("Selected Rows:", selectedRows);
};
const handleSelectAllUnpostedRows = (event: React.ChangeEvent<HTMLInputElement>) => {
  // Filter rows that are NOT disabled (from_customer_service true)
   const isChecked = event.target.checked;
  const selectableRows = tabledata.length > 0 ? tabledata : initialData

  if (isChecked) {
    setSelectedRows(selectableRows.map((row: { id: any; }) => row.id)); 
    // console.log("rowdata",rowData)
    // console.log("selectableRows",selectableRows.map(row => row.id))
    setRowData(selectableRows)
    setReverseRowData(selectableRows); // Full row objects
    setIsAllSelected(true);
    setIsSelectAllChecked(isChecked);
  } else {
    setSelectedRows([]);
    setReverseRowData([]);
    setIsAllSelected(false);
    setIsSelectAllChecked(isChecked);
  }
};

 
  const handleSelectCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>, row: any) => {
    const isChecked = event.target.checked;
    // console.log("isselectallchecked",isSelectAllChecked)
    // console.log("Row data in checkbox change:", row);
    // Check if the row's remaining amount is 0 and disable selection
    if (popupHeading === "Bills" && parseAmount(row.remaining) <= 0) {
      return; // Do not allow selection if remaining is 0
    }
    setSelectedRows(prevSelected => {
      let updatedSelectedRows = prevSelected
      // Apply restriction only if popupHeading is "Bills"
      if (popupHeading === "Bills" && (!row.payment_mode || row.payment_mode === "Money Order" || row.payment_mode === "Paper Check")) {
        return prevSelected; // Don't change selection if it's an invalid payment mode
      }
      updatedSelectedRows = isChecked
        ? [...prevSelected, row.id] // Add row ID if checked
        : prevSelected.filter(id => id !== row.id); // Remove row ID if unchecked
      // Update the "Select All" state
      if (popupHeading === "Bills" && isChecked) {
        const validRows = initialData.filter(row => row.payment_mode && row.payment_mode !== "Money Order" && row.payment_mode !== "Paper Check" && parseAmount(row.remaining) > 0);
        setIsAllSelected(updatedSelectedRows.length === validRows.length);
      } else {
        setIsAllSelected(updatedSelectedRows.length === initialData.length);
      }
      // Update reverse row data
      if (typeof setReverseRowData === "function") {
        setReverseRowData(updatedSelectedRows);
      } else {
        console.error("setReverseRowData is not a function");
      }
      return updatedSelectedRows;
    });
  };
 const handleSelectAllCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const isChecked = event.target.checked;
    let updatedSelectedRows;
    let validRows = initialData;
    
    if (popupHeading === "Bills") {
      setIsSelectAllChecked(isChecked);
      // Filter out rows with invalid payment modes (null, "Money Order", "Paper Check") and remaining amount of 0

      validRows = initialData.filter(row =>
        row.payment_mode &&
        row.payment_mode !== "Money Order" &&
        row.payment_mode !== "Paper Check" &&
        parseAmount(row.remaining) > 0
      );
    } else if (popupHeading === "Billing") {
      // ✅ FIXED: For Billing, only select rows with eligible account numbers (always filter by eligibleAccounts)
      validRows = rowData.filter(row => eligibleAccounts.includes(row.account_number));
      // console.log("Select All - Eligible accounts list:", eligibleAccounts);
      // console.log("Select All - Valid rows found:", validRows.length);
    }
 
    updatedSelectedRows = isChecked ? validRows.map(row => row.id) : [];
   
    setSelectedRows(updatedSelectedRows);
    setIsAllSelected(isChecked);
   
    if (typeof setReverseRowData === "function") {
      // ✅ NEW: Pass the actual row objects, not just IDs
      const selectedRowData = isChecked ? validRows : [];
      setReverseRowData(selectedRowData);
    } else {
      console.error("setReverseRowData is not a function");
    }
  };
 
 


  // Update the isAllSelected state whenever selectedRows changes
  useEffect(() => {
    // if(selectedRows.length !== 0 && initialData.length!==0){
    //   setIsAllSelected(selectedRows.length === initialData.length);
    // }
    // else{
    //   setIsAllSelected(false);
    // }
    const totalAmount = (Array.isArray(initialData) ? initialData : [])
  .filter((row: any) => selectedRows.includes(row.id))
  .reduce((sum: number, row: any) => sum + (row.amount_due || 0), 0);

  setTotalAmount(totalAmount)
    // console.log(selectedRows,"Selected Rows.......",initialData,"initial rowws....")
  }, [selectedRows, initialData]);
  const handleInputChange =
    (field: string) =>
      (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const value = e.target.value;

        if (field === "item_amount") {
          const regex = /^\d+(\.\d{0,2})?$/;
           if (value === "" || regex.test(value)) {
              setFormData((prev) => ({
                ...prev,
                item_amount: value,
              }));
            }
          if(Number(value) > remainingAmount){
             setFormErrors((prevErrors) => ({
                          ...prevErrors,
                          item_amount: `Item amount cannot exceed the total remaining amount of ${remainingAmount}.`,
                        }));
              return;

          }
          const cleanValue = value.replace(/,/g, "");
          if (!regex.test(cleanValue)) {
            return;
            // setFormErrors((prevErrors) => ({
            //   ...prevErrors,
            //   item_amount: "Only numbers with up to 2 decimal places are allowed.",
            // }));
          } else if (value === "0") {
            setFormErrors((prevErrors) => ({
              ...prevErrors,
              item_amount: "Entered Number is Invalid",
            }));
          } else if (/^0\d+/.test(value)) {
            setFormErrors((prevErrors) => ({
              ...prevErrors,
              item_amount: "Item Amount should not start with 0",
            }));
          } else {
            setFormErrors((prevErrors) => ({
              ...prevErrors,
              item_amount: "", // Clear error if valid
            }));
          }
        }

        setFormData((prev) => ({
          ...prev,
          [field]: value,
        }));
      };


  useEffect(() => {
    // console.log("Updated formData:", formData);
  }, [formData]); // Logs whenever formData changes


  const GetToken = async (row: any) => {
    // setLoading(true);
    if (accountNumber) {
      sessionStorage.setItem("account_number", accountNumber);
    }
    const newBillId: number = row.id ? Number(row.id) : Number(localStorage.getItem("bill_id")) || 0;

    // Store bill_id as an array of numbers
    const billIdArray: number[] = newBillId ? [newBillId] : [];
    try {

      // console.log("row",row)     
      let data;
      const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
      data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_payment_token",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: popupHeading,
        // feature_module_name: "Billing and Collections Bills",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        // table_name: "sim_management_inventory",
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        tenant_id:tenant_id_,
        action: "create",
        modified_by: firstLastName,
        credit_card_flag: formData?.credit_card_fee ?? "False",
        account_number:row.account_number ? Number(row.account_number):accountNumber,
        bill_id:billIdArray,
        ...formData,
        item_amount: formData?.item_amount
          ? String(formData.item_amount).replace(/,/g, "")
          : "",
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      // console.log(resp, "show the response");

      if (response.data.statusCode === 200 && resp.flag === true) {
        if(resp.batch_id){
          const batchId_ = resp.batch_id;
          // setBatchId(batchId_);
          // console.log("Batch ID:", batchId_);
          localStorage.setItem("batch_id", batchId_ ); 
        }
        if (resp.token) {
          // const trxIframeUrl = `https://trx-iframe-host/paynow?token=${resp.token}`;
          console.log("tokennn",resp.token)
          setIframeUrl(resp.token);
          setSinglePaymentModalOpen(true)
          setIsProcessing(false);
          setProcessPaymentOpen(false)
        } else {
          throw new Error("Payment token missing in response.");
        }
      } else {
        Modal.error({
          title: "Data Error",
          content: resp.message || "Something went wrong while Fetching token",
          centered: true,
        });
        // setLoading(false);
        handleCancel()
        setIsProcessing(false);

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Error',
        content: 'Missing Payment Token',
        centered: true,
      });
      handleCancel()
      // setLoading(false);

    } finally {
      // setLoading(false);
      setIsProcessing(false);
    }
  };
  const handleCancel = () => {
    setProcessPaymentOpen(false);
    setFormData({
        item_amount: null,
        reason: null,
        comment: null,
        fee: null,
        reference_no: null,
        payment_method: null,
        agent: null,
        received_date: null,
        transaction_id:null,
      });
    setFormErrors({ item_amount: "" });
    setAmount("")
    setIsAmountModalOpen(false)
    setCallFetchdata(true)

  };
  const handleClosePaynowModal = () => {
    setProcessPaymentOpen(false);
    setFormData({
        item_amount: null,
        reason: null,
        comment: null,
        fee: null,
        reference_no: null,
        payment_method: null,
        agent: null,
        received_date: null,
        transaction_id:null,
      });
    setFormErrors({ item_amount: "" });
    setAmount("")
    setIsAmountModalOpen(false)
  }
  const ReportsModule =["Transaction Analysis","A/R Aging","Altaworx Billing Report","Charge By Service","Billing Charge By Service","Chargebacks & Returns","Billing Report w/_City_County_Country","Export Variance Billing","Total MRC for Sales Person: Catapult","Collections Summary" ,"Product Level Tax Mapping"]
  const freezeColumn = (header:string) =>{
    if(
      ((popupHeading === "Bills" && header === "bill_id") || ( !ReportsModule.includes(popupHeading) && header === "account_number") ||
      (popupHeading === "Automation rule" && header === "automation_rule_name")) && rowData.length > 0
    ){
      return true
    }
    else{
      return false
    }
  }
  const currencyHeaders = ["Rate", "Charges", "Credits", "Payments", "Total", "Amount Due", "Remaining", "Charge", "Credit", "Balance", "Amount","Account Balance","Grouped","Ungrouped","One Time Charge","MRC","SMS","Balance Limit","Balance Forward","NRC","Network Access Fee","Admin Recovery Tax","Other Taxes","Cost Recovery Fee","Usage","SMS"];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  const handlePaymentModeChange = async (row: { [key: string]: any }, newValue: string , index: any) => {
    // console.log("Payment Mode changed for row:", row, "New Value:", newValue);
    setSelectedPaymentMode(newValue);
    setTotalAmount(row.amount_due)
    setSelectedPaymentMethodAccountNumber(row.account_number)
    setProcessPaymentOpenRowIndex(index)
    setSelectedRow(row.id);
    setRemainingAmount(parseAmount(row.remaining));
    if (newValue === "Paper Check" || newValue === "Money Order") {
      setIsAmountModalOpen(true);
    } else {
      setIsConfirmModalOpen(true);
    }
     setFormData({
    item_amount: String(row.amount_due) || "",
    reason: "",
    comment: "",
    fee: "",
    reference_no: "",
    payment_method: "",
    agent: "",
  received_date: dayjs().format("MM-DD-YYYY"),
   transaction_id:""
  });
  };
  const handleConfirmChange = async (flag?:any) => {
    setIsConfirmModalOpen(false);
    if (!selectedRow) return;
    const rowindex =ProcessPaymentOpenRowIndex !== null ? rowData[ProcessPaymentOpenRowIndex]:null
    if (!formData.item_amount) {
      setFormErrors({ item_amount: "Item Amount is required" });
      return; // Stop execution if validation fails
    }
    formData["item_amount"]=(formData.item_amount).toString()
    if(formData.item_amount > parseAmount(rowindex?.remaining)){
      setFormErrors({ item_amount: `Item amount cannot exceed the total remaining amount of ${rowindex?.remaining}` });
      return; // Stop execution if validation fails
    }
    setFormErrors({ item_amount: "" });

    console.log("Payment Mode changed for row:", selectedRow, "New Value:", selectedPaymentMode,"Account number", accountNumber);

    setLoading(true);
    try {
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/change_payment_mode",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Bills",
        feature_module_name: "Billing and Collections Bills",
          main_module_name: "Customer Profiles",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        account_number: accountNumber?accountNumber:selectedPaymentAccountNumber,
        payment_mode: selectedPaymentMode,
        // amount:amount,
        // bill_id: selectedRow,
        bill_id: [selectedRow],
        flag:flag,
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        modified_by: firstLastName,
        ...formData
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);

      // console.log(resp, "show the response");

      if (response.data.statusCode === 200 && resp.flag === true) {
        notification.success({
          message: "Success",
          description: resp.message || "Successfully updated payment mode!",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons();

        setRowData((prevData) =>
          prevData.map((item) =>
            item.id === selectedRow ? { ...item, payment_mode: selectedPaymentMode } : item
          )
        );
        handleCancel()

      } else {
        Modal.error({
          title: "Saving Error",
          content: resp.message,
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        //  onOk: onclose
      });
    } finally {
      setLoading(false);
    }
  };
  const handleConfirmMoveDown = () => {
    if (isMoveDownRowIndex === null || isMoveDownRowIndex < 0 || isMoveDownRowIndex >= initialData.length - 1) return;

    const updatedTableData = [...initialData];

    // Swap the row with the next row
    const temp = updatedTableData[isMoveDownRowIndex];
    updatedTableData[isMoveDownRowIndex] = updatedTableData[isMoveDownRowIndex + 1];
    updatedTableData[isMoveDownRowIndex + 1] = temp;

    // Recalculate day values correctly
    updatedTableData.forEach((row, index) => {
      if (index === 0) {
        // First row → day = grace_period
        row.day = row.grace_period.toString();
        // console.log(`Row ${index + 1} (First row): day = ${row.day} (grace period: ${row.grace_period})`);
      } else {
        const previousRow = updatedTableData[index - 1];

        // Correct calculation: Previous day + current grace_period
        const newDay = parseInt(previousRow.day, 10) + row.grace_period;

        row.day = newDay.toString();

        // console.log(`Previous Row Day: ${previousRow.day}`, previousRow);
        // console.log(`Row ${index + 1}: newDay = ${newDay}`);
      }
    });
    setRowData(updatedTableData);
    setTableData?.(updatedTableData)
    setMoveDownConfirmModalOpen(false);
  };
  const handleConfirmMoveUp = () => {
    if (isMoveUpRowIndex === null || isMoveUpRowIndex <= 0) return;  // Prevent invalid moves

    const updatedTableData = [...rowData];

    // Swap the current row with the previous row
    const temp = updatedTableData[isMoveUpRowIndex];
    updatedTableData[isMoveUpRowIndex] = updatedTableData[isMoveUpRowIndex - 1];
    updatedTableData[isMoveUpRowIndex - 1] = temp;

    // Recalculate the day values after the swap
    updatedTableData.forEach((row, index) => {
      if (index === 0) {
        row.day = row.grace_period.toString();  // First row → day = grace_period
      } else {
        const previousRow = updatedTableData[index - 1];
        const newDay = parseInt(previousRow.day, 10) + row.grace_period;
        row.day = newDay.toString();  // Calculate day based on new order
      }
    });

    setRowData(updatedTableData);
    setTableData?.(updatedTableData);
    setMoveUpConfirmModalOpen(false);  // Close the modal
  };
  const handleConfirmCancelPayment = async () => {
    setCancelPaymentModal(false)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
      const updated_data: any = {
      transaction_id: formData.transaction_id,
      amount: formData.item_amount,
      reason: formData.reason,
      };
      if (formData.isChargeBack && formData.charge_back_fee ) {
        updated_data.charge_back_fee = generalFields.charge_back_fee;
      }
      const accountName = sessionStorage.getItem("CustomerName")
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: formData.isChargeBack ? "/transaction_charge_back" : "/cancel_payment",
        role_name: role,
        account_number: accountNumber,
        customer_name:accountName,
        parent_module: "Billing Platform",
        module_name: "Payment History",
        table_name: "cancel_payment_history",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        updated_data,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id:tenant_id_,
        db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Payment History",
        main_module_name: "Payment History",
      };

      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        if(parsedData.validation){
           Modal.error({
          title: "Validation Error",
          content: parsedData.message,
          centered: true,
        });
        return;
        }
        setLoading(true)
        await updatePaginator()
        setLoading(false)
        notification.success({
          message: "Success",
          description: parsedData.message||"Updated Successfully",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons();
        // setRowData(parsedData?.data?.customer_services || []);
      }
      else{
        Modal.error({
          title: "Saving Error",
          content: parsedData.message,
          centered: true,
        });
      }
    }
    catch { }
    finally { setLoading(false) }
  }
  const afterFetchData=async()=>{
    setShowPackageModal(false);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/customer_services_list_view",
        role_name: role,
        account_number: accountNumber,
        parent_module: "Billing Platform",
        module_name: "Customer Services",
        table_name: "customer_services",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id:tenant_id_,
        db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        status: servicesActive ? "true" : "false",
        feature_module_name: "Customer Services",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        setRowData(parsedData?.data?.customer_services || []);
      };
    }
    catch { }
    finally { setLoading(false) }

  }

  const handleCancelChange = () => {
    setIsConfirmModalOpen(false);
    setSelectedPaymentMode("");
    setSelectedPaymentMethodAccountNumber("");
    setMoveDownConfirmModalOpen(false);
    setMoveUpConfirmModalOpen(false);
    setCancelPaymentModal(false)
  };
  const handlePayNowClick = () => {
    const rowindex =ProcessPaymentOpenRowIndex !== null ? rowData[ProcessPaymentOpenRowIndex]:null
    if (!formData.item_amount) {
      setFormErrors({ item_amount: "Item Amount is required" });
      return; // Stop execution if validation fails
    }
    formData["item_amount"]=(formData.item_amount).toString()
    if(formData.item_amount > parseAmount(rowindex?.remaining)){
      setFormErrors({ item_amount: `Item amount cannot exceed the total remaining amount of ${rowindex?.remaining}` });
      return; // Stop execution if validation fails
    }
    setFormErrors({ item_amount: "" });
    if(formData.payment_method.toLowerCase() === "paper check" || formData.payment_method.toLowerCase() === "money order"){
        handleConfirmChange('transaction');
    }
    else{
      setIsProcessing(true);
      GetToken(rowindex );
      // setProcessPaymentOpen(false);
    }
  };
  const handleAdjustClick = async () =>{
    if (!formData.item_amount) {
      setFormErrors({ item_amount: "Item Amount is required" });
      return; // Stop execution if validation fails
    }
    setFormErrors({ item_amount: "" });
    setIsConfirmModalOpen(false);
    // console.log("selected row for adjust", adjustInvoiceOpenRowIndex !== null && rowData[adjustInvoiceOpenRowIndex].id);

    setLoading(true);
    try {
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/adjust_bill_amount",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Bills",
        feature_module_name: "Billing and Collections Bills",
          main_module_name: "Customer Profiles",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        account_number: accountNumber,
        item_amount:formData.item_amount,
        table_name:"customer_bills",
        // payment_mode: selectedPaymentMode,
        // bill_id: selectedRow,
        id:  ProcessPaymentOpenRowIndex !== null ? rowData[ProcessPaymentOpenRowIndex].id:"",
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        modified_by: firstLastName,
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);

      // console.log(resp, "show the response");

      if (response.data.statusCode === 200 && resp.flag === true) {
        notification.success({
          message: "Success",
          description: resp.message||"Updated Successfully",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons();

        setRowData((prevData) =>
          prevData.map((item, index) =>
            index === ProcessPaymentOpenRowIndex
              ? { ...item, total: formData.item_amount }
              : item
          )
        );

        handleCancel()
      } else {
        Modal.error({
          title: "Saving Error",
          content: resp.message,
          centered: true,
        });
        handleCancel()
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        //  onOk: onclose
      });
    } finally {
      setLoading(false);
    }
  }
  const handleTaxClick = (rowData: any) => {
    setSelectedRow(rowData);
    setTaxesModalOpen(true);
  }

const paginationComponent = (
    <BillingPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading} />
);
  const isPayNowDisabled = !formData.item_amount || !!formErrors.item_amount;
  const tablesInModals = ["Charge By Service","Billing Charge By Service","Charge Details"]
  const hasAnyEligible = rowData.some(row =>
  eligibleAccounts.includes(row.account_number)
);
const reversedBillIds = new Set(
  rowData
    .filter(row => row.type === "Reverse Bill")
    .map(row => {
      const match = row.description?.match(/Reversed Bill ID:\s*(INV\d+)/);
      return match?.[1];
    })
    .filter(Boolean)
);
  return (

    <div>

      {isSmallScreen && visibleColumns.length > 0 && (
        <div className="flex justify-end mb-2 mr-2">
          {paginationComponent}
        </div>
      )}
      <div className="overflow-x-auto">
      <div className="overflow-x-auto overflow-y-auto"
        style={{
          height: popupHeading === "Service Product" || popupHeading === "Charge Details"
            ? undefined  // Let height be auto
            : `${viewportHeight - height}px`,
          minHeight: popupHeading === "Service Product"
            ? "300px"    // Set a fixed minimum height
            : undefined, // No minHeight otherwise
          maxHeight:popupHeading === "Charge Details"?`${viewportHeight - height}px`:undefined
        }}
      >
          <table className="table-auto w-full">
            <thead className={`sticky top-0 bg-gray-200 z-10 ${tablesInModals.includes(popupHeading)?"disconnect-table-header":"table-header-row"}`}>
              <tr>
                {(typeof window !== "undefined" && window.innerWidth < 700) && rowData.length > 0 && (
                  <th
                    className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 freeze-header`}
                    style={{
                      cursor: "pointer", position: "sticky", left: 0, zIndex: 11,minWidth: "40px"
                    }}>

                  </th>
                )}
                {(popupHeading === "Unposted" || popupHeading === "Transfer Service" || popupHeading === "Reversals" || popupHeading === "Reversals Unposted" || popupHeading === "RepostMRCs" ) && rowData.length > 0  &&(
                    //  <th className="px-4 py-2 border-b border-gray-300 table-cell">
                    <th className="px-4 py-2 border-b border-gray-300 text-left font-semibold table-header sticky top-0 w-[50px] freeze-header" style={{ position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : 0, zIndex: 11 }}>
                    {/* Checkbox for selecting all rows */}
                    <input
                      type="checkbox"
                      className="cursor-pointer"
                      checked={isAllSelected} // Bind header checkbox to isAllSelected state
                      onChange={handleSelectAllUnpostedRows}
                    />
                  </th>
                )}
                {(popupHeading === "Service Product" )&& (
                  <th className="px-4 py-2 border-b border-gray-300 table-cell">
                    {/* Checkbox for selecting all rows */}
                    <input
                      type="checkbox"
                      className="cursor-pointer"
                      checked={isAllSelected} // Bind header checkbox to isAllSelected state
                      onChange={handleSelectAllCheckboxChange}
                    />
                  </th>
                )}
                 {(popupHeading === "Billing") && (
                 <th className="px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 w-[50px] freeze-header" style={{ position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : 0, zIndex: 11 }}>
                  {(hasAnyEligible)
                    ? (
                        <input
                          type="checkbox"
                          className="cursor-pointer"
                          checked={isAllSelected}
                          onChange={handleSelectAllCheckboxChange}
                        />
                      )
                    : (
                        // Keep space → hide checkbox but preserve layout
                        <input
                          type="checkbox"
                          style={{ visibility: "hidden" }}
                          readOnly
                        />
                      )
                  }
                </th>
                )}
                {popupHeading === "Bills" && rowData.length > 0 && allowedActions && allowedActions.length > 0 &&(
                  // <th className="px-4 py-2 border-b border-gray-300 table-cell">
                    <th className="px-4 py-2 border-b border-gray-300 table-cell text-left font-semibold table-header sticky top-0 w-[50px] freeze-header" style={{ position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : 0, zIndex: 11 }}>
                    {/* Checkbox for selecting all rows */}
                    <input
                      type="checkbox"
                      className="cursor-pointer"
                      checked={isAllSelected} // Bind header checkbox to isAllSelected state
                      onChange={handleSelectAllCheckboxChange}
                    />
                  </th>
                )}
                
                {headers.map((header) => (
                  headerMap && headerMap[header] && visibleColumns.includes(header) && (
                    <th
                      key={header}
                      className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 freeze-header
        ${sortConfig && sortConfig.key === header ? "text-blue-600 active-table-header" : ""
                        } ${freezeColumn(header) ? 'freeze-header' : ''}`}
                      // className="px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0"
                      onClick={() => { headerMap && headerMap[header][0] !== 'Total' && handleSort(header) }}
                      style={{
                        cursor: "pointer",
                        ...(freezeColumn(header)
                          ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : (popupHeading === "Customer Profiles" || popupHeading === "Payments") ? 0: 61, zIndex: 11, cursor: "pointer" }
                          : {})
                      }}
                    > 
                      {headerMap && headerMap[header]
                        ? headerMap[header][0]
                        : formatColumnName(header)}
                      {headerMap && headerMap[header][0] !== 'Total' ?
                        (sortConfig && sortConfig.key === header ? (
                          sortConfig.direction === "ascending" ? (
                            <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                          ) : (
                            <ArrowDownOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                          )
                        ) : (
                          <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }} />
                        )
                        ) : null}
                    </th>
                  )
                ))}
                {/* { visibleColumns.length > 0 && popupHeading === "Services" &&(
                  <th className="px-6 border-b border-gray-300 text-left font-semibold table-header">
                    { "Customize"}
                  </th>)} */}
                {popupHeading === "Collections Steps" && showStepsHeader &&  (
                  <th className="px-6 border-b border-gray-300 text-left font-semibold table-header">
                  </th>
                )}
                {(allowedActions && allowedActions.length > 0) && visibleColumns.length > 0 && (
                  <th className="px-6 border-b border-gray-300 text-left font-semibold table-header">
                    {"Actions"}
                  </th>)}
              </tr>
            </thead>
            <tbody>

              {visibleColumns.length > 0 ? (
              rowData.length > 0 ? (
                (rowData)
                .map((row, index) => (                 
                  <tr
                    key={index}
                    className={index % 2 === 0 ? "bg-gray-50 even-table-row" : ""}
                  >
                    {(typeof window !== "undefined" && window.innerWidth < 700) && (
                      <td
                        className={`border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                        style={
                          { position: "sticky", left: 0, backgroundColor: "white", zIndex: 5 }
                        }>
                        <Radio
                          checked={true}
                          onClick={() => {
                            setShowRowModal(true);
                            setShowRowModalData(row);
                          }}
                          className="custom-gray-radio"
                        />
                      </td>
                    )}
                    {popupHeading === "Unposted" && (
                           <td className={`px-4 py-2 border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                      style={{ position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : 0, zIndex: 5 }}>
                        <input
                          type="checkbox"
                          className="cursor-pointer"
                          checked={selectedRows.includes(row.id)} // Check if row.id is in selectedRows
                          onChange={(e) => handleCheckboxChange(e, row)}
                          disabled={popupHeading === "Unposted" && (row.from_customer_service === true || row.from_customer_service === "true")}
                        />
                      </td>
                    )}
                    {(popupHeading === "Transfer Service" || popupHeading === "Reversals" || popupHeading === "Reversals Unposted" || popupHeading === "RepostMRCs" || popupHeading === "Billing")&& rowData.length > 0 && (
                      <td className={`px-4 py-2 border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                      style={{ position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : 0, zIndex: 5 }}>
                        <input
                          type="checkbox"
                          className="cursor-pointer"
                          checked={selectedRows.includes(Number(row.id))} // Check if row.id is in selectedRows
                          onChange={(e) => handleCheckboxChange(e, row)}
                          disabled={popupHeading === "Billing" && !eligibleAccounts.includes(row.account_number)}
                          title={
                            popupHeading === "Billing" && !eligibleAccounts.includes(row.account_number)
                              ? "Default payment method not selected"
                              : ""
                          }
                        />
                      </td>
                    )}
                    {popupHeading === "Bills" && allowedActions && allowedActions.length > 0 &&(
                      //  <td className="px-4 py-2 border-b border-gray-300 table-cell">
                          <td className={`px-4 py-2 border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                      style={{ position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : 0, zIndex: 5 }}>
                        <input
                          type="checkbox"
                          className="cursor-pointer"
                          checked={selectedRows.includes(row.id)} // Check if the row is selected
                          onChange={(e) => handleSelectCheckboxChange(e, row)}
                          disabled={popupHeading === "Bills" && (!row.payment_mode || row.payment_mode === "Money Order" || row.payment_mode === "Paper Check" || parseAmount(row.remaining) <= 0)}

                        />
                      </td>
                    )}
                    {popupHeading === "Service Product" && (
                      <td className="px-4 py-2 border-b border-gray-300 table-cell">
                        <input
                          type="checkbox"
                          className="cursor-pointer"
                          checked={selectedRows.includes(row.id)} // Check if the row is selected
                          onChange={(e) => handleSelectCheckboxChange(e, row)}
                        />
                      </td>
                    )}
                    {headers.map(
                      (header, columnIndex) =>
                        visibleColumns.includes(header) &&
                        headerMap[header] && (
                          <td
                            key={columnIndex}
                            className={` px-6 py-3 border-b border-gray-300 table-cell 
                              ${headerMap?.[header]?.[0] === "Payment Mode"
                                ? "table-cell !px-[24px] !py-[3px]"
                                : "table-cell"}
                              ${freezeColumn(header) ?index % 2 === 0 ? "even-freeze-cell" :"freeze-cell" : ""}`}
                            // onClick={() => {
                            //   if (headerMap[header][0] !== "Bills") {
                            //     onRowClick && onRowClick(row);
                            //   }
                            // }}
                             style={{
                            ...(freezeColumn(header)
                              ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : (popupHeading === "Customer Profiles" || popupHeading === "Payments") ? 0 : 61, zIndex: 5, cursor: "pointer" }
                              : {})
                          }}
                          >
                            
                            {popupHeading === "A/R Aging" && headerMap[header][0] === "Collection Step" ? (
                            <>
                              <a
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent row click from triggering
                                  handleRowClick(row, header);
                                }}
                                className="text-blue-500 cursor-pointer underline"
                              >
                                <Tooltip title={row[header]}>
                                  <span>{row[header]}</span>
                                </Tooltip>
                              </a>
                            </>
                            ):((headerMap[header][0] === "Account ID" && popupHeading === "Customer Profiles") || (headerMap[header][0] === "Customer ID" && popupHeading === "Chargebacks & Returns")) ||
                            (customerLinkReports.includes(popupHeading) &&
                              (
                                headerMap[header][0] === "Customer ID" ||
                                headerMap[header][0] === "Account Number" || 
                                headerMap[header][0] === "Account ID"
                              )
                            )                          
                            ? (
                              <>
                                <a
                                  onClick={() => handleRowClick(row, header)} // Attach click only to the "Account ID" value
                                  className="text-blue-500 cursor-pointer underline"

                                >
                                  <Tooltip title={row[header]}>
                                    <span>{row[header]}</span>
                                  </Tooltip>
                                </a>

                              </>
                            ) : header === "bill_id" && ( popupHeading === "Billing" || popupHeading === "Bills")? (
                              <>
                                <a
                                  onClick={(e) => {
                                    e.stopPropagation(); // Prevent row click from triggering
                                    handleRowClick(row, header);
                                  }}
                                  className="text-blue-500  cursor-pointer underline"

                                >
                                  <Tooltip title={row[header]}>
                                    <span>{row[header]}</span>
                                  </Tooltip>
                                </a>

                                {showChargesPage && selectedRow === row.id && (
                                  <ChargesPopup row={row}
                                    isOpen={showChargesPage}
                                    onClose={handleChargesModalClose}
                                    popupheading={popupHeading} />
                                )}
                              </>
                            ) : popupHeading === "Services" && headerMap[header][0] === "Products / Packages" ? (
                              <a
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent event propagation
                                  handleRowClick(row, header);
                                }}
                                className="text-blue-500 cursor-pointer underline"
                              >
                                {row[header]}
                              </a>
                                ) : popupHeading === "Ledger" && headerMap[header][0] === "Description" ? (
                                  <Tooltip title={row[header]} placement="top">
                                    <span
                                      className="inline-block w-full"
                                      style={{
                                        display: "-webkit-box",
                                        WebkitBoxOrient: "vertical",
                                        overflow: "hidden",
                                        WebkitLineClamp: 5,
                                        maxWidth: "100%",
                                        whiteSpace: "normal",
                                      }}
                                    >
                                      {typeof row[header] === "string"
                                        ? (() => {
                                          const lines = row[header]
                                            .replace(/\\n/g, "\n") // if coming with literal \n
                                            .split(/\n/g)
                                            .map(line => line.trim())
                                            .filter(Boolean);

                                          const firstLine = lines[0];
                                          const lastLine = lines[lines.length - 1];
                                              const middleLines = lines.slice(1, lines.length - 1);
                                              const billIdMatch = row.description?.match(/Bill ID:\s*(INV\d+)/);
                                              const billId = billIdMatch?.[1];
                                          return (
                                            <>
                                              <div className="flex flex-col">
                                              <div className="block font-medium">{firstLine!== lastLine ? firstLine : undefined}</div>
                                              <div>
                                                {middleLines.length > 0 && (
                                                <span className="whitespace-normal">
                                                  {middleLines.join(" ")}
                                                </span>
                                              )}
                                              </div>
                                              <div>
                                                {lines.length > 1 &&
                                                  lastLine.includes("Tax") &&
                                                  row.type !== "Reverse Bill" &&
                                                  !reversedBillIds.has(billId) ? (
                                                  <a
                                                    className="block text-blue-500 cursor-pointer underline"
                                                    onClick={() => handleTaxClick(row)}
                                                  >
                                                    {lastLine}
                                                  </a>
                                                ) : (
                                                  <div className="block">{lastLine}</div>
                                                )}
                                              </div>
                                              </div>

                                              
                                            </>
                                          );
                                        })()
                                        : null}
                                    </span>
                                  </Tooltip>
                                ) : popupHeading === "Services" && headerMap[header][0] === "Package" ? (
                              <a
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent event propagation
                                  handleRowClick(row, header);
                                }}
                                className="text-blue-500 cursor-pointer underline"
                              >
                                view list
                              </a>
                            ) : headerMap[header][0] === "Payment Mode" && ((popupHeading === "Bills" && allowedActions && allowedActions.length > 0) || popupHeading === "Billing") ? (
                              <Select
                                className="w-full min-w-[200px]"
                                value={paymentModeOptions.find((opt) => opt.value.toLowerCase() === row[header].toLowerCase()) || null}
                                      onChange={(selectedOption) =>
                                      handlePaymentModeChange(row, selectedOption?.value ?? "", index)}
                                     options={paymentModeOptions}
                                    // isClearable
                                     styles={{
                                          ...DropdownStyles,
                                            menuPortal: (base) => ({
                                              ...base,
                                              zIndex: 9999,
                                            }),
                                          }}
                                           menuPlacement="top"
                                menuPosition="fixed"
                              />
                            ) : headerMap[header][0] === "Tax" && (popupHeading === "Unposted") ? (
                               <a
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent event propagation
                                  handleRowClick(row, header);
                                }}
                                className="text-blue-500 cursor-pointer underline"
                              >
                               {row[header]}
                              </a>
                            ) :
                              headerMap && headerMap?.[header]?.[0] === "Progress" ? (
                                <ProgressBar value={row[header]} />
                              ) :
                                header === "Status" ||
                                  (headerMap && headerMap?.[header]?.[0] === "Status" && popupHeading === "Upload Tracking") ? (
                                  <StatusIndicator
                                    row={row}
                                    status={row[header]}
                                    heading={popupHeading}
                                  />
                                ) :
                                  headerMap &&
                                    headerMap?.[header]?.[0] === "Uploaded" ? (
                                    <QuantityCell
                                      value={row[header]}
                                      type={STATUS_TYPE.UPLOAD}
                                    />
                                  ) : headerMap &&
                                    headerMap?.[header]?.[0] === "Successful" ? (
                                    <QuantityCell
                                      value={row[header]}
                                      type={STATUS_TYPE.SUCCESSFUL}
                                    />
                                  ) : headerMap && headerMap?.[header]?.[0] === "Errors" ? (
                                    <QuantityCell
                                      value={row[header]}
                                      type={STATUS_TYPE.ERRORS}
                                    />
                                  ) : ((moduleFeatures.includes("Info-Unposted Upload Status") && popupHeading==="Upload Tracking")) && (headerMap &&
                                    headerMap?.[header]?.[0] === "Info") ? (
                                    <BillingInfoDetailCellRenderer row={row} popupHeading= {popupHeading}/>
                                  ) : (
                              renderCell(
                                  (currencyHeaders.includes(headerMap[header][0]) && row[header]
                                    ? `$${row[header]}`
                                    : row[header]),
                                header,
                                index
                              ) || ""


                            )}
                          </td>
                        )
                    )}


                    {Array.isArray(allowedActions) && allowedActions.length > 0 && visibleColumns.length > 0 && !["Services", "Collections Steps","Bills","Billing"].includes(popupHeading) ? (
                      <td className="px-6 border-b border-gray-300 table-cell relative" style={{ overflow: "visible" }}>
                        <div className="flex items-center space-x-2">
                          {allowedActions.includes("preview") && (
                            <Tooltip title="Preview">
                              <EyeOutlined
                                className="h-6 w-6 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("preview", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("edit") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("edit", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editCollection") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("editCollection", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editStep") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("editStep", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editPackage") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("editPackage", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("deactivate") && (
                            <Tooltip
                              title={
                                row.is_active === true || row.status === "Active"
                                  ? "Deactivate"
                                  : row.is_active === false || row.status === "Inactive"
                                    ? "Activate"
                                    : "Unknown Status"
                              }
                            >
                              {row.is_active === true || row.status === "Active" ? (
                                <NoSymbolIcon
                                  className="h-5 w-5 text-red-500 cursor-pointer"
                                  onClick={() => handleActionClick("deactivate", index, row.status, row.is_active)}
                                />
                              ) : row.is_active === false || row.status === "Inactive" ? (
                                <CheckIcon
                                  className="h-5 w-5 text-green-500 cursor-pointer"
                                  onClick={() => handleActionClick("deactivate", index, row.status, row.is_active)}
                                />
                              ) : (
                                <NoSymbolIcon
                                  className="h-5 w-5 text-gray-400 cursor-pointer"
                                  onClick={() => handleActionClick("unknown", index, row.status, row.is_active)}
                                />
                              )}
                            </Tooltip>
                          )}

                          
                          {allowedActions.includes("adjust") && (
                            <Tooltip title="Adjust">
                              <TagOutlined
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("adjust", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("paynow") && (
                            <Tooltip title={row.payment_mode === "Money Order" || row.payment_mode === "Paper Check" || parseAmount(row.remaining) === 0 ? "Payment not allowed" : "Paynow"}>
                              <CreditCardOutlined
                                className={`h-5 w-5  ${row.payment_mode === "Money Order" || row.payment_mode === "Paper Check" || parseAmount(row.remaining) === 0 ? "text-gray-400 cursor-not-allowed" : "text-blue-500 cursor-pointer"
                                  }`}
                                onClick={() => {
                                  if (row.payment_mode !== "Money Order" && row.payment_mode !== "Paper Check" && parseAmount(row.remaining) !== 0) {
                                    handleActionClick("paynow", index);
                                  }
                                }}
                              />
                            </Tooltip>
                          )}
                          {(allowedActions.includes("cancel-payment") ||
                            allowedActions.includes("chargeback") ||
                            allowedActions.includes("downloadreceipt")) && row.status !== "Successful" && row.status !== "Voided" && row.status !== "Returned" && (
                            <span className="flex justify-center w-full text-gray-400">—</span>
                          )}
                          {allowedActions.includes("cancel-payment") && (row.status === "Successful" || row.status === "Voided" || row.status === "Returned") &&(
                            <Tooltip
                              title={
                                row.cancel_payment_flag
                                  ? "Already Returned"
                                  : row.status !== "Successful" || (row.category ==="Money Order" || row.category === "Paper Check")
                                  ? ""
                                  : "Cancel Payment"
                              }
                            >
                              <span
                                className="flex justify-center w-full"
                                onClick={() => {
                                  if (!row.cancel_payment_flag && row.status === "Successful" && AccountStatus) {
                                    handleActionClick("cancel-payment", index);
                                  }
                                }}
                              >
                                <div className="relative">
                                <CreditCardIcon
                                  className={`h-5 w-5 ${
                                    row.cancel_payment_flag || row.status !== "Successful" || !AccountStatus || (row.category ==="Money Order" || row.category === "Paper Check")
                                      ? "text-gray-400 cursor-not-allowed"
                                      : "text-blue-500 cursor-pointer hover:text-blue-600"
                                  }`}
                                />
                                
                                <div
                                  className={`absolute top-0 -right-1 rounded-full ${
                                    row.cancel_payment_flag || row.status !== "Successful" || !AccountStatus || (row.category ==="Money Order" || row.category === "Paper Check")
                                      ? "bg-gray-200"
                                      : "bg-white"
                                  }`}
                                >
                                  <XCircleIcon
                                    className={`h-3 w-3 ${
                                      row.cancel_payment_flag || row.status !== "Successful" || !AccountStatus || (row.category ==="Money Order" || row.category === "Paper Check")
                                        ? "text-gray-400"
                                        : "text-blue-500 pointer-events-none"
                                    }`}
                                  />
                                </div>
                              </div>
                              </span>
                            </Tooltip>
                          )}
                          {allowedActions.includes("chargeback") && (row.status === "Successful" || row.status === "Voided" || row.status === "Returned") &&(
                            <Tooltip
                              title={
                                row.cancel_payment_flag
                                  ? "Already Returned"
                                  : row.status !== "Successful" || !AccountStatus || (row.category ==="Money Order" || row.category === "Paper Check")
                                  ? ""
                                  : "ChargeBack"
                              }
                            >
                              <span
                                className="flex justify-center w-full"
                                onClick={() => {
                                  if (!row.cancel_payment_flag && row.status === "Successful" && AccountStatus) {
                                    handleActionClick("chargeback", index);
                                  }
                                }}
                              >
                                <ArrowPathIcon
                                  className={
                                    row.cancel_payment_flag
                                      ? "h-5 w-5 text-gray-400 cursor-not-allowed" // Returned → greyed out, disabled
                                      : row.status !== "Successful" || !AccountStatus || (row.category ==="Money Order" || row.category === "Paper Check")
                                      ? "h-5 w-5 text-gray-400 cursor-not-allowed" // "-" or Payment Failed → greyed out
                                      : "h-5 w-5 text-blue-500 cursor-pointer hover:text-blue-600" // Active Cancel → blue, clickable
                                  }
                                />
                              </span>
                            </Tooltip>
                          )}
                          {allowedActions.includes("downloadreceipt") && (row.status === "Successful" || row.status === "Voided" || row.status === "Returned") && (
                            <>
                              <Tooltip title="Download Receipt" placement="left">
                                <DownloadOutlined
                                  className="text-blue-500 underline cursor-pointer h-5 w-5"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    handleActionClick("downloadreceipt", index);
                                  }}
                                />
                              </Tooltip>

                            </>
                          )}
                          {allowedActions.includes("downloadbill") && (
                            <>
                              <Tooltip title="Download bill">
                                <DownloadOutlined
                                  className="text-blue-500 underline cursor-pointer h-5 w-5"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    handleActionClick("downloadbill", index);
                                  }}
                                />
                              </Tooltip>

                            </>
                          )}
                          {allowedActions.includes("delete") && (
                            <Tooltip title="Delete">
                              <TrashIcon
                                className="h-5 w-5 text-red-500 cursor-pointer"
                                onClick={() => handleActionClick("delete", index)}
                              />
                            </Tooltip>
                          )}

                          {allowedActions.includes("info") && (
                            <Tooltip title="Info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() => handleActionClick("info", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("copy") && (
                            <Tooltip title="Copy">
                              <CopyOutlined
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("copy", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("copyPackage") && (
                            <Tooltip title="Copy Package">
                              <CopyOutlined
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("copyPackage", index)}
                              />
                            </Tooltip>
                          )}

                          
                        </div>
                        {openIndex === index && (popupHeading === "Bills" || popupHeading === "Billing") && (
                          <div ref={popupRef}
                            className="absolute right-0 ant-dropdown z-50"
                            style={{ minWidth: "110px" }}
                          >
                            <ul className="space-y-1 ant-dropdown-menu rounded-lg shadow-lg">
                              <li
                                className="cursor-pointer px-2 py-1 rounded hover:bg-gray-100"
                                onClick={() => handleOptionClick("downloadbill", index)}
                              >
                                Download PDF
                              </li>
                              <li
                                className="cursor-pointer px-2 py-1 rounded hover:bg-gray-100"
                                onClick={() => handleOptionClick("downloadExcel", index)}
                              >
                                Download Excel
                              </li>
                              {/* <li
                                  className="cursor-pointer text-gray-700 hover:text-blue-500"
                                  onClick={() => handleOptionClick("emailBill", index)}
                                >
                                  Email Bill
                                </li> */}
                            </ul>
                          </div>
                        )}
                      </td>
                    ) : (
                      null
                    )}
                    {(popupHeading === "Bills" || popupHeading === "Billing") && allowedActions && allowedActions.length > 0 && (
                      <td className="px-6 border-b border-gray-300 table-cell relative" style={{ overflow: "visible" }}>
                        <div className="flex items-center space-x-2">
                          <Tooltip title="Options">
                            <a
                              href="#"
                              className="text-blue-500 hover:underline cursor-pointer"
                              onClick={(e) => {
                                e.preventDefault();
                                handleToggleDropdown(index);
                              }}
                            >
                              Options
                            </a>
                          </Tooltip>
                        </div>
                        {openIndex === index && (popupHeading === "Bills" || popupHeading === "Billing") &&  allowedActions && allowedActions.length > 0 && (
                          <div
                            ref={popupRef}
                            className="absolute right-0 ant-dropdown z-50"
                            style={{ minWidth: "110px" }}
                          >
                            <ul className={`absolute right-0 ant-dropdown-menu z-50 ${
                              rowData.length > 2 && index > rowData.length - 3
                              ? "bottom-full mb-2"
                              : "top-full mt-2"}`}
 

                            style={{ minWidth: "110px" }}>
                              {[
                                { label: "Adjust", action: "adjust" },
                                { label: "Pay Now", action: "paynow" },
                                { label: "Download PDF", action: "downloadbill", isOption: true },
                                { label: "Download Excel", action: "downloadExcel", isOption: true },
                                { label: "Repost MRC", action: "repostMRC" },
                              ].filter((item: any) => allowedActions.includes(item.action))
                              .filter(item => !(item.action === "paynow" && (parseAmount(row.remaining) === 0 || row.payment_mode === "Money Order" || row.payment_mode === "Paper Check")))
                              .map((item, idx) => (
                                <li
                                  key={item.label}
                                  className="cursor-pointer px-2 py-1 rounded ant-dropdown-menu-item"
                                  onClick={() =>
                                    item.isOption
                                      ? handleOptionClick(item.action, index)
                                      : handleActionClick(item.action, index)
                                  }
                                >
                                  {item.label}
                                </li>
                              ))}
                            </ul>
                          </div>

                        )}
                      </td>
                    )}
                    {popupHeading === "Services" && allowedActions && allowedActions.length> 0 && (
                      <td className="px-6 border-b border-gray-300 table-cell relative" style={{ overflow: "visible" }}>
                        <div className="flex items-center space-x-2">
                          <Tooltip title="Options">
                            <a
                              href="#"
                              className="text-blue-500 hover:underline cursor-pointer"
                              onClick={(e) => {
                                e.preventDefault();
                                handleToggleDropdown(index);
                              }}
                            >
                              Options
                            </a>
                          </Tooltip>
                        </div>
                        {openIndex === index && popupHeading === "Services" && (
                          <div
                            ref={popupRef}
                            className="absolute right-0 ant-dropdown rounded  z-50"
                            style={{ minWidth: "110px" }}
                          >
                            <ul className="space-y-1 ant-dropdown-menu rounded-lg shadow-lg p-2">
                              {allowedActions.includes("editServiceLocation") && (<li
                                className="cursor-pointer px-2 py-1 rounded ant-dropdown-menu-item"
                                onClick={() => handleOptionClick("editServiceLocation", index)}
                              >
                                Edit Service Location
                              </li>)}
                              {allowedActions.includes("editNewService") && (<li
                                className="cursor-pointer px-2 py-1 rounded ant-dropdown-menu-item"
                                onClick={() => handleOptionClick("editNewService", index)}
                              >
                                Edit Service
                              </li>)}
                              {/* ADD THIS NEW SECTION */}
                              {allowedActions.includes("disconnectService") && row.bp_service && row.status.toLowerCase() === "active" && (
                                <li
                                  className="cursor-pointer px-2 py-1 rounded ant-dropdown-menu-item"
                                  onClick={() => handleOptionClick("disconnectService", index)}
                                >
                                  Disconnect Service
                                </li>
                              )}
                            </ul>
                          </div>
                        )}
                      </td>
                    )}
                    {popupHeading === "Collections Steps" &&
                      (Boolean(row.closure_step) ||
                        Boolean(row.promise_step) ||
                        rowData.some((r) => Boolean(r.closure_step) || Boolean(r.promise_step))) && (
                        <td className="px-6 border-b border-gray-300 table-cell relative" style={{ overflow: "visible" }}>
                          <div className="flex flex-col gap-1 p-2">
                            {Boolean(row.closure_step) && (
                              <div className="text-gray-700 px-2 py-1 rounded bg-gray-100">
                                Closure Step
                              </div>
                            )}
                            {Boolean(row.promise_step) && (
                              <div className="text-gray-700 px-2 py-1 rounded bg-gray-100">
                                Payment Promise Failure Step
                              </div>
                            )}
                            {rowData.some((r) => Boolean(r.closure_step) || Boolean(r.promise_step)) &&
                              !Boolean(row.closure_step) &&
                              !Boolean(row.promise_step) && (
                                <div className="text-gray-700 px-2 py-1 rounded invisible">
                                  Placeholder
                                </div>
                              )}
                          </div>
                        </td>
                      )}

                    {popupHeading === "Collections Steps" && (
                      <td className="px-6 border-b border-gray-300 table-cell relative" style={{ overflow: "visible" }}>
                        <div className="flex items-center space-x-2">
                          <Tooltip title="Options">
                            <a
                              href="#"
                              className="text-blue-500 hover:underline cursor-pointer"
                              onClick={(e) => {
                                e.preventDefault();
                                handleToggleDropdown(index);
                              }}
                            >
                              Options
                            </a>
                          </Tooltip>
                        </div>
                        {openIndex === index && popupHeading === "Collections Steps" && (
                          <div
                            ref={popupRef}
                            className="absolute right-0 bg-white border border-gray-300 rounded shadow-lg p-2 z-50 user-info-div"
                            style={{ minWidth: "110px", overflow: "visible" }}
                          >
                            <ul className="space-y-1 collection-steps-div">
                              {index > 0 && (
                                <li
                                  className="cursor-pointer text-gray-700  px-2 py-1 rounded hover:bg-gray-100"
                                  onClick={() => handleOptionClick("moveup", index)}
                                >
                                  Move Up
                                </li>
                              )}
                              {index < rowData.length - 1 && (
                                <li
                                  className="cursor-pointer text-gray-700 px-2 py-1 rounded hover:bg-gray-100"
                                  onClick={() => handleOptionClick("movedown", index)}
                                >
                                  Move Down
                                </li>
                              )}
                              <li
                                className="cursor-pointer text-gray-700 px-2 py-1 rounded hover:bg-gray-100"
                                onClick={() => handleOptionClick("editStep", index)}
                              >
                                Edit
                              </li>
                              <li
                                className="cursor-pointer text-gray-700 px-2 py-1 rounded hover:bg-gray-100"
                                onClick={() =>
                                  handleOptionClick(
                                    row.closure_step ? "removeClosureStep" : "closureStep",
                                    index
                                  )
                                }
                              >
                                {row.closure_step ? "Remove as Closure Step" : "Set as Closure Step"}
                              </li>
                              <li
                                className="cursor-pointer text-gray-700 px-2 py-1 rounded hover:bg-gray-100"
                                onClick={() =>
                                  handleOptionClick(
                                    row.promise_step ? "removePromiseStep" : "promiseFailureStep",
                                    index
                                  )
                                }
                              >
                                {row.promise_step
                                  ? "Remove as Payment Promise Step"
                                  : "Set as Payment Promise Failure Step"}
                              </li>
                              <li
                                className="cursor-pointer text-gray-700 px-2 py-1 rounded hover:bg-gray-100"
                                onClick={() => handleActionClick("delete", index)}
                              >
                                Delete
                              </li>
                            </ul>
                          </div>
                        )}
                      </td>
                    )}


                  </tr>
                ))
              ):(
              <tr>
                  <td
                    colSpan={
                      headers.filter((header) =>
                        visibleColumns.includes(header)
                      ).length + 1
                    }
                    className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                  >
                    No Records Found
                  </td>
                </tr>
                )
               ) : null}
            </tbody>
          </table>
        </div>
      </div>
      {/* {visibleColumns.length > 0 &&
        <div className="flex justify-center mt-5">
          <BillingPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading} />
        </div>
      } */}
       {(!isSmallScreen && visibleColumns.length > 0) && (
                <div className="flex justify-center mt-5">
                    {paginationComponent}
                </div>
            )}

      {/* {showNewPage && (
        <AdvancedTab row={selectedRow} onClose={closeAdvancedTabs} />
      )} */}
      {editModalOpen &&
        (<EditPopup
          createModalData={createModalData || []}
          isOpen={editModalOpen}
          isEditable={isEditable}
          rowData={editRowIndex !== null ? rowData[editRowIndex] : null}
          onSave={handleSaveModal}
          onClose={handleCloseModal}
          heading={popupHeading}
          generalFields={generalFields}
          tableData={rowData}
          action="edit"
          selectedSubPartner = {selectedSubPartner}
          selectedPartner={selectedPartner}
        />)

      }
      {repostModalOpen && (
         <RepostMRC
                    isOpen={repostModalOpen}
                    onClose={handleCloseModal }
                    rowData={generalFields}
                    reversalsReverseData = {repostModalIndex !== null ? rowData[repostModalIndex] : null}
                    onSave={handleSaveModal}
                  />
      )}
      {PreviewModal && (
        loading ? (
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        ) : (
          <MultiDownloadPDFBill
            rowData={
              rowData !== null && PreviewModalRowIndex !== null
                ? rowData[PreviewModalRowIndex]
                : null
            }
            isOpen={PreviewModal}
            onClose={handleCloseModal}
          />
        )
      )}

      {isCollectionModal &&
        <div className="absolute inset-0 flex justify-center items-center z-50 ">
          <div className="bg-white p-2  w-full h-full">
            <EditCollectionModal
              modalData={createModalData || []}
              isOpen={isCollectionModal}
              rowData={isCollectionModalRowIndex !== null ? rowData[isCollectionModalRowIndex] : null}
              onSave={handleSaveModal}
              onClose={handleCloseModal}
              title={popupHeading}
              generalFields={generalFields}
              action="editCollection"
            />
          </div>
        </div>

      }
      {isStepModal &&
        (<StepModal
          isModalOpen={isStepModal}
          rowData={isStepModalRowIndex !== null ? rowData[isStepModalRowIndex] : null}
          quillValue={quillValue}
          setQuillValue={setQuillValue}
          onClose={handleCloseModal}
          setHeaders={setHeaders}
          setHeaderMap={setHeaderMap}
          setTableData={setTableData}
          tableData={initialData}
        />)
      }
      {isCopyModal &&
        (<EditPopup
          createModalData={createModalData || []}
          isOpen={isCopyModal}
          isEditable={isEditable}
          rowData={isCopyRowIndex !== null ? rowData[isCopyRowIndex] : null}
          onSave={handleSaveModal}
          onClose={handleCloseModal}
          heading={popupHeading}
          generalFields={generalFields}
          tableData={rowData}
          action="copy"
        />)


      }
      {isCopyPackageModal &&
        (<CopyPackageModal
          isOpen={isCopyPackageModal}
          rowData={isCopyPackageRowIndex !== null ? rowData[isCopyPackageRowIndex] : null}
          isEditable={isEditable}
          onSave={rowData}
          onClose={handleCloseModal}
          title={popupHeading}
          generalFields={generalFields}
          modalData={createModalData || []}
          action="copy" />)


      }
      {isEditPackageModal &&
        (<CopyPackageModal
          isOpen={isEditPackageModal}
          rowData={isEditPackageRowIndex !== null ? rowData[isEditPackageRowIndex] : null}
          isEditable={isEditable}
          onSave={rowData}
          onClose={handleCloseModal}
          title={popupHeading}
          generalFields={generalFields}
          modalData={createModalData || []}
          action="edit" />)


      }
      {editServiceModalOpen && (
        <EditServiceLocationModal
          isOpen={editServiceModalOpen}
          onClose={() => setEditServiceModalOpen(false)}
          rowData={serviceSelectedRow}
        />
      )}
      {downloadPDFBill && (
        <DownloadPDFBill
          isOpen={downloadPDFBill}
          onClose={() => setDownloadPDFBill(false)}
          rowData={serviceSelectedRow}
        />
      )}
      {editServiceProductModalOpen && (

        <CustomerProfilesEditModal
          isOpen={editServiceProductModalOpen}
          onSave={rowData}
          onClose={() => setEditServiceProductModalOpen(false)}
          generalFields={generalFields}
          modalData={createModalData || []}
          action="edit"
          title={popupHeading}
          dropdownValues={serviceDropdownValues}
          accountNumber={accountNumber}
          rowData={isEditServiceProductRowIndex !== null ? rowData[isEditServiceProductRowIndex] : null}
        />
      )}
      {editNewServiceModalOpen && (
        <CustomerProfilesEditNewServiceModal
          isOpen={editNewServiceModalOpen}
          onSave={rowData}
          onClose={() => setEditNewServiceModalOpen(false)}
          generalFields={generalFields}
          modalData={createModalData || []}
          action="edit"
          title={popupHeading}
          dropdownValues={serviceDropdownValues}
          accountNumber={accountNumber}
          rowData={isEditNewServiceRowIndex !== null ? rowData[isEditNewServiceRowIndex] : null}
        />
      )}
    {serviceProductModal&&(
        <PackageListModal
          isOpen={serviceProductModal}
          onClose={() => setServiceProductModal(false)}
          rowData={showServicePackageDetails}
        />
      )}
      {showPackageModal && (
        <PackageModal
          row={productDetails}
          rowId={selctedProductServiceRow}
          rowData={selectedProductsServiceRowData}
          rowflag={ProductOrPackage}
          isOpen={showPackageModal}
          onClose={() => {
            afterFetchData();
          }}
        />
      )}
      {showRowModal &&
        <RowDetailsModal
          row={showRowModalData}
          headerMap={headerMap}
          onClose={() => {
            setShowRowModal(false)
            setShowRowModalData(null)
          }}
          isOpen={showRowModal}
        />
      }
      {isTaxesModalOpen && (
        <TaxesModal
          isOpen={isTaxesModalOpen}
          onClose={() => setTaxesModalOpen(false)}
          row={selectedRow || {}}
          // onSave={handleSaveModal}
          />
      )}
    {isCollectionStepsModal && (
      <CollectionsStepModal
        isOpen={isCollectionStepsModal}
        rowData={collectionStepsRowData || null}
        onClose={() => {
          setIsCollectionStepsModal(false);
          setCollectionStepsRowData(null);
        }}
      />
    )}
      <Modal
        open={isSinglePaymentModalOpen}
        onCancel={() => setSinglePaymentModalOpen(false)}
        footer={null}
        width={800}
        destroyOnClose
        centered
        bodyStyle={{ height: "500px", padding: 0, position: "relative" }}
      >
        {iframeUrl && (
          <>
            {paymentFormloading && (
              <div
                className="flex items-center justify-center"
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  height: '100%',
                  backgroundColor: 'rgba(255, 255, 255, 0.8)',
                  zIndex: 1000, // ensure it appears above iframe
                }}
              >
                <Spin size="large" tip="Loading Payment Form..." />
              </div>
            )}
            <iframe
              src={iframeUrl}
              width="100%"
              height="100%"
              frameBorder="0"
              allowFullScreen
              title="Payment"
              onLoad={() => setPaymentFormLoading(false)} // hide loader once iframe is ready
            />
          </>
        )}
      </Modal>
      <Modal
        title={actionType === "delete"
          ? "Confirm Deletion"
          : actionType === "deactivate"
            ? ("Confirm Deactivation")
            : "Confirm Activation"}
        open={deleteModalOpen}
        onOk={() => confirmDelete(actionType, statusType)}
        onCancel={() => setDeleteModalOpen(false)}
        centered
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={() => setDeleteModalOpen(false)}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={() => confirmDelete(actionType, statusType)}
            >
              OK
            </button>
          </div>
        }
      >
        {actionType === "delete" ? (
          <p>Do you want to delete this row?</p>
        ) : (
          <p>Do you want to {statusType} this row?</p>
        )}
      </Modal>
      <Modal
        title={"Adjust Invoice Item"}
        open={adjustInvoiceOpen}
        onOk={() => handleAdjustClick()}
        onCancel={() => setAdjustInvoiceOpen(false)}
        centered
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={() => setAdjustInvoiceOpen(false)}
            >
              Cancel
            </button>
            <button className="save-btn" onClick={handleAdjustClick}>
                OK
              </button>
          </div>
        }
      >
        <div className="flex gap-4">
          <div className="flex flex-col">
            <label className="field-label">Item Amount</label>
            <Input
              type="text"
              className="input"
              value={formData.item_amount}
              onChange={handleInputChange('item_amount')}
              placeholder="Enter Amount"
              prefix="$"
            />
          </div>
          {/* <div className="flex flex-col">
            <label className="field-label">Reason</label>
            <Input
              type="text"
              className="input"
              value={formData.reason}
              onChange={handleInputChange('buy_rate')}
              placeholder="Enter Buy Rate"
            />
          </div> */}

        </div>
        <div className="flex flex-col mt-4">
          <label className="field-label">Comment</label>
          <textarea
            className="textarea"
            value={formData.comment ?? ""}
            onChange={handleInputChange('comment')}
            placeholder="Enter your comment"
            rows={4} // Adjust the height
          />
        </div>
      </Modal>

      <Modal
        title={"Process Payment"}
        open={ProcessPaymentOpen}
        onCancel={handleClosePaynowModal}
        centered
        footer={
          <div style={{ display: "flex", justifyContent: "center", width: "100%", gap: "6px" }}>
            <button className="cancel-btn" onClick={handleClosePaynowModal} disabled={isProcessing}>
              Cancel
            </button>
           
              <button
                className={isPayNowDisabled || isProcessing ? "cancel-btn cursor-not-allowed" : "save-btn"}
                onClick={handlePayNowClick}
                disabled={isPayNowDisabled || isProcessing}
              >
                {isProcessing ? "Redirecting..." : "Pay Now"}
              </button>
          </div>
        }
        width={450}
      >
        {/* Show Loader When Processing */}
        {isProcessing ? (
          <div className="flex justify-center items-center flex-col h-[200px]">
            <Spin size="large" />
            <p className="mt-2 text-gray-600">Processing...</p>
          </div>
        ) : (
          <>
              <div className="flex gap-2 mb-2">
                <label className="field-label" style={{ minWidth: '150px' }}>Payment Method</label>
                <Select
                  options={[
                    { value: "card payment", label: "Card Payment" },
                    { value: "paper check", label: "Paper Check" },
                    { value: "money order", label: "Money Order" },
                    { value: "inbound ach", label: "Inbound ACH" },


                  ]}
                  styles={DropdownStyles}
                  // className="min-w-[220px]"
                  className={`${isSmallScreen?'w-full':'min-w-[220px]'}`}
                  value={
                    formData.payment_method
                      ? { value: formData.payment_method, label: formData.payment_method.charAt(0).toUpperCase() + formData.payment_method.slice(1) }
                      : null
                  }
                  onChange={(selectedOption) =>
                  {setSelectedPaymentMode(selectedOption? selectedOption.label : ""),setFormData((prev) => ({
                    ...prev,
                    payment_method: selectedOption ? selectedOption.label : "",
                  }))}
                  }
                />
              </div>
              <div className="flex gap-2 mb-2">
              <label className="field-label" style={{ minWidth: '150px' }}>Amount</label>
              <div className="flex flex-col gap-2">
                <Input
                  type="text"
                  // className="input !w-[220px]"
                  inputMode="decimal"
                  className={`input ${isSmallScreen?'':'!w-[220px]'}`}
                  value={formData.item_amount}
                  onChange={handleInputChange("item_amount")}
                  placeholder="Enter amount"
                  prefix="$"
                />
                {formErrors.item_amount && <p className="text-red-500 text-sm">{formErrors.item_amount}</p>}
              </div>
              {/* <p className="text-sm text-gray-500">
            Note: After saving, the due amount is updated, and the entered amount is reflected in the payment column.
          </p> */}
            </div>
            {/* <div className="flex gap-2 mb-2 items-center">
              <label className="field-label" style={{ minWidth: '150px' }}>Fee</label>
              <div className="flex items-center gap-1 text-sm text-black-800 ml-2">
              <span>${parseFloat(formData.item_amount || "0").toFixed(2)}</span>
                <span className="text-black-600">
                  (
                  {formData.item_amount && totalAmount
                    ? `${((parseFloat(formData.item_amount) / parseFloat(totalAmount.toString())) * 100).toFixed(2)}%`
                    : '0.00%'}
                  )
                </span>
              </div>
            </div> */}
              {selectedPaymentMode !== "Inbound ACH" && (
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.credit_card_fee === true} // default checked
                    onChange={(e) =>
                      setFormData((prev: any) => ({
                        ...prev,
                        credit_card_fee: e.target.checked, // ✅ fixed key name
                      }))
                    }
                  />
                  <label className="field-label text-sm" style={{ minWidth: "150px" }}>
                    Apply Credit Card Fee ({creditCardFee}%)
                  </label>
                </div>
              )}
            <div className="flex gap-2 mb-2">
              <label className="field-label" style={{ minWidth: '150px' }}>Total</label>
              <span className="text-sm text-gray-800 ml-2">${totalAmount || 0}</span>
            </div>
            <div className="flex gap-2 mb-2">
              <label className="field-label" style={{ minWidth: '150px' }}>Reference</label>
              <Input
                type="text"
                // className="input !w-[220px]"
                  className={`input ${isSmallScreen?'':'!w-[220px]'}`}
                value={formData.reference_no}
                onChange={handleInputChange("reference_no")}
              //  placeholder="Enter Amount"
              //  prefix="$"
              />
            </div>
            <div className="flex gap-2 mb-2">
              <label className="field-label" style={{ minWidth: '150px' }}>Received</label>
              <DatePicker
                value={formData.received_date ? dayjs(formData.received_date) : dayjs()}
                onChange={(date) => {
                  setFormData(prev => ({
                    ...prev,
                    received_date: date ? date.format('MM-DD-YYYY') : '',
                  }));
                }}
                format="MM-DD-YYYY"
                // className="input !w-[220px]"
                disabled
                className={`non-editable-input ${isSmallScreen?'':'!w-[220px]'}`}
                disabledDate={(current) => current && current > dayjs().startOf('day')
                }
              />
            </div>
            <div className="flex gap-2 mb-2">
              <label className="field-label" style={{ minWidth: '150px' }}>Agent</label>
              <Select
                options={agentOptions.map((option) => ({
                  value: option,
                  label: option,
                }))}
                styles={DropdownStyles}
                // className="min-w-[220px]"
                className={`${isSmallScreen?'w-full':'min-w-[220px]'}`}
                value={
                  formData.agent
                    ? { value: formData.agent, label: formData.agent }
                    : null
                }
                onChange={(selectedOption) =>
                  setFormData((prev) => ({
                    ...prev,
                    agent: selectedOption ? selectedOption.value : "",
                  }))
                }
                menuPlacement="top"
                isClearable
              />
            </div>
          </>
        )}
      </Modal>

      <Modal
        open={isConfirmModalOpen}
        onCancel={handleCancelChange}
        title="Confirmation"
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelChange}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={()=>handleConfirmChange('payment_mode')}
            >
              OK
            </button>
          </div>
        } centered
      >
        <div className="flex mb-4">
          <p >
            Are you sure you want to change the payment mode to{" "}
            {selectedPaymentMode}?
          </p>
        </div>
      </Modal>
      <Modal
        open={isMoveDownConfirmModalOpen}
        onCancel={handleCancelChange}
        title="Confirmation"
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelChange}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={handleConfirmMoveDown}
            >
              OK
            </button>
          </div>
        } centered
      >
        <div className="flex mb-4">
          <p >
            Are you sure you want to move this down to the next position?
          </p>
        </div>
      </Modal>
      <Modal
        open={isMoveUpConfirmModalOpen}
        onCancel={handleCancelChange}
        title="Confirmation"
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelChange}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={handleConfirmMoveUp}
            >
              OK
            </button>
          </div>
        } centered
      >
        <div className="flex mb-4">
          <p >
            Are you sure you want to move this previous position?
          </p>
        </div>
      </Modal>

      <Modal
        open={isAmountModalOpen}
        onCancel={handleClosePaynowModal}
        title={selectedPaymentMode}
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button className="cancel-btn" onClick={handleClosePaynowModal}>Cancel</button>
            <button className="save-btn" onClick={()=>handleConfirmChange('payment_mode')}>Save</button>
          </div>
        }
        centered
        width={450}
      >
        <div className="flex gap-2 mb-2">
          <label className="field-label"style={{ minWidth: '150px' }}>Amount</label>
          <div className="flec flex-col gap-2">
          <Input
            // type="number"
            type="text"
            className={`input ${isSmallScreen?'!w-[150px]':'!w-[220px]'}`}
            value={formData.item_amount}
            onChange={handleInputChange("item_amount")}
            placeholder="Enter amount"
            prefix="$"
          />
          {formErrors.item_amount && <p className="text-red-500 text-sm">{formErrors.item_amount}</p>}
          </div>

          {/* <p className="text-sm text-gray-500">
            Note: After saving, the due amount is updated, and the entered amount is reflected in the payment column.
          </p> */}
        </div>
        {/* <div className="flex gap-2 mb-2 items-center">
          <label className="field-label" style={{ minWidth: '150px' }}>Fee</label>

          <div className="flex items-center gap-1 text-sm text-black-800 ml-2">
            <span>${formData.item_amount || 0}</span>
            <span className="text-black-600">
              (
              {formData.item_amount && totalAmount
                ? `${((parseFloat(formData.item_amount) / parseFloat(totalAmount.toString())) * 100).toFixed(2)}%`
                : '0.00%'}
              )
            </span>
          </div>
        </div> */}
        {/* <div className="flex gap-2 mb-2">
          <label className="field-label" style={{ minWidth: '150px' }}>Total</label>
          <span className="text-sm text-gray-800 ml-2">${totalAmount || 0}</span>
          <span className="text-sm text-gray-800 ml-2">${(Math.floor((totalAmount || 0) * 100) / 100).toFixed(2)}</span>
        </div> */}
        <div className="flex gap-2 mb-2">
          <label className="field-label" style={{ minWidth: '150px' }}>Reference</label>
          <Input
            type="text"
            className="input !w-[220px]"
            value={formData.reference_no}
            onChange={handleInputChange("reference_no")}
          //  placeholder="Enter Amount"
          //  prefix="$"
          />
        </div>
        <div className="flex gap-2 mb-2">
          <label className="field-label" style={{ minWidth: '150px' }}>Received</label>
          <DatePicker
            value={formData.received_date ? dayjs(formData.received_date) : dayjs()}
            onChange={(date) => {
              setFormData(prev => ({
                ...prev,
                received_date: date ? date.format('MM-DD-YYYY') : '',
              }));
            }}
            format="MM-DD-YYYY"
            className="input !w-[220px]"
            disabledDate={(current) => current && current > dayjs().startOf('day')
            }
          />
        </div>
        <div className="flex gap-2 mb-2">
          <label className="field-label" style={{ minWidth: '150px' }}>Agent</label>
          <Select
            options={agentOptions.map((option) => ({
              value: option,
              label: option,
            }))}
            styles={DropdownStyles}
            className={`${isSmallScreen?'!w-[150px]':'!w-[220px]'}`}
            value={
              formData.agent
                ? { value: formData.agent, label: formData.agent }
                : null
            }
            onChange={(selectedOption) =>
              setFormData((prev) => ({
                ...prev,
                agent: selectedOption ? selectedOption.value : "",
              }))
            }
            menuPlacement="top"
            menuPosition="fixed"
          />
        </div>
      </Modal>
      <Modal
        open={isCancelPaymentModal}
        onCancel={handleCancelChange}
        title={formData.isChargeBack ? "Charge Back" : "Cancel Payment"}
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelChange}
            >
              Cancel
            </button>
            <button
              className={`${!formData.reason ? "cancel-btn" : "save-btn"}`}
              disabled={!formData.reason}
              onClick={handleConfirmCancelPayment}
            >
              Save
            </button>
          </div>
        } centered
      >
       <div className="flex gap-4">
        <div className="flex flex-col">
            <label className="field-label">Transaction ID</label>
            <Input
              type="text"
              className="non-editable-input"
              value={formData.transaction_id}
              onChange={handleInputChange('transaction_id')}
              placeholder="Enter Transaction ID"
              readOnly
            />
          </div>
          <div className="flex flex-col">
            <label className="field-label">Amount</label>
            <Input
              type="text"
              className="non-editable-input"
              value={formData.item_amount}
              onChange={handleInputChange('item_amount')}
              placeholder="Enter Amount"
              prefix="$"
              readOnly
            />
          </div>
        </div>
        <div className="flex flex-col mt-4">
          {formData.isChargeBack && (
            <div className="flex flex-col mb-4">
      <div className="flex items-center">
        <Checkbox
          checked={formData.charge_back_fee || false}
          onChange={(e) =>
            setFormData({ ...formData, charge_back_fee: e.target.checked })
          }
        >
          Apply NSF fee ${generalFields.charge_back_fee ?? 0}
        </Checkbox>
      </div>
      <p className="ml-6 text-sm text-gray-500 italic">
        (leave unchecked to process without fee)
      </p>
    </div>
          )}
          

          
          <label className="field-label">Cancel Reason<span className="text-red-500">*</span></label>
          <textarea
            className="textarea"
            value={formData.reason}
            onChange={handleInputChange('reason')}
            placeholder="Enter your reason"
            rows={4}
          />
        </div>
      </Modal>
    </div>
  );
};

export default KillbillTableComponent;

// const GetToken = async (row: any) => {
//     // setLoading(true);
//     if (accountNumber) {
//       localStorage.setItem("account_number", accountNumber);
//     }
//     const newBillId: number = row.id ? Number(row.id) : Number(localStorage.getItem("bill_id")) || 0;

//     // Store bill_id as an array of numbers
//     const billIdArray: number[] = newBillId ? [newBillId] : [];
//     try {

//       // console.log("row",row)     
//       let data;
//       const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
//       data = {
//         tenant_name: partner || "default_value",
//         username: username,
//         firstLastName: firstLastName,
//         path: "/get_token",
//         role_name: role,
//         parent_module: "Billing Platform",
//         // module_name: "Billing and Collections Bills",
//         // feature_module_name: "Billing and Collections Bills",
//         Partner: partner,
//         access_token: token,
//         db_name: selectedDb,
//         // table_name: "sim_management_inventory",
//         request_received_at: getCurrentDateTime(),
//         sessionID: sessionId,
//         action: "create",
//         modified_by: firstLastName,
//         account_number:accountNumber,
//         bill_id:billIdArray,
//         ...formData
//       };

//       const response = await axios.post(url, { data });
//       const resp = JSON.parse(response.data.body);
//       // console.log(resp, "show the response");

//       if (response.data.statusCode === 200 && resp.flag === true) {
//         if(resp.batch_id){
//           const batchId_ = resp.batch_id;
//           // setBatchId(batchId_);
//           // console.log("Batch ID:", batchId_);
//           localStorage.setItem("batch_id", batchId_ ); 
//         }
//         if (resp.token) {
//           const authToken = resp.token;
//           // console.log("Auth Token:", authToken);
//           SubmitFormToAuthorizeNet(authToken, formData.item_amount);
//           // const authorizeNetURL = `https://test.authorize.net/payment/payment?token=${authToken}`;

//           // window.location.href = authorizeNetURL;
//         } else {
//           throw new Error("Auth token missing in response.");
//           setIsProcessing(false);
//         }
//       } else {
//         Modal.error({
//           title: "Data Error",
//           content: resp.message,
//           centered: true,
//         });
//         // setLoading(false);
//         handleCancel()
//         setIsProcessing(false);

//       }
//     } catch (error) {
//       console.error("Error fetching data:", error);
//       Modal.error({
//         title: 'Error',
//         content: 'Missing Authorize Token',
//         centered: true,
//       });
//       handleCancel()
//       // setLoading(false);

//     } finally {
//       // setLoading(false);
//     }
//   };
//   const SubmitFormToAuthorizeNet = (token: string, amount: string) => {
//     const form = document.createElement("form");
//     form.method = "POST";
//     form.action = ENV_ROUTES.AUTHORIZE_NET
//     const storedBatchId = localStorage.getItem("batch_id");
//     console.log("Stored Batch ID:", storedBatchId);
//     // form.action = "https://test.authorize.net/payment/payment";
//     // form.target = "_blank"; 

//     form.appendChild(createHiddenInput("token", token));
//     form.appendChild(createHiddenInput("amount", amount));
//     form.appendChild(createHiddenInput("billid", storedBatchId ?? ""));
//     document.body.appendChild(form);
//     form.submit();
//   };
//   const createHiddenInput = (name: string, value: string) => {
//     const input = document.createElement("input");
//     input.type = "hidden";
//     input.name = name;
//     input.value = value;
//     return input;
//   };