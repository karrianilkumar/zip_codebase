import { FC, useEffect, useState } from "react";
import { useRouter } from 'next/navigation';
import { Tooltip } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import { useAuth } from "../../../app/components/auth_context";
import { useSearchStore } from "@/app/stores/searchStore";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";

export const BillingInfoDetailCell: FC<{
  row?: any;popupHeading?: any
}> = ({ row ,popupHeading}) => {
  const [isMounted, setIsMounted] = useState(false);
  const router = useRouter();
  const { setRowId, setBulkRow, setICCID } = useFeatureStore();
  const { username, partner, role, settabledata, token, selectedDb, firstLastName, sessionId, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination, setStoredPagination } = useAuth();
    const { setShowNewPage,showNewPage,setBillingAndCollectionsActiveTab,setIsUploadInfoLoaded , isUploadInfoLoaded} = useCustomerProfileStore();
  
  const current_bulk_history_active_module = localStorage.getItem("current_bulk_history_active_module");
const { setIsRedirectedFromDetails, detailsRedirectedFilters , detailsRedirectedSearchTerm } = useSearchStore();
  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleClick = () => {
    setIsUploadInfoLoaded(true);
    sessionStorage.setItem('UnpostedUploadRow', JSON.stringify(row || "{}"));
    const allEmpty = Object.values(detailsRedirectedFilters).every(
        (value) => Array.isArray(value) && value.length === 0
      );
    const isEmptySearchTerm = detailsRedirectedSearchTerm === ""
      console.log("details ...",detailsRedirectedFilters,detailsRedirectedSearchTerm)
      if (allEmpty && isEmptySearchTerm) {
        setIsRedirectedFromDetails(false)
      }
      else {
        setIsRedirectedFromDetails(true)
      }
  };

  return (
    <div className="flex w-full ml-2">
      <Tooltip title="More information about the unposted upload">
        <a onClick={handleClick} className="text-center block cursor-pointer">
          <InformationCircleIcon className="h-5 w-5 text-green-500 cursor-pointer" />
        </a>
      </Tooltip>
    </div>
  );
};

export function BillingInfoDetailCellRenderer(row: any, popupHeading: any) {
  return <BillingInfoDetailCell row={row} popupHeading={popupHeading}/>;
}

