import React, { useState, useEffect, useMemo } from "react";
import { Select as AntdSelect, Checkbox, Input, Modal, notification, Spin, Switch, DatePicker } from "antd";
import { DropdownStyles, NonEditableDropdownStyles } from '@/app/components/css/dropdown';
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import dayjs from "dayjs";
import { useUserStore } from "@/app/partner/partner_info/users/createUser/createUserStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Select from "react-select";
import { CloseOutlined, DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { MinusCircleIcon, PlusCircleIcon } from "@heroicons/react/24/outline";
import { useKillBillStore } from "../killbill_stores/activeStore";
import CreatableSelect from "react-select/creatable";
import VirtualList from "rc-virtual-list";
import { X } from "lucide-react";
import { title } from "process";
import { useSearchStore } from "@/app/stores/searchStore";
import { fireSideCannons } from "@/app/components/confetti";
interface Column {
  display_name: string;
  db_column_name: string;
  type: string;
  default: string;
  mandatory: string;
}

interface EditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedRow: any, tableData: any) => void;
  rowData: any;
  createModalData?: any[];
  isEditable: boolean;
  heading: string;
  generalFields?: any;
  tableData?: any;
  action: any;
  isTabEdit?: any;
   selectedSubPartner?: any;
  selectedPartner?: any;
}

const EditModal: React.FC<EditModalProps> = ({
  isOpen,
  onClose,
  onSave,
  rowData,
  action,
  createModalData = [],
  isEditable,
  heading,
  generalFields,
  isTabEdit,
  tableData = [],
  selectedSubPartner,
  selectedPartner,
}) => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const [formData, setFormData] = useState<any>({});
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const {
    username,
    tenantNames,
    role,
    partner,
    settabledata,
    token,
    selectedDb,
    metaData,
    selectedBillingDb,
    firstLastName,
    sessionId,
  } = useAuth();
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [customFieldError, setCustomFieldError] = useState("");
  const [mandatoryError, setMandatoryError] = useState<string | null>(null);
  const [initialData] = useState<any>(tableData);
  const [builtinFields, setBuiltinFields] = useState<any[]>([]);
  const [showBuiltinFields, setShowBuiltinFields] = useState(false);
  const [selectedFields, setSelectedFields] = useState<{ display_name: string, type: string, db_column_name: string }[]>([]);
  const [tempSelectedFields, setTempSelectedFields] = useState<string[]>([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [isDropdownEnabled, setIsDropdownEnabled] = useState(false);
  const [editIndex, setEditIndex] = useState<number | null>(null);
  const [editValue, setEditValue] = useState("");
  const [showCustomFields, setShowCustomFields] = useState(false);
  const [customFields, setCustomFields] = useState<string[]>([]);
  const [customIdentifier, setCustomIdentifier] = useState<string[]>([]);

  const [newFieldDisplayName, setNewFieldDisplayName] = useState("");
  const [validationErrors, setValidationErrors] = useState<{ [key: string]: string }>({});
  const { serviceShowActive, packageActive, productTypeShowActive, productShowActive } = useKillBillStore();
  const { tenant, role_name, sub_tenant, setTenant, setRoleName, setSubTenant } = useUserStore();
  const [isTaxClassOverrideEnabled, setIsTaxClassOverrideEnabled] = useState(rowData?.override_tax_class ?? false);
  const [isTaxTypeOverrideEnabled, setIsTaxTypeOverrideEnabled] = useState(rowData?.override_tax_type ?? false);
  const [isPSCodeOverrideEnabled, setIsPSCodeOverrideEnabled] = useState(rowData?.override_ps_code ?? false);
  const [searchTerm, setSearchTerm] = useState('');
// const [userChangedTaxClass, setUserChangedTaxClass] = useState(false);
// const [userChangedTaxType, setUserChangedTaxType] = useState(false);
// const [userChangedPSCode, setUserChangedPSCode] = useState(false);
const [selectedPrimaryField, setSelectedPrimaryField] = useState<string | null>(null);
const [selectedCustomIdentifer, setSelectedCustomIdentifier] = useState<string | null>(null);

const [searchValue, setSearchValue] = React.useState("");
const { setOptimizationErrorsData , setGLCodeTableData , setserviceProviderData} = useSearchStore();

createModalData = useMemo(() => {
  return [...createModalData].sort((a, b) => {
    const orderA = parseInt(a.table_header_order || "0") || 0;
    const orderB = parseInt(b.table_header_order || "0") || 0;
    return orderA - orderB;
  });
}, [createModalData]);

  const fetchBuiltinFields = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/services_built_in_fields",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Service Types Builtin Fields",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: "Service Types",
      };

      const response = await axios.post(url, { data });
      if (!response.data.body) {
        throw new Error("Response data body is missing or invalid.");
      }

      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === true) {
        const fields = parsedData.header_map["Service Types Builtin Fields"].pop_up;
        setBuiltinFields(fields || []);
        return fields || [];
      } else {
        Modal.error({
          title: "Fetch Error",
          content: parsedData.message || "An error occurred while fetching built-in fields.",
          centered: true,
        });
        return [];
      }
    } catch (error) {
      Modal.error({
        title: "Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred.",
        centered: true,
      });
      return [];
    } finally {
      setLoading(false);
    }
  };

  // useEffect(() => {
  //   if (heading === "Product" &&
  //     formData["product_type_code"] &&
  //     formData["product_type_code"]?.toLowerCase().startsWith("onetime")
  //   ) {
  //     setFormData((prevState: any) => {
  //       const updatedFormData = {
  //         ...prevState,
  //         prorate: false
  //       };
  //       return updatedFormData;
  //     });
  //   }
  // }, [heading, formData]);

  const handleChange = (name: string, value: any) => {
    setFormData((prevState: any) => ({
      ...prevState,
      [name]: value ?? "",
    }));
    let errors = { ...validationErrors };

    if (name === "postal_code") {
      const regex = /^\d{5}$/;
      if (!regex.test(value)) {
        errors[name] = "Postal code must be exactly 5 digits";
      } else {
        delete errors[name];
      }
    }
     if (name === "bill_period_end_day") {
      if (value && (!/^\d+$/.test(value.toString()) || Number(value) < 1 || Number(value) > 28)) {
        errors[name] = "Bill Period Start Day must be a number between 1 and 28";
      } else {
        delete errors[name];
      }
    }

    if (name === "bill_period_end_hour") {
      if (value && (!/^\d+$/.test(value.toString()) || Number(value) < 0 || Number(value) > 23)) {
        errors[name] = "Bill Period Start Hour must be a number between 0 and 23";
      } else {
        delete errors[name];
      }
    }
    if (name === "customer_bill_period_end_hour") {
      const hour = Number(value);
      if (isNaN(hour) || hour < 0 || hour > 23) {
        errors[name] = "Customer bill period end hour must be between 0 and 23";
      } else {
        delete errors[name];
      }
    }
    if (name === "customer_bill_period_end_date" || name === "customer_bill_period_end_day") {
      const date = Number(value);
      if (isNaN(date) || date < 1 || date > 28) {
        errors[name] = "Customer bill period end date must be between 1 and 28";
      } else {
        delete errors[name];
      }
    }
    if (name.toLowerCase().endsWith("date")) {
      if (value && !dayjs(value).isValid()) {
        errors[name] = "Please enter a valid date";
      } else {
        if (value && name === "customer_bill_period_end_date") {
          const day = dayjs(value).date();
          if (day < 1 || day > 28) {
            errors[name] = "Customer bill period end date must be between 1 and 28";
          } else {
            delete errors[name];
          }
        } else {
          delete errors[name];
        }
      }
    }
    setValidationErrors(errors);
  };

  const handleSelectChange = (name: string, value: any) => {
    if(name === "ps_code" && value && formData.bundle_code){
      Modal.warning({
        title: 'Input Warning',
        content: 'Only one of Bundle Code or Tax Code can be entered.',
        centered: true,
      });
      return;
    }
    if (name === "bundle_code") {
      setFormData((prevState: any) => ({
        ...prevState,
        [name]:value,
        "ps_code": "",
      }));
    }
    else {
      setFormData((prevState: any) => ({
        ...prevState,
        [name]: value,
      }));
    }
    // Track the selected value for primary_field
  if (name === "primary_field") {
    setSelectedPrimaryField(value);
  }
  };

  const handleSave = () => {
    onSave(formData, initialData);
    handleCancel();
  };

  const handleCancel = () => {
    setTenant([]);
    setSubTenant([]);
    setRoleName("");
    setFormData({});
    setSelectedFields([]);
    setTempSelectedFields([]);
    setBuiltinFields([]);
    setCustomFields([]);
    setNewFieldDisplayName("");
    setShowBuiltinFields(false);
    setShowCustomFields(false);
    setDropdownOpen(false);
    setIsDropdownEnabled(false);
    setValidationErrors({});
    onClose();
  };

  const handleBuiltinFields = async () => {
    setShowBuiltinFields(true);
    setIsDropdownEnabled(true);
    if (builtinFields.length === 0) {
      await fetchBuiltinFields();
    }
    setTempSelectedFields(selectedFields.map(field => field.db_column_name));
    setDropdownOpen(true);
  };

  const handleOkFields = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const newSelectedFields = tempSelectedFields
      .map(val => {
        const field = builtinFields.find(f => f.db_column_name === val);
        const existingField = selectedFields.find(f => f.db_column_name === val);
        if (!field && !existingField) {
          console.warn(`Field with db_column_name "${val}" not found in builtinFields or selectedFields`);
          return null;
        }
        return {
          display_name: field?.display_name || existingField?.display_name || val,
          type: field?.type || existingField?.type || "text",
          db_column_name: val,
        };
      })
      .filter((field): field is { display_name: string, type: string, db_column_name: string } => field !== null);
    setSelectedFields(newSelectedFields);
    setDropdownOpen(false);
    setIsDropdownEnabled(false);
    setSearchTerm('')
  };

  const handleCancelFields = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setTempSelectedFields(selectedFields.map(field => field.db_column_name));
    setDropdownOpen(false);
    setIsDropdownEnabled(false);
  };

  const handleDeleteField = (index: number) => {
    setSelectedFields(prev => prev.filter((_, i) => i !== index));
    setTempSelectedFields(prev => prev.filter(val => val !== selectedFields[index].db_column_name));
  };

  const handleEditField = (index: number) => {
    setEditIndex(index);
    setEditValue(selectedFields[index].display_name);
  };

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditValue(e.target.value);
  };

  const handleEditSave = (index: number) => {
    if (editValue.trim()) {
      setSelectedFields(prev => {
        const updatedFields = [...prev];
        updatedFields[index].display_name = editValue;
        return updatedFields;
      });
      setEditIndex(null);
      setEditValue("");
    }
  };

  const handleToggleCustomFields = () => {
    setShowCustomFields(true);
  };

  const showConfirmation = async () => {
    if (heading === "Service Type" && action === "edit" ) {
      setLoading(true);
      let url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
      console.log("formData",formData)
      try{
        let data ;        
        data = {
          tenant_name: partner || "default_value",
          username,
          firstLastName,
          path: "/fetch_active_customer_services_by_service_type",
          role_name: role,
          module_name: "Service Types",
          action: "edit",
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          description:formData.description,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id:tenant_id_,
          table_name: "services",
          main_module_name: "Service Types",

        };
        const response = await axios.post(url, { data });
        const resp = JSON.parse(response.data.body);

        if (response.data.statusCode === 200 && resp.flag === true) {

          Modal.confirm({
            title: "Warning",
            content: resp.message,
            centered: true,
            okText: "Yes",        // Text for OK button
            cancelText: "Cancel",  // Text for Cancel button
            onOk: () => {
              handleConfirmSave();
            },
            closable: true, 
            onCancel: () => {
              // Modal will close automatically on cancel
              console.log("User cancelled");
            },
          });

        }
        else{
          handleConfirmSave()
        }
      }catch (error) {
        Modal.error({
          title: "Saving Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    } 
    else{
      const errors: { [key: string]: string } = {};
  
      createModalData.forEach((column) => {
        const value = formData[column.db_column_name];
        if(column.db_column_name === "ps_code"){
          return;
        }
        if(column.db_column_name === "bundle_code" && !formData.bundle_code && !formData.ps_code){
          errors[column.db_column_name] = `Bundle Code or Tax Code is required.`;
        }
        if (
          column.mandatory &&
          ((Array.isArray(value) && value.length === 0) ||
            (!Array.isArray(value) && (!value || value === "None")))
        ) {
            errors[column.db_column_name] = `${column.display_name} is required.`;
        }
      });
  
      if (Object.keys(errors).length > 0) {
        setValidationErrors(errors);
        setIsConfirmationOpen(false);
        return;
      } else {
        setValidationErrors({});
        setMandatoryError(null);
        setIsConfirmationOpen(true);
      }
    }

  };

  const handleAddCustomField = () => {
    if (!newFieldDisplayName.trim()) {
      setCustomFieldError("Please enter field name");
      return;
    }
    if (customFields.some((field) => field.toLowerCase() === newFieldDisplayName.trim().toLowerCase())) {
      setCustomFieldError("Field name already exists");
      return;
    }
    setCustomFields((prev) => [...prev, newFieldDisplayName.trim()]);
    setNewFieldDisplayName("");
    setCustomFieldError("");
  };

  const handleDeleteCustomField = (index: number) => {
    const updatedCustomFields = customFields.filter((_, i) => i !== index);
    setCustomFields(updatedCustomFields);
  };

  const handleConfirmSave = async () => {
    if (formData) {
      setLoading2(true);
      try {
        setIsConfirmationOpen(false);
        const updatedFormData = {
          ...formData,
          ...(selectedFields.length > 0 && {
            built_in_fields: selectedFields.map((field) => ({
              field: field.display_name,
              type: field.type,
            })),
          }),
          ...(customFields.length > 0 && {
            custom_fields: customFields.map((field) => ({
              field,
              type: "text",
            })),
          }),
        };

        let data : any;
        let url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
        let url2 = ENV_ROUTES.MODULE_MANAGEMENT;
        let Action = action === "edit" ? "update" : "copy";
        if (heading === "Service Type") {
          const Path = action === "edit" ? "/update_service_type" : "/copy_service_type";

          updatedFormData["modified_by"] = firstLastName;
          updatedFormData["modified_date"] = getCurrentDateTime();
          delete updatedFormData["tenant_id"];

          data = {
            tenant_name: partner || "default_value",
            username,
            firstLastName,
            path: Path,
            role_name: role,
            module_name: "Service Types",
            action: Action,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            table_name: "services",
            main_module_name: "Service Types",
          };

          if (action === "edit") {
            data.changed_data = {
              description: updatedFormData.description,
              ...(selectedFields.length > 0 && {
                built_in_fields: selectedFields.map((field) => ({
                  field: field.display_name,
                  type: field.type,
                })),
              }),
              ...(customFields.length > 0 && {
                custom_fields: customFields.map((field) => ({
                  field,
                  type: "text",
                })),
              }),
            };
          } else {
            data.changed_data = updatedFormData;
          }
        }
        else if (heading === "Product") {
           let Path =  action === "edit"?"/update_products":"/copy_products";
          updatedFormData["modified_by"] = firstLastName;
          updatedFormData["modified_date"] = getCurrentDateTime();
          // updatedFormData["ps_code"] = updatedFormData["bundle_code"] !== "null" ? `${updatedFormData["bundle_code"]} - ${updatedFormData["ps_code"]}` : updatedFormData["ps_code"]
          // delete updatedFormData["bundle_code"]
          delete updatedFormData["tenant_id"];
          data = {
            tenant_name: partner || "default_value",
            username,
            firstLastName,
            path: Path,
            role_name: role,
            module_name: "Billing Products",
            action: Action,
            changed_data: updatedFormData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            tenant_id:tenant_id_,
            sessionID: sessionId,
            table_name: "products",
          };
        } else if (heading === "Product Type") {
           let Path =  action === "edit"?"/update_product_type":"/copy_product_type";
          updatedFormData["modified_by"] = firstLastName;
          updatedFormData["modified_date"] = getCurrentDateTime();
          delete updatedFormData["tenant_id"];
          data = {
            tenant_name: partner || "default_value",
            username,
            firstLastName,
            path: Path,
            role_name: role,
            module_name: "Billing Product Types",
            action: Action,
            changed_data: updatedFormData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            tenant_id:tenant_id_,
            sessionID: sessionId,
            table_name: "product_types",
          };
        } else if (heading === "Packages") {
           let Path =  action === "edit"?"/update_package":"/copy_package";
          updatedFormData["modified_by"] = firstLastName;
          updatedFormData["modified_date"] = getCurrentDateTime();
          delete updatedFormData["tenant_id"];
          data = {
            tenant_name: partner || "default_value",
            username,
            firstLastName,
            path: Path,
            role_name: role,
            module_name: "Billing Packages",
            table_name: "packages_list_view",
            action: Action,
            changed_data: updatedFormData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            tenant_id:tenant_id_,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            sessionID: sessionId,
          };
        }
        else if (heading === "GL Code") {

          updatedFormData["modified_by"] = firstLastName;
          updatedFormData["modified_date"] = getCurrentDateTime();
          delete updatedFormData["tenant_id"];
          data = {
            tenant_name: partner || "default_value",
            username,
            firstLastName,
            path: "/update_glcode",
            parent_module: "Partner Info",
            module_name: "Billing GL Code",
            Selected_Partner: selectedPartner,
            sub_partner: selectedSubPartner,
            role_name: role,
            action: Action,
            changed_data: updatedFormData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            tenant_id:tenant_id_,
            sessionID: sessionId,
          };
        }
         else if (heading === "Service Provider") {
          updatedFormData["modified_by"] = firstLastName;
          updatedFormData["modified_date"] = getCurrentDateTime();
          delete updatedFormData["tenant_id"];
          data = {
            tenant_name: partner || "default_value",
            username,
            firstLastName,
            path: "/update_bp_service_provider",
            parent_module: "Partner Info",
            module_name: "Billing Service Providers",
            Selected_Partner: selectedPartner,
            sub_partner: selectedSubPartner,
            role_name: role,
            action: Action,
            changed_data: updatedFormData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            tenant_id:tenant_id_,
            sessionID: sessionId,
          };
        }
        let postUrl;
        if (heading === "GL Code" || heading === "Service Provider") {
          postUrl = url2;
        }else{
          postUrl = url;
        }
        const response = await axios.post(postUrl, { data });
        const resp = JSON.parse(response.data.body);

        if (response.data.statusCode === 200 && resp.flag === true) {
            if(resp?.validation){
                    Modal.warning({
                      title: "Validation Error",
                      content: resp.message,
                      centered: true,
                    });
                    return;
                  }
          notification.success({
            message: "Success",
            description: resp.message,
            style: { fontSize: "14px", fontWeight: "normal", padding: "16px" },
            placement: "top",
          });
          fireSideCannons();
          settabledata([])
          if (heading === "Service Type") {
            try {
              setLoading2(true);
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
              const data = {
                tenant_name: partner || "default_value",
                username,
                firstLastName,
                path: "/services_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Service Types",
                sub_module: "Services",
                mod_pages: { start: 0, end: 100 },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
billing_db_name: selectedBillingDb,
                tenant_id:tenant_id_,
                sessionID: sessionId,
                status: serviceShowActive ? "true" : "false",
                feature_module_name: "Service Types",
        main_module_name: "Service Types",
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content: parsedData.message || "An error occurred while fetching data.",
                  centered: true,
                });
              } else {
                settabledata(parsedData?.data?.billing_services || []);
              }
            } catch {
            } finally {
              setLoading2(false);
            }
          } else if (heading === "Product") {
            try {
              setLoading2(true);
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
              const data = {
                tenant_name: partner || "default_value",
                username,
                firstLastName,
                path: "/products_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Billing Products",
                sub_module: "Products",
                mod_pages: { start: 0, end: 100 },
                request_received_at: getCurrentDateTime(),
                status: productShowActive ? "true" : "false",
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                tenant_id:tenant_id_,
                feature_module_name: "Billing Products",
        main_module_name: "Service Types",
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content: parsedData.message || "An error occurred while fetching data.",
                  centered: true,
                });
              } else {
                settabledata(parsedData?.data?.billing_products || []);
              }
            } catch {
            } finally {
              setLoading2(false);
            }
          } else if (heading === "Product Type") {
            try {
              setLoading2(true);
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
              const data = {
                tenant_name: partner || "default_value",
                username,
                firstLastName,
                path: "/product_type_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Billing Product Types",
                sub_module: "Products",
                mod_pages: { start: 0, end: 100 },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                tenant_id:tenant_id_,
                status: productTypeShowActive ? "true" : "false",
                feature_module_name: "Billing Product Types",
        main_module_name: "Service Types",
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content: parsedData.message || "An error occurred while fetching data.",
                  centered: true,
                });
              } else {
                settabledata(parsedData?.data?.billing_product_types || []);
              }
            } catch {
            } finally {
              setLoading2(false);
            }
          } else if (heading === "Packages") {
            try {
              setLoading2(true);
              const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
              const data = {
                tenant_name: partner || "default_value",
                username,
                firstLastName,
                path: "/services_product_package_list_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Billing Packages",
                sub_module: "Products",
                mod_pages: { start: 0, end: 100 },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                tenant_id:tenant_id_,
                status: packageActive ? "true" : "false",
                feature_module_name: "Billing Packages",
        main_module_name: "Service Types",
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content: parsedData.message || "An error occurred while fetching data.",
                  centered: true,
                });
              } else {
                settabledata(parsedData?.data?.billing_services || []);
              }
            } catch {
            } finally {
              setLoading2(false);
            }
          }
          else if (heading === "GL Code") {
            try {
              setLoading2(true);
              const url = ENV_ROUTES.MODULE_MANAGEMENT;
               const data = {
                            tenant_name: partner || "default_value",
                            username: username,
                            firstLastName: firstLastName,
                            path: "/glcode_list_view",
                            role_name: role,
                            parent_module: "Partner Info",
                            module_name: "Billing GL Code",
                            Selected_Partner: selectedPartner,
                            sub_partner: selectedSubPartner,
                            request_received_at: getCurrentDateTime(),
                            access_token: token,
                            db_name: selectedDb,
                            ...metaData,
billing_db_name: selectedBillingDb,
                            sessionID: sessionId,
                            mod_pages: {
                            start: 0,
                            end: 100,
                          },      
                          };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content: parsedData.message || "An error occurred while fetching data.",
                  centered: true,
                });
              } else {
                // settabledata(parsedData?.data?.billing_gl_code || []);
                setGLCodeTableData(parsedData?.data?.billing_gl_code || []);
              }
            } catch {
            } finally {
              setLoading2(false);
            }
          }
          else if (heading === "Service Provider") {
            try {
              setLoading2(true);
              const url = ENV_ROUTES.MODULE_MANAGEMENT;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/bp_service_providers_list_view",
                role_name: role,
                parent_module: "Partner Info",
                module_name: "Billing Service Providers",
                Selected_Partner: selectedPartner,
                sub_partner: selectedSubPartner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                mod_pages: {
                  start: 0,
                  end: 100,
                },
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content: parsedData.message || "An error occurred while fetching data.",
                  centered: true,
                });
              } else {
                setserviceProviderData(parsedData?.data?.billing_service_providers || []);
              }
            } catch {
            } finally {
              setLoading2(false);
            }
          }
        } else {
          Modal.error({
            title: "Saving Error",
            content: resp.message,
            centered: true,
          });
          return;
        }
        handleSave();
      } catch (error) {
        Modal.error({
          title: "Saving Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred.",
          centered: true,
        });
      } finally {
        setLoading2(false);
      }
    }
  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const capitalizeFirstLetter = (text: string) => {
    if (!text) return "";
    return text
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ");
  };

  const lowerCaseFirstLetter = (text: string) => {
    if (!text) return "";
    return text
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ");
  };

  useEffect(() => {
    if (isOpen) {
      console.log("rowdata",rowData)
      //  const fullPsCode = rowData?.ps_code; // "19010200 - On Site or Phone Support - Optional"
      // if (fullPsCode) {
      //   const parts = fullPsCode.split(" - ");
      //   const bundleCode = parts.shift()?.trim() || "";  
      //   const psCodeOnly = parts.join(" - ").trim();

      //   setFormData((prev: any) => {
      //     const updatedData = {
      //       ...rowData,
      //       bundle_code: bundleCode,
      //       ps_code: psCodeOnly,
      //     }
      //     console.log("updatedData",updatedData)
      //     return updatedData;
      //   });
      // } else {
        setFormData(rowData || {});
      // }
      setIsTaxClassOverrideEnabled(rowData?.override_tax_class ?? false);
      setIsTaxTypeOverrideEnabled(rowData?.override_tax_type ?? false);
      setIsPSCodeOverrideEnabled(rowData?.override_ps_code ?? false);
      setSelectedPrimaryField(rowData?.primary_field || null);
      setCustomIdentifier(rowData?.custom_primary_field || null)


      // Initialize built_in_fields
      if (rowData?.built_in_fields && Array.isArray(rowData.built_in_fields)) {
        // const formattedFields = rowData.built_in_fields.map((field: any) => ({
        //   db_column_name: field.field.replace(/\s+/g, "_").toLowerCase(),
        //   display_name: field.field,
        //   type: field.type || "text",
        // }));
        const formattedFields = rowData.built_in_fields.map((field: any) => {
          const display_name = field.field; // ← Do NOT change this

          // Default db column name comes from backend if present
          let db_column_name = field.db_column_name
            || display_name.replace(/\s+/g, "_").toLowerCase();

          // ✅ Override only db_column_name for specific display names
          if (display_name === "Customer Rate Plan") {
            db_column_name = "customer_rate_plan_name";
          }

          if (display_name === "Customer Cycle Usage") {
            db_column_name = "customer_cycle_usage_mb";
          }
           if (display_name === "Username") {
            db_column_name = "created_by";
          }

          return {
            db_column_name,   // ← Only this changes
            display_name,     // ← Keep exactly as backend sent
            type: field.type || "text",
          };
        });
        console.log("formattedFields",formattedFields);
        setSelectedFields(formattedFields);
        if(rowData?.built_in_fields && rowData?.built_in_fields.length > 0){
          setShowBuiltinFields(true);
        }

        // Fetch builtinFields to validate tempSelectedFields
        fetchBuiltinFields().then((fields) => {
          const validDbColumnNames = fields.map((f: any) => f.db_column_name);
          const validTempFields = formattedFields
            .map((field: any) => field.db_column_name)
            .filter((db_column_name: string) => validDbColumnNames.includes(db_column_name));
          setTempSelectedFields(validTempFields);
        });
      } else {
        setSelectedFields([]);
        setTempSelectedFields([]);
        setShowBuiltinFields(false);
      }

      // Initialize custom_fields
      if (rowData?.custom_fields && Array.isArray(rowData.custom_fields) && rowData?.custom_fields.length > 0) {
        setCustomFields(rowData.custom_fields.map((field: any) => field.field));
        setShowCustomFields(true);
      } else {
        setCustomFields([]);
        setShowCustomFields(false);
      }

      setValidationErrors({});
      setIsDropdownEnabled(false);
    }
  }, [isOpen, rowData]);

  // const handleOverrideChange = (fieldName: string, isChecked: boolean) => {
  //   setFormData((prev: any) => ({
  //     ...prev,
  //     [`override_${fieldName}`]: isChecked,
  //   }));
  //   if (fieldName === "ps_code") setIsPSCodeOverrideEnabled(isChecked);
  //   if (fieldName === "tax_class") setIsTaxClassOverrideEnabled(isChecked);
  //   if (fieldName === "tax_type") setIsTaxTypeOverrideEnabled(isChecked);
  // };

  const getDropdownStyles = (fieldName: string) => {
    const isNonEditable =
      (heading === "Product" && (fieldName === "bundle_code" && formData.ps_code)) ||
      (heading === "Customer Profiles" &&
        fieldName === "parent_accounts" &&
        formData.account_type !== "Child") || (heading === "Service Type" && action === "edit");

    return {
      ...(isNonEditable ? NonEditableDropdownStyles : DropdownStyles),
      menuPortal: (base: any) => ({ ...base }),
    };
  };

  const isFieldDisabled = (fieldName: string) => {
    if (heading === "Product") {
      if (fieldName === "bundle_code" && formData.ps_code) {
        return true;
      }
    }
    if (heading === "Customer Profiles" && fieldName === "parent_accounts" && formData.account_type !== "Child") {
      return true;
    }
    if (heading === "Service Type" && action === "edit") {
      return true;
    }
    return false;
  };

  const handleCloseBuiltinFields = () => {
    setShowBuiltinFields(false);
    setDropdownOpen(false);
    setIsDropdownEnabled(false);
    setBuiltinFields([])
    setSelectedFields([])
    setFormData((prev:any) => ({
      ...prev,
      built_in_fields:[]
    }))
  };

  const handleCloseCustomFields = () => {
    setShowCustomFields(false);
    setCustomFields([])
    setFormData((prev:any) => ({
      ...prev,
      custom_fields:[]
    }))
  };

  const handleCustomFieldChange = (e: any) => {
    setNewFieldDisplayName(e.target.value);
    setCustomFieldError("");
  };
const handleColumnChange = (
  columnName: string,
  values: any,
  setError: (msg: string | null) => void
) => {
  const isMultiSelect =
    columnName === "multi_service_id" ||
    columnName === "multi_provider_accounts" ||
    columnName === "multi_options";

 if (isMultiSelect) {
    if (Array.isArray(values)) {
      if (values.length > 20) {
        setError("You can select up to 20 options only.");
        return;
      }
      setError(null);
      const updatedValues = values.map((option) => option.value);
      handleSelectChange(columnName, updatedValues);
    } else {
      handleSelectChange(columnName, values ? [values.value] : []);
    }
  } else {
    handleSelectChange(columnName, values ? values.value : null);
  }
};
const getDropdownOptions = (column: any) => {
  const rawOptions = column.db_column_name === 'bundle_code'?  generalFields.dropdown['ps_code'] : generalFields.dropdown[column.db_column_name];
  if (!rawOptions && column.db_column_name !== "bundle_code") return [];

  // PRODUCT TYPE (object)
  if (
    column.db_column_name === "product_type" &&
    typeof rawOptions === "object"
  ) {
    return Object.keys(rawOptions).map(key => ({
      label: key,
      value: key,
    }));
  }

  // BUNDLE CODE → unique bundle codes (before first "-")
if (column.display_name === "Bundle Code" && Array.isArray(rawOptions)) {
  const uniqueBundles = Array.from(
    new Set(
      rawOptions
        .filter(opt => typeof opt === "string")
        .map(opt => opt.split(" - ")[0].trim())
    )
  );

  const result = uniqueBundles
    .filter(bundle => bundle && bundle !== "No BundleCode")
    .map(bundle => ({
      label: bundle,
      value: bundle,
    }));

  result.sort((a, b) =>
    a.label.localeCompare(b.label, undefined, {
      numeric: true,
      sensitivity: "base",
    })
  );

  return result;
}

  // PS CODE / TAX CODE → dependent on bundle code
  if (
    (column.display_name === "Tax Code") &&
    Array.isArray(rawOptions)
  ) {
    const selectedBundle = formData?.bundle_code ;

    const filtered = selectedBundle
      ? rawOptions.filter(
        (opt): opt is string =>
          typeof opt === "string" &&
          opt.startsWith(`${selectedBundle} -`)
      )
      : rawOptions.filter((opt): opt is string => typeof opt === "string");


    return filtered.map((opt: string) => {
      const [, ...rest] = opt.split(" - ");
      return {
        label: rest.join(" - ").trim(),
        value: rest.join(" - ").trim(),
      };
    });
  }

  // DEFAULT
  if (Array.isArray(rawOptions)) {
    return rawOptions.map((opt: string) => ({
      label: opt,
      value: opt,
    }));
  }

  return [];
};


  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const modalWidth = typeof window !== "undefined"
  ? window.innerWidth <= 768  // 768px is Tailwind's `md` breakpoint
    ? (window.innerWidth * 3.5) / 4
    : (window.innerWidth * 2.5) / 4
  : 0;
  const modalHeight = typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;

  if (loading2) {
    return (
      <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div>
      {isTabEdit ? (
        <Modal
          title={isEditable ? `Edit User` : `User Details`}
          open={isOpen}
          onCancel={handleCancel}
          width={modalWidth}
          styles={{ body: { height: modalHeight, padding: "4px" } }}
          footer={null}
          centered
        />
      ) : (
        <>
          {!isEditable && (heading === "NetSapien Customer" || heading === "Bandwidth Customer") ? (
            <Modal
              open={isOpen}
              onCancel={handleCancel}
              title={
                <div className="">
                  <span className="text-[18px]">
                    {isEditable ? `Edit ${capitalizeFirstLetter(heading)}` : `${capitalizeFirstLetter(heading)} Details`}
                  </span>
                </div>
              }
              width={500}
              footer={
                isEditable ? (
                  <div className="justify-center flex space-x-2">
                    <button onClick={handleCancel} className="cancel-btn">Cancel</button>
                    <button onClick={showConfirmation} className="save-btn">Save</button>
                  </div>
                ) : null
              }
              centered
              styles={{ body: { height: "auto", padding: "4px" } }}
            />
          ) : (
            <Modal
              open={isOpen}
              onCancel={handleCancel}
              title={
                <h3 className="popup-heading">
                  {action === "copy" ? `Copy ${heading}` : isEditable ? `Edit ${capitalizeFirstLetter(heading)}` : `${capitalizeFirstLetter(heading)} Details`}
                </h3>
              }
              footer={
                isEditable ? (
                  <div className="mt-7 flex flex-wrap justify-center gap-2">            
                    
                    {heading === "Service Type" && (
                      <>
                        <button
                          className={(showBuiltinFields) ? 'cancel-btn' : 'save-btn'}
                          onClick={handleBuiltinFields}
                          disabled={showBuiltinFields}
                        >
                          Add Built-in Fields
                        </button>
                        <button
                          className={showCustomFields ? 'cancel-btn' : 'save-btn'}
                          onClick={handleToggleCustomFields}
                          disabled={showCustomFields}
                        >
                          Add Custom Fields
                        </button>
                      </>
                    )}
                    <button onClick={handleCancel} className="cancel-btn">Cancel</button>
                    <button onClick={showConfirmation} className="save-btn">Save</button>
                  </div>
                ) : null
              }
              width={(createModalData.length > 5 || heading === "Service Type") ? modalWidth : "500px"}
              styles={{
                body: {
                  height: (createModalData.length >= 5 || heading === "Service Type") ? modalHeight : "auto",
                  padding: "4px",
                },
              }}
              centered
            >
              {loading ? (
                <div className="flex justify-center items-center h-full">
                  <Spin size="large" />
                </div>
              ) : (
                <div className={`${(createModalData.length >= 5 || heading === "Service Type") ? "popup" : ""}`}>
                  <form>
                  <div
                      className={`grid gap-4
                        ${createModalData.length > 5 && heading === "Product"
                          ? "grid-cols-1 sm:grid-cols-2"
                          : createModalData.length > 4 && heading === "Product Type"
                          ? "grid-cols-1 sm:grid-cols-1"
                          : createModalData.length >= 5 && heading !== "Product"
                          ? "grid-cols-1 sm:grid-cols-2 md:grid-cols-3"
                          : createModalData.length >= 4 && heading === "Service Type"
                          ? "sm:grid-cols-1 md:grid-cols-2"
                          : "grid-cols-1"
                        }`}
                    >
                      {createModalData.map((column: Column) => (
                        <div key={column.db_column_name}  className={`${heading === "Product Type" ? "mb-2":"mb-4"} flex flex-col`}>
                          {column.type !== "checkbox" && (
                            <label className="field-label">
                              {column.display_name}{" "}
                              {column.mandatory && column.mandatory !== null && (
                                <span className="text-red-500">*</span>
                              )}
                            </label>
                          )}
                          {column.type === "text" && (
                            <>
                              <Input
                                type="text"
                                value={formData[column.db_column_name] && formData[column.db_column_name] !== "None" ? formData[column.db_column_name] : ""}
                                placeholder={`Enter ${lowerCaseFirstLetter(column.display_name)}`}
                                onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                                className={
                                  !isEditable || (heading === "Service Type" && action === "edit")
                                    ? "non-editable-input !text-black"
                                    : "input"
                                }                                
                                disabled={!isEditable || (heading === "Service Type" && action === "edit")}
                              />
                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500">{validationErrors[column.db_column_name]}</span>
                              )}
                            </>
                          )}
                          {column.type === "dollar" && (
                            <div className="relative">
                              {/* <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                $
                              </span> */}

                              <Input
                                type="number"
                                prefix="$"
                                value={formData[column.db_column_name] || ""}
                                placeholder={`Enter ${lowerCaseFirstLetter(column.display_name)}`}
                                className="input !pl-4"
                                onChange={(e) => {
                                  let value = e.target.value;

                                  // Allow only digits and one dot
                                  value = value.replace(/[^0-9.]/g, "");

                                  // Ensure max 1 dot
                                  const parts = value.split(".");
                                  if (parts.length > 2) {
                                    parts.splice(2);
                                  }

                                  // Limit decimals to 2 digits
                                  if (parts[1]?.length > 2) {
                                    parts[1] = parts[1].slice(0, 2);
                                  }

                                  value = parts.join(".");

                                  handleChange(column.db_column_name, value);
                                }}
                                 onWheel={(e) => {
                                  (e.target as HTMLInputElement).blur();
                                }} 
                              />

                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500">
                                  {validationErrors[column.db_column_name]}
                                </span>
                              )}
                            </div>
                          )}

                          {column.type === "dropdown" && (
                            <>
                              <Select
                                isMulti={["multi_service_id", "multi_provider_accounts", "multi_options"].includes(column.db_column_name)}
                                isClearable
                                styles={getDropdownStyles(column.db_column_name)}
                                isDisabled={isFieldDisabled(column.db_column_name)}
                                placeholder="Select..."
                                 menuPlacement="auto" 
                                value={(() => {
                                   let selectedValues = formData[column.db_column_name] || [];
                                  try {
                                    selectedValues = typeof selectedValues === "string" ? JSON.parse(selectedValues) : selectedValues;
                                    selectedValues = Array.isArray(selectedValues) ? selectedValues : [selectedValues];
                                    return selectedValues.map((item: any) => ({
                                      label: item,
                                      value: item,
                                    }));
                                  } catch {
                                    const values = selectedValues?.split(",") || [];
                                    return values.map((item: string) => ({
                                      label: item.trim(),
                                      value: item.trim(),
                                    }));
                                  }
                                })()}
                               onChange={(values) => handleColumnChange(column.db_column_name, values, setError)}
                                options={getDropdownOptions(column) }
                              />
                             

                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500 mt-2">{validationErrors[column.db_column_name]}</span>
                              )}
                               {/* {["tax_class", "tax_type", "ps_code"].includes(column.db_column_name) && heading === "Product" && (
                                <>
                                  <div className="flex items-center mt-2">
                                    <input
                                      type="checkbox"
                                      id={`override_${column.db_column_name}`}
                                      checked={formData[`override_${column.db_column_name}`] ?? false}
                                      onChange={(e) => handleOverrideChange(column.db_column_name, e.target.checked)}
                                      className="mr-2"
                                    />
                                    <label htmlFor={`override_${column.db_column_name}`} className="text-sm font-medium">
                                      Override
                                    </label>
                                  </div>
                                  <span className="text-[#B5B5B5]">
                                    This {column.db_column_name.replace("_", " ")} is inherited from the selected Product Type
                                  </span>
                                </>
                              )} */}
                            </>
                          )}
                           

                          {column.type === "multi_dropdown" && (
                            <>
                              <AntdSelect
                                mode="multiple"
                                style={{ ...NonEditableDropdownStyles, width: "100%" }}
                                allowClear
                                showArrow
                                showSearch
                                disabled={isFieldDisabled(column.db_column_name)}
                                placeholder="Select..."
                                value={(() => {
                                  let selectedValues = formData[column.db_column_name] || [];

                                  try {
                                    selectedValues =
                                      typeof selectedValues === "string"
                                        ? JSON.parse(selectedValues)
                                        : selectedValues;

                                    selectedValues = Array.isArray(selectedValues)
                                      ? selectedValues
                                      : [selectedValues];

                                    // ✅ Special mapping for display_name
                                    if (column.db_column_name === "display_name") {
                                      const options =
                                        generalFields?.dropdown?.[column.db_column_name] || [];

                                      // Map stored short names → full option text
                                      const mapped = selectedValues.map((stored: string) => {
                                        const matched = options.find((opt: string) =>
                                          opt.startsWith(stored)
                                        );
                                        return matched || stored;
                                      });

                                      return mapped;
                                    }

                                    if (
                                      column.db_column_name === "multi_service_id" ||
                                      column.db_column_name === "multi_provider_accounts" ||
                                      column.db_column_name === "multi_options"
                                    ) {
                                      return selectedValues;
                                    }

                                    return selectedValues.length > 0 ? selectedValues : [];
                                  } catch {
                                    const values = selectedValues?.split(",") || [];

                                    // ✅ Special mapping for display_name (catch block case)
                                    if (column.db_column_name === "display_name") {
                                      const options =
                                        generalFields?.dropdown?.[column.db_column_name] || [];

                                      const mapped = values.map((stored: string) => {
                                        const matched = options.find((opt: string) =>
                                          opt.startsWith(stored.trim())
                                        );
                                        return matched || stored.trim();
                                      });

                                      return mapped;
                                    }

                                    if (
                                      column.db_column_name === "multi_service_id" ||
                                      column.db_column_name === "multi_provider_accounts" ||
                                      column.db_column_name === "multi_options"
                                    ) {
                                      return values.map((item: string) => item.trim());
                                    }

                                    return values.length > 0
                                      ? values.map((item: string) => item.trim())
                                      : [];
                                  }
                                })()}

                                onChange={(value) => {
                                  const isMultiSelect =
                                    column.db_column_name === "multi_service_id" ||
                                    column.db_column_name === "multi_provider_accounts" ||
                                    column.db_column_name === "multi_options" ||
                                    column.db_column_name === "display_name";

                                  if (Array.isArray(value)) {
                                    if (isMultiSelect) {
                                      handleSelectChange(column.db_column_name, value);
                                    } else {
                                      handleSelectChange(column.db_column_name, value.length === 0 ? null : value);
                                    }
                                  } else if (value === undefined || value === null) {
                                    handleSelectChange(column.db_column_name, null);
                                  }
                                }}

                                onDropdownVisibleChange={(open) => {
                                  if (!open) {
                                    setSearchValue("");
                                  }
                                }}

                                options={
                                  generalFields && generalFields.dropdown[column.db_column_name]
                                    ? column.db_column_name === "product_type" && typeof generalFields.dropdown[column.db_column_name] === "object"
                                      ? Object.keys(generalFields.dropdown[column.db_column_name]).map((key) => ({
                                        label: key,
                                        value: key,
                                      }))
                                      : Array.isArray(generalFields.dropdown[column.db_column_name])
                                        ? generalFields.dropdown[column.db_column_name].map((option: string) => ({
                                          label: option,
                                          value: option,
                                        }))
                                        : []
                                    : []
                                }

                                maxTagCount={1}
                                maxTagPlaceholder={(omittedValues: any) => `+${omittedValues.length}`}

                                tagRender={(props: any) => {
                                  const { label, closable, onClose } = props;
                                  const labelString = String(label);
                                  const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;
                                  let allSelectedLabels = "";
                                  const fieldValue = formData[column.db_column_name];

                                  if (Array.isArray(fieldValue)) {
                                    const fieldOptions =
                                      column.db_column_name === "product_type" && typeof generalFields.dropdown[column.db_column_name] === "object"
                                        ? Object.keys(generalFields.dropdown[column.db_column_name]).map((key) => ({
                                          label: key,
                                          value: key,
                                        }))
                                        : Array.isArray(generalFields.dropdown[column.db_column_name])
                                          ? generalFields.dropdown[column.db_column_name].map((option: string) => ({
                                            label: option,
                                            value: option,
                                          }))
                                          : [];
                                    allSelectedLabels = fieldValue
                                      .map((value: any) => {
                                        const option = fieldOptions.find((opt: any) => opt.value === value);
                                        return option?.label || value;
                                      })
                                      .join(", ");
                                  } else if (fieldValue) {
                                    allSelectedLabels = labelString;
                                  }

                                  return (
                                    <span
                                      className="inline-flex items-center px-1 py-1 bg-white shadow-lg rounded-lg archive-summary-warning"
                                      title={allSelectedLabels}
                                      style={{
                                        maxWidth: "165px",
                                        color: "black",
                                        overflow: "hidden",
                                        whiteSpace: "nowrap",
                                      }}
                                    >
                                      <span
                                        style={{
                                          textOverflow: "ellipsis",
                                          overflow: "hidden",
                                          whiteSpace: "nowrap",
                                          display: "inline-block",
                                          flexShrink: 1,
                                          minWidth: 0,
                                        }}
                                      >
                                        {truncatedLabel}
                                      </span>

                                      {closable && (
                                        <CloseOutlined
                                          onClick={onClose}
                                          style={{
                                            marginLeft: 6,
                                            cursor: "pointer",
                                            color: "black",
                                            flexShrink: 0,
                                          }}
                                        />
                                      )}
                                    </span>

                                  );
                                }}

                                dropdownRender={(menu) => {
                                  // Prepare original data
                                  const optionsData =
                                    generalFields && generalFields.dropdown[column.db_column_name]
                                      ? column.db_column_name === "product_type" &&
                                        typeof generalFields.dropdown[column.db_column_name] === "object"
                                        ? Object.keys(generalFields.dropdown[column.db_column_name]).map(
                                          (key) => ({
                                            label: key,
                                            value: key,
                                          })
                                        )
                                        : Array.isArray(generalFields.dropdown[column.db_column_name])
                                          ? generalFields.dropdown[column.db_column_name].map(
                                            (option: string) => ({
                                              label: option,
                                              value: option,
                                            })
                                          )
                                          : []
                                      : [];

                                  // Filter by search term
                                  const filteredData = optionsData.filter((item: { label: string; }) =>
                                    item.label.toLowerCase().includes(searchValue.toLowerCase())
                                  );

                                  return (
                                    <div className="relative bg-white shadow-lg rounded-lg max-w-full dark-theme-select">
                                      {/* Search input */}
                                      <div className="sticky top-0 bg-white z-10 p-2">
                                        <input
                                          type="text"
                                          placeholder="Search..."
                                          value={searchValue}
                                          onChange={(e) => {
                                            e.stopPropagation();
                                            setSearchValue(e.target.value);
                                          }}
                                          onKeyDown={(e) => {
                                            e.stopPropagation();
                                          }}
                                          onClick={(e) => {
                                            e.stopPropagation();
                                          }}
                                          className="w-full px-2 py-1 text-sm border rounded"
                                        />
                                      </div>

                                      <VirtualList
                                        data={filteredData}
                                        height={250}
                                        itemHeight={0}
                                        itemKey="value"
                                      >
                                        {(item) => {
                                          const fieldValue = formData[column.db_column_name];

                                          // ✅ FIXED: Enhanced matching logic
                                          const isChecked = (() => {
                                            if (!fieldValue) return false;

                                            const values = Array.isArray(fieldValue)
                                              ? fieldValue
                                              : [fieldValue];

                                            // Check exact match first
                                            if (values.includes(item.value)) return true;

                                            // For display_name field, check if any stored value matches by comparing prefixes
                                            if (column.db_column_name === "display_name") {
                                              return values.some((storedValue: string) => {
                                                const stored = String(storedValue).trim();
                                                const option = String(item.value).trim();

                                                // Extract base name before " -- "
                                                const getBaseName = (str: string) => {
                                                  const parts = str.split(' -- ');
                                                  return parts[0].trim();
                                                };

                                                const storedBase = getBaseName(stored);
                                                const optionBase = getBaseName(option);

                                                // Match if base names are the same
                                                return storedBase === optionBase;
                                              });
                                            }

                                            return false;
                                          })();

                                          return (
                                            <div
                                              key={item.value}
                                              className="ml-2 mb-2 flex items-center"
                                            >
                                              <Checkbox
                                                checked={isChecked}
                                                onChange={(e) => {
                                                  e.stopPropagation();
                                                  const currentValues = Array.isArray(fieldValue)
                                                    ? fieldValue
                                                    : fieldValue
                                                      ? [fieldValue]
                                                      : [];

                                                  let newValues: any[];

                                                  if (e.target.checked) {
                                                    // ✅ When checking, add the display option value
                                                    newValues = [...currentValues, item.value];
                                                  } else {
                                                    // ✅ FIXED: When unchecking, remove matching values
                                                    if (column.db_column_name === "display_name") {
                                                      const getBaseName = (str: string) => {
                                                        const parts = String(str).split(' -- ');
                                                        return parts[0].trim();
                                                      };

                                                      const optionBase = getBaseName(item.value);

                                                      newValues = currentValues.filter((v: string) => {
                                                        const storedBase = getBaseName(String(v));
                                                        return storedBase !== optionBase;
                                                      });
                                                    } else {
                                                      newValues = currentValues.filter((v) => v !== item.value);
                                                    }
                                                  }

                                                  handleSelectChange(column.db_column_name, newValues);
                                                }}
                                                className="mr-2"
                                              />
                                              {item.label}
                                            </div>
                                          );
                                        }}
                                      </VirtualList>
                                    </div>
                                  );
                                }}
                              />
                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500 mt-2">{validationErrors[column.db_column_name]}</span>
                              )}
                            </>
                          )}
                          {column.type === "editable_dropdown" && (
                            <>
                              <Select
                                isMulti={column.db_column_name === "multi_service_id" || column.db_column_name === "multi_provider_accounts" || column.db_column_name === "multi_options"}
                                isClearable
                                styles={{ ...DropdownStyles, menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
                                menuPortalTarget={document.body}
                                menuPlacement="auto"
                                menuPosition="fixed"
                                placeholder="Select..."
                                value={(() => {
                                  let selectedValues = formData[column.db_column_name] || [];
                                  if (Array.isArray(selectedValues)) {
                                    return selectedValues.map((item) => ({ label: item, value: item }));
                                  } else {
                                    return [{ label: selectedValues, value: selectedValues }];
                                  }
                                })()}
                                onChange={(values) => {
                                  const isMultiSelect =
                                    column.db_column_name === "multi_service_id" ||
                                    column.db_column_name === "multi_provider_accounts" ||
                                    column.db_column_name === "multi_options";
                                  if (values === null) {
                                    handleSelectChange(column.db_column_name, null);
                                  } else if (isMultiSelect && Array.isArray(values)) {
                                    const updatedValues = values.map((option) => option.value);
                                    handleSelectChange(column.db_column_name, updatedValues);
                                  } else if (!isMultiSelect && values && "value" in values) {
                                    handleSelectChange(column.db_column_name, values.value);
                                  }
                                }}
                                options={
                                  Array.isArray(generalFields.dropdown[column.db_column_name])
                                    ? generalFields.dropdown[column.db_column_name].map((option: any) => ({
                                        label: option,
                                        value: option,
                                      }))
                                    : []
                                }
                              />
                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500 mt-2">{validationErrors[column.db_column_name]}</span>
                              )}
                            </>
                          )}
                          {column.type === "month" && (
                            <>
                              <Input
                                type="number"
                                value={formData[column.db_column_name] || ""}
                                onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                                placeholder="Enter months"
                                className="input"
                              />
                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500">{validationErrors[column.db_column_name]}</span>
                              )}
                            </>
                          )}
                          {error && <div style={{ color: "red", marginTop: "10px" }}>{error}</div>}
                          {column.type === "checkbox" && (
                            <>
                              <Checkbox
                                checked={formData[column.db_column_name] && formData[column.db_column_name] !== "None" ? formData[column.db_column_name] : false}
                                onChange={(e) => handleChange(column.db_column_name, e.target.checked)}
                                className={`checkbox ${((heading === "Product") && column.db_column_name === "is_active")||((heading === "Product") && column.db_column_name === "is_surcharge")
                                  ? "mt-6"
                                  : ""
                                }`}
                                disabled={
                                  heading === "Product" &&
                                  column.db_column_name === "prorate" &&
                                  formData["product_type_code"]?.toLowerCase().startsWith("onetime")
                                }
                                >
                                {column.display_name}
                              </Checkbox>
                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500">{validationErrors[column.db_column_name]}</span>
                              )}
                            </>
                          )}
                          {column.type === "date" && (
                            <>
                              <DatePicker
                                value={formData[column.db_column_name] && dayjs(formData[column.db_column_name]).isValid() ? dayjs(formData[column.db_column_name]) : null}
                                onChange={(date) => handleChange(column.db_column_name, date ? date.format("YYYY-MM-DD") : null)}
                                className="input min-h-[40px]"
                                disabledDate={(current) =>
                                  (column.db_column_name === "inactivity_start" && current && current < dayjs().startOf("day")) ||
                                  (column.db_column_name === "inactivity_end" && current && current < dayjs().startOf("day"))
                                }
                                format="MM-DD-YY"
                                placeholder="Select a date"
                                disabled={!isEditable}
                              />
                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500">{validationErrors[column.db_column_name]}</span>
                              )}
                            </>
                          )}
                          {column.type === "textarea" && (
                            <textarea
                              value={formData[column.db_column_name] || ""}
                              onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                              className="input min-h-[80px] mt-1 w-full"
                              disabled={!isEditable}
                            />
                          )}
                          {column.type === "boolean" && (
                            <>
                              <div className="flex items-center">
                                <span className="mr-2 w-12">{formData[column.db_column_name] === "True" ? "Active" : "Inactive"}</span>
                                <Switch
                                  onChange={() => handleChange(column.db_column_name, formData[column.db_column_name] === "True" ? "False" : "True")}
                                  checked={formData[column.db_column_name] === "True"}
                                  className="custom-switch"
                                />
                              </div>
                              {validationErrors[column.db_column_name] && (
                                <span className="text-red-500">{validationErrors[column.db_column_name]}</span>
                              )}
                            </>
                          )}
                        </div>
                      ))}
                    </div>

                    {showBuiltinFields && (
                      <div className="mt-6">
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="popup-heading !pl-0">Built-in Fields</h3>
                          <button
                            onClick={handleCloseBuiltinFields}
                            className="text-red-500 hover:text-red-700 p-1"
                            title="Close Built-in Fields"
                          >
                            <X size={20} />
                          </button>
                        </div>
                        <div className="mb-4">
                          <AntdSelect
                            mode="multiple"
                            className="w-full sm:w-1/2 md:w-1/3"
                            allowClear
                            showArrow
                            showSearch
                            placeholder="Select fields"
                            value={[]}
                            open={dropdownOpen}
                            onDropdownVisibleChange={(open) => {
                              setDropdownOpen(open);
                              if (!open) setSearchTerm('');
                            }}
                            options={builtinFields
                              .filter(field => !selectedFields.some(selected => selected.db_column_name === field.db_column_name))
                              .map(field => ({
                                label: field.display_name,
                                value: field.db_column_name,
                                type: field.type,
                                disabled: field.db_column_name.toLowerCase() === selectedPrimaryField?.toLowerCase(), // Case-insensitive comparison
                              }))}
                            getPopupContainer={(triggerNode) => triggerNode.parentNode}
                            dropdownRender={(menu) => (
                              <div
                                className="relative bg-white shadow-lg rounded-lg max-w-full dark-theme-select"
                                style={{ zIndex: 10000 }}
                              >
                                <div className="p-2 border-b">
                                  <Input
                                    placeholder="Search..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full"
                                  />
                                </div>
                                <VirtualList
                                  data={builtinFields.filter(field => 
                                    !selectedFields.some(selected => selected.db_column_name === field.db_column_name) &&
                                    field.display_name.toLowerCase().includes(searchTerm.toLowerCase())
                                  )}
                                  height={250}
                                  itemHeight={0}
                                  itemKey="db_column_name"
                                >
                                  {(item) => {
                                    const isChecked = tempSelectedFields.includes(item.db_column_name);
                                      const isDisabled = item.db_column_name.toLowerCase() === selectedPrimaryField?.toLowerCase();
                                      // console.log(isDisabled,selectedPrimaryField, item.db_column_name,"is disabled....");
                                    return (
                                      <div key={item.db_column_name} className="ml-2 mb-2 flex items-center">
                                        <Checkbox
                                         disabled={isDisabled} // Disable checkbox if the option is disabled
                                          checked={isChecked}
                                          onChange={(e) => {
                                            if (e.target.checked) {
                                              setTempSelectedFields(prev => [...prev, item.db_column_name]);
                                            } else {
                                              setTempSelectedFields(prev => prev.filter(val => val !== item.db_column_name));
                                            }
                                          }}
                                          className="mr-2"
                                        />
                                        {item.display_name}
                                      </div>
                                    );
                                  }}
                                </VirtualList>
                                <div className="flex justify-between p-2 border-t">
                                  <button
                                    className="save-btn mr-2 !min-w-[70px]"
                                    onClick={handleOkFields}
                                  >
                                    OK
                                  </button>
                                  <button
                                    className="cancel-btn !min-w-[70px]"
                                    onClick={handleCancelFields}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            )}
                            onChange={(value) => setTempSelectedFields(value)}
                          />
                        </div>
                        {selectedFields.length > 0 && (
                          <div className="mt-4">
                            <h4 className="text-sm font-medium mb-2">Selected Fields</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                              {selectedFields.map((field, index) => (
                                  <div key={index} className="flex items-center justify-between p-2 rounded builtin-field">
                                  {editIndex === index ? (
                                    <div className="flex items-center space-x-2">
                                      <Input
                                        value={editValue}
                                        onChange={handleEditChange}
                                        className="input"
                                        placeholder="Edit field name"
                                      />
                                      <button
                                        className="text-green-500 hover:text-green-700"
                                        onClick={() => handleEditSave(index)}
                                      >
                                        Save
                                      </button>
                                      <button
                                        className="text-red-500 hover:text-red-700"
                                        onClick={() => setEditIndex(null)}
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  ) : (
                                    <>
                                      <span>{field.display_name}</span>
                                      <div className="flex space-x-2">
                                        <EditOutlined
                                          className="text-blue-500 cursor-pointer"
                                          onClick={() => handleEditField(index)}
                                        />
                                        <DeleteOutlined
                                          className="text-red-500 cursor-pointer"
                                          onClick={() => handleDeleteField(index)}
                                        />
                                      </div>
                                    </>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                     {customIdentifier && (
                      <div className="mt-6">
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="popup-heading !pl-0">Custom Identifier <span className="text-red-500">*</span></h3>
                        </div>
                        <div className="mb-4 flex items-center space-x-2">
                          <Input
                            type="text"
                            value={customIdentifier}
                            onChange={handleCustomFieldChange}
                            placeholder="Enter field name"
                            className="non-editable-input !w-[300px] !text-black"
                          />
                          
                        </div>
                        {customFieldError && (
                          <div className="text-red-500 text-sm mb-2">{customFieldError}</div>
                        )}
                       
                      </div>
                    )}
                    {showCustomFields && (
                      <div className="mt-6">
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="popup-heading !pl-0">Custom Fields</h3>
                          <button
                            onClick={handleCloseCustomFields}
                            className="text-red-500 hover:text-red-700 p-1"
                            title="Close Custom Fields"
                          >
                            <X size={20} />
                          </button>
                        </div>
                        <div className="mb-4 flex items-center space-x-2">
                          <Input
                            type="text"
                            value={newFieldDisplayName}
                            onChange={handleCustomFieldChange}
                            placeholder="Enter field name"
                            className="input !w-[300px]"
                          />
                          <PlusCircleIcon
                            onClick={handleAddCustomField}
                            className="w-6 h-6 text-green-500 cursor-pointer"
                          />
                        </div>
                        {customFieldError && (
                          <div className="text-red-500 text-sm mb-2">{customFieldError}</div>
                        )}
                        {customFields.length > 0 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                            {customFields.map((field, index) => (
                              <div key={index} className="flex items-center justify-between p-2 rounded builtin-field">
                                <span>{field}</span>
                                <MinusCircleIcon
                                  className="w-6 h-6 text-red-500 cursor-pointer"
                                  onClick={() => handleDeleteCustomField(index)}
                                />
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </form>
                </div>
              )}
            </Modal>
          )}
          <Modal
            visible={isConfirmationOpen}
            onOk={handleConfirmSave}
            onCancel={handleCancelConfirmation}
            title="Confirmation"
            footer={
              <div className="justify-center flex space-x-2 mt-2">
                <button onClick={handleCancelConfirmation} className="cancel-btn">Cancel</button>
                <button onClick={handleConfirmSave} className="save-btn">Ok</button>
              </div>
            }
            centered
          >
            <p>Are you sure you want to {action} the changes?</p>
          </Modal>
        </>
      )}
    </div>
  );
};

export default EditModal;