import React from 'react';
import Select from 'react-select'; 
import { DropdownStyles, NonEditableDropdownStyles } from '@/app/components/css/dropdown';

const Dropdown = ({ options, value, onChange, placeholder,mandatory,disabled }:any) => {
  return (
    <div className="flex flex-col">
    <label className="field-label">{placeholder}{mandatory && <span className="text-red-500 ml-1">*</span>}</label>
    <Select
      options={options}
      value={value}
      onChange={onChange}
      placeholder={"Select"}
      // styles={{
      //   ...DropdownStyles,
      //   menuPortal: (base) => ({ ...base, zIndex: 9999 }), // Ensure dropdown is on top
      // }}  
      // className="w-full"
      styles={{
        ...(disabled ? NonEditableDropdownStyles : DropdownStyles),
        menuPortal: (base) => ({ ...base, zIndex: 9999 }), // Ensure dropdown is on top
      }}
      className={`w-full ${disabled ? 'cursor-not-allowed' : ''}`} // Apply class if disabled
      isClearable
      isDisabled={disabled}
      menuPortalTarget={document.body} // Makes the dropdown appear on top of other components
    />
  </div>

  );
};

export default Dropdown;

// import React from 'react';
// import Select from 'react-select'; 
// import { DropdownStyles } from '@/app/components/css/dropdown';

// const Dropdown = ({ options, value, onChange, placeholder, mandatory, disabled }: any) => {
//   return (
//     <div className="flex flex-col">
//       <label className="field-label">
//         {placeholder}
//         {mandatory && <span className="text-red-500 ml-1">*</span>}
//       </label>
//       <Select
//         options={options}
//         value={value}
//         onChange={onChange}
//         placeholder={"Select"}
//         styles={{
//           ...DropdownStyles,
//           menuPortal: (base) => ({ ...base, zIndex: 9999 }), // Ensure dropdown is on top
//           control: (provided, state) => ({
//             ...provided,
//             minWidth: '100px',
//             borderRadius: '8px',
//             display: 'flex',
//             padding: '4px 4px',
//             paddingRight: '8px',
//             minHeight: '46px',
//             alignItems: 'center',
//             justifyContent: 'center',
//             fontSize: '16px',
//             backgroundColor: state.isDisabled ? '#d1d5db' : provided.backgroundColor, // Background color for disabled
//             color: state.isDisabled ? 'white' : provided.color, // Text color for disabled
//             cursor: state.isDisabled ? 'not-allowed' : 'pointer', // Cursor style for disabled
//             opacity: state.isDisabled ? 0.5 : 1, // Change opacity when disabled
//           }),
//         }}  
//         className="w-full " // Apply classes if disabled
//         classNamePrefix="custom-select" // Set a prefix for styling
//         isClearable
//         isDisabled={disabled}
//         menuPortalTarget={document.body} // Makes the dropdown appear on top of other components
//       />
//     </div>
//   );
// };

// export default Dropdown;