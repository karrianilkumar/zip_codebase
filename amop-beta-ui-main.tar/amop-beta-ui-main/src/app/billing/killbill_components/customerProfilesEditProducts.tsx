import React, { useCallback, useEffect, useState,useRef } from "react";
import { Checkbox, Input, Modal, notification, Popover, Spin, Switch, DatePicker, Select } from 'antd'; // Import DatePicker
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";
import { PlusOutlined } from "@ant-design/icons";
import dayjs, { Dayjs } from 'dayjs'; // Import dayjs
import Dropdown from "./dropdownComponent";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import EditableTableComponent from "./editable_table_component";
import { CloseOutlined } from "@ant-design/icons";
import VirtualList from 'rc-virtual-list';
import { fireSideCannons } from "@/app/components/confetti";


interface EditeProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: any;
  modalData: {
    id: number;
    display_name: string;
    type: string;
    mandatory: boolean;
    db_column_name: string;
  }[];
  title: string;
//   visible: boolean;
  action: string;
  rowData?: any;
  generalFields?: any;
  dropdownValues?:any;
  accountNumber?:any;
}
type FormData = {
  create:any|null;
  service_type: any | null;
  provider: any | null;
  contract_term: [Dayjs | null, Dayjs | null];
  terms: any | null;
  effective_date: any | null;
  accounts: string;
  services: any | null;
  dest_customer: any|null;
  products: string[];
};

const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};
const CustomerProfilesEditModal: React.FC<EditeProductModalProps> = ({
  isOpen,
  onClose,
  onSave,
  modalData,
  title,
  rowData,
  generalFields,
  dropdownValues,
  accountNumber,
}) => {
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const { username, partner, role, settabledata, token, selectedDb,metaData,selectedBillingDb, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [newServiceFields, setNewServiceFields] = useState(false);
  const [productsFields, setProductsFields] = useState(false);
  const [transferServicesFields, setTransferServicesFields] = useState(false);
  const options = [
    { value: "products", label: "Products" },
  ];
  const [selectedOption, setSelectedOption] = useState(options[0]);

  const [formData, setFormData] = useState<FormData>({
    create: null,
    service_type: null,
    provider: "", // Only store the value (empty string initially)
    contract_term: [null, null],
    terms: null,
    effective_date: null,
    accounts: "",
    services: null,
    dest_customer: null,
    products: [],
  });
  const [validationErrors, setValidationErrors] = useState<{ service_type: string }>({
    service_type: '', // initially empty or no error
  });
  const [errors, setErrors] = useState({
    service_type: '',

  });
  const [tableData, setTableData] = useState<any>([]);
  type HeaderMap = Record<string, [string, number]>;
 
    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
      const entries = Object.entries(headerMap) as [string, [string, number]][];
      entries.sort((a, b) => a[1][1] - b[1][1]);
      return Object.fromEntries(entries) as HeaderMap;
    }, []);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [headers, setHeaders] = useState<any[]>([]);
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const [UpdatedTableData, setUpdatedTableData] = useState<string[]>([]);
    const [features, setFeatures] = useState<string[]>([]);
    const hasFetchedData = useRef(false);
    const {
        features: moduleFeatures,
        setFeatures: setModuleFeatures, 
      } = useFeatureStore();
    const [pagination, setPagination] = useState<any>({});
    const [searchTerm, setSearchTerm] = useState("");
    const [filteredData, setFilteredData] = useState([]);
    const convertStringToArray = (str:any) => {
        // Remove the brackets and split by comma, then trim whitespace
        return str.replace(/[\[\]']/g, '').split(',').map((item:any) => item.trim());
      };
      
    const [selectedValues, setSelectedValues] = useState(formData.products || []);
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    
    useEffect(() => {
        if (isOpen && rowData) {
          console.log("Hello")
          try {
            // Set initial form data based on rowData
            setFormData({
              create: selectedOption, // Assuming selectedOption is defined elsewhere
              service_type: { label: rowData.service_type, value: rowData.service_type }, // Assuming rowData.service_type is a string
              provider: null,
              contract_term: [null, null],
              terms: null,
              effective_date: null,
              accounts: '',
              services: null,
              dest_customer: null,
              products: convertStringToArray(rowData.product_type || ''), // Convert product_type string to array
            });
             // Clean and prepare the products data
             console.log("hiii",rowData?.products);
             fetchData();
             let products = rowData.products;
              // Check if products is an array
              if (Array.isArray(products)) {
                  setTableData(products);
                  // setShowProductDetails(products);
                
              }
            
          } catch (error) {
            console.error("Error parsing rowData:", error);
            // Handle error (e.g., show a notification or set an error state)
          }
        }
    }, [isOpen, rowData, selectedOption]); // Ensure selectedOption is included if it affects the state 

    const fetchData = async () => {
      let parsedData: any;
      const payload = {
        service_type: formData?.service_type?.value || null, // Use state value
        product_type: formData?.products|| []
      };
      try {
        setLoading(true);
        const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/customer_service_products_pop_list_view",
          role_name: role,
          parent_module: "Billing Platform",
          module_name: "Product Packages",
          mod_pages: {
            start: 0,
            end: 100,
          },
          changed_data: payload,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          billing_db_name: selectedBillingDb,
          ...metaData,
          tenant_id: tenant_id_,
          sessionID: sessionId,
          feature_module_name: "Product Packages",
          main_module_name: "Customer Profiles",
        };
        
        const response = await axios.post(url, { data });
      console.log("API Response:", response.data);
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        // Log data and set loading to false immediately to stop the loader
        setLoading(false);
        console.log("table response:", getCurrentDateTime());
        //  setLoading(false); // Ensure this happens right away

        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Product Packages"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          console.log("parsedData", parsedData)
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Product Packages"]?.module_features || []
          const createModalData_ = parsedData?.header_map?.["Product Packages"]?.pop_up || []
          console.log("createModalData_", createModalData_)
          setProductsFields(createModalData_)

          const allowedActions_: any = []
          if (featres_.includes("Edit-Billing Product Types")) {
            allowedActions_.push("edit")
          }
          setPagination(parsedData?.pages || {});   
        }, 0);  
      } else {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      //  setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }

  };

    const fetchProductsTableData = async () => {
        let parsedData: any;
        const payload = {
          service_type: formData?.service_type?.value || null, // Use state value
          product_type: formData?.products|| []
        };
        try {
          setLoading(true);
          const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/customer_service_products_pop_list_view",
            role_name: role,
            parent_module: "Billing Platform",
            module_name: "Product Packages",
            mod_pages: {
              start: 0,
              end: 100,
            },
            changed_data: payload,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            billing_db_name: selectedBillingDb,
            ...metaData,
            tenant_id: tenant_id_,
            sessionID: sessionId,
            feature_module_name: "Product Packages",
          main_module_name: "Customer Profiles",
          };
          const response = await axios.post(url, { data });
          console.log("API Response:", response.data);
          parsedData = JSON.parse(response.data.body);
      
          if (parsedData.flag === true) {
            // Log data and set loading to false immediately to stop the loader
            setLoading(false);
            console.log("table response:", getCurrentDateTime());
            //  setLoading(false); // Ensure this happens right away
      
            // Defer other state updates using a timeout to decouple them from the main thread
            setTimeout(() => {
              const newTableData = parsedData?.data?.product_packages || [];
              setTableData((prevTableData:any) => {
                console.log("🔄 Previous Table Data:", prevTableData);
                console.log("🆕 New Table Data:", newTableData);
              
                const existingIds = new Set(prevTableData.map((item:any) => item.id)); // Extract old table IDs
                const newIds = new Set(newTableData.map((item:any) => item.id)); // Extract new table IDs
              
                console.log("📌 Existing IDs in prevTableData:", existingIds);
                console.log("📌 Incoming New IDs in newTableData:", newIds);
              
                // 🔹 Find rows that are new (IDs not in old table)
                const filteredNewData = newTableData.filter((item:any) => !existingIds.has(item.id));
                console.log("🆕 Filtered New Data (IDs that are NOT in old table):", filteredNewData);
              
                // 🔹 Keep only the rows that still exist in newTableData (removing missing ones)
                const updatedOldData = prevTableData.filter((item:any) => newIds.has(item.id));
                console.log("✅ Updated Old Data (Rows that exist in both tables):", updatedOldData);
              
                // 🔹 If `filteredNewData` is empty, just return `updatedOldData`
                const finalTableData = filteredNewData.length > 0 ? [...updatedOldData, ...filteredNewData] : updatedOldData;
              
                console.log("📊 Final Table Data:", finalTableData);
                return finalTableData;
              });
              
              const headersMap_ = parsedData?.header_map?.["Product Packages"]?.header_map || {};
              const sortedheaderMap = sortHeaderMap(headersMap_);
              setHeaderMap(sortedheaderMap);
              console.log("parsedData", parsedData)
              // setgeneralFields2(parsedData || {})
              const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
              console.log("headers", headers_)
              setHeaders(headers_);
              setVisibleColumns(headers_);
              setFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
              setModuleFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
              const featres_ = parsedData?.header_map?.["Product Packages"]?.module_features || []
              const createModalData_ = parsedData?.header_map?.["Product Packages"]?.pop_up || []
              console.log("createModalData_", createModalData_)
              setProductsFields(createModalData_)
              setPagination(parsedData?.pages || {}); 
            }, 0);
           
          } else {
            //  setIsLoading(false);
            Modal.error({
              title: "Data Fetch Error",
              content: parsedData.message || "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          }
        } catch (error) {
          //  setLoading(false);
          Modal.error({
            title: "Data Fetch Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          setLoading(false);
        }    
    
      };
     
    const SubmitData = async (formData: any,) => {
    setLoading2(true);
    try {
      const cleanedData = Object.keys(formData).reduce((acc: any, key) => {
        const value = formData[key];
        if (key === 'create' && (value === "newService" || value === "transferService")) {
          acc[key] = value;
          
        } else if (key === 'products') {
          if (acc.create !== "newService" && acc.create !== "transferService") {
            acc[key] = Array.isArray(value) ? value : [];
            acc['updatedTableData'] = UpdatedTableData && UpdatedTableData.length ? UpdatedTableData : tableData;
          }
        } else if (
          value !== null &&
          value !== undefined &&
          value !== "" &&
          !(Array.isArray(value) && value.every((item) => item === null || item === "")) // Ignore empty/falsy arrays
        ) {
          if (typeof value === "object" && value?.label) {
            acc[key] = value.value; // Extract value from { label, value } objects
          } else {
            acc[key] = value; // Otherwise, store as-is
          }
        }
        return acc;
      }, {});    
      // Add row_id to cleanedData
      cleanedData.row_id = rowData.id; // Assuming rowData is passed correctly
 
      let data;
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_customer_service",
        role_name: role,
        module_name: "Customer Profile Services",
        feature_module_name: "Billing Platform",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        billing_db_name: selectedBillingDb,
        ...metaData,
        // table_name: "sim_management_inventory",
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        tenant_id: tenant_id_,
        action: "update",
        modified_by: firstLastName,
        changed_data: cleanedData , // Spread the collected data here
        account_number: accountNumber,
        modified_date:getCurrentDateTime(),
          main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200 && resp.flag === true) {
        if (response && response.data.statusCode === 200) {
        
          let parsedData: any;
          try {
            setLoading(true);
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

             const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/customer_services_list_view",
                    role_name: role,
                    account_number: accountNumber,
                    parent_module: "Billing Platform",
                    module_name: "Customer Services",
                    table_name: "customer_services",
                    // sub_module:"Services",
                    mod_pages: {
                      start: 0,
                      end: 100,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    tenant_id:tenant_id_,
                    db_name: selectedDb,
                    billing_db_name: selectedBillingDb,
                    ...metaData,
                    sessionID: sessionId,
                    feature_module_name: "Customer Services",
                    main_module_name: "Customer Profiles",
                  };
  
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);
  
            if (parsedData.flag === true) {
              settabledata(parsedData?.data?.customer_services || []);
            };
            notification.success({
              message: 'Success',
              description: 'Successfully updated the record!',
              style: {
                fontSize: '14px',
                fontWeight: 'bold',
                padding: '16px',
              },
              placement: 'top',
            });
            fireSideCannons()
            handleCancel()
            onClose();
          }
          catch { }
          finally { setLoading(false) }

        } else {
          const errorMsg = JSON.parse(response.data.body);
          Modal.error({
            title: "Saving Error",
            content: errorMsg,
            centered: true,
          });
       setIsConfirmationOpen(false)

        }
      } else {
        const errorMsg = JSON.parse(response.data.body).message;
        Modal.error({
          title: "Saving Error",
          content: errorMsg,
          centered: true,
        });
       setIsConfirmationOpen(false)

      }
    } catch (error) {
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        onOk: onClose
      });
    } finally {
      setLoading2(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const isValid = validateForm(); // Validate the form
    if (isValid) {
      setIsConfirmationOpen(true); // If form is valid, show confirmation modal
    }
  };
    // Update formData when selectedValue changes
   
  const handleCancel = () => {
    setIsConfirmationOpen(false);
    setFormData({
      create: null,
      service_type: null,
      provider: null,
      contract_term: [null, null],
      terms: null,
      effective_date: null,
      accounts: '',
      services: null,
      dest_customer: null,
      products: [],
    });    
    onClose();
    setHeaderMap({});
    setTableData([]);
    setHeaders([]);
    setNewServiceFields(false);
    setProductsFields(false);
    setTransferServicesFields(false);
  };


  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const modalWidth = typeof window !== "undefined"
  ? window.innerWidth <= 768
    ? (window.innerWidth * 3.5) / 4
    : (window.innerWidth * 2.5) / 4
  : 0;  
  const modalHeight =
    typeof window !== 'undefined' ? (window.innerHeight * 2.7) / 4 : 0;
    
  // if (!isOpen) return null;
  

  const handleConfirmCreate = async () => {
    // Call SubmitData when the user confirms in the modal
    await SubmitData(formData);
  };


  const validateForm = () => {
    let isValid = true;
    let newValidationErrors = { ...validationErrors }; // Copy existing errors to a new object

    // Validate serviceType (mandatory field)
    if (!formData.service_type) {
      newValidationErrors.service_type = 'Service Type is required.';
      isValid = false;
    }

    setErrors(newValidationErrors); // Update state with the new validation errors
    return isValid;
  };

  const handleChange = (key: any, selected: any) => {
    setSelectedValues(selected);
    setFormData({
      create: selected,
      service_type: null,
      provider: null,
      contract_term: [null, null],
      terms: null,
      effective_date: null,
      accounts: '',
      services: null,
      dest_customer: null,
      products: selected || [], // Update products with selected values
    });

    if (selected?.label === 'Products') {
      setProductsFields(true);
    } else {
      setProductsFields(false);
    }
  };

  const handleInputChange = (key: any) => (e: any) => {
    setFormData({ ...formData, [key]: e.target.value });
  };

  // Modified handleSelectChange to handle arrays
  const handleSelectChange = (key: keyof FormData) => (selectedValues: any) => {
    if (key === 'products') {
      setFormData(prev => ({
        ...prev,
        [key]: selectedValues.map((val: any) => String(val)), // Ensure values are strings
      }));
    } else {
      // Handle other single-selection dropdowns as before
      setFormData(prev => ({
        ...prev,
        [key]: selectedValues
      }));
    }
  }; 
  const serviceTypeOptions = dropdownValues?.service_type
  ? Object.keys(dropdownValues.service_type).map((key) => ({
      label: key, // Assigning the key (e.g., "AVPN") as the label
      value: key, // Assigning the key as the value
    }))
  : [];

  const selectedServiceType = formData?.service_type?.value || null;
  const productOptions = selectedServiceType && dropdownValues?.service_type?.[selectedServiceType]
  ? dropdownValues.service_type[selectedServiceType].map((item: string) => ({
      label: item,
      value: item,
    }))
  : Array.isArray(dropdownValues?.product)
  ? dropdownValues.product.map((item: string) => ({
      label: item,
      value: item,
    }))
  : [];

  const handleFilterLoad = (event:any) => {
    event.preventDefault()
    fetchProductsTableData();
  };

// Modified ProductsMultiSelect component with checkboxes
const ProductsMultiSelect = () => (
  <Select
    mode="multiple"
    allowClear
    showArrow
    showSearch
    style={{ width: "100%" }}
    value={Array.isArray(formData.products) ? formData.products : []}
    options={productOptions.map((item:any) => ({
      label: String(item.label ?? ""),
      value: String(item.value ?? ""),
    }))}
    onChange={(selectedValues) => handleSelectChange('products')(selectedValues)}
    optionLabelProp="label"
    maxTagCount={1}
    maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
    tagRender={(props) => {
      const { label, closable, onClose } = props;
      const labelString = String(label);
      const truncatedLabel = labelString.length > 190 
        ? `${labelString.slice(0, 187)}...` 
        : labelString;

      // Combine all selected labels for the tooltip
      const allSelectedLabels = Array.isArray(formData.products)
        ? formData.products.map((value: any) => {
          const option = productOptions.find((opt:any) => opt.value === value);
          return option?.label;
        }).join(", ")
        : '';

      return (
        <span
          className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap relative bg-white shadow-lg rounded-lg max-w-[185px]"
          title={allSelectedLabels}
          style={{ 
            maxWidth: '165px',
            wordWrap: 'break-word',
            overflow: 'hidden',
          }}
        >
          {truncatedLabel}
          {closable && (
            <CloseOutlined
              onClick={onClose}
              style={{ marginLeft: 4, cursor: 'pointer', color: 'black' }}
            />
          )}
        </span>
      );
    }}
    dropdownRender={(menu) => (
      <div
        className="relative bg-white shadow-lg rounded-lg max-w-full"
        style={{ maxHeight: "250px", overflowY: "auto" }}
      >
        <VirtualList
          data={productOptions}
          height={250}
          itemHeight={32}
          itemKey="value"
        >
          {(item) => (
            <div key={item.value} className="ml-2 mb-2 flex items-center">
              <Checkbox
                checked={formData.products.includes(item.value)}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    products: e.target.checked
                      ? [...prev.products, item.value]
                      : prev.products.filter((val: any) => val !== item.value),
                  }))
                }
              >
                {item.label}
              </Checkbox>
            </div>
          )}
        </VirtualList>
      </div>
    )}
  />
);

  if (loading2) {
    return (
      <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
        <div className='flex justify-center'>
          <Spin size="large" />
        </div>

      </div>

    );
  }
  console.log(dropdownValues?.service_type,"show the values")

  return (
    <div>
      <Modal
        open={isOpen}
        onCancel={handleCancel}
        title={
          <h3 className='popup-heading'>
            Edit Product
          </h3>
        }
        centered
        footer={
          <div className="justify-center flex space-x-2 mt-7">
            <button onClick={handleCancel} className="save-btn">
              Cancel
            </button>
            <button onClick={handleSave} className="save-btn">
              Save
            </button>
          </div>
        }
        width={modalData.length >= 5 ? modalWidth : "800px"}
        styles={{
          body: {
            height:modalHeight,
            padding: "4px",overflow: 'auto' 
          },
        }}// Set fixed height and hide overflow
      >
        <>
          <div className={`${modalData.length > 5 ? 'popup' : ''}`}>
            <form onSubmit={handleSave}>
              {loading ? (
                <div className="flex justify-center items-center w-full h-full absolute top-0 left-0">
                  <Spin size="large" />
                </div>
              ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="flex flex-col w-full">
                      <Dropdown
                        options={options}
                        value={formData.create}
                        onChange={(selected: any) => handleChange('create', selected)}
                        placeholder="Create"
                      />
                    </div>

                    {productsFields && (
                      <>
                        <div className="flex flex-col w-full">
                          <label className="field-label">Accounts</label>
                          <Input
                            type="text"
                            className="input w-full"
                            value={accountNumber}
                            disabled
                            onChange={handleInputChange('accounts')}
                            placeholder="Enter account value"
                          />
                        </div>

                        <div className="flex flex-col w-full">
                          <Dropdown
                            options={serviceTypeOptions}
                            value={formData.service_type}
                            onChange={handleSelectChange('service_type')}
                            placeholder="Service Type"
                            mandatory={true}
                          />
                          {errors.service_type && (
                            <span className="text-red-500 text-sm mt-1">{errors.service_type}</span>
                          )}
                        </div>

                        <div className="flex flex-col w-full">
                          <label className="field-label">Products</label>
                          <ProductsMultiSelect />
                        </div>

                        <div className="flex items-end w-full">
                          <button
                            className="save-btn w-full sm:w-auto mt-2"
                            type="button"
                            onClick={handleFilterLoad}
                          >
                            Filter
                          </button>
                        </div>

                        <div className="col-span-1 sm:col-span-2 lg:col-span-3 overflow-x-auto w-full">
                          <EditableTableComponent
                            headers={headers}
                            headerMap={headerMap}
                            initialData={tableData}
                            searchQuery={searchTerm}
                            visibleColumns={visibleColumns}
                            itemsPerPage={100}
                            popupHeading="Customer Edit Service Packages"
                            pagination={pagination}
                            advancedFilters={filteredData}
                            height={350}
                            setUpdatedTableData={setUpdatedTableData}
                          />
                        </div>
                      </>
                    )}
                  </div>

              )}
            </form>
          </div>
        </>
      </Modal>
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        centered
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelConfirmation}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={handleConfirmCreate}
            >
              OK
            </button>
          </div>
        }
      >
        <p>Are you sure you want to Create this {title
          .split(" ")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ")}</p>
      </Modal>
    </div>
  );
};

export default CustomerProfilesEditModal;

