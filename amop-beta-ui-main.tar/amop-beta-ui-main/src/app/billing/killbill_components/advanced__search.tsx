import { Modal, Select, Checkbox, Spin, InputNumber, Input } from "antd";
import { CloseOutlined } from "@ant-design/icons";
import React, { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import VirtualList from "rc-virtual-list";
import { ArrowPathIcon, CheckIcon, ChevronDownIcon, ChevronUpIcon, FunnelIcon } from "@heroicons/react/24/outline";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useSearchStore } from "@/app/stores/searchStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import { useKillBillStore } from "../killbill_stores/activeStore";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import { Dayjs } from "dayjs";
import { useChargesModalDataStore } from "../killbill_stores/chargesModalData_store";

// Define numeric fields that require range selection
const NUMERIC_FIELDS = [
  'overage_rate_cost',
  'rate_charge_amt',
  'base_rate',
  'sms_rate',
  'total_charge_amount',
  'total_charges'
];

interface RangeValue {
  min?: number;
  max?: number;
  single?: number;
}

interface FilterShape {
  [key: string]: string[];
}

const splitAndFilter = (input?: string): string[] => {
  return input?.split("\n").filter(Boolean) || [];
};

interface AdvancedFilterProps {
  showAdvanced?: boolean;
  setShowAdvanced: (value: boolean) => void;
  onFilter: (filters: FilterShape) => void;
  onReset: (filters: FilterShape) => void;
  headers?: string[];
  headerMap?: any;
  tableName?: string;
  billId?:string;
  current_cycle?: [Dayjs | null, Dayjs | null];
  selectedSubPartner?: any;
  selectedPartner?: any;
  filters?: {
    sync_status: string;
    service_provider: string;
    tenant_name: string;
    start_date: any;
    end_date: any;
  };
}

const AdvancedMultiFilter2: React.FC<AdvancedFilterProps> = ({
  showAdvanced,
  setShowAdvanced,
  onFilter,
  onReset,
  headers = [],
  headerMap,
  tableName = "",current_cycle,
   selectedSubPartner,
  selectedPartner,filters
}) => {
  const [activeFilters, setActiveFilters] = useState<FilterShape>({});
  const [formValues, setFormValues] = useState<{ [key: string]: string[] }>({});
  const [rangeValues, setRangeValues] = useState<{ [key: string]: RangeValue }>({});
  const [openRangeDropdown, setOpenRangeDropdown] = useState<string | null>(null);
  const [rangeErrors, setRangeErrors] = useState<{ [key: string]: string }>({});
  const {
    advancedStoredpagination,
    storedpagination,
    combineAdnvaceStoredpagination,
    settabledata,
    setStoredPagination,
    selectedDb,
    metaData,
    selectedBillingDb,
    sessionId,
    setCombineAdnvaceStoredpagination,
    setAdvancedStoredPagination,
    tenantId,
    partner,
    username,
    tenantName,
    wholeSearchWord
  } = useAuth();
  const {accountNumber, BillId , setSummaryExportData , setSearchIdsforSelectAll} = useCustomerProfileStore();

  const [options, setOptions] = useState<{ [key: string]: string[] }>({});
  const [loading, setLoading] = useState<{ [key: string]: boolean }>({});
  const [searchLoading, setSearchLoading] = useState(false);
  const [visibleOptions, setVisibleOptions] = useState<{
    [key: string]: number;
  }>({});
  const [filteredOptions, setFilteredOptions] = useState<{
    [key: string]: string[];
  }>({});
  const [searchInput, setSearchInput] = useState<{ [key: string]: string }>({});
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const { setAdvancedSearchData, searchData, combineAdnvaceSearchData, setCombineAdnvaceSearchData,setDetailsRedirectedFilters,setDetailsRedirectedSearchTerm,setIsRedirectedFromDetails,isRedirectedFromDetails ,detailsRedirectedFilters} = useSearchStore();
  const { customerShowActive } = useCustomerRatePlanStore();
  const { optimizationRow } = useOptimizationStore();
  const bulkRow: any = JSON.parse(localStorage.getItem('bulk_row') || '{}');
  const iccid: any = localStorage.getItem('iccid') || '0';
  const { serviceShowActive, packageActive, productTypeShowActive ,productShowActive , servicesActive ,customerProfilesActive } = useKillBillStore();
  const [searchTable, setSearchTable] = useState<any[]>([]);
  const ReportsModule =["AR Aging Report","Billing Report w/_City_County_Country","Transaction Analysis Report","Payment Details Report","Billed Through Date Report","Export Variance Billing","Billing report by day with OCC Report","Altaworx Billing Report"]
  const TimeConversionHeaders = [ "created_date",
        "modified_date",
        "last_email_triggered_at",
        "billed_through_date",
        "activation_date",
        "closed_date",
        "bill_due_date",
        "payment_date",
        "received_date",
        "date",
        "statement_date",
        "bill_cycle_start_date",
        "bill_date"]
  // Function to check if a field should use range selection
  const isNumericField = (header: string) => {
    return (
      (NUMERIC_FIELDS.includes(header) && tableName === "Customer_Rate_Plan") ||
      (['device_count', 'total_charges', 'total_charge_amount'].includes(header) && tableName === 'carrier_optimization_list_view') ||
      (['device_count', 'total_charges', 'total_charge_amount'].includes(header) && tableName === 'customer_optimization_list_view')
    );
  };
    const {setChargesDetailsPagination,setChargeDetailsSearchData,setChargeDetailsTableData} = useSearchStore();
  

  const handleScroll = () => {
    if (openDropdown) {
      setOpenDropdown(null);
    }
    if (openRangeDropdown) {
      setOpenRangeDropdown(null);
    }
  };
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";

  useEffect(() => {
      if(tableName === "Unposted Upload Status"){
        if (isRedirectedFromDetails) {
                const allEmpty = Object.values(detailsRedirectedFilters).every(
                  (value) => Array.isArray(value) && value.length === 0
                );
              if (!allEmpty) {
                setShowAdvanced(true)
                setFormValues(detailsRedirectedFilters)
                handleNormalButtonClick(detailsRedirectedFilters)
              }
              }
      }
    }, []);
        useEffect(() => {
          if(tableName === "Unposted Upload Status"){
            if (isRedirectedFromDetails) {
                    const allEmpty = Object.values(detailsRedirectedFilters).every(
                      (value) => Array.isArray(value) && value.length === 0
                    );
                  if (!allEmpty) {
                    setShowAdvanced(true)
                    setFormValues(detailsRedirectedFilters)
                    handleNormalButtonClick(detailsRedirectedFilters)
                  }
                  }
          }
        }, [isRedirectedFromDetails]);
  useEffect(() => {
    const allEmpty = Object.values(activeFilters).every(
      (value) => Array.isArray(value) && value.length === 0
    );
    if (!storedpagination && !combineAdnvaceStoredpagination && !allEmpty) {
      // handleNormalButtonClick(activeFilters);
      handleClear()
    }
  }, [storedpagination, combineAdnvaceStoredpagination]);

  useEffect(() => {
    const scrollContainer = document.querySelector(".overflow-x-auto");
    if (scrollContainer) {
      scrollContainer.addEventListener("scroll", handleScroll);
    }
    return () => {
      if (scrollContainer) {
        scrollContainer.removeEventListener("scroll", handleScroll);
      }
    };
  }, [openDropdown, openRangeDropdown]);

  //  const handleRangeChange = (header: string, type: 'min' | 'max', value: number | null) => {
  //   setRangeValues(prev => {
  //     const newValues = { ...prev };
  //     if (!newValues[header]) {
  //       newValues[header] = {};
  //     }

  //     // Update the specific min/max value
  //     if (type === 'min') {
  //       newValues[header].min = value ?? undefined;
  //     } else {
  //       newValues[header].max = value ?? undefined;
  //     }

  //     // Convert to filter format
  //     const filterValues: string[] = [];
  //     const { min, max } = newValues[header];

  //     if (min !== undefined && max === undefined) {
  //       filterValues.push(String(min));
  //     } else if (min !== undefined || max !== undefined) {
  //       filterValues.push(`${min ?? ''}:${max ?? ''}`);
  //     }

  //     handleSelectChange(header, filterValues);
  //     return newValues;
  //   });
  // };
  // Update handleRangeChange to handle the display format while maintaining original data
  const handleRangeChange = (header: string, type: 'min' | 'max', value: number | null) => {
    setRangeValues(prev => {
      const newValues = { ...prev };
      if (!newValues[header]) {
        newValues[header] = {};
      }
      // Update the specific min/max value
      if (type === 'min') {
        newValues[header].min = value ?? undefined;
      } else {
        newValues[header].max = value ?? undefined;
      }
      // Check if min is greater than or equal to max
      const { min, max } = newValues[header];
      let errorMessage = '';
      if (min !== undefined && max !== undefined && min >= max) {
        errorMessage = "minimum value should be less than the maximum value.";
      }
      // Update the error message state
      setRangeErrors(prev => ({
        ...prev,
        [header]: errorMessage,
      }));

      // Convert to filter format for backend
      const filterValues: string[] = [];
      if (min !== undefined && max === undefined) {
        filterValues.push(String(min));
      } else if (min !== undefined || max !== undefined) {
        filterValues.push(`${min ?? ''}:${max ?? ''}`);
      }

      handleSelectChange(header, filterValues);
      return newValues;
    });
  };
  const handleFocus = (header:any) => {
    if (searchInput[header]) {
      handleSearch(header, searchInput[header]);
    }
  };
  const handleClear = () => {
    const emptyFilters = Object.keys(activeFilters).reduce<FilterShape>(
      (acc, key) => {
        acc[key] = [];
        return acc;
      },
      {} as FilterShape
    );

    if (Object.keys(activeFilters).length > 0) {
      onReset(emptyFilters);
    }
    onReset(emptyFilters);
    setFormValues({});
    setActiveFilters({});
    setSearchInput({});
    setFilteredOptions({});
    setRangeValues({});
    // Do not close the advanced filter section here
    setShowAdvanced(false); // Remove this line
    setAdvancedStoredPagination(null);
    setCombineAdnvaceStoredpagination(null)
    setCombineAdnvaceSearchData(null)
    setStoredPagination(null);
    setIsRedirectedFromDetails(false)
    setDetailsRedirectedFilters({})
    if(tableName === "Rev.io Syncs"){
      setChargesDetailsPagination(null)
      setChargeDetailsSearchData({})
    }
  };
  // const formatDisplayValue = (values: string[]): string => {
  //   if (!values || values.length === 0) return '';

  //   const value = values[0]; // We only handle one range/value at a time
  //   if (value.includes(':')) {
  //     const [min, max] = value.split(':');
  //     if (min && max) return `${min} to ${max}`;
  //     if (min) return `≥ ${min}`;
  //     if (max) return `≤ ${max}`;
  //   }
  //   return value; // Single value
  // };



  const fetchOptions = async (header: string, searchedText?: string) => {
    setLoading((prev) => ({ ...prev, [header]: true }));
    const advancedFilters = Object.entries(formValues).reduce<FilterShape>((acc, [key, value]) => {
      const modifiedValue = value.map((item) => item === "" ? ' ' : item);
      acc[key] = value;
      return acc;
    }, {});
    Object.keys(advancedFilters).forEach((key) => {
      if (TimeConversionHeaders.includes(key) && ReportsModule.includes(tableName)) {
        const selectedDates = advancedFilters[key]; // ["03/10/2026"]

        const expanded = (options?.[key] || []).filter((value: string) =>
          selectedDates.some((date: string) => value.startsWith(date))
        );

        if (expanded.length > 0) {
          advancedFilters[key] = expanded;
        }
      }
    });

    try {
      const url = ENV_ROUTES.OPEN_SEARCH;
      const data = {
        data: {
          path: "/fetch_dropdown",
          drop_down: header,
          table: tableName,
          ...(tableName === "Billing Service"
            ? { toggle: serviceShowActive }
            : {}),
          ...(tableName === "Billing Product Type"
            ? { toggle: productTypeShowActive }
            : {}),
            ...(tableName === "Billing Product"
              ? { toggle: productShowActive }
              : {}),
              ...(tableName === "Customer Profile" ? {toggle : customerProfilesActive} : {}),
          ...(tableName === "Customer Services" ? { toggle : servicesActive} : {}),
          ...(tableName === "Billing Package"
            ? { toggle: packageActive }
            : {}),
          ...(Billing_Collections_modules.includes(tableName)
            ? { account_number: accountNumber, }
            : {}),
          ...(["Usage Details","Charge By Service","Charge Overview"].includes(tableName) ? { bill_id : BillId} : {}),
          ...(tableName === "RepostedMRC" ? {current_cycle : current_cycle , account_number:accountNumber} : {}),
          cascade: advancedFilters || {},
          partner: partner,
          db_name: tableName === "Rev.io Syncs" ? selectedDb : selectedBillingDb,
          ...metaData,
// billing_db_name: selectedBillingDb,
          // Only include Selected_Partner and sub_partner if tableName is "GL Code Settings"
          ...(tableName === "GL Code Settings" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "GL Code Settings" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          sessionID: sessionId,
          tenant_id: tenant_id_,
          username: username,
          ...(tableName === "Billing Service" ? {tenant_database : selectedDb } : {}),
          ...(tableName === "Rev.io Syncs" && {
            sync_status: filters?.sync_status,
            service_provider: filters?.service_provider,
            start_date: filters?.start_date,
            end_date: filters?.end_date,
            tenant_name: filters?.tenant_name})
        },
      };

      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);

      if (parsedData?.flag) {
        setOptions((prevOptions) => ({
          ...prevOptions,
          [header]: parsedData?.[header] || [],
        }));

        if (searchedText) {
          const filtered = Array.from(
            new Set<string>(
              (parsedData?.[header] || [])
                .map((option: any) => {
                  if (TimeConversionHeaders.includes(header) && ReportsModule.includes(tableName)) {
                    return option?.toString().split(" ")[0];
                  }
                  return option?.toString();
                })
                .filter((option: string) =>
                  option.toLowerCase().includes(searchedText.toLowerCase())
                )
            )
          );

          setFilteredOptions((prev) => ({
            ...prev,
            [header]: filtered,
          }));

        } else {
          const filtered = Array.from(
            new Set<string>(
              (parsedData?.[header] || []).map((option: any) =>
                (TimeConversionHeaders.includes(header) && ReportsModule.includes(tableName))
                  ? option?.toString().split(" ")[0]
                  : option?.toString()
              )
            )
          );

          setFilteredOptions((prevOptions) => ({
            ...prevOptions,
            [header]: filtered,
          }));
        }

        setVisibleOptions((prev) => ({
          ...prev,
          [header]: 20,
        }));
      } else {
        Modal.error({
          title: "Filter error",
          content: parsedData.error || "An error occurred while filtering. Please try again.",
        });
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading((prev) => ({ ...prev, [header]: false }));
    }
  };

  const handleDropdownVisibleChange = (header: string, open: boolean) => {
    if (open) {
      setOpenDropdown(header);
      if (!isNumericField(header)) {
        fetchOptions(header);
      }
    } else {
      setOpenDropdown(null);
    }
  };


  const handleSelectChange = (header: string, value: string[]) => {
    if (header) {
      setSearchInput((prev) => ({
        ...prev,
        [header]: "",
      }));
      // Allow removal of filters
      const newValue = value.filter(val => String(val).trim() !== "");
      setFormValues(prev => ({
        ...prev,
        [header]: newValue,
      }));

      const formValues_ = { ...formValues, [header]: newValue };
      const allEmpty = Object.values(formValues_).every(
        (value) => Array.isArray(value) && value.length === 0
      );

      if (allEmpty) {
        handleClear();
      }
    }
  };
  const handleSearch = (header: string, inputValue: string) => {
    // Prevent spaces from being accepted
    if (inputValue.trim() === "") {
      setSearchInput((prev) => ({
        ...prev,
        [header]: "",
      }));
      setFilteredOptions((prev) => ({
        ...prev,
        [header]: options[header] || [],
      }));
      return;
    }

    setSearchInput((prev) => ({
      ...prev,
      [header]: inputValue,
    }));

    if (loading[header]) {
      fetchOptions(header, inputValue)
    }
    else {
      const filtered = options[header]?.filter((option) =>
        option?.toString().toLowerCase().includes(inputValue.toLowerCase())
      ) || [];

      setFilteredOptions((prev) => ({
        ...prev,
        [header]: filtered,
      }));
    }
  };
  const loadMoreOptions = (header: string) => {
    setVisibleOptions((prev) => ({
      ...prev,
      [header]: (prev[header] || 20) + 20,
    }));
  };

  const handleCheckboxChange = (header: string, option: string, checked: boolean) => {
    if (header) {
      setSearchInput((prev) => ({
        ...prev,
        [header]: "",
      }));
      const currentValues = formValues[header] || [];
      const newValues = checked
        ? [...currentValues, option]
        : currentValues.filter((item) => item !== option);

      setFormValues((prev) => ({
        ...prev,
        [header]: newValues,
      }));

      const formValues_ = { ...formValues, [header]: newValues };
      const allEmpty = Object.values(formValues_).every(
        (value) => Array.isArray(value) && value.length === 0
      );

      if (allEmpty) {
        handleClear();
      }
    }
  };

  const handleFilterLoad = () => {
    setSearchLoading(true);
    // if(searchLoading){
    handleFilter()
    // }
  }

  const handleFilter = () => {
    console.log(options,"options")
    const advancedFilters = Object.entries(formValues).reduce<FilterShape>((acc, [key, value]) => {
      const modifiedValue = value.map((item) => item === "" ? ' ' : item);
      acc[key] = modifiedValue;
      return acc;
    }, {});
    Object.keys(advancedFilters).forEach((key) => {
      if (TimeConversionHeaders.includes(key) && ReportsModule.includes(tableName)) {
        const selectedDates = advancedFilters[key]; // ["03/10/2026"]

        const expanded = (options?.[key] || []).filter((value: string) =>
          selectedDates.some((date: string) => value.startsWith(date))
        );

        if (expanded.length > 0) {
          advancedFilters[key] = expanded;
        }
      }
    });



    // Handle search input
    Object.entries(searchInput).forEach(([key, input]) => {
      const valuesArray = input
        .split(/[\s,]+/) // Split by spaces or commas
        .map((value) => value.trim()) // Trim whitespace
        .filter(Boolean); // Remove empty values
      if (valuesArray.length > 0) {
        advancedFilters[key] = [`${valuesArray.join(",")}`]; // Send as a single string in an array
      }
    });

    // Add additional filters based on table-specific requirements
    if (Object.keys(advancedFilters).length > 0) {
      if (tableName === "status_history" && iccid && iccid !== "None") {
        advancedFilters["iccid"] = [iccid];
      }
      if (tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null) {
        advancedFilters["bulk_change_id"] = [bulkRow?.row?.id];
      }
    }

    setActiveFilters(advancedFilters);
    onFilter(advancedFilters);
    // Call the backend search function
    handleNormalButtonClick(advancedFilters);
    setSearchInput({})
  };
  const Billing_Collections_modules = ["Billing and Collections Bill","Unposted","Customer Payment History","Customer Services","Ledger","Customer Service","Reversals","Usage Details","Charge By Service","Charge Overview","Unposted Upload Status"]
  const handleNormalButtonClick = async (filters_: any) => {
    console.log(advancedStoredpagination, "AdvancedStoredPagination");
    console.log(storedpagination, "storedpagination");
    console.log(searchData, "searchData");
    const filteredFilters = { ...filters_ };
    // setStoredPagination(null);  removed the pagination setting to null
    if ((storedpagination && searchData) || combineAdnvaceStoredpagination) {
      const searchData_ = combineAdnvaceStoredpagination ? combineAdnvaceSearchData : searchData
      const search_word_ = searchData_?.data?.search_word
      handleCombineButtonClick(filters_, search_word_);
    }
    else if (wholeSearchWord && wholeSearchWord !== "") {
      console.log("wholeSearchWord",wholeSearchWord);
      handleCombineButtonClick(filters_, wholeSearchWord);
    }
    else {
      setSearchLoading(true);
      try {
        const url = ENV_ROUTES.OPEN_SEARCH;
        const data = {
          data: {
            path: "/perform_search",
            search: "advanced",
            filters: filters_,
            index_name: tableName,
            tenant_id: tenant_id_,
            pages: {
              start: 0,
              end: 100,
            },
            partner: partner,
            username: username,
            db_name: tableName === "Rev.io Syncs" ? selectedDb : selectedBillingDb,
            ...metaData,
// billing_db_name: selectedBillingDb,
            // Only include Selected_Partner and sub_partner if tableName is "GL Code Settings"
            ...(tableName === "GL Code Settings" && selectedPartner && { Selected_Partner: selectedPartner }),
            ...(tableName === "GL Code Settings" && selectedSubPartner && { sub_partner: selectedSubPartner }),
            sessionID: sessionId,
            ...(tableName === "Billing Service"
              ? { toggle: serviceShowActive,
                col_sort:{description: "ASC"}
               }
              : {}),
              ...(tableName === "Billing Product Type"
                ? { toggle: productTypeShowActive, 
                  col_sort:{description: "ASC"}
                }
                : {}),
                ...(tableName === "Billing Product"
                  ? { toggle: productShowActive, 
                    col_sort:{description: "ASC"}
                  }
                  : {}),
                   ...(tableName === "Customer Services"
                  ? { toggle: servicesActive, 
                    col_sort:{description: "ASC"}
                  }
                  : {}),
                
              ...(tableName === "Billing Package"
                ? { toggle: packageActive ,
                    col_sort:{category: "ASC"}
                  }
                : {}),
              ...(Billing_Collections_modules.includes(tableName)
                ? { account_number: accountNumber}
                : {}),
                ...(["Usage Details","Charge By Service","Charge Overview"].includes(tableName) ? { bill_id : BillId} : {}),
            ...(tableName === "Billing Product"
              ? { col_sort: { description: "ASC" } }
              : {}),
            ...(tableName === "Customer Profile"
              ? {  toggle: customerProfilesActive,col_sort: { account_number: "ASC" } }
              : {}),
            ...(tableName === "RepostedMRC" ? {current_cycle : current_cycle , account_number:accountNumber} : {}),
            ...(tableName === "Billing Service" ? {tenant_database : selectedDb } : {}),
            ...(tableName === "Rev.io Syncs" && {
            service_provider: filters?.service_provider,
            start_date: filters?.start_date,
            end_date: filters?.end_date,
            tenant_name: filters?.tenant_name,
            sync_status: filters?.sync_status})
          },


        };
        console.log(data, "Adnvaced data....");
        setAdvancedSearchData(data);
        const response = await axios.post(url, data);
        const parsedData = JSON.parse(response.data.body);
        const pagination_ = parsedData?.pages || {};

        if (parsedData?.flag) {
          const tableData = parsedData?.data?.table;
         
          if (tableName === "Unposted Upload Status") {
            setDetailsRedirectedFilters(filteredFilters)
            setDetailsRedirectedSearchTerm("")
          }
          else if(tableName === "Rev.io Syncs"){
            setChargeDetailsTableData(tableData)
            setChargesDetailsPagination(pagination_)
            setChargeDetailsSearchData(data);
          }
          else{
            settabledata(tableData);
          }
          setSearchTable(tableData)
          setAdvancedStoredPagination(pagination_);
          console.log("hraders",headerMap)
           const summary_ = parsedData?.summary || {};
          const mappedSummary: Record<string, number> = {};

          // Loop through summary keys and map to headerMap display name
          Object.entries(summary_).forEach(([key, value]) => {
            const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
            mappedSummary[displayName] = value as number;
          });

          console.log("Mapped Summary:", mappedSummary);
          setSummaryExportData(mappedSummary || {});
          setSearchIdsforSelectAll(parsedData.search_ids || []);
          if (tableData.length === 0) {
            Modal.error({
              title: "No Records found",
            });
            handleClear()
            setShowAdvanced(false)
          }
        } else {
          Modal.error({
            title: "Search error",
            content: parsedData.error || "An error occurred while searching. Please try again.",
          });
          handleClear()
          setShowAdvanced(false)
        }
      } catch (error) {
        console.error(error);
      }
      finally {
        setSearchLoading(false);
      }
    }
  };

  const handleCombineButtonClick = async (filters_: any, searchWord: string) => {
    setSearchLoading(true);
    try {
      const url = ENV_ROUTES.OPEN_SEARCH;
      const data = {
        data: {
          path: "/perform_search",
          search: "combined",
          filters: filters_,
          search_word: searchWord,
          search_all_columns: "True",
          index_name: tableName,
          tenant_id: tenant_id_,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: tableName === "Rev.io Syncs" ? selectedDb : selectedBillingDb,
          ...metaData,
// billing_db_name: selectedBillingDb,
          
          // Only include Selected_Partner and sub_partner if tableName is "GL Code Settings"
          ...(tableName === "GL Code Settings" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "GL Code Settings" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          sessionID: sessionId,
          ...(tableName === "Billing Service"
            ? { toggle: serviceShowActive,
              col_sort:{description: "ASC"} }
            : {}),
          ...(tableName === "Billing Product Type"
            ? { toggle: productTypeShowActive, 
              col_sort:{description: "ASC"}
            }
            : {}),
            ...(tableName === "Billing Product"
              ? { toggle: productTypeShowActive, 
                col_sort:{description: "ASC"}
              }
              : {}),
          ...(tableName === "Billing Package"
            ? { toggle: packageActive ,
                col_sort:{category: "ASC"}
              }
            : {}),
          ...(Billing_Collections_modules.includes(tableName)
            ? { account_number: accountNumber }
            : {}),
          ...(["Usage Details","Charge By Service","Charge Overview"].includes(tableName) ? { bill_id : BillId} : {}),
          ...(tableName === "Billing Product"
                ? { col_sort:{description: "ASC"}}
                : {}),
          ...(tableName === "Unposted"
            ? { col_sort: { charge_description: "ASC" } }
            : {}),
          ...(tableName === "Customer Profile"
            ? {toggle: customerProfilesActive, col_sort: { account_number: "ASC" } }
            : {}),
          ...(tableName === "RepostedMRC" ? {current_cycle : current_cycle , account_number:accountNumber} : {}),
          ...(tableName === "Billing Service" ? {tenant_database : selectedDb } : {}),
            ...(tableName === "Rev.io Syncs" && {
            sync_status: filters?.sync_status,
            service_provider: filters?.service_provider,
            start_date: filters?.start_date,
            end_date: filters?.end_date,
            tenant_name: filters?.tenant_name})
        },

      };

      setCombineAdnvaceSearchData(data);
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);

      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        const pagination_ = parsedData?.pages || {};
        if (tableName === "Rev.io Syncs") {
          setChargeDetailsTableData(tableData)
          setChargesDetailsPagination(pagination_)
          setChargeDetailsSearchData(data);
        }
        else {
          settabledata(tableData);
        }
        setSearchTable(tableData)
        setCombineAdnvaceStoredpagination(pagination_);
        const summary_ = parsedData?.summary || {};
        const mappedSummary: Record<string, number> = {};

        // Loop through summary keys and map to headerMap display name
        Object.entries(summary_).forEach(([key, value]) => {
          const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
          mappedSummary[displayName] = value as number;
        });

        console.log("Mapped Summary:", mappedSummary);
        setSummaryExportData(mappedSummary || {});
        setSearchIdsforSelectAll(parsedData.search_ids || []);
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
          handleClear()
          setShowAdvanced(false)
        }

      } else {
        Modal.error({
          title: "Search error",
          content: parsedData.error || "An error occurred while searching. Please try again.",
        });
        handleClear()
        setShowAdvanced(false)
      }
    } catch (error) {
      console.error(error);
    }
    finally {
      setSearchLoading(false);
    }
  };

  const renderRangeDropdown = (header: string) => {
    const values = rangeValues[header] || {};
    const errorMessage = rangeErrors[header];
    const showDollar =
      ((header === 'total_charge_amount' || header === 'total_charges') &&
        (tableName === 'customer_optimization_list_view' || tableName === 'carrier_optimization_list_view'));

    return (
      <div className="p-4 bg-white shadow-lg rounded-lg">
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <div className="relative w-1/2">
              {showDollar && (
                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              )}
              <InputNumber
                className={`w-full`}
                value={values.min === undefined ? undefined : values.min}
                onChange={(value) => {
                  if (value !== null && value < 0) {
                    setRangeErrors(prev => ({
                      ...prev,
                      [header]: "Negative values are not accepted."
                    }));
                    return;
                  }
                  setRangeErrors(prev => ({ ...prev, [header]: "" }));
                  handleRangeChange(header, 'min', value);
                }}
                placeholder="Min value"
                title={values.min !== undefined ? `Min Value: ${showDollar ? `$${values.min}` : values.min}` : "Enter minimum value"}
                formatter={(value) => {
                  if (value === undefined || value === null) return '';
                  return String(value);
                }}
                parser={(displayValue) => {
                  if (!displayValue) return 0; // Return 0 for empty input
                  const numericValue = displayValue.replace(/\$\s?|(,*)/g, ''); // Remove dollar sign and commas
                  if (!/^[0-9]*$/.test(numericValue)) {
                    setRangeErrors(prev => ({ ...prev, [header]: "Only numbers are accepted." }));
                    return 0; // Return 0 for invalid input
                  }
                  setRangeErrors(prev => ({ ...prev, [header]: "" }));
                  return Number(numericValue);
                }}
                min={0}
                addonBefore={showDollar}
              />
            </div>

            <span className="text-gray-500">to</span>

            <div className="relative w-1/2">
              {showDollar && (
                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              )}

              <InputNumber
                className={`w-full`}
                value={values.max === undefined ? undefined : values.max}
                onChange={(value) => {
                  if (value !== null && value < 0) {
                    setRangeErrors(prev => ({
                      ...prev,
                      [header]: "Negative values are not accepted."
                    }));
                    return;
                  }
                  if (value !== null && value <= (values.min === undefined ? 0 : values.min)) {
                    setRangeErrors(prev => ({
                      ...prev,
                      [header]: "Max value must be greater than min value."
                    }));
                    return;
                  }
                  setRangeErrors(prev => ({ ...prev, [header]: "" }));
                  handleRangeChange(header, 'max', value);
                }}
                placeholder="Max value"
                title={values.max !== undefined ? `Max value: ${showDollar ? `$${values.max}` : values.max}` : "Enter maximum value"}
                formatter={(value) => {
                  if (value === undefined || value === null) return '';
                  return String(value);
                }}
                parser={(displayValue) => {
                  if (!displayValue) return 0; // Return 0 for empty input
                  const numericValue = displayValue.replace(/\$\s?|(,*)/g, ''); // Remove dollar sign and commas
                  if (!/^[0-9]*$/.test(numericValue)) {
                    setRangeErrors(prev => ({ ...prev, [header]: "Only numbers are accepted." }));
                    return 0; // Return 0 for invalid input
                  }
                  setRangeErrors(prev => ({ ...prev, [header]: "" }));
                  return Number(numericValue);
                }}
                min={0}
                // style={{ paddingLeft: showDollar ? '0.5rem' : '0.5rem' }}
                addonBefore={showDollar}
              />
            </div>
          </div>
          {errorMessage && (
            <div className="text-red-500 text-xs mt-1">{errorMessage}</div>
          )}
          <div className="text-xs text-gray-500 mt-1">
            Enter single value in first box or specify a range
          </div>
        </div>
      </div>
    );
  };
  // Add this function to format values with dollar sign
  const formatValueWithDollar = (value: string, header: string): string => {
    // const showDollar = (header === 'total_charge_amount' || header === 'total_charges') && (tableName === "Customer_Rate_Plan" ||tableName === 'customer_optimization_list_view'||tableName === 'carrier_optimization_list_view' );
    const showDollar =
      ((header === 'total_charge_amount' || header === 'total_charges') &&
        (tableName === 'customer_optimization_list_view' || tableName === 'carrier_optimization_list_view'));
    return showDollar ? `$${value}` : value;
  };

  const countActiveFilters = useMemo(() => {
    if (
      (tableName === "status_history" && activeFilters?.["iccid"]) ||
      (tableName === "sim_management_bulk_change_request" && activeFilters["bulk_change_id"])
    ) {
      return (
        Object.values(activeFilters).filter((value) => value.length > 0)
          .length - 1
      );
    } else {
      return Object.values(activeFilters).filter((value) => value.length > 0)
        .length;
    }
  }, [activeFilters]);

  const isFilterButtonEnabled = () => {
    return Object.values(formValues).some((values) => values.length > 0) ||
      Object.values(rangeValues).some((range) => range.single !== undefined || (range.min !== undefined && range.max !== undefined)) ||
      Object.values(searchInput).some((input) => input.length > 0);
  };

  return (
    <div>
      {searchLoading && (
        <div className="absolute inset-0 flex justify-center items-center adv-search-loader  bg-white bg-opacity-75 z-50 pointer-events-none">
          <Spin size="large" />
        </div>
      )}
      {/* <div className="flex flex-col md:flex-row md:justify-end space-y-4 md:space-y-0 md:space-x-2">
        <button
          className="save-btn w-[150px]"
          onClick={() => setShowAdvanced(!showAdvanced)}
          style={{ fontWeight: "450" }}
        >
          {showAdvanced ? (
            <span className="flex items-center pl-2">
              Hide Advanced
              <ChevronUpIcon className="ml-2 w-4 h-4" />
            </span>
          ) : (
            <span className="flex items-center pl-2">
              Show Advanced
              <ChevronDownIcon className="ml-2 w-4 h-4" />
            </span>
          )}
        </button>

        {(showAdvanced && isFilterButtonEnabled()) && (
          <div className="relative w-full md:w-auto">
            <button
              className={`save-btn ${!showAdvanced || Object.keys(formValues).length < 1
                ? "disabled"
                : ""}`}
              style={{ minWidth: '70px' }}
              onClick={handleFilterLoad}
              disabled={!showAdvanced || !isFilterButtonEnabled()}
            >
              Filter
            </button>
          </div>
        )}

        {(showAdvanced && isFilterButtonEnabled() && Object.keys(formValues).length > 0) && (
          <div className="relative w-full md:w-auto">
            <button
              className="min-h-[46px] text-gray-800 border bg-gray-200 border-gray-300 rounded-lg px-4 py-2 transition-colors duration-200 hover:bg-gray-300 disabled:cursor-not-allowed disabled:opacity-50"
              onClick={handleClear}
              disabled={Object.keys(formValues).length < 1}
            >
              Clear
            </button>
            <div className={`absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ${countActiveFilters > 0 ? "bg-green-500" : "bg-blue-500"}`}>
              {countActiveFilters}
            </div>
          </div>
        )}
      </div> */}
         <div className="flex md:flex-row md:justify-end gap-2 md:space-y-0 md:space-x-2">
        <button
          className="save-btn w-fit md:w-auto px-2 !h-[40px] md:!h-[46px] "
          onClick={() => setShowAdvanced(!showAdvanced)}
          style={{ fontWeight: "450" }}
        >
          <span className="flex items-center justify-center pl-2">
            {/* Text for medium and up */}
            <span className="hidden md:flex items-center">
              {showAdvanced ? (
                <>
                  Hide Advanced <ChevronUpIcon className="ml-2 w-4 h-4" />
                </>
              ) : (
                <>
                  Show Advanced <ChevronDownIcon className="ml-2 w-4 h-4" />
                </>
              )}
            </span>

            {/* Icon only for small screens */}
            <span className="flex md:hidden items-center space-x-1">
              <FunnelIcon className="w-5 h-5" />
              {showAdvanced ? (
                <ChevronUpIcon className="w-5 h-5" />
              ) : (
                <ChevronDownIcon className="w-5 h-5" />
              )}
            </span>
          </span>
        </button>

        {showAdvanced && isFilterButtonEnabled() && (
          <>
            {/* Small screens - icon only */}
            <button
              className="save-btn !flex md:!hidden items-center justify-center"
              onClick={handleFilterLoad}
              disabled={!showAdvanced || !isFilterButtonEnabled()}
              title="Filter"
            >
            <CheckIcon className="w-6 h-6" />            
            </button>

            {/* Medium and up - full button */}
            {/* <div className="hidden md:flex"> */}
              <button
                className="save-btn !hidden md:!flex items-center justify-center h-8"
                onClick={handleFilterLoad}
                disabled={!showAdvanced || !isFilterButtonEnabled()}
              >
                Filter
              </button>
            {/* </div> */}
          </>
        )}

        {showAdvanced && isFilterButtonEnabled() && Object.keys(formValues).length > 0 && (
          <>
            <div className="cancel-btn md:hidden relative">
              <button
                className="cancel-btn  flex items-center justify-center"
                onClick={handleClear}
                disabled={Object.keys(formValues).length < 1}
                title="Clear"
              >
                <ArrowPathIcon className="w-6 h-6 text-black-600" />
              </button>
               <div className={`absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ${countActiveFilters > 0 ? "bg-green-500" : "bg-blue-500"}`}>
                {countActiveFilters}
              </div>
            </div>

            {/* Medium and up - full button */}
            <div className="hidden md:flex relative">
              <button
                className="cancel-btn h-8 text-gray-800 border bg-gray-200 border-gray-300 rounded-lg px-4 py-0 transition-colors duration-200 hover:bg-gray-300 disabled:cursor-not-allowed disabled:opacity-50"
                onClick={handleClear}
                disabled={Object.keys(formValues).length < 1}
              >
                Clear
              </button>
              <div className={`absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ${countActiveFilters > 0 ? "bg-green-500" : "bg-blue-500"}`}>
                {countActiveFilters}
              </div>
            </div>
          </>
        )}
      </div>
      {showAdvanced && headers && (
        <div className="overflow-x-auto rounded-md mt-2 block absolute left-0 right-0">
          <div className="flex space-x-2 p-1">
            {headers.map(
              (header) =>
                header !== "modified_by" &&
                headerMap[header]?.[0] !== "Info" &&
                headerMap[header]?.[0] !== "Details" &&
                !(header === "packages" && tableName === "Customer Service") &&
                !(header === "iccid" && tableName === "status_history") && (
                  <div className="flex-none w-64" key={header}>
                    {isNumericField(header) ? (
                      (() => {
                        const SelectProps = {
                          mode: "multiple" as "multiple",
                          placeholder: headerMap ? headerMap[header]?.[0] : "",
                          open: openRangeDropdown === header,
                          onOpenChange: (open: boolean) => setOpenRangeDropdown(open ? header : null),
                          value: formValues[header] || [],
                          className: "w-full",
                          maxTagCount: 1,
                          maxTagPlaceholder: (omittedValues: any[]) => `+${omittedValues.length}`,
                          tagRender: (props: any) => {
                            const { label, closable, onClose } = props;
                            let displayValue = label;

                            if (label.includes(':')) {
                              const [min, max] = label.split(':');
                              if (min && max) {
                                displayValue = `${formatValueWithDollar(min, header)} to ${formatValueWithDollar(max, header)}`;
                              } else if (min) {
                                displayValue = `≥ ${formatValueWithDollar(min, header)}`;
                              } else if (max) {
                                displayValue = `≤ ${formatValueWithDollar(max, header)}`;
                              }
                            } else {
                              displayValue = formatValueWithDollar(label, header);
                            }

                            const handleRemove = () => {
                              // Create a new array of selected values without the one being removed
                              const newValues = formValues[header]?.filter((val: any) => val !== label);
                              handleSelectChange(header, newValues); // Update the selected values
                            };

                            return (
                              <span
                                className="inline-flex items-center text-ellipsis px-2 py-1 overflow-hidden whitespace-nowrap relative bg-white shadow-lg rounded-lg max-w-[185px]"
                                title={displayValue}
                              >
                                {displayValue}
                                {closable && <CloseOutlined className="ml-2" onClick={handleRemove} />}
                              </span>
                            );
                          },
                          dropdownRender: () => renderRangeDropdown(header),
                          suffixIcon: <ChevronDownIcon className="ml-2 w-4 h-4" />,
                          // Temporary input value for search
                          onSearch: (inputValue: string) => {
                            if (inputValue.trim() === "") return;

                            setSearchInput((prev) => ({
                              ...prev,
                              [header]: inputValue,
                            }));
                          },

                          // Handle key press to add selected value
                          onKeyDown: (event: React.KeyboardEvent) => {
                            if (event.key === 'Enter') {
                              const inputValue = searchInput[header]?.trim();
                              if (inputValue && !formValues[header]?.includes(inputValue)) {
                                handleSelectChange(header, [...(formValues[header] || []), inputValue]);
                                setSearchInput((prev) => ({ ...prev, [header]: "" })); // Clear input after adding
                              }
                            }
                          },
                        };

                        return <Select {...SelectProps} />;
                      })()
                    ) : (
                      <Select
                        mode="multiple"
                        placeholder={headerMap ? headerMap[header]?.[0] : ""}
                        onChange={(value: any[]) => {
                          handleSelectChange(header, value); // ✅ Corrected logic
                          if (value.length === 0) {
                            handleSearch(header, "");
                          }
                        }}
                        onOpenChange={(open) => handleDropdownVisibleChange(header, open)}
                        open={openDropdown === header}
                        value={formValues[header] || []}
                        className="w-full text-ellipsis overflow-hidden whitespace-nowrap adv-filter-drp"
                        maxTagCount={1}
                        maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
                        tagRender={(props) => {
                          const { label, closable, onClose } = props;
                          const labelString = String(label);
                          const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;
                          const allSelectedLabels = formValues?.[header]?.join(", ");
                          return (
                            <span
                              className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap  bg-white relative shadow-lg rounded-lg max-w-[185px] selected-value"
                            title={`${allSelectedLabels}`}
                            >
                              {truncatedLabel}
                              {closable && <CloseOutlined onClick={onClose} />}
                            </span>
                          );
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            const previouslySelected = formValues[header] || [];
                            const currentOptions =
                              filteredOptions[header]?.length > 0
                                ? filteredOptions[header]
                                : options[header];
                        
                            // Append only newly unselected options
                            const newSelections = currentOptions.filter(
                              (item) => !previouslySelected.includes(item)
                            );
                        
                            handleSelectChange(header, [...previouslySelected, ...newSelections]);
                          }
                        }} 
                        showSearch={!loading[header]} // Disable search input when loading                        
                        filterOption={false}
                        onSearch={(input) => handleSearch(header, input)}
                        onFocus={() => handleFocus(header)}
                        autoClearSearchValue={loading[header]?true:false}
                        // onBlur={() => {
                        //   // ✅ Reapply the search input to persist text after blur
                        //   handleSearch(header, searchInput[header]);
                        // }}
                        // onBlur={() => handleSearch(header, "")} // Call handleSearch with empty input on blur
                        searchValue={searchInput[header]}
                        // searchValue={loading[header] ? "" : searchInput[header]}
                        popupRender={(menu) => (
                          <div className="relative bg-white shadow-lg rounded-lg max-w-full  adv-filter-drp-div">
                            {options[header]?.length > 0 && (
                              <Checkbox
                                indeterminate={
                                  formValues[header]?.length > 0 &&
                                  formValues[header]?.length <
                                  (filteredOptions[header]?.length || options[header]?.length)
                                }
                                checked={
                                  formValues[header]?.length ===
                                  (filteredOptions[header]?.length || options[header]?.length)
                                }
                                onChange={(e) => {
                                  const isChecked = e.target.checked;
                                const currentOptions = filteredOptions[header]
                                  ?.length
                                  ? filteredOptions[header] // Use filtered options if available
                                  : options[header]; // Fallback to all options

                                handleSelectChange(
                                  header,
                                  isChecked ? currentOptions : []
                                );
                                  if (!isChecked) {
                                  handleSearch(header, ""); // Clear search text when deselecting all
                                  }
                                }}
                                className="transform scale-100 px-2  adv-list-item"
                                style={{ width: '100%', overflowY: 'auto' }}
                              >
                                Select All
                              </Checkbox>
                            )}

                            {loading[header] ? (
                              <div className="flex justify-center p-4">
                                <Spin />
                              </div>
                            ) : (
                              <VirtualList
                                className="p-2"
                                data={
                                  filteredOptions[header]?.slice(0, visibleOptions[header] || 20) ||
                                  options[header]?.slice(0, visibleOptions[header] || 20)
                                }
                                height={250}
                                itemHeight={0}
                                itemKey="value"
                                onScroll={(e) => {
                                  const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
                                  const isBottom = Math.abs(scrollHeight - scrollTop - clientHeight) < 1;
                                  if (isBottom) {
                                    loadMoreOptions(header);
                                  }
                                }}
                              >
                                {(item) => (
                                  <span className="mb-2">
                                    <Checkbox
                                      key={item}
                                      checked={formValues[header]?.includes(item)}
                                      onChange={(e) => handleCheckboxChange(header, item, e.target.checked)}
                                      className="inline-flex mr-2  adv-list-item"
                                    >
                                      {item}
                                    </Checkbox>
                                  </span>
                                )}
                              </VirtualList>
                            )}
                          </div>
                        )}
                        suffixIcon={<ChevronDownIcon className="ml-2 w-4 h-4" />}
                      />
                    )}
                  </div>
                )
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedMultiFilter2;