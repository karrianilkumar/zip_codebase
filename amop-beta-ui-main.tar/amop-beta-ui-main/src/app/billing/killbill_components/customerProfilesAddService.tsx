"use client"
import React, { useCallback, useEffect, useState, useRef } from "react";
import { Checkbox, Input, Modal, notification, Popover, Spin, Switch, DatePicker, Select } from 'antd';
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";
import dayjs, { Dayjs } from 'dayjs';
import Dropdown from "./dropdownComponent";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import EditableTableComponent from "./editable_table_component";
import { CloseOutlined } from "@ant-design/icons";
import VirtualList from 'rc-virtual-list';
import KillbillTableComponent from "./table__component";
import { FunnelIcon } from "@heroicons/react/24/outline";
import { fireSideCannons } from "@/app/components/confetti";

interface CreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedRow: any, tableData?: any) => void;
  fetchdata: () => void;
  modalData: {
    id: number;
    display_name: string;
    type: string;
    mandatory: boolean;
    db_column_name: string;
  }[];
  title: string;
  visible: boolean;
  action: string;
  rowData?: any;
  generalFields?: any;
  dropdownValues?: any;
  accountNumber?: any;
}

type FormData = {
  create: any | null;
  service_type: any | null;
  customer_services_id_list: any | null;
  provider: any | null;
  contract_term: [Dayjs | null, Dayjs | null];
  effective_date: any | null;
  accounts: string;
  services: any | null;
  dest_customer: any | null;
  products: string[];
  packages: any | null; // Added 'packages' property
  address_line_1: string | null; // Added 'address_line_1' property
  city: string | null; // Added 'city' property
  state: string | null; // Added 'state' property
  postal_code: string | null; // Added 'postal_code' property
  country: string | null; // Added 'country' property
  built_in_fields: { [key: string]: string | Dayjs | null };
  custom_fields: { [key: string]: string | Dayjs | null } | null;
  primary_fields: { [key: string]: string | Dayjs | null };
  iccid: string | null;
  msisdn: string | null;
  imei: string | null;
  eid: string | null;
  customer_rate_plan: any | null;
  custom_primary_field?:string | null;
   apply_to_all?: boolean; 
};

const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};
const CustomCreateModal: React.FC<CreateModalProps> = ({
  isOpen,
  onClose,
  onSave,
  modalData,
  title,
  visible,
  action,
  rowData,
  generalFields,
  dropdownValues,
  accountNumber,
  fetchdata
}) => {
  // console.log(dropdownValues, accountNumber, "show dropdownData");
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination } = useAuth();
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [newServiceFields, setNewServiceFields] = useState(false);
  const [productsFields, setProductsFields] = useState(false);
  const [transferServicesFields, setTransferServicesFields] = useState(false);
  const [showProductRow, setShowProductRow] = useState(false);
  const [disconnectServiceFields, setDisconnectServiceFields] = useState(false);
type DisconnectServiceData =
  | Record<string, string> // e.g. { "3703-127-2": "11-04-2025 00:00:00" }
  | DisconnectItem[]       // e.g. [{ id: 3703, manual_disconnect_date: "11-04-2025" }]
  | string[];              // e.g. ["3703-127-2"]

interface DisconnectItem {
  id: string | number;
  manual_disconnect_date?: string;
}

const [disconnectServiceData, setDisconnectServiceData] =
  useState<any>({});

// const [disconnectLoading, setDisconnectLoading] = useState(false);
  const options = [
    { value: "newService", label: "New Service" },
    { value: "transferService", label: "Transfer Service" },
    { value: "disconnectService", label: "Disconnect Service" },
    
    // { value: "products", label: "Products" },
  ];
  const [productOptions, setProductOptions] = useState<{ label: string; value: string }[]>([]);
  const [packageOptions, setPackageOptions] = useState<{ label: string; value: string }[]>([]);
  const [productPackageData, setProductPackageData] = useState<any>({});
  const [serviceTypeID, setServiceTypeID] = useState<string | null>(null);
  const [selectedOption, setSelectedOption] = useState(options[0]);
  const [PrimaryField, setPrimaryField] = useState('')
  const [builtInFields, setBuiltInFields] = useState<any[]>([]);
  const [customFields, setCustomFields] = useState<any[]>([]);
  const [customerRatePlanOptions, setCustomerRatePlanOptions] = useState<any[]>([]);
  const [providerOptions, setProviderOptions] = useState<any[]>([]);
  const [disconnectTableData, setDisconnectTableData] = useState<any[]>([]);
  const [showDisconnectTable, setShowDisconnectTable] = useState(false);
  const [viewportHeight, setViewportHeight] = useState(0);
 useEffect(() => {
    const updateHeight = () => {
      setViewportHeight(window.innerHeight);
    };

    updateHeight(); // Initial height set
    window.addEventListener("resize", updateHeight); // Update on resize

    return () => window.removeEventListener("resize", updateHeight); // Cleanup
  }, []);

  const [formData, setFormData] = useState<FormData>({
    create: null,
    service_type: null,
    customer_services_id_list: null,
    provider: "",
    contract_term: [null, null],
    effective_date: null,
    accounts: "",
    services: null,
    dest_customer: null,
    products: [],
    packages: null,
    address_line_1: null,
    iccid: null,
    msisdn: null,
    eid: null,
    imei: null,
    city: null,
    state: null,
    postal_code: null,
    country: null,
    built_in_fields: {},
    custom_fields: {},
    primary_fields: {},
    customer_rate_plan: null,
    custom_primary_field : null,
     apply_to_all: false,
  });
  const { RangePicker } = DatePicker;
  const [errors, setErrors] = useState<{
    service_type: string;
    customer_services_id_list: string;
    provider: string;
    effective_date: string;
    accounts: string;
    products: string;
    packages: string;
    address_line_1: string;
    city: string;
    state: string;
    postal_code: string;
    country: string;
    dest_customer: string;
    contract_term: string;
    iccid: string;
    msisdn: string;
    imei: string;
    eid: string;
    customer_rate_plan: string;
    primary_field: string;
  }>({
    service_type: '',
    customer_services_id_list: '',
    provider: '',
    effective_date: '',
    accounts: '',
    products: '',
    packages: '',
    address_line_1: '',
    city: '',
    state: '',
    postal_code: '',
    country: '',
    dest_customer: '',
    contract_term: '',
    iccid: '',
    msisdn: '',
    imei: '',
    eid: '',
    customer_rate_plan: '',
    primary_field: ''
  });
  const [tableData, setTableData] = useState<any>([]);
  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const [headerMap, setHeaderMap] = useState<any>({});
  const [headers, setHeaders] = useState<any[]>([]);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [UpdatedTableData, setUpdatedTableData] = useState<string[]>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const { features: moduleFeatures, setFeatures: setModuleFeatures } = useFeatureStore();
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields_, setgeneralFields] = useState<any[]>([])
  const [pagination, setPagination] = useState<any>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredData, setFilteredData] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState<any>([]);
  const [selectedPackages, setSelectedPackages] = useState<any>([]);
  const [ReverseRowData, setReverseRowData] = useState<any[]>([]);
  const [productRates, setProductRates] = useState<Record<string, number | null>>({});
  const [packageRates, setPackageRates] = useState<Record<string, number | null>>({});
  const [productQuantities, setProductQuantities] = useState<Record<string, number | null>>({});
  const [packageQuantities, setPackageQuantities] = useState<Record<string, number | null>>({});
  const [showDisconnectFields, setShowDisconnectFields] = useState(false);
const [applyToAll, setApplyToAll] = useState(false);


  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  // Set default quantity to 1 when products/packages are selected
  useEffect(() => {
    setProductQuantities((prev) => {
      const newQuantities = { ...prev };
      selectedProducts.forEach((key: any) => {
        if (!(key in newQuantities) || newQuantities[key] === null) {
          newQuantities[key] = 1;
        }
      });
      // Remove quantities for unselected products
      Object.keys(newQuantities).forEach((key) => {
        if (!selectedProducts.includes(key)) {
          delete newQuantities[key];
        }
      });
      return newQuantities;
    });
  }, [selectedProducts]);

  useEffect(() => {
    setPackageQuantities((prev) => {
      const newQuantities = { ...prev };
      selectedPackages.forEach((key: any) => {
        if (!(key in newQuantities) || newQuantities[key] === null) {
          newQuantities[key] = 1;
        }
      });
      // Remove quantities for unselected packages
      Object.keys(newQuantities).forEach((key) => {
        if (!selectedPackages.includes(key)) {
          delete newQuantities[key];
        }
      });
      return newQuantities;
    });
  }, [selectedPackages]);
  useEffect(() => {
    if (isOpen) {
      if(dropdownValues?.customer_rate_plan){
        setCustomerRatePlanOptions(
          dropdownValues.customer_rate_plan.map((item: string) => ({
            label: item,
            value: item,
          }))
        );
      }
      if(dropdownValues?.provider){
        setProviderOptions(
          dropdownValues?.provider?.map((item: string) => ({
            label: item,
            value: item,
          }))
        );
      }
    }

  }, [dropdownValues,isOpen]);
useEffect(() => {
  if (disconnectServiceData) {
    console.log("🔄 Syncing disconnectServiceData to ReverseRowData:", disconnectServiceData);
    setReverseRowData(disconnectServiceData);
  }
}, [disconnectServiceData]);

  const callSyncSubmit = async (insertData:any) => {
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_usage_for_past_bill_cycle",
        role_name: role,
        account_number: accountNumber,
        parent_module: "Billing Platform",
        module_name: "Customer Services",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: "Customer Profiles",
        feature_module_name: "Customer Services",
        inserted_data_dict: insertData
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        console.log("syn success")
      }
      else {
        console.log("Sync Failed")
      }
    } catch (error) {
        console.log("Sync Failed")
    } finally {
    }
  }

  const SubmitData = async (formData: any) => {
    setLoading(true);
    setIsConfirmationOpen(false)
    try {
      const cleanedData = Object.keys(formData).reduce((acc: any, key) => {
         if (key === "apply_to_all") return acc; 
        const value = formData[key];
        acc["service_type_id"] = serviceTypeID ? serviceTypeID : ''
        if (key === 'create') {
          acc[key] = value.value;
        } else if (key === 'products') {
          acc[key] = Array.isArray(value) ? value : [];

          // Build product_data with updated rate & quantity
          acc['product_data'] = selectedProducts.map((prod: any) => {
            const rate =
              productRates[prod.product_id] !== undefined
                ? productRates[prod.product_id]
                : prod.rate;

            const quantity =
              productQuantities[prod.product_id] !== undefined
                ? productQuantities[prod.product_id]
                : 1;

            return {
              product_id: prod.product_id,
              id: prod.id,
              description: prod.description,
              rate,
              quantity,
              total_rate:
                rate !== null && quantity !== null ? rate * quantity : null,
            };
          });

          // For packages
          acc['package_data'] = selectedPackages.map((prod: any) => {
            const rate =
              packageRates[prod.product_id] !== undefined
                ? packageRates[prod.product_id]
                : prod.rate;

            const quantity =
              packageQuantities[prod.product_id] !== undefined
                ? packageQuantities[prod.product_id]
                : 1;

            return {
              product_id: prod.product_id,
              id: prod.id,
              description: prod.description,
              rate,
              quantity,
              total_rate:
                rate !== null && quantity !== null ? rate * quantity : null,
            };
          });
        }
          else if (key === 'built_in_fields') {
          if (Object.keys(value).length > 0) {
            acc['built_in_fields'] = Object.keys(value).reduce((fieldsAcc: any, fieldKey) => {
              const fieldValue = value[fieldKey];
              fieldsAcc[fieldKey] = fieldValue && fieldValue.isValid ? fieldValue.format('YYYY-MM-DD') : fieldValue;
              return fieldsAcc;
            }, {});
          }
        } else if (key === 'primary_fields') {
          if (Object.keys(value).length > 0) {
            acc['primary_field'] = Object.keys(value).reduce((fieldsAcc: any, fieldKey) => {
              const fieldValue = value[fieldKey];
              fieldsAcc[fieldKey] = fieldValue && fieldValue.isValid ? fieldValue.format('YYYY-MM-DD') : fieldValue;
              return fieldsAcc;
            }, {});
          }
        }
        else if (
          value !== null &&
          value !== undefined &&
          value !== "" &&
          !(Array.isArray(value) && value.every((item) => item === null || item === ""))
        ) {
          if (typeof value === "object" && value?.label) {
            acc[key] = value.value;
          } else if (key === 'contract_term' && Array.isArray(value)) {
            acc[key] = value.map((date: Dayjs | null) => (date ? date.format('MM-DD-YY') : null));
          } else if (key === 'effective_date' && value?.isValid) {
            acc[key] = value.format('MM-DD-YY');
          } else {
            acc[key] = value;
          }
        } else if (
          (key === 'address_line_1' || key === 'city' || key === 'state' || key === 'postal_code' || key === 'country') &&
          (value === null || value === undefined || value === '')
        ) {
          // If formData value is empty, use generalFields value if available
          const generalValue = generalFields?.address_vals?.[key];
          if (generalValue !== undefined && generalValue !== null && generalValue !== '') {
            acc[key] = generalValue;
          }
        }
        return acc;
      }, {});
      // const UpdatedTableData_ = UpdatedTableData && UpdatedTableData.length ? UpdatedTableData : tableData;
      

      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      let data: any = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        // path: cleanedData["create"] === "newService" ? "/add_customer_service" : "/service_line_creation_from_transfer_service",
        path: cleanedData["create"] === "newService"? "/add_customer_service": cleanedData["create"] === "transferService"? "/service_line_creation_from_transfer_service": cleanedData["create"] === "disconnectService"? "/disconnect_service_lines": "",

        role_name: role,
        module_name: cleanedData["create"] === "newService" ? "Customer Profile Services" : "Transfer Service-Services Table",
        feature_module_name: "Billing Platform",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        tenant_id: tenant_id_,
        main_module_name: "Customer Profiles",
        action: "create",
        modified_by: firstLastName,
        // changed_data: cleanedData,
        account_number: accountNumber,
      };
      if (cleanedData["create"] !== "newService" && cleanedData["create"] !== "disconnectService") {
        data.service_records_data = ReverseRowData;
      }
      if (cleanedData["create"] === "disconnectService") {
        let disconnectDataObj: Record<string, string> = {};
        const tableData = disconnectServiceData;

        // ✅ Case 1: tableData is an array of DisconnectItem objects
        if (Array.isArray(tableData) && typeof tableData[0] === "object" && tableData[0] !== null) {
          const missingDateRows = tableData.filter((row: any) => {
            const date = row.manual_disconnect_date;
            if (!date) return true;
            if (typeof date === "string") return date.trim() === "";
            if (date._isAMomentObject || date.$d) return !date.isValid?.();
            return false;
          });

          if (missingDateRows.length > 0) {
            Modal.error({
              title: "Validation Error",
              content: "Please enter a Disconnect Date for all selected services before submitting.",
              centered: true,
            });
            // isValid = false;
            return; // stop further execution if invalid
          }

          // Build disconnect_data object
          (tableData as DisconnectItem[]).forEach((item) => {
            const serviceId = String(item.id).split("-")[0];
            const formattedDate = item.manual_disconnect_date
              ? dayjs(item.manual_disconnect_date, [
                "MM-DD-YYYY HH:mm:ss",
                "MM-DD-YYYY",
                "MM-DD-YY",
                "YYYY-MM-DD",
              ]).format("YYYY-MM-DD")
              : "";
            disconnectDataObj[serviceId] = formattedDate;
          });
        }

        // ✅ Case 2: tableData is an object (e.g., { "3703-127-2": "11-04-2025 00:00:00" })
        else if (tableData && typeof tableData === "object" && !Array.isArray(tableData)) {
          const missingEntries = Object.entries(tableData).filter(([_, value]) => {
            if (!value) return true;
            if (typeof value === "string") return value.trim() === "";
            return false;
          });

          if (missingEntries.length > 0) {
            Modal.error({
              title: "Validation Error",
              content: "Please provide a Disconnect Date for all selected services before submitting.",
              centered: true,
            });
            // isValid = false;
            return;
          }

          Object.entries(tableData as Record<string, string>).forEach(([key, value]) => {
          const serviceId = key.split("-")[0];
          let formattedDate = "";

          if (value) {
            // If already ISO-like (YYYY-MM-DD), don’t reparse
            if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
              formattedDate = value;
            } else {
              const parsed = dayjs(value, [
                "MM-DD-YYYY HH:mm:ss",
                "MM-DD-YYYY",
                "MM-DD-YY",
                "YYYY-MM-DD",
              ], true); // ✅ strict parsing
              formattedDate = parsed.isValid() ? parsed.format("YYYY-MM-DD") : "";
            }
          }

          disconnectDataObj[serviceId] = formattedDate;
        });

        }

        // ✅ Assign the final disconnect_data
        data.disconnect_data = disconnectDataObj;
      }




        else{
          data.changed_data = cleanedData
        }
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200 && resp.flag === true) {
        if (resp?.validation) {
          setIsConfirmationOpen(false)
          Modal.error({
            title: "Validation Error",
            content: resp.message,
            centered: true,
          });
          return;
        }
        // callSyncSubmit(resp?.inserted_charge_dict || {})
        notification.success({
          message: 'Success',
          description: resp.message, // This is your success message from backend
          style: {
            fontSize: '14px',
            fontWeight: 'normal',
            padding: '16px',
          },
          placement: 'top',
        });
        fireSideCannons();

        // let parsedData: any;
        // try {
        //   setLoading(true);
        //   const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
        //   const data = {
        //     tenant_name: partner || "default_value",
        //     username: username,
        //     firstLastName: firstLastName,
        //     path: "/customer_services_list_view",
        //     role_name: role,
        //     account_number: accountNumber,
        //     parent_module: "Billing Platform",
        //     module_name: "Customer Services",
        //     table_name: "customer_services",
        //     mod_pages: {
        //       start: 0,
        //       end: 100,
        //     },
        //     request_received_at: getCurrentDateTime(),
        //     Partner: partner,
        //     access_token: token,            
        //     db_name: selectedDb,
        //     sessionID: sessionId,
        //     tenant_id:tenant_id_,
        //     feature_module_name: "Customer Services",
        //     main_module_name: "Customer Profiles",
        //   };

        //   const response = await axios.post(url, { data });
        //   parsedData = JSON.parse(response.data.body);

        //   if (parsedData.flag === true) {
        //     settabledata(parsedData?.data?.customer_services || []);
        //   }
        //   notification.success({
        //     message: 'Success',
        //     description: resp.message || '',
        //     style: {
        //       fontSize: '14px',
        //       fontWeight: 'normal',
        //       padding: '16px',
        //     },
        //     placement: 'top',
        //   });
        //   handleCancel();
        //   onClose();
        // } catch {
        //   const errorMsg = JSON.parse(response.data.body).message;
        // Modal.error({
        //   title: "Saving Error",
        //   content: errorMsg,
        //   centered: true,
        // });
        handleCancel()
        fetchdata();
        // } finally {
        //   setLoading(false);
        // }
      } else {
        const errorMsg = JSON.parse(response.data.body).message;
        Modal.error({
          title: "Saving Error",
          content: errorMsg,
          centered: true,
        });
        handleCancel()
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        onOk: handleCancel,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const isValid = validateForm();

    if (isValid) {
      setIsConfirmationOpen(true);
    }
  };

  const handleCancel = () => {
    setIsConfirmationOpen(false);
    setShowProductRow(false);
    setFormData({
      create: null,
      service_type: null,
      customer_services_id_list: null,
      provider: null,
      contract_term: [null, null],
      effective_date: null,
      accounts: '',
      services: null,
      dest_customer: null,
      products: [],
      packages: null,
      address_line_1: null,// Added 'packages' property
      city: null, // Added 'city' property
      state: null,
      postal_code: null,
      country: null,
      built_in_fields: {},
      custom_fields: {},
      primary_fields: {},
      msisdn: '',
      iccid: '',
      imei: '',
      eid: '',
      customer_rate_plan: null,
      custom_primary_field: null,
        apply_to_all: false,
    });
    setErrors({
      service_type: '',
      customer_services_id_list: '',
      provider: '',
      effective_date: '',
      accounts: '',
      products: '',
      packages: '',
      address_line_1: '',
      city: '',
      state: '',
      postal_code: '',
      country: '',
      dest_customer: '',
      contract_term: '',
      iccid: '',
      msisdn: '',
      imei: '',
      eid: '',
      customer_rate_plan: '',
      primary_field: ''
    });
    onClose();
    setHeaderMap({});
    setTableData([]);
    setHeaders([]);
    setNewServiceFields(false);
    setProductsFields(false);
    setTransferServicesFields(false);
    setPackageRates({});
    setProductRates({});
    setSelectedProducts([]);
    setSelectedPackages([]);
    setCustomerRatePlanOptions([])
    setPrimaryField('')

     setDisconnectServiceFields(false);
  setShowDisconnectTable(false);
  setDisconnectTableData([]);

  };

  // Fix postal_code input onChange key from 'postal-code' to 'postal_code'
  // Find the postal_code input and fix the onChange handler key

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const handleAddProduct = () => {
    setShowProductRow(true);
  };

  const modalWidth = typeof window !== "undefined"
    ? window.innerWidth <= 768
      ? (window.innerWidth * 3.5) / 4
      : (window.innerWidth * 2.5) / 4
    : 0;
  const modalHeight = typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
  // In your component:
  // const [modalHeight, setModalHeight] = useState(0);

  // useEffect(() => {
  //   // Function to compute modal height (e.g., 75% of current window height)
  //   const updateModalHeight = () => {
  //     if (typeof window !== "undefined") {
  //       // console.log("Window height:", window.innerHeight);
  //       if (window.innerHeight > 900) {
  //         setModalHeight(window.innerHeight * 0.85); // taller modal for big screens
  //       } else if (window.innerHeight > 700) {
  //         setModalHeight(window.innerHeight * 0.76);
  //       } else {
  //         setModalHeight(window.innerHeight * 0.72);  // smaller modal for small screens
  //       }
  //     }
  //   };

  //   updateModalHeight(); // set initially
  //   window.addEventListener("resize", updateModalHeight);

  //   return () => window.removeEventListener("resize", updateModalHeight);
  // }, []);
  if (!isOpen) return null;

  const handleConfirmCreate = async () => {
    await SubmitData(formData);
  };

  const validateForm = () => {
    let isValid = true;
    let newValidationErrors = {
      service_type: '',
      customer_services_id_list: '',
      provider: '',
      effective_date: '',
      accounts: '',
      products: '',
      packages: '',
      address_line_1: '',
      city: '',
      state: '',
      postal_code: '',
      country: '',
      dest_customer: '',
      contract_term: '',
      iccid: '',
      msisdn: '',
      imei: '',
      eid: '',
      customer_rate_plan: '',
      primary_field:''
    };

    const selectedOptionLabel = selectedOption.label;

    if (selectedOptionLabel === 'New Service') {
      if (!formData.service_type?.value) {
        newValidationErrors.service_type = 'Service Type is required.';
        isValid = false;
      }
      if (!formData.provider) {
        newValidationErrors.provider = 'Provider is required.';
        isValid = false;
      }
      // if (!formData.customer_rate_plan) {
      //   newValidationErrors.customer_rate_plan = 'Customer Rate Plan is required.';
      //   isValid = false;
      // }
      if (PrimaryField === 'ICCID' && !formData.primary_fields.iccid) {
        newValidationErrors.iccid = 'ICCID is required.';
        isValid = false;
      }
      if (PrimaryField === 'MSISDN' && !formData.primary_fields.msisdn) {
        newValidationErrors.msisdn = 'MSISDN is required.';
        isValid = false;
      }
      if (PrimaryField === 'IMEI' && !formData.primary_fields.imei) {
        newValidationErrors.imei = 'IMEI is required.';
        isValid = false;
      }
      if (PrimaryField === 'EID' && !formData.primary_fields.eid) {
        newValidationErrors.eid = 'EID is required.';
        isValid = false;
      }
      if(PrimaryField && !["ICCID", "MSISDN", "IMEI", "EID"].includes(PrimaryField) && !formData.custom_primary_field){
        newValidationErrors.primary_field = 'Please select a valid Primary Field.';
      }
      if (!formData.effective_date) {
        newValidationErrors.effective_date = 'Effective Date is required.';
        isValid = false;
      }
      if ((!formData.address_line_1 || formData.address_line_1 === '') && (!generalFields?.address_vals?.address_line_1 || generalFields.address_vals.address_line_1 === '')) {
        newValidationErrors.address_line_1 = 'Address is required.';
        isValid = false;
      }
      if ((!formData.city || formData.city === '') && (!generalFields?.address_vals?.city || generalFields.address_vals.city === '')) {
        newValidationErrors.city = 'City is required.';
        isValid = false;
      }
      const state_ = stateOptions.find((opt: { value: any; }) => opt.value === (formData.state || generalFields?.address_vals?.state)) || null
      if (!state_) {
        newValidationErrors.state = 'State is required.';
        isValid = false;
      }
      if ((!formData.postal_code || formData.postal_code === '') && (!generalFields?.address_vals?.postal_code || generalFields.address_vals.postal_code === '')) {
        newValidationErrors.postal_code = 'Postal Code is required.';
        isValid = false;
      }
      if ((!formData.country || formData.country === '') && (!generalFields?.address_vals?.country || generalFields.address_vals.country === '')) {
        newValidationErrors.country = 'Country is required.';
        isValid = false;
      }
      if (formData.postal_code) {
        const postalCodeRegex = /^\d{5}$/;
        if (!postalCodeRegex.test(formData.postal_code)) {
          newValidationErrors.postal_code = 'Postal Code must be exactly 5 digits.';
          isValid = false;
        }
      }
      if (formData.primary_fields.iccid) {
        const iccid = formData.primary_fields.iccid as string;
        if (!/^\d+$/.test(iccid) || iccid.length < 14 || iccid.length > 22) {
          newValidationErrors.iccid = 'ICCID must only contain numbers and be between 14 and 22 digits.';
          isValid = false;
        }
      }
      if (formData.primary_fields.msisdn) {
        const msisdn = formData.primary_fields.msisdn as string;
        if (!/^\d+$/.test(msisdn)) {
          newValidationErrors.msisdn = 'MSISDN must only contain numbers.';
          isValid = false;
        }
        else if (msisdn.length < 10 || msisdn.length > 15) {
          newValidationErrors.msisdn = 'MSISDN must be between 10 and 15 digits.';
          isValid = false;
        }
      }
      if (formData.primary_fields.imei) {
        const imei = formData.primary_fields.imei as string;
        if (!/^\d+$/.test(imei)) {
          newValidationErrors.imei = 'IMEI must only contain numbers.';
          isValid = false;
        }
        else if (imei.length !== 15) {
          newValidationErrors.imei = 'IMEI must be exactly 15 digits.';
          isValid = false;
        }
      }
      if(selectedProducts.length === 0 && selectedPackages.length === 0){
     Modal.error({
          title: "Validation Error",
          content:"Please fill all the mandatory fields",
          centered: true,
        });
      isValid = false;
    }
    } 
    else if (selectedOptionLabel === 'Transfer Service') {
      // if (!formData.customer_services_id_list) {
      //   newValidationErrors.customer_services_id_list = 'Service Type is required.';
      //   isValid = false;
      // }
      if (!formData.effective_date) {
        newValidationErrors.effective_date = 'Effective Date is required.';
        isValid = false;
      }
      if (transferServicesFields && !formData.dest_customer) {
        newValidationErrors.dest_customer = 'Destination Customer is required.';
        isValid = false;
      }
      if (tableData?.length > 0 && ReverseRowData?.length === 0) {
        Modal.error({
          title: 'Error',
          content: 'Please select at least one service to proceed with the transfer',
          centered: true,
        });
        isValid = false;
      } else if ((tableData?.length === 0 || !tableData) && (ReverseRowData?.length === 0 || !ReverseRowData)) {
        Modal.error({
          title: 'Error',
          content: 'No active services available for transfer',
          centered: true,
        });
        isValid = false;
      }

    } else if (selectedOptionLabel === 'Products') {
      if (!formData.service_type) {
        newValidationErrors.service_type = 'Service Type is required.';
        isValid = false;
      }
      if (formData.products.length === 0) {
        newValidationErrors.products = 'At least one product must be selected.';
        isValid = false;
      }
    }
    if (selectedOptionLabel === "Disconnect Service") {
      let disconnectDataObj: Record<string, string> = {};
      const tableData_ = disconnectServiceData;

      console.log("disconnectServiceData in validateForm:", disconnectServiceData);
      console.log("Type of disconnectServiceData:", typeof disconnectServiceData);
      console.log("Is array?:", Array.isArray(disconnectServiceData));

      // ❌ Reject if it's missing, empty, or an array of service objects
      if (
        !tableData_ ||
        (Array.isArray(tableData_) && tableData_.length > 0) || // reject all arrays
        (typeof tableData_ === "object" &&
          !Array.isArray(tableData_) &&
          Object.keys(tableData_).length === 0) // reject empty object
      ) {
        Modal.error({
          title: "Validation Error",
          content: "Please select at least one service before submitting.",
          centered: true,
        });
        isValid = false;
        return isValid;
      }

      // ✅ Allow only object format { id: date }
      if (typeof tableData_ === "object" && !Array.isArray(tableData_)) {
        const entries = Object.entries(tableData_);

        if (entries.length === 0) {
          Modal.error({
            title: "Validation Error",
            content: "Please select at least one service before submitting.",
            centered: true,
          });
          isValid = false;
          return isValid;
        }

        // ❌ Reject if any disconnect date is missing, blank, or invalid
        const invalidEntries = entries.filter(([_, value]) => {
          if (!value) return true; // missing or undefined
          if (typeof value === "string") {
            const trimmed = value.trim();
            if (trimmed === "" || trimmed.toLowerCase() === "invalid date") {
              return true;
            }
          }
          return false;
        });

        if (invalidEntries.length > 0) {
          Modal.error({
            title: "Validation Error",
            content: "Please provide a Disconnect Date for all selected services before submitting.",
            centered: true,
          });
          isValid = false;
          return isValid;
        }

        // ✅ Build disconnectDataObj only from valid {id: date} entries
        entries.forEach(([key, value]) => {
          const serviceId = key.split("-")[0];
          let formattedDate = "";

          let dateValue: string | number | Date | dayjs.Dayjs | null | undefined = null;

          if (typeof value === "string" || value instanceof Date) {
            dateValue = value;
          } else if (value && typeof value === "object" && "$d" in value) {
            // Unwrap internal JS Date from Dayjs-like object
            dateValue = (value as { $d: Date }).$d;
          }

          if (dateValue) {
            const formatted = dayjs(dateValue).format("YYYY-MM-DD");
            // Double check it's valid before storing
            if (formatted !== "Invalid Date") {
              formattedDate = formatted;
            }
          }

          disconnectDataObj[serviceId] = formattedDate;
        });
      } else {
        // ❌ Everything else (numbers, strings, arrays, etc.)
        Modal.error({
          title: "Validation Error",
          content: "Invalid data format. Expected { service_id: date } format.",
          centered: true,
        });
        isValid = false;
        return isValid;
      }
    }




    

    setErrors(newValidationErrors);
    return isValid;
  };

  const handleChange = (key: any, selected: any) => {
    setSelectedOption(selected);
    setShowProductRow(false);
    setFormData({
      create: selected,
      service_type: null,
      customer_services_id_list: null,
      provider: null,
      contract_term: [null, null],
      effective_date: null,
      accounts: '',
      services: null,
      dest_customer: null,
      products: [],
      packages: [],
      address_line_1: null,
      city: null,
      state: null,
      postal_code: null,
      country: null,
      built_in_fields: {},
      custom_fields: {},
      primary_fields: {},
      msisdn: '',
      iccid: '',
      imei: '',
      eid: '',
      customer_rate_plan: null,
      custom_primary_field: null,
        apply_to_all: false,

    });
    setErrors({
      service_type: '',
      customer_services_id_list: '',
      provider: '',
      effective_date: '',
      accounts: '',
      products: '',
      packages: '',
      address_line_1: '',
      city: '',
      state: '',
      postal_code: '',
      country: '',
      dest_customer: '',
      contract_term: '',
      iccid: '',
      msisdn: '',
      imei: '',
      eid: '',
      customer_rate_plan: '',
      primary_field:''
    });
    setSelectedPackages([])
    setSelectedProducts([])
    setNewServiceFields(false);
    setProductsFields(false);
    setTransferServicesFields(false);
    setDisconnectServiceFields(false);
    setShowDisconnectTable(false);
    switch (selected?.label) {
      case 'New Service':
        setNewServiceFields(true);
        setProductsFields(false);
        setTransferServicesFields(false);
        break;
      case 'Products':
        setProductsFields(true);
        setNewServiceFields(false);
        setTransferServicesFields(false);
        break;
      case 'Transfer Service':
        setTransferServicesFields(true);
        setNewServiceFields(false);
        setProductsFields(false);
        break;
       case 'Disconnect Service':
        setDisconnectServiceFields(true);
        setNewServiceFields(false);
        setProductsFields(false);
        setTransferServicesFields(false);
        setShowDisconnectTable(false);
        handleDisconnectDateChange()
        break;

      default:
        setNewServiceFields(false);
        setProductsFields(false);
        setTransferServicesFields(false);
          setDisconnectServiceFields(false);
      setShowDisconnectTable(false);
        break;
    }
  };

  const handleInputChange = (key: any) => (e: any) => {
    const value = e.target.value;
    setFormData({ ...formData, [key]: e.target.value });
    if (e.target.value) {
      setErrors(prev => ({
        ...prev,
        [key]: '',
      }));
    }
    if (key === 'postal_code') {
      if (!value) {
        setErrors(prev => ({
          ...prev,
          postal_code: 'Postal Code is required.',
        }));
      } else if (!/^\d+$/.test(value)) {
        setErrors(prev => ({
          ...prev,
          postal_code: 'Postal Code must only contain numbers.',
        }));
      } else if (value.length !== 5) {
        setErrors(prev => ({
          ...prev,
          postal_code: 'Postal Code must be exactly 5 digits.',
        }));
      } else {
        setErrors(prev => ({
          ...prev,
          postal_code: '',
        }));
      }
    }
    if (key === 'address_line_1') {
      if (!value) {
        setErrors(prev => ({
          ...prev,
          address_line_1: 'Address is required.',
        }));
      } else {
        setErrors(prev => ({
          ...prev,
          address_line_1: '',
        }));
      }
    }
    if (key === 'country') {
      if (!value) {
        setErrors(prev => ({
          ...prev,
          country: 'Country is required.',
        }));
      } else {
        setErrors(prev => ({
          ...prev,
          country: '',
        }));
      }
    } else {
      if (value) {
        setErrors(prev => ({
          ...prev,
          [key]: '',
        }));
      }
    }
  };
  const FetchPrimaryByServiceType = async (serviceType: string) => {
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_products_packages_by_service_type",
        role_name: role,
        account_number: accountNumber,
        parent_module: "Billing Platform",
        module_name: "Customer Services",
        table_name: "customer_services",
        service_type: serviceType,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        customer_rate_plan:formData?.customer_rate_plan?.value,
        main_module_name: "Customer Profiles",
        feature_module_name: "Customer Services",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        console.log("parsedData:", parsedData);
        setProductPackageData(parsedData);
        setPrimaryField(parsedData?.primary_field)
        setBuiltInFields(parsedData?.built_in_fields || {})
        setCustomerRatePlanOptions(parsedData?.customer_rate_plan.map((item:string)=> ({
          label:item,
          value:item
        }))
        )
        setProviderOptions(parsedData?.service_providers?.map((item:string) => ({
           label:item,
          value:item
        }))
        )
        
        setCustomFields(parsedData?.custom_fields || {})
        const normalizeFields = (fields: any) => {
          const normalized: Record<string, string> = {};
          Object.keys(fields).forEach((key) => {
            if (fields[key]?.field) {
              // If format is { field, type }
              normalized[fields[key].field] = "";
            } else {
              // If already key-value
              normalized[key] = fields[key];
            }
          });
          return normalized;
        };

        // When setting parsed data into formData
        setFormData((prev) => ({
          ...prev,
          custom_fields: normalizeFields(parsedData?.custom_fields || {}),
          built_in_fields: normalizeFields(parsedData?.built_in_fields || {}),
           service_type_id: parsedData.service_type_id
            ? parsedData.service_type_id
            : null,
        }));
        const for_new_service_ = parsedData?.built_in_fields || {}
        dropdownValues["for_new_service"][serviceType] = for_new_service_
        // -------- PRODUCTS --------
        if (parsedData.products && Object.keys(parsedData.products).length > 0) {
          const productOptionsFromApi = Object.keys(parsedData.products).map(key => ({
            label: key,   // show the key itself
            value: key,   // use key as value
          }));
          const productKeys = productOptionsFromApi.map(opt => opt.value);

          setProductOptions(productOptionsFromApi);
          setPackageOptions([]);
          // setSelectedPackages([]);
          // setSelectedProducts(productKeys);
        }

        // -------- PACKAGES --------
        if (parsedData.packages && Object.keys(parsedData.packages).length > 0) {
        const packageOptionsFromApi = Object.keys(parsedData.packages).map(pkgKey => ({
        label: pkgKey,   // e.g. "48-testing for format_"
        value: pkgKey,   // use the key itself as value
      }));

      const packageKeys = packageOptionsFromApi.map(opt => opt.value);

          setPackageOptions(packageOptionsFromApi);
          // setSelectedPackages(packageKeys);

        
        }
      }
      else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  }
  const FetchPrimaryFieldDetails = async (primaryKey: any) => {
    let parsedData: any;
    const primaryValue = formData?.primary_fields?.[primaryKey] || ""
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_customer_rate_plan_details_by_service_type",
        role_name: role,
        account_number: accountNumber,
        parent_module: "Billing Platform",
        module_name: "Customer Services",
        table_name: "customer_services",
        service_type: formData?.service_type?.value || "",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: "Customer Profiles",
        feature_module_name: "Customer Services",
        primary_key: primaryKey || "",
        primary_value: primaryValue || "",
        customer_rate_plan:formData.customer_rate_plan?.label ?? null
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        console.log("parsedData:", parsedData);
        const customer_plan_options = parsedData?.customer_rate_plan || []
        const customerRatePlanOptions_ = customer_plan_options
          ? customer_plan_options.map((item: string) => ({
            label: item,
            value: item,
          }))
          : [];
        // setCustomerRatePlanOptions(customerRatePlanOptions_)
        setFormData(prev => ({
          ...prev,
          provider: parsedData.service_provider_name
            ? parsedData.service_provider_name
            : null,
            service_type_id: parsedData.service_type_id
            ? parsedData.service_type_id
            : null,
        }));
        // Clear validation errors when values are set programmatically
        setErrors(prev => ({
          ...prev,
          provider: parsedData.service_provider_name ? '' : prev.provider,
          // You can also clear other related errors if needed
        }));

      }
      else {
        setLoading(false);
        console.log("flag set to false")
        if(parsedData.validation){
        Modal.error({
          title: "Validation Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
         setFormData(prev => ({
          ...prev,
          provider: null,
        }));
        }
        else{
          Modal.error({
            title: "Data Fetch Error",
            content: parsedData.message || "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        }
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  }
  const FetchProductPackageOptions = async (ratePlanType: string) => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_customer_rate_plan_details",
        role_name: role,
        account_number: accountNumber,
        parent_module: "Billing Platform",
        module_name: "Customer Services",
        table_name: "customer_services",
        customer_rate_plan: ratePlanType,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: "Customer Profiles",
        feature_module_name: "Customer Services",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        console.log("parsedData:", parsedData);
        setProductPackageData(parsedData);
        // setServiceTypeID(parsedData?.service_type_id)
        FetchPrimaryByServiceType(parsedData.service_type)
        setFormData(prev => ({
          ...prev,
          service_type: parsedData.service_type
            ? { label: parsedData.service_type, value: parsedData.service_type }
            : null,
        }));
        // setFormData(prev => ({
        //   ...prev,
        //   provider: parsedData.service_provider_name
        //     ?  parsedData.service_provider_name 
        //     : null,
        // }));

        // Determine if products exist and are non-empty
        const hasProducts = !parsedData.packages && parsedData.products && Array.isArray(parsedData.products) && parsedData.products.length > 0;
        const hasPackages = parsedData.packages && parsedData.packages !== null && parsedData.packages !== "";
        if (hasProducts) {
          // Map products keys for options and selectedProducts
          const productOptionsFromApi = parsedData.products.map((prod: any) => ({
            label: `${prod.product_id} - ${prod.description}`,
            value: String(prod.product_id),
          }));
          const productKeys = productOptionsFromApi.map((opt: { value: any; }) => opt.value); // Use full "id - desc"
          setProductOptions(productOptionsFromApi);
          console.log("productKeys", productKeys)
          setSelectedProducts(parsedData.products);
          setFormData(prev => ({
            ...prev,
          products:parsedData?.product,
            packages: [],
          }));
          setProductsFields(true);
          setPackageOptions([]);
          setSelectedPackages([]);
        } else if (hasPackages) {

          const packageOptionsFromApi = parsedData.packages
            ? [
              {
                label: parsedData.packages,
                value: parsedData.packages,
              },
            ]
            : [];
          const packageKeys = packageOptionsFromApi.map((opt: { value: any; }) => opt.value);
          setPackageOptions(packageOptionsFromApi);
          setSelectedPackages(parsedData?.products);
          setFormData(prev => ({
            ...prev,
            packages: parsedData?.packages,
            products: [],
          }));
          setProductsFields(false);
          setSelectedProducts([]);
          setProductOptions([]);
        }
        else {
          Modal.error({
            title: "Error",
            content: "No products or packages available",
            centered: true
          })
          setFormData(prev => ({
            ...prev,
            customer_rate_plan: null
          }));

        }

        // setPrimaryField(parsedData?.primary_field);
      }
      else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  }

  const fetchServiceLinesData = async (customername: any) => {
    settabledata([]);
    // setTableData([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/transfer_service_date_validation",
        role_name: role,
        account_number: accountNumber,
        parent_module: "Billing Platform",
        module_name: "Transfer Service-Services Table",
        table_name: "customer_services",
        dest_customer: customername,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: "Customer Profiles",
        feature_module_name: "Customer Services",
      };

      const response = await axios.post(url, { data });
      // console.log(response)
      parsedData = JSON.parse(response.data.body);
      // console.log(parsedData)

      if (parsedData.flag === true) {
        if (parsedData.validation) {
          Modal.error({
            title: "Validation Error",
            content: parsedData.message || "An error occurred while fetching data. Please try again.",
            centered: true,
            onOk: () => {
              handleCancel();
            }
          })
        }
        setLoading(false);
        // console.log("parsedData:", parsedData);

        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Transfer Service-Services Table"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setModuleFeatures(parsedData?.header_map?.["Transfer Service-Services Table"]?.module_features || []);
          // const createModalData_ = parsedData?.header_map?.["Billing Charge By Service"]?.pop_up || []

          // setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.service_records_data || []);



        }, 0);
      }
      else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  }
  const handleSelectChange = (key: keyof FormData) => (selectedValues: any) => {
    console.log("formadata", formData)
    if (selectedValues === null) {
      setFormData(prev => ({
        ...prev,
        [key]: null,
      }));
      setSelectedPackages([])
      setSelectedProducts([])
    if (key === "service_type") {
      setProductOptions([])
      setPackageOptions([])
      setFormData(prev => ({
        ...prev,
        customer_rate_plan:null,
      }))
    }
       if (dropdownValues?.customer_rate_plan) {
      setCustomerRatePlanOptions(
        dropdownValues.customer_rate_plan.map((item: string) => ({
          label: item,
          value: item,
        }))
      );
    }
    }
    if (key === "service_type") {
      setFormData(prev => ({
        ...prev,
        service_type: selectedValues,
        customer_rate_plan:null,
        provider:null,
        products: [],
        packages: [],
        built_in_fields: {},
        primary_fields:{iccid:'',msisdn:'',imei:'',eid:''},
      }));
      setSelectedProducts([]);
      setSelectedPackages([]);
      setErrors(prev => ({
        ...prev,
        service_type: '',
        // products: '',
        // packages: '',
      }));
      if(selectedValues?.value){
        FetchPrimaryByServiceType(selectedValues?.value || '');
      }

    }
    else if (key === "products") {
      const newProductValues = selectedValues.map((val: any) => String(val));

      // Normalize products: extract objects with consistent shape
      const selectedProdsArray = newProductValues.map((val: string | number) => {
        const prod = productPackageData.products[val];
        return {
          product_id: val,                 // use key (like "102-Upload1")
          id: prod.id,
          description: prod.description,
          rate: prod.rate,
        };
      });

      setFormData(prev => ({
        ...prev,
        products: newProductValues,
        packages: [],
      }));

      console.log("newProductValues", newProductValues);
      console.log("selectedProdsArray", selectedProdsArray);

      setSelectedProducts(selectedProdsArray); // always array
      setErrors(prev => ({
        ...prev,
        products: '',
        packages: '',
      }));
    }

    else if (key === "packages") {
  const newPackageValues = selectedValues.map((val: any) => String(val));

  // Flatten the selected packages into a single array of products
  const normalizedPackages = newPackageValues.flatMap((packageKey: string | number) => {
    const items = productPackageData.packages[packageKey] || [];
    return items.map((item: any) => ({
      product_id: item.id,
      description: item.description,
      rate: item.rate,
    }));
  });

  setFormData(prev => ({
    ...prev,
    packages: newPackageValues,
    products: [],
  }));
  console.log("normalizedPackages",normalizedPackages)
  setSelectedPackages(normalizedPackages); // ✅ normalized directly

  setErrors(prev => ({
    ...prev,
    products: '',
    packages: '',
  }));
}



    else if (key === "dest_customer") {
      const dest_customer_ = selectedValues?.label;

      setFormData(prev => ({
        ...prev,
        dest_customer: dest_customer_
      }));
      if (dest_customer_ !== null) {
        fetchServiceLinesData(selectedValues?.value)
      }
    }
    else if (key === "customer_rate_plan") {
      setFormData(prev => ({
        ...prev,
        customer_rate_plan: selectedValues
      }));
      if (selectedValues !== null) {
        FetchProductPackageOptions(selectedValues?.value || '');
      }
      else {
        setProductPackageData(null);
        setSelectedPackages([]);
        setFormData(prev => ({
          ...prev,
          service_type: null,
          packages: null,
          products: [],
          primary_fields:{}
        }));
      }
    }
    else {
      const value = selectedValues?.value ?? selectedValues;
      setFormData(prev => ({
        ...prev,
        [key]: value,
      }));
      if (value) {
        setErrors(prev => ({
          ...prev,
          [key]: '',
        }));
      }
    }
  };


  const handleContractTermChange = (dates: [Dayjs | null, Dayjs | null] | null, dateStrings: [string, string]) => {
    if (dates && dates.length === 2) {
      setFormData((prevState) => ({
        ...prevState,
        contract_term: dates,
      }));
      setErrors(prev => ({
        ...prev,
        contract_term: '',
      }));
    } else {
      setFormData((prevState) => ({
        ...prevState,
        contract_term: [null, null],
      }));
    }
  };

const handleDisconnectDateChange = async () => {
  // setFormData((prev) => ({ ...prev, effective_date: date }));

  
  //   //  Clear "Apply to all" checkbox when new date selected
  // setApplyToAll(false);
  // setFormData((prev) => ({ ...prev, apply_to_all: false }));

  //  Reset the disconnect_effective_date in all rows
  if (disconnectTableData.length > 0) {
    const clearedData = disconnectTableData.map((row) => ({
      ...row,
      disconnect_effective_date: null,
    }));
    setDisconnectTableData(clearedData);
  }


  try {
    setLoading(true);
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";

    const data = {
      tenant_name: partner || "default_value",
      username,
      firstLastName,
      path: "/account_active_services_details",
      role_name: role,
      account_number: accountNumber,
      parent_module: "Billing Platform",
      module_name: "Disconnect Service",
      main_module_name: "Customer Profiles",
      table_name: "customer_services",
      // effective_date: date.format("YYYY-MM-DD HH:mm:ss"),
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
billing_db_name: selectedBillingDb,
      tenant_id: tenant_id_,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);

    const resultData =
      parsedData?.data?.account_active_services_details ||
      parsedData?.data ||
      [];
    if (Array.isArray(resultData) && resultData.length > 0) {
          const headersMap_ = parsedData?.header_map?.["Disconnect Service-Services Table"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setModuleFeatures(parsedData?.header_map?.["Disconnect Service-Services Table"]?.module_features || []);
          // const createModalData_ = parsedData?.header_map?.["Billing Charge By Service"]?.pop_up || []

          // setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data || []);
      setDisconnectTableData(resultData);
      setShowDisconnectTable(true);
    } else {
      setShowDisconnectTable(false);
      Modal.info({
        title: "No Active Services Found",
        content: "There are no active services available for disconnection.",
        centered: true,
      });
    }
  } catch (err) {
    console.error("Error fetching disconnect table data:", err);
    Modal.error({
      title: "Error",
      content: "Failed to load disconnect service details. Please try again.",
      centered: true,
    });
  } finally {
    setLoading(false);
  }
};

console.log("DISCONNECT RESPONSE:", `parsedData`);

// When "Apply to all" is checked, fill all rows with the selected effective date
const handleApplyToAllChange = (e: any) => {
  const checked = e.target.checked;
  setFormData((prev) => ({ ...prev, apply_to_all: checked }));
  setApplyToAll(checked);

  if (checked && formData.effective_date) {
    const effectiveDate = dayjs(formData.effective_date).format("YYYY-MM-DD");

    // 1️⃣ Detect if current data is object or array
    const isObjectFormat =
      disconnectServiceData &&
      typeof disconnectServiceData === "object" &&
      !Array.isArray(disconnectServiceData);

    const isArrayFormat =
      Array.isArray(disconnectServiceData) &&
      disconnectServiceData.length > 0 &&
      typeof disconnectServiceData[0] === "object";

    // 2️⃣ If it’s object format {id: date}
    if (isObjectFormat) {
      console.log("🔍 Detected object format {id: date}");

      // Validate if current data looks like proper ID-date map
      const isValidIdDateFormat = Object.entries(
        disconnectServiceData
      ).every(([key, value]) => {
        const isValidKey = !isNaN(Number(key));

        let isValidValue = false;
        if (typeof value === "string" && value.trim() !== "") {
          isValidValue = dayjs(value, ["YYYY-MM-DD", "MM-DD-YYYY", "MM-DD-YY"], true).isValid();
        } else if (dayjs.isDayjs(value)) {
          isValidValue = value.isValid();
        } else if (value instanceof Date) {
          isValidValue = !isNaN(value.getTime());
        } else if (typeof value === "object" && value !== null && "$d" in value) {
          const v = value as { $d?: unknown };
          if (v.$d instanceof Date) isValidValue = !isNaN(v.$d.getTime());
        }

        return isValidKey && (isValidValue || value === "");
      });

      if (isValidIdDateFormat) {
        // ✅ Build new object with same IDs, updated date
        const updatedDisconnectData: Record<string, string> = {};
        Object.keys(disconnectServiceData).forEach((id) => {
          updatedDisconnectData[id] = effectiveDate;
        });

        // Update all table rows too
        const updatedTable = tableData.map((row: any) => ({
          ...row,
          manual_disconnect_date: formData.effective_date,
        }));

        setTableData(updatedTable);
        setDisconnectTableData(updatedTable);
        setDisconnectServiceData(updatedDisconnectData);

        console.log("✅ Updated (object format):", updatedDisconnectData);
      } else {
        console.warn("⚠️ Invalid {id: date} format — clearing.");
        setDisconnectServiceData({});
      }
    }

    // 3️⃣ If it’s array of row objects
    else if (isArrayFormat) {
      console.log("🔍 Detected array format [ {id, manual_disconnect_date, ...} ]");

      const updatedArray = disconnectServiceData.map((row: any) => ({
        ...row,
        manual_disconnect_date: formData.effective_date,
      }));

      // Convert to object { id: formattedDate }
      const updatedObject: Record<string, string> = {};
      updatedArray.forEach((row: any) => {
        updatedObject[row.id] = effectiveDate;
      });

      setTableData(updatedArray);
      setDisconnectTableData(updatedArray);
      setDisconnectServiceData(updatedObject);

      console.log("✅ Updated (array format):", updatedObject);
    }

    // 4️⃣ Otherwise — unknown data type
    else {
      console.warn("⚠️ Unknown disconnectServiceData format — resetting.");
      setDisconnectServiceData({});
    }
  }
  // Optionally reset if unchecked
  // else if (!checked) {
  //   setDisconnectServiceData({});
  // }
};




  const serviceTypeOptions = dropdownValues?.service_type
    ? (dropdownValues.service_type).map((opt: any) => ({
      label: opt,
      value: opt,
    }))
    : [];
  const newServiceTypeOptions = dropdownValues?.for_new_service
    ? Object.keys(dropdownValues.for_new_service).map((key) => ({
      label: key,
      value: key,
    }))
    : [];
  // const customerRatePlanOptions = dropdownValues?.customer_rate_plan
  //   ? dropdownValues.customer_rate_plan.map((item: string) => ({
  //     label: item,
  //     value: item,
  //   }))
  //   : [];
  const customerServicesIdListOptions = dropdownValues?.customer_services_id_list
    ? Object.keys(dropdownValues.customer_services_id_list).map((key) => ({
      label: dropdownValues.customer_services_id_list[key],
      value: dropdownValues.customer_services_id_list[key],
    }))
    : [];

  // const providerOptions = dropdownValues?.provider?.map((item: string) => ({
  //   label: item,
  //   value: item,
  // }));
  const stateOptions = dropdownValues?.state?.map((item: string) => ({
    label: item,
    value: item,
  }));

  const selectedServiceType = formData?.service_type?.value || null;
  // console.log(selectedServiceType, "Show .....");

  // const productOptions =
  // selectedOption?.label === 'New Service'
  //   ? dropdownValues?.products_
  //     ? [
  //         ...Object.keys(dropdownValues.products_.products || {})
  //       ].map((key: string) => ({
  //         label: key,
  //         value: key
  //       }))
  //     : []
  //   : selectedServiceType && dropdownValues?.service_type?.[selectedServiceType]
  //     ? dropdownValues.service_type[selectedServiceType].map((item: string) => ({
  //         label: item,
  //         value: item
  //       }))
  //     : Array.isArray(dropdownValues?.product)
  //       ? dropdownValues.product.map((item: string) => ({
  //           label: item,
  //           value: item
  //         }))
  //       : [];


  // const packageOptions = selectedOption?.label === 'New Service'
  // ? dropdownValues?.products_
  // ? [
  //     ...Object.keys(dropdownValues.products_.packages || {})
  //   ].map((key: string) => ({
  //     label: key,
  //     value: key
  //   }))
  // : []
  //   : selectedServiceType && dropdownValues?.service_type?.[selectedServiceType]
  //     ? dropdownValues?.service_type[selectedServiceType].map((item: string) => ({
  //         label: item,
  //         value: item,
  //       }))
  //     : Array.isArray(dropdownValues?.package)
  //       ? dropdownValues.package.map((item: string) => ({
  //           label: item,
  //           value: item,
  //         }))
  //       : [];

  // console.log("productOptions:", productOptions);

  const destCustomers = dropdownValues?.customer_names?.map((item: string) => ({
    label: item,
    value: item,
  }));

  const fetchProductsTableData = async () => {
    settabledata([]);
    let parsedData: any;
    const payload = {
      service_type: formData?.service_type?.value || null,
      product_type: formData?.products || [],
    };
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/customer_service_products_pop_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Product Packages",
        mod_pages: {
          start: 0,
          end: 100,
        },
        changed_data: payload,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Product Packages",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        setLoading(false);
        setTimeout(() => {
          setTableData((prevTableData: any) => {
            if (!prevTableData.length) {
              return parsedData?.data?.product_packages || [];
            }
            const oldTableData = [...prevTableData];
            const newTableData = parsedData?.data?.product_packages || [];
            const oldDataIds = new Set(oldTableData.map((row) => row.id));
            const newDataIds = new Set(newTableData.map((row: { id: any; }) => row.id));
            const addedRows = newTableData.filter((row: { id: any; }) => !oldDataIds.has(row.id));
            const unchangedRows = oldTableData.filter((row) => newDataIds.has(row.id));
            return [...unchangedRows, ...addedRows];
          });

          const headersMap_ = parsedData?.header_map?.["Product Packages"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          const createModalData_ = parsedData?.header_map?.["Product Packages"]?.pop_up || [];
          setProductsFields(createModalData_);
          setPagination(parsedData?.pages || {});
        }, 0);
      } else {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchNewServiceProductsTableData = async () => {
    settabledata([]);
    let parsedData: any;

    const payload = {
      products: formData?.products || [],

    };
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "Altaworx Test",
        username: username,
        firstLastName: firstLastName,
        path: "/products_list_view_in_add_service_pop",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Product Packages",
        mod_pages: {
          start: 0,
          end: 100,
        },
        products: formData?.products || [],
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Product Packages",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        setLoading(false);
        setTimeout(() => {
          setTableData((prevTableData: any) => {
            if (!prevTableData.length) {
              return parsedData?.data?.customer_services_products || [];
            }
            const oldTableData = [...prevTableData];
            const newTableData = parsedData?.data?.customer_services_products || [];
            const oldDataIds = new Set(oldTableData.map((row) => row.id));
            const newDataIds = new Set(newTableData.map((row: { id: any; }) => row.id));
            const addedRows = newTableData.filter((row: { id: any; }) => !oldDataIds.has(row.id));
            const unchangedRows = oldTableData.filter((row) => newDataIds.has(row.id));
            return [...unchangedRows, ...addedRows];
          });

          const headersMap_ = parsedData?.header_map?.["Product Packages"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          setPagination(parsedData?.pages || {});
          // console.log("New Service table data set:", parsedData?.data?.customer_services_products);
        }, 0);
      } else {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFilterLoad = (event: any) => {
    event.preventDefault();
    // console.log("Filter clicked, productsFields:", productsFields);
    if (selectedOption.label === 'New Service') {
      fetchNewServiceProductsTableData();
    } else {
      fetchProductsTableData();
    }
  };

  const ProductsMultiSelect = ({ label = "Products" }: { label?: string }) => (
    <div className={`${!!formData.customer_rate_plan? "custom-disabled-antd-select" : ""}`}>
      <label className="field-label">{label}<span className="text-red-500">*</span></label>
      <Select
        mode="multiple"
        allowClear
        showSearch
        style={{ width: "100%" }}
        value={
          Array.isArray(formData.products)
            ? formData.products.map((v: any) => (typeof v === 'object' && v?.value ? v.value : v))
            : []
        }
        disabled={!!formData.customer_rate_plan}
        placeholder="Select products"
        options={productOptions.map((item: any) => ({
          label: String(item.label ?? ""),
          value: String(item.value ?? ""),
        }))}
        getPopupContainer={(triggerNode) => triggerNode.parentNode as HTMLElement}
        maxTagCount={1}
        maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
        tagRender={(props) => {
          const { label, closable, onClose } = props;
          const labelString = String(label);
          const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;

          const allSelectedLabels = Array.isArray(formData.products)
            ? formData.products
              .map((value: any) => {
                const option = productOptions.find((opt: any) => opt.value === (typeof value === 'object' ? value.value : value));
                return option?.label || value;
              })
              .join(', ')
            : '';

          return (
            <span
              className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap relative bg-white shadow-lg rounded-lg max-w-[185px] archive-summary-warning"
              title={allSelectedLabels}
              style={{
                maxWidth: '165px',
                wordWrap: 'break-word',
                overflow: 'hidden',
              }}
            >
              {truncatedLabel}
              {closable && (
                <CloseOutlined
                  onClick={onClose}
                  style={{ marginLeft: 4, cursor: 'pointer', color: 'black' }}
                />
              )}
            </span>
          );
        }}
        dropdownRender={(menu) => (
          <div
            className="relative bg-white shadow-lg rounded-lg max-w-full"
            style={{ maxHeight: "250px", overflowY: "auto" }}
          >
            <VirtualList
              data={productOptions}
              height={250}
              itemHeight={0}
              itemKey="value"
            >
              {(item) => {
                const isChecked = Array.isArray(formData.products)
                  ? formData.products.some((v: any) => (typeof v === 'object' ? v.value === item.value : v === item.value))
                  : false;

                return (
                  <div key={item.value} className="ml-2 mb-2 flex items-center">
                    <Checkbox
                      checked={isChecked}
                      onChange={(e) => {
                        const currentValues = Array.isArray(formData.products)
                          ? formData.products.map((v: any) => (typeof v === 'object' && v?.value ? v.value : v))
                          : [];
                        const newValues = e.target.checked
                          ? [...currentValues, item.value]
                          : currentValues.filter((v) => v !== item.value);
                        handleSelectChange('products')(newValues);
                      }}
                      disabled={formData?.packages.length > 0}
                    >
                      {item.label}
                    </Checkbox>
                  </div>
                );
              }}
            </VirtualList>
          </div>
        )}
        onChange={(value) => {
          if (value === undefined || value === null) {
            handleSelectChange('products')([]);
          } else {
            handleSelectChange('products')(value);

          }
        }}
      />
      {errors.products && <span className="text-red-500">{errors.products}</span>}
    </div>
  );

  const PackagesMultiSelect = ({ label = "Packages" }: { label?: string }) => (
    <div className={`${!!formData.customer_rate_plan? "custom-disabled-antd-select" : ""}`}>
      <label className="field-label">{label}<span className="text-red-500">*</span></label>
      <Select
        // mode="multiple"
        allowClear
        showSearch
        style={{ width: "100%" }}
        value={
          Array.isArray(formData.packages)
            ? (formData.packages as any[]).length > 0
              ? (typeof (formData.packages as any[])[0] === 'object' && (formData.packages as any[])[0]?.value
                ? (formData.packages as any[])[0].value
                : (formData.packages as any[])[0])
              : undefined
            : undefined
        }
        disabled={formData.customer_rate_plan}
        placeholder="Select packages"
        options={packageOptions.map((item: any) => ({
          label: String(item.label ?? ""),
          value: String(item.value ?? ""),
        }))}
        getPopupContainer={(triggerNode) => triggerNode.parentNode as HTMLElement}
        maxTagCount={1}
        maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
        tagRender={(props) => {
          const { label, closable, onClose } = props;
          const labelString = String(label);
          const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;

          const allSelectedLabels = Array.isArray(formData.packages)
            ? formData.packages
              .map((value: any) => {
                const option = packageOptions.find((opt: any) => opt.value === (typeof value === 'object' ? value.value : value));
                return option?.label || value;
              })
              .join(', ')
            : '';

          return (
            <span
              className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap relative bg-white shadow-lg rounded-lg max-w-[185px] archive-summary-warning"
              title={allSelectedLabels}
              style={{
                maxWidth: '165px',
                wordWrap: 'break-word',
                overflow: 'hidden',
              }}
            >
              {truncatedLabel}
              {closable && (
                <CloseOutlined
                  onClick={onClose}
                  style={{ marginLeft: 4, cursor: 'pointer', color: 'black' }}
                />
              )}
            </span>
          );
        }}

        onChange={(value) => {
          if (value === undefined || value === null) {
            handleSelectChange('packages')([]);
            setSelectedPackages([]);
            setPackageRates({});
          } else {
            console.log("dropdownValues.products_.packages:", productPackageData?.packages);
            // Set formData.packages to single selected package
            handleSelectChange('packages')([value]);
            // Set selectedPackages to related packages list for the selected package
            const relatedPackages = productPackageData?.packages?.[value] || [];
            const relatedPackageKeys = relatedPackages.map((_: any, idx: any) => `${value}__${idx}`);
            setSelectedProducts([])

            // setSelectedPackages(relatedPackageKeys.length > 0 ? relatedPackageKeys : [value]);
            // // Set package rates for related packages
            // const rates = Object.fromEntries(
            //   relatedPackages.map((pkg: any, idx: number) => [`${value}__${idx}`, pkg.rate ?? null])
            // );
            // setPackageRates(rates);

          }
        }}
      />
      {errors.packages && <span className="text-red-500">{errors.packages}</span>}
    </div>
  );

  if (loading2) {
    return (
      <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
        <div className='flex justify-center'>
          <Spin size="large" />
        </div>
      </div>
    );
  }

  return (
    <div>
      <Modal
        open={isOpen}
        onCancel={handleCancel}
        title={
          <h3 className='popup-heading'>
            {'Actions'}
          </h3>
        }
        centered
        footer={
          <div className="justify-center flex space-x-2 mt-2">
            <button onClick={handleCancel} className="cancel-btn">
              Cancel
            </button>
            {/* {newServiceFields && (
              <button onClick={handleAddProduct} className="save-btn">
                Add Product
              </button>
            )} */}
            <button onClick={handleSave} className="save-btn">
              Save
            </button>
          </div>
        }
        width={modalData.length > 5 ? modalWidth : '780px'}
        styles={{ body: { height: modalHeight, padding: "4px" } }}
        bodyStyle={{  minHeight: "400px", overflowY: "auto" }}
      >
        <div className={`${modalData.length > 5 ? 'popup' : ''}`}>

          <form onSubmit={handleSave}>
            {loading ? (
              <div className="flex justify-center items-center w-full h-full absolute top-0 left-0">
                <Spin size="large" />
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 w-full h-full">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-2">
                    {/* Create Dropdown */}
                    <div className="flex flex-col">
                      <Dropdown
                        options={options}
                        value={formData.create}
                        onChange={(selected: any) => handleChange('create', selected)}
                        placeholder="Choose your Action"
                      />

                    </div>

                    {newServiceFields && (
                      <>
                      <div className="flex flex-col">
                          <Dropdown
                            options={serviceTypeOptions}
                            value={formData.service_type}
                            onChange={handleSelectChange('service_type')}
                            placeholder="Service Type"
                            mandatory={true}
                            className="input"
                          // disabled
                          />
                          {errors.service_type && <span className="text-red-500">{errors.service_type}</span>}
                        </div>
                        <div className="flex flex-col">
                          <Dropdown
                            options={customerRatePlanOptions}
                            value={formData.customer_rate_plan}
                            onChange={handleSelectChange("customer_rate_plan")}
                            placeholder="Customer Rate Plan"
                            mandatory={false}
                            className="input"
                          />
                          {errors.customer_rate_plan && <span className="text-red-500">{errors.customer_rate_plan}</span>}
                        </div>
                        {PrimaryField === "ICCID" && (
                          <div className="flex flex-col">
                            <label className="field-label">ICCID <span className="text-red-500">*</span> </label>
                            <div className="flex w-full">
                              <Input
                                value={(formData.primary_fields.iccid as string) || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  setFormData((prev) => ({
                                    ...prev,
                                    primary_fields: { ...prev.primary_fields, iccid: value },
                                  }));
                                  if (/^\d{14,22}$/.test(value)) {
                                    setErrors((prev) => ({ ...prev, iccid: '' }));
                                  } else {
                                    setErrors((prev) => ({
                                      ...prev,
                                      iccid: 'ICCID must only contain numbers and be between 14 and 22 digits.',
                                    }));
                                  }
                                }}
                                placeholder="Enter ICCID"
                                className="input !w-[85%]"
                              />
                              <button
                                className="!w-[15%] border border-gray rounded-md p-[5px]"
                                onClick={() => FetchPrimaryFieldDetails("iccid")}>
                                <FunnelIcon className="w-5 h-5" />
                              </button>
                            </div>
                            {errors.iccid && <span className="text-red-500">{errors.iccid}</span>}
                          </div>)}
                        {PrimaryField === "MSISDN" && (
                          <div className="flex flex-col">
                            <label className="field-label">MSISDN <span className="text-red-500">*</span> </label>
                            <div className="flex w-full">
                              <Input
                                value={(formData.primary_fields.msisdn as string) || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  setFormData((prev) => ({
                                    ...prev,
                                    primary_fields: { ...prev.primary_fields, msisdn: value },
                                  }));
                                  if (/^\d+$/.test(value) && value.length === 10) {
                                    setErrors((prev) => ({ ...prev, msisdn: '' }));
                                  } else if (!/^\d+$/.test(value)) {
                                    setErrors((prev) => ({
                                      ...prev,
                                      msisdn: 'MSISDN must only contain numbers.',
                                    }));
                                  } else if (value.length < 10 || value.length > 15 ) {
                                    setErrors((prev) => ({
                                      ...prev,
                                      msisdn: 'MSISDN must be betweeen 10 to 15 digits.',
                                    }));
                                  }
                                }}
                                placeholder="Enter MSISDN"
                                className="input !w-[85%]" />
                              <button
                                className="!w-[15%] border border-gray rounded-md p-[5px]"
                                onClick={() => FetchPrimaryFieldDetails("msisdn")}>
                                <FunnelIcon className="w-5 h-5" />
                              </button>
                            </div>
                            {errors.msisdn && <span className="text-red-500">{errors.msisdn}</span>}
                          </div>)}
                        {PrimaryField === "IMEI" && (
                          <div className="flex flex-col">
                            <label className="field-label">IMEI <span className="text-red-500">*</span> </label>
                            <div className="flex w-full">
                              <Input
                                value={(formData.primary_fields.imei as string) || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  setFormData((prev) => ({
                                    ...prev,
                                    primary_fields: { ...prev.primary_fields, imei: value },
                                  }));
                                  if (/^\d+$/.test(value) && value.length === 10) {
                                    setErrors((prev) => ({ ...prev, imei: '' }));
                                  } else if (!/^\d+$/.test(value)) {
                                    setErrors((prev) => ({
                                      ...prev,
                                      imei: 'IMEI must only contain numbers.',
                                    }));
                                  } else if (value.length !== 15) {
                                    setErrors((prev) => ({
                                      ...prev,
                                      imei: 'IMEI must be exactly 15 digits.',
                                    }));
                                  }
                                }}
                                placeholder="Enter IMEI"
                                className="input !w-[85%]" />
                              <button
                                className="!w-[15%] border border-gray rounded-md p-[5px]"
                                onClick={() => FetchPrimaryFieldDetails("iccid")}>
                                <FunnelIcon className="w-5 h-5" />
                              </button>
                            </div>
                            {errors.imei && <span className="text-red-500">{errors.imei}</span>}
                          </div>)}
                        {PrimaryField === "EID" && (
                          <div className="flex flex-col">
                            <label className="field-label">EID <span className="text-red-500">*</span> </label>
                            <div className="flex w-full">
                              <Input
                                value={(formData.primary_fields.eid as string) || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  setFormData((prev) => ({
                                    ...prev,
                                    primary_fields: { ...prev.primary_fields, eid: value },
                                  }));
                                  if (/^\d+$/.test(value) && value.length === 10) {
                                    setErrors((prev) => ({ ...prev, eid: '' }));
                                  } else if (!/^\d+$/.test(value)) {
                                    setErrors((prev) => ({
                                      ...prev,
                                      imei: 'EID must only contain numbers.',
                                    }));
                                  } else if (value.length !== 10) {
                                    setErrors((prev) => ({
                                      ...prev,
                                      imei: 'EID must be exactly 10 digits.',
                                    }));
                                  }
                                }}
                                placeholder="Enter EID"
                                className="input !w-[85%]" />
                              <button
                                className="!w-[15%] border border-gray rounded-md p-[5px]"
                                onClick={() => FetchPrimaryFieldDetails("iccid")}>
                                <FunnelIcon className="w-5 h-5" />
                              </button>
                            </div>
                            {errors.eid && <span className="text-red-500">{errors.eid}</span>}
                          </div>)}
                      {PrimaryField && !["ICCID", "MSISDN", "IMEI", "EID"].includes(PrimaryField) && (
                          <div className="flex flex-col">
                            <label className="field-label">{PrimaryField}<span className="text-red-500">*</span> </label>
                            <div className="flex w-full">
                              <Input
                                value={(formData.custom_primary_field as string) || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  setFormData((prev) => ({
                                    ...prev,
                                    custom_primary_field: value || '',
                                    primary_fields:{...prev.primary_fields, [PrimaryField]: value || ''},
                                  }));
                                }}
                                placeholder="Enter Primary Field"
                                className="input" />
                              
                            </div>
                            {errors.primary_field && <span className="text-red-500">{errors.primary_field}</span>}
                          </div>)}
                        <div className="flex flex-col">
                          <Dropdown
                            options={providerOptions}
                            value={
                              formData?.provider
                                ? providerOptions.find((option: { value: any; }) => option.value === formData.provider)
                                : null
                            }
                            onChange={handleSelectChange('provider')}
                            placeholder="Provider"
                            mandatory={true}
                            className={["ICCID","MSISDN","IMEI","EID"].includes(PrimaryField) ? "non-editable-input cursor-not-allowed" : "input"}
                            disabled = {["ICCID","MSISDN","IMEI","EID"].includes(PrimaryField)}
                          />
                          {errors.provider && <span className="text-red-500">{errors.provider}</span>}
                        </div>
                        <div className="flex flex-col">
                          <label className="field-label">Contract Term</label>
                          <RangePicker
                            value={formData.contract_term as [Dayjs, Dayjs]}
                            onChange={handleContractTermChange}
                            className="input p-4"
                            format="MM-DD-YY"
                            placeholder={['Start Date', 'End Date']}
                            popupClassName="custom-range-popup"
                          />
                          {errors.contract_term && <span className="text-red-500">{errors.contract_term}</span>}
                        </div>
                        <div className="flex flex-col">
                          <label className="field-label">Effective Date <span className="text-red-500">*</span></label>
                          <DatePicker
                            value={formData.effective_date}
                            onChange={handleSelectChange('effective_date')}
                            placeholder="Select a date"
                            format="MM-DD-YY"
                            className="input"
                          />
                          {errors.effective_date && <span className="text-red-500">{errors.effective_date}</span>}
                        </div>
                        
                        <div className="flex flex-col">
                          <label className="field-label">Address <span className="text-red-500">*</span> </label>
                          <Input
                            value={formData.address_line_1 ?? generalFields?.address_vals?.address_line_1 ?? ''}
                            onChange={handleInputChange('address_line_1')}
                            placeholder="Enter Address"
                            className="input"
                          />
                          {errors.address_line_1 && <span className="text-red-500">{errors.address_line_1}</span>}
                        </div>
                        <div className="flex flex-col">
                          <label className="field-label">City <span className="text-red-500">*</span> </label>
                          <Input
                            value={formData.city ?? generalFields?.address_vals?.city ?? ''}
                            onChange={handleInputChange('city')}
                            placeholder="Enter City"
                            className="input"
                          />
                          {errors.city && <span className="text-red-500">{errors.city}</span>}
                        </div>
                        <div className="flex flex-col">
                          <Dropdown
                            options={stateOptions}
                            value={
                              stateOptions.find((opt: { value: any; }) => opt.value === (formData.state || generalFields?.address_vals?.state)) || null
                            }
                            onChange={handleSelectChange('state')}
                            placeholder="State"
                            mandatory={true}
                            className="input"
                          />
                          {errors.state && <span className="text-red-500">{errors.state}</span>}
                        </div>
                        <div className="flex flex-col">
                          <label className="field-label">Postal Code<span className="text-red-500">*</span> </label>
                          <Input
                            value={formData.postal_code ?? generalFields?.address_vals?.postal_code ?? ''}
                            onChange={handleInputChange('postal_code')}
                            placeholder="Enter Postal Code"
                            className="input"
                          />
                          {errors.postal_code && <span className="text-red-500">{errors.postal_code}</span>}
                        </div>
                        <div className="flex flex-col">
                          <label className="field-label"> Country<span className="text-red-500">*</span> </label>
                          <Input
                            value={formData.country ?? generalFields?.address_vals?.country ?? ''}
                            onChange={handleInputChange('country')}
                            placeholder="Enter Country"
                            className="input"
                          />
                          {errors.country && <span className="text-red-500">{errors.country}</span>}
                        </div>

                          {formData.service_type?.value && (
                            <>
                              {/* Built-in fields */}
                              {builtInFields?.length > 0 &&
                                builtInFields.map(
                                  (field: { field: string; type: string; db_column_name: string }, index: number) => (
                                    <div key={`built-${index}`} className="flex flex-col">
                                      <label className="field-label">{field.field}</label>
                                      {field.type === "text" ? (
                                        <Input
                                          value={
                                            typeof formData.built_in_fields[field.db_column_name ? field.db_column_name : field.field] === "string"
                                              ? (formData.built_in_fields[field.db_column_name ? field.db_column_name : field.field] as string)
                                              : ""
                                          } 
                                          onChange={(e) =>
                                            setFormData((prev) => ({
                                              ...prev,
                                              built_in_fields: {
                                                ...prev.built_in_fields,
                                                [field.db_column_name ? field.db_column_name : field.field]: e.target.value,
                                              },
                                            }))
                                          }
                                          placeholder={`Enter ${field.field}`}
                                          className="input"
                                        />
                                      ) : field.type === "date" ? (
                                        <DatePicker
                                          value={formData.built_in_fields[field.db_column_name] || null}
                                          onChange={(date) =>
                                            setFormData((prev) => ({
                                              ...prev,
                                              built_in_fields: {
                                                ...prev.built_in_fields,
                                                [field.db_column_name]: date,
                                              },
                                            }))
                                          }
                                          format="MM-DD-YY"
                                          placeholder={`Select ${field.field}`}
                                          className="input"
                                        />
                                      ) : null}
                                    </div>
                                  )
                                )}

                              {/* Custom fields */}
                              {customFields?.length > 0 &&
                                customFields.map(
                                  (field: { field: string; type: string; db_column_name: string }, index: number) => (
                                    <div key={`custom-${index}`} className="flex flex-col">
                                      <label className="field-label">{field.field}</label>
                                      {field.type === "text" ? (
                                        <Input
                                          value={typeof formData.custom_fields?.[field.db_column_name ? field.db_column_name : field.field] === "string"
                                              ? (formData.custom_fields?.[field.db_column_name ? field.db_column_name : field.field] as string)
                                              : ""
                                          }onChange={(e) =>
                                            setFormData((prev) => ({
                                              ...prev,
                                              custom_fields: {
                                                ...prev.custom_fields,
                                                [field.db_column_name ? field.db_column_name : field.field]: e.target.value,
                                              },
                                            }))
                                          }
                                          placeholder={`Enter ${field.field}`}
                                          className="input"
                                        />
                                      ) : field.type === "date" ? (
                                        <DatePicker
                                        value={
                                            formData.custom_fields?.[field.db_column_name ? field.db_column_name : field.field] &&
                                            typeof formData.custom_fields?.[field.db_column_name ? field.db_column_name : field.field] !== "string"
                                              ? (formData.custom_fields?.[field.db_column_name ? field.db_column_name : field.field] as Dayjs)
                                              : null
                                          }                                          
                                          onChange={(date) =>
                                            setFormData((prev) => ({
                                              ...prev,
                                              custom_fields: {
                                                ...prev.custom_fields,
                                                [field.db_column_name ? field.db_column_name : field.field]: date,
                                              },
                                            }))
                                          }
                                          format="MM-DD-YY"
                                          placeholder={`Select ${field.field}`}
                                          className="input"
                                        />
                                      ) : null}
                                    </div>
                                  )
                                )}
                            </>
                          )}

                      </>

                    )}

                    {showProductRow && (
                      <>
                        <div className="flex flex-col">
                          <ProductsMultiSelect label="Products" />
                        </div>
                        <div className="relative w-full md:w-auto mt-6">
                          <button
                            className="save-btn"
                            type="button"
                            onClick={handleFilterLoad}
                          >
                            Filter
                          </button>
                        </div>
                        {headers && headers.length > 0 && (
                          <div className="col-span-3" style={{ overflowX: 'auto', width: '100%', marginTop: '10px' }}>
                            <EditableTableComponent
                              headers={headers}
                              headerMap={headerMap}
                              initialData={tableData}
                              searchQuery={searchTerm}
                              visibleColumns={visibleColumns}
                              itemsPerPage={100}
                              popupHeading="Customer Products"
                              pagination={pagination}
                              advancedFilters={filteredData}
                              height={400}
                              setUpdatedTableData={setUpdatedTableData}
                            />
                          </div>
                        )}
                      </>
                    )}

                    {!newServiceFields && productsFields && (
                      <>
                        <div className="flex flex-col">
                          <label className="field-label">Accounts<span className="text-red-500">*</span></label>
                          <Input
                            type="text"
                            className="input"
                            value={accountNumber}
                            disabled
                            onChange={handleInputChange('accounts')}
                            placeholder="Enter account value"
                          />
                        </div>
                        <div className="flex flex-col">
                          <Dropdown
                            options={serviceTypeOptions}
                            value={formData.service_type || null}
                            onChange={handleSelectChange('service_type')}
                            placeholder="Service Type"
                            mandatory={true}
                            className="input"
                          />
                          {errors.service_type && <span className="text-red-500">{errors.service_type}</span>}
                        </div>
                        <div className="flex flex-col">
                          <ProductsMultiSelect label="Products" />
                          {errors.products && <span className="text-red-500">{errors.products}</span>}
                        </div>


                      </>
                    )}

                    {transferServicesFields && (
                      <>
                        <div className="flex flex-col">
                          <Dropdown
                            options={destCustomers}
                            value={destCustomers.find((opt: any) => opt.value === formData.dest_customer) || null}
                            onChange={handleSelectChange('dest_customer')}
                            placeholder="Dest Customer"
                            mandatory={true}
                            className="input"
                          />
                          {errors.dest_customer && <span className="text-red-500">{errors.dest_customer}</span>}
                        </div>
                        <div className="flex flex-col">
                          <label className="field-label">Effective Date <span className="text-red-500">*</span></label>
                          <DatePicker
                            value={formData.effective_date}
                            onChange={handleSelectChange('effective_date')}
                            placeholder="Select a date"
                            className="input"
                            format="MM-DD-YY"
                          />
                          {errors.effective_date && <span className="text-red-500">{errors.effective_date}</span>}
                        </div>
                        {/* <div className="flex flex-col">
                      <Dropdown
                        options={customerServicesIdListOptions}
                        value={customerServicesIdListOptions.find((opt: any) => opt.value === formData.customer_services_id_list) || null}
                        onChange={handleSelectChange('customer_services_id_list')}
                        placeholder="Service Type"
                        mandatory={true}
                        className="input"
                      />
                      {errors.customer_services_id_list && <span className="text-red-500">{errors.customer_services_id_list}</span>}
                    </div> */}
                      </>
                    )}

                  {disconnectServiceFields && (
                    <>
                      <div className="flex flex-col">
                        <label className="field-label">
                          Disconnect Effective Date <span className="text-red-500">*</span>
                        </label>
                        <DatePicker
                          value={formData.effective_date}
                          onChange={(date) => {
                            setFormData((prev) => ({
                              ...prev,
                              effective_date: date,
                              apply_to_all: date ? prev.apply_to_all : false, // uncheck if cleared
                            }));
                            const formattedDate = dayjs(date).format("YYYY-MM-DD");
                            const updatedDisconnectData: Record<string, string> = {};
                            tableData.forEach((row: any) => {
                              updatedDisconnectData[row.id] = formattedDate;
                            });
                            // ✅ When date changes and "Apply to all" is checked, update all rows
                            if (date && formData.apply_to_all) {
                              const updatedData = tableData.map((row: any) => ({
                                ...row,
                                manual_disconnect_date: date,
                              }));
                              setTableData(updatedData);
                              setDisconnectTableData(updatedData);
                              setDisconnectServiceData(updatedDisconnectData);
                            }
                          }}
                          placeholder="Select Disconnect Date"
                          className="input"
                          format="MM-DD-YY"
                          // disabledDate={(current) => current && current < dayjs().startOf("day")} // ✅ Disable past dates
                        />
                        {errors.effective_date && (
                          <span className="text-red-500">{errors.effective_date}</span>
                        )}
                      </div>

                      <div className="flex flex-col">
                      
                        <Checkbox
                    checked={formData.apply_to_all || false}
                    onChange={handleApplyToAllChange}
                    className="mt-6"
                    disabled={!formData.effective_date}
                  >
                    Apply to all
                  </Checkbox>

                      </div>

                    {showDisconnectTable && (
                    <div className="col-span-3 w-full mt-2" style={{ height:`${viewportHeight - 330}px` }}>
                      <EditableTableComponent
                        headers={headers}
                        headerMap={headerMap}
                        initialData={tableData}
                        searchQuery={searchTerm}
                        visibleColumns={visibleColumns}
                        itemsPerPage={100}
                        // allowedActions={allowedActions}
                        popupHeading="Disconnect Service"
                        pagination={pagination}
                        advancedFilters={filteredData}
                        generalFields={generalFields_}
                        height={330}
                        setUpdatedTableData={setUpdatedTableData}
                        setSelectedRowData={setDisconnectServiceData}
                      />
                    </div>
                  )}


                    </>
                  )}

                  </div>
                  {newServiceFields && (
                    <div className="mt-4 px-2 flex flex-col md:flex-row md:space-x-4 space-y-4 md:space-y-0">
                      {/* Left Column: MultiSelects */}
                      <div className="flex flex-col space-y-2 md:w-1/2 lg:w-1/3">
                        <ProductsMultiSelect label="Products" />
                        <div className="text-black-500 font-semibold text-center">OR</div>
                        <PackagesMultiSelect label="Packages" />
                      </div>

                      {/* Right Column: Descriptions & Rates */}
                      <div className="flex-1 space-y-3">
                        {(selectedProducts.length > 0 || selectedPackages.length > 0) && (
                          <div className="flex font-semibold mb-2 space-x-4">
                            <div className="w-[150px]">Product Description</div>
                            <div className="w-[70px]">Rate</div>
                            <div className="w-[70px] !ml-10">Quantity</div>
                            <div className="w-[70px] !ml-4">Total Rate</div>


                          </div>
                        )}

                        {/* Product Rates */}
                        {selectedProducts.map((product: any) => {
                          const key = product.product_id;

                          return (
                            <div key={key} className="flex items-center space-x-4">
                              <span className="w-[150px] text-gray-800 bulk-history-div">
                                {product.description}
                              </span>

                              {/* Rate Input */}
                              <input
                                type="number"
                                className={`${!!formData?.customer_rate_plan ? "non-editable-input" : "input"} !w-[70px]`}
                                 value={
                                    productRates[key] !== undefined
                                      ? productRates[key] === null
                                        ? ''
                                        : productRates[key]
                                      : product.rate ?? ''
                                  }
                                 onChange={(e) => {
                                    const newValue = e.target.value;
                                    setProductRates((prev) => ({
                                      ...prev,
                                      [key]: newValue === '' ? null : parseFloat(newValue),
                                    }));
                                  }}
                                readOnly={!!formData?.customer_rate_plan}
                              />

                              <span>X</span>

                              {/* Quantity Input */}
                              <input
                                type="number"
                                className={`${!!formData?.customer_rate_plan ? "non-editable-input" : "input"} !w-[70px]`}
                                value={
                                  productQuantities[key] !== undefined
                                    ? productQuantities[key] === null
                                      ? ''
                                      : productQuantities[key]
                                    : 1 // initial default
                                }
                                onChange={(e) =>
                                  setProductQuantities((prev) => ({
                                    ...prev,
                                    [key]:
                                      e.target.value === '' ? null : parseInt(e.target.value, 10),
                                  }))
                                }
                                min={1}
                                readOnly={!!formData?.customer_rate_plan}
                              />


                            {/* Total = rate × quantity */}
                            <input
                              type="number"
                              className="non-editable-input !w-[70px]"
                              value={
                                (() => {
                                  const rate =
                                    productRates[key] !== undefined
                                      ? productRates[key] === null
                                        ? 0
                                        : productRates[key]
                                      : product.rate ?? 0;

                                  const qty =
                                    productQuantities[key] !== undefined
                                      ? productQuantities[key] === null
                                        ? 0
                                        : productQuantities[key]
                                      : 1; // default 1

                                  return rate * qty;
                                })()
                              }
                              readOnly
                            />

                            </div>
                          );
                        })}



                        {/* Package Rates */}
                        {selectedPackages.map((product: any) => {
                          const key = product.product_id;
                          return (
                            <div key={key} className="flex items-center space-x-4">
                              <span className="w-[150px]">{product?.description}</span>
                              <input
                                type="number"
                                className="non-editable-input !w-[70px]"
                                value={
                                    packageRates[key] !== undefined
                                      ? packageRates[key] === null
                                        ? ''
                                        : packageRates[key]
                                      : product.rate ?? ''
                                  }
                                onChange={(e) =>
                                  setPackageRates((prev) => ({
                                    ...prev,
                                    [key]: e.target.value === '' ? null : parseFloat(e.target.value),
                                  }))
                                }
                                readOnly
                              />
                              <span>X</span>
                              <input
                                type="number"
                                className="non-editable-input !w-[70px]"
                                 value={
                                  packageQuantities[key] !== undefined
                                    ? packageQuantities[key] === null
                                      ? ''
                                      : packageQuantities[key]
                                    : 1 // initial default
                                }
                                onChange={(e) =>
                                  setPackageQuantities((prev) => ({
                                    ...prev,
                                    [key]: e.target.value === '' ? null : parseInt(e.target.value, 10),
                                  }))
                                }
                                min={1}
                                readOnly
                              />
                              <input
                                type="number"
                                className="non-editable-input !w-[70px]"
                                value={
                                (() => {
                                  const rate =
                                    packageRates[key] !== undefined
                                      ? packageRates[key] === null
                                        ? 0
                                        : packageRates[key]
                                      : product.rate ?? 0;

                                  const qty =
                                    packageQuantities[key] !== undefined
                                      ? packageQuantities[key] === null
                                        ? 0
                                        : packageQuantities[key]
                                      : 1; // default 1

                                  return rate * qty;
                                })()
                              }
                                readOnly
                              />
                            </div>
                          );
                        })}

                      </div>
                    </div>
                  )}

                  {/* Tables and Filter Button Section */}
                  {/* {(showProductRow || productsFields) && (
                    <div className="px-2 space-y-4 mt-4">
                      <div className="w-full md:w-auto">
                        <button className="save-btn" type="button" onClick={handleFilterLoad}>
                          Filter
                        </button>
                      </div>

                      {headers?.length > 0 && (
                        <div className="overflow-x-auto w-full">
                          <EditableTableComponent
                            headers={headers}
                            headerMap={headerMap}
                            initialData={tableData}
                            searchQuery={searchTerm}
                            visibleColumns={visibleColumns}
                            itemsPerPage={100}
                            popupHeading={newServiceFields ? "Customer Products" : "Products"}
                            pagination={pagination}
                            advancedFilters={filteredData}
                            height={400}
                            setUpdatedTableData={setUpdatedTableData}
                          />
                        </div>
                      )}
                    </div>
                  )} */}
                </div>
                {transferServicesFields && formData["dest_customer"] && (
                    <div className="col-span-3 w-full mt-2" style={{ height:`${viewportHeight - 330}px` }}>
                  <KillbillTableComponent
                    headers={headers}
                    headerMap={headerMap}
                    initialData={tableData}
                    searchQuery={searchTerm}
                    visibleColumns={visibleColumns}
                    itemsPerPage={100}
                    allowedActions={allowedActions}
                    popupHeading={"Transfer Service"}
                    pagination={pagination}
                    advancedFilters={filteredData}
                    // createModalData={createModalData}
                    generalFields={generalFields_}
                    height={330}
                    setReverseRowData={setReverseRowData}
                  />
                  </div>)}
                  
              </>

            )}
          </form>
        </div>
      </Modal>
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onCancel={handleCancelConfirmation}
        centered
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelConfirmation}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={handleConfirmCreate}
            >
              OK
            </button>
          </div>
        }
      >
        {formData?.create?.label === "Transfer Service" ? (
          <p>This transfer will also update the corresponding record in AMOP.</p>
        ) : formData?.create?.label === "Disconnect Service" ? (
          <p>Deactivating this service may affect unposted charges.</p>
        ): (
          <p>Are you sure you want to Create this Service ?</p>
        )}
      </Modal>
    </div>
  );
};

export default CustomCreateModal;