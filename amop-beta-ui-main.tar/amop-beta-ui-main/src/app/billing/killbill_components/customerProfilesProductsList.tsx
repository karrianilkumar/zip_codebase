import React,  {
    useEffect,
    useState,
    lazy,
    Suspense,
    useRef,
    useCallback,
  } from 'react';
import { useFeatureStore } from '@/app/sim_management/inventory/featureStore';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import { Modal,Button,DatePicker, notification,Spin, Switch } from 'antd/lib';
import { useAuth } from '@/app/components/auth_context';
import { fireSideCannons } from "@/app/components/confetti";
import EditableTableComponent from './editable_table_component';
const KillbillTableComponent = lazy(
  () => import("./table__component")
);

  
  // Define the props for the PackageModal component
  interface PackageModalProps {
    row: any; // The row data passed to the modal
    isOpen: boolean; // Whether the modal is open
    onClose: () => void;
    rowId:any; // Function to close the modal
    // headersMap_:any;
    rowflag:any;
    rowData:any
  }
  type ExportData = {
    path: string;
    username: string | null;
    module_name: string;
    request_received_at: string;
    start_date: string;
    end_date: string;
    Partner: string | null;
    access_token: string | null;
    db_name: string | null;
  };




  const PackageModal: React.FC<PackageModalProps> = ({ row, isOpen, onClose,rowId,rowflag,rowData }) => {
    console.log("rowData...",row);
    console.log(rowData?.effective_date,"Show row data Effective Date.........");
    const [searchTerm, setSearchTerm] = useState("");
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination} = useAuth();
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [loading, setLoading] = useState(false);
    const [filteredData, setFilteredData] = useState([]);
    const [isEditable, setIsEditable] = useState(false);
    const [createModalData, setcreateModalData] = useState<any[]>([]);
    const [generalFields, setgeneralFields] = useState<any[]>([]);
    const [editableRowData,setEditableRowData] = useState<any[]>([]);
    const [totalRate, setTotalRate] = useState(0); // State for total rate
    const [UpdatedTableData, setUpdatedTableData] = useState<string[]>([]);
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    const {
      features: moduleFeatures,
      setFeatures: setModuleFeatures,
      setICCID,
      setBulkRow
    } = useFeatureStore();
    // const queryClient = useQueryClient();
  
    type HeaderMap = Record<string, [string, number]>;
  
    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
      const entries = Object.entries(headerMap) as [string, [string, number]][];
      entries.sort((a, b) => a[1][1] - b[1][1]);
      return Object.fromEntries(entries) as HeaderMap;
    }, []);
  
  
    const fetchData = async () => {
      setBulkRow(null)
      setICCID("");
      setStoredPagination(null);
      setAdvancedStoredPagination(null);
      settabledata([])
      setUpdatedTableData([])
      let parsedData: any;
      try {
        setLoading(true);
        const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/service_products_headermap_data",
          role_name: role,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenant_id_,
          row_id : rowId,
          flag : rowflag,
          main_module_name: "Customer Profiles",
        };
        const response = await axios.post(url, {data});
        console.log(response)
        parsedData = JSON.parse(response.data.body);
        console.log(parsedData)
  
        if (parsedData.flag === true) {
          setLoading(false);
          
            const headersMap_ = parsedData?.header_map?.["Product Packages"]?.header_map || {};
            const sortedheaderMap = sortHeaderMap(headersMap_);
            setHeaderMap(sortedheaderMap);
            const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
            console.log("headers", headers_)
            setHeaders(headers_);
            setVisibleColumns(headers_);
            const generalFields_ = parsedData || {}
            setgeneralFields(generalFields_)
            setTableData(parsedData?.data?.products_packages || []);
            setUpdatedTableData(parsedData?.data?.products_packages || []);

        } else {
          setLoading(false);
          console.log("flag set to false")
          Modal.error({
            title: "Data Fetch Error",
            content: parsedData.message || "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        }
      } catch (error) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };

    const submitUpdatedTable = async (submitData:any) => {
      let parsedData: any;
      try {
        setLoading(true);
        const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/update_service_products",
          role_name: role,
          submit_data:submitData,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          tenant_id: tenant_id_,
          sessionID: sessionId,
          row_id : rowId,
          main_module_name: "Customer Profiles",
        };
        const response = await axios.post(url, {data});
        console.log(response)
        parsedData = JSON.parse(response.data.body);
        console.log(parsedData)
  
        if (parsedData.flag === true) {
          setLoading(false);
          notification.success({
            message: "Success",
            description: parsedData.message|| "Successfully saved!",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons();
            
        } else {
          setLoading(false);
          console.log("flag set to false")
          Modal.error({
            title: "Submit Error",
            content: parsedData.message || "An error occurred while submitting data. Please try again.",
            centered: true,
          });
        }
      } catch (error) {
        setLoading(false);
        Modal.error({
          title: "Submit Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while submitting data. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };

     useEffect(() => { 
      
          fetchData();
      }, []);

      useEffect(() => {
        if (isOpen) {
            // Calculate total rate when the modal opens
            calculateTotalRate();
        }
    }, [isOpen, editableRowData,UpdatedTableData]); // Run when modal opens or editableRowData changes

    const calculateTotalRate = () => {
      // Log the incoming row data
      console.log("Incoming row data:", row);
  
      const total = UpdatedTableData.reduce((acc: number, item: any) => {
          if (editableRowData.includes(item.id)) {
              console.log(`Matching ID found: ${item.id}, Rate: ${item.rate}`);
              // Convert item.rate to a number, default to 0 if conversion fails
              const total_rate = Number(item.rate); // or use parseFloat(item.rate)
              return acc + (isNaN(total_rate) ? 0 : total_rate); // Sum the rates, treating NaN as 0
          }
          return acc; // No match, return accumulated total
      }, 0);
  
      setTotalRate(total);
      console.log("Total Rate:", total); // Log the total rate
  };

    if (!isOpen) return null;
  
    const messageStyle = {
      fontSize: "14px",
      fontWeight: "normal",
      padding: "16px",
    };
  
    
    const handleCancel = () => {
        setHeaders([]) // Clear new field input
        setTableData([])
        onClose();
    };
    const handleSave = () => {
      console.log("UpdatedTableData",UpdatedTableData)
      const filteredData_ = UpdatedTableData.filter(
  (updatedRow: any) =>
    !tableData.some((originalRow: any) =>
      JSON.stringify(originalRow) === JSON.stringify(updatedRow)
    )
);

    console.log("filtered row",filteredData_)
    submitUpdatedTable(filteredData_)
      handleCancel()
      
    };    

  return (
   <Modal
  title="Details"
  open={isOpen}
  onCancel={handleCancel}
  centered
  width={1000}
  bodyStyle={{
  height: "auto",overflowY: "auto"}}
  footer={
 <div className="relative">
  {/* Centered buttons */}
  {/* <div className="absolute left-1/2 transform -translate-x-1/2 flex space-x-2">
    <button
      className={`${isEditable ? 'save-btn' : 'cancel-btn cursor-not-allowed'}`}
      disabled={!isEditable}
      onClick={handleSave}
    >
      Save
    </button>
    <button key="cancel-btn" className="cancel-btn" onClick={handleCancel}>
      Close
    </button>
  </div> */}

  {/* Right-aligned Total Rate */}
  <div className="flex justify-end">
    <p><strong>Total Rate:</strong> ${typeof totalRate === 'number' ? totalRate.toFixed(2) : '0.00'}</p>
  </div>
</div>


  }
>
    <div style={{ flex: 1, overflow: 'auto', padding: '0 16px',marginTop:'10px' }}>
      {loading ? (
        <div className="flex justify-center items-center h-[300px]" >
          <Spin size="large" />
        </div>
      ) : (
        <>
          {!isEditable ? (
            <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              popupHeading="Service Product"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields={generalFields}
              height={340}
              setReverseRowData={setEditableRowData}
            />
          ) : (
            <EditableTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              popupHeading="Services"
              pagination={pagination}
              height={280}
              setUpdatedTableData={setUpdatedTableData}
              setSelectedRowData={setEditableRowData}
              setEffectiveDateDisable={rowData?.effective_date}
            />
          )}
        </>
      )}
    </div>
</Modal>

);
};

export default PackageModal;