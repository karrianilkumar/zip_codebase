import React, { useEffect, useState } from "react";
import { ArrowLeftIcon, ArrowRightIcon, ChevronLeftIcon, ChevronRightIcon } from "@heroicons/react/24/outline";
import { BackwardFilled, CaretLeftFilled, CaretRightFilled, DoubleLeftOutlined, DoubleRightOutlined, ForwardFilled, LeftOutlined, RightOutlined } from "@ant-design/icons";
import { useAuth } from "@/app/components/auth_context";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  moduleName:string;
}

const BillingPagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
  moduleName
}) => {
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const { storedpagination,advancedStoredpagination} =
    useAuth();
  const excludeModules = ["Status history report", "Automation rule verification report", "Customer rate pool usage report","Daily usage report","Newly actvated report","Pool group summary report","Usage by line report","Zero usage report"];
  const minPagesToShow =excludeModules.includes(moduleName)?10: 5; // Minimum pages to show before ellipses
    // Check for small screen on component mount and window resize
    useEffect(() => {
      const checkScreenSize = () => {
        setIsSmallScreen(window.innerWidth < 700);
      };
      
      // Initial check
      checkScreenSize();
      
      // Add event listener for window resize
      window.addEventListener('resize', checkScreenSize);
      
      // Clean up
      return () => window.removeEventListener('resize', checkScreenSize);
    }, []);
  const handlePageChange = (page: number) => {
    onPageChange(page);
  };

  useEffect(() => {
    console.log(`Total Pages for ${moduleName}:`, totalPages);
  }, [totalPages, moduleName]);
  //To handle and set the update pages when click on forward next
  const handleForwardNext = () => {
    onPageChange(currentPage+5);
  };

  //To handle and set the update pages when click on backward prev
  const handleForwardPrev = () => {
    onPageChange(currentPage-5);
  };

  //To handle and set the update pages when click on next
  const handleNext = () => {
    onPageChange(currentPage+1)
  };

  //To handle and set the update pages when click on prev
  const handlePrev = () => {
    onPageChange(currentPage-1)
  };
  const calculatePagesToShow = () => {

    const pagesToShow: (number | string)[] = [];
    if (excludeModules.includes(moduleName)&& !storedpagination && !advancedStoredpagination) {
      if(currentPage<=minPagesToShow){
        for (let i = 1; i <= minPagesToShow; i++) {
          pagesToShow.push(i);
        }
      }
      else{
        const start=currentPage-minPagesToShow
        const end=currentPage
        for (let i = start+1; i <= end; i++) {
          pagesToShow.push(i);
        }
      }
    }
    else{
      // Check if the total number of pages is less than or equal to the minimum pages to show
    if (totalPages <= minPagesToShow) {
      // If total pages are less than or equal to minPagesToShow, show all pages
      for (let i = 1; i <= totalPages; i++) {
        pagesToShow.push(i);
      }
    }
     else {
      if(currentPage<=minPagesToShow){
        const start_page=1
        const end_page=minPagesToShow+1
        for (let i = start_page; i <end_page; i++) {
            pagesToShow.push(i);
        }
        pagesToShow.push("...");
        pagesToShow.push(totalPages);
      }
      else if(currentPage>totalPages-minPagesToShow){
        const start_page=totalPages-minPagesToShow+1
        const end_page=totalPages+1
        pagesToShow.push(1);
        pagesToShow.push("...");
        for (let i = start_page; i <end_page; i++) {
          if(i<=totalPages){
            pagesToShow.push(i);
            }
        }
      }
      else{
        const start_page=currentPage-2
        const end_page=currentPage+3
        pagesToShow.push(1);
        pagesToShow.push("...");
        for (let i = start_page; i <end_page; i++) {
          if(i<=totalPages){
            pagesToShow.push(i);
            }
        }
        pagesToShow.push("...");
        pagesToShow.push(totalPages);
      }
    }

    }
    
    return pagesToShow;
  };


  //The page numbers to display
  const pageNumbers = calculatePagesToShow();
  if (totalPages <= 0) {
    return null;
  }
  
  // Small screen view for excluded modules
  if (isSmallScreen && excludeModules.includes(moduleName)) {
    return (
      <div className="flex justify-center mb-1 pagination items-center">
        <button
          onClick={handleForwardPrev}
          disabled={currentPage <= minPagesToShow}
          className={`w-[15px] mr-2 text-gray-800 font-semibold  h-full sm-pagination-btn ${
            currentPage <= minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <BackwardFilled className="h-8 w-8" />
        </button>
        <button
          onClick={handlePrev}
          disabled={currentPage === 1}
          className={`w-[15px] text-gray-800 font-semibold  h-full sm-pagination-btn ${
            currentPage === 1 ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          < CaretLeftFilled className="h-8 w-8" />
        </button>
        <button
          className="text-gray-800 font-semibold  h-full px-2 sm-pagination-btn"
        >
          {currentPage}
        </button>
        <button
          onClick={handleNext}
          disabled={false}
          className="w-[15px] text-gray-800 font-semibold h-full sm-pagination-btn"
        >
          <CaretRightFilled className="h-8 w-8" />
        </button>
        <button
          onClick={handleForwardNext}
          disabled={false}
          className="w-[15px] ml-2 text-gray-800 font-semibold h-full sm-pagination-btn"
        >
          <ForwardFilled className="h-8 w-8" />
        </button>
      </div>
    );
  }

  // Small screen view for non-excluded modules
  if (isSmallScreen) {
    return (
      <div className="flex justify-center pagination items-center">
        <span className="mr-2 text-sm font-semibold">
          {currentPage} of {totalPages}
        </span>
        <button
          onClick={handleForwardPrev}
          disabled={currentPage <= minPagesToShow}
          className={`w-[15px] text-gray-800 font-semibold h-full sm-pagination-btn ${
            currentPage <= minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <BackwardFilled className="h-8 w-8" />
        </button>
        <button
          onClick={handlePrev}
          disabled={currentPage === 1}
          className={`w-[15px] text-gray-800 font-semibold h-full sm-pagination-btn ${
            currentPage === 1 ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          < CaretLeftFilled className="h-8 w-8" />
        </button>
        <span className="mr-2 ml-2 text-sm font-semibold sm-pagination-btn">
         Prev
        </span>
        <span className="mr-2 text-sm font-semibold sm-pagination-btn">
          Next
        </span>
        <button
          onClick={handleNext}
          disabled={currentPage === totalPages}
          className={`w-[15px] text-gray-800 font-semibold h-full sm-pagination-btn ${
            currentPage === totalPages ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <CaretRightFilled className="h-8 w-8" />
        </button>
        <button
          onClick={handleForwardNext}
          disabled={currentPage > totalPages - minPagesToShow}
          className={`w-[15px] text-gray-800 font-semibold h-full sm-pagination-btn ${
            currentPage > totalPages - minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <ForwardFilled className="h-8 w-8" />
        </button>
      </div>
    );
  }


  return (
    <div className="flex justify-center mb-1 pagination">
      <button
        // onClick={() => handlePageChange(currentPage - 10)}
        onClick={handleForwardPrev}

        disabled={currentPage<=minPagesToShow}
        className={`bg-white pagination-angular-btn hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-1 ${
          currentPage<=minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <DoubleLeftOutlined className="h-5 w-5"/> 
      </button>
      <button
        // onClick={() => handlePageChange(currentPage - 10)}
        onClick={handlePrev}

        disabled={currentPage === 1}
        className={`bg-white pagination-angular-btn hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-1 ${
          currentPage === 1 ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <ChevronLeftIcon className="h-5 w-5"/>
      </button>
      {pageNumbers.map((page, index) => (
        <button
          key={index}
          onClick={() => typeof page === "number" && handlePageChange(page)}
           className={`hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-2 pagination-btn ${
            page === currentPage ? "bg-[#bfdbfe] text-gray-800 pagination-current-btn !important" : ""
          } ${page === "..." ? "cursor-default" : ""}`}
          disabled={page === "..."}
        >
          {page}
        </button>
      ))}
      <button
        onClick={handleNext}
        disabled={excludeModules.includes(moduleName)?false:currentPage === totalPages}
        className={`bg-white pagination-angular-btn hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-1 ${
          !excludeModules.includes(moduleName)&&currentPage === totalPages ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <ChevronRightIcon className="h-5 w-5" />
      </button>
      <button
        onClick={handleForwardNext}
        disabled={excludeModules.includes(moduleName)?false:currentPage > totalPages-minPagesToShow}
        className={`bg-white pagination-angular-btn hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-1 ${
          !excludeModules.includes(moduleName)&&currentPage > totalPages-minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <DoubleRightOutlined className="h-5 w-5" />
      </button>
    </div>
  );
};

export default BillingPagination;
