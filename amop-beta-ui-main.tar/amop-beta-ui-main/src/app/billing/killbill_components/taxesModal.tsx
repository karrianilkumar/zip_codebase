import React, { useCallback, useEffect, useState } from "react";
import { Modal, notification, Spin } from "antd";
import EditableTableComponent from "../killbill_components/editable_table_component";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useAuth } from "@/app/components/auth_context";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { fireSideCannons } from "@/app/components/confetti";


interface TaxesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave?: () => void;
  row: any; 
}

const TaxesModal: React.FC<TaxesModalProps> = ({
  isOpen,
  onClose,
  onSave,
  row,
}) => {
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    const [loading, setLoading] = useState(true);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const { addExport, removeExport } = exportLoadingStore();
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const accountNumber = useCustomerProfileStore((state) => state.accountNumber);
    const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination } = useAuth();
    const [totalAmount, setTotalAmount] = useState<any>(0);
    
   
      type HeaderMap = Record<string, [string, number]>;
      const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
      }, []);
      
    const fetchTaxesData = async () => {
        setLoading(true);
         settabledata([])
    setStoredPagination(null);
    setAdvancedStoredPagination(null);

    let parsedData: any;
    try {
      console.log("row...",row)
      const type = row?.type || null
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_taxes_unposted",
        account_number: accountNumber,
        role_name: role,
        row_id: row?.row_id || row?.id || "",
        parent_module: "Billing Platform",
        module_name:  "Billing and Collections Taxes",
        table_name: type && (type==="Bill" || type==="Reverse Bill")?"customer_bills":"customer_charges",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Taxes",
        main_module_name: 'Customer Profiles',
        mod_pages: {
          start: 0,
          end: 10,
        },
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)
      // setModalData(parsedData)
      if (parsedData.flag === true) {
        // console.log("table response:", parsedData?.data?.basic_details_deposits);
        setLoading(false);

        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Taxes"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
        //   console.log("parsedData", parsedData)
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
        //   console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setTableData(parsedData?.data?.billing_collections_taxes || []);
          calculateTotalAndQuantity(parsedData?.data?.billing_collections_taxes || []);
          setPagination(parsedData?.pages || {});
          setTotalAmount(parsedData?.total_amount || 0)
        }, 0);
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
    }
    const calculateTotalAndQuantity = (data: any[]) => {
      return {
        quantity: data.length,
        total_rate: data.reduce((sum, item) => sum + Number(item.Amount || 0), 0),
      };
    };
    const totals = calculateTotalAndQuantity(tableData);
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }
  const handleExport = async () => {
  const key = "Taxes Export"
    try {
      // Add the export to the store
      addExport(key, "Taxes");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const type = row?.type || null
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/get_taxes_unposted_export",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: key,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        account_number:accountNumber,
        table_name: type && (type==="Bill" || type==="Reverse Bill")?"customer_bills":"customer_charges",
        db_name: selectedDb,
        sessionID: sessionId,
        billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        ...metaData,
        feature_module_name: "Billing and Collections Taxes",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag:"True",
        main_module_name: "Customer Profiles",
        row_id: row?.row_id || row?.id || "",
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 5 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 5000));
  
      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
   
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Taxes Export.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Taxes Exported successfully!",
                  style: messageStyle,
                  placement: "top",
                });
                fireSideCannons();
              removeExport(key);

              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
            removeExport(key);
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
           removeExport(key);
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
     useEffect(() => {
        fetchTaxesData();
    } , [isOpen, row]);
    
  return (
    <Modal
      open={isOpen}
      onCancel={onClose}
      title="Taxes"
      centered
      width={1000}
      styles={{
        body: {
          height: "auto",
          overflowY: "auto",
        },
      }}
      footer={
  (totalAmount !== null && totalAmount !== undefined) && (
    <div className="flex flex-col justify-start items-start gap-2">
      <p><strong>Total: {`$${totalAmount}`}</strong></p>
    </div>
  )
}
    >
      <div>
        <div className="flex items-center justify-end mb-2">
          <button className="save-btn !p-2" onClick={handleExport}>
           Export 
          </button>
        </div>

        {loading ? (
          <div
            className="flex justify-center items-center overflow-y-auto"
            style={{ height: "270px" }}
          >
            <Spin size="large" />
          </div>
        ) : (
          <EditableTableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            visibleColumns={visibleColumns}
            itemsPerPage={10}
            popupHeading="Taxes"
            pagination={pagination}
            height={340}
            row={row|| null}
            // setUpdatedTableData={setUpdatedTableData}
          />
        )}
      </div>
    </Modal>
  );
};

export default TaxesModal;
