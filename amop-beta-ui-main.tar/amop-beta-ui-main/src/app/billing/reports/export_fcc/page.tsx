"use client";
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, notification, DatePicker, Input, Button, Table } from "antd";
import { CalendarOutlined } from '@ant-design/icons';
import { useAuth } from "@/app/components/auth_context";
import axios, { AxiosResponse } from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { fireSideCannons } from "@/app/components/confetti";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useDateRangeStore } from "../../killbill_stores/dateStoreReports";

const KillbillTableComponent = lazy(() => import("../../killbill_components/table__component"));
const WholeTableSearch = lazy(() => import("../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(() => import("../../killbill_components/advanced__search"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));

const ExportFCCReport: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination, combineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any[]>([]);
  const [summaryData, setSummaryData] = useState<any>({});
  const [isSummaryModalVisible, setIsSummaryModalVisible] = useState(false);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [headerMap, setHeaderMap] = useState<Record<string, any>>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState<any[]>([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const { setFeatures: setModuleFeatures } = useFeatureStore();
  const hasFetchedData = useRef(false);
  const [dropdownValues, setDropDownValues] = useState<any>({});
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  // Add this state for the date modal
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  
  const { RangePicker } = DatePicker;
  const { 
    startDateDailyReport, 
    endDateDailyReport,  
    setCustomRange
  } = useDateRangeStore();
  const [startDate, setStartDate] = useState(startDateDailyReport ? dayjs(startDateDailyReport) : null);
  const [endDate, setEndDate] = useState(endDateDailyReport ? dayjs(endDateDailyReport) : null);   
  const [selectedButton, setSelectedButton] = useState("today");
  
  const fetchData = async (startDate: string | null, endDate: string | null) => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false);
    setCombineAdnvaceStoredpagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_REPORTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fcc_report_list_view",
        role_name: role,
        start_date: startDate,
        end_date: endDate,
        parent_module: "Billing Platform",
        module_name: "Export FCC",
        mod_pages: { start: 0, end: 100 },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
 ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        feature_module_name: "Export FCC",
        table_name: "vw_fcc_report",
        main_module_name: "Export FCC",
      };

      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        setLoading(false);
          const headersMap_ = parsedData?.header_map?.["Export FCC"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          setHeaders(headers_);
          const summary_ = parsedData?.summary || {};
          const mappedSummary: Record<string, number> = {};

          // Loop through summary keys and map to headerMap display name
          Object.entries(summary_).forEach(([key, value]) => {
            const displayName = headersMap_[key]?.[0] || key; // fallback to key if not found
            mappedSummary[displayName] = value as number;
          });

          console.log("Mapped Summary:", mappedSummary);
          setSummaryData(mappedSummary); 
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {};
          setgeneralFields(generalFields_);
          setFeatures(parsedData?.header_map?.["Export FCC"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Export FCC"]?.module_features || []);
          const createModalData_ = parsedData?.header_map?.["Export FCC"]?.pop_up || [];
          setcreateModalData(createModalData_);
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.reports_data || []);
          setDropDownValues(parsedData?.dropdown || {});
        
      } else {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const showErrorModal = (message: string) => {
    Modal.error({
      title: "Data Fetch Error",
      content: message,
      centered: true,
    });
  };

  const sortHeaderMap = useCallback((headerMap: Record<string, [string, number]>): Record<string, [string, number]> => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as Record<string, [string, number]>;
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleExport = async (key: string, heading: string) => {
      setIsSummaryModalVisible(false);
    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name:selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Export FCC",
          module_name: "Export FCC",
        };
        console.log("combineAdnvaceStoredpagination", data);
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Export FCC",
          module_name: "Export FCC",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          username: username,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Export FCC",
          module_name: "Export FCC",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          db_name:selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        url = ENV_ROUTES.BP_REPORTS;
        const tenant_id_ = localStorage.getItem("tenant_id") || "0";
        data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/export_fcc_report",
          role_name: role,
          start_date: startDate ? dayjs(startDate).format("YYYY-MM-DD") : null,
          end_date: endDate ? dayjs(endDate).format("YYYY-MM-DD") : null,          
          module_name: "Export FCC",
          feature_module_name: "Export FCC",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
 ...metaData,
billing_db_name: selectedBillingDb,
          table_name: "vw_fcc_report",
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id: tenant_id_,
          modified_by: firstLastName,
          report_name: "Export FCC Report",
        };
        const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
          return new Promise((resolve, reject) => {
            const timer = setTimeout(() => reject(new Error("Request timed out")), timeout);
            promise.then((res) => { clearTimeout(timer); resolve(res); }).catch((err) => { clearTimeout(timer); reject(err); });
          });
        };

        let generateReportResponse;
        try {
          const export_response = await callWithTimeout(axios.post(url, { data }), 10000) as AxiosResponse<any>;
          generateReportResponse = JSON.parse(export_response.data.body);
        } catch (err) {
          console.warn("First API request failed or timed out:", err);
        }

        await new Promise((resolve) => setTimeout(resolve, 20000));

        const export_url = ENV_ROUTES.BP_REPORTS;
        const export_data = { ...data, path: "/get_export_status", report_id: generateReportResponse?.report_id, request_received_at: getCurrentDateTime() };

        const pollExportStatus = async () => {
          try {
            const export_response = await axios.post(export_url, { data: export_data });
            const export_parsedData = JSON.parse(export_response.data.body);

            if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
              const s3Url = export_parsedData?.export_status_data?.url || null;
              if (s3Url) {
                fetch(s3Url)
                .then(response => response.blob())
                .then(blob => {
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'Export FCC.xlsx';
                  a.click();
                  a.remove();
                  window.URL.revokeObjectURL(url);
                  notification.success({
                    message: "Success",
                    description: "Successfully exported the record!",
                    style: messageStyle,
                    placement: "top",
                  });
                  fireSideCannons();
                })
                .catch((err) => {
                  console.log("error", err)
                  Modal.error({
                    title: "Export Error",
                    content: "An error occurred while exporting data. Please try again.",
                    centered: true,
                  });
                });
              } else {
                Modal.error({ title: "Export Error", content: export_parsedData.message || "An error occurred while exporting data.", centered: true });
              }
              return true;
            }

            if (export_parsedData?.export_status_data?.status_flag === "Failure") {
              Modal.error({ title: "Export Error", content: export_parsedData.message || "An error occurred while exporting data.", centered: true });
              return true;
            }
            if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
              return true;
            }
            return false;
          } catch (error) {
            Modal.error({ title: "Export Error", content: error instanceof Error ? error.message : "An unexpected error occurred.", centered: true });
            return true;
          }
        };

        const startPolling = async () => {
          let isPollingComplete = false;
          while (!isPollingComplete) {
            isPollingComplete = await pollExportStatus();
            if (!isPollingComplete) await new Promise((resolve) => setTimeout(resolve, 5000));
          }
        };

        await startPolling();
        return;
      }

      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          fetch(s3Url)
          .then(response => response.blob())
          .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'Export FCC.xlsx';
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            notification.success({
              message: "Success",
              description: "Successfully exported the record!",
              style: messageStyle,
              placement: "top",
            });
            fireSideCannons();
          })
          .catch((err) => {
            console.log("error", err)
            Modal.error({
              title: "Export Error",
              content: "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters);
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const handleExportButtonClick = () => {
    setIsSummaryModalVisible(true)
    // handleExport("exportFcc", "Export FCC");
  };
 const summaryColumns = [
  { 
    title: "Metric", 
    dataIndex: "key", 
    key: "key",
    width: 120,
  },
  { 
    title: "SUM", 
    dataIndex: "value", 
    key: "value",
    width: 80,
    render: (value: number | string) => `$${Number(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  },
];

  const summaryDataArray = Object.entries(summaryData || {}).map(([key, value]) => ({
    key,
    value,
  }));

  const handleExportConfirm = () => {
    handleExport("exportFcc", "Export FCC");
    setExportModalOpen(false);
  };
    
  const handleTodayClick = () => {
    setStartDate(null);
    setEndDate(null);
    setCustomRange(null, null);
    fetchData(null, null);
  };
  
  useEffect(() => {
    handleTodayClick();
  }, []);
  
  const handleClickRangePicker = (range: any) => {
    if (!range) {
      setStartDate(null);
      setEndDate(null);
      setCustomRange(null, null);
      fetchData(null, null);
      return;
    }
  
    const [rangeStart, rangeEnd] = range;
    
    if (rangeStart && rangeEnd) {
      const formattedStart = rangeStart.format('YYYY-MM-DD');
      const formattedEnd = rangeEnd.format('YYYY-MM-DD');
      
      setStartDate(rangeStart);
      setEndDate(rangeEnd);
      setCustomRange(formattedStart, formattedEnd);
      fetchData(formattedStart, formattedEnd);
    }
  };
  
  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day");
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Export FCC") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Export FCC"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Export FCC") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Export FCC"}
                />
              )}
            </div>
            
            {/* Export and ColumnFilter Container - Hidden on small screens */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
              <RangePicker
              format="MM-DD-YY"
              placeholder={["Start Date", "End Date"]}
              value={startDate && endDate ? [startDate, endDate] : [null, null]}
              // style={{ width: "20%" }}
              onChange={(dates) => {
                setSelectedButton("customDate");
                handleClickRangePicker(dates)
              }}
              disabledDate={disableFutureDates}
              className={`${selectedButton === 'customDate' ? 'save-btn' : ''} min-h-[40px] ml-2 w-[200px]`}
            />
              {features.includes("Export-Export FCC") && (
                <button className="save-btn" onClick={handleExportButtonClick}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          </div>

          {/* Sticky Footer for Small Screens */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            {/* Calendar Icon for Date Range Picker on Small Screens */}
            <button className="save-btn" onClick={() => setIsDateModalOpen(true)}>
              <CalendarOutlined className="h-5 w-5 text-black-500" />
            </button>
            {features.includes("Export-Export FCC") && (
              <button className="save-btn" onClick={handleExportButtonClick}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>

          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Export FCC"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields={generalFields}
              height={showAdvanced ? 280 : 210} 
            />
          </div>

          {/* Date Selection Modal for Small Screens */}
          <Modal
            title="Select Date Range"
            visible={isDateModalOpen}
            onCancel={() => setIsDateModalOpen(false)}
            footer={null}
            centered
          >
            <div className="flex flex-col space-y-4">
              <span>Select date range</span>
              <RangePicker
                format="MM-DD-YY"
                placeholder={["Start Date", "End Date"]}
                value={startDate && endDate ? [startDate, endDate] : [null, null]}
                onChange={(dates) => {
                  setSelectedButton("customDate");
                  handleClickRangePicker(dates);
                  setIsDateModalOpen(false);
                }}
                disabledDate={disableFutureDates}
                className="w-full"
              />
            </div>
          </Modal>
          <Modal
        title="Summary Data"
         width={300}
        visible={isSummaryModalVisible}
        onCancel={() => setIsSummaryModalVisible(false)}
        footer={[
          <div className="flex justify-center gap-2 w-full">
            <button  className="cancel-btn"
                    style={{
                    height: "44px",
                    lineHeight: "1",
                    padding: "0 10px",
                    fontSize: "13px",
                    minHeight: "unset",          //removes AntD's default min-height
                    minWidth: "80px",
                  }}
            onClick={() => setIsSummaryModalVisible(false)} >
            Cancel
          </button>

          <button className="save-btn"
           style={{
                height: "44px",
                lineHeight: "1",
                padding: "0 10px",
                fontSize: "13px",
                minHeight: "unset",          //removes AntD's default min-height
                minWidth: "80px",
            }}
          onClick={() => handleExport("exportFcc", "Export FCC")}>
            Export
          </button>
          </div>
        ]}
      >
        <Table
          dataSource={summaryDataArray}
          columns={summaryColumns}
          pagination={false}
          size="small"
          className="summary-table"
        />
      </Modal>
        </div>
      </Suspense>

    </>
  );
};

export default ExportFCCReport;
