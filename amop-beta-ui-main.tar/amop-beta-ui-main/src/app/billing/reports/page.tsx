"use client";
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import { ArrowDownTrayIcon, PlusIcon } from "@heroicons/react/24/outline"; // Removed ChevronDownIcon if unused
import { Modal, Spin, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import ReportPage from "./ReportPage";

const KillbillTableComponent = lazy(() => import("../killbill_components/table__component"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const WholeTableSearch = lazy(() => import("../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(() => import("../killbill_components/advanced__search"));

type ReportFormData = {
  report_type: { label: string; value: string } | null;
  date_range: [Dayjs | null, Dayjs | null];
  [key: string]: any;
};

const Reports: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [loading, setLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const exportKey = "Inventory";
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [selectedReport, setSelectedReport] = useState<string | null>(null);
  const [selectedReportData, setSelectedReportData] = useState<ReportFormData | null>(null); // Fixed type here
  const { iccid, bulkRow, features: moduleFeatures, setFeatures: setModuleFeatures, setICCID, setBulkRow } = useFeatureStore();
  const hasFetchedData = useRef(false);
  const [isReportPage, setIsReportPage] = useState(false);
  const [dropdownValues,setDropDownValues] = useState<any>({});

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);
  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters);
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, "0")}-${String(firstDay.getDate()).padStart(2, "0")} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, "0")}-${String(lastDay.getDate()).padStart(2, "0")} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    try {
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error("Request timed out")), timeout);
          promise.then((res) => { clearTimeout(timer); resolve(res); }).catch((err) => { clearTimeout(timer); reject(err); });
        });
      };

      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Billing Report",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Billing Report",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };

      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      await new Promise((resolve) => setTimeout(resolve, 20000));

      const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
      const export_data = { ...data, path: "/get_export_status" };

      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);

          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              window.location.href = s3Url;
              notification.success({
                message: "Success",
                description: "Successfully exported the inventory record!",
                style: messageStyle,
                placement: "top",
              });
            } else {
              Modal.error({ title: "Export Error", content: export_parsedData.message || "An error occurred while exporting data.", centered: true });
            }
            return true;
          }

          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({ title: "Export Error", content: export_parsedData.message || "An error occurred while exporting data.", centered: true });
            return true;
          }

          return false;
        } catch (error) {
          Modal.error({ title: "Export Error", content: error instanceof Error ? error.message : "An unexpected error occurred.", centered: true });
          return true;
        }
      };

      const startPolling = async () => {
        let isPollingComplete = false;
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) await new Promise((resolve) => setTimeout(resolve, 5000));
        }
      };

      await startPolling();
    } catch (error) {
      Modal.error({ title: "Export Error", content: error instanceof Error ? error.message : "An unexpected error occurred.", centered: true });
    }
  };

  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
      let parsedData;
      let url;
      let data: any;
      let response;

      if (advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/export_inventory",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Billing Report",
          module_name: "Billing Report",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else if (storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/export_inventory",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Billing Report",
          module_name: "Billing Report",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }

      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          window.location.href = s3Url;
          notification.success({
            message: "Success",
            description: "Successfully exported the inventory record!",
            style: messageStyle,
            placement: "top",
          });
        } else {
          Modal.error({ title: "Export Error", content: parsedData.message || "An error occurred while exporting data.", centered: true });
        }
      } else {
        Modal.error({ title: "Export Error", content: parsedData.message || "An error occurred while exporting data.", centered: true });
      }
    } catch (error) {
      Modal.error({ title: "Export Error", content: error instanceof Error ? error.message : "An unexpected error occurred.", centered: true });
    } finally {
      removeExport(key);
    }
  };
 const backFunction =() =>{
  setIsReportPage(false)
 }
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        {isReportPage ? (
              <ReportPage
                onBack={backFunction}
                dropdown={dropdownValues}
              />
            ) : (
        <div className="relative">
          {/* <div className="p-4 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2"> */}
            <div className="pr-4 pl-4  pt-1 flex flex-col md:flex-row md:items-center md:justify-between mb-2 space-y-2">
            {/* Search and Advanced Filter Container */}
              <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Billing Reports") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Billing Report"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Billing Reports") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Billing Report"}
                />
              )}
            </div>
            {/* <div className="flex space-x-2"> */}
                          {/* Export and ColumnFilter Container */}
                          <div className="flex flex-col  md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
             {features.includes("Generate-Billing Reports") &&(
              <button className="save-btn" onClick={() => setIsReportPage(true)}>
                <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                Generate
              </button>)}
              {/* {features.includes("Export-Billing and Payments Billing") && (
                <button className="save-btn" onClick={() => handleExport("Billing", "Billing")}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )} */}
              {/* <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              /> */}
            </div>
          </div>
  
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}> 
              <KillbillTableComponent
                headers={headers}
                headerMap={headerMap}
                initialData={tableData}
                searchQuery={searchTerm}
                visibleColumns={visibleColumns}
                itemsPerPage={100}
                allowedActions={allowedActions}
                popupHeading="Billing Reports"
                pagination={pagination}
                advancedFilters={filteredData}
                createModalData={createModalData}
                generalFields={generalFields}
                height={showAdvanced ? 300 : 235}
              />
          </div>
        </div>)}
      </Suspense>
    </>
  );
};

export default Reports;