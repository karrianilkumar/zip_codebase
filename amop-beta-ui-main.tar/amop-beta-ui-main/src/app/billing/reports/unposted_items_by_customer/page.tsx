"use client";
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import { ArrowDownTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, notification, DatePicker, Input, Radio, Checkbox, Button } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios, { AxiosResponse } from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { fireSideCannons } from "@/app/components/confetti";

const KillbillTableComponent = lazy(() => import("../../killbill_components/table__component"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(() => import("../../killbill_components/advanced__search"));

type ReportFormData = {
  report_type: { label: string; value: string } | null;
  date_range: [Dayjs | null, Dayjs | null];
  [key: string]: any;
};

const UnpostedItemsReports: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination, combineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const { iccid, bulkRow, features: moduleFeatures, setFeatures: setModuleFeatures, setICCID, setBulkRow } = useFeatureStore();
  const hasFetchedData = useRef(false);
  const [exportFormData, setExportFormData] = useState<Record<string, any>>({});

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const fetchData = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false);
    setCombineAdnvaceStoredpagination(null);

    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_REPORTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/unposted_items_report_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Unposted Items",
        mod_pages: { start: 0, end: 100 },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
 ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        feature_module_name: "Unposted Items",
        main_module_name: "Unposted Items By Customer",
        table_name: "unposted_items_view",
      };

      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        setLoading(false);
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Unposted Items"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {};
          setgeneralFields(generalFields_);
          setFeatures(parsedData?.header_map?.["Unposted Items"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Unposted Items"]?.module_features || []);
          const createModalData_ = parsedData?.header_map?.["Unposted Items"]?.pop_up || [];
          setcreateModalData(createModalData_);
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.unposted_items || []);
        }, 0);
      } else {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateModalOpen = () => setCreateModalOpen(true);
  const handleCreateModalClose = () => setCreateModalOpen(false);

  const handleRunReport = (formData: ReportFormData) => {
    console.log("Running report with:", formData);
  };

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const exportToExcel = (headers: any, rowData: any, fileName = "exported_data.xlsx") => {
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters);
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleInputChange = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setExportFormData({ ...exportFormData, [key]: e.target.value });
  };

  const handleExport = async (key: string, heading: string, formData?: Record<string, any>) => {
    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Unposted Items Report",
          module_name: "Unposted Items",
        };
        console.log("combineAdnvaceStoredpagination", data);
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Unposted Items Report",
          module_name: "Unposted Items",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          username: username,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Unposted Items Report",
          module_name: "Unposted Items",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        url = ENV_ROUTES.BP_REPORTS;
        const tenant_id_ = localStorage.getItem("tenant_id") || "0";

        data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/export_unposted_items_report",
          role_name: role,
          module_name: "Unposted Items",
          feature_module_name: "Unposted Items",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
 ...metaData,
billing_db_name: selectedBillingDb,
          table_name: "unposted_items_view",
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id: tenant_id_,
          modified_by: firstLastName,
          report_name: "Unposted Items Report",
        };
        const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
          return new Promise((resolve, reject) => {
            const timer = setTimeout(() => reject(new Error("Request timed out")), timeout);
            promise.then((res) => { clearTimeout(timer); resolve(res); }).catch((err) => { clearTimeout(timer); reject(err); });
          });
        };

        let generateReportResponse;
        try {
          const export_response = await callWithTimeout(axios.post(url, { data }), 10000) as AxiosResponse<any>;
          generateReportResponse = JSON.parse(export_response.data.body);
        } catch (err) {
          console.warn("First API request failed or timed out:", err);
        }

        await new Promise((resolve) => setTimeout(resolve, 20000));

        const export_url = ENV_ROUTES.BP_REPORTS;
        const export_data = { ...data, path: "/get_export_status", report_id: generateReportResponse?.report_id, request_received_at: getCurrentDateTime() };

        const pollExportStatus = async () => {
          try {
            const export_response = await axios.post(export_url, { data: export_data });
            const export_parsedData = JSON.parse(export_response.data.body);

            if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
              const s3Url = export_parsedData?.export_status_data?.url || null;
              if (s3Url) {
                fetch(s3Url)
                  .then(response => response.blob())
                  .then(blob => {
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'Unposted Items.xlsx';
                    a.click();
                    a.remove();
                    window.URL.revokeObjectURL(url);
                    notification.success({
                      message: "Success",
                      description: "Successfully exported the record!",
                      style: messageStyle,
                      placement: "top",
                    });
                    fireSideCannons();
                  })
                  .catch((err) => {
                    console.log("error", err)
                    Modal.error({
                      title: "Export Error",
                      content: "An error occurred while exporting data. Please try again.",
                      centered: true,
                    });
                  });
              } else {
                Modal.error({ title: "Export Error", content: export_parsedData.message || "An error occurred while exporting data.", centered: true });
              }
              return true;
            }

            if (export_parsedData?.export_status_data?.status_flag === "Failure") {
              Modal.error({ title: "Export Error", content: export_parsedData.message || "An error occurred while exporting data.", centered: true });
              return true;
            }
            if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
              return true;
            }

            return false;
          } catch (error) {
            Modal.error({ title: "Export Error", content: error instanceof Error ? error.message : "An unexpected error occurred.", centered: true });
            return true;
          }
        };

        const startPolling = async () => {
          let isPollingComplete = false;
          while (!isPollingComplete) {
            isPollingComplete = await pollExportStatus();
            if (!isPollingComplete) await new Promise((resolve) => setTimeout(resolve, 5000));
          }
        };

        await startPolling();
        return;
      }

      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Unposted Items.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons();
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };

  const handleExportButtonClick = () => {
    handleExport("unpostedItems", "Unposted Items", exportFormData);
  };

  const handleExportConfirm = () => {
    handleExport("unpostedItems", "Unposted Items", exportFormData);
    setExportModalOpen(false);
  };

  const handleModalClose = () => {
    setExportFormData({});
    setExportModalOpen(false);
  };

  const renderExportForm = () => (
    <div className="p-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col">
          <label className="field-label">Column</label>
          <Input onChange={handleInputChange("column")} placeholder="Enter Column" value={exportFormData.column} className="input w-full mt-1 h-10" defaultValue={"Customer ID"} disabled/>
        </div>
        <div className="flex flex-col">
          <label className="field-label">Value</label>
          <Input onChange={handleInputChange("column_value")} value={exportFormData.column_value} placeholder="Enter Value" className="input" />
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
           <div className="p-2 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Unposted Reports") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Unposted Items Report"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Unposted Reports") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Unposted Items Report"}
                />
              )}
            </div>
            
            {/* Export and ColumnFilter Container - Hidden on small screens */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first pb-2 md:pb-4">
              {features.includes("Export-Unposted Reports") && (
                <button className="save-btn" onClick={handleExportButtonClick}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          </div>

          {/* Sticky Footer for Small Screens */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            {features.includes("Export-Unposted Reports") && (
              <button className="save-btn" onClick={handleExportButtonClick}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>

          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Unposted Items"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields={generalFields}
              height={showAdvanced ? 280 : 225}
            />
          </div>
        </div>
      </Suspense>

      {/* Export Modal */}
      <Modal
        title="Export Unposted Items Report"
        open={isExportModalOpen}
        onCancel={handleModalClose}
        footer={
          <div style={{ display: "flex", flex: "column", justifyContent: "center" }}>
            <button className="cancel-btn" onClick={handleModalClose} style={{ marginRight: "10px" }}>
              Cancel
            </button>
            <button className="save-btn" onClick={handleExportConfirm}>
              Export
            </button>
          </div>
        }
        width={600}
      >
        {renderExportForm()}
      </Modal>
    </>
  );
};

export default UnpostedItemsReports;
