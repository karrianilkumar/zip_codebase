/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, CreditCardIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, Button, Table } from "antd";
import { CalendarOutlined } from '@ant-design/icons';
import { useAuth } from "../../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../../components/header_constants";
import { useFeatureStore } from "../../../sim_management/inventory/featureStore";
import { ENV_ROUTES } from "../../../components/routes/route_constants";
import { SyncOutlined } from "@ant-design/icons";
import CreateBillModal from "../../customer_profiles/billings_collections/billing_collections_sub_tabs/createBill";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import dayjs, { Dayjs } from "dayjs";
import { fireSideCannons } from "@/app/components/confetti";
const KillbillTableComponent = lazy(
  () => import("../../killbill_components/table__component")
);
const WholeTableSearch = lazy(() => import("../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../killbill_components/advanced__search")
);
import ColumnFilter from "@/app/components/columnfilter";
import { useDateRangeStore } from "../../killbill_stores/dateStoreReports";
import { useCustomerProfileStore } from "../../killbill_stores/customer_profile_store";

interface BillingProps {
  row?: any;
  onRowClick: (row: any) => void; // Callback function
}

const Billing: React.FC<BillingProps> = ({ row, onRowClick }) => {
  const [editableRowData,setEditableRowData] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [eligibleAccounts, setEligibleAccounts] = useState<string[]>([]);
  const [creditcardfeeaccounts , setCreditCardFeeForAccounts] = useState<any>({})
  const [selectAllChangedData, setSelectAllChangedData] = useState<any>({});
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const { addExport, removeExport } = exportLoadingStore();
  const [loading, setLoading] = useState(false);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  // Add this state for the date modal
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const [ProcessPaymentOpen, setProcessPaymentOpen] = useState(false);
  const [isPayNowProcessing, setIsPayNowProcessing] = useState(false);
  const { isSelectAllChecked } = useCustomerProfileStore();

  const { RangePicker } = DatePicker;
  const { 
    startDateDailyReport, 
    endDateDailyReport,  
    setCustomRange
  } = useDateRangeStore();
  
  const [startDate, setStartDate] = useState<string | null>(startDateDailyReport ? dayjs(startDateDailyReport).startOf('day').format("YYYY-MM-DD 00:00:00") : null);
  const [endDate, setEndDate] = useState<string | null>(endDateDailyReport ? dayjs(endDateDailyReport).endOf('day').format("YYYY-MM-DD 23:59:59") : null);    
  const [selectedButton, setSelectedButton] = useState("today");

  const hasFetchedData = useRef(false);
  const {
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
  } = useFeatureStore();

  type HeaderMap = Record<string, [string, number]>;
  
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const fetchData = async (startDate: string | null, endDate: string | null) => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)

    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_BILLING_PAYMENTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/billing_payments_bills_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Payments Billing",
        mod_pages: {
          start: 0,
          end: 100,
        },
        start_date: startDate,
        end_date: endDate,
        table_name:"customer_bills",
        // account_number: '3000005505',
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id:tenant_id_,
        feature_module_name: "Billing and Payments Billing",
        main_module_name: "Billing",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Billing and Payments Billing"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_", generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Payments Billing"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing and Payments Billing"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Payments Billing"]?.module_features || []
          const allowedActions_: any = []
          
          if (featres_.includes("Payment-Billing and Payments Billing")) {
            allowedActions_.push("paynow")
          }
          if (featres_.includes("adjust-Billing and Payments Billing")) {
            allowedActions_.push("adjust")
          }
          if (featres_.includes("download bill-Billing and Payments Billing")) {
            allowedActions_.push("downloadbill")
          }
          if(featres_.includes("download Excel-Billing and Payments Billing")){
            allowedActions_.push("downloadExcel")
          }
          

          setAllowedActions(allowedActions_)
          const createModalData_ = parsedData?.header_map?.["Billing and Payments Billing"]?.pop_up || []
          console.log("createModalData_", createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.billing_and_payments_billing || []);
          
          // ✅ NEW: Capture eligible accounts from API response
          const eligibleAccounts_ = parsedData?.eligible_accounts || [];
          console.log("API Response - Eligible accounts:", eligibleAccounts_);
          console.log("API Response - Total data rows:", parsedData?.data?.billing_and_payments_billing?.length || 0);
          setEligibleAccounts(eligibleAccounts_);
          setCreditCardFeeForAccounts(parsedData?.credit_card_fee)
          setSelectAllChangedData(parsedData?.changed_data || {});
        }, 0);

      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  
  const setCallFetchdata = () => {
    fetchData(startDate, endDate)
  }
  
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleSave = async (type:boolean) => {
    fetchData(startDate, endDate)
    return true;
  }
  // useEffect(() => {
  //   if (!hasFetchedData.current) {
  //     fetchData((startDate?.format('YYYY-MM-DD HH:mm:ss') ?? null), (endDate?.format('YYYY-MM-DD HH:mm:ss') ?? null))
  //     hasFetchedData.current = true;
  //   }
  // }, [fetchData]);

const formatAmount = (value: number | string): string => {
 
  const num = typeof value === 'string' ? parseFloat(value) : value;
  
  if (isNaN(num) || !isFinite(num)) {
    return '0.00';
  }
  
  return num.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
};
  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const handleTodayClick = () => {
     setStartDate(null);
     setEndDate(null);
     setCustomRange(null,null);
     fetchData(null, null); // passing nulls instead of today
   };
   
  useEffect(() => {
    handleTodayClick();
  }, []);

  const handleClickRangePicker = (range: any) => {
    if (!range) {
      // If range is null, clear both local state and store
      setStartDate(null);
      setEndDate(null);
      setCustomRange(null, null);
      fetchData(null, null)
      return;
    }
  
    const [rangeStart, rangeEnd] = range;
    
    if (rangeStart && rangeEnd) {
      // Format dates as strings in the desired format
      const formattedStart = dayjs(rangeStart).startOf('day').format("YYYY-MM-DD 00:00:00");
      const formattedEnd = dayjs(rangeEnd).endOf('day').format("YYYY-MM-DD 23:59:59");
  
      // Update local state with formatted strings
      setStartDate(formattedStart);
      setEndDate(formattedEnd);
  
      // Update store with formatted strings
      setCustomRange(formattedStart, formattedEnd);
  
      // Fetch data with formatted dates
      fetchData(formattedStart, formattedEnd);
    }
  };

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day");
  };

  const ExportWithoutSearch = async () => {
    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.BP_BILLING_PAYMENTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/bills_export",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing Bills",
        start_date: startDate,
        end_date: endDate,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing and Payments Billing",
        killbill_flag: "True",
        main_module_name: "Billing",
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 5 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 5000));
  
      const export_url = ENV_ROUTES.BP_BILLING_PAYMENTS;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
  
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
                .then(response => response.blob())
                .then(blob => {
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'Billing and Payments Billing.xlsx';
                  a.click();
                  a.remove();
                  window.URL.revokeObjectURL(url);
                  notification.success({
                    message: "Success",
                    description: "Successfully exported the record!",
                    style: messageStyle,
                    placement: "top",
                  });
                  fireSideCannons();
                })
                .catch((err) => {
                  console.log("error", err)
                  Modal.error({
                    title: "Export Error",
                    content: "An error occurred while exporting data. Please try again.",
                    centered: true,
                  });
                });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                    Modal.error({
                      title: "Export Error",
                      content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                      centered: true,
                    });
                    return true; // Stop polling
                  }  
          return false; // Continue polling
        }
        
         catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };

  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
  
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // account_number:accountNumber,
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Billing and Payments Billing",
          module_name: "Billing and Payments Billing",
          col_sort: { account_number: "ASC" },
        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Billing and Payments Billing",
          module_name: "Billing and Payments Billing",
          pages: { start: 0, end: 100 },
          partner,
          // account_number:accountNumber,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          username: username,
          col_sort: { account_number: "ASC" }
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Billing and Payments Billing",
          module_name: "Billing and Payments Billing",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          // account_number:accountNumber,
          db_name:selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          username: username,
          col_sort: { account_number: "ASC" }
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Billing and Payments Billing.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons();
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
const grouped = editableRowData.reduce((acc, row) => {
   console.log("Row data:", row); 
  if (!acc[row.account_number]) {
    acc[row.account_number] = { 
      key: row.account_number,
      accountNumber: row.account_number, 
      billsList: [], 
      amount: 0,
    };
  }
  acc[row.account_number].billsList.push(row.id);
  const amountDue = parseFloat(String(row.amount_due || '0').replace(/,/g, '')) || 0;
   acc[row.account_number].amount += amountDue;
  return acc;
}, {});
// console.log("creditcardfeeaccounts",creditcardfeeaccounts)
const payloadData = Object.values(grouped).map((item: any) => ({
  key: item.accountNumber,
  accountNumber: item.accountNumber,
  billsList: item.billsList.join(','),
  ccFee: creditcardfeeaccounts[item.accountNumber] || 0, // ✅ add CC Fee for payload
  amount: item.amount.toFixed(2),
}));

const dataSource = Object.values(grouped).map((item: any) => ({
  key: item.accountNumber,
  accountNumber: item.accountNumber,
  billsList: `${item.billsList.length}`,
  ccFee: creditcardfeeaccounts[item.accountNumber] || 0, // ✅ add CC Fee for table
  amount: item.amount.toFixed(2),
}));

const columns = [
  {
    title: "Account Number",
    dataIndex: "accountNumber",
    key: "accountNumber",
  },
  {
    title: "Bills List",
    dataIndex: "billsList",
    key: "billsList",
  },
  {
    title: "CC Fee",
    dataIndex: "ccFee",
    key: "ccFee",
    render: (fee: number) => `${fee.toFixed(2)}%`,  },
  {
    title: "Amount",
    dataIndex: "amount",
    key: "amount",
     render: (amount: string) => `$${formatAmount(amount)}`,
  },
  
];
  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
  const handlePayNowClick = async() => {
    setProcessPaymentOpen(false);
    let parsedData: any;
    try {
        // Add export to loading store - show the banner
        addExport("payment_processing", "Payment Processing"); // ✅ FIXED
        
        // Disable Pay Now button during processing
        setIsPayNowProcessing(true);
        // ✅ REMOVE THIS LINE - setLoading(true);
        
        const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
        const tenant_id_ = localStorage.getItem("tenant_id") || "0";
        let changed_data: any = {};
        if(isSelectAllChecked){
          changed_data = selectAllChangedData
        }
        else{
          changed_data = payloadData.reduce((acc: any, item: any) => {
            acc[item.accountNumber] = {
              bill_list: item.billsList.split(","), // convert back to array
              bill_total: parseFloat(item.amount),  // convert string to number
            };
            return acc;
          }, {});
        }
        
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/multi_account_auto_debit",
          role_name: role,
          parent_module: "Billing Platform",
          module_name: "Billing and Payments Billing",
          mod_pages: {
            start: 0,
            end: 100,
          },
          start_date: startDate,
          end_date: endDate,
          table_name:"customer_bills",
          changed_data,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id:tenant_id_,
          feature_module_name: "Billing and Payments Billing",
          main_module_name: "Billing",
        };

        const response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === true) {
          // ✅ REMOVE THIS LINE - setLoading(false);
          
          // Show success message from multi_account_auto_debit
          if (parsedData.validation === true){
               Modal.error({
              title: "Validation Error",
              content: parsedData.message || "An error occurred while processing auto debit. Please try again.",
              centered: true,
            });
            return;
          }


          // notification.success({
          //   message: "Success",
          //   description: parsedData.message || "Multi Account Auto Debit processing initiated successfully!",
          //   style: messageStyle,
          //   placement: "top",
          // });

          // Wait for 20 seconds before polling - same as ExportWithoutSearch
          await new Promise((resolve) => setTimeout(resolve, 20000));
  
          // Start polling export status - same pattern as ExportWithoutSearch
          const pollExportStatus = async () => {
            try {
              const export_url = ENV_ROUTES.BP_BILLING_PAYMENTS; // Use same route as ExportWithoutSearch
              const export_tenant_id = localStorage.getItem("tenant_id") || "0";
              
              const export_data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_export_status", // Same path as ExportWithoutSearch
                role_name: role,
                parent_module: "Billing Platform", 
                module_name: "Multi Account Payment",
                start_date: startDate,
                end_date: endDate,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                tenant_id: export_tenant_id,
                feature_module_name: "Multi Account Payment",
                main_module_name: "Billing",
              };

              const export_response = await axios.post(export_url, { data: export_data });
              const export_parsedData = JSON.parse(export_response.data.body);
              console.log("Export status response:", export_parsedData);

              if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
                const s3Url = export_parsedData?.export_status_data?.url || null; // Use 'url' same as ExportWithoutSearch
                
                if (s3Url) {
                  // Download the Excel file using the reference code
                  fetch(s3Url)
                    .then(response => response.blob())
                    .then(blob => {
                      const url = window.URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'Multi Account Auto Debit.xlsx';
                      a.click();
                      a.remove();
                      window.URL.revokeObjectURL(url);
                      
                      notification.success({
                        message: "Success",
                        description: "Payment Processed and Exported successfully!",
                        style: messageStyle,
                        placement: "top",
                      });
                      fireSideCannons();
                    })
                    .catch((err) => {
                      console.log("Download error", err)
                      Modal.error({
                        title: "Export Error",
                        content: "An error occurred while downloading the export file. Please try again.",
                        centered: true,
                      });
                    });
                } else {
                  console.log("No export URL found in response");
                }
                
                // Call fetchData after successful export - REFRESH THE DATA
                await fetchData(startDate, endDate);
                
                return true; // Stop polling
                
              } else if (export_parsedData?.export_status_data?.status_flag === "Failure") {
                // Export failed, stop polling
                Modal.error({
                  title: "Export Failed",
                  content: "The export process failed. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
                
              } else if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.error({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "No data found for export.",
                  centered: true,
                });
                return true; // Stop polling
              }
              
              return false; // Continue polling
              
            } catch (error) {
              console.error("Error polling export status:", error);
              Modal.error({
                title: "Export Error",
                content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
                centered: true,
              });
              return true; // Stop polling
            }
          };

          // Start continuous polling - same pattern as ExportWithoutSearch
          const startPolling = async () => {
            let isPollingComplete = false;

            while (!isPollingComplete) {
              isPollingComplete = await pollExportStatus();
              if (!isPollingComplete) {
                await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
              }
            }
          };

          await startPolling();

        } else {
          // HIDE LOADER on error and SHOW error message
          setLoading(false);
          
          // ✅ ADD BACK - Show error message from multi_account_auto_debit
          console.log("flag set to false")
          Modal.error({
            title: "Processing Error",
            content: parsedData.message || "An error occurred while processing auto debit. Please try again.",
            centered: true,
          });
        }
      } catch (error) {
        // Check if it's a timeout error
        const isTimeoutError = error instanceof Error && (
          error.message.toLowerCase().includes('timeout') ||
          error.message.toLowerCase().includes('aborted') ||
          (error as any).code === 'ECONNABORTED' ||
          (error as any).code === 'TIMEOUT'
        );

        if (isTimeoutError) {
          console.log("Timeout error detected, starting polling anyway:", error);
          
          // Show timeout message but still proceed with polling
          // notification.warning({
          //   message: "Request Timeout",
          //   description: "The initial request timed out, but we'll check for processing status...",
          //   style: messageStyle,
          //   placement: "top",
          // });

          // Wait for 20 seconds before polling - same as success case
          await new Promise((resolve) => setTimeout(resolve, 20000));

          // Start polling export status even on timeout
          const pollExportStatus = async () => {
            try {
              const export_url = ENV_ROUTES.BP_BILLING_PAYMENTS;
              const export_tenant_id = localStorage.getItem("tenant_id") || "0";
              
              const export_data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_export_status",
                role_name: role,
                parent_module: "Billing Platform", 
                module_name: "Multi Account Payment",
                start_date: startDate,
                end_date: endDate,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                tenant_id: export_tenant_id,
                feature_module_name: "Multi Account Payment",
                main_module_name: "Billing",
              };

              const export_response = await axios.post(export_url, { data: export_data });
              const export_parsedData = JSON.parse(export_response.data.body);
              console.log("Export status response (after timeout):", export_parsedData);

              if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
                console.log("Export completed successfully");
                
                // Remove the processing banner
                removeExport("payment_processing");
                
                // Download the file
                const downloadUrl = export_parsedData.export_status_data.download_url;
                if (downloadUrl) {
                  const response = await fetch(downloadUrl);
                  const blob = await response.blob();
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.style.display = 'none';
                  a.href = url;
                  a.download = `multi_account_payment_${getCurrentDateTime()}.xlsx`;
                  document.body.appendChild(a);
                  a.click();
                  window.URL.revokeObjectURL(url);
                  document.body.removeChild(a);
                  
                  notification.success({
                    message: "Success",
                    description: "Payment Processed and Exported successfully!",
                    style: messageStyle,
                    placement: "top",
                  });
                }
                
                return true; // Stop polling
              } else if (export_parsedData?.export_status_data?.status_flag === "Failed") {
                console.log("Export failed");
                removeExport("payment_processing");
                Modal.error({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "Export failed after timeout.",
                  centered: true,
                });
                return true; // Stop polling
              }
              
              return false; // Continue polling
              
            } catch (pollError) {
              console.error("Error polling export status after timeout:", pollError);
              removeExport("payment_processing");
              Modal.error({
                title: "Export Error",
                content: pollError instanceof Error ? pollError.message : "An unexpected error occurred while checking export status.",
                centered: true,
              });
              return true; // Stop polling
            }
          };

          // Start continuous polling
          const startPolling = async () => {
            let isPollingComplete = false;

            while (!isPollingComplete) {
              isPollingComplete = await pollExportStatus();
              if (!isPollingComplete) {
                await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
              }
            }
          };

          await startPolling();

        } else {
          Modal.error({
            title: "Processing Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred while processing auto debit. Please try again.",
            centered: true,
          });
        }
      } finally {
        // Re-enable Pay Now button and cleanup
        setIsPayNowProcessing(false);
        removeExport("payment_processing"); // ✅ UPDATED
      }
  }
  return (
    <> 
      <div className="relative">
        <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            {features.includes("Search-Billing and Payments Billing") && (
              <WholeTableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"Billing and Payments Billing"}
                headerMap={headerMap}
              />
            )}
            {features.includes("Advanced filter-Billing and Payments Billing") && (
              <AdvancedMultiFilter2
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"Billing and Payments Billing"}
              />
            )}
          </div>
          {/* Export and ColumnFilter Container */}
          <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
            {features.includes("Create-Billing and Collections Bills") && (
              <button className="save-btn" onClick={handleCreateModalOpen}>
                <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                Create
              </button>)}
            {features.includes("Update Bill-Billing and Collections Bills") && (
              <button className="save-btn" onClick={handleCreateModalOpen}>
                <SyncOutlined className="h-5 w-5 text-black-500 mr-1" />
                Update Bill
              </button>
            )}
            <RangePicker
              format="MM-DD-YY"
              placeholder={["Start Date", "End Date"]}
              value={startDate && endDate ? [dayjs(startDate), dayjs(endDate)] : [null, null]}
              // style={{ width: "20%", marginLeft: "10px" }}
              onChange={(dates) => {
                setSelectedButton("customDate");
                handleClickRangePicker(dates);
              }}
              disabledDate={disableFutureDates}
              className={`${selectedButton === 'customDate' ? 'save-btn' : ''} min-h-[40px] ml-2 w-[200px]`}
              popupClassName="custom-range-popup"
            />
            {features.includes("Multi Payment-Billing and Payments Billing") && (
              <button 
                className={editableRowData.length === 0 || isPayNowProcessing ? "cancel-btn" : "save-btn"} 
                onClick={() => setProcessPaymentOpen(true)} 
                disabled={editableRowData.length === 0 || isPayNowProcessing}
              >
                <span>Pay Now</span> {/* ✅ REMOVE conditional text */}
              </button>
            )}
            {features.includes("Export-Billing and Payments Billing") && (
              <button className="save-btn" onClick={() => handleExport("Billing", "Billing")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                <span>Export</span>
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
              popupHeading="Billing"
            />
          </div>
        </div>

        {/* Sticky Footer for Small Screens */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
          {features.includes("Create-Billing and Collections Bills") && (
            <button className="save-btn" onClick={handleCreateModalOpen}>
              <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
            </button>)}
          {features.includes("Update Bill-Billing and Collections Bills") && (
            <button className="save-btn" onClick={handleCreateModalOpen}>
              <SyncOutlined className="h-5 w-5 text-black-500 mr-1" />
            </button>
          )}
          {features.includes("Multi Payment-Billing and Payments Billing") && (
              <button 
                className={editableRowData.length === 0 || isPayNowProcessing ? "cancel-btn" : "save-btn"} 
                onClick={() => setProcessPaymentOpen(true)} 
                disabled={editableRowData.length === 0 || isPayNowProcessing}
              >
              <CreditCardIcon className="h-5 w-5 text-white-500 mr-1" />
              </button>
            )}
          {features.includes("Export-Billing and Payments Billing") && (
            <button className="save-btn" onClick={() => handleExport("Billing", "Billing")}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
            </button>
          )}
          {/* Calendar Icon for Date Range Picker on Small Screens */}
          <button className="save-btn" onClick={() => setIsDateModalOpen(true)}>
            <CalendarOutlined className="h-5 w-5 text-black-500" />
          </button>
          <ColumnFilter
            headers={headers}
            visibleColumns={visibleColumns}
            setVisibleColumns={setVisibleColumns}
            headerMap={headerMap}
          />
        </div>

        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <KillbillTableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            allowedActions={allowedActions}
            popupHeading="Billing"
            pagination={pagination}
            advancedFilters={filteredData}
            createModalData={createModalData}
            generalFields={generalFields}
            setCallFetchdata={setCallFetchdata}
            height={showAdvanced ? 290 : 210}
            setReverseRowData={setEditableRowData}
            eligibleAccounts={eligibleAccounts} // ✅ NEW: Pass eligible accounts
          />
        </div>

        <CreateBillModal
          isOpen={isCreateModalOpen}
          onClose={handleCreateModalClose}
          onSave={handleSave}
          modalData={createModalData}
          title="Billing"
          visible={isCreateModalOpen}
          action="create"
          generalFields={generalFields}
          row={row}
        />
      <Modal
        title={"Process Payment"}
        open={ProcessPaymentOpen}
        onCancel={() => setProcessPaymentOpen(false)}
        centered
          footer={
            <div style={{ display: "flex", justifyContent: "center", width: "100%", gap: "6px" }}>
              <button className="cancel-btn" onClick={() => setProcessPaymentOpen(false)}>
                Cancel
              </button>

              <button 
                className={isPayNowProcessing ? "cancel-btn" : "save-btn"} 
                onClick={handlePayNowClick}
                disabled={isPayNowProcessing}
              >
                Pay Now {/* ✅ REMOVE conditional text */}
              </button>

            </div>
          }
        width={600} // increase width for large tables!
      >
        <div style={{ maxHeight: 400, overflowY: "auto" }}>
          <Table
            dataSource={dataSource}
            columns={columns}
            pagination={{ pageSize: 10 }}             
            bordered
            size="small"
            className="summary-table"
          />
        </div>
      </Modal>

        {/* Date Selection Modal for Small Screens */}
        <Modal
          title="Select Date Range"
          visible={isDateModalOpen}
          onCancel={() => setIsDateModalOpen(false)}
          footer={null}
          centered
        >
          <div className="flex flex-col space-y-4">
            <span>Select date range</span>
            <RangePicker
              format="MM-DD-YY HH:mm:ss"
              placeholder={["Start Date", "End Date"]}
              value={startDate && endDate ? [dayjs(startDate), dayjs(endDate)] : [null, null]}
              onChange={(dates) => {
                setSelectedButton("customDate");
                handleClickRangePicker(dates);
                setIsDateModalOpen(false);
              }}
              disabledDate={disableFutureDates}
              popupClassName="custom-range-popup"
              className="w-full"
            />
          </div>
        </Modal>
      </div>
    </>
  );
};

export default Billing;
