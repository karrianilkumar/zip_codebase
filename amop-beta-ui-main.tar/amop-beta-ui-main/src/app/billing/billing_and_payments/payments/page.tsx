/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, Button } from "antd";
import { CalendarOutlined } from '@ant-design/icons';
import { useAuth } from "../../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../../components/header_constants";
import { useFeatureStore } from "../../../sim_management/inventory/featureStore";
import { ENV_ROUTES } from "../../../components/routes/route_constants";
import { exportLoadingStore } from "../../../stores/ExportLoadingStore";
import CreateModal from "../../killbill_components/createpopup";
import { fireSideCannons } from "@/app/components/confetti";

const KillbillTableComponent = lazy(
  () => import("../../killbill_components/table__component")
);
const WholeTableSearch = lazy(() => import("../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../killbill_components/advanced__search")
);         
import ColumnFilter from "@/app/components/columnfilter";

// check
import dayjs, { Dayjs } from "dayjs";
import { useDateRangeStore } from "../../killbill_stores/dateStoreReports";

interface PaymentHistoryProps {
  row?: any;
}

const PaymentHistory: React.FC<PaymentHistoryProps> = ({row}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination,setCombineAdnvaceStoredpagination,combineAdnvaceStoredpagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [transactionChecked, setTransactionChecked] = useState(false);
  // Add this state for the date modal
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  
  const hasFetchedData = useRef(false);
  const {
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
  } = useFeatureStore();
  const { RangePicker } = DatePicker;
  const { 
         startDateDailyReport, 
         endDateDailyReport,  
         setCustomRange
       } = useDateRangeStore();
  const [startDate, setStartDate] = useState<string | null>(startDateDailyReport ? dayjs(startDateDailyReport).startOf('day').format("YYYY-MM-DD 00:00:00") : null);
  const [endDate, setEndDate] = useState<string | null>(endDateDailyReport ? dayjs(endDateDailyReport).endOf('day').format("YYYY-MM-DD 23:59:59") : null);    
  const [selectedButton, setSelectedButton] = useState("today");

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const fetchData = async (startDate: string | null, endDate: string | null) => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_BILLING_PAYMENTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/all_payment_history_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Payments-Payment History",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        start_date: startDate,
        end_date: endDate,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id:tenant_id_,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: 'Payments',
        feature_module_name: "Payment History",
        table_name: "payment_history"
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Billing and Payments-Payment History"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_",generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Payments-Payment History"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing and Payments-Payment History"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Payments-Payment History"]?.module_features || []
          const allowedActions_:any=[]
          
          setAllowedActions(allowedActions_)
          const createModalData_=parsedData?.header_map?.["Billing and Payments-Payment History"]?.pop_up||[]
          console.log("createModalData_",createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.payment_history || []);
        }, 0);
        
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
 
  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleCreateRow = () => {
    handleCreateModalClose();
  };
  
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData(startDate,endDate)
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }
  
  const handleTodayClick = () => {
       setStartDate(null);
       setEndDate(null);
       setCustomRange(null,null);
       fetchData(null, null); // passing nulls instead of today
     };
     
  useEffect(() => {
     handleTodayClick();
   }, []);

  const handleClickRangePicker = (range: any) => {
    if (!range) {
      // If range is null, clear both local state and store
      setStartDate(null);
      setEndDate(null);
      setCustomRange(null, null);
      fetchData(null,null)
      return;
    }
  
    const [rangeStart, rangeEnd] = range;
    
    if (rangeStart && rangeEnd) {
      // Format dates as strings in the desired format
      const formattedStart = dayjs(rangeStart).startOf('day').format("YYYY-MM-DD 00:00:00");
      const formattedEnd = dayjs(rangeEnd).endOf('day').format("YYYY-MM-DD 23:59:59");
  
      // Update local state with formatted strings
      setStartDate(formattedStart);
      setEndDate(formattedEnd);
  
      // Update store with formatted strings
      setCustomRange(formattedStart, formattedEnd);
  
      // Fetch data with formatted dates
      fetchData(formattedStart, formattedEnd);
    }
  };

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day"); // Disable future dates
  };

  const ExportWithoutSearch = async () => {
    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const url = ENV_ROUTES.BP_BILLING_PAYMENTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/payments_history_export",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "All Payment History",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        tenant_id:tenant_id_,
        sessionID: sessionId,
        main_module_name: 'Payments',
        feature_module_name: "Billing and Payments-Payment History",
        start_date: startDate,
        end_date: endDate,
        killbill_flag:"True"
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 5 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 5000));
  
      const export_url = ENV_ROUTES.BP_BILLING_PAYMENTS;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
  
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Billing and Payments-Payment History.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
                fireSideCannons();
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
  
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };

  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
  
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // account_number:accountNumber,
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Payment History",
          module_name: "Billing and Payments-Payment History",
          col_sort:{account_number: "ASC"}
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if  (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Payment History",
          module_name: "Billing and Payments-Payment History",
          pages: { start: 0, end: 100 },
          partner,
          // account_number:accountNumber,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          username: username,
          col_sort:{account_number: "ASC"}
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Payment History",
          module_name: "Billing and Payments-Payment History",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          // account_number:accountNumber,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          username: username,
          col_sort:{account_number: "ASC"}
          
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          fetch(s3Url)
          .then(response => response.blob())
          .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'Billing and Payments-Payment History.xlsx';
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            notification.success({
              message: "Success",
              description: "Successfully exported the record!",
              style: messageStyle,
              placement: "top",
            });
            fireSideCannons();
          })
          .catch((err) => {
            console.log("error", err)
            Modal.error({
              title: "Export Error",
              content: "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
  
  if (loading2) {
    return (
      <div className="absolute inset-0 flex flex-col justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
        <div className="flex justify-center">
          <Spin size="large" />
        </div>
        <p className="mt-2 text-gray-600 font-semibold">Fetching Transaction Status...</p>
      </div>
    );
  }

  return (
    <>
      <Suspense 
        fallback={
          <div className="flex justify-center items-center h-[400px]">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
           <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Payment History") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Payment History"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced filter-Payment History") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Payment History"}
                />
              )}
            </div>
            
            {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
                <RangePicker
              format="MM-DD-YY"
              placeholder={["Start Date", "End Date"]}
              value={startDate && endDate ? [dayjs(startDate), dayjs(endDate)] : [null, null]}
              // style={{ width: "20%", marginLeft: "10px" }}
              onChange={(dates) => {
                setSelectedButton("customDate");
                handleClickRangePicker(dates);
              }}
              disabledDate={disableFutureDates}
              className={`${selectedButton === 'customDate' ? 'save-btn' : ''} min-h-[40px] ml-2 w-[200px]`}
            />
              {features.includes("Export-Payment History") && (
                <button className="save-btn" onClick={() => handleExport("Payments", "Payments")}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
             
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Payments"
              />
            </div>
          </div>

          {/* Sticky Footer for Small Screens */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            {features.includes("Export-Payment History") && (
              <button className="save-btn" onClick={() => handleExport("Payments", "Payments")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              </button>
            )}
            {/* Calendar Icon for Date Range Picker on Small Screens */}
            <button className="save-btn" onClick={() => setIsDateModalOpen(true)}>
              <CalendarOutlined className="h-5 w-5 text-black-500" />
            </button>
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>

          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Payments"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields={generalFields}
              height={showAdvanced ? 290 : 210}
            />
          </div>

          <CreateModal
            isOpen={isCreateModalOpen}
            onClose={handleCreateModalClose}
            onSave={handleCreateRow}
            modalData={createModalData}
            title="Payments"
            visible={isCreateModalOpen}
            action="create"
            generalFields={generalFields}
          />

          {/* Date Selection Modal for Small Screens */}
          <Modal
            title="Select Date Range"
            visible={isDateModalOpen}
            onCancel={() => setIsDateModalOpen(false)}
            footer={null}
            centered
          >
            <div className="flex flex-col space-y-4">
              <span>Select date range</span>
              <RangePicker
                format="MM-DD-YY HH:mm:ss"
                placeholder={["Start Date", "End Date"]}
                value={startDate && endDate ? [dayjs(startDate), dayjs(endDate)] : [null, null]}
                onChange={(dates) => {
                  setSelectedButton("customDate");
                  handleClickRangePicker(dates);
                  setIsDateModalOpen(false);
                }}
                disabledDate={disableFutureDates}
                className="w-full"
              />
            </div>
          </Modal>
        </div>
      </Suspense>
    </>
  );
};

export default PaymentHistory;
