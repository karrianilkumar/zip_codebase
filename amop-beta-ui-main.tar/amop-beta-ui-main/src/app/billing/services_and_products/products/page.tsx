"use client";

import React, { useEffect, useState, lazy, Suspense } from "react";
import { useSidebarStore } from "@/app/stores/navBarStore";

const Product = lazy(() => import("./product"));
// const ProductType = lazy(() => import("./product_type"));
const Packages = lazy(() => import("./packages"));


const ProductsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState("product");
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);

  // if (loading) {
  //   return (
  //     <div className="flex justify-center items-center h-screen">
  //       <Spin size="large" />
  //     </div>
  //   );
  // }
  return (
    // <Suspense
    //   fallback={
    //     <div className="flex justify-center items-center h-screen">
    //       <Spin size="large" />
    //     </div>
    //   }
    // >
      <div className="">
        <div
          className={`bg-white shadow-md mb-4 gap-4  tabs ${isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`} style={{ zIndex: '98' }}
        >
         
         
          {/* <button
            className={`tab-headings ${
              activeTab === "product_type" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("product_type")}
          >
            Product Type
          </button> */}
          <button
            className={`tab-headings ${
              activeTab === "product" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("product")}
          >
            Product
          </button>
          <button
            className={`tab-headings ${
              activeTab === "packages" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("packages")}
          >
            Packages
          </button>
        </div>
        <div className="h-[calc(100vh-150px)] pt-[70px]">
          {/* {activeTab === "product_type" && <ProductType />} */}
          {activeTab === "product" && <Product />}
          {activeTab === "packages" && <Packages />}

        </div>
      </div>
    // </Suspense>
  );
};

export default ProductsPage;
