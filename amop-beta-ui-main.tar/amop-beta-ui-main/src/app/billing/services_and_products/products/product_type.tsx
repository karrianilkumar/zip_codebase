"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, Switch } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
// import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import OptimizationTableComponent from "@/app/components/optimizationTableComponent/page";
import InventoryTableComponent from "@/app/components/inventoryTableComponent/page";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import KillbillTableComponent from "../../killbill_components/table__component";
import CreateModal from "../../killbill_components/createpopup";
import { useKillBillStore } from "../../killbill_stores/activeStore";
type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  start_date: string;
  end_date: string;
  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
};

const { RangePicker } = DatePicker;
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../killbill_components/advanced__search")
);


const ProductTypePage: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination,setCombineAdnvaceStoredpagination,combineAdnvaceStoredpagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [loading, setLoading] = useState(false);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const exportKey = "Inventory";
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [showActive, setShowActive] = useState(true);
  const { productTypeShowActive, setProductTypeShowActive} = useKillBillStore();

  const hasFetchedData = useRef(false);
  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  // const queryClient = useQueryClient();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  // eslint-disable-next-line react-hooks/exhaustive-deps
  const fetchData = async () => {
    setBulkRow(null)
    setICCID("");
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    settabledata([]);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/product_type_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing Product Types",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id:tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing Product Types",
        status: showActive?"true":"false",
        main_module_name: "Products",
      };
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === true) {
        console.log("table response:", getCurrentDateTime());
        setLoading(false); 
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Billing Product Types"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setFeatures(parsedData?.header_map?.["Billing Product Types"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing Product Types"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing Product Types"]?.module_features || []
          const createModalData_=parsedData?.header_map?.["Billing Product Types"]?.pop_up||[]
          setcreateModalData(createModalData_)
         


          const allowedActions_:any=[]
          if(featres_.includes("Edit-Billing Product Types")){
            allowedActions_.push("edit")
          }
          // if(featres_.includes("Delete-Billing Product Types")){
          //   allowedActions_.push("delete")
          // }
          if(featres_.includes("Copy-Billing Product Types")){
            allowedActions_.push("copy")
          }
          
          setAllowedActions(allowedActions_)
          setPagination(parsedData?.pages || {});
          console.log("billing type data",parsedData?.data?.billing_product_types)
          setTableData(parsedData?.data?.billing_product_types || []);

          // Defer heavy state updates to allow the UI to remain responsive
          // setTimeout(() => {
          //   setTableData(parsedData?.inventory_data || []);
          // }, 0);
        }, 0);
        // requestIdleCallback(() => {
        //   setTableData(parsedData?.inventory_data || []);
        //   console.log("table response:", getCurrentDateTime());
        // });
      } else {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleCreateRow = () => {
    handleCreateModalClose();
  };
  // useEffect(() => {
  //   if (!hasFetchedData.current) {
  //     fetchData();
  //     hasFetchedData.current = true;
  //   }
  // }, [fetchData]);

    useEffect(() => {
        fetchData();
        console.log("If show active is false", showActive)
        setProductTypeShowActive(showActive);
      }, [partner, showActive]);
    const handleSwitchChange = (checked: any) => {
      setShowActive(checked)
    };
  

  const exportToExcel = (headers: any, rowData: any, fileName = 'exported_data.xlsx') => {
    // Map the rowData to an array of objects with headers as keys
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });

    // Create a new worksheet from the formatted data
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

    // Write the workbook and trigger download
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  // const handleExport = async () => {
  //   if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
  //     Modal.error({ title: "Error", content: "Please select a date range." });
  //     return;
  //   }

  //   const [startDate, endDate] = dateRange;
  //   const exportData: ExportData = {
  //     path: "/export",
  //     username: username,
  //     module_name: "SimManagement Inventory",
  //     request_received_at: getCurrentDateTime(),
  //     start_date: startDate.format("YYYY-MM-DD 00:00:00"),
  //     end_date: endDate.format("YYYY-MM-DD 23:59:59"),
  //     Partner: partner,
  //     access_token: token,
  //     db_name: selectedDb,
  //   };

  //   try {
  //     const url = ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(url, { data: exportData }, {
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     });
  //     const data = JSON.parse(response.data.body);

  //     if (data.flag === true) {
  //       notification.success({
  //         message: "Success",
  //         description: "Successfully exported the record!",
  //         placement: "top",
  //       });
  //       downloadBlob(data.blob);
  //     } else {
  //       Modal.error({
  //         title: "Export Error",
  //         content: data.message,
  //         centered: true,
  //       });
  //     }
  //     handleExportModalClose();
  //   } catch (error) {
  //     console.error("Error downloading the file:", error);
  //     Modal.error({
  //       title: "Export Error",
  //       content: "An error occurred while exporting the file. Please try again.",
  //     });
  //   }
  // };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  
  const ExportWithoutSearch = async () => {
  
    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: productTypeShowActive?"Active Billing Product Types":"Billing Product Types",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
 ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Billing Product Types",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag:"True"
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
  
      const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
  
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = showActive ? 'Active Billing Product Types.xlsx' : "Billing Product Types.xlsx";
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
  
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };

  const handleExport = async (key: string, heading: string) => {
  
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Billing Product Type",
          module_name:"Billing Product Types",
          toggle:productTypeShowActive?true:false,
          col_sort:{description: "ASC"}
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if  (advancedStoredpagination && !storedpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Billing Product Type",
          module_name:"Billing Product Types",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          toggle:productTypeShowActive?true:false,
          col_sort:{description: "ASC"},
          username: username

        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Billing Product Type",
          module_name: "Billing Product Types",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
 ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          toggle:productTypeShowActive?true:false,
          col_sort:{description: "ASC"},
          username: username

        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = showActive ? 'Active Billing Product Types.xlsx' : "Billing Product Types.xlsx";
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
        <div className="flex justify-end p-2">
            <div className="flex items-center space-x-2 justify-end">
              <Switch onChange={handleSwitchChange} checked={showActive} className="custom-switch" />
              <span className="font-bold text-lg">Show Active only</span>
            </div>
          </div>
            <div className="p-2 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
            {/* Search and Advanced Filter Container */}
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Billing Product Types") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Billing Product Type"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced filter-Billing Product Types") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Billing Product Type"}
                />
              )}
            </div>
            {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col pb-4 md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
              {features.includes("Add-Billing Product Types") && (
                <button className="save-btn" onClick={handleCreateModalOpen}>
                  <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                  Add Product Type
                </button>)}
              {features.includes("Export-Billing Product Types") && (
                <button className="save-btn" onClick={() => handleExport("productType", "Product Type")}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          </div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Product Type"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields = {generalFields}
              height = {showAdvanced?380:320}
              />
          </div>
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
              {features.includes("Add-Billing Product Types") && (
                <button className="save-btn" onClick={handleCreateModalOpen}>
                  <PlusIcon className="h-5 w-5 text-black-500" />
                </button>)}
              {features.includes("Export-Billing Product Types") && (
                <button className="save-btn" onClick={() => handleExport("productType", "Product Type")}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          <CreateModal
              isOpen={isCreateModalOpen}
              onClose={handleCreateModalClose}
              onSave={handleCreateRow}
              modalData={createModalData}
              title="Product Type"
              visible={isCreateModalOpen}
               action="create"
              generalFields = {generalFields}   
            />
          {/* {exportLoading && (
            <div className="export-processing-div">
              Export processing...
            </div>
          )} */}
        </div>
      </Suspense>
    </>
  );
};

export default ProductTypePage;
