import { create } from "zustand";

interface Item {
  id: string;
  content:JSX.Element | string;
  x?: number;
  y?: number;
  type: string;
}


interface ItemStore {
  items: Item[];
  setItems: (items: Item[] | ((prev: Item[]) => Item[])) => void;
  updateItemPosition: (id: string, x: number, y: number) => void;
  saveItems: () => void;
  loadItems: () => Item[];
  updateItemContent: (id: string, content: string) => void;
}

export const useItemStore = create<ItemStore>((set, get) => ({
  items: [],
  setItems: (items) =>
    set((state) => ({
      items: typeof items === "function" ? items(state.items) : items,
    })),
  updateItemPosition: (id, x, y) => {
    set((state) => ({
      items: state.items.map((item) =>
        item.id === id ? { ...item, x, y } : item
      ),
    }));
  },
  saveItems: () => {
    localStorage.setItem("savedItems", JSON.stringify(get().items));
  },
  loadItems: () => {
    const savedItems = localStorage.getItem("savedItems");
    return savedItems ? JSON.parse(savedItems) : [];
  },
  updateItemContent: (id, content) => {
    set((state) => ({
      items: state.items.map((item) =>
        item.id === id ? { ...item, content } : item
      ),
    }));
  },
}));
