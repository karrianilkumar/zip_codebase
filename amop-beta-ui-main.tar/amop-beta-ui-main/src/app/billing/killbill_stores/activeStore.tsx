// stores/revStore.tsx
import { create } from 'zustand';

interface ActiveState {
    serviceShowActive: boolean;
    setServiceShowActive: (value: boolean) => void;
    productTypeShowActive: boolean;
    setProductTypeShowActive: (value: boolean) => void;
    productShowActive: boolean;
    setProductShowActive: (value: boolean) => void;
    packageActive: boolean;
    setPackageShowActive: (value: boolean) => void;
    servicesActive: boolean;
    setservicesShowActive: (value: boolean) => void;
    customerProfilesActive: boolean;
    setCustomerProfilesActive: (value: boolean) => void;
}

export const useKillBillStore = create<ActiveState>((set) => ({
    serviceShowActive: true, // Default value
    setServiceShowActive: (value) => set({ serviceShowActive: value }),
    productTypeShowActive: true, // Default value
    setProductTypeShowActive: (value) => set({ productTypeShowActive: value }),
    productShowActive: true, // Default value
    setProductShowActive: (value) => set({ productShowActive: value }),
    packageActive: true, // Default value
    setPackageShowActive: (value) => set({ packageActive: value }),
    servicesActive: true,
    setservicesShowActive: (value) => set({servicesActive:value}),
    customerProfilesActive: true,
    setCustomerProfilesActive: (value) => set({ customerProfilesActive: value }),
}));