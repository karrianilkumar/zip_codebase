import { create } from "zustand";

type ChargesDataStore = {
  creditTableData: any[];
   chargesTableData:any[]; 
  recurringChargeData: any[];
  usageDetailsTableData: any[];
  chargeByServiceTableData: any[];

  setCreditTableData: (data: any[]) => void;
  setChargesTableData: (data: any[]) => void;
  setRecurringChargeData: (data: any[]) => void;
  setUsageDetailsTableData: (data: any[]) => void;
  setChargeByServiceTableData: (data: any[]) => void;

  resetAll: () => void;
};

export const useChargesModalDataStore = create<ChargesDataStore>((set) => ({
  creditTableData: [],
  chargesTableData: [],
  recurringChargeData: [],
  chargeByServiceTableData: [],
  usageDetailsTableData: [],

  setCreditTableData: (data) => set({ creditTableData: data }),
  setChargesTableData: (data) => set({ chargesTableData: data }),
  setRecurringChargeData: (data) => set({ recurringChargeData: data }),
  setChargeByServiceTableData: (data) => set({ chargeByServiceTableData: data }),
  setUsageDetailsTableData: (data) => set({ usageDetailsTableData: data }),

  resetAll: () =>
    set({
      creditTableData: [],
      chargesTableData: [],
      recurringChargeData: [],
      usageDetailsTableData: [],
      chargeByServiceTableData: [],
    })
}));
