import { create } from 'zustand';
import dayjs from 'dayjs';

interface DateRangeState {
  startDateDailyReport: string | null;
  endDateDailyReport: string | null;
  weekStartDate: string | null;
  setCustomRange: (start: string | null, end: string | null) => void;
  setWeekStartDate: (date: string | null) => void;
}

export const useDateRangeStore = create<DateRangeState>((set) => ({
  // Initialize with today's date
  startDateDailyReport:null,
  endDateDailyReport: null,
  
  weekStartDate: null,
  // Custom range setter
  setCustomRange: (start, end) => {
    set({ 
      startDateDailyReport: start, 
      endDateDailyReport: end 
    });
  },
  setWeekStartDate: (date) => {
    set({ weekStartDate: date });
  },
}));