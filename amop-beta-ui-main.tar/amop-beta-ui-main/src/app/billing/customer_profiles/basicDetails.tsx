"use client";
import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react"; import { Checkbox, Input, notification, Popover, Spin, Switch, DatePicker, Modal } from "antd"; // Import DatePicker
import Select from "react-select";
import { Select as AntDSelect} from "antd";
import { NonEditableDropdownStyles, DropdownStyles } from "@/app/components/css/dropdown";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import dayjs from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
const { RangePicker } = DatePicker; // Extract RangePicker
import { CloseOutlined } from "@ant-design/icons";
import VirtualList from "rc-virtual-list";
import { fireSideCannons } from "@/app/components/confetti";

const KillbillTableComponent = lazy(
  () => import("../killbill_components/table__component")
);
const EditableTableComponent = lazy(
  () => import("../killbill_components/editable_table_component")
);

interface BasicDetailsProps {
  isOpen: boolean;
  onClose: () => void;
  // onSave: (formData: any) => void;
  title: string;
  row: any;
}
const messageStyle = {
  fontSize: '14px',
  fontWeight: 'normal',
  padding: '16px',
};
const BasicDetails: React.FC<BasicDetailsProps> = ({
  isOpen,
  onClose,
  // onSave,
  title,
  row
}) => {
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loading2, setLoading2] = useState(false);
  const [isEditable, setIsEditable] = useState(true);
  const [isdisabled, setisdisabled] = useState(true);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [filteredData, setFilteredData] = useState([]);
  const [UpdatedTableData, setUpdatedTableData] = useState<string[]>([]);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [ModalData, setModalData] = useState<any>([]);
  const hasFetchedData = useRef(false);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination } = useAuth();
  const [formValues, setFormValues] = useState<Record<string, any>>({});
  const {  setAccountNumber, setBillId ,setUserProfileDetails} = useCustomerProfileStore();
  const accountNumber = sessionStorage.getItem("accountNumber")
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isViewHistoryModalOpen, setIsViewHistoryModalOpen] = useState(false);
  const [isAssinedAccountsModalOpen, setIsAssinedAccountsModalOpen] = useState(false);
  const [originalBillCycleStartDate, setOriginalBillCycleStartDate] = useState<string | null>(null);
  const [viewportHeight, setViewportHeight] = useState(0);
  const [validationErrors, setValidationErrors] = useState<{
    [key: string]: string;
  }>({});
  const [startDate, setStartDate] = useState(dayjs());
  const [btnProviderSearchValue, setBtnProviderSearchValue] = useState("");
  const [depositData, setDepositData] = useState({
    description: "",
    startDate: dayjs(), // Default to current date
    amount: "",
  });
    const [generalFields, setgeneralFields] = useState<any[]>([]);
    const {
        features: moduleFeatures,
        setFeatures: setModuleFeatures,
      } = useFeatureStore();
    
  
  // eslint-disable-next-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (isDepositModalOpen || loading2) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }

    // Cleanup function to remove the class when the component unmounts
    return () => {
      document.body.classList.remove('no-scroll');
    };
  }, [isDepositModalOpen, loading2]);
  // useEffect(() => {
  //   if (formValues["btn_provider"] && formValues["bill_cycle_start_date"]) {
  //     handleInputChange("bill_cycle_start_date", null);
  //   }
  // }, [formValues["btn_provider"]]);
  
  
  const fetchData = async (UpdatedaccountNumber?:any) => {
    
    settabledata([])
    // setBulkRow(null)
    // setICCID("");
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setIsAssinedAccountsModalOpen(false)
    
    let parsedData: any;
    try {
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      console.log("accountNumber", accountNumber)
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/customer_basic_details",
        account_number: UpdatedaccountNumber? UpdatedaccountNumber : accountNumber,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Customer Basic Details",
        // sub_module: "Customer Basic Details",
        table_name:"customer_profiles",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        main_module_name: 'Customer Profiles',
        tenant_id:tenant_id_,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Customer Basic Details",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)
      setModalData(parsedData)
      if (parsedData.flag === true) {
        console.log("table response:", parsedData);
        setLoading(false);
        setUserProfileDetails(parsedData?.data?.billing_customer_profiles?.user_profile_details || {}); // Set user profile details     

          const createModalData_ = parsedData?.header_map?.["Customer Basic Details"]?.pop_up || []
          setcreateModalData(createModalData_)
          const initialData = parsedData?.data?.billing_customer_profiles || [];
          // if (initialData.bill_cycle_start_date && initialData.btn_provider) {
          //   initialData.bill_cycle_start_date = null;
          // }
          setFormValues(initialData);   
          // setOriginalBillCycleStartDate(initialData.bill_cycle_start_date && initialData.btn_provider ? null : initialData.bill_cycle_start_date); // Set original value
          setOriginalBillCycleStartDate(initialData.bill_cycle_start_date);
          setModuleFeatures(parsedData?.header_map?.["Customer Basic Details"]?.module_features)

        console.log("formdata", initialData);
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [partner]);
  useEffect(() => {
    const updateHeight = () => {
      setViewportHeight(window.innerHeight);
    };

    updateHeight(); // Initial height set
    window.addEventListener("resize", updateHeight); // Update on resize

    return () => window.removeEventListener("resize", updateHeight); // Cleanup
  }, []);

  const modalPadding = 60; // Approx padding inside modal
  const headerHeight = 50; // Modal header height
  const buttonHeight = 60; // Save/Cancel button height
  const availableHeight = viewportHeight - (modalPadding + headerHeight + buttonHeight);
  const contentHeight = availableHeight - 100;
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";

  const SubmitData = async (formData: any) => {
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES; // Ensure `ENV_ROUTES` is properly defined
    try {
      setLoading(true);
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_customer_basic_details",
        role_name: role,
        module_name: "Customer Basic Details",
        main_module_name: 'Customer Profiles',
        feature_module_name: "Billing Platform",
        Partner: partner,
        access_token: token,
        table_name: "customer_profiles",
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        action: "update",
        modified_by: firstLastName,
        changed_data: { ...formData }, // Spread the collected data here
      };

      const response = await axios.post(url, { data }); // Make the POST request
      const resp = JSON.parse(response.data.body);

      if (response.data.statusCode === 200 && resp.flag === true) {
        if(resp?.validation){
        Modal.error({
          title: "Validation Error",
          content: resp.message,
          centered: true,
        })
        return;
      }
        // Show success message
        notification.success({
          message: "Success",
          description: "Successfully saved the record!",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons()
        setIsEditable(true);
        fetchData();
      } else {
        // Handle error response from the server
        Modal.error({
          title: "Saving Error",
          content: resp.message || "An error occurred while saving the record.",
          centered: true,
        });
        setLoading(false);

      }
    } catch (error) {
      console.error("Error submitting data:", error);
      Modal.error({
        title: "Submit Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
        onOk: onClose,
      });
    } finally {
      setLoading(false);
    }
  };
  const AddDeposits = async () => {
    fetchDepositsData('add')
  };
  const AddCollection = async () => {
    fetchHistoryData('add')
  }
  const SaveDeposits = async () => {
    if (!UpdatedTableData || UpdatedTableData.length === 0) {
      Modal.warning({
        title: "No Changes Detected",
        content: "Please add or modify at least one row before saving.",
        centered: true,
      });
      return;
    }
    
    const invalidRows = UpdatedTableData.filter(
      (row: any) =>
        row.isNew &&
        (
          !row.description || row.description.trim() === "" ||
          row.amount === undefined || row.amount === null || row.amount === ""
        )
    );
    
    if (invalidRows.length > 0) {
      Modal.warning({
        title: "Validation Error",
        content: "Please fill in Description and Amount for all newly added rows before saving.",
        centered: true,
      });
      return;
    }
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES; // Ensure `ENV_ROUTES` is properly defined
    try {
      setLoading2(true);
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_customer_basic_details_deposits",
        role_name: role,
        module_name: "Basic Details Deposits",
        main_module_name: 'Customer Profiles',
        feature_module_name: "Basic Details Deposits",
        Partner: partner,
        access_token: token,
        table_name: "customer_profiles",
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        ...metaData,
        db_name: selectedDb,
        billing_db_name: selectedBillingDb,
        action: "update",
        modified_by: firstLastName,
        changed_data: { UpdatedTableData }, // Spread the collected data here
      };

      const response = await axios.post(url, { data }); // Make the POST request
      const resp = JSON.parse(response.data.body);

      if (response.data.statusCode === 200 && resp.flag === true) {
        // Show success message
        notification.success({
          message: "Success",
          description: "Successfully saved the record!",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons()
        handleCloseDepositModal()
        fetchData()

      } else {
        // Handle error response from the server
        Modal.error({
          title: "Saving Error",
          content: resp.message || "An error occurred while saving the record.",
          centered: true,
        });
        setLoading2(false);

      }
    } catch (error) {
      console.error("Error submitting data:", error);
      Modal.error({
        title: "Submit Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
        onOk: onClose,
      });
    } finally {
      setLoading2(false);
    }
  };
    const SaveCollections = async () => {
    if (!UpdatedTableData || UpdatedTableData.length === 0) {
      Modal.warning({
        title: "No Changes Detected",
        content: "Please add or modify at least one row before saving.",
        centered: true,
      });
      return;
    }
    
    const invalidRows = UpdatedTableData.filter((row: any) => row.isNew && (
      (!row.step_description || row.step_description.trim() === "") ||
      (!row.canceled_date && !row.completed_date)
    ));

    if (invalidRows.length > 0) {
      let missingDescription = false;
      let missingDates = false;
    
      invalidRows.forEach((row: any) => {
        if (!row.step_description || row.step_description.trim() === "") {
          missingDescription = true;
        }
        if (!row.canceled_date && !row.completed_date) {
          missingDates = true;
        }
      });
    
      const missingFields = [];
      if (missingDescription) missingFields.push("Step Description");
      if (missingDates) missingFields.push("Canceled Date or Completed Date");
    
      Modal.warning({
        title: "Validation Error",
        content: `Some rows are missing: ${missingFields.join(", ")}`,
        centered: true,
      });
      return;
    }
    
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES; // Ensure `ENV_ROUTES` is properly defined
    try {
      setLoading2(true);
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/collection_steps_list_view_save",
        role_name: role,
        module_name: "Basic Details Collection Steps",
        main_module_name: 'Customer Profiles',
        feature_module_name: "Basic Details Collection Steps",
        Partner: partner,
        access_token: token,
        table_name: "customer_profiles",
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        action: "update",
        modified_by: firstLastName,
        changed_data: [...UpdatedTableData ], // Spread the collected data here
      };

      const response = await axios.post(url, { data }); // Make the POST request
      const resp = JSON.parse(response.data.body);

      if (response.data.statusCode === 200 && resp.flag === true) {
        // Show success message
        notification.success({
          message: "Success",
          description: "Successfully saved the record!",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons()
        handleCloseDepositModal()
        fetchData()

      } else {
        // Handle error response from the server
        Modal.error({
          title: "Saving Error",
          content: resp.message || "An error occurred while saving the record.",
          centered: true,
        });
        setLoading2(false);

      }
    } catch (error) {
      console.error("Error submitting data:", error);
      Modal.error({
        title: "Submit Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
        onOk: onClose,
      });
    } finally {
      setLoading2(false);
    }
  };

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);
  
  const fetchDepositsData = async (action:string) => {
    settabledata([])
    setUpdatedTableData([])
    // setBulkRow(null)
    // setICCID("");
    setStoredPagination(null);
    setAdvancedStoredPagination(null);

    let parsedData: any;
    try {
      setLoading2(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/customer_deposit_pop_up",
        account_number: accountNumber,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Basic Details Deposits",
        table_name:"customer_profiles",
        // sub_module:"Customer Basic Details",
        flag:action,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Basic Details Deposits",
        main_module_name: 'Customer Profiles',
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)
      // setModalData(parsedData)
      if (parsedData.flag === true) {
        console.log("table response:", parsedData?.data?.basic_details_deposits);
        setLoading2(false);

        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Basic Details Deposits"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          console.log("parsedData", parsedData)
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const newRows = (parsedData?.data?.basic_details_deposits || []).map((row: any) => ({
            ...row,
            isNew: action === "add" ? true : false,
          }));
    
          // ✅ Append new rows while preserving deleted rows
          setTableData((prevData: any) => {
            const mergedData = [...prevData, ...newRows];
    
            // Remove duplicates
            const uniqueData = mergedData.reduce((acc, current) => {
              if (!acc.some((row: any) => row.created_date === current.created_date)) {
                acc.push(current);
              }
              return acc;
            }, []);
            const updatedMerged = [...uniqueData].filter((row: any) => row.isNew);
            setUpdatedTableData(updatedMerged);
            return uniqueData;
          });          

        }, 0);
      } else {
        setLoading2(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading2(false);
    }
  };
  const fetchHistoryData = async (action:string) => {
    settabledata([])
    setUpdatedTableData([])
    setStoredPagination(null);
    setAdvancedStoredPagination(null);

    let parsedData: any;
    try {
      setLoading2(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/collection_steps_list_view",
        account_number: accountNumber,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Basic Details Collection Steps",
        table_name:"collection_steps",
        // sub_module:"Customer Basic Details",
        flag:action,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        template_id:ModalData.dropdown.collection_step[formValues["collection_step"]] || null,
        sessionID: sessionId,
        feature_module_name: "Basic Details Collection Steps",
        main_module_name: 'Customer Profiles',
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)
      // setModalData(parsedData)
      if (parsedData.flag === true) {
        console.log("table response:", parsedData?.data?.basic_details_deposits);
        setLoading2(false);

        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Basic Details Collection Steps"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          setgeneralFields(parsedData)
          
          console.log("parsedData", parsedData)
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          if (action === "add") {
            const newRows = (parsedData?.data?.collection_steps || []).map((row: any) => ({
              ...row,
              isNew: true,
            }));
          
            setTableData((prevData: any) => [...prevData, ...newRows]);
            setUpdatedTableData((prev: any) => [...prev, ...newRows]); // <-- This ensures validation picks up the new row
          }
           else {
            setTableData(
              (parsedData?.data?.collection_steps || []).map((row: any) => ({
                ...row,
                isNew: false, // Mark all rows as non-editable
              }))
            );
          }
          

        }, 0);
      } else {
        setLoading2(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading2(false);
    }
  };
   const fetchAssignedAccountsData = async (action:string) => {
    settabledata([])
    setUpdatedTableData([])
    // setBulkRow(null)
    // setICCID("");
    setStoredPagination(null);
    setAdvancedStoredPagination(null);

    let parsedData: any;
    try {
      setLoading2(true);
       const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
       
            const data = {
              account_number: accountNumber,
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/assigned_accounts",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Assigned Accounts",
              // table_name:"customer_profiles",
              // sub_module:"Customer Profiles",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              feature_module_name: "Assigned Accounts",
              main_module_name: 'Customer Profiles',
            };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)
      // setModalData(parsedData)
      if (parsedData.flag === true) {
        console.log("table response:", parsedData?.data?.assigned_accounts);
        setLoading2(false);

        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Assigned Accounts"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          console.log("parsedData", parsedData)
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
           setTableData(parsedData?.data?.assigned_accounts || []);        

        }, 0);
      } else {
        setLoading2(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading2(false);
    }
  };
  useEffect(() => {
    if (isDepositModalOpen) {
      fetchDepositsData('fetch');
    }
  }, [isDepositModalOpen]);
   useEffect (() => {
    if(isViewHistoryModalOpen){
      fetchHistoryData('fetch')
    }
   },[isViewHistoryModalOpen])
   useEffect(() => {
    if(isAssinedAccountsModalOpen) {
      fetchAssignedAccountsData('fetch')
      }
  }, [isAssinedAccountsModalOpen]);

const handleSave = (event: React.FormEvent<HTMLFormElement>) => {
  event.preventDefault();

  let errors: { [key: string]: string } = {};

  createModalData.forEach((column) => {
    if (
      column.mandatory ||
        (column.db_column_name === "minimum_amount" && formValues.late_fee_type === "percentage")) { // ✅ Add this condition
    
      // Skip validation for parent_acc_lv when account_type !== "Child"
      if (
        column.db_column_name === "parent_acc_lv" &&
        formValues["account_type"] !== "Child"
      ) {
        return; // don't add error
      }

      const value = formValues[column.db_column_name];
      if (!value || (Array.isArray(value) && value.length === 0)) {
        errors[column.db_column_name] = `${column.display_name} is required.`;
      }
    }

  });
  // ✅ Add specific validation for minimum_amount when percentage is selected
  if (formValues.late_fee_type === "percentage" && (!formValues.minimum_amount || formValues.minimum_amount === "")) {
    errors.minimum_amount = "Minimum Amount is required when Late Fee Type is percentage.";
  }

  if (Object.keys(errors).length > 0) {
    setValidationErrors(errors);
    // setIsConfirmationOpen(false);
    return; // ✅ stops here when errors exist
  }

  setValidationErrors({});
  // setIsConfirmationOpen(true);

  const formData = new FormData(event.target as HTMLFormElement);
  const data = Array.from(formData.entries()).reduce(
    (acc, [key, value]) => ({ ...acc, [key]: value }),
    {}
  );

  const changedData: Record<string, any> = { ...data };
  if (formValues.bill_cycle_start_date) {
    changedData.bill_cycle_start_date = formValues.bill_cycle_start_date;
  }
  if (formValues.btn_provider) {
    changedData.btn_provider = formValues.btn_provider;
  }
  if(formValues.email_invoice_formats){
    changedData.email_invoice_formats = formValues.email_invoice_formats;
  }
  console.log("changedData",changedData)

  SubmitData(changedData);
};


  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);

  };
  const handleOpenDepositModal = () => {
    setIsDepositModalOpen(true);
  };
  const handleOpenViewHistoryModal = () =>{
    setIsViewHistoryModalOpen(true);

  }
  const handleOpenAssignedAccountsModal: () => void = () => {
   setIsAssinedAccountsModalOpen(true);
  };
  const handleCloseDepositModal = () => {
    setIsDepositModalOpen(false);
    setIsViewHistoryModalOpen(false);
    setIsAssinedAccountsModalOpen(false);
    setTableData([])
    setHeaders([])
    setHeaderMap([])
    // fetchData()

  };
  const OnEditButtonChange = () => {
    if (isEditable) {
      // If in edit mode, cancel editing and fetch data
      setIsEditable(false);
    } else {
      // Enter edit mode
      fetchData();
      setIsEditable(true);
    }
  };
const handleInputChange = (name: any, value: any) => {
  setFormValues((prevState: any) => {
    let updatedFormData = { ...prevState, [name]: value };

    // If leaddays is cleared, clear latefee and latefeetype too
    if (name === "lead_days" && (!value || value === "")) {
       delete errors["late_fee"];
       delete errors["late_fee_type"];
       delete errors["minimum_amount"];
      // updatedFormData = {
      //   ...updatedFormData,
      //   late_fee: "",
      //   late_fee_type: "",
      //   minimum_amount: "",
      // };
      return updatedFormData;
    }

    // Handle late fee type changes
    if (name === "late_fee_type") {
      if (value !== "percentage") {
        // Clear minimum_amount when late_fee_type is not percentage
        updatedFormData = {
          ...updatedFormData,
          minimum_amount: "",
        };
        // Clear minimum_amount validation error
        // const newErrors = { ...validationErrors };
        // delete newErrors["minimum_amount"];
        // setValidationErrors(newErrors);
      }
      // Force component re-render for minimum amount field to appear/disappear
      setTimeout(() => {
        setFormValues(prev => ({ ...prev }));
      }, 0);
    }

    setisdisabled(false);
    // console.log("updatedFormData",updatedFormData)
    return updatedFormData;
  });

    setisdisabled(false);
    let errors = { ...validationErrors };
  if((name === "late_fee_type" || name === "late_fee")&& value ){
    delete errors["late_fee"];
    delete errors["late_fee_type"];
    delete errors["minumum_amount"];
  }
  if (name === "customer_name") {
    const regex = /^[a-zA-Z\s]+$/; // Only allow letters and spaces
    if (!regex.test(value)) {
      errors[name] = "Numbers are not allowed in customer name";
    } else {
      delete errors[name]; // Remove error if validation passes
    }
  }

  if (name === "email") {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (value && !emailRegex.test(value)) {
      errors[name] = "Please enter a valid email address";
    } else {
      delete errors[name];
    }
  }

  if (name === "postal_code") {
    const postalCodeRegex = /^\d{5}$/;
    if (value && !postalCodeRegex.test(value)) {
      errors[name] = "Postal code must be exactly 5 digits";
    } else {
      delete errors[name];
    }
  }
  if(name === "net_terms" || name === "lead_days" || name === "late_fee" || name ===  "credit_card_fee" || name === "minimum_amount"){
    const netTermsRegex = /^[0-9]+$/;
    if (value && !netTermsRegex.test(value)) {
      errors[name] = "Only Valid numeric values are allowed";
      } else {
        delete errors[name];
        }
  }
  if (name === "telephone_number") {
    const phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (value && !phoneRegex.test(value)) {
      errors[name] = "Please enter a valid phone number (e.g., 123-456-7890)";
    } else {
      delete errors[name];
    }
  }

    setValidationErrors(errors);

  };
  const handleDepositsInputChange = (field: string, value: any) => {
    setDepositData((prev) => ({
      ...prev,
      [field]: value,
    }));
    console.log("deposits data",depositData)
  };
  const showConfirmation = (): void => {
    let errors: { [key: string]: string } = { ...validationErrors };

    createModalData.forEach((column) => {
      if (column.mandatory) {
        const value = formValues[column.db_column_name];
        if (!value || (Array.isArray(value) && value.length === 0)) {
          errors[column.db_column_name] = `${column.display_name} is required.`;
        }
      }
    });

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      setIsConfirmationOpen(false);
    } else {
      setValidationErrors({});
      setIsConfirmationOpen(true);
    }
  };

  const sortedModalData = [...createModalData].sort(
    (a, b) => Number(a.table_header_order) - Number(b.table_header_order)
  );
  const currencyHeaders  =["Deposits","Account Balance","Account Due"]
  const percentileHeaders = ["Cost Recovery Fee","Network Access Fee","Credit Card Fee"]
 const formatCurrencyValue = (val: any) => {
  const num = Number(String(val).replace(/,/g, ""));
  if (isNaN(num)) return val;

  const formatted = Math.abs(num).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return num < 0 ? `-$${formatted}` : `$${formatted}`;
};
  const modalHeight = typeof window !== 'undefined' ? (window.innerHeight * 2.5) / 4 : 0;
  return (
    <div className="relative">
      {/* Show loader initially */}
      {loading ? (
        <div className="flex justify-center items-center h-[500px]">
          <Spin size="large" />
        </div>
      ) : (
        <div>
          {/* Form Layout */}
          <form onSubmit={handleSave} className="flex flex-col space-y-2 p-2 pt-4">
            <div
              className={`${
                createModalData.length > 2 ? "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4" : "flex flex-col space-y-4"
              }`}
            >
                {sortedModalData
                  .filter((field) => !["auto_debit_type","auto_debit_flag"].includes(field.db_column_name))
                  .map((field) => (
                <div key={field.id} className="mb-4 flex flex-col">
                  {field.db_column_name !== "deposits" && !["auto_debit_type","auto_debit_flag"].includes(field.db_column_name) &&(
                    <div className="flex flex-col">
                      <label className="field-label">
                        {field.display_name} {field.mandatory && !isEditable && <span className="text-red-500 ml-1">*</span>}
                        {field.db_column_name === "collection_step" && formValues?.["collection_step"] && !isEditable && (
                          <a
                            href="#"
                            className="underline text-blue-500 mb-1 w-[50px]"
                            onClick={handleOpenViewHistoryModal}
                          >
                            View History
                          </a>
                        )}
                         {field.db_column_name === "account_type" && formValues?.["account_type"] && formValues?.["account_type"] != "Standard" && (
                          <a
                            href="#"
                            className="underline text-blue-500 mb-1 w-[50px] ml-2"
                            onClick={handleOpenAssignedAccountsModal}
                          >
                            Assigned Accounts
                          </a>
                        )}
                      </label>
                    </div>
                  )}
                  {field.type === "text" && field.db_column_name === "deposits" && (
                    <>
                      {isEditable ? (
                        <span>Deposits</span>
                      ) : (
                        <a
                          href="#"
                          className="underline text-blue-500 mb-1 w-[50px]"
                          onClick={handleOpenDepositModal}
                        >
                          {field.display_name}
                          {field.mandatory && <span className="text-red-500 ml-1">*</span>}
                        </a>
                      )}

                      {validationErrors[field.db_column_name] && (
                        <div className="text-red-500 text-sm mt-1">
                          {validationErrors[field.db_column_name]}
                        </div>
                      )}

                      <Modal
                        open={isDepositModalOpen}
                        onCancel={handleCloseDepositModal}
                        title="Manage Deposits"
                        centered
                        width={1000}
                        bodyStyle={{
                          height: "auto",
                          overflowY: "auto",
                        }}
                        footer={
                          <div className="flex space-x-2 mt-4 justify-center">
                            <button
                              className="cancel-btn"
                              type="button"
                              onClick={handleCloseDepositModal}
                              disabled={loading}
                            >
                              Cancel
                            </button>
                            <button
                              className="save-btn"
                              type="button"
                              onClick={SaveDeposits}
                              disabled={loading}
                            >
                              Save
                            </button>
                          </div>
                        }
                      >
                        <div>
                          <div className="flex items-center justify-end mb-2">
                            <button className="save-btn !p-2" onClick={() => AddDeposits()}>
                              Add Deposit
                            </button>
                          </div>
                          {loading2 ? (
                            <div
                              className="flex justify-center items-center overflow-y-auto"
                              style={{ height: "270px" }}
                            >
                              <Spin size="large" />
                            </div>
                          ) : (
                            <EditableTableComponent
                              headers={headers}
                              headerMap={headerMap}
                              initialData={tableData}
                              visibleColumns={visibleColumns}
                              itemsPerPage={100}
                              popupHeading="Deposits"
                              pagination={pagination}
                              height={340}
                              setUpdatedTableData={setUpdatedTableData}
                            />
                          )}
                        </div>
                      </Modal>
                    </>
                  )}
                  {field.type === "text" && field.db_column_name === "late_fee" && (
                    <div className="relative flex flex-col w-full">
                      {/* {(currencyHeaders.includes(field.display_name)) && (
                        <span className="absolute text-gray-700 pl-2 pr-4 top-2.5 left-0">$</span>
                      )} */}
                      {isEditable ? (
                        formValues[field.db_column_name] ===0 ? (
                           <span>0</span>): formValues[field.db_column_name] ? (
                            formValues["late_fee_type"]?.toLowerCase() === "percentage" ?(
                              <span>{formValues[field.db_column_name] ?? 0}%</span>
                            ):(
                              <span>${formValues[field.db_column_name] ?? 0}</span>
                            )
                        ) : (
                          <div className="text-gray-500 select-none">-</div>
                        )
                      ) : (
                        <Input
                          type="text"
                          name={field.db_column_name}
                          className={'input'}
                          value={formValues[field.db_column_name] ?? ""}
                          required={field.mandatory}
                          onChange={(e) => handleInputChange(field.db_column_name, e.target.value)}
                          disabled={isEditable }
                          placeholder="Enter Late Fee"
                          suffix={formValues["late_fee_type"]?.toLowerCase() === "percentage" ? "%" : undefined}
                          prefix={formValues["late_fee_type"]?.toLowerCase() === "percentage" ? undefined : "$"}
                        />
                      )}
                      {validationErrors[field.db_column_name] && (
                        <div className="text-red-500 text-sm mt-1">
                          {validationErrors[field.db_column_name]}
                        </div>
                      )}
                    </div>
                  )}
                  {field.type === "text" && field.db_column_name !== "late_fee"  &&(
                    <div className="relative flex flex-col w-full">
                      {/* {(currencyHeaders.includes(field.display_name)) && (
                        <span className="absolute text-gray-700 pl-2 pr-4 top-2.5 left-0">$</span>
                      )} */}
                      {isEditable ? (
                        formValues[field.db_column_name] ===0 ? (
                          <span>0</span>):formValues[field.db_column_name] ? (
                          <span>
                            {currencyHeaders.includes(field.display_name)
                              ? `$${formValues[field.db_column_name] ?? 0}`
                              : percentileHeaders.includes(field.display_name)? `${formValues[field.db_column_name]}% `
                              : formValues[field.db_column_name]}
                          </span>
                        ) : (
                          <div className="text-gray-500 select-none">-</div>
                        )
                      ) : (
                        <Input
                          type="text"
                          name={field.db_column_name}
                          prefix = {currencyHeaders.includes(field.display_name) ? "$" : undefined}
                          suffix={percentileHeaders.includes(field.display_name) ? "%" : undefined}
                          className={[
                            "account_ageing"
                          ].includes(field.db_column_name)
                            ? `non-editable-input1 !text-black`
                            : isEditable && !currencyHeaders.includes(field.display_name)
                              ? `non-editable-input1 !text-black`
                                :`input`}
                            value={
                                formValues[field.db_column_name] ?? ""
                            }
                          required={field.mandatory}
                          onChange={(e) => handleInputChange(field.db_column_name, e.target.value)}
                          disabled={["account_ageing", "account_balance", "amount_due", "deposits"].includes(
                            field.db_column_name
                          ) || isEditable}
                          // prefix={currencyHeaders.includes(field.display_name) ? "$" : undefined}
                        />
                      )}
                      {validationErrors[field.db_column_name] && (
                        <div className="text-red-500 mt-1">
                          {validationErrors[field.db_column_name]}
                        </div>
                      )}
                    </div>
                  )}
                  
                  {field.type === "dropdown" && (
                    <div className="flex flex-col w-full">
                      {isEditable ? (
                        formValues[field.db_column_name] ? (
                          <span>{formValues[field.db_column_name]}</span>
                        ) : (
                          <div className="text-gray-500 select-none">-</div>
                        )
                      ) :
                        <Select
                            styles={(field.db_column_name === "parent_acc_lv" &&
                              formValues["account_type"] !== "Child") 
                              // (field.db_column_name === "btn_provider" && formValues["bill_cycle_start_date"]) ||
                              // (field.db_column_name === "late_fee_type" && !formValues["lead_days"])
                              ? NonEditableDropdownStyles
                              : DropdownStyles}
                            name={field.db_column_name}
                            className="w-full"
                            options={field.db_column_name === "collection_step"
                              ? ModalData?.dropdown?.[field.db_column_name]
                                ? Object.keys(ModalData.dropdown[field.db_column_name]).map((key) => ({
                                  label: key,
                                  value: key,
                                }))
                              : []
                            : ModalData?.dropdown?.[field.db_column_name]?.map((option: string) => ({
                                label: option,
                                value: option,
                              })) || []
                          }
                          required={field.mandatory}
                          isDisabled={
                            (field.db_column_name === "parent_acc_lv" &&
                              formValues["account_type"] !== "Child") 
                            // (field.db_column_name === "btn_provider" && formValues["bill_cycle_start_date"]) ||
                            // (field.db_column_name === "late_fee_type" && !formValues["lead_days"])
                          }
                          value={
                            field.db_column_name === "parent_acc_lv" && formValues["account_type"] !== "Child"
                              ? null
                              : formValues[field.db_column_name]
                                ? {
                                  label: formValues[field.db_column_name],
                                  value: formValues[field.db_column_name],
                                }
                                : null
                          }
                          isClearable
                          onChange={(value: any) => {
                            handleInputChange(field.db_column_name, value ? value.value : null);
                          }}
                          menuPlacement={field.db_column_name === "late_fee_type"? 'top':'auto'}
                        />
                      }
                      {validationErrors[field.db_column_name] && (
                        <div className="text-red-500 text-sm mt-1">
                          {validationErrors[field.db_column_name]}
                        </div>
                      )}
                    </div>
                  )}
                      {field.type === "multi_dropdown" && (
                        <div className="flex flex-col w-full">
                          {isEditable ? (
                            formValues[field.db_column_name] ? (
                              <span>{(Array.isArray(formValues[field.db_column_name]) ? formValues[field.db_column_name].join(", ") : formValues[field.db_column_name]) || "-"}</span>
                            ) : (
                              <div className="text-gray-500 select-none">-</div>
                            )
                          ) :
                            (
                              <>
                                <AntDSelect
                                  mode="multiple"
                                  allowClear
                                  showArrow
                                  showSearch
                                  style={{ width: "100%" }}
                                  value={
                                    Array.isArray(formValues[field.db_column_name])
                                      ? formValues[field.db_column_name]
                                      : formValues[field.db_column_name]
                                        ? [formValues[field.db_column_name]]
                                        : []
                                  }
                                  options={
                                    ModalData?.dropdown?.[field.db_column_name]?.map((item: string) => ({
                                      label: String(item ?? ""),
                                      value: String(item ?? ""),
                                    })) || []
                                  }
                                  onChange={(selectedValues) => {
                                    console.log("selectedValues", selectedValues)
                                    // console.log("selectedValues.map((val) => String(val)", selectedValues.map((val) => String(val)))

                                    setFormValues((prev) => ({
                                      ...prev,
                                      [field.db_column_name]: selectedValues.map((val: any) => String(val)),
                                    }))
                                  }
                                  }
                                  optionLabelProp="label"
                                  maxTagCount={1}
                                  maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
                                  tagRender={(props) => {
                                    const { label, closable, onClose } = props;
                                    const labelString = String(label);
                                    const truncatedLabel =
                                      labelString.length > 190
                                        ? `${labelString.slice(0, 187)}...`
                                        : labelString;

                                    // Combine all selected labels for tooltip
                                    const allSelectedLabels = Array.isArray(formValues[field.db_column_name])
                                      ? formValues[field.db_column_name].join(", ")
                                      : "";

                                    return (
                                      <span
                                        className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap relative shadow-lg rounded-lg max-w-[185px]"
                                        title={allSelectedLabels}
                                        style={{
                                          maxWidth: "165px",
                                          wordWrap: "break-word",
                                          overflow: "hidden",
                                        }}
                                      >
                                        {truncatedLabel}
                                        {closable && (
                                          <CloseOutlined
                                            onClick={onClose}
                                            style={{ marginLeft: 4, cursor: "pointer" }}
                                          />
                                        )}
                                      </span>
                                    );
                                  }}
                                  dropdownRender={(menu) => {
                                    const filteredOptions =
                                      ModalData?.dropdown?.[field.db_column_name]?.filter((item: string) =>
                                        item.toLowerCase().includes(btnProviderSearchValue.toLowerCase())
                                      ) || [];

                                    return (
                                      <div className="relative shadow-lg rounded-lg max-w-full">
                                        <div style={{ padding: "4px 8px" }}>
                                          <Input
                                            placeholder="Search..."
                                            size="middle"
                                            value={btnProviderSearchValue}
                                            onChange={(e) => setBtnProviderSearchValue(e.target.value)}
                                          />
                                        </div>
                                        <VirtualList
                                          data={filteredOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                          }))}
                                          height={250}
                                          itemHeight={0}
                                          itemKey="value"
                                        >
                                          {(item) => (
                                            <div key={item.value} className="ml-2 mb-2 flex items-center">
                                              <Checkbox
                                                checked={
                                                  Array.isArray(formValues[field.db_column_name]) &&
                                                  formValues[field.db_column_name].includes(item.value)
                                                }
                                                onChange={(e) => {
                                                  console.log("formValues", formValues)
                                                  setFormValues((prev) => ({
                                                    ...prev,
                                                    [field.db_column_name]: e.target.checked
                                                      ? [...(prev[field.db_column_name] ?? []), item.value]
                                                      : (prev[field.db_column_name] ?? []).filter(
                                                        (val: any) => val !== item.value
                                                      ),
                                                  }))
                                                }
                                                }
                                              >
                                                {item.label}
                                              </Checkbox>
                                            </div>
                                          )}
                                        </VirtualList>
                                      </div>
                                    );
                                  }}
                                  onDropdownVisibleChange={(open) => {
                                    if (!open) setBtnProviderSearchValue(""); // Clear search when dropdown closes
                                  }}
                                />
                                {validationErrors[field.db_column_name] && (
                                  <span className="text-red-500">
                                    {validationErrors[field.db_column_name]}
                                  </span>
                                )}
                              </>

                            )}
                          {validationErrors[field.db_column_name] && (
                            <div className="text-red-500 text-sm mt-1">
                              {validationErrors[field.db_column_name]}
                            </div>
                          )}
                        </div>
                      )}
                  
                  

                  {field.type === "date_range" && (
                    <div className="flex flex-col w-full">
                      <RangePicker
                        style={{ marginLeft: "2px", marginRight: "5px", height: "43px" }}
                        name={field.db_column_name}
                        className="w-full"
                        format="MM-DD-YY"
                        getPopupContainer={(trigger) => trigger.parentElement!}
                        required={field.mandatory}
                      />
                      {validationErrors[field.db_column_name] && (
                        <div className="text-red-500 text-sm mt-1">
                          {validationErrors[field.db_column_name]}
                        </div>
                      )}
                    </div>
                  )}
                  {field.type === "date" && (
                    <div className="flex flex-col w-full">
                      {isEditable ? (
                        formValues[field.db_column_name] ? (
                          <span>{formValues[field.db_column_name]}</span>
                        ) : (
                          <div className="text-gray-500 select-none">-</div>
                        )
                      ) : (
                      <DatePicker
                        value={
                          // field.db_column_name === "bill_cycle_start_date" && formValues["btn_provider"]? null:
                          formValues[field.db_column_name]
                            ? dayjs(formValues[field.db_column_name])
                            : null
                        }
                        onChange={(date, dateString) =>
                          handleInputChange(field.db_column_name, dateString)
                        }
                        format="MM-DD-YY"
                         placement="bottomLeft"
                        getPopupContainer={(triggerNode) => triggerNode.parentElement as HTMLElement}
                        className={` ${(isEditable || (field.db_column_name === "bill_cycle_start_date_btn_provider")) ? "non-editable-input":"input"}`}
                            disabledDate={(current) => {
                               const selectedDate = formValues["bill_cycle_start_date"]
                                ? dayjs(formValues["bill_cycle_start_date"])
                                : null;

                              if (field.db_column_name === 'billing_cycle_range') {
                                return current.date() >= 29;
                              }
                            //   else if (field.db_column_name === "bill_cycle_start_date" && originalBillCycleStartDate) {
                            //   return current && current < dayjs(originalBillCycleStartDate).startOf("day");
                            // }
                              else if (field.db_column_name === 'inactivity_start') {
                                return current && current < dayjs().startOf('day');
                              }
                              return false;
                            }}
                      disabled={isEditable || (field.db_column_name === "bill_cycle_start_date_btn_provider")
                        || (field.db_column_name === "bill_cycle_start_date" && !moduleFeatures.includes("Edit Bill Cycle-Customer Account Details"))
                        // || (field.db_column_name === "bill_cycle_start_date" ? formValues["btn_provider"] : "")
                        }
                      />
                    )}
                      {validationErrors[field.db_column_name] && (
                        <div className="text-red-500 text-sm mt-1">
                          {validationErrors[field.db_column_name]}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
              {formValues["late_fee_type"]?.toLowerCase() === "percentage" && (
                    // <div key={`minimum_amount_field_${Date.now()}`} className="flex flex-col">
                      <div className="flex flex-col">
                        <label className="field-label">
                          Minimum Amount
                          {!isEditable && <span className="text-red-500 ml-1">*</span>}
                        </label>
                        <div className="flex flex-col w-full">
                          {isEditable ? (
                        <span>
                          {formValues["minimum_amount"] === 0
                            ? "$0"
                            : formValues["minimum_amount"]
                              ? `$${formValues["minimum_amount"]}`
                              : <span className="text-gray-500 select-none">-</span>}
                        </span>
                          ) : (
                            <Input
                              type="text"
                              name="minimum_amount"
                              className="input"
                              prefix="$"
                              value={formValues?.minimum_amount ?? ""}
                              required={true}
                              onChange={(e) => handleInputChange("minimum_amount", e.target.value)}
                              disabled={isEditable}
                              placeholder="Enter Minimum Amount"
                            />
                          )}
                          {validationErrors.minimum_amount && !isEditable && (
                            <div className="text-red-500 text-sm mt-1">
                              {validationErrors.minimum_amount}
                            </div>
                          )}
                        </div>
                      </div>
                    // </div>
                  )}
                  {/* Auto Debit Flag Checkbox */}
                  <div className={`flex flex-col w-full mb-4 ${isEditable ? "" : "mt-6"}`}>
                    {isEditable ? (
                      formValues["auto_debit_flag"] ? (
                        <>
                        <label className="field-label">Auto Debit Flag</label>
                        <span>Enabled</span>
                        </>
                      ) : (
                        <>
                        <label className="field-label">Auto Debit Flag</label>
                        <span>Disabled</span>
                        </>
                      )
                    ) : (
                      <Checkbox
                        checked={!!formValues["auto_debit_flag"]}
                        onChange={(e) => handleInputChange("auto_debit_flag", e.target.checked)}
                        disabled={!moduleFeatures.includes("Enable Auto Debit-Customer Account Details")} // ADD THIS LINE
                      >
                        Enable Auto Debit
                      </Checkbox>
                    )}

                    <input
                      type="hidden"
                      name="auto_debit_flag"
                      value={formValues["auto_debit_flag"] ? "true" : "false"}
                    />

                    {validationErrors["auto_debit_flag"] && (
                      <div className="text-red-500 text-sm mt-1">
                        {validationErrors["auto_debit_flag"]}
                      </div>
                    )}
                  </div>

                  {/* Auto Debit Type Toggle (only if flag is checked) */}
                  {formValues["auto_debit_flag"] && (
                    <div className="flex flex-col w-full">
                      <label className="field-label mb-1">Auto Debit Retry</label>

                      {(() => {
                        const checkedValue =
                          ModalData?.dropdown?.["auto_debit_type"]?.[0] || "Weekly";
                        const unCheckedValue =
                          ModalData?.dropdown?.["auto_debit_type"]?.[1] || "Daily";

                        return (
                          <>
                            {isEditable ? (
                              formValues["auto_debit_type"] ? (
                                <span>{formValues["auto_debit_type"]}</span>
                              ) : (
                                <div className="text-gray-500 select-none">-</div>
                              )
                            ) : (
                              <>
                                <Switch
                                  style={{
                                    width: 80,
                                    backgroundColor: "#1890ff", // same color for both states
                                    borderRadius: 20,
                                  }}
                                  checked={formValues["auto_debit_type"] === checkedValue}
                                  onChange={(checked) =>
                                    handleInputChange(
                                      "auto_debit_type",
                                      checked ? checkedValue : unCheckedValue
                                    )
                                  }
                                  disabled={!moduleFeatures.includes("Enable Auto Debit-Customer Account Details")}
                                  checkedChildren={checkedValue}
                                  unCheckedChildren={unCheckedValue}
                                />

                                <input
                                  type="hidden"
                                  name="auto_debit_type"
                                  value={formValues["auto_debit_type"] || ""}
                                />
                              </>
                            )}

                            {validationErrors["auto_debit_type"] && (
                              <div className="text-red-500 text-sm mt-1">
                                {validationErrors["auto_debit_type"]}
                              </div>
                            )}
                          </>
                        );
                      })()}
                    </div>
                  )}
            </div>
           { moduleFeatures.includes("Edit - Customer Account Details") && createModalData.length > 0 && ( <div className="flex space-x-4 mt-6 justify-center">
                <button
                  onClick={OnEditButtonChange}
                  className={isEditable ?  'save-btn':'cancel-btn' }
                  type="button"
                >
                  {isEditable ? 'Edit':'Cancel'  }
                </button>
                <button
                className={isEditable ? "cancel-btn cursor-not-allowed" : "save-btn"}
                type="submit"
                disabled={isEditable}
              >
                Save
              </button>
              </div>)}
          </form>
          {isConfirmationOpen && (
            <div className="confirmation-screen absolute inset-0 bg-black bg-opacity-50 flex justify-center items-center">
              <div className="confirmation-box bg-white p-4 rounded">
                <p>
                  Are you sure you want to create this {title.toLocaleLowerCase()}?
                </p>
                <div className="mt-4 flex justify-around">
                  <button onClick={handleCancelConfirmation} className="cancel-btn">
                    Cancel
                  </button>
                  <button type="submit" className="save-btn">
                    Confirm
                  </button>
                </div>
              </div>
            </div>
          )}
          <Modal
            open={isViewHistoryModalOpen}
            onCancel={handleCloseDepositModal}
            title='Collection History'
            footer={ <div className="flex space-x-2 mt-4 justify-center">
              <button
                className="cancel-btn"
                type="button"
                onClick={handleCloseDepositModal}
                disabled={loading}
              >
                Cancel
              </button>
              <button
                className="save-btn"
                type="button"
                onClick={SaveCollections}
                disabled={loading}
              >
                Save
              </button>
            </div>}
            centered
            width={1000}
            bodyStyle={{
              height: 'auto',
              overflowY: 'auto',
          }}

          >
            <div >
              <div className="flex items-center justify-end mb-2">
                <button className="save-btn" onClick={() => AddCollection()}>
                  Add Step
                </button>
              </div>
              {loading2 ? (
                <div className="flex justify-center items-center" style={{ height:`${viewportHeight - 330}px` }}>
                  <Spin size="large" />
                </div>
              ) : (
                <EditableTableComponent
                  headers={headers}
                  headerMap={headerMap}
                  initialData={tableData}
                  visibleColumns={visibleColumns}
                  itemsPerPage={100}
                  popupHeading="Collection"
                  pagination={pagination}
                  generalFields={generalFields}
                  height={340}
                  setUpdatedTableData={setUpdatedTableData}
                />
              )}
             
            </div>
          </Modal>
           <Modal
            open={isAssinedAccountsModalOpen}
            onCancel={handleCloseDepositModal}
            title='Assigned Accounts'
            footer={ null}
            centered
            width={900}
            bodyStyle={{
              height: 'auto',
              overflowY: 'auto',
          }}

          >
            <div >
              
              {loading2 ? (
                <div className="flex justify-center items-center" style={{ height:`${viewportHeight - 330}px` }}>
                  <Spin size="large" />
                </div>
              ) : (
                <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              // allowedActions={allowedActions}
              popupHeading="Customer Profiles1"
              pagination={pagination}
              advancedFilters={filteredData}
              // height = {showAdvanced?300:235}
              height = {300}
              onTabsClose={(accountNumberFromChild:any) => fetchData(accountNumberFromChild)}
            />
              )}
             
            </div>
          </Modal>
        </div>
      )}
    </div>
  );
  
};

export default BasicDetails;
