"use client";

import React, { useState, lazy, Suspense, useEffect, useRef } from "react";
import { useSidebarStore } from "@/app/stores/navBarStore";
import { useRouter } from 'next/navigation';
import { Spin } from "antd";
import { CloseOutlined } from "@ant-design/icons";
import { useAuth } from "@/app/components/auth_context";



const BasicDetails = lazy(() => import("./basicDetails"));
const Services = lazy(() => import("./services"));
const BillingAndCollections = lazy(() => import("./billings_collections/page"))
interface AdvancedTabProps {
  row?: any;
  onClose: () => void;}

const AdvancedTabs: React.FC<AdvancedTabProps> = ({  row,onClose }) => {
  const router = useRouter();
    const ACTIVE_TAB_KEY = "advancedTabs.activeTab";
    const validTabs = ["BasicDetails", "services", "billingandcollections"];
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [isHydrated, setIsHydrated] = useState(false);
    const [loading, setLoading] = useState(false);
    const isExpanded = useSidebarStore((state: any) => state.isExpanded);
    const [isOpen, setIsOpen] = useState(true);
// const hasRestored = useRef(false);
  const handleCreateModalClose = () => {
  };

  useEffect(() => {
    if (!isHydrated || !activeTab) return;

    sessionStorage.setItem(ACTIVE_TAB_KEY, activeTab);
  }, [activeTab, isHydrated]);


  useEffect(() => {
    const storedTab = sessionStorage.getItem(ACTIVE_TAB_KEY);

    if (storedTab && validTabs.includes(storedTab)) {
      setActiveTab(storedTab);
    } else {
      setActiveTab("BasicDetails");
    }

    setIsHydrated(true);
  }, []);


  const handleClose = () => {
    console.log("AdvancedTab is closing...");
    sessionStorage.removeItem(ACTIVE_TAB_KEY);
    onClose(); // Call the parent's close function
  };
 
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    // <Suspense
    // fallback={
    //   <div className="flex justify-center items-center h-screen">
    //       <Spin size="large" />
    //     </div>
    // }
    // >
      <div
        // style={{
        //   position: "absolute",
        //   top: 0,
        //   left: 0,
        //   width: "100%",
        //   bottom:0,
        //   // backgroundColor: "#F9FAFB",
        //   // color: "#000",
        //   zIndex: 50,
        // }}
        className="advanced-tabs-overlay"
      >
        <div className="billing-collections-sub-tabs-content">
        {/* Tabs Section */}
        <div className="">
        <div
          className={`shadow-md tabs-color mb-4 gap-4  tabs top-[70px] ${isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`}
        >
        <button
            className={`tab-headings ${
              activeTab === "BasicDetails" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("BasicDetails")}
          >
            Account Details
          </button>
          <button
            className={`tab-headings ${
              activeTab === "services" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("services")}
          >
            Services
          </button>
          <button
            className={`tab-headings ${
              activeTab === "billingandcollections" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("billingandcollections")}
          >
            Billing and  Collections
          </button>
         
          { (
              <div className="hidden md:flex flex-col md:flex-row absolute right-[1%] top-[1%] rounded-full w-[25px] text-[20px] flex space-x-4 mt-2">
                <CloseOutlined
                  className="text-gray-500 cursor-pointer"
                  onClick={handleClose}
                  title="Go back"
                />

              </div>
            )}
            { (
              <div className="md:hidden absolute right-[1%] top-[10%] rounded-full w-[25px] text-[20px] flex space-x-4">
                <CloseOutlined
                  className="text-gray-500 cursor-pointer"
                  onClick={handleClose}
                  title="Go back"
                />

              </div>
            )}
          </div>
        </div>

        {/* Content Section */}
        <div
          className="pt-[60px] h-[calc(100vh-150px)]"
        >          
        {activeTab === "BasicDetails" && <BasicDetails 
                                            isOpen={isOpen}
                                            row={row}
                                            onClose={handleCreateModalClose}
                                            title="Customer"/>}
          {activeTab === "billingandcollections" && <BillingAndCollections  row={row}/>}                                  
          {activeTab === "services" && <Services row={row} />}
        </div>
        </div>
      </div>
    // </Suspense>
  );
};

export default AdvancedTabs;
