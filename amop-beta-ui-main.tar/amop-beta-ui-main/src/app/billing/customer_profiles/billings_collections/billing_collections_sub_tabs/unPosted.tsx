/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, ArrowPathIcon, ArrowUpTrayIcon, ArrowUturnLeftIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, Input, Upload, message } from "antd";
import Dropdown from "../../../killbill_components/dropdownComponent";

import { useAuth } from "../../../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../../../components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "../../../../sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
import { ENV_ROUTES } from "../../../../components/routes/route_constants";
import { exportLoadingStore } from "../../../../stores/ExportLoadingStore";
import { DownloadOutlined, PlusCircleOutlined, UndoOutlined, UploadOutlined } from "@ant-design/icons";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { fireSideCannons } from "@/app/components/confetti";

const KillbillTableComponent = lazy(
  () => import("../../../killbill_components/table__component")
);
// const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("../../../../components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../../killbill_components/advanced__search")
);
const CreateBillModal = lazy(
  () => import("./createBill")
);
interface UnpostedProps {
  row?: any;
 
}
interface CreateBillModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCycle: string;
  onCreate: (dueDate: Dayjs | null) => void; 
  dueDate: Dayjs | null;
}
const UnPosted: React.FC <UnpostedProps>= ({row}) => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination,combineAdnvaceStoredpagination,setCombineAdnvaceStoredpagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [ReverseRowData, setReverseRowData] = useState<any[]>([]);
  const { setUserProfileDetails ,isSelectAllChecked , setIsSelectAllChecked ,searchIdsforSelectAll , setSearchIdsforSelectAll} = useCustomerProfileStore();
  const accountNumber = sessionStorage.getItem("accountNumber");
  const [isCreateBillModalOpen, setCreateBillModalOpen] = useState(false);
  const [isApplyToBillModalOpen, setApplyToBillModalOpen] = useState(false);
  const [isPushChargesModalOpen, setPushChargesModalOpen] = useState(false);
  const [currentCycle, setCurrentCycle] = useState("");
  const [dueDate, setDueDate] = useState<Dayjs | null>(null);
  const [unpostedTotalCharge, setUnpostedTotalCharge] = useState(0);
  const [accountStatus , setAccountStatus] = useState(false);
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [serviceProvider, setServiceProvider] = useState<any>(null);
  const [providerError, setProviderError] = useState<string>('');
  const [currentBillCycle, setCurrentBillCycle] = useState<string>("");
  const [providerCycles, setProviderCycles] = useState<Record<string, string>>({});
//   const { RangePicker } = DatePicker; 
//   const [currentBillCycle, setCurrentBillCycle] = useState<
//   [Dayjs | null, Dayjs | null]
// >([null, null]);
  const hasFetchedData = useRef(false);
  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  // const queryClient = useQueryClient();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  const fetchData = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    setIsSelectAllChecked(false)
    setSearchIdsforSelectAll([])
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/unposted_bills_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        table_name:"customer_charges",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setUserProfileDetails(parsedData?.user_profile_details || {});
          const unposted_total_charge_ = parsedData?.unposted_total_charge || 0;
          setUnpostedTotalCharge(unposted_total_charge_);
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Unposted"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const current_cycle_ = parsedData?.current_cycle || '';
        console.log("current_cycle_", current_cycle_);
        setCurrentCycle(current_cycle_);
        setDueDate(parsedData?.due_date_of_this_bill ? dayjs(parsedData.due_date_of_this_bill) : null);
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_",generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []
          if(parsedData?.account_status){
             const allowedActions_:any=[]
          if(featres_.includes("Edit-Billing Services")){
            allowedActions_.push("edit")
          }
          // if(featres_.includes("Delete-Billing Services")){
          //   allowedActions_.push("delete")
          // }
          if(featres_.includes("Copy-Billing Services")){
            allowedActions_.push("copy")
          }
          if(featres_.includes("Discontinue-Billing Services")){
            allowedActions_.push("deactivate")

          }
          
          setAllowedActions(allowedActions_)
          }
          else{
            setAllowedActions([])
          }
           setAccountStatus(parsedData?.account_status || "");
          const createModalData_=parsedData?.header_map?.["Billing and Collections Unposted"]?.pop_up||[]
          console.log("createModalData_",createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          const activetab_ = sessionStorage.getItem("billingCollectionsTabs.activeTab")
          if(activetab_ === "unposted"){
            setTableData(parsedData?.data?.billing_and_collections_unposted || []);
            settabledata(parsedData?.data?.billing_and_collections_unposted || [])
          }
          setProviderCycles(parsedData?.provider_cycles_not_charged)
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateRow = async () => {
    handleCreateBillModalClose();
    await fetchData()
    return true;
  };
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [partner]);
const startExportPolling = async (sessionID: string, key: string) => {
  const module_name_ =
    key === "unposted"
      ? "Unposted Reverse Transaction"
      : "Push Charges for Unposted Charges";

  addExport(key, module_name_);

  let attempts = 0;
  const MAX = 180;
  let timeoutId: any = null;
  let stopped = false; // 👈 guard flag

  const poll = async () => {
    if (stopped) return; // 🛑 hard stop

    attempts++;

    try {
      const payload = {
        tenant_name: partner || "default_value",
        username,
        path: "/get_export_status",
        role_name: role,
        access_token: token,
        sessionID,
        db_name: selectedDb,
        billing_db_name: selectedBillingDb,
        module_name: module_name_,
        tenant_id: tenant_id_,
      };

      const res = await axios.post(ENV_ROUTES.BP_CUSTOMER_PROFILES, {
        data: payload,
      });

      const parsed = JSON.parse(res.data.body);
      console.log("Polling status:", parsed);

      if (
        parsed.flag === true &&
        parsed.export_status_data?.status_flag?.toLowerCase() === "success"
      ) {
        stopped = true;               // ✅ stop future runs
        clearTimeout(timeoutId);      // 🧹 clear pending timeout

        notification.success({
          message: "Success",
          description: parsed.export_status_data.url || `${module_name_} completed successfully`,
          placement: "top",
        });
        fireSideCannons()
        removeExport(key);
        await fetchData();
        return;
      }
      if(parsed.flag === true && parsed.export_status_data?.status_flag?.toLowerCase() === "cancelled"){
        stopped = true;               
        clearTimeout(timeoutId);
        notification.warning({
          message: "Warning",
          description: parsed.export_status_data.url || `${module_name_} was cancelled.`,
          placement: "top",
        });
        removeExport(key);
        await fetchData();
      }

      if (attempts >= MAX) {
        stopped = true;
        clearTimeout(timeoutId);
        removeExport(key);
        return;
      }

      timeoutId = setTimeout(poll, 5000); // ⏱ schedule next poll
    } catch (err) {
      stopped = true;
      clearTimeout(timeoutId);
      console.error("Polling failed:", err);
      removeExport(key);
    }
  };
setTimeout(() => {
  poll();
}, 5000);
};


  const handleReverseTransaction = async () => {
    try {
      // setLoading(true);

      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const updatedReverseRowData = ReverseRowData.map(row => ({
        ...row,
        is_active: false,
        is_deleted: true,
      }));

      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/unposted_reverse_transaction",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",
        changed_data: updatedReverseRowData,
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        billing_db_name: selectedBillingDb,
        ...metaData,
        select_all: isSelectAllChecked,
        search_select_all: isSelectAllChecked ? searchIdsforSelectAll : [],
        table_name: "customer_charges",
        sessionID: sessionId,
        tenant_id: tenant_id_,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",
      };

      // 🚀 FIRE API (NO WAIT)
      axios.post(url, { data });

     
        startExportPolling(sessionId || "","unposted");

      // 🔁 START POLLING IMMEDIATELY
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred",
        centered: true,
      });
      removeExport("unposted_reverse");
    }
  };

  const exportToExcel = (headers: any, rowData: any, fileName = 'exported_data.xlsx') => {
    // Map the rowData to an array of objects with headers as keys
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });

    // Create a new worksheet from the formatted data
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

    // Write the workbook and trigger download
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
  
    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/unposted_export",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        account_number:accountNumber,
        table_name:"customer_charges",
        db_name: selectedDb,
        sessionID: sessionId,
        billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        ...metaData,
        feature_module_name: "Billing and Collections Unposted",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag:"True",
        main_module_name: "Customer Profiles",
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
  
      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
   
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Billing and Collections Unposted.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
                fireSideCannons();
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };
  


  const handleExport = async (key: string, heading: string) => {
  
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
  
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          account_number:accountNumber,
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Unposted",
          module_name: "Billing and Collections Unposted",
          // col_sort:{charge_description: "ASC"}
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if  (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Unposted",
          module_name: "Billing and Collections Unposted",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          // col_sort:{charge_description: "ASC"},
          username: username,

        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Unposted",
          module_name: "Billing and Collections Unposted",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          // col_sort:{charge_description: "ASC"},
          username: username,
          
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Billing and Collections Unposted.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons();
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };

  const handleCreateBillModalOpen = () => {
  setCreateBillModalOpen(true);
};
 const handleUploadClick = () => {
    setIsUploadModalVisible(true);
  }
    const handleUploadModalClose = () => {
    setIsUploadModalVisible(false);
  };
  const downloadBlob = (base64Blob: string, file_name: any) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = `${file_name}.xlsx` || "Customer Service.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleChange = (info: any) => {
    if (info.file.status === "done") {
      const file = info.file.originFileObj;
      const reader = new FileReader();

      reader.onload = (e: any) => {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: "array", cellDates: false });

        const allSheetsData = workbook.SheetNames.map((sheetName) => {
          const sheet = workbook.Sheets[sheetName];

          // Convert to JSON with raw: false to preserve formatted text
          const json = XLSX.utils.sheet_to_json(sheet, {
            raw: false,  // This will read formatted values as strings
            defval: ''   // Default empty values
          }) as Record<string, any>[];

          // Data is already in the correct format, just pass it through
          const parsed = json.map((row) => {
            const newRow: Record<string, any> = {};

            for (const key in row) {
              // All values including dates are now strings, no conversion needed
              newRow[key] = row[key];
            }

            return newRow;
          });

          return { sheetName, data: parsed };
        });

        console.log("All Sheets Data:", allSheetsData);
        handleUpload(JSON.stringify(allSheetsData), "Unposted Upload");
        setUploadKey(prev => prev + 1);
      };

      reader.readAsArrayBuffer(file);
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      // setIsFileSelected(false);

    }
  };
  const pollExportStatus = async (
    baseData: any,
    onSuccess: (message: string) => void,
    onError: (message: string) => void
  ) => {
    const POLL_INTERVAL = 5000;
    let intervalId = setInterval(async () => {
      try {
        const response = await axios.post(ENV_ROUTES.BP_CUSTOMER_PROFILES, {
          data: {
            ...baseData,
            path: "/get_export_status",
          },
        });

        const resp = JSON.parse(response.data.body);

        if (resp?.flag && resp?.export_status_data?.status_flag === "Success") {
          clearInterval(intervalId);
          onSuccess(resp.export_status_data.url);
        }
      } catch (err) {
        clearInterval(intervalId);
        onError("Failed to fetch export status");
      }
    }, POLL_INTERVAL);
  };
  function sanitizeUsername(username: string) {
  return username.replace(/[^a-zA-Z0-9]/g, "_");
}

const handleUpload = async (blob: string, key: string) => {
  setIsUploadModalVisible(false);
  addExport(key, key);
  
  try {
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;

    const data = {
      accountNumber,
      tenant_name: partner || "default_value",
      username: sanitizeUsername(username || ""),
      firstLastName,
      path: "/create_s3_folder_and_get_url",
      module_name: "Unposted Charges Upload",
      role_name: role,
      Partner: partner,
      account_number: accountNumber,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      tenant_id: tenant_id_,
      main_module_name: "Customer Profiles",
      db_name: selectedDb,
      billing_db_name: selectedBillingDb,
      sessionID: sessionId,
    };

    // Step 1: Get S3 folder URL
    const response = await axios.post(url, { data });
    const body = JSON.parse(response.data.body || "{}");
    
    if (body.flag && body.folder_url) {
      const folderUrl = body.folder_url;
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const fileName = `unposted_data_.txt`;
      const fileUrl = `${folderUrl}/${fileName}`;
      
      // Step 2: Upload the data to S3
      try {
        await axios.put(fileUrl, blob, {
          headers: {
            'Content-Type': 'text/plain',
          },
        });
        
        console.log("File uploaded successfully to:", fileUrl);
        
        // ✅ Step 3: Trigger bulk_upload_unposted_router (fire and forget)
        const bulkUploadData = {
          accountNumber,
          tenant_name: partner || "default_value",
          username,
          username_for_s3 :sanitizeUsername(username || ""),
          firstLastName,
          path: "/bulk_upload_unposted_router",
          module_name: "Unposted Charges Upload",
          role_name: role,
          Partner: partner,
          account_number: accountNumber,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          tenant_id: tenant_id_,
          main_module_name: "Customer Profiles",
          db_name: selectedDb,
          billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          file_name: fileName,
        };

        // Fire and forget the bulk upload trigger
        axios.post(url, { data: bulkUploadData }).catch((err) => {
          console.error("Bulk upload trigger failed", err);
        });

        // ✅ Step 4: Poll for bulk import status
        const pollPayload = {
          tenant_name: partner || "default_value",
          username,
          role_name: role,
          Partner: partner,
          access_token: token,
          account_number: accountNumber,
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id: tenant_id_,
          db_name: selectedDb,
          billing_db_name: selectedBillingDb,
          module_name: "Unposted Charges Upload",
          main_module_name: "Customer Profiles",
        };

        let attempts = 0;
        const MAX_ATTEMPTS = 180;
        let isPolling = false;

        const pollStatus = async () => {
          if (isPolling) return;
          
          isPolling = true;
          attempts++;

          try {
            const res = await axios.post(url, {
              data: {
                ...pollPayload,
                path: "/get_export_status", // Poll the export status
              },
            });

            const pollBody = JSON.parse(res.data.body || "{}");

            if (pollBody?.flag && pollBody?.export_status_data?.status_flag === "Success") {
              clearInterval(interval);
              
              notification.success({
                message: "Success",
                description: pollBody.export_status_data.url || "File uploaded and processed successfully!",
                placement: "top",
              });
              fireSideCannons()
              removeExport(key);
              fetchData();

            }

            if (attempts >= MAX_ATTEMPTS) {
              clearInterval(interval);
              notification.error({
                message: "Timeout",
                description: "Upload processing is taking longer than expected. Please check status later.",
                placement: "top",
                duration: 3,
              });
              removeExport(key);
            }
          } catch (error) {
            console.error("Polling error:", error);
            clearInterval(interval);
            notification.error({
              message: "Error",
              description: "Failed to check upload status",
              placement: "top",
              duration: 3,
            });
            removeExport(key);
          } finally {
            isPolling = false;
          }
        };

        const interval = setInterval(pollStatus, 5000);
        
      } catch (uploadError: any) {
        console.error("S3 upload failed:", uploadError);
        
        Modal.error({
          title: "Upload Error",
          content: "Failed to upload file to S3.",
          centered: true,
        });
        removeExport(key);
      }
    } else {
      Modal.error({
        title: "Error",
        content: "Failed to get S3 folder URL.",
        centered: true,
      });
      removeExport(key);
    }
   
  } catch (error) {
    console.error("Error during file upload:", error);
    Modal.error({
      title: "Import Error",
      content: "There was an error uploading the file.",
      centered: true,
    });
    removeExport(key);
  }
};
  const handleDownloadTemplate = async (flag: string, type?: any) => {
    settabledata([]);
    setLoading(true);
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";

    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path:type === "upload" ? '/download_unposted_excel_sheet' : "/download_unposted_usage_only_excel_sheet",
      module_name: "Unposted",
      flag: flag,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      billing_db_name: selectedBillingDb,
      sessionID: sessionId,
      tenant_id: tenant_id_,
      account_number: accountNumber,
      main_module_name: "Customer Profiles",
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: 'Success',
          description: 'Successfully downloaded the template!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob, resp.file_name || "Unposted Template");
        // fetchData();
        setLoading(false);
        setIsUploadModalVisible(false);

      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
        setLoading(false)

      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
      setLoading(false)

    }
  };
const uploadProps = {
  key: uploadKey,
  accept: '.xlsx, .xls',
  beforeUpload: (file: any) => {
    // Check if file is an Excel file
    const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
                    file.type === 'application/vnd.ms-excel';
    if (!isExcel) {
      message.error('You can only upload Excel files!');
      return false;
    }
    
    // Process file immediately in beforeUpload
    const reader = new FileReader();
    reader.onload = (e: any) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array", cellDates: false });

      const allSheetsData = workbook.SheetNames.map((sheetName) => {
        const sheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(sheet, {
          raw: false,
          defval: ''
        }) as Record<string, any>[];

        return { sheetName, data: json };
      });

      console.log("All Sheets Data:", allSheetsData);
      handleUpload(JSON.stringify(allSheetsData), "Unposted Upload");
      setUploadKey(prev => prev + 1);
    };
    reader.readAsArrayBuffer(file);
    
    return false; // ✅ Prevent actual upload
  },
  showUploadList: false,
};
const handlePusheChargesModalOpen = () => {
  setServiceProvider([]);
  setCurrentBillCycle('');
  setPushChargesModalOpen(true);
}
const handleApplytoBillModalOpen = () => {
    const hasNonCredit = ReverseRowData.some((row: any) => row.category !== "Credit");

  if (hasNonCredit) {
    Modal.error({
      title: "Invalid Operation",
      content: "Apply to Bill is only applicable for Credit entries.",
      centered: true,
    });
    return;
  }


  setApplyToBillModalOpen(true);
  };

  const handleCreateBillModalClose = () => {
  setCreateBillModalOpen(false);
};

const handleCreateBill = async (dueDate: Dayjs | null) => {
  setLoading(true);

  try {
    // ---------- Extract selected charge IDs ----------
    const selectedChargeIds = ReverseRowData.map(row => row.id);

    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;

    // ---------- FIRE bill creation (NO WAIT) ----------
    axios.post(url, {
      data: {
        current_cycle: currentCycle,
        due_date:
          dueDate && dayjs(dueDate).isValid()
            ? dayjs(dueDate).format("MM-DD-YYYY")
            : null,
        selected_charge_ids: selectedChargeIds,
        select_all: isSelectAllChecked,
        path: "/bill_creation_from_unposted_charges",
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",
        feature_module_name: "Billing and Collections Unposted",
        table_name: "customer_charges",
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        billing_db_name: selectedBillingDb,
        search_select_all: isSelectAllChecked ? searchIdsforSelectAll : [],
        sessionID: sessionId,
        tenant_id: tenant_id_,
        ...metaData,
        main_module_name: "Customer Profiles",
      },
    }).catch(console.error);

    // ---------- START POLLING ----------
    const pollPayload = {
      tenant_name: partner || "default_value",
      username,
      role_name: role,
      Partner: partner,
      access_token: token,
      account_number: accountNumber,
      request_received_at: getCurrentDateTime(),
      sessionID: sessionId,
      tenant_id: tenant_id_,
      db_name: selectedDb,
      billing_db_name: selectedBillingDb,
      ...metaData,
      main_module_name: "Customer Profiles",
    };

    let attempts = 0;
    const POLL_INTERVAL = 5000; // 5 sec
    const MAX_ATTEMPTS = 180;   // 15 minutes

    addExport("unposted", "Bills Creation from Unposted");

    const interval = setInterval(async () => {
      attempts++;

      try {
        const res = await axios.post(url, {
          data: {
            ...pollPayload,
            path: "/get_export_status",
            module_name: "Bill Creation from Unposted Charges",
          },
        });

        const body = JSON.parse(res.data.body || "{}");

        if (body?.flag && body?.export_status_data?.status_flag === "Success") {
          clearInterval(interval);
          
          notification.success({
            message: "Success",
            description: "Bill created successfully",
            placement: "top",
            duration: 2,
          });
          fireSideCannons()
          removeExport("unposted");

          await fetchData();
          const emailTriggerDetails = JSON.parse(
            body?.export_status_data?.url || "{}"
          );
          // 🔥 CALL upload_pdf_to_s3 HERE
          const emailPayload = {
            tenant_name: partner || "default_value",
            username,
            path: "/upload_pdf_to_s3",
            role_name: role,
            access_token: token,
            db_name: selectedDb,
            billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            account_number: accountNumber,
            email_trigger_details: emailTriggerDetails,
            ...metaData,
          };

          try {
            await axios.post(url, { data: emailPayload });
          } catch (e) {
            console.error("PDF upload failed", e);
          }
          
        }

        if (attempts >= MAX_ATTEMPTS) {
          clearInterval(interval);
          removeExport("unposted");
          setLoading(false);
        }
      } catch {
        clearInterval(interval);
        removeExport("unposted");
        setLoading(false);
      }
    }, POLL_INTERVAL);

  } catch (error) {
    setLoading(false);
    Modal.error({
      title: "Creation Error",
      content:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred",
      centered: true,
    });
  }
  finally{
    handleCreateBillModalClose();
    setLoading(false);
  }
};


// New modal component for Apply to Bill
const ApplyToBillModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  billIds: string[];
}> = ({ isOpen, onClose, billIds }) => {
  const [applyToBill, setApplyToBill] = useState<any>(null);
  const [billOptions, setBillOptions] = useState<any[]>([]);

  const [selectedBillId, setSelectedBillId] = useState<string>("");

useEffect(() => {
  if (isOpen) {
    setSelectedBillId("");
    console.log("Bill IDs:", (generalFields as Record<string, any>)['apply_to_bill']);

    const dynamicOptions = Array.isArray(generalFields)
      ? []
      : generalFields['apply_to_bill'] || [];

    // Prepend the static option
    const updatedOptions = [
      "Apply to old invoice", // static option
      ...dynamicOptions        // dynamic options
    ];

    setBillOptions(updatedOptions); // Update billOptions with combined list
  }
}, [isOpen]);


  const handleSelectChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedBillId(event.target.value);
  };

  const handleApply = async () => {
   setLoading(true)
    // Extract only the IDs from ReverseRowData
    const updatedReverseRowData = ReverseRowData.map(row => row.id);
    console.log("Selected charge IDs:", updatedReverseRowData);

  const payload = {
   apply_to_bill: applyToBill.value,
    selected_charge_ids : updatedReverseRowData,

  };

  try {
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const response = await axios.post(url, {
      data: {
        ...payload,
        path: "/apply_credits_to_bill",
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",       
        // table_name:"customer_charges",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        select_all : isSelectAllChecked,
        search_select_all: isSelectAllChecked ? searchIdsforSelectAll : [],
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",
      },
    });

    const parsedData = JSON.parse(response.data.body);
    if (parsedData.flag) {
      notification.success({
        message: "Success",
        description: parsedData.message || "Bill applied successfully!",
         style: messageStyle,
        placement: "top",
      });
      fireSideCannons()
      setLoading(false)
      setApplyToBillModalOpen(false);

       fetchData(); // Refresh data after creating the bill
     
    } else {
      Modal.error({
        title: "Creation Error",
        content: parsedData.message || "An error occurred while creating the bill. Please try again.",
        centered: true,
      });
      setLoading(false)
      setApplyToBillModalOpen(false);


    }
  } catch (error) {
    Modal.error({
      title: "Creation Error",
      content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      centered: true,
    });
      setLoading(false)

  }
  };

  return (
    <Modal
      title="Apply to Bill"
      open={isOpen}
      onCancel={onClose}
      centered
      width={400}
      footer={
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 16,
            padding: "12px 24px",
          }}
        >
          <button onClick={onClose} className="cancel-btn">
            Cancel
          </button>
          <button
            className={!applyToBill ? "cancel-btn cursor-not-allowed" : "save-btn"}
            onClick={handleApply}
            disabled={!applyToBill}
          >
            Save
          </button>
        </div>
      }
    >
      <div className="flex flex-col">
        <Dropdown
          options={
            (billOptions || []).map((item) => ({
              label: item.includes('-') ? item.split('-')[0].trim() : item,
              value: item,
            }))
          }
          value={applyToBill}
          onChange={(selected: any) => setApplyToBill(selected)}
          placeholder="Create"
          mandatory={true}
        />

      </div>
    </Modal>
  );
};


// const CreateBillModal: React.FC<CreateBillModalProps> = ({
//   isOpen,
//   onClose,
//   currentCycle,
//   onCreate,
//   dueDate
// }) => {
//   // // Local state for dueDate
//   const [dueDateChange, setDueDateChange] = useState<Dayjs | null>(null);
//   useEffect(() => {
//     setDueDateChange(dueDate ?? null);
//   }, [dueDate, isOpen]);


//   const handleCreate = () => {
//     onCreate(dueDateChange);
//     setDueDateChange(null) // Pass dueDate to parent
//   };

//   return (
//     <Modal
//       title="Create Bill"
//       open={isOpen}
//       onCancel={onClose}
//       centered
//       width={400}
//       footer={
//         <div
//           style={{
//             display: "flex",
//             justifyContent: "center",
//             gap: 16,
//             padding: "12px 24px",
//           }}
//         >
//           <button onClick={onClose} className="cancel-btn ">
//             Cancel
//           </button>
//           <button
//             className={!dueDateChange || !accountStatus? "cancel-btn cursor-not-allowed" : "save-btn"}
//             onClick={handleCreate}
//             disabled={!dueDateChange || !accountStatus}
//           >
//             Create Bill
//           </button>
//         </div>
//       }
//     >
//       <div
//         style={{
//           display: "flex",
//           flexDirection: "column",
//           gap: 24,
//         }}
//       >
//         <div
//           style={{
//             display: "flex",
//             alignItems: "center",
//             gap: 16,
//           }}
//         >
//           <label
//             htmlFor="current-cycle"
//             style={{
//               minWidth: 120,
//               fontWeight: 600,
//               userSelect: "none",
//             }}
//           >
//             Current Cycle
//           </label>
//           <Input
//             id="current-cycle"
//             value={currentCycle}
//             readOnly
//             style={{ flex: 1, minWidth: 0 }}
//           />
//         </div>
//         <div
//           style={{
//             display: "flex",
//             alignItems: "center",
//             gap: 16,
//           }}
//         >
//           <label
//             htmlFor="due-date"
//             style={{
//               minWidth: 120,
//               fontWeight: 600,
//               userSelect: "none",
//             }}
//           >
//             Due Date
//           </label>
//           <DatePicker
//             id="due-date"
//             style={{ flex: 1, minWidth: 0 }}
//             value={dueDateChange}
//             onChange={val => setDueDateChange(val ?? null)}
//             disabledDate={(current) =>
//               current ? current < dayjs().startOf('day') : false
//             }
//             allowClear={false}
//             format="MM-DD-YY"
//           />
//         </div>
//       </div>
//     </Modal>
//   );
// };

const handlePushCharges = async () => {
  setProviderError('');

  if (!serviceProvider?.value) {
    setProviderError('Please select a Service Provider');
    return;
  }

  const cycle = providerCycles[serviceProvider.value];
  if (!cycle) {
    setProviderError('Selected provider does not have a current cycle');
    return;
  }
  setPushChargesModalOpen(false);
  setLoading(true);
   try {
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        service_provider: serviceProvider.label || "",
        bill_range: providerCycles[serviceProvider.label] || "",
        mode:"manual",
        path: "/call_container_function_scheduler",
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",       
        // table_name:"customer_charges",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",
        tenant_id:tenant_id_,
        port:5000,
        ec2_host:"100.49.17.163",
        container_name:"Billing_Handler"
      };
      axios.post(url,{data});
      setTimeout(() => {
        setLoading(false);
        startExportPolling(sessionId || "","pushCharges")
      },5000);

  } catch (error) {
    Modal.error({
      title: "Creation Error",
      content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      centered: true,
    });
      setLoading(false)

  }
}

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
  const isDisabled =
  ReverseRowData.length === 0 ||
  ReverseRowData.some(row => row.category === "Usage" || row.category === "SMS") ||
  !accountStatus;
  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-[400px]">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2"> */}
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
            {/* Search and Advanced Filter Container */}
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              { features.includes("Search-Billing and Collections Unposted") &&(
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Unposted"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Billing and Collections Unposted") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Unposted"}
                />
              )}
            </div>
            {/* <div className="flex space-x-2"> */}
              {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-1">
                <span className="save-btn no-hover">
                  Total: {unpostedTotalCharge}
                </span>
                {features.includes("Apply to Bill-Billing and Collections Unposted") && (
                <button className="save-btn" onClick={handlePusheChargesModalOpen}>
                 Push Charges
                </button>)} 
                {features.includes("Apply to Bill-Billing and Collections Unposted") && (<button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleApplytoBillModalOpen}>
                  Apply to Bill
                </button>)}    
                 {features.includes("Create Bill-Billing and Collections Unposted") && (
                  <button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleCreateBillModalOpen}>
                  Create Bill
                </button>  )}     
                {(
              <button className={!accountStatus? "cancel-btn" : "save-btn !min-w-[40px] !pr-0"} onClick={handleUploadClick} disabled={!accountStatus}  title="Upload">
                <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              </button>
            )}
                {features.includes("Export-Billing and Collections Unposted") && (
                <button className={'save-btn !min-w-[40px] !pr-0'} onClick={() => handleExport("Unposted", "Unposted")}  title="Export">
                <ArrowDownTrayIcon className={`h-5 w-5 text-black-500 ${!showAdvanced ? ' mr-2' : ''}`} />
                </button>
              )}
              {features.includes("Reverse Transaction-Billing and Collections Unposted") && (
                <button
                  className={isDisabled  ? "cancel-btn cursor-not-allowed !min-w-[40px] !pr-0" : 'save-btn !min-w-[40px] !pr-0'}
                  disabled={isDisabled}
                  onClick={handleReverseTransaction}  title="Reversals"
                >
                  <ArrowPathIcon className="h-5 w-5 text-black-500 mr-1" />
                </button>

              )}
              <Modal
                title="Upload Files"
                visible={isUploadModalVisible}
                onCancel={handleUploadModalClose}
                footer={null}
                centered
                bodyStyle={{ padding: "1rem", height: "200px", overflow: "hidden" }}
                width={400}
              >
                <div className="flex flex-col items-center justify-center gap-4 h-full">
                    <div className="flex flex-col gap-4">
                    <Upload   {...uploadProps}>
                      <button
                        className="upload-btn w-64 disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-normal break-words"
                      >
                        <span className="mr-2"><UploadOutlined /></span>
                        Upload
                      </button>
                    </Upload>
                    <button
                      onClick={() => handleDownloadTemplate("download_template", 'upload')}
                      className="upload-btn w-64 disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-normal break-words"
                      >
                      <span className="mr-2"><DownloadOutlined /></span>
                     Download MRC Template
                    </button>
                    <button
                      onClick={() => handleDownloadTemplate("download_template", 'non-mrc')}
                      className="upload-btn w-64 disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-normal break-words"
                      >
                      <span className="mr-2"><DownloadOutlined /></span>
                     Download Non-MRC Template
                    </button>
                    </div>
                </div>
              </Modal>
             
             <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Unposted"
              />
            </div>
          </div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Unposted"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields = {generalFields}
              // height={350}  
              height = {showAdvanced?395:325}                
              setReverseRowData={setReverseRowData}
            />
          </div>
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                <span className="save-btn no-hover">
                  Total: {unpostedTotalCharge}
                </span>
                {features.includes("Apply to Bill-Billing and Collections Unposted") &&(<button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleApplytoBillModalOpen}>
                  Apply to Bill
                </button> )}   
                {features.includes("Create Bill-Billing and Collections Unposted") &&( <button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                  style={{minWidth: "3rem", width: "3rem", padding: 0}}
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleCreateBillModalOpen}>
                  <PlusCircleOutlined className="text-xl text-black-500"  />
                </button> )}      
                {features.includes("Export-Billing and Collections Unposted") && (
                <button className="save-btn" onClick={() => handleExport("Unposted", "Unposted")}
                  style={{minWidth: "3rem", width: "3rem", padding: 0}}>  
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500"  />
                </button>
              )}
              {features.includes("Reverse Transaction-Billing and Collections Unposted") && (
                <button
                  className={
                    ReverseRowData.length > 0 &&
                      !ReverseRowData.some(row => row.category === "Usage" || row.category === "SMS")
                      ? "save-btn "
                      : "cancel-btn"
                  }
                  style={{minWidth: "3rem", width: "3rem", padding: 0}}
                  disabled={
                    ReverseRowData.length === 0 ||
                    ReverseRowData.some(row => row.category === "Usage" || row.category === "SMS")
                  }
                  onClick={handleReverseTransaction}
                >
                  <UndoOutlined className="text-xl text-black-500" />
                 
                </button>
              )}

             
             <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Unposted"
              />
            </div>
          {/* <CreateModal
              isOpen={isCreateModalOpen}
              onClose={handleCreateModalClose}
              onSave={handleCreateRow}
              modalData={createModalData}
              title="Unposted"
              visible={isCreateModalOpen}
              action="create"
              generalFields = {generalFields}
              
            /> */}
          {/* <CreateBillModal
            isOpen={isCreateBillModalOpen}
            onClose={handleCreateBillModalClose}
            currentCycle={currentCycle}
            onCreate={handleCreateBill}
            dueDate={dueDate}
          /> */}
           <CreateBillModal
            isOpen={isCreateBillModalOpen}
            onClose={() => setCreateBillModalOpen(false)}
            onSave={handleCreateRow}
            modalData={createModalData}
            rowData={ReverseRowData}
            title="Unposted"
            visible={isCreateBillModalOpen}
            action="create"
            generalFields={generalFields}
            row={row}
            
          />
          <ApplyToBillModal
            isOpen={isApplyToBillModalOpen}
            onClose={() => setApplyToBillModalOpen(false)}
            billIds={tableData.map((item: any) => item.bill_id).filter(Boolean)}
          />
          {isPushChargesModalOpen && (
            <Modal
              title="Push Charges"
              open={isPushChargesModalOpen}
              onCancel={() => setPushChargesModalOpen(false)}
              centered
              width={400}
              footer={
                <div
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    gap: 16,
                    padding: "12px 24px",
                  }}
                >
                  <button onClick={() => setPushChargesModalOpen(false)} className="cancel-btn">
                    Cancel
                  </button>
                  <button
                    className={"save-btn"}
                    onClick={handlePushCharges}
                  >
                    Save
                  </button>
                </div>
              }
            >
              <div className="flex flex-col gap-4">
                <Dropdown
                  options={Object.keys(providerCycles).map(provider => ({
                    label: provider,
                    value: provider,
                  }))}
                  value={serviceProvider}
                  onChange={(value: string | number) => {
                    setServiceProvider(value);
                     setProviderError('');
                  }}
                  placeholder="Service Provider"
                  mandatory={true}
                />
                <Input
                  className="input"
                  placeholder="Provider cycle date range"
                  value={
                    serviceProvider
                      ? providerCycles[serviceProvider.value]
                      : ''
                  }
                  readOnly
                />
                {providerError && (
                  <div className="text-red-500 text-sm">
                    {providerError}
                  </div>
                )}

                {/* <label className="field-label">Current Cycle<span className="text-red-500 ml-1">*</span></label>
                <RangePicker
                  value={currentBillCycle}
                  onChange={(dates) => setCurrentBillCycle(dates ?? [null, null])}
                  className="input"
                  placeholder={['Start Date', 'End Date']}
                  format="MM-DD-YY"
                /> */}
              </div>
            </Modal>
          )}

          {/* {exportLoading && (
            <div className="export-processing-div">
              Export processing...
            </div>
          )} */}
        </div>
      </Suspense>
    </>
  );
};

export default UnPosted;
