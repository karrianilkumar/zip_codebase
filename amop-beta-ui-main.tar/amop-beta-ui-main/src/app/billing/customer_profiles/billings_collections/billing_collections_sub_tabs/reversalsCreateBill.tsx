"use client";

import React, { useCallback, useEffect, useState, useMemo, lazy } from "react";
import { Modal, DatePicker, Input, Spin, notification } from "antd";
const { RangePicker } = DatePicker;
import Select from "react-select";
import dayjs, { Dayjs } from "dayjs";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { getCurrentDateTime } from "../../../../components/header_constants";
import axios from "axios";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useAuth } from "@/app/components/auth_context";
import { fireSideCannons } from "@/app/components/confetti";


const KillbillTableComponent = lazy(
  () => import("../../../killbill_components/table__component")
);
const WholeTableSearch = lazy(() => import("../../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../../killbill_components/advanced__search")
);
interface FormData {
  due_date_of_this_bill: Dayjs | null;
  // bill_type: any | null;
  // specify_amount_to_bill: string;
  include_unposted_charges: boolean;
  current_cycle: [Dayjs | null, Dayjs | null];
}

interface ReversalsCreateBillProps {
  isOpen: boolean;
  onClose: () => void;
  onSave : () => void;
  rowData: any;
  reversalsReverseData:any;
  totalAmount: any;
  //   onCreate: (formData: FormData) => void;
}
type SuccessCallback = (message: string) => void;
type ErrorCallback = (message: string) => void;

interface PollPayload {
  module_name: string;
  tenant_id?: string;
  sessionID?: string;
  account_number?: string;
  feature_module_name?: string;
  [key: string]: any;
}

export const pollExportStatus2 = (
  payload: PollPayload,
  onSuccess: (message: string, data: any) => void,
  onError: (message: string) => void,
  options?: {
    interval?: number;
    maxRetries?: number;
  }
) => {
  const interval = options?.interval ?? 5000;
  const maxRetries = options?.maxRetries ?? 180; // Default to 15 minutes

  let attempts = 0;

  const poll = async () => {
    attempts++;

    try {
      const response = await axios.post(
        ENV_ROUTES.BP_CUSTOMER_PROFILES,
        { data: payload }
      );

      const parsed = JSON.parse(response.data.body);
      const status =
        parsed?.export_status_data?.status_flag?.toLowerCase();

      if (status === "success") {
        onSuccess(
          "Bill created successfully.",
          parsed // 🔥 full backend response
        );
        return;
      }

      if (status === "failed") {
        onError(
          parsed.export_status_data.url || "Operation failed"
        );
        return;
      }

      if (attempts < maxRetries) {
        setTimeout(poll, interval);
      } else {
        onError("Operation timed out. Please try again.");
      }
    } catch (err) {
      if (attempts < maxRetries) {
        setTimeout(poll, interval);
      } else {
        onError("Unable to fetch export status.");
      }
    }
  };

  poll();
};

const ReversalsCreateBill: React.FC<ReversalsCreateBillProps> = ({
  isOpen,
  onClose,
  onSave,
  rowData,
  reversalsReverseData,
  totalAmount,
  //   onCreate,
}) => {
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName,
    setStoredPagination, setAdvancedStoredPagination, combineAdnvaceStoredpagination,
    setCombineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const { addExport, removeExport } = exportLoadingStore();
  const exportKey = "Inventory";
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [ReverseRowData, setReverseRowData] = useState<any[]>([]);
  const { accountNumber, setUserProfileDetails,isSelectAllChecked , searchIdsforSelectAll} = useCustomerProfileStore();
  const [billTypeOptions, setBillTypeOptions] = useState<any[]>([]);
  const [validationErrors, setValidationErrors] = useState<{ [key: string]: string }>({});
  // Add this after your other useState declarations
const reversalsTotalAmount = useMemo(() => {
  if (!reversalsReverseData || !Array.isArray(reversalsReverseData)) {
    return "0.00";
  }
  
  const total = reversalsReverseData.reduce((sum, item) => {
    // const amount = parseFloat(item.charge_amount) || 0;
    const x=item?.charge_amount || "0";
    const amount =
    Number(String(x).replace(/[$,]/g, "")) || 0;
    return sum + amount;
  }, 0);
  return total.toFixed(2);
}, [reversalsReverseData]);

  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  const [formData, setFormData] = useState<FormData>({
    due_date_of_this_bill: null,
    // bill_type: null,
    // specify_amount_to_bill: "",
    include_unposted_charges: false,
    current_cycle: [null, null],
  });
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";

 useEffect(() => {
  console.log("RowData", rowData)
  console.log("reverserowdata", reversalsReverseData)
  if (isOpen) {
    // const options = Array.isArray(rowData.bill_type)
    // ? rowData.bill_type.map((item: any) => ({
    //     label: item,
    //     value: item,
    //   }))
    // : [];

    // setBillTypeOptions(options);      
    setFormData({
      due_date_of_this_bill: rowData?.due_date_of_this_bill ? dayjs(rowData.due_date_of_this_bill) : null,
      // bill_type: null,
      // specify_amount_to_bill: reversalsTotalAmount, // Use calculated total
      include_unposted_charges: false,
      current_cycle: Array.isArray(rowData.current_cycle)
      ? rowData.current_cycle.map((d: any) => d ? dayjs(d) : null)
      : typeof rowData.current_cycle === "string" && rowData.current_cycle.includes(" - ")
        ? rowData.current_cycle.split(" - ").map((dateStr: string | number | Date | dayjs.Dayjs | null | undefined) => dayjs(dateStr))
        : [null, null],
    });
  }
}, [isOpen, reversalsTotalAmount]); // Add reversalsTotalAmount as dependency

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);
  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const fetchUnpostedCharges = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/unposted_bills_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        table_name: "customer_charges",
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setUserProfileDetails(parsedData?.user_profile_details || {});

        setTimeout(() => {
          //  const unposted_total_charge_ = parsedData?.unposted_total_charge || 0;
          //  setUnpostedTotalCharge(unposted_total_charge_);
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Unposted"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const current_cycle_ = parsedData?.current_cycle
            ? dayjs(parsedData.current_cycle).format('YYYY-MM-DD')
            : '';

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_", generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []
          const allowedActions_: any = []
          if (featres_.includes("Edit-Billing Services")) {
            allowedActions_.push("edit")
          }
          // if(featres_.includes("Delete-Billing Services")){
          //   allowedActions_.push("delete")
          // }
          if (featres_.includes("Copy-Billing Services")) {
            allowedActions_.push("copy")
          }
          if (featres_.includes("Discontinue-Billing Services")) {
            allowedActions_.push("deactivate")

          }

          setAllowedActions(allowedActions_)
          const createModalData_ = parsedData?.header_map?.["Billing and Collections Unposted"]?.pop_up || []
          console.log("createModalData_", createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.billing_and_collections_unposted || []);


        }, 0);

      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
    if (field === "include_unposted_charges") {
      fetchUnpostedCharges();
    }
  };
  const handleCreate = () => {
  const errors: { [key: string]: string } = {};

  if (!formData.current_cycle[0] || !formData.current_cycle[1]) {
    errors.current_cycle = "Current cycle is required.";
  }

  if (!formData.due_date_of_this_bill) {
    errors.due_date_of_this_bill = "Due date is required.";
  }

  // if (!formData.bill_type) {
  //   errors.bill_type = "Bill type is required.";
  // }

  // if (!formData.specify_amount_to_bill || formData.specify_amount_to_bill === "0") {
  //   errors.specify_amount_to_bill = "Specify amount is required.";
  // }

  // If there are errors, set them in state or display them
  if (Object.keys(errors).length > 0) {
  setValidationErrors(errors);
 // Make sure you have a useState for this
    return;
  }
  ConfirmCreate()
  // If valid, proceed with bill creation
  console.log("Creating bill with:", formData);
};

  const ConfirmCreate = () => {
  // setLoading(true);
  onClose();

  const exportKey = "Bill Creation from Unposted Charges";

  // 1️⃣ SHOW BANNER
  addExport("reversals","Bills Creation from Reversals");
 
    const { current_cycle, ...restFormData } = formData;

    const formattedFormData = {
      ...restFormData,

      due_date_of_this_bill: formData?.due_date_of_this_bill
        ? dayjs(formData.due_date_of_this_bill).format("MM-DD-YY")
        : null,

       current_bill_cycle: [
    current_cycle?.[0]
      ? dayjs(current_cycle[0]).format("MM-DD-YY")
      : null,
    current_cycle?.[1]
      ? dayjs(current_cycle[1]).format("MM-DD-YY")
      : null,
  ],

      // specify_amount_to_bill: formData.specify_amount_to_bill.replace(/,/g, ""),
    };


  const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;

  const data: any = {
    tenant_name: partner || "default_value",
    username,
    firstLastName,
    path: "/bill_creation_from_unposted_charges",
    role_name: role,
    account_number: accountNumber,
    module_name: "Billing and Collections Reversals",
    table_name: "customer_bills",
    feature_module_name: exportKey,
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    billing_db_name: selectedBillingDb,
    select_all: isSelectAllChecked,
    search_select_all: isSelectAllChecked ? searchIdsforSelectAll : [],
    request_received_at: getCurrentDateTime(),
    sessionID: sessionId,
    tenant_id: tenant_id_,
    modified_by: firstLastName,
    changed_data: [...reversalsReverseData, ...ReverseRowData],
    reversal_ids: reversalsReverseData.map((i: any) => i.id) || [],
    unposted_ids: ReverseRowData.map((i: any) => i.id) || [],
    main_module_name: "Customer Profiles",
    ...metaData,
    ...formattedFormData,
  };

  data.selected_charge_ids = [
    ...(data.reversal_ids || []),
    ...(data.unposted_ids || []),
  ];

  // 2️⃣ FIRE & FORGET (NO WAIT)
  axios.post(url, { data }).catch(err => {
    console.error("Bill creation trigger failed", err);
  });

  const { changed_data, reversal_ids, unposted_ids, ...baseData } = data;

  // 3️⃣ START POLLING
  setTimeout(() => {
   pollExportStatus2(
  {
    ...baseData,
    module_name: "Bill Creation from Unposted Charges",
    path: "/get_export_status",
  },

  // ✅ SUCCESS (message + full data)
  async (successMessage, pollData) => {
    removeExport("reversals");
    setLoading(false);

    notification.success({
      message: "Success",
      description: "Bill created successfully.",
      placement: "top",
    });
    fireSideCannons()

    onSave();
    const emailTriggerDetails = JSON.parse(
    pollData?.export_status_data?.url || "{}"
  );
    // 🔥 CALL upload_pdf_to_s3 HERE
    const emailPayload = {
      tenant_name: partner || "default_value",
      username,
      path: "/upload_pdf_to_s3",
      role_name: role,
      access_token: token,
      db_name: selectedDb,
      billing_db_name: selectedBillingDb,
      sessionID: sessionId,
      tenant_id: tenant_id_,
      account_number: accountNumber,
      email_trigger_details:emailTriggerDetails,
      ...metaData,
    };

    try {
      await axios.post(url, { data: emailPayload });
    } catch (e) {
      console.error("PDF upload failed", e);
    }
  },

  // ❌ FAILURE
  (errorMessage) => {
    removeExport("reversals");
    setLoading(false);

    Modal.error({
      title: "Bill Creation Failed",
      content: errorMessage,
      centered: true,
    });
  }
);

  }, 5000);
};

  const formatAmount = (value: string | number | null | undefined) => {
  if (value === null || value === undefined || value === "") {
    return "0.00";
  }

  // Remove commas and $ if value is a string
  const numericValue =
    typeof value === "string"
      ? Number(value.replace(/[$,]/g, ""))
      : value;

  if (isNaN(numericValue)) {
    return "0.00";
  }

  return `${numericValue.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
};

  // const isFormValid = formData.due_date_of_this_bill && formData.bill_type;
  // if (loading) {
  //   return (
  //     <div className="flex justify-center items-center h-[400px]">
  //       <Spin size="large" />
  //     </div>
  //   );
  // }
  return (
    <Modal
      title="Create Bill"
      open={isOpen}
      onCancel={onClose}
      centered
      width={800}
      footer={
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 16,
            padding: "12px 12px",
          }}
        >
          <button onClick={onClose} className="cancel-btn">
            Cancel
          </button>
          <button
            className={"save-btn"}
            onClick={handleCreate} 
          >
            Create Bill
          </button>
        </div>
      }
    >
        {loading ? (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    ) : (
      <>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 24,
        }}
      >
        {/* Current Cycle */}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <label className="field-label">Current Cycle <span className="text-red-500">*</span></label>
          <RangePicker
            className="input"
            value={formData.current_cycle}
            onChange={(dates) => handleChange("current_cycle", dates || [null, null])}
            allowClear={false}
            format="MM-DD-YY"

          />
                {validationErrors["current_cycle"] && (
                  <span className="text-red-500">
                    {validationErrors["current_cycle"]}
                  </span>
                )}

        </div>

        {/* Due Date */}
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <label className="field-label">Due Date <span className="text-red-500">*</span></label>
                <DatePicker
                  className="input"
                  value={formData.due_date_of_this_bill || null}
                  onChange={(date) => handleChange("due_date_of_this_bill", date)}
                  // disabledDate={(current) =>
                  //   current ? current < dayjs().startOf("day") : false
                  // }
                  allowClear={false}
                  format="MM-DD-YY"
                />
                {validationErrors["due_date_of_this_bill"] && (
                  <span className="text-red-500">
                    {validationErrors["due_date_of_this_bill"]}
                  </span>
                )}

              </div>

        {/* Bill Type - react-select */}
        {/* <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                           
          <label className="field-label">Bill Type  <span className="text-red-500">*</span></label>
          <Select
            placeholder="Select Bill Type"
            value={
              formData.bill_type
                ? billTypeOptions.find((opt) => opt.value === formData.bill_type)
                : null
            }
            onChange={(option) => handleChange("bill_type", option ? option.value : null)}
            options={billTypeOptions}
            isClearable
            styles={DropdownStyles}
          />
                {validationErrors["bill_type"] && (
                  <span className="text-red-500">
                    {validationErrors["bill_type"]}
                  </span>
                )}
        </div> */}

        {/* Specify Amount */}
        {/* <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <label className="field-label">Specify Amount To Bill</label>
          <Input
            prefix = {"$"}
            placeholder="Enter amount"
            type="text"
            value={isSelectAllChecked ? totalAmount :formatAmount(reversalsTotalAmount)}
            readOnly
            className="non-editable-input"
          />
     
          {validationErrors["specify_amount_to_bill"] && (
                  <span className="text-red-500">
                    {validationErrors["specify_amount_to_bill"]}
                  </span>
                )}
        </div> */}
      </div>
      <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 8 }}>
        <input
          type="checkbox"
          id="include_unposted_charges"
          checked={formData.include_unposted_charges}
          onChange={(e) => handleChange("include_unposted_charges", e.target.checked)}
        />
        <label htmlFor="include_unposted_charges" className="field-label">
          Include unposted charges
        </label>
      </div>
      {formData.include_unposted_charges && formData.include_unposted_charges === true && (

        <div className="relative">
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
                  <div className="flex space-x-2"> */}
          <div className="pr-4 pl-4  pt-1 flex flex-col md:flex-row md:items-center md:justify-between mb-2 space-y-2">
            {/* Search and Advanced Filter Container */}
            <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last min-h-[40px]">
              {features.includes("Search-Billing and Collections Reversals") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Unposted"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Billing and Collections Reversals") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Unposted"}
                />
              )}
            </div>

          </div>
          {formData.include_unposted_charges && formData.include_unposted_charges === true && (
            <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
              {loading ? (
                <div className="flex justify-center items-center h-[400px]">
                  <Spin size="large" />
                </div>
              ) : (
                <KillbillTableComponent
                  headers={headers}
                  headerMap={headerMap}
                  initialData={tableData}
                  searchQuery={searchTerm}
                  visibleColumns={visibleColumns}
                  itemsPerPage={100}
                  allowedActions={allowedActions}
                  popupHeading="Unposted"
                  pagination={pagination}
                  advancedFilters={filteredData}
                  createModalData={createModalData}
                  generalFields={generalFields}
                  height={showAdvanced ? 395 : 335}
                  setReverseRowData={setReverseRowData}
                />
              )}
            </div>
          )}

        </div>)}
      </>
    )}
    </Modal>
  );
};

export default ReversalsCreateBill;
