/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, notification } from "antd";
import { useAuth } from "../../../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../../../components/header_constants";
import { useFeatureStore } from "../../../../sim_management/inventory/featureStore";
import { ENV_ROUTES } from "../../../../components/routes/route_constants";
import { exportLoadingStore } from "../../../../stores/ExportLoadingStore";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { fireSideCannons } from "@/app/components/confetti";

const KillbillTableComponent = lazy(
  () => import("../../../killbill_components/table__component")
);
// const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("../../../../components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../../killbill_components/advanced__search")
);
interface PaymentHistoryProps {
  row?: any;
}
const PaymentHistory: React.FC <PaymentHistoryProps>= ({row}) => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination,setCombineAdnvaceStoredpagination,combineAdnvaceStoredpagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [transactionChecked, setTransactionChecked] = useState(false);
  const [AccountStatus , setAccountStatus] = useState(false);
  const hasFetchedData = useRef(false);
  const {
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
  } = useFeatureStore();
  // const queryClient = useQueryClient();
  const {BillId ,setUserProfileDetails} = useCustomerProfileStore();
  const accountNumber = sessionStorage.getItem("accountNumber");

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  // useEffect(() => {
  //   const fetchTransactionAndData = async () => {
  //     if (PaymentSuccess && !hasFetchedTransaction) {
  //       // setTimeout(async () => {
  //         await fetchTransactionStatus();
  //         await fetchData();
  //         setHasFetchedTransaction(true);
  //       // }, 5000); // 5-second delay
  //     } else {
  //       setTransactionChecked(true); // If no transaction check is needed, allow fetchData
  //     }
  //   };
  
  //   fetchTransactionAndData(); // Call the async function
  // }, [PaymentSuccess]);
  
  const fetchData = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/payment_history_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Payment History",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id:tenant_id_,
        feature_module_name: "Payment History",
        table_name: "payment_history",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
          setUserProfileDetails(parsedData?.data?.user_profile_details || {});
          const headersMap_ = parsedData?.header_map?.["Payment History"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_",generalFields_)
          setFeatures(parsedData?.header_map?.["Payment History"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Payment History"]?.module_features || []);
          const features_ = parsedData?.header_map?.["Payment History"]?.module_features || []
          const allowedActions_:any=[]
          if(features_.includes("Cancel Payment-Payment History")){
            allowedActions_.push("cancel-payment")
          }
          if(features_.includes("Chargeback-Payment History")){
            allowedActions_.push("chargeback")
          }
          if(features_.includes("Download Receipt-Payment History")){
            allowedActions_.push("downloadreceipt")
          }
          setAllowedActions(allowedActions_)
          setAccountStatus(parsedData?.account_status || false)
          const createModalData_=parsedData?.header_map?.["Payment History"]?.pop_up||[]
          console.log("createModalData_",createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          const activetab_ = sessionStorage.getItem("billingCollectionsTabs.activeTab")
          if(activetab_ === "paymentHistory"){
            setTableData(parsedData?.data?.payment_history || []);
          }

         
        
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleCreateRow = (newRow: any) => {
    console.log("New Row Data:", newRow);
    handleCreateModalClose();
  };
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);


  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };



  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
  
    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/customer_payments_export",
        role_name: role,
        account_number:accountNumber,
        parent_module: "Billing Platform",
        module_name: "Payment History",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        ...metaData,
        db_name: selectedDb,
        billing_db_name: selectedBillingDb,
        ...metaData,
        tenant_id:tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Payment History",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag:"True",
        main_module_name: "Customer Profiles",
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 5000));
  
      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
  
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Payment History.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
                fireSideCannons();
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
  
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };
  


  const handleExport = async (key: string, heading: string) => {
  
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
  
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          account_number:accountNumber,
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          ...metaData,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Customer Payment History",
          module_name: "Payment History",
          // col_sort:{account_number: "ASC"}
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if  (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Customer Payment History",
          module_name: "Payment History",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          ...metaData,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          // col_sort:{account_number: "ASC"},
          username: username,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Customer Payment History",
          module_name: "Payment History",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          ...metaData,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          // col_sort:{account_number: "ASC"},
          username: username,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Payment History.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons();
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
  if (loading2) {
    return (
      <div className="absolute inset-0 flex flex-col justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
        <div className="flex justify-center">
          <Spin size="large" />
        </div>
        <p className="mt-2 text-gray-600 font-semibold">Fetching Transaction Status...</p>
      </div>
    );
  }
  

  return (
    <>
      <Suspense 
        fallback={
          <div className="flex justify-center items-center h-[400px]">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2"> */}
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
            {/* Search and Advanced Filter Container */}
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Payment History")&& (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Customer Payment History"}
                  headerMap={headerMap}
                />
              )}
              { features.includes("Advanced filter-Payment History")&&(
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Customer Payment History"}
                />
              )}
            </div>
            {/* <div className="flex space-x-2"> */}
             {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-1">
              { features.includes("Export-Payment History")&&(
                <button className="save-btn"  onClick={() => handleExport("Payment History", "Payment History")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
          
             
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          </div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Payment History"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields = {generalFields}
              // height = {showAdvanced?410:350}      
              height = {showAdvanced?395:325}  
              AccountStatus = {AccountStatus}      
            />
          </div>
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
              { features.includes("Export-Payment History")&&(
                <button className="save-btn"  onClick={() => handleExport("Payment History", "Payment History")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
               </button>
              )}
          
             
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          {/* <CreateModal
              isOpen={isCreateModalOpen}
              onClose={handleCreateModalClose}
              onSave={handleCreateRow}
              modalData={createModalData}
              title="Unposted"
              visible={isCreateModalOpen}
              action="create"
              generalFields = {generalFields}


              
            /> */}
        </div>
      </Suspense>
    </>
  );
};

export default PaymentHistory;
