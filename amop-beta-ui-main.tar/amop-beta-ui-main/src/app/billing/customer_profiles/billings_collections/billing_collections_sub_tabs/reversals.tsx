/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, ArrowPathIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, notification } from "antd";
import Dropdown from "../../../killbill_components/dropdownComponent";

import { useAuth } from "../../../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../../../components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "../../../../sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
import { ENV_ROUTES } from "../../../../components/routes/route_constants";
import { exportLoadingStore } from "../../../../stores/ExportLoadingStore";
import CreateModal from "../../../killbill_components/createpopup";
import {  UndoOutlined } from "@ant-design/icons";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { fireSideCannons } from "@/app/components/confetti";

import ReversalsCreateBill from "./reversalsCreateBill";
const KillbillTableComponent = lazy(
  () => import("../../../killbill_components/table__component")
);
// const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("../../../../components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../../killbill_components/advanced__search")
);
interface UnpostedProps {
  row?: any;
 
}

const Reversal: React.FC <UnpostedProps>= ({row}) => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb,sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination,combineAdnvaceStoredpagination,setCombineAdnvaceStoredpagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [ReverseRowData, setReverseRowData] = useState<any[]>([]);
  const { setUserProfileDetails ,isSelectAllChecked, setIsSelectAllChecked , searchIdsforSelectAll , setSearchIdsforSelectAll} = useCustomerProfileStore();
  const [isCreateBillModalOpen, setCreateBillModalOpen] = useState(false);
  const [isApplyToBillModalOpen, setApplyToBillModalOpen] = useState(false);
  const [currentCycle, setCurrentCycle] = useState("");
  const [unpostedTotalCharge, setUnpostedTotalCharge] = useState(0);
  const [accountStatus , setAccountStatus] = useState(false);
  const accountNumber = sessionStorage.getItem("accountNumber");


  const hasFetchedData = useRef(false);
  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  // const queryClient = useQueryClient();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  const fetchData = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    setIsSelectAllChecked(false)
    setSearchIdsforSelectAll([])
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/bill_reversal_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Reversals",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        table_name:"customer_reversal_bills",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Reversals",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setUserProfileDetails(parsedData?.user_profile_details || {});

        setTimeout(() => {
          const unposted_total_charge_ = parsedData?.unposted_total_charge || 0;
          setUnpostedTotalCharge(unposted_total_charge_);
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Reversals"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const current_cycle_ = parsedData?.current_cycle
          ? dayjs(parsedData.current_cycle).format('YYYY-MM-DD')
          : '';
        // console.log("current_cycle_", current_cycle_);
        setCurrentCycle(current_cycle_);
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          // console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          // console.log("generalFields_",generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Collections Reversals"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing and Collections Reversals"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Collections Reversals"]?.module_features || []
          if(parsedData?.account_status){
             const allowedActions_:any=[]
          if(featres_.includes("Edit-Billing Services")){
            allowedActions_.push("edit")
          }
          // if(featres_.includes("Delete-Billing Services")){
          //   allowedActions_.push("delete")
          // }
          if(featres_.includes("Copy-Billing Services")){
            allowedActions_.push("copy")
          }
          if(featres_.includes("Discontinue-Billing Services")){
            allowedActions_.push("deactivate")

          }
          
          setAllowedActions(allowedActions_)
          }
           else{
            setAllowedActions([])
          }
          setAccountStatus(parsedData?.account_status || "");
          const createModalData_=parsedData?.header_map?.["Billing and Collections Reversals"]?.pop_up||[]
          // console.log("createModalData_",createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          const activetab_ = sessionStorage.getItem("billingCollectionsTabs.activeTab")
          if(activetab_ === "reversals"){
            setTableData(parsedData?.data?.billing_collections_reversals || []);
          }

         
        }, 0);
        
      } else {
        setLoading(false);
        // console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleCreateRow = () => {
    handleCreateModalClose();
  };
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [partner]);
  const startExportPolling = (sessionID: string) => {
    addExport("reversals", "Reversals Reverse Transaction");
    let attempts = 0;
    const MAX = 180;
    const interval = setInterval(async () => {
      attempts++;
      try {
        const payload = {
          tenant_name: partner || "default_value",
          username,
          path: "/get_export_status",
          role_name: role,
          access_token: token,
          sessionID,
          db_name: selectedDb,
          billing_db_name: selectedBillingDb,
          module_name: "Reversals Reverse Transaction",
          tenant_id: tenant_id_,
        };

        const res = await axios.post(ENV_ROUTES.BP_CUSTOMER_PROFILES, {
          data: payload,
        });

        const parsed = JSON.parse(res.data.body);

        console.log("Polling status:", parsed);

        if (parsed.flag && parsed.export_status_data?.status_flag.toLowerCase() === "success") {
          clearInterval(interval);

          notification.success({
            message: "Success",
            description: "Reverse transaction completed successfully",
            placement: "top",
          });
          fireSideCannons()
          removeExport("reversals");
          await fetchData();
        }
        if (attempts >= MAX) {
          clearInterval(interval);
        }

      } catch (err) {
        clearInterval(interval);
      }
    }, 5000); // every 5 seconds
  };
  const handleReverseTransaction = async () => {

    try {
      // setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      setReverseRowData((prevReverseRowData) => {
        if (!Array.isArray(prevReverseRowData)) return [];

        // console.log("Previous row data:", prevReverseRowData);

        const updatedData = prevReverseRowData.map((row, index) => ({
          ...row,
          is_active: false,
          is_deleted: true
        }));

        // console.log("Updated ReverseRowData:", updatedData);
        return updatedData;
      });

      // ✅ Use a separate variable to store the modified data
      const updatedReverseRowData = ReverseRowData.map(row => ({
        ...row,
        is_active: false,
        is_deleted: true
      }));




      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/reversals_reverse_transaction",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Reversals",
        search_select_all: isSelectAllChecked ? searchIdsforSelectAll : [],
        changed_data: updatedReverseRowData,
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        select_all: isSelectAllChecked,
        table_name: 'customer_reversal_bills',
        sessionID: sessionId,
        tenant_id: tenant_id_,
        feature_module_name: "Billing and Collections Reversals",
        main_module_name: "Customer Profiles",
      };

      axios.post(url, { data });
      startExportPolling(sessionId || "");

    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const exportToExcel = (headers: any, rowData: any, fileName = 'exported_data.xlsx') => {
    // Map the rowData to an array of objects with headers as keys
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });

    // Create a new worksheet from the formatted data
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

    // Write the workbook and trigger download
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    // console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    // console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    // console.log("Modal closed, resetting date range.");
  };

  
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
  
    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/reverals_export",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Reversals",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        account_number:accountNumber,
        table_name:"customer_reversal_bills",
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id:tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Reversals",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag:"True",
        main_module_name: "Customer Profiles",
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
  
      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
  
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Billing and Collections Reversals.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
                fireSideCannons()
              })
              .catch((err) => {
                // console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };
  


  const handleExport = async (key: string, heading: string) => {
  
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
  
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          account_number:accountNumber,
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Reversals",
          module_name: "Billing and Collections Reversals",
          // col_sort:{charge_description: "ASC"}
        };
        // console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if  (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Reversals",
          module_name: "Billing and Collections Reversals",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          // col_sort:{charge_description: "ASC"},
          username: username,

        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Reversals",
          module_name: "Billing and Collections Reversals",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          // col_sort:{charge_description: "ASC"},
          username: username,
          
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Billing and Collections Reversals.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons()
            })
            .catch((err) => {
              // console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Inventory.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCreateBillModalOpen = () => {
  setCreateBillModalOpen(true);
};
const handleApplytoBillModalOpen = () => {
    const hasNonCredit = ReverseRowData.some((row: any) => row.category !== "Credit");

  if (hasNonCredit) {
    Modal.error({
      title: "Invalid Operation",
      content: "Apply to Bill is only applicable for Credit entries.",
      centered: true,
    });
    return;
  }


  setApplyToBillModalOpen(true);
  };

  const handleCreateBillModalClose = () => {
  setCreateBillModalOpen(false);
};

// New modal component for Apply to Bill
const ApplyToBillModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  billIds: string[];
}> = ({ isOpen, onClose, billIds }) => {
  const [applyToBill, setApplyToBill] = useState<any>(null);
  const [billOptions, setBillOptions] = useState<any[]>([]);

  const [selectedBillId, setSelectedBillId] = useState<string>("");

 useEffect(() => {
  if (isOpen) {
    setSelectedBillId("");
    // console.log("Bill IDs:", (generalFields as Record<string, any>)['apply_to_bill']);

    const dynamicOptions = Array.isArray(generalFields)
      ? []
      : generalFields['apply_to_bill'] || [];

    // Prepend the static option
    const updatedOptions = [
      "Apply to old invoice", // static option
      ...dynamicOptions        // dynamic options
    ];

    setBillOptions(updatedOptions); // Update billOptions with combined list
  }
}, [isOpen]);


  const handleSelectChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedBillId(event.target.value);
  };

  const handleApply = async () => {
   setLoading(true)
    // Extract only the IDs from ReverseRowData
    const updatedReverseRowData = ReverseRowData.map(row => row.id);
    // console.log("Selected charge IDs:", updatedReverseRowData);

  const payload = {
   apply_to_bill: applyToBill.value,
    selected_charge_ids : updatedReverseRowData,

  };

  try {
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const response = await axios.post(url, {
      data: {
        ...payload,
        path: "/apply_credits_to_bill",
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Reversals",       
        // table_name:"customer_charges",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        billing_db_name: selectedBillingDb,
        select_all : isSelectAllChecked,
        ...metaData,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Reversals",
        main_module_name: "Customer Profiles",
      },
    });

    const parsedData = JSON.parse(response.data.body);
    if (parsedData.flag) {
      notification.success({
        message: "Success",
        description: parsedData.message || "Bill applied successfully!",
         style: messageStyle,
        placement: "top",
      });
      fireSideCannons()
      setLoading(false)
      setApplyToBillModalOpen(false);

       fetchData(); // Refresh data after creating the bill
     
    } else {
      Modal.error({
        title: "Creation Error",
        content: parsedData.message || "An error occurred while creating the bill. Please try again.",
        centered: true,
      });
      setLoading(false)
      setApplyToBillModalOpen(false);


    }
  } catch (error) {
    Modal.error({
      title: "Creation Error",
      content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      centered: true,
    });
      setLoading(false)

  }
  };

  return (
    <Modal
      title="Apply to Bill"
      open={isOpen}
      onCancel={onClose}
      centered
      width={400}
      footer={
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 16,
            padding: "12px 24px",
          }}
        >
          <button onClick={onClose} className="cancel-btn">
            Cancel
          </button>
          <button
            className={!applyToBill ? "cancel-btn cursor-not-allowed" : "save-btn"}
            onClick={handleApply}
            disabled={!applyToBill}
          >
            Save
          </button>
        </div>
      }
    >
      <div className="flex flex-col">
        <Dropdown
          options={
            (billOptions || []).map((item) => ({
              label: item.includes('-') ? item.split('-')[0].trim() : item,
              value: item,
            }))
          }
          value={applyToBill}
          onChange={(selected: any) => setApplyToBill(selected)}
          placeholder="Create"
          mandatory={true}
        />

      </div>
    </Modal>
  );
};






  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-[400px]">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2"> */}
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
            {/* Search and Advanced Filter Container */}
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              { features.includes("Search-Billing and Collections Reversals") &&(
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Reversals"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Billing and Collections Reversals") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Reversals"}
                />
              )}
            </div>
            {/* <div className="flex space-x-2"> */}
              {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-1">
                <span className="save-btn no-hover">
                  Total: {unpostedTotalCharge}
                </span>
                {/* <button className={ReverseRowData.length === 0 ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0}  onClick={handleApplytoBillModalOpen}>
                  Apply to Bill
                </button>     */}
              {features.includes("Create Bill-Billing and Collections Reversals") && (
                <button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"}
                  disabled={ReverseRowData.length === 0 || !accountStatus} onClick={handleCreateBillModalOpen}>
                  Create Bill
                </button>
              )}     
                {features.includes("Export-Billing and Collections Reversals") && (
                <button className="save-btn" onClick={() => handleExport("Reversals", "Reversals")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2"  />
                  <span>Export</span>
                </button>
              )}
            {features.includes("Reverse Transaction-Billing and Collections Reversals") && (
                   <button 
                   className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn" : "save-btn"} 
                   disabled={ReverseRowData.length === 0 || !accountStatus} 
                   onClick={handleReverseTransaction}
                 >
                   <ArrowPathIcon className="h-5 w-5 text-black-500 mr-1" />
                   Reversal
                 </button>
                  )} 
             
             <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Reversals"
              />
            </div>
          </div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Reversals"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields = {generalFields}
              // height={350}  
              height = {showAdvanced?395:325}                
              setReverseRowData={setReverseRowData}
            />
          </div>
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                <span className="save-btn no-hover">
                  Total: {unpostedTotalCharge}
                </span>
                {/* <button className={ReverseRowData.length === 0 ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0}  onClick={handleApplytoBillModalOpen}>
                  Apply to Bill
                </button>     */}
                 {features.includes("Create Bill-Billing and Collections Reversals")&&(<button className={ReverseRowData.length === 0 ||!accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleCreateBillModalOpen}>
                  Create Bill
                </button> )}      
                {features.includes("Export-Billing and Collections Reversals") && (
                <button className="save-btn" onClick={() => handleExport("Reversals", "Reversals")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500"  />
                </button>
              )}
            {features.includes("Reverse Transaction-Billing and Collections Reversals") && (
                   <button 
                   className={ReverseRowData.length === 0 ? "cancel-btn" : "save-btn"} 
                   disabled={ReverseRowData.length === 0} 
                   onClick={handleReverseTransaction}
                 >
                 <UndoOutlined className="text-xl text-black-500" />
                 </button>
                  )} 
             
             <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          <CreateModal
              isOpen={isCreateModalOpen}
              onClose={handleCreateModalClose}
              onSave={handleCreateRow}
              modalData={createModalData}
              title="Unposted"
              visible={isCreateModalOpen}
              action="create"
              generalFields = {generalFields}
              
            />
          <ReversalsCreateBill
            isOpen={isCreateBillModalOpen}
            onClose={handleCreateBillModalClose}
            rowData={generalFields}
            reversalsReverseData = {ReverseRowData}
            totalAmount={unpostedTotalCharge}
            onSave={fetchData}
          />
          <ApplyToBillModal
            isOpen={isApplyToBillModalOpen}
            onClose={() => setApplyToBillModalOpen(false)}
            billIds={tableData.map((item: any) => item.bill_id).filter(Boolean)}
          />

          {/* {exportLoading && (
            <div className="export-processing-div">
              Export processing...
            </div>
          )} */}
        </div>
      </Suspense>
    </>
  );
};

export default Reversal;
