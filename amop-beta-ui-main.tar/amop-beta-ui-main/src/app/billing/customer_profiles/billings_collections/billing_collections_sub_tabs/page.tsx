// app/createUser/page.tsx

"use client";
import React, { useEffect, useState,useLayoutEffect } from 'react';
import dynamic from 'next/dynamic';
import { useSidebarStore } from '@/app/stores/navBarStore';
import { useCustomerProfileStore } from '@/app/billing/killbill_stores/customer_profile_store';
import { useAuth } from '@/app/components/auth_context';
import { useFeatureStore } from '@/app/sim_management/inventory/featureStore';

// Dynamically import the UserInfo and TenantInfo components
const Bills = dynamic(() => import('./bills'));
const Ledger = dynamic(() => import('./ledger'));
const UnPosted = dynamic(() => import('./unPosted'));
const PaymentHistory = dynamic(() => import('./paymentHistory'));
const PaymentAccounts = dynamic(() => import('./paymentProfilesDetails'));
const Reversals = dynamic(() => import('./reversals'));
const UploadTracking = dynamic(() => import('./upload_tracking'))


interface SubTabsProps {
  isPopup?: boolean;
  row?: any;
  editable?: boolean
}

const BillingAndCollectionsSubTabs: React.FC<SubTabsProps> = ({ isPopup, row, editable }) => {
  // const [activeTab, setActiveTab] = useState('bills');
  const [redirectToUnposted, setRedirectToUnposted] = useState(false);  
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const { accountNumber, BillId, setBillId ,setBillingAndCollectionsActiveTab,BillingAndCollectionsActiveTab} = useCustomerProfileStore();
  const ACTIVE_TAB_KEY = "billingCollectionsTabs.activeTab";
  const [isHydrated, setIsHydrated] = useState(false);
  // useLayoutEffect(() => {
  //   if (PaymentSuccess) {
  //     setBillingAndCollectionsActiveTab("paymentHistory");
  //   } else if (PaymentFail) {
  //     setBillingAndCollectionsActiveTab("bills");
  //   }
  // }, [PaymentSuccess, PaymentFail]);
  useEffect(() => {
    // console.log("redirectToUnposted:", redirectToUnposted);
    if (redirectToUnposted) {
      setBillingAndCollectionsActiveTab("unposted");
    }
    setRedirectToUnposted(false)
  }, [redirectToUnposted]);
  const {
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
  } = useFeatureStore();

  useEffect(() => {
    if (!isHydrated || !BillingAndCollectionsActiveTab) return;

    sessionStorage.setItem(ACTIVE_TAB_KEY, BillingAndCollectionsActiveTab);
  }, [BillingAndCollectionsActiveTab, isHydrated]);

  useEffect(() => {
  }, []);
  useEffect(() => {
    const storedTab = sessionStorage.getItem(ACTIVE_TAB_KEY);

    if (storedTab) {
    setBillingAndCollectionsActiveTab(storedTab);
    } else {
    setBillingAndCollectionsActiveTab('bills')
    }

    setIsHydrated(true);
  }, []);


  return (
    <>
        <div className="">

          <div className={`bg-white shadow-md mb-4 gap-4  tabs top-[120px] ${isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`} style={{ zIndex: '98' }}>
            <button
              className={`tab-headings ${BillingAndCollectionsActiveTab === 'bills' ? 'active-tab-heading' : ''}`}
              onClick={() => setBillingAndCollectionsActiveTab('bills')}
            >
              Bills
            </button>
            {moduleFeatures.includes("Ledger - Billing and Collections") && (<button
              className={`tab-headings ${BillingAndCollectionsActiveTab === 'ledger' ? 'active-tab-heading' : ''} `}
              onClick={() => setBillingAndCollectionsActiveTab('ledger')}
             
            >
              Ledger
            </button>)}
           { moduleFeatures.includes("Unposted - Billing and Collections") && ( <button
              className={`tab-headings ${BillingAndCollectionsActiveTab === 'unposted' ? 'active-tab-heading' : ''}`}
              onClick={() => setBillingAndCollectionsActiveTab('unposted')}
            >
              Unposted
            </button>)}
             <button
              className={`tab-headings ${BillingAndCollectionsActiveTab === 'uploadTracking' ? 'active-tab-heading' : ''}`}
              onClick={() => setBillingAndCollectionsActiveTab('uploadTracking')}
            >
              Upload Tracking
            </button>
            <button
              className={`tab-headings ${BillingAndCollectionsActiveTab === 'reversals' ? 'active-tab-heading' : ''}`}
              onClick={() => setBillingAndCollectionsActiveTab('reversals')}
            >
              Reversals
            </button>
           
            <button
              className={`tab-headings ${BillingAndCollectionsActiveTab === 'paymentHistory' ? 'active-tab-heading' : ''}`}
              onClick={() => setBillingAndCollectionsActiveTab('paymentHistory')}
            >
              Payment History
            </button>

            <button
              className={`tab-headings ${BillingAndCollectionsActiveTab === 'paymentAccount' ? 'active-tab-heading' : ''}`}
              onClick={() => setBillingAndCollectionsActiveTab('paymentAccount')}
            >
              Payment Profiles
            </button>
          </div>
          <div className={` ${isPopup ? '' : 'mt-[-10px] pt-[70px]'}`}>
             
              {BillingAndCollectionsActiveTab === 'bills' && <Bills row={row} onRedirectToUnpostedChange={setRedirectToUnposted}/>}
            {BillingAndCollectionsActiveTab === 'ledger' && <Ledger row={row} />}
            {BillingAndCollectionsActiveTab === 'unposted' && <UnPosted row={row}/>}
            {BillingAndCollectionsActiveTab === 'paymentHistory' && <PaymentHistory  row={row}/>}
            {BillingAndCollectionsActiveTab === 'paymentAccount' && <PaymentAccounts  row={row}/>}
            {BillingAndCollectionsActiveTab === 'reversals' && <Reversals  row={row}/>}
            {BillingAndCollectionsActiveTab === 'uploadTracking' && <UploadTracking  row={row}/>}

          </div>
        </div>
    </>
     

  );
};

export default BillingAndCollectionsSubTabs;
