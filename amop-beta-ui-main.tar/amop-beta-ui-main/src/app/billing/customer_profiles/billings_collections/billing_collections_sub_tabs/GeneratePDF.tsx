// GeneratePDF.tsx
"use client";

import { pdf, Document, Page, Text } from "@react-pdf/renderer";
// import { InvoicePDFTemplate } from "../../../generate_bill/createTemplate"; // Adjust path as needed
// import { InvoicePDFTemplate } from "@/app/billing/multiGenerateBill/createMultiTemplate";

export const generatePDFBlob = async (
  invoiceData: any,
  templateItems: any[],
  logoUrl: string | null
): Promise<Blob> => {
  console.log("Generating PDF with:", { invoiceData, templateItems, logoUrl });

  const pdfInstance = pdf(
    // <InvoicePDFTemplate
    //   invoiceData={invoiceData}
    //   templateItems={templateItems}
    //   logoUrl={logoUrl}
    // />
  );

  const blob = await pdfInstance.toBlob();
  console.log("Generated Blob:", blob, "Size:", blob?.size);

  if (!blob) {
    throw new Error("PDF generation failed: Blob is undefined");
  }

  return blob;
};