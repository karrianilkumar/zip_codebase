"use client";

import React, { useEffect, useState, lazy, Suspense } from "react";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Legend,
  ResponsiveContainer,
  Cell,
  LineChart,
  Line,
} from "recharts";
import {
  Button,
  DatePicker,
  Modal,
  notification,
  Select,
  Spin,
} from "antd";
import {
  ArrowsAltOutlined,
  BarChartOutlined,
  PieChartOutlined,
  DownloadOutlined,
  LineChartOutlined,
  ShrinkOutlined,
} from "@ant-design/icons";
import moment from "moment";
import dayjs, { Dayjs } from "dayjs";
import { ResponsiveLine } from '@nivo/line';
import { fireSideCannons } from "@/app/components/confetti";

const DashboardTables = lazy(() => import("@/app/billing/dashboard/bpDashboardTable"));

const { RangePicker } = DatePicker;

const BPDashboard: React.FC = () => {
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, firstLastName } = useAuth();
  const [loading, setLoading] = useState(true);
  const [loadingMultiLineChart, setLoadingMultiLineChart] = useState(true);
  const [chartsData, setChartsData] = useState<any[]>([]);
  const [selectedButton, setSelectedButton] = useState("Weekly");
  const [startDate, setStartDate] = useState<string>(moment().startOf("week").format("YYYY-MM-DD"));
  const [endDate, setEndDate] = useState<string>(moment().endOf("week").format("YYYY-MM-DD"));
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [emailType, setEmailType] = useState("All");
  const [expandedChart, setExpandedChart] = useState<number | null>(null);
  const [downloadLoading, setDownloadLoading] = useState<{ [key: string]: boolean }>({});
  const [module_features, setModuleFeatures] = useState<any[]>([]);
  const [isModuleFeaturesReady, setIsModuleFeaturesReady] = useState(false);
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";


  const COLORS = ["#0088FE", "#00C49F", "#FFBB28"];
  const AR_AGING_COLORS = ["#4096ff", "#4ade80", "#facc15", "#6e6e6e", "#ff0000"];

  const LINE_KEYS = ["MRC", "NRC", "Taxes", "NA", "CR", "Total"];
  const LINE_COLORS: { [key: string]: string } = {
    MRC: "#00b200",
    NRC: "#00e7e7",
    Taxes: "#6e6e6e",
    NA: "#ffd700",
    CR: "#ff0000",
    Total: "#6abff8",
  };

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const fullScreenStyle: React.CSSProperties = {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1000,
    backgroundColor: "white",
  };

  const downloadBlob = (base64Blob: string, filename: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadTemplate = async (chartPath: string, title: string) => {
    setDownloadLoading((prev) => ({ ...prev, [title]: true }));
    const url = ENV_ROUTES.BP_DASHBOARDS;
    const data = {
      partner,
      role_name: role,
      action: "download",
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      billing_db_name: selectedBillingDb,
      tenant_name: partner || "default_value",
      tenant_id: tenant_id_,
      path: chartPath,
      start_date: startDate,
      end_date: endDate,
      flag: selectedButton.toLowerCase(),
      username,
      first_last_name: firstLastName,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        const blob = resp?.blob || '';
        const filename = resp?.filename || `${title}.xlsx`;
        if (resp.flag === true) {
          notification.success({
            message: "Success",
            description: "Successfully exported the record!",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons();
          downloadBlob(blob, filename);
        } else {
          Modal.error({
            title: "Export Error",
            content: resp.message,
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: resp.message,
          centered: true,
        });
      }
    } catch (error) {
      console.error("An error occurred while downloading the template:", error);
      Modal.error({
        title: "Export Error",
        content: "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      setDownloadLoading((prev) => ({ ...prev, [title]: false }));
    }
  };
 const fetchFlag= async () => {
   setLoading(true);
    setLoadingMultiLineChart(true);
    
    let parsedData: any;
    try {
      const url = ENV_ROUTES.BP_DASHBOARDS
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/bp_dashboards",
        role_name: role,
        parent_module: "Billing",
        // module_name: "Customer Services",
        // main_module_name: "Customer Profiles",
        // table_name: "customer_services",
        // // sub_module:"Services",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id:tenant_id_,
        sessionID: sessionId,
        main_module_name : 'Dashboard'
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        setTimeout(() => {
          const features = parsedData?.header_map["Billing Customer Profiles"]?.module_features 
          setModuleFeatures(parsedData?.header_map["Billing Customer Profiles"]?.module_features || []);
          if(features){
            setIsModuleFeaturesReady(true);
          }
          
        }, 0);
        
      } else {
        setLoading(false);
      setLoadingMultiLineChart(false);

        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      setLoadingMultiLineChart(false);

      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
      setLoadingMultiLineChart(false);

    }
  };
  const fetchData = async (startDate: string, endDate: string, flag: string) => {
    setLoading(true);
    setLoadingMultiLineChart(true);
    try {
      const url = ENV_ROUTES.BP_DASHBOARDS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      // const requestPaths = [
      //   { path: "/ar_aging_pie", title: "AR Aging" },
      //   { path: "/total_payments", title: "Total Payment Amount Per Day" },
      //   { path: "/total_bill_line_graph", title: "Total Billed" },
      //   { path: "/total_bill_by_ledger_bar", title: "Total Billed By Ledger Account" },
      // ];
      const featurePathMap: Record<string, string> = {
        "AR Aging Pie-Dashboard": "/ar_aging_pie",
        "Total Payment Amount-Dashboard": "/total_payments",
        "Total Bill Line Graph-Dashboard": "/total_bill_line_graph",
        // "Outstanding Amount-Dashboard": "/billing/outstanding-amount",
        // Add more feature → path mappings here as needed
      };
      const requestPaths = module_features
        .filter((feature) => featurePathMap.hasOwnProperty(feature))
        .map((feature) => featurePathMap[feature]);
      const promises = requestPaths.map((path) => {
        const requestData = {
          partner,
          start_date: startDate,
          end_date: endDate,
          flag,
          path,
          action: "view",
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenant_id_,
          username,
          role_name: role,
          tenant_name: partner || "default_value",
          first_last_name: firstLastName,
          request_received_at: getCurrentDateTime(),
        };

        return axios.post(url, { data: requestData }).then((response) => {
          const parsedBody = JSON.parse(response.data.body);
          console.log(parsedBody, "parsedBody");
          const { data } = parsedBody;

          if (path === "/total_bill_line_graph") {
            console.log("total_bill_line_graph data:", data);
            const multiLineData = (data.total_bill_line_graph || []).map((item: any) => {
              // Normalize data to ensure all keys are present and numeric
              const normalizedItem: { [key: string]: any } = { month: item.month || "" };
              LINE_KEYS.forEach((key) => {
                normalizedItem[key] = typeof item[key] === "number" ? item[key] : 0;
              });
              return normalizedItem;
            });
            console.log("Normalized total_bill_line_graph data:", multiLineData); // Debug log
            return {
              title: data.title || "",
              chart_type: "line",
              data: multiLineData.length > 0 ? multiLineData : [{ month: "", MRC: 0, NRC: 0, Taxes: 0, NA: 0, CR: 0, Total: 0 }],
              path,
            };
          }
          return {
            title: data.title || "",
            chart_type: data.chart_type,
            data: data.data,
            angleField: data.angleField,
            colorField: data.colorField,
            radius: data.radius,
            innerRadius: data.innerRadius,
            height: data.height,
            width: data.width,
            xField: data.xField,
            yField: data.yField,
            smooth: data.smooth,
            isStacked: data.isStacked,
            path,
          };
        }).catch((error) => {
          console.error("Error fetching data for path:", path, error);
          return null;
        });
      });

      const results = await Promise.all(promises);
      const validResults = results.filter((result) => result !== null);
      setChartsData(validResults);
    } catch (error) {
      console.error("Error in fetchData:", error);
      notification.error({
        message: "Error",
        description: "Failed to load dashboard data.",
        style: messageStyle,
      });
    } finally {
      setLoading(false);
      setLoadingMultiLineChart(false);
    }
  };
  useEffect(() => {
    fetchFlag();
  },[])
  useEffect(() => {
    const initializeDashboard = async () => {
      setLoading(true);
      setLoadingMultiLineChart(true);
      try {
        let flag = selectedButton.toLowerCase();
        await fetchData(startDate, endDate, flag);
      } catch (error) {
        console.error("Error during initialization:", error);
      } finally {
        setLoading(false);
        setLoadingMultiLineChart(false);
      }
    };

    initializeDashboard();
  }, [isModuleFeaturesReady,startDate, endDate, selectedButton, emailType,]);

  const handleButtonClick = (range: "Today" | "Weekly" | "Monthly" | "Yearly") => {
    setSelectedButton(range);
    if (range === "Today") {
      setDateRange([null, null]);
      setStartDate(moment().format("YYYY-MM-DD"));
      setEndDate(moment().format("YYYY-MM-DD"));
    } else if (range === "Weekly") {
      setDateRange([null, null]);
      setStartDate(moment().startOf("week").format("YYYY-MM-DD"));
      setEndDate(moment().endOf("week").format("YYYY-MM-DD"));
    } else if (range === "Monthly") {
      setDateRange([null, null]);
      setStartDate(moment().startOf("month").format("YYYY-MM-DD"));
      setEndDate(moment().endOf("month").format("YYYY-MM-DD"));
    } else if (range === "Yearly") {
      setDateRange([null, null]);
      setStartDate(moment().startOf("year").format("YYYY-MM-DD"));
      setEndDate(moment().endOf("year").format("YYYY-MM-DD"));
    }
  };

  const handleDateRangeChange = (
    dates: [Dayjs | null, Dayjs | null] | null,
    dateStrings: [string, string]
  ) => {
    if (dates && dates[0] && dates[1]) {
      setDateRange([dates[0], dates[1]]);
      setStartDate(dates[0].format("YYYY-MM-DD"));
      setEndDate(dates[1].format("YYYY-MM-DD"));
      setSelectedButton("");
    } else {
      setDateRange([null, null]);
      setSelectedButton("Weekly");
    }
  };

  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
  }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor="middle"
        dominantBaseline="central"
        fontSize="16"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  const formatStackedBarData = (data: any[]) => {
    const result: any[] = [];
    const categories = new Set<string>();

    data.forEach((item) => {
      if (item.value && typeof item.value === "object") {
        Object.keys(item.value).forEach((category) => categories.add(category));
      }
    });

    data.forEach((item) => {
      const baseEntry: { day: any; [key: string]: any } = { day: item.day };
      if (item.value && typeof item.value === "object") {
        Object.keys(item.value).forEach((category) => {
          baseEntry[category] = item.value[category] || 0;
        });
      }
      result.push(baseEntry);
    });

    return { data: result, categories: Array.from(categories) };
  };

  const toggleExpand = (chartIndex: number) => {
    setExpandedChart(expandedChart === chartIndex ? null : chartIndex);
  };

  const isExpanded = (index: number) => expandedChart === index;

  const getChartIcon = (chartType: string) => {
    switch (chartType) {
      case "pie":
        return <PieChartOutlined className="cursor-pointer mr-2" />;
      case "bar":
      case "stacked-bar":
      case "bar_two":
        return <BarChartOutlined className="cursor-pointer mr-2" />;
      case "line":
        return <LineChartOutlined className="cursor-pointer mr-2" />;
      default:
        return <BarChartOutlined className="cursor-pointer mr-2" />;
    }
  };

  const renderChart = (chart: any, index: number) => {
    if (!chart || !chart.chart_type || !chart.data) {
      return <div style={{ textAlign: "center", color: "#8884d8" }}>Invalid Chart Data</div>;
    }

    switch (chart.chart_type) {
      case "bar":
        if (!chart.data || !Array.isArray(chart.data) || chart.data.length === 0) {
          return <div style={{ textAlign: "center", color: "#8884d8" }}>No Data Available</div>;
        }
        const formatDayLabel = (day: string, expanded: boolean) => {
          if (!day) return "";
          return expanded ? day : day.slice(0, 3);
        };
        return (
          <ResponsiveContainer width="100%" height={isExpanded(index) ? "90%" : 300}>
            <BarChart data={chart.data}
             margin={{ bottom: 0 , left:40 ,top:10}} >
              <XAxis
                dataKey={chart.xField || "day"}
                axisLine={false}
                label={{
                  value: "Days",
                  position: "insideBottom",
                  // offset: -35,
                  dy:10,
                  fill: "#000",
                  fontSize: 14,
                  fontFamily: "Calibri",
                  textAnchor: "middle",
                }}
                tickFormatter={(value) => formatDayLabel(value, isExpanded(index))}  
                tick={{ fontSize: 12, fontFamily: "Calibri",fill:"#000" }}
              />
              <YAxis
                dataKey={chart.yField || "value"}
                axisLine={false}
                label={{
                  value: "Payment Amount ($)",
                  angle: -90,
                  position: "left",
                  offset: 15,
                  dy: -50,
                  fill:'#000',
                  fontSize: 14,
                  fontFamily: "Calibri",
                }}
                tick={{ fontSize: 12, fontFamily: "Calibri" ,fill:'#000'}}
                tickFormatter={(value) => `$${value.toFixed(2)}`}
              />
              <CartesianGrid strokeDasharray="2 2" horizontal={true} vertical={false} />
              <Tooltip
                formatter={(value: number) => [`$${value.toFixed(2)}`, "Payment Amount"]}
                labelFormatter={(label) => `Day: ${label}`}
                cursor={false}
              />
              <Legend verticalAlign="bottom" align="center" wrapperStyle={{
                   marginLeft:'45px',
                    bottom: "-7px",
                    fontFamily: "Calibri",
                    fontSize: 14,
                  }} />
              <Bar dataKey={chart.yField || "value"} fill="#00C49F" barSize={40} />
            </BarChart>
          </ResponsiveContainer>
        );
      case "stacked-bar":
        const formattedData = formatStackedBarData(chart.data);
        return (
          <ResponsiveContainer width="100%" height={isExpanded(index) ? "90%" : 300}>
            <BarChart data={formattedData.data}>
              <XAxis
                dataKey="day"
                axisLine={false}
                label={{ value: "Days", position: "bottom", offset: 0 }}
              />
              <YAxis
                axisLine={false}
                label={{
                  value: "Email type",
                  angle: -90,
                  position: "left",
                  offset: -10,
                  dy: -35,
                }}
              />
              <CartesianGrid strokeDasharray="2 2" horizontal={true} vertical={false} />
              <Tooltip cursor={false} />
              <Legend />
              {formattedData.categories.map((category: string, idx: number) => (
                <Bar
                  key={idx}
                  dataKey={category}
                  stackId="a"
                  fill={COLORS[idx % COLORS.length]}
                />
              ))}
            </BarChart>
          </ResponsiveContainer>
        );
      case "pie":
        const hasData = chart.data && chart.data.length > 0;
        const pieColors = chart.path === "/ar_aging_pie" ? AR_AGING_COLORS : COLORS;

        // Filter out segments with 0 or negligible value
        const filteredData = hasData 
          ? chart.data.filter((entry: any) => entry[chart.angleField] > 0.001)
          : [];
        return (
          <ResponsiveContainer width="100%" height={isExpanded(index) ? "90%" : 300}>
            {filteredData.length > 0 ? (
              <PieChart>
                <Pie
                  data={filteredData}
                  dataKey={chart.angleField}
                  nameKey={chart.colorField}
                  outerRadius={110}
                  fill="#8884d8"
                  // label={renderCustomizedLabel}
                  // labelLine={false}
                >
                  {filteredData.map((entry: any, idx: number) => (
                    <Cell
                      key={`cell-${idx}`}
                      fill={entry.isError ? "#FF0000" : pieColors[idx % pieColors.length]}
                    />
                  ))}
                </Pie>
                <Tooltip />
                <Legend 
                  layout="horizontal"
                  verticalAlign="bottom"
                  align="center"
                  iconType="square"
                  payload={chart.data.map((entry: any, idx: number) => ({
                    value: entry[chart.colorField],
                    type: "square",
                    id: entry[chart.colorField],
                    color: pieColors[idx % pieColors.length],
                  }))}
                />
              </PieChart>
            ) : (
              <PieChart>
                <Pie
                  data={[{ name: "No data", value: 1 }]}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  fill="#f0f0f0"
                  dataKey="value"
                  labelLine={false}
                  isAnimationActive={false}
                />
                <text
                  x="50%"
                  y="50%"
                  textAnchor="middle"
                  fill="#8884d8"
                  style={{
                    fontSize: "16px",
                    fontFamily: "Calibri",
                  }}
                >
                  No Data
                </text>
              </PieChart>
            )}
          </ResponsiveContainer>
        );
      case "bar_two":
        return (
          <ResponsiveContainer width="100%" height={isExpanded(index) ? "90%" : 300}>
            <BarChart data={chart.data}>
              <XAxis
                dataKey={chart.xField}
                axisLine={false}
                label={{ value: "Days", position: "bottom", offset: 0 }}
              />
              <YAxis
                axisLine={false}
                label={{
                  value: "Errors",
                  angle: -90,
                  position: "left",
                  offset: -8,
                  dy: -20,
                }}
              />
              <CartesianGrid strokeDasharray="2 2" horizontal={true} vertical={false} />
              <Tooltip cursor={false} />
              <Legend />
              <Bar dataKey={chart.yField} fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        );
      case "line":
        console.log("Rendering line chart with data:", chart.data); // Debug log

        const displayKeys = LINE_KEYS;

        // Transform data for Nivo format
        const transformDataForNivo = (data: any[]) => {
          if (!data || data.length === 0) return [];

          return displayKeys.map((key) => ({
            id: key,
            color: LINE_COLORS[key],
            data: data.map((item) => ({
              x: item.month ? item.month.split(' ')[0] : '',
              y: item[key] || 0,
            })),
          }));
        };

        const nivoData = chart.data && chart.data.length > 0
          ? transformDataForNivo(chart.data)
          : transformDataForNivo([{ month: "", MRC: 0, NRC: 0, Taxes: 0, NA: 0, CR: 0, Total: 0 }]);
        const CustomLegend = () => (
          <div style={{ 
            display: 'flex', 
            justifyContent: 'center', 
            gap: '20px',
            marginTop: '10px',
            fontFamily: 'Calibri',
            fontSize: '12px'
          }}>
            {displayKeys.map((key) => (
              <div key={key} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <div style={{ 
                  width: '12px', 
                  height: '12px', 
                  borderRadius: '50%', 
                  backgroundColor: LINE_COLORS[key] 
                }} />
                <span style={{ color: LINE_COLORS[key] }}>{key}</span>
              </div>
            ))}
          </div>
        );
        return (
          <ResponsiveContainer width="100%" height={isExpanded(index) ? "90%" : 300}>
            {loadingMultiLineChart ? (
              <div className="flex flex-row justify-center items-center pt-32">
                <Spin size="large" />
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>

                {/* 📊 CHART */}
                <div style={{ flex: 1 }} className="nivo-chart-wrapper">
                  <ResponsiveLine
                    data={nivoData}
                    margin={{ top: 20, right: 30, bottom: 40, left: 110 }}
                    xScale={{ type: "point" }}
                    yScale={{
                      type: "linear",
                      min: 0,
                      max: "auto",
                      stacked: false,
                      reverse: false,
                    }}
                    axisBottom={{
                      legend: "Month",
                      legendOffset: 35,
                      legendPosition: "middle",
                    }}
                    axisLeft={{
                      legend: "Amount ($)",
                      legendOffset: -95,
                      legendPosition: "middle",
                      format: (value) => `$${value.toFixed(2)}`,
                    }}
                      tooltip={({ point }) => (
                        <div className="nivo-default-tooltip w-[150px]">
                          <span>Month: {point.data.x}</span>
                          <br />
                          <span style={{ color: point.seriesColor }}>
                            {point.seriesId}: ${Number(point.data.y).toFixed(2)}
                          </span>
                        </div>
                      )}
                    pointSize={8}
                    curve="monotoneX"
                    useMesh
                    enableGridX={false}
                    enableGridY
                    colors={(d) => d.color}
                    legends={[]} 
                      theme={{
                        axis: {
                          ticks: {
                            text: {
                              fontSize: 12,
                              fontFamily: "Calibri",
                              // fill: "#000",
                            },
                          },
                          legend: {
                            text: {
                              fontSize: 14,
                              fontFamily: "Calibri",
                              // fill: "#000",
                            },
                          },
                        },
                        grid: {
                        line: {
                              strokeWidth: 1,
                              strokeDasharray: "2 2", // ✅ DASHED
                            },
                        },
                        legends: {
                          text: {
                            fontSize: 12,
                            fontFamily: "Calibri",
                            fill: "#000",
                          },
                        },
                        tooltip: {
                          container: {
                            fontFamily: "Calibri",
                            borderRadius: "8px",
                            boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                          },
                        },
                      }}
                    enableTouchCrosshair={false}
                    enableCrosshair={false}
                  />
                </div>
              <CartesianGrid strokeDasharray="2 2" horizontal={true} vertical={false} />
                {/* 🧾 LEGEND BELOW */}
                <div>
                  <CustomLegend />
                </div>

              </div>
            )}
          </ResponsiveContainer>

        );
      default:
        return <div style={{ textAlign: "center", color: "#8884d8" }}>Unsupported Chart Type</div>;
    }
  };

  const renderControls = () => {
    const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;
    if (isSmallScreen) {

      return (
        <div
          className="flex flex-wrap items-center gap-2 mt-2"
        >
          <span
             style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "16px",
              }}
              className="mr-2 ml-2"
          >
            Select:
          </span>
          <button
            className={
              selectedButton === "Today" ? "save-btn" : "email-dashboard-btns"
            }
            onClick={() => handleButtonClick("Today")}
            style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "14px",
                padding: "8px 12px",
              }}
          >
            Today
          </button>
          <button
            className={
              selectedButton === "Weekly" ? "save-btn" : "email-dashboard-btns"
            }
            onClick={() => handleButtonClick("Weekly")}
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "14px",
                padding: "8px 12px",
              }}
          >
            Weekly
          </button>
          <button
            className={
              selectedButton === "Monthly" ? "save-btn" : "email-dashboard-btns"
            }
            onClick={() => handleButtonClick("Monthly")}
            style={{
              marginRight: 10,
              fontFamily: "Calibri",
              fontSize: "16px",
              padding: "10px",
              marginTop: "-2px",
            }}
          >
            Monthly
          </button>
          <button
            className={
              selectedButton === "Yearly" ? "save-btn" : "email-dashboard-btns"
            }
            onClick={() => handleButtonClick("Yearly")}
            style={{
              marginLeft: 50,
              fontFamily: "Calibri",
              fontSize: "16px",
              padding: "10px",
              marginTop: "-2px",
            }}
          >
            Yearly
          </button>
        </div>
      );
    }
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          marginBottom: "10px",
          marginTop: "10px",
          marginRight: "12px",
        }}
      >
        <span
          style={{
            marginLeft: 10,
            marginRight: 20,
            fontFamily: "Calibri",
            fontSize: "16px",
            marginTop: "-2px",
          }}
        >
          Select:
        </span>
        <button
          className={
            selectedButton === "Today" ? "save-btn" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Today")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Today
        </button>
        <button
          className={
            selectedButton === "Weekly" ? "save-btn" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Weekly")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Weekly
        </button>
        <button
          className={
            selectedButton === "Monthly" ? "save-btn" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Monthly")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Monthly
        </button>
        <button
          className={
            selectedButton === "Yearly" ? "save-btn" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Yearly")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Yearly
        </button>
      </div>
    );
  };

  const renderCharts = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      );
    }

    return (
      <div className="p-4 w-full rounded-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {chartsData.length === 0 ? (
            <div className="flex justify-center items-center h-screen w-full col-span-2">
              <Spin size="large" />
            </div>
          ) : (
            chartsData.map((chart, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg shadow-md graph ${
                  isExpanded(index) ? "full-screen" : ""
                }`}
                style={isExpanded(index) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 chart-title flex justify-between items-center p-4">
                  <div className="flex items-center">
                    {getChartIcon(chart.chart_type)}
                    <h2 className="font-semibold">{chart.title}</h2>
                  </div>
                  <div className="flex items-center">
                    <div>
                      {downloadLoading[chart.title] ? (
                        <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <DownloadOutlined
                          className="cursor-pointer mr-2"
                          onClick={() => handleDownloadTemplate(chart.path, chart.title)}
                        />
                      )}
                    </div>
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(index)}
                    >
                      {isExpanded(index) ? <ShrinkOutlined /> : <ArrowsAltOutlined />}
                    </div>
                  </div>
                </div>
                {renderChart(chart, index)}
              </div>
            ))
          )}
        </div>
      </div>
    );
  };

  return (
    <>
      <Suspense>
        {renderControls()}
        {renderCharts()}
        <div className="m-[10px]">
          <DashboardTables startDate={startDate} endDate={endDate} moduleFeatures={module_features} />
        </div>
      </Suspense>
    </>
  );
};

export default BPDashboard;