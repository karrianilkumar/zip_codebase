// "use client"
// import React,{useEffect} from "react";
// import { useState } from "react";
// import { Modal, Spin, Table,notification } from "antd";
// import type { ColumnsType } from "antd/es/table";
// import { DownloadOutlined } from "@ant-design/icons";
// import axios from "axios";
// import { useAuth } from "../../components/auth_context";
// import { ENV_ROUTES} from "../../components/routes/route_constants";
// import { getCurrentDateTime } from "../../components/header_constants";

// interface TableDataResponse<T> {
//   columns: ColumnsType<T>;
//   data: T[];
// }

// interface SyncStatusData {
//   key: string;
//   no: number;
//   syncName: string;
//   syncType: string;
//   status: string;
//   dateTime: string;
// }

// interface UserLogData {
//   key: string;
//   no: number;
//   userName: string;
//   loginTime: string;
//   logoutTime: string;
// }

// interface bpDasboardTableProps {
// //   selectedServiceProvider: string;
//   startDate: string;
//   endDate: string;
//   moduleFeatures?:any;
// //   serviceProvider: string;
// }

// const BPDashboardTables: React.FC<bpDasboardTableProps> = ({ startDate, endDate , moduleFeatures}) => {
//   const { username, role, token, partner, selectedDb, firstLastName, sessionId} = useAuth();
//   const [loading, setLoading] = useState(true);
//   const [syncTableData, setSyncTableData] =
//     useState<TableDataResponse<SyncStatusData> | null>(null);
//   const [collectionsTableData, setCollectionsTableData] =
//     useState<TableDataResponse<UserLogData> | null>(null);
//     const [downloadLoading, setDownloadLoading] = useState(false);
//     const [collectionsDownloadLoading, setCollectionsDownloadLoading] = useState(false);

//     const messageStyle = {
//       fontSize: "14px",
//       fontWeight: "bold",
//       padding: "16px",
//     };
  
//     const downloadBlob = (base64Blob: string, filename: string) => {
//       const byteCharacters = atob(base64Blob);
//       const byteNumbers = new Array(byteCharacters.length);
//       for (let i = 0; i < byteCharacters.length; i++) {
//         byteNumbers[i] = byteCharacters.charCodeAt(i);
//       }
//       const byteArray = new Uint8Array(byteNumbers);
  
//       const blobObject = new Blob([byteArray], {
//         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
//       });
//       const link = document.createElement("a");
//       link.href = URL.createObjectURL(blobObject);
//       link.download = filename;
//       document.body.appendChild(link);
//       link.click();
//       document.body.removeChild(link);
//     };

//   const fetchSyncTableData = async () => {
//     setLoading(true);
//     try {
//       const url = ENV_ROUTES.BP_DASHBOARDS;
//       const tenant_id_ = localStorage.getItem("tenant_id") || "0";

//       const data = {
//         tenant_name: partner || "default_value",
//         username: username,
//         firstLastName: firstLastName,
//         start_date: startDate,
//         end_date: endDate,
//         path: "/outstanding_table", //
//         role_name: role,
//         // parent_module: "Sim Management",
//         // module_name: "Dashboard",
//         mod_pages: {
//           start: 0,
//           end: 100,
//         },
//         request_received_at: getCurrentDateTime(),
//         Partner: partner,
//         access_token: token,
//         db_name: selectedDb,
//         sessionID: sessionId,
//         tenant_id:tenant_id_,
//         action: "view",
//       };

//       const response = await axios.post(url, { data });
//       const parsedData = JSON.parse(response.data.body);

//       if (parsedData.flag === false) {
//         Modal.error({
//           title: "Data Fetch Error",
//           content:
//             parsedData.message ||
//             "An error occurred while fetching data. Please try again.",
//           centered: true,
//         });
//       } else {

//         if (parsedData.columns && parsedData.data) {
//           const fixedWidthColumns = parsedData.columns.map((col: any) => ({
//             ...col,
//             width: 150, // Set default width (px)
//             ellipsis: true, // Optional: adds "..." for overflow
//           }));

//           setSyncTableData({
//             columns: fixedWidthColumns,
//             data: parsedData.data,
//           });
//           // setSyncTableData({
//           //   columns: parsedData.columns,
//           //   data: parsedData.data,
//           // });
//         } else {
//           console.error("Expected columns and data in parsedData are missing");
//         }

//       }
//     } catch (error) {
//       console.error("Error fetching data:", error);
//       Modal.error({
//         title: "Data Fetch Error",
//         content:
//           error instanceof Error
//             ? error.message
//             : "An unexpected error occurred while fetching data. Please try again.",
//         centered: true,
//       });
//     } finally {
//       setLoading(false);
//     }
//   };
//   const fetchCollectionSummaryTableData = async () => {
//     setLoading(true);
//     try {
//       const url = ENV_ROUTES.BP_DASHBOARDS;
//       const tenant_id_ = localStorage.getItem("tenant_id") || "0";

//       const data = {
//         tenant_name: partner || "default_value",
//         username: username,
//         firstLastName: firstLastName,
//         start_date: startDate,
//         end_date: endDate,
//         path: "/collections_summary", //
//         role_name: role,
//         // parent_module: "Sim Management",
//         // module_name: "Dashboard",
//         mod_pages: {
//           start: 0,
//           end: 100,
//         },
//         request_received_at: getCurrentDateTime(),
//         Partner: partner,
//         access_token: token,
//         db_name: selectedDb,
//         sessionID: sessionId,
//         tenant_id:tenant_id_,
//         action: "view",
//       };

//       const response = await axios.post(url, { data });
//       const parsedData = JSON.parse(response.data.body);

//       if (parsedData.flag === false) {
//         Modal.error({
//           title: "Data Fetch Error",
//           content:
//             parsedData.message ||
//             "An error occurred while fetching data. Please try again.",
//           centered: true,
//         });
//       } else {

//         if (parsedData.columns && parsedData.data) {
//           const fixedWidthColumns = parsedData.columns.map((col: any) => ({
//             ...col,
//             width: 150, // Set default width (px)
//             ellipsis: true, // Optional: adds "..." for overflow
//           }));

//           setCollectionsTableData({
//             columns: fixedWidthColumns,
//             data: parsedData.data,
//           });
//           // setSyncTableData({
//           //   columns: parsedData.columns,
//           //   data: parsedData.data,
//           // });
//         } else {
//           console.error("Expected columns and data in parsedData are missing");
//         }

//       }
//     } catch (error) {
//       console.error("Error fetching data:", error);
//       Modal.error({
//         title: "Data Fetch Error",
//         content:
//           error instanceof Error
//             ? error.message
//             : "An unexpected error occurred while fetching data. Please try again.",
//         centered: true,
//       });
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleDownloadTable = async () => {
//     setDownloadLoading(true);
//     try {
//       const url = ENV_ROUTES.BP_DASHBOARDS;
//       const tenant_id_ = localStorage.getItem("tenant_id") || "0";

//       const data = {
//         tenant_name: partner || "default_value",
//         username: username,
//         firstLastName: firstLastName,
//         start_date: startDate,
//         end_date: endDate,
//         path: "/outstanding_table",
//         role_name: role,
//         mod_pages: {
//           start: 0,
//           end: 100,
//         },
//         request_received_at: getCurrentDateTime(),
//         Partner: partner,
//         access_token: token,
//         db_name: selectedDb,
//         tenant_id:tenant_id_,
//         sessionID: sessionId,
//         action: "download", // Action flag for Excel download
//       };

//       const response = await axios.post(url, { data });
//       const resp = JSON.parse(response.data.body);
//       if (response.data.statusCode === 200) {
//         const blob = resp?.blob || '';
//         const filename = resp?.filename || "Outstanding_Table.xlsx"; // Use filename from response, fallback to default
//         if (resp.flag === true) {
//           notification.success({
//             message: "Success",
//             description: "Successfully exported the record!",
//             style: messageStyle,
//             placement: "top",
//           });
//           downloadBlob(blob, filename);
//         } else {
//           Modal.error({
//             title: "Export Error",
//             content: resp.message,
//             centered: true,
//           });
//         }
//       } else {
//         Modal.error({
//           title: "Export Error",
//           content: resp.message,
//           centered: true,
//         });
//       }
//     } catch (error) {
//       console.error("An error occurred while downloading the table:", error);
//       Modal.error({
//         title: "Export Error",
//         content: "An unexpected error occurred while downloading. Please try again.",
//         centered: true,
//       });
//     } finally {
//       setDownloadLoading(false);
//     }
//   };
// const handleCollectionsDownloadTable = async () => {
//     setCollectionsDownloadLoading(true);
//     try {
//       const url = ENV_ROUTES.BP_DASHBOARDS;
//       const tenant_id_ = localStorage.getItem("tenant_id") || "0";

//       const data = {
//         tenant_name: partner || "default_value",
//         username: username,
//         firstLastName: firstLastName,
//         start_date: startDate,
//         end_date: endDate,
//         path: "/collections_summary",
//         role_name: role,
//         mod_pages: {
//           start: 0,
//           end: 100,
//         },
//         request_received_at: getCurrentDateTime(),
//         Partner: partner,
//         access_token: token,
//         db_name: selectedDb,
//         tenant_id:tenant_id_,
//         sessionID: sessionId,
//         action: "download", // Action flag for Excel download
//       };

//       const response = await axios.post(url, { data });
//       const resp = JSON.parse(response.data.body);
//       if (response.data.statusCode === 200) {
//         const blob = resp?.blob || '';
//         const filename = resp?.filename || "Collections_Summary.xlsx"; // Use filename from response, fallback to default
//         if (resp.flag === true) {
//           notification.success({
//             message: "Success",
//             description: "Successfully exported the record!",
//             style: messageStyle,
//             placement: "top",
//           });
//           downloadBlob(blob, filename);
//         } else {
//           Modal.error({
//             title: "Export Error",
//             content: resp.message,
//             centered: true,
//           });
//         }
//       } else {
//         Modal.error({
//           title: "Export Error",
//           content: resp.message,
//           centered: true,
//         });
//       }
//     } catch (error) {
//       console.error("An error occurred while downloading the table:", error);
//       Modal.error({
//         title: "Export Error",
//         content: "An unexpected error occurred while downloading. Please try again.",
//         centered: true,
//       });
//     } finally {
//       setCollectionsDownloadLoading(false);
//     }
//   };


//   const fetchAllData = async () => {
//     setLoading(true);
//     await Promise.all([fetchSyncTableData()]);
//     await Promise.all([fetchCollectionSummaryTableData()]);
//     setLoading(false);
//   };

//   // useEffect(() => {
//   //   fetchAllData();
//   // }, [selectedServiceProvider, startDate, endDate]); 
//   useEffect(() => {
//     const fetchDataWithSSM = async () => {
//       try {
//         console.log("Fetching SSM parameters...");
//         // await fetchAllData(); // Ensure SSM parameters are fetched first
//         console.log("SSM parameters fetched successfully");
//         if(moduleFeatures.includes("Outstanding Amount-Dashboard")){
//           // Call your main data fetching function
//           await fetchAllData();
//         }
//       } catch (error) {
//         console.error("Error fetching SSM parameters or data:", error);
//       }
//     };
  
//     fetchDataWithSSM();
//   }, [ startDate, endDate ,moduleFeatures]);
  

//   const paginationConfig = {
//     pageSize: 50,
//     showSizeChanger: false, 
//   };

//   return (
//         <div className="dashboard-tables">
//          {moduleFeatures.includes("Outstanding Amount-Dashboard")&&( 
//           <div className="table-section graph">
//           <div className="flex justify-between items-center">
//             <h2 style={{fontFamily: "Calibri, sans-serif" }}>Top Five Customers Outstanding Amount</h2>
//             <div>

// {downloadLoading ? (

//   <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
// ) : (

//   <DownloadOutlined

//     className="cursor-pointer mr-2"

//     onClick={handleDownloadTable}

//     style={{ fontSize: "20px" }}

//   />

// )}
// </div>
// </div>
//             <div className="over">
//             <Table
//               columns={syncTableData?.columns || []}
//               dataSource={syncTableData?.data || []}
//               loading={loading}
//               pagination={paginationConfig}
//               size="middle"
//               scroll={{ y: 300 }}
//             />
//             </div>
//           </div>)}
//           {moduleFeatures.includes("Collections Summary-Dashboard") && (
//         <div className="table-section graph mt-4">
//           <div className="flex justify-between items-center">
//             <h2 style={{ fontFamily: "Calibri, sans-serif" }}>Collections Summary</h2>
//             <div>

//               {collectionsDownloadLoading ? (

//                 <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
//               ) : (

//                 <DownloadOutlined

//                   className="cursor-pointer mr-2"

//                   onClick={handleCollectionsDownloadTable}

//                   style={{ fontSize: "20px" }}

//                 />

//               )}
//             </div>
//           </div>
//           <div className="over">
//             <Table
//               columns={collectionsTableData?.columns || []}
//               dataSource={collectionsTableData?.data || []}
//               loading={loading}
//               pagination={paginationConfig}
//               size="middle"
//               scroll={{ y: 300 }}
//             />
//           </div>
//         </div>)}

//           {/* <style jsx>{`
//             .dashboard-tables {
//               padding: 20px;
//             }
//             .table-section {
//               background: white;
//               padding: 20px;
//               border-radius: 8px;
//               box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
//             }
//             h2 {
//               margin-bottom: 16px;
//               font-size: 20px;
//               font-weight: 600;
//             }
//       :global(.custom-table) {
//         font-family: Calibri, sans-serif;
//       }
//       :global(.custom-table .ant-table) {
//         font-family: Calibri, sans-serif;
//       }
//       :global(.custom-table .ant-table-thead > tr > th) {
//         font-family: Calibri, sans-serif;
//       }
//       :global(.custom-table .ant-table-tbody > tr > td) {
//         font-family: Calibri, sans-serif;
//       }
//       :global(.custom-table .ant-pagination-item),
//       :global(.custom-table .ant-pagination-prev),
//       :global(.custom-table .ant-pagination-next),
//       :global(.custom-table .ant-pagination-jump-prev),
//       :global(.custom-table .ant-pagination-jump-next) {
//         font-family: Calibri, sans-serif;
//       }
//         }
//           `}</style> */}
//         </div>
//     //   )}
//     // </>
//   );
// };

// export default BPDashboardTables;

"use client"
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import { Modal, Spin, Table, notification } from "antd";
import type { ColumnsType } from "antd/es/table";
import { DownloadOutlined } from "@ant-design/icons";
import axios from "axios";
import { useAuth } from "../../components/auth_context";
import { ENV_ROUTES } from "../../components/routes/route_constants";
import { getCurrentDateTime } from "../../components/header_constants";
import { useFeatureStore } from "../../sim_management/inventory/featureStore";
import { exportLoadingStore } from "../../stores/ExportLoadingStore";
import { fireSideCannons } from "@/app/components/confetti";

// Lazy load the components like in AR Aging
const KillbillTableComponent = lazy(() => import("../../../app/billing/killbill_components/table__component"));
const WholeTableSearch = lazy(() => import("../../../app/billing/killbill_components/whole__search"));

interface TableDataResponse<T> {
  columns: ColumnsType;
  data: T[];
}

interface SyncStatusData {
  key: string;
  no: number;
  syncName: string;
  syncType: string;
  status: string;
  dateTime: string;
}

interface UserLogData {
  key: string;
  no: number;
  userName: string;
  loginTime: string;
  logoutTime: string;
}

interface bpDasboardTableProps {
  startDate: string;
  endDate: string;
  moduleFeatures?: any;
}

const BPDashboardTables: React.FC<bpDasboardTableProps> = ({ startDate, endDate, moduleFeatures }) => {
  const { username, role, token, partner, selectedDb,metaData,selectedBillingDb, firstLastName, sessionId, tenantId, settabledata, advancedStoredpagination, storedpagination, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination, combineAdnvaceStoredpagination } = useAuth();
  
  // Outstanding Table States (UNCOMMENTED)
  const [outstandingLoading, setOutstandingLoading] = useState(true);
  const [outstandingTableData, setOutstandingTableData] = useState<TableDataResponse<SyncStatusData> | null>(null);
  
  // Collections Table States
  const [collectionsLoading, setCollectionsLoading] = useState(true);
  const [collectionsTableData, setCollectionsTableData] = useState([]);
  const [collectionsHeaders, setCollectionsHeaders] = useState<any[]>([]);
  const [collectionsHeaderMap, setCollectionsHeaderMap] = useState<Record<string, [string, number]>>({});
  const [collectionsPagination, setCollectionsPagination] = useState({});
  const [collectionsSearchTerm, setCollectionsSearchTerm] = useState("");
  const [collectionsAdvancedFilters, setCollectionsAdvancedFilters] = useState({});
  const [collectionsFilteredData, setCollectionsFilteredData] = useState([]);
  const [collectionsShowAdvanced, setCollectionsShowAdvanced] = useState(false);
  const [collectionsVisibleColumns, setCollectionsVisibleColumns] = useState<any[]>([]);
  const [collectionsCreateModalData, setCollectionsCreateModalData] = useState<any[]>([]);

  const [downloadLoading, setDownloadLoading] = useState(false);
  const [collectionsDownloadLoading, setCollectionsDownloadLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const sortHeaderMap = useCallback((headerMap: Record<string, [string, number]>): Record<string, [string, number]> => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as Record<string, [string, number]>;
  }, []);

  const downloadBlob = (base64Blob: string, filename: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Fixed Outstanding Table Data Fetch Function
  const fetchOutstandingTableData = async () => {
    setOutstandingLoading(true);
    try {
      const url = ENV_ROUTES.BP_DASHBOARDS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        path: "/outstanding_table",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Outstanding Dashboard",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        action: "view",
        feature_module_name: "Outstanding Dashboard",
        table_name: "outstanding_view",
        main_module_name: "Outstanding Amount",
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        if (parsedData.columns && parsedData.data) {
          const fixedWidthColumns = parsedData.columns.map((col: any) => ({
            ...col,
            width: 150,
            ellipsis: true,
          }));

          setOutstandingTableData({
            columns: fixedWidthColumns,
            data: parsedData.data,
          });
        } else {
          console.error("Expected columns and data in parsedData are missing");
        }
      }
    } catch (error) {
      console.error("Error fetching outstanding data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setOutstandingLoading(false);
    }
  };

  const fetchCollectionSummaryTableData = async () => {
    setCollectionsLoading(true);
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setCollectionsSearchTerm("");
    setCollectionsShowAdvanced(false);
    setCombineAdnvaceStoredpagination(null);
    try {
      const url = ENV_ROUTES.BP_DASHBOARDS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        path: "/collections_summary",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Collections Dashboard",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        action: "view",
        feature_module_name: "Collections Dashboard",
        table_name: "collections_view",
        main_module_name: "Collections Summary",
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Collections Summary"]?.header_map || {};
          const sortedHeaderMap = sortHeaderMap(headersMap_);
          setCollectionsHeaderMap(sortedHeaderMap);
          
          const headers_ = Object.keys(sortedHeaderMap).length > 0 ? Object.keys(sortedHeaderMap) : [];
          setCollectionsHeaders(headers_);
          setCollectionsVisibleColumns(headers_);
          
          setCollectionsPagination(parsedData?.pages || {});
          setCollectionsTableData(parsedData?.data?.collections_summary || []);
        }, 0);
      }
    } catch (error) {
      console.error("Error fetching collections data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setCollectionsLoading(false);
    }
  };

  // Collections Table Handlers
  const handleCollectionsFilter = useCallback((advancedFilters: any) => {
    setCollectionsAdvancedFilters(advancedFilters);
  }, []);

  const handleCollectionsReset = useCallback((EmptyFilters: any) => {
    setCollectionsFilteredData(EmptyFilters);
  }, []);

  const handleDownloadTable = async () => {
    setDownloadLoading(true);
    try {
      addExport("outstanding", "Outstanding Table");
      
      const url = ENV_ROUTES.BP_DASHBOARDS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        path: "/outstanding_table",
        role_name: role,
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        action: "download",
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);

      if (response.data.statusCode === 200) {
        const blob = resp?.blob || '';
        const filename = resp?.filename || "Outstanding_Table.xlsx";

        if (resp.flag === true) {
          notification.success({
            message: "Success",
            description: "Successfully exported the record!",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons();
          downloadBlob(blob, filename);
        } else {
          Modal.error({
            title: "Export Error",
            content: resp.message,
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: resp.message,
          centered: true,
        });
      }
    } catch (error) {
      console.error("An error occurred while downloading the table:", error);
      Modal.error({
        title: "Export Error",
        content: "An unexpected error occurred while downloading. Please try again.",
        centered: true,
      });
    } finally {
      setDownloadLoading(false);
      removeExport("outstanding");
    }
  };
 const handleExport = async (key: string, heading: string) => {
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
      const moduleName = "Collections Summary";
  
       if (storedpagination && !advancedStoredpagination) {
        console.log("storedpagination",storedpagination)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: collectionsSearchTerm,
          username: username,
          search_all_columns: "True",
          index_name: moduleName,
          module_name: moduleName,
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenant_id_,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await handleCollectionsDownloadTable();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
          .then(response => response.blob())
          .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = parsedData.file_name || 'Collections_Summary.xlsx';
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            notification.success({
              message: "Success",
              description: "Successfully exported the record!",
              style: messageStyle,
              placement: "top",
            });
            fireSideCannons();
          })
          .catch((err) => {
            console.log("error", err)
            Modal.error({
              title: "Export Error",
              content: "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  const handleCollectionsDownloadTable = async () => {
    setCollectionsDownloadLoading(true);
    try {
      // addExport("collections", "Collections Table");
      
      const url = ENV_ROUTES.BP_DASHBOARDS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        path: "/collections_summary",
        role_name: role,
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        action: "download",
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);

      if (response.data.statusCode === 200) {
        const blob = resp?.blob || '';
        const filename = resp?.filename || "Collections_Summary.xlsx";

        if (resp.flag === true) {
          notification.success({
            message: "Success",
            description: "Successfully exported the record!",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons();
          downloadBlob(blob, filename);
        } else {
          Modal.error({
            title: "Export Error",
            content: resp.message,
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: resp.message,
          centered: true,
        });
      }
    } catch (error) {
      console.error("An error occurred while downloading the table:", error);
      Modal.error({
        title: "Export Error",
        content: "An unexpected error occurred while downloading. Please try again.",
        centered: true,
      });
    } finally {
      setCollectionsDownloadLoading(false);
      // removeExport("collections");
    }
  };

  const fetchAllData = async () => {
    await Promise.all([fetchOutstandingTableData(), fetchCollectionSummaryTableData()]);
  };

  useEffect(() => {
    const fetchDataWithSSM = async () => {
      try {
        console.log("Fetching SSM parameters...");
        console.log("SSM parameters fetched successfully");
        
        if (moduleFeatures.includes("Outstanding Amount-Dashboard")) {
          await fetchAllData();
        }
      } catch (error) {
        console.error("Error fetching SSM parameters or data:", error);
      }
    };

    fetchDataWithSSM();
  }, [startDate, endDate, moduleFeatures]);

  // Fixed loading condition to check both tables
  if (outstandingLoading || collectionsLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spin size="large" />
      </div>
    );
  }

  const paginationConfig = {
    pageSize: 50,
    showSizeChanger: false, 
  };

  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        {moduleFeatures.includes("Outstanding Amount-Dashboard") && (
          <div >
            <div className="relative">
              {/* Header with Export Button */}
              <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4 space-y-2 md:space-y-0">
                <h3 className="text-lg font-semibold">Top Five Customers Outstanding Amount</h3>
                
                {/* Export Button - Hidden on small screens */}
                <div className="hidden md:block">
                  <button
                    onClick={handleDownloadTable}
                    disabled={downloadLoading}
                    className="save-btn"
                  >
                    {downloadLoading ? (
                      <Spin size="small" className="mr-2" />
                    ) : (
                      <DownloadOutlined className="mr-2" />
                    )}
                    Export
                  </button>
                </div>
              </div>

              {/* Sticky Footer for Small Screens */}
              <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                <button 
                  onClick={handleDownloadTable}
                  disabled={downloadLoading}
                  className="save-btn"
                >
                  {downloadLoading ? (
                    <Spin size="small" />
                  ) : (
                    <DownloadOutlined className="h-5 w-5 text-black-500" />
                  )}
                </button>
              </div>

              {/* Outstanding Table - Using Ant Design Table */}
              <div className="overflow-auto">
                <Table
                  className="custom-outstanding-table"
                  columns={outstandingTableData?.columns || []}
                  dataSource={outstandingTableData?.data || []}
                  loading={outstandingLoading}
                  pagination={paginationConfig}
                  size="middle"
                  // scroll={{ y: 300 }}
                />
              </div>
            </div>
          </div>
        )}

        {moduleFeatures.includes("Collections Summary-Dashboard") && (
          <div className="mb-2 mt-2">
            <div className="relative">
              {/* Header with Export Button */}
              <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-2 md:space-y-0">
                <h3 className="text-lg font-semibold">Collections Summary</h3>
                
               
              </div>

              {/* Search and Advanced Filter Controls */}
              <div className="p-2 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
                <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
                  <WholeTableSearch
                    searchTerm={collectionsSearchTerm}
                    setSearchTerm={setCollectionsSearchTerm}
                    tableName={"Collections Summary"}
                    headerMap={collectionsHeaderMap}
                  />
                  {/* Export Button - Hidden on small screens */}
                </div>
                  <div className="hidden md:block">
                    <button
                      onClick={() => handleExport("Collections Summary", "Collections Summary")}
                      disabled={collectionsDownloadLoading}
                      className="save-btn"
                    >
                      {collectionsDownloadLoading ? (
                        <Spin size="small" className="mr-2" />
                      ) : (
                        <DownloadOutlined className="mr-2" />
                      )}
                      Export
                    </button>
                  </div>
              </div>

              {/* Sticky Footer for Small Screens */}
              {/* <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                <button 
                  onClick={handleCollectionsDownloadTable}
                  disabled={collectionsDownloadLoading}
                  className="save-btn"
                >
                  {collectionsDownloadLoading ? (
                    <Spin size="small" />
                  ) : (
                    <DownloadOutlined className="h-5 w-5 text-black-500" />
                  )}
                </button>
              </div> */}

              {/* Collections Table - Using KillbillTableComponent */}
              <div className={`${collectionsShowAdvanced ? "mt-[70px]" : ""} ${moduleFeatures.includes("Collections Summary-Dashboard") ? "mb-16 md:mb-0" : ""}`}>
                <KillbillTableComponent
                  headers={collectionsHeaders}
                  headerMap={collectionsHeaderMap}
                  initialData={collectionsTableData}
                  searchQuery={collectionsSearchTerm}
                  visibleColumns={collectionsVisibleColumns}
                  itemsPerPage={100}
                  allowedActions={[]}
                  popupHeading="Collections Summary"
                  pagination={collectionsPagination}
                  advancedFilters={collectionsFilteredData}
                  createModalData={[]}
                  generalFields={[]}
                  height={collectionsShowAdvanced ? 370 : 320}
                  BPDashboardStartDate={startDate}
                  BPDashboardEndDate={endDate}
                />
              </div>
            </div>
          </div>
        )}
      </Suspense>
    </>
  );
};

export default BPDashboardTables;


