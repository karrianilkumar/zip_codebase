import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Spin } from "antd";
import { ENV_ROUTES} from "@/app/components/routes/route_constants";
// import { serviceProviders } from "../constants/partnercarrier";

interface ConfigTypes {
  title: string;
  height: number;
  width: number;
  count: number | string;
}

interface bpDasboardCardsProps {
  selectedServiceProvider: string;
  startDate: string;
  endDate: string;
  serviceProvider: string;
}

const BPDashbaordCards: React.FC<bpDasboardCardsProps> = ({ selectedServiceProvider, startDate, endDate, serviceProvider }) => {
  const [loading, setLoading] = useState(true);
  const [datalog, setData] = useState<ConfigTypes[]>([]);
  const { token, partner ,selectedDb,metaData,selectedBillingDb, sessionId,username} = useAuth();
 
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
  
      try {
        console.log("Fetching SSM parameters...");
        // await fetchSSMParameters(); // Ensure SSM parameters are fetched first
        console.log("SSM parameters fetched successfully");
  
        const url = ENV_ROUTES.DASHBOARD;
        const requestPaths = [
          { path: "/count_of_service_provider" },
          { path: "/count_of_active_customers" },
          { path: "/count_of_active_sims" },
          { path: "/count_of_pending_sim_activations" },
        ];
  
        const promises = requestPaths.map(({ path }) => {
          const requestData = {
            partner: partner,
            start_date: startDate,
            end_date: endDate,
            service_provider: serviceProvider,
            path: path,
            username: username,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            sessionID: sessionId,
          };
  
          return axios.post(url, { data: requestData }).then((response) => {
            const parsedData = JSON.parse(response.data.body);
            const { data } = parsedData;
            return {
              title: data.title,
              count: parsedData.data.data,
              height: parsedData.data.height,
              width: parsedData.data.width,
            };
          });
        });
  
        const results = await Promise.all(promises);
        setData(results);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
  
    fetchData();
  }, [token, selectedServiceProvider, startDate, endDate]);
  

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }


  return (
    <div className="ml-1 py-2 px-6 w-full">
      <div className="flex gap-4 justify-between">
        {datalog.map((item, index) => {
          return (
            <div
              key={index}
              className="chart w-full"
              style={{ width: `${item.width}px`, height: `${item.height}px` }}
            >
              <div className="p-2 mt-0">
                <div className="flex flex-col">
                  <h2 style={{ fontFamily: "Calibri, sans-serif", fontSize: "18px" }}>
                    {item.title}
                  </h2>
                  <p className="chart-count">
                    <span style={{ fontSize: "18px"}}>{item.count}</span>
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
  
};

export default BPDashbaordCards;
