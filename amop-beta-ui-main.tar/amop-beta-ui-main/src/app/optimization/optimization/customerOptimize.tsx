
import { Modal, notification, Spin } from "antd";
import axios from "axios";
import React, { useEffect, useState } from "react";
import Select from "react-select";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import VirtualizedMultiSelect from "@/app/components/virtualized_multi_dropdown";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import moment from "moment";
import VirtualizedSelect from "@/app/components/virtualized_dropdown";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";

interface OptimizeProps {
  onCancel: () => void;
  isOpen: boolean;
  module_name: string;
  onSubmit: () => void;
}

const messageStyle = {
  fontSize: "14px",
  fontWeight: "bold",
  padding: "16px",
};

const CustomerOptimize: React.FC<OptimizeProps> = ({
  onCancel,
  isOpen,
  module_name,
  onSubmit,
}) => {
  const { optimizationType: storeOptimizationType } = useOptimizationStore();
  const [optimizationType, setOptimizationType] = useState<string>(
    storeOptimizationType === "Customer" ? "Customer" : "Carrier"
  );
  const [serviceProviders, setServiceProviders] = useState<string[]>([]);
  const [selectedServiceProviderIds, setSelectedServiceProviderIds] = useState<
    any[]
  >([]);
  const [serviceProviderOptions, setServiceProviderOptions] = useState<any>([]);
  const [serviceProviderIdMap, setServiceProviderIdMap] = useState<any>([]);
  const [customerOptions, setCustomerOptions] = useState<any>([]);
  const [customerIdMap, setCustomerIdMap] = useState<any>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);
  const [selectedCustomerId, setSelectedCustomerId] = useState<any | null>(null);
  const [selectedRevCustomerId, setSelectedRevCustomerId] = useState<any | null>(
    null
  );
  const [billPeriodEndOptions, setBillPeriodEndOptions] = useState<any>([]);
  const [billPeriodEndOptionsMap, setBillPeriodEndOptionsMap] = useState<any>([]);
  const [selectedAllBillPeriodEnd, setSelectedAllBillPeriodEnd] = useState<
    any[]
  >([]);
  const [billPeriodOptions, setBillPeriodOptions] = useState<any>([]);
  const [billPeriodMap, setBillPeriodMap] = useState<any>([]);
  const [allBillPeriodMap, setAllBillPeriodMap] = useState<any>([]);
  const [selectedBillPeriodEnd, setSelectedBillPeriodEnd] = useState<string | null>(
    null
  );
  const [selectedBillPeriodStart, setSelectedBillPeriodStart] = useState<
    string | null
  >(null);
  const [selectedBillPeriodId, setSelectedBillPeriodId] = useState<any | null>(
    null
  );
  const [startModalOpen, setStartModalOpen] = useState<boolean>(false);
  const [formattedDate, setFormattedDate] = useState<string | null>(null);
  const [crossProvider, setCrossSelector] = useState<boolean>(false);
  const { username, role, partner, token, selectedDb,metaData, firstLastName, sessionId } =
    useAuth();
  const [loading, setLoading] = useState(false);
  const optimizationTypeOptions =
    optimizationType === "Carrier"
      ? [{ label: "Carrier", value: "Carrier" }]
      : [{ label: "Customer", value: "Customer" }];
  const [totalSIMCards, setTotalSIMCards] = useState<any | null>(null);
  const [SIMCardsToOptimize, setSIMCardsToOptimize] = useState<any | null>(null);
  const [ratePlanCount, setRatePlanCount] = useState<any | null>(null);
  const [optimizationTypeError, setOptimizationTypeError] = useState<boolean>(false);
  const [serviceProviderError, setServiceProviderError] = useState<boolean>(false);
  const [billPeriodError, setBillPeriodError] = useState <boolean>(false);
  const [billPeriodStartError, setBillPeriodStartError] = useState<boolean>(
    SIMCardsToOptimize === 0
  );
  const [billPeriod, setBillPeriod] = useState<any>({});
  const [customerError, setCustomerError] = useState<boolean>(false);

  useEffect(() => {
    setBillPeriodStartError(SIMCardsToOptimize === 0);
  }, [SIMCardsToOptimize]);

  const formatDate = (value: any) => {
     // Helper function to parse date in DD/MM/YYYY HH:mm:ss format
    const parseDate = (dateString: string): Date | null => {
      const [day, month, year, time] = dateString.split(/[/ ]/);
      if (!day || !month || !year) return null;
      return new Date(`${year}-${month}-${day}T${time || "00:00:00"}`);
    };
     // Format the date to "Jan 2025"
    const formattedDate = value
      ? parseDate(value)?.toLocaleString("en-US", {
          month: "short",
          year: "numeric",
        }) || "Invalid Date"
      : "Invalid Date";
    return formattedDate;
  };

  const formatEndDate = (value: any) => {
    // Helper function to parse date in DD/MM/YYYY HH:mm:ss format
    const parseDate = (dateString: string): Date | null => {
      const [day, month, year, time] = dateString.split(/[/ ]/);// Split into components
      if (!day || !month || !year) return null;// Check for invalid date
      return new Date(`${year}-${month}-${day}T${time || "00:00:00"}`);
    };
      // Format the date to "Jan 1 2025"
    const formattedDate = value
      ? parseDate(value)?.toLocaleString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
        }) || "Invalid Date"
      : "Invalid Date";
    return formattedDate;
  };

  // Fetch offsets from /get_cross_provider_customer_offsets
  const fetchOffsets = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_customer_offsets",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Offset Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching offsets. Please try again.",
          centered: true,
        });
        return 0;
      }
      return parsedData.offsets || 0;
    } catch (error) {
      Modal.error({
        title: "Offset Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching offsets.",
        centered: true,
      });
      return 0;
    } finally {
      setLoading(false);
    }
  };

  // Modified fetchData to accept offset parameter
  const fetchData = async (offset: number) => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_dropdown_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        offset, // Include offset in the request
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            `An error occurred while fetching data for offset ${offset}. Please try again.`,
          centered: true,
        });
        return null;
      }
      return parsedData;
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : `An unexpected error occurred while fetching data for offset ${offset}.`,
        centered: true,
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Function to merge data from multiple fetchData calls
  const mergeData = (
    existingData: {
      service_provider_list: any[];
      customers_data: any[];
      customer_billing_period: any;
    },
    newData: {
      service_provider_list: any[];
      customers_data: any[];
      customer_billing_period: any;
    }
  ) => {
    // Merge service providers, removing duplicates by id
    const serviceProviderMap = new Map();
    [
      ...(existingData?.service_provider_list || []),
      ...(newData?.service_provider_list || []),
    ].forEach((provider) => {
      serviceProviderMap.set(provider.id, provider);
    });
    const mergedServiceProviders = Array.from(serviceProviderMap.values());

    // Merge customers, removing duplicates by id
    const customerMap = new Map();
    [
      ...(existingData?.customers_data || []),
      ...(newData?.customers_data || []),
    ].forEach((customer) => {
      customerMap.set(customer.id, customer);
    });
    const mergedCustomers = Array.from(customerMap.values());

    // Merge billing periods, combining objects by key
    const mergedBillingPeriods = {
      ...(existingData?.customer_billing_period || {}),
      ...(newData?.customer_billing_period || {}),
    };

    return {
      service_provider_list: mergedServiceProviders,
      customers_data: mergedCustomers,
      customer_billing_period: mergedBillingPeriods,
    };
  };

  // Fetch all data with offsets and merge
  const fetchAllData = async () => {
    try {
      setLoading(true);
      const offsets = await fetchOffsets();
      if (offsets === 0) {
        setLoading(false);
        return;
      }

      let mergedData: {
        service_provider_list: any[];
        customers_data: any[];
        customer_billing_period: any;
      } = {
        service_provider_list: [],
        customers_data: [],
        customer_billing_period: {},
      };

      // Call fetchData for each offset (0 to offsets-1)
      for (let i = 0; i < offsets; i++) {
        const data = await fetchData(i);
        if (data) {
          mergedData = mergeData(mergedData, data);
        }
      }

      // Populate dropdowns with merged data
      // Set service provider options
      const service_provider_options = mergedData?.service_provider_list || [];
      setServiceProviderIdMap(service_provider_options);
      const serviceProviderOptions_ = service_provider_options.map(
        (provider: any) => provider.service_provider_name
      );
      setServiceProviderOptions(serviceProviderOptions_);

      // Set customer options
      const customer_options_map = mergedData?.customers_data || [];
      setCustomerIdMap(customer_options_map);
      const customerOptions_ = customer_options_map.map(
        (customer: any) => customer.customer_name
      );
      setCustomerOptions([{customer_name:"All Customers" , account_number:""}, ...customer_options_map]);

      // Set bill period options for All Customers
      const bill_period_map = Object.values(
        mergedData?.customer_billing_period || {}
      ).map((period: any) => {
        const billingDate = period.BillingPeriodEndDateTime || "";
        const formattedDate = formatDate(billingDate);
        return { ...period, formattedDate };
      });
      setAllBillPeriodMap(bill_period_map);
      const billPeriodOptions_ = bill_period_map.map(
        (period: any) => period.formattedDate || ""
      );
      setBillPeriodOptions(billPeriodOptions_);
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching all data.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomerBillingPeriods = async (customerId: string) => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/get_billing_periods_for_customer_and_site",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        customer_id: customerId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (!parsedData.flag) {
        throw new Error(parsedData.message);
      }

      const bill_periods = parsedData?.customer_billing_period_list || [];
      setBillPeriodMap(bill_periods);
      const bill_period_options = bill_periods.map(
        (period: any) => period.billing_cycle_end_date || ""
      );
      setBillPeriodOptions(bill_period_options);
    } catch (error) {
      Modal.error({
        title: "Error",
        content:
          error instanceof Error
            ? error.message
            : "Failed to fetch billing periods",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const convertSingleCustomerDate = (dateString: string): string => {
    if (!dateString) return "";
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "";
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = "00";
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  };

  const convertAllCustomersDate = (dateString: string): string => {
    if (!dateString) return "";
    const [day, month, year, time] = dateString.split(/[/ ]/);
    if (!day || !month || !year) return "";
    return `${year}-${month}-${day} ${time || "12:00:00"}`;
  };

  const getFormattedBillPeriodsParams = () => {
    const isAllCustomers = selectedCustomer === "All Customers";
    let bill_period_end_date;
    let bill_period_start_date;
    if (isAllCustomers) {
      // const periodObj = allBillPeriodMap.find(
      //   (period: any) => period.formattedDate === selectedBillPeriodEnd
      // );
      // const convert_date = periodObj?.BillingPeriodEndDateTime || "";
      // bill_period_end_date = convertAllCustomersDate(convert_date);
      // bill_period_start_date = convertAllCustomersDate(
      //   selectedBillPeriodStart || ""
      // );

       if (Array.isArray(selectedAllBillPeriodEnd) && selectedAllBillPeriodEnd.length > 0) {
      // Convert all date strings to Date objects
      const dateObjects = selectedAllBillPeriodEnd.map(dateStr => new Date(dateStr));

      // Find min and max dates
      const minDate = new Date(Math.min(...dateObjects.map(d => d.getTime())));
      const maxDate = new Date(Math.max(...dateObjects.map(d => d.getTime())));

      // Helper to format date like convertAllCustomersDate
      const formatToAllCustomersDate = (date: Date): string => {
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, "0");
        const day = date.getDate().toString().padStart(2, "0");
        return `${year}-${month}-${day} 00:00:00`;
      };

      // End date = latest date formatted
      bill_period_end_date = formatToAllCustomersDate(maxDate);

      // Start date = one month before the earliest date
      const startDate = new Date(minDate);
      startDate.setMonth(startDate.getMonth() - 1);
      bill_period_start_date = formatToAllCustomersDate(startDate);
    } else {
      const periodObj = allBillPeriodMap.find(
        (period: any) => period.formattedDate === selectedBillPeriodEnd
      );
      const convert_date = periodObj?.BillingPeriodEndDateTime || "";
      bill_period_end_date = convertAllCustomersDate(convert_date);
      bill_period_start_date = convertAllCustomersDate(
        selectedBillPeriodStart || ""
      );
    }
      console.log("selectedAllBillPeriodEnd",selectedAllBillPeriodEnd)
    } else {
      bill_period_end_date = convertSingleCustomerDate(selectedBillPeriodEnd || "");
      bill_period_start_date = convertSingleCustomerDate(
        selectedBillPeriodStart || ""
      );
    }
    const bill_period = { end: bill_period_end_date, start: bill_period_start_date };
    return bill_period || {};
  };
  const getFormattedBillPeriods = () => {
    const isAllCustomers = selectedCustomer === "All Customers";
    let bill_period_end_date;
    let bill_period_start_date;
    if (isAllCustomers) {
      // const periodObj = allBillPeriodMap.find(
      //   (period: any) => period.formattedDate === selectedBillPeriodEnd
      // );
      // const convert_date = periodObj?.BillingPeriodEndDateTime || "";
      // bill_period_end_date = convertAllCustomersDate(convert_date);
      // bill_period_start_date = convertAllCustomersDate(
      //   selectedBillPeriodStart || ""
      // );

       if (Array.isArray(selectedAllBillPeriodEnd) && selectedAllBillPeriodEnd.length > 0) {
       // Convert all date strings to Date objects
      const dateObjects = selectedAllBillPeriodEnd.map(dateStr => new Date(dateStr));

      // Find min and max dates
      const minDate = new Date(Math.min(...dateObjects.map(d => d.getTime())));
      const maxDate = new Date(Math.max(...dateObjects.map(d => d.getTime())));

      // End date = latest date formatted
      bill_period_end_date = `${(maxDate.getMonth() + 1)
        .toString()
        .padStart(2, "0")}/${maxDate.getDate().toString().padStart(2, "0")}/${maxDate.getFullYear()} 12:00 AM`;

      // Start date = one month before the earliest date
      const startDate = new Date(minDate);
      startDate.setMonth(startDate.getMonth() - 1);

      bill_period_start_date = `${(startDate.getMonth() + 1)
        .toString()
        .padStart(2, "0")}/${startDate.getDate().toString().padStart(2, "0")}/${startDate.getFullYear()} 12:00 AM`;
    } else {
      const periodObj = allBillPeriodMap.find(
        (period: any) => period.formattedDate === selectedBillPeriodEnd
      );
      const convert_date = periodObj?.BillingPeriodEndDateTime || "";
      bill_period_end_date = convertAllCustomersDate(convert_date);
      bill_period_start_date = convertAllCustomersDate(
        selectedBillPeriodStart || ""
      );
    }
      console.log("selectedAllBillPeriodEnd",selectedAllBillPeriodEnd)
    } else {
      bill_period_end_date = convertSingleCustomerDate(selectedBillPeriodEnd || "");
      bill_period_start_date = convertSingleCustomerDate(
        selectedBillPeriodStart || ""
      );
    }
    const bill_period = { end: bill_period_end_date, start: bill_period_start_date };
    return bill_period || {};
  };

  const fetchNextData = async () => {
    const isAllCustomers = selectedCustomer === "All Customers";
    const billPeriod_ = getFormattedBillPeriodsParams();
    const billPeriodDisplay = getFormattedBillPeriods();

    setBillPeriod(billPeriodDisplay);
    const serviceProviderIdsString = selectedServiceProviderIds.join(",");
    let bill_period_end_list:any = [];
      if (isAllCustomers) {
        const selectedLists = billPeriodEndOptionsMap
          .filter((item: any) => selectedAllBillPeriodEnd.includes(item.formatted))
          .map((item: any) => item.value);
        bill_period_end_list = selectedLists.map((date: any) => {
          const day = date.split("/")[0];
          return parseInt(day, 10);
        });
      }
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_pop_up_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        rev_customer_ids: isAllCustomers ? null : selectedRevCustomerId,
        service_provider_ids: serviceProviderIdsString,
        tenant_id: 1,
        site_type: 1,
        amop_customer_ids: null,
        billing_period_start_date: billPeriod_.start,
        billing_period_end_date: billPeriod_.end,
        billing_period_id: Number(selectedBillPeriodId),
        site_id: null,
        site_ids: null,
        customer_id: isAllCustomers ? 0 : selectedCustomerId,
        ... isAllCustomers?{bill_period_days:bill_period_end_list || []}:{},
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
        await startPolling();
      } else {
        setLoading(false);
        const rate_plan_count = parsedData?.rate_plan_count;
        setRatePlanCount(rate_plan_count);
        const sim_cards_to_optimize = parsedData?.sim_cards_to_optimize;
        setSIMCardsToOptimize(sim_cards_to_optimize);
        const total_sim_cards_count = parsedData?.total_sim_cards_count;
        setTotalSIMCards(total_sim_cards_count);
        setStartModalOpen(true);
      }
    } catch (error) {
      await startPolling();
    } finally {
      setLoading(false);
    }
  };

  const pollNextData = async () => {
    try {
      const isAllCustomers = selectedCustomer === "All Customers" || false;
      const billPeriod_ = getFormattedBillPeriods();
      const serviceProviderIdsString = selectedServiceProviderIds.join(",");
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_optimization_pop_up_values",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        optimization_type: optimizationType,
        rev_customer_ids: isAllCustomers ? null : selectedRevCustomerId,
        service_provider_ids: serviceProviderIdsString,
        tenant_id: 1,
        site_type: 1,
        amop_customer_ids: null,
        billing_period_start_date: billPeriod_.start,
        billing_period_end_date: billPeriod_.end,
        billing_period_id: Number(selectedBillPeriodId),
        site_id: null,
        site_ids: null,
        ...(!isAllCustomers && { customer_id: selectedCustomerId }),
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag && parsedData?.status === "Success") {
        const rate_plan_count = parsedData?.rate_plan_count;
        setRatePlanCount(rate_plan_count);
        const sim_cards_to_optimize = parsedData?.sim_cards_to_optimize;
        setSIMCardsToOptimize(sim_cards_to_optimize);
        const total_sim_cards_count = parsedData?.total_sim_cards_count;
        setTotalSIMCards(total_sim_cards_count);
        setStartModalOpen(true);
        return true;
      }

      if (parsedData?.status === "Failure") {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
        return true;
      }

      return false;
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true;
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;
    while (!isPollingComplete) {
      isPollingComplete = await pollNextData();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000));
      }
    }
  };

  useEffect(() => {
    if (isOpen) {
      clearFields();
      fetchAllData();
    }
  }, [isOpen]);

  const clearFields = () => {
    setServiceProviders([]);
    setSelectedServiceProviderIds([]);
    setSelectedBillPeriodEnd(null);
    setFormattedDate(null);
    setSelectedBillPeriodStart(null);
    setSelectedBillPeriodId(null);
    setSelectedCustomer(null);
    setSelectedCustomerId(null);
    setRatePlanCount(null);
    setTotalSIMCards(null);
    setSIMCardsToOptimize(null);
    setBillPeriodStartError(false);
    setBillPeriodError(false);
    setCustomerError(false);
    setServiceProviderError(false);
    setOptimizationTypeError(false);
  };

  const handleValidation = (): boolean => {
        let isNotValid = false
        //optimization type valiadation
        if (!optimizationType) {
            setOptimizationTypeError(true);
            isNotValid = true
        } else {
            setOptimizationTypeError(false);
            // isValid = true
        }

        //service provider error valiadation
        if (serviceProviders.length === 0) {
            setServiceProviderError(true);
            isNotValid = true
        } else {
            // isValid = true
            setServiceProviderError(false);
        }

        //customer error valiadation
        if (optimizationType && optimizationType === "Customer") {
            if (!selectedCustomer) {
                setCustomerError(true)
                isNotValid = true
            }
            else {
                setCustomerError(false);
                // isValid = true
            }
        }
        

        //bill period valiadation
        if (!selectedBillPeriodEnd) {
            setBillPeriodError(true);
        console.log("true",selectedBillPeriodEnd)

            isNotValid = true
        } else {
            setBillPeriodError(false);
            // isValid = true
        }
        
        // Continue with further actions if no errors
        if (!isNotValid) {
            fetchNextData()
            return false
        }
        else {
            return true
        }
    }
  const handleNext = () => {
    handleValidation();
  };

  const submitData = async () => {
    setLoading(true);
    onCancel();
    setTimeout(() => {
      setLoading(false);
      onSubmit();
      notification.success({
        message: "Success",
        description: "Successfully started Optimization.",
        style: messageStyle,
        placement: "top",
      });
      fireSideCannons()
    }, 10000);
    try {
      const isAllCustomers = selectedCustomer === "All Customers";
      let bill_period_end_list;
      if (isAllCustomers) {
        const selectedLists = billPeriodEndOptionsMap
          .filter((item: any) => selectedAllBillPeriodEnd.includes(item.formatted))
          .map((item: any) => item.value);
        bill_period_end_list = selectedLists.map((date: any) => {
          const day = date.split("/")[0];
          return parseInt(day, 10).toString();
        });
      }
      const billPeriod_ = getFormattedBillPeriods();
      const serviceProviderIdsString = selectedServiceProviderIds.join(",");
      const url = ENV_ROUTES.OPTIMIZATION;
      const body = {
        billPeriodId: Number(selectedBillPeriodId),
        siteId: isAllCustomers ? null : selectedCustomerId || null,
        serviceProviderId: "",
        serviceProviderIds: serviceProviderIdsString,
        optimizationType: 1,
        optimizationFrom: "group",
        billingEndDayList: isAllCustomers ? bill_period_end_list.join(",") : "",
      };
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/start_cross_provider_optimization",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        body: { ...body },
        device_count: SIMCardsToOptimize,
        billing_period_start_date: billPeriod_.start,
        billing_period_end_date: billPeriod_.end,
        template: `
        Hi ${username},

        This will start a ${optimizationType} optimization for the ${formattedDate} billing period.

        The billing period for ${serviceProviders} is from ${billPeriod_.start} to ${billPeriod_.end}.

        Total SIM Cards: ${totalSIMCards}

        SIM Cards to Optimize: ${SIMCardsToOptimize}

        Rate Plan Count: ${ratePlanCount}

        Thank you
      `,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
              setLoading(false);
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while submitting data. Please try again.",
                centered: true,
              });
            } else {
              setLoading(false);
            //   notification.success({
            //     message: 'Success',
            //     description: 'Successfully saved.',
            //     style: messageStyle,
            //     placement: 'top',
            //   });
            }
        } catch (error) {
            // Modal.error({
            //   title: "Data Fetch Error",
            //   content:
            //     error instanceof Error
            //       ? error.message
            //       : "An unexpected error occurred while submitting data. Please try again.",
            //   centered: true,
            // });
        }
        finally {
            setLoading(false)
        }
    };

  const handleStart = () => {
    submitData();
  };

  const handleCancel = () => {
    clearFields();
    onCancel();
    setStartModalOpen(false);
  };

   const handleOptimizationTypeChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption.value
            setOptimizationType(selectedOption.value);
        }
        else {
            setOptimizationType(selectedOption.value);
        }
    };

  const handleServiceProviderChange = (selectedOptions: any) => {
    if (selectedOptions.length > 0) {
      setServiceProviders(selectedOptions);
      const selectedValues = selectedOptions.map((option: any) => option.value);
      const selectedIds = serviceProviderIdMap
        .filter((item: any) => selectedValues.includes(item.service_provider_name))
        .map((item: any) => item.id);
      setSelectedServiceProviderIds(selectedIds);
    } else {
      setServiceProviders([]);
      setSelectedServiceProviderIds([]);
    }
  };

  const handleCustomerChange = (selectedOption: any) => {
    setSelectedAllBillPeriodEnd([]);
    setSelectedBillPeriodEnd(null);
    setSelectedBillPeriodId(null);
    setSelectedBillPeriodStart(null);
    if (selectedOption) {
      const value = selectedOption.value;
      if (value === "All Customers") {
        setSelectedCustomer("All Customers");
        const billPeriodOptions_ = allBillPeriodMap.map(
          (period: any) => period.formattedDate || ""
        );
        setBillPeriodOptions(billPeriodOptions_);
      } else {
        setSelectedCustomer(value);
        const selectedCustomerObject = customerIdMap.find(
          (customer: any) => customer.customer_name === value
        );
        const selectedId = selectedCustomerObject?.id || null;
        const selectedRevId = selectedCustomerObject?.rev_customer_id || null;
        setSelectedRevCustomerId(selectedRevId);
        setSelectedCustomerId(selectedId);
        fetchCustomerBillingPeriods(selectedId);
      }
    } else {
      setSelectedCustomer(null);
      setSelectedCustomerId(null);
    }
  };

  const handleFutureDateSelection = (date: any) => {
    if (date) {
      const selectedStartDate = new Date(date);
      const today = new Date();
      // Add validation if needed
    }
  };

  const handleBillPeriodChange = (selectedOption: any) => {
    if (selectedOption) {
      const value = selectedOption.value;
      setSelectedBillPeriodEnd(value);
      handleFutureDateSelection(value);

      if (selectedCustomer === "All Customers") {
        const selectedBillPeriodObject = allBillPeriodMap.find(
          (period: any) => period.formattedDate === value
        );
        const selectedStart =
          selectedBillPeriodObject?.BillingPeriodStartDateTime || null;
        setSelectedBillPeriodStart(selectedStart);
        const selectedId = selectedBillPeriodObject?.billing_period_id || null;
        setSelectedBillPeriodId(selectedId);
        const bill_period_end_options =
          selectedBillPeriodObject?.BillingEndDateTimeList || [];
        const bill_period_end_map = bill_period_end_options.map((period: any) => ({
          formatted: formatEndDate(period),
          value: period,
        }));
        setBillPeriodEndOptionsMap(bill_period_end_map);
        const billPeriodEndOptions_ = bill_period_end_map.map(
          (period: any) => period.formatted
        );
        setBillPeriodEndOptions(billPeriodEndOptions_);
        setSelectedAllBillPeriodEnd(billPeriodEndOptions_);
      } else {
        const selectedBillPeriodObject = billPeriodMap.find(
          (period: any) => period.billing_cycle_end_date === value
        );
        const selectedStart =
          selectedBillPeriodObject?.billing_cycle_start_date || null;
        setSelectedBillPeriodStart(selectedStart);
        const selectedId = selectedBillPeriodObject?.value || null;
        setSelectedBillPeriodId(selectedId);
      }
    } else {
      setSelectedBillPeriodEnd(null);
      setSelectedAllBillPeriodEnd([]);
      setFormattedDate(null);
      setSelectedBillPeriodId(null);
      setSelectedBillPeriodStart(null);
    }
  };

  const handleAllBillPeriodChange = (selectedOptions: any) => {
    if (selectedOptions.length > 0) {
      const selectedValues = selectedOptions.map((option: any) => option.value);
      setSelectedAllBillPeriodEnd(selectedValues);
    } else {
      setSelectedAllBillPeriodEnd([]);
    }
  };

  return (
    <Modal
      visible={isOpen}
      onCancel={handleCancel}
      footer={null}
      width="600px"
      centered
    >
      {loading ? (
        <div className="flex justify-center items-center h-[400px]">
          <Spin size="large" />
        </div>
      ) : (
        <>
          <div className="container">
            <div className="mb-4">
              <h2 className="font-[600] text-[18px]">Start Optimization</h2>
            </div>
            <div className="flex flex-col space-y-4 mb-4">
              <div>
                <label className="field-label">
                  Optimization Type<span className="text-red-500">*</span>
                </label>
                <Select
                  options={optimizationTypeOptions}
                  value={{ label: optimizationType, value: optimizationType }}
                  onChange={handleOptimizationTypeChange}
                  styles={DropdownStyles}
                />
                {optimizationTypeError && (
                  <span className="text-red-500 text-sm">
                    Please Select an Optimization Type.
                  </span>
                )}
              </div>
              <div>
                <label className="field-label">
                  Service Provider<span className="text-red-500">*</span>
                </label>
                <Select
                  options={serviceProviderOptions.map((option: string) => ({
                    label: option,
                    value: option,
                  }))}
                  value={serviceProviders}
                  onChange={handleServiceProviderChange}
                  isClearable
                  isMulti
                  styles={DropdownStyles}
                />
                {serviceProviderError && (
                  <span className="text-red-500 text-sm">
                    Service Provider is Required.
                  </span>
                )}
              </div>
              <div>
                <div className="flex items-center">
                  <label className="field-label">Customer</label>
                  {optimizationType === "Customer" && (
                    <span className="text-red-500">*</span>
                  )}
                </div>
                <VirtualizedSelect
                  value={
                    selectedCustomer
                      ? { label: selectedCustomer, value: selectedCustomer }
                      : null
                  }
                  onChange={handleCustomerChange}
                  options={customerOptions.map((option: any) => ({
                    label:`${ option?.customer_name || ""} ${option?.customer_name !=="All Customers"?"--":""} ${option?.account_number || ""}`,
                    value: option?.customer_name,
                  }))}
                  isMulti={false}
                  placeholder=""
                  isClearable
                  maxHeight={300}
                  styles={DropdownStyles}
                />
                {customerError && (
                  <span className="text-red-500 text-sm">
                    Customer is Required.
                  </span>
                )}
              </div>
              {selectedCustomer === "All Customers" ? (
                <>
                  <div>
                    <label className="field-label">
                      Bill Period<span className="text-red-500">*</span>
                    </label>
                    <Select
                      options={billPeriodOptions.map(
                        (option: string | { label: string; value: string }) =>
                          typeof option === "string"
                            ? { label: option, value: option }
                            : option
                      )}
                      styles={DropdownStyles}
                      value={
                        selectedBillPeriodEnd
                          ? {
                              label: selectedBillPeriodEnd,
                              value: selectedBillPeriodEnd,
                            }
                          : null
                      }
                      onChange={handleBillPeriodChange}
                      isDisabled={!selectedCustomer}
                      isClearable
                    />
                    {billPeriodError && (
                      <span className="text-red-500 text-sm">
                        Bill Period End Date is Required.
                      </span>
                    )}
                  </div>
                  <div>
                    <label className="field-label">
                      Bill Period End Date<span className="text-red-500">*</span>
                    </label>
                    <Select
                      options={billPeriodEndOptions.map(
                        (option: string, index: number) => ({
                          label: option,
                          value: option,
                          key: `${option}-${index}`,
                        })
                      )}
                      styles={DropdownStyles}
                      value={selectedAllBillPeriodEnd.map((option: any) => ({
                        label: option,
                        value: option,
                      }))}
                      onChange={handleAllBillPeriodChange}
                      isDisabled={!selectedBillPeriodEnd || !selectedCustomer}
                      isMulti
                    />
                    {billPeriodError && (
                      <span className="text-red-500 text-sm">
                        Bill Period End Date is Required.
                      </span>
                    )}
                  </div>
                </>
              ) : (
                <div>
                  <label className="field-label">
                    Bill Period End Date<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={billPeriodOptions.map(
                      (option: string | { label: string; value: string }) =>
                        typeof option === "string"
                          ? { label: option, value: option }
                          : option
                    )}
                    styles={DropdownStyles}
                    value={
                      selectedBillPeriodEnd
                        ? {
                            label: selectedBillPeriodEnd,
                            value: selectedBillPeriodEnd,
                          }
                        : null
                    }
                    onChange={handleBillPeriodChange}
                    isDisabled={!selectedCustomer}
                    isClearable
                  />
                  {billPeriodError && (
                    <span className="text-red-500 text-sm">
                      Bill Period End Date is Required.
                    </span>
                  )}
                </div>
              )}
            </div>
            <div className="flex space-x-4 justify-center">
              <button className="cancel-btn" onClick={handleCancel}>
                Cancel
              </button>
              <button className="save-btn" onClick={handleNext}>
                Next
              </button>
            </div>
          </div>
          <Modal
            title="Optimization start"
            visible={startModalOpen}
            onCancel={handleCancel}
            footer={
              <div className="flex space-x-4 justify-center">
                <button className="cancel-btn" onClick={handleCancel}>
                  Cancel
                </button>
                <button
                  className={`${
                    ratePlanCount === 0 && SIMCardsToOptimize === 0
                      ? "cancel-btn"
                      : "save-btn"
                  } disabled:cursor-not-allowed`}
                  onClick={handleStart}
                  disabled={ratePlanCount === 0}
                >
                  Start
                </button>
              </div>
            }
            centered
          >
            <div>
              <div className="justify-content">
                <p className="mb-4">{`This will start a Customer Optimization for the ${selectedBillPeriodEnd} billing period.`}</p>
                <p className="mb-4">{`The billing period for ${serviceProviders
                  .map((provider: any) => provider.value)
                  .join(", ")} is from ${billPeriod?.start || ""} to ${
                  billPeriod?.end || ""
                }.`}</p>
              </div>
              <div className="text-left">
                <p className="font-semibold">
                  Total SIM Cards: <span className="font-normal">{totalSIMCards}</span>
                </p>
                <p className="font-semibold">
                  SIM Cards to Optimize:{" "}
                  <span className="font-normal">{SIMCardsToOptimize}</span>
                </p>
                {billPeriodStartError && (
                  <span className="text-red-500 text-sm">
                    Error Starting Optimization: No eligible SIM Cards found for these
                    options.
                  </span>
                )}
                <p className="font-semibold">
                  Rate Plan Count: <span className="font-normal">{ratePlanCount}</span>
                </p>
              </div>
            </div>
          </Modal>
        </>
      )}
    </Modal>
  );
};

export default CustomerOptimize;