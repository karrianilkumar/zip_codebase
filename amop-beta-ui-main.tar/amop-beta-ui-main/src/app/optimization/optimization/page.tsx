"use client";

import React, { useEffect, useState, lazy, Suspense } from "react";
import { useSidebarStore } from "@/app/stores/navBarStore";
import { useLogoStore } from "@/app/stores/logoStore";
import { Spin } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { useSearchStore } from "@/app/stores/searchStore";

const CarrierOptimization = lazy(() => import("./carrier_optimization"));
const CustomerOptimization = lazy(() => import("./customer_optimization"));

const Optimization: React.FC = () => {
  const active_tab=localStorage.getItem("activeTab") || "customer"
  const active_tabs_list=["customer","carrier"]
  const [activeTab, setActiveTab] = useState(() => {
     // Check if active_tab is in active_tabs_list; default to 'customer' if not
  return active_tabs_list.includes(active_tab) ? active_tab : "customer";
  });
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const [loading, setLoading] = useState(false);
  const { role } = useAuth();
  const { setIsRedirectedFromDetails , setDetailsRedirectedFilters, setDetailsRedirectedSearchTerm } = useSearchStore();
  
  useEffect(() => {
    // Save activeTab state to localStorage on change
    localStorage.setItem("activeTab", activeTab);
    setDetailsRedirectedFilters({})
    setDetailsRedirectedSearchTerm("")
    setIsRedirectedFromDetails(false)
  }, [activeTab]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    // <Suspense
    //   fallback={
    //     <div className="flex justify-center items-center h-screen">
    //       <Spin size="large" />
    //     </div>
    //   }
    // >
      <div className="">
        <div
          className={`bg-white shadow-md mb-4 gap-4  tabs ${
            isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`}
        >
          <button
            className={`tab-headings ${
              activeTab === "customer" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("customer")}
          >
            Customer Optimization
          </button>
          {(role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin") && 
          <button
          className={`tab-headings ${
            activeTab === "carrier" ? "active-tab-heading" : ""
          }`}
          onClick={() => setActiveTab("carrier")}
        >
          Carrier Optimization
        </button>}
          
        </div>
        <div className="h-[calc(100vh-150px)] pt-[70px]">
          {activeTab === "carrier" && <CarrierOptimization />}
          {activeTab === "customer" && <CustomerOptimization />}
        </div>
      </div>
    // </Suspense>
  );
};

export default Optimization;
