"use client";
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
} from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Optimize from "@/app/sim_management/optimize";
import Select from 'react-select';
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import { useMutation } from "@tanstack/react-query";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";

const { RangePicker } = DatePicker;
const OptimizationTableComponent = lazy(() => import("@/app/components/optimizationTableComponent/page"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(() => import("@/app/components/advanced_search"));

type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  // billing_period_start_date: string;
  // billing_period_end_date: string;
  billing_cycle_period: any | null,

  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
  optimization_type: string | null,
  service_provider: any | null,
  sessionID: string|null
};
const CarrierOptimization: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName,sessionId,dynamicColumns,setDynamicColumns,tenantId,combineAdnvaceStoredpagination,advancedStoredpagination,storedpagination} = useAuth();
  const [loading, setLoading] = useState(true);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport,exports } = exportLoadingStore();
  const exportKey = "carrie Optimization";
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [isOptimizeModalVisible, setIsOptimizeModalVisible] = useState(false);
  const [optimizeDisable, setOptimizeDisable] = useState<boolean>(false);
  const hasFetchedData = useRef(false);
  const { features: moduleFeatures, setFeatures: setModuleFeatures } = useFeatureStore();
  const { setOptimizationType } = useOptimizationStore()

  //Export variabes
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [optimizationTypeOptions, setOptimizationTypeOptions] = useState<any[]>(["Carrier", "Customer"])
  const [serviceProviderOptions, setServiceProviderOptions] = useState<any[]>([])
  const [selectedProvider, setSelectedProvider] = useState<{ value: string; label: string } | null>({
    value: "All service providers",
    label: "All service providers",
  });
  const [selectedOptimizationType, setSelectedOptimizationType] = useState<string | null>("Carrier");
  const [billingPeriodDates, setBillingPeriodDates] = useState<Record<string, string[]>>({});
  const [billingCyclePeriods, setBillingCyclePeriods] = useState<string[]>([]);
  const [selectedBillingCyclePeriod, setSelectedBillingCyclePeriod] = useState<{ value: string; label: string } | null>(null);
  const [selectedBillingCyclePeriodEnd, setSelectedBillingCyclePeriodEnd] = useState<{ value: string; label: string } | null>(null);
  const [optimizationTyperror, setOptimizationTypeError] = useState(false);
  const [providerError, setProviderError] = useState(false);
  const [dateError, setDateError] = useState(false);

    const [optimizeDisableFlag, setOptimizeDisableFlag] = useState(false);
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const DisableOtimize = (value: any) => {
    let numericData = value && typeof value === 'number' ? value : Number(value);
    let normalizedValue = 0;

    if (!isNaN(numericData)) {
      normalizedValue = Math.max(0, Math.min(100, numericData));
    }
    if (normalizedValue === 0 || normalizedValue >= 75) {
      setOptimizeDisable(false)
    } else {
      setOptimizeDisable(true)
    }

  }

  const fetchOptimizeData = useCallback(async () => {
    try {
      console.log("setLoading", loading)
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/optimize_button_status",
        // tenant_id: 1,
        optimization_type: "All",
        filter_str: "",
        role_name: role,
        parent_module: "Optimization",
        module_name: "Optimization",
        feature_module_name: "Optimization",
        // optimization_type: "Customer",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
  
      } else {
        const optimizeFlag= parsedData?.optimize_button_status || false
        setOptimizeDisableFlag(optimizeFlag)
      }
      // addLog('BulkChange Table Data Processing Data Completed');
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
    }
  }, [username, partner, role, token]);

  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Carrier":visibleColumns}))
      }, [visibleColumns]);
  const fetchData = useCallback(async () => {
    settabledata([])
      setLoading(true);
      localStorage.setItem("current_session_details_active_module", "Optimization");
    try {
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_optimization_data",
        role_name: role,
        parent_module: "Optimization",
        module_name: "Optimization",
        feature_module_name: "Optimization",
        optimization_type: "Carrier",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const headersMap_ = parsedData?.headers_map?.["Carrier"]?.header_map || {}
        const sortedheaderMap = sortHeaderMap(headersMap_)
        setHeaderMap(sortedheaderMap)
        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
        setHeaders(headers_)
        const dynamic_cols=dynamicColumns?.["Carrier"] && dynamicColumns["Carrier"].length>0 ?dynamicColumns["Carrier"] :headers_ || headers_
        setVisibleColumns(dynamic_cols)
        const tableData_ = parsedData?.data || []
        setTableData(tableData_)
        const features_ = parsedData?.headers_map?.["Carrier"]?.module_features || []
        setFeatures(features_)
        setModuleFeatures(features_)
        const pagination_ = parsedData?.pages || {}
        setPagination(pagination_)
        const service_provider = parsedData?.service_providers || []
        setServiceProviderOptions(service_provider)
        setBillingPeriodDates(parsedData.billing_period_dates || {});

        const firstRow = tableData_[0] || {}
        const progressVal = firstRow?.progress || 0
        DisableOtimize(progressVal)
      }
      // addLog('BulkChange Table Data Processing Data Completed');
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  }, [username, partner, role, token]);

  useEffect(() => {
    setOptimizationType("Carrier")
    if (!hasFetchedData.current) {
      fetchData();
      fetchOptimizeData()
      hasFetchedData.current = true;
    }
    // Set an interval to call fetchOptimizeData every 5 minutes
    // const intervalId = setInterval(() => {
    //   fetchOptimizeData();
    // }, 5000); // 5 minutes in milliseconds

    // Cleanup the interval when the component unmounts
    // return () => {
    //   clearInterval(intervalId);
    // };
  }, [fetchData]);

  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };

  const handleOptimizationTypeChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedOptimizationType(selectedOption.value);
      setOptimizationTypeError(false)
    }
    else if (selectedOption === null) {
      setSelectedOptimizationType("Carrier")
    }
  };
  const handleServiceProviderChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedProvider(selectedOption);
      setProviderError(false)
      const periods = billingPeriodDates[selectedOption.value] || [];
      setBillingCyclePeriods(periods);
      if (selectedOption.value !== "All service providers" && periods.length > 0) {
        setSelectedBillingCyclePeriod({ value: periods[0], label: periods[0] }); // Set first value as default
        setSelectedBillingCyclePeriodEnd({value:periods[0], label:periods[0]});
      } else {
        setSelectedBillingCyclePeriod(null); // Clear selection if "All service providers" is selected
        setSelectedBillingCyclePeriodEnd(null);
      }
    }
    else if (selectedOption === null) {
      setSelectedProvider({
        value: "All service providers",
        label: "All service providers",
      });
    }
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);

  };

  const handleExportModalClose = () => {
    setDateRange([null, null]);
    setSelectedProvider({
      value: "All service providers",
      label: "All service providers",
    });
    setSelectedBillingCyclePeriod(null);
    setSelectedBillingCyclePeriodEnd(null);
    setSelectedOptimizationType("Carrier")
    setOptimizationTypeError(false)
    setProviderError(false)
    setDateError(false)
    setExportModalOpen(false);
  };
  const handleExportClick = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          index_name: "carrier_optimization_list_view",
          module_name: "Carrier Optimization",
        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Carrier Optimization",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "carrier_optimization_list_view",
          pages: {
            start: 0,
            end: 100
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Carrier Optimization",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "carrier_optimization_list_view",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        handleExportModalOpen()
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        if (parsedData.flag === true) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // // setExportLoading(false)
            // notification.success({
            //   message: 'Success',
            //   description: 'Successfully exported the record!',
            //   style: messageStyle,
            //   placement: 'top',
            // });
            fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Carrier Optimization.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
                fireSideCannons()
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
          }
          else {
            // setExportLoading(false)
            removeExport(key);
            Modal.error({
              title: "Export Error",
              content: parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }


        } else {
          // setExportLoading(false)
          removeExport(key);
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      }

    } catch (error) {
      console.log("catch")
      await startPolling()
      removeExport(key);
      // setLoading(false);
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      removeExport(key);

    }
  };

  //Continuous calling of export
  const pollExportStatus = async () => {
    try {

      const export_url = ENV_ROUTES.OPTIMIZATION;
      const export_data = {
        tenant_name: partner || "default_value",
        username,
        path: "/get_export_status",
        role_name: role,
        parent_module: "Optimization",
        module_name: "Export Optimization",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
      };

      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Carrier Optimization.zip';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                            fireSideCannons()
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      // Modal.error({
      //     title: "Export Error",
      //     content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      //     centered: true,
      // });
      return true; // Stop polling
    }
  };
  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

  const handleExportSave = async (key:string, heading:string) => {
    const isBillingPeriodDisabled = selectedProvider?.value === "All service providers";

    if (!isBillingPeriodDisabled && (!selectedBillingCyclePeriod || !selectedBillingCyclePeriodEnd)) {
      setDateError(true); // Show error message
      return; // Stop further execution
    }
  
   // Clear any existing error state if the inputs are valid
   setDateError(false);
    let [startDate, endDate] = dateRange || [];
    handleExportModalClose()
    // setExportLoading(true);
    addExport(key, heading);
    try {
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        path: "/export_optimization_data_zip",
        username: username,
        module_name: "Optimization",
        optimization_type: selectedOptimizationType,
        service_provider: selectedProvider?.value === "All service providers" ? "" : selectedProvider?.value,
        request_received_at: getCurrentDateTime(),
        // billing_cycle_period: selectedBillingCyclePeriod ? selectedBillingCyclePeriod.value : "",
        billing_period_start_date: isBillingPeriodDisabled
        ? "":selectedBillingCyclePeriod?.value.split(" - ")[0].trim(),
        billing_period_end_date:isBillingPeriodDisabled
        ? ""
        :  selectedBillingCyclePeriodEnd?.value.split(" - ")[1].trim(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
      };;
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === true) {
        await startPolling();

      } else {
        await startPolling();
      }

    } catch (error) {
      await startPolling();
    } finally {
      // setExportLoading(false);
      removeExport(key)
    }
  };

  const handleExport = (key:string, heading:string) => {
    
    const isValid = selectedOptimizationType && selectedProvider?.value && (selectedProvider?.value === "All service providers" || selectedBillingCyclePeriod||selectedBillingCyclePeriodEnd)
    if (isValid) {
      if (!exports.some((exportItem) => exportItem.popupHeading === "Carrier Optimization")) {
        handleExportSave("CarrierOptimization", "Carrier Optimization")
      }
      // setExportLoading(true)
      // addExport(key, heading);
    }
    else {
      if (!selectedOptimizationType) {
        setOptimizationTypeError(true)
      }
      if (!selectedProvider) {
        setProviderError(true)
      }
      if (selectedProvider?.value !== "All service providers" && !selectedBillingCyclePeriod) {
        setDateError(true);
      }
       else {
        setDateError(false); // Ensure no error when "All service providers" is selected
      }
    }
  }
  // const exportMutation = useMutation<any, Error, ExportData>({
  //   mutationFn: async (exportData) => {
  //     setExportLoading(true)
  //     const url = ENV_ROUTES.OPTIMIZATION
  //     const response = await axios.post(
  //       url,
  //       { data: exportData },
  //       {
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //       }
  //     );
  //     return JSON.parse(response.data.body);
  //   },
  //   onSuccess: (data) => {
  //     if (data.flag === true) {
  //       setExportLoading(false)
  //       notification.success({
  //         message: "Success",
  //         description: "Successfully exported the record!",
  //         style: messageStyle,
  //         placement: "top",
  //       });
  //       downloadZipBlob(data.blob);
  //     } else {
  //       setExportLoading(false)
  //       Modal.error({
  //         title: "Export Error",
  //         content: data.message,
  //         centered: true,
  //       });
  //     }
  //     handleExportModalClose();
  //   },
  //   onError: (error) => {
  //     setExportLoading(false)
  //     console.error("Error downloading the file:", error);
  //     Modal.error({
  //       title: "Export Error",
  //       content:
  //         "An error occurred while exporting the file. Please try again.",
  //     });
  //     handleExportModalClose();
  //   },
  // });

  // const handleExportSave = () => {

  //   if (!selectedBillingCyclePeriod && selectedProvider?.value != "All service providers") {
  //     setDateError(true)
  //     return;
  //   }

  //   let [startDate, endDate] = dateRange;

  //   const exportData: ExportData = {
  //     path: "/export_optimization_data_zip",
  //     username: username,
  //     module_name: "Optimization",
  //     optimization_type:selectedOptimizationType,
  //     service_provider: selectedProvider?.value ==="All service providers" ? "" : selectedProvider?.value,
  //     request_received_at: getCurrentDateTime(),
  //     billing_cycle_period : selectedBillingCyclePeriod ? selectedBillingCyclePeriod.value : "",

      // billing_period_start_date: startDate.format("YYYY-MM-DD 00:00:00"),
      // billing_period_end_date: endDate.format("YYYY-MM-DD 23:59:59"),
    //   Partner: partner,
    //   access_token: token,
    //   db_name: selectedDb,
                // ...metaData,
    //   sessionID: sessionId,
    // };

  //   exportMutation.mutate(exportData);
  // };

  const downloadZipBlob = (base64Blob: string) => {

    // Convert base64 string to binary data
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    // Create a Blob from the byteArray with a type of zip
    const blobObject = new Blob([byteArray], {
      type: "application/zip",
    });

    // Create a download link and trigger it to download the .zip file
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = `${selectedOptimizationType}.zip`; // Ensure to download as .zip
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleOpenOptimizeModal = () => {
    setIsOptimizeModalVisible(true);
  };

  const handleOptimizeCancel = () => {
    setIsOptimizeModalVisible(false);
  };
  const handleOptimizeSubmit = () => {
    setIsOptimizeModalVisible(false);
    fetchData()
    fetchOptimizeData()
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf('day'));
    return current && current > dayjs().endOf('day');
  };


  return (
    <>
      <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>
        <div className="relative">
        <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">

              {features.includes("Search-Carrier optimization") && (
                <TableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"carrier_optimization_list_view"}
                  headerMap={headerMap}
                />
              )}

              {features.includes("Advanced filter-Carrier optimization") && (
                <AdvancedMultiFilter
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"carrier_optimization_list_view"} />
              )}
            </div>


              {/* Export and ColumnFilter Container */}
              <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
              {features.includes("Optimize-Carrier optimization") && (
                <button
                  className={`${optimizeDisable || optimizeDisableFlag ? "cancel-btn" : "save-btn "} disabled:cursor-not-allowed`}
                  onClick={handleOpenOptimizeModal}
                  disabled={optimizeDisable  || optimizeDisableFlag}>
                  <span>Optimize</span>
                </button>
              )}
              {features.includes("Export-Carrier optimization") && (
                <button className="save-btn"  onClick={() => {
                    if (!exports.some((exportItem) => exportItem.popupHeading === "Carrier Optimization")) {
                      handleExportClick("CarrierOptimization", "Carrier Optimization");
                    }
                  }}>

                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />

            </div>
          </div>
           {/* Sticky Footer for Small Screens */}
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            {features.includes("Optimize-Carrier optimization") && (
                <button
                  className={`${optimizeDisable || optimizeDisableFlag ? "cancel-btn" : "save-btn "} disabled:cursor-not-allowed`}
                  onClick={handleOpenOptimizeModal}
                  disabled={optimizeDisable  || optimizeDisableFlag}>
                  <span>Optimize</span>
                </button>
              )}    
              {features.includes("Export-Carrier optimization") && (
                <button className="save-btn"  onClick={() => {
                    if (!exports.some((exportItem) => exportItem.popupHeading === "Carrier Optimization")) {
                      handleExportClick("CarrierOptimization", "Carrier Optimization");
                    }
                  }}>

                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
                </button>
              )}
                     
                      <ColumnFilter
                        headers={headers}
                        visibleColumns={visibleColumns}
                        setVisibleColumns={setVisibleColumns}
                        headerMap={headerMap}
                      />
                    </div>
          <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
            <OptimizationTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              moduleName="Carrier optimization"
              pagination={pagination}
              advancedFilters={filteredData}
              height = {showAdvanced?360:300}
            />
          </div>
          <Modal
            title="Export Output"
            visible={isExportModalOpen}
            onCancel={() => {
              handleExportModalClose();

            }}
            footer={null}
            centered
            afterClose={() => { handleExportModalClose() }}
            style={{ top: "-4%" }}
          >
            <>
              <div className="flex flex-col space-y-4 mb-4">
                <div className="">
                  <label className="field-label">
                    Optimization Type<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={optimizationTypeOptions.map((option) => ({
                      label: option,
                      value: option,
                    }))}
                    value={{ label: selectedOptimizationType, value: selectedOptimizationType }}
                    onChange={handleOptimizationTypeChange}
                    styles={DropdownStyles}
                  />
                  {optimizationTyperror && (<span className="text-red-500">Please Select Optimization Type</span>)}
                </div>
                <div className="">
                  <label className="field-label">
                    Service Provider<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={serviceProviderOptions.map((option) => ({
                      label: option,
                      value: option,
                    }))}
                    value={selectedProvider}
                    onChange={handleServiceProviderChange}
                    styles={DropdownStyles}

                  />
                  {providerError && (<span className="text-red-500">Please Select Service Provider</span>)}
                </div>
                <div className="flex space-x-4">
                <div className="">
                  
                  <Select
                    options={billingCyclePeriods.map(period => ({ value: period, label: period }))}
                    onChange={setSelectedBillingCyclePeriod}
                    placeholder="Select Billing Cycle Period"
                    isDisabled={selectedProvider?.value === "All service providers"} // Disable if "All service providers" is selected
                    value={selectedBillingCyclePeriod}
                    styles={DropdownStyles}
                  />
                  {/* {dateError && (<span className="text-red-500">Please Select Bill Period</span>)} */}
                  {/* <label className="field-label">
                    Bill Period<span className="text-red-500">*</span>
                  </label>
                  <RangePicker
                  className="w-full input"
                  value={
                    dateRange[0] && dateRange[1]
                      ? [dateRange[0], dateRange[1]]
                      : null
                  }
                  onChange={(dates) => {
                    if (dates && dates.length === 2) {
                      setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                      setDateError(false)
                    } else {
                      setDateRange([null, null]);
                    }
                  }}
                  format="YYYY-MM-DD"
                  disabled={selectedProvider?.value === "All service providers"}
                  disabledDate={disableFutureDates}
                />
                {dateError && (<span className="text-red-500">Please Select Bill Period</span>)} */}
                </div>
                <div className="">
                  
                  <Select
                    options={billingCyclePeriods.map(period => ({ value: period, label: period }))}
                    onChange={setSelectedBillingCyclePeriodEnd}
                    placeholder="Select Billing Cycle Period"
                    isDisabled={selectedProvider?.value === "All service providers"} // Disable if "All service providers" is selected
                    value={selectedBillingCyclePeriodEnd}
                    styles={DropdownStyles}
                  />
                  {/* {dateError && (<span className="text-red-500">Please Select Bill Period</span>)} */}
                  {/* <label className="field-label">
                    Bill Period<span className="text-red-500">*</span>
                  </label>
                  <RangePicker
                  className="w-full input"
                  value={
                    dateRange[0] && dateRange[1]
                      ? [dateRange[0], dateRange[1]]
                      : null
                  }
                  onChange={(dates) => {
                    if (dates && dates.length === 2) {
                      setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                      setDateError(false)
                    } else {
                      setDateRange([null, null]);
                    }
                  }}
                  format="YYYY-MM-DD"
                  disabled={selectedProvider?.value === "All service providers"}
                  disabledDate={disableFutureDates}
                />
                {dateError && (<span className="text-red-500">Please Select Bill Period</span>)} */}
                </div>
                </div>
                <div className="flex space-x-4 justify-center">
                  <button className="cancel-btn" onClick={() => {
                    handleExportModalClose();
                  }}>
                    Cancel
                  </button>
                  <button className="save-btn" onClick={() => handleExport("CarrierOptimization", "Carrier Optimization")}>
                    Export
                  </button>
                </div>
              </div>
            </>
          </Modal>
          {isOptimizeModalVisible && (
            <Optimize
              isOpen={isOptimizeModalVisible}
              onCancel={handleOptimizeCancel}
              module_name={'Optimization'}
              onSubmit={handleOptimizeSubmit}
            />
          )}
        </div>
        {/* {exportLoading && (
          <div className="export-processing-div">
            Export Processing...
          </div>
        )} */}
      </Suspense>
    </>
  );
};

export default CarrierOptimization;
