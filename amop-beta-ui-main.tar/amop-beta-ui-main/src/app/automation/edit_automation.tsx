import React, { useEffect, useState } from 'react';
import { Input, Modal, notification, Spin, Switch } from 'antd';
import Select from 'react-select';
import { DropdownStyles } from '../components/css/dropdown';
import { useAuth } from '../components/auth_context';
import { ENV_ROUTES } from '../components/routes/route_constants';
import { getCurrentDateTime } from '../components/header_constants';
import axios from 'axios';
import moment from 'moment';
import dayjs from 'dayjs';
import { fireSideCannons } from '../components/confetti';

interface Step {
    id: number;
    dataCondition: string;
    dataConditionId: any
    dataAmount: string;
    dataUnit: string;
    dataStatus: string;
    dataStatusId: any;
    dataFeature: any;
    dataFeatureId: any;
    followUpActions: [],
    thenAction: string,
    thenActionId: any;
    thenStatus: string,
    thenStatusId: any,
    thenFeature: string,
    thenFeatureId: any,
    datePeriod: string,
    datePeriodId: any
}

interface CreateModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    row: any;
}

const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
};
const EditAutomation: React.FC<CreateModalProps> = ({ isOpen, onClose, row, onSuccess }) => {
    // Initial state for the dynamic steps
    const [steps, setSteps] = useState<any[]>([
        { id: 1, dataCondition: '', dataAmount: '0', dataUnit: 'GB', dataStatus: '', followUpActions: [], thenAction: '', thenStatus: '', thenFeature: '', datePeriod: '', dataConditionId: '', dataStatusId: '', thenActionId: '', thenStatusId: '', thenFeatureId: '', datePeriodId: '', dataFeature: '', dataFeatureId: '' },
    ]);

    const [ruleName, setRuleName] = useState('');
    const [carrier, setCarrier] = useState<string>('');
    const [carrierId, setCarrierId] = useState<string>('');
    const [isActive, setIsActive] = useState(true);
    const [description, setDescription] = useState('');


    const [ruleConditionMap, setRuleConditionMap] = useState<any>([]);
    const [ruleActionMap, setRuleActionMap] = useState<any>([]);
    const [ruleStatusMap, setRuleStatusMap] = useState<any>([]);
    const [ruleDatePeriodMap, setRuleDatePeriodMap] = useState<any>([]);
    const [ruleProviderMap, setRuleProviderMap] = useState<any>([]);
    const [ruleFeatureMap, setRuleFeatureMap] = useState<any>([]);


    const { username, partner, role, token, selectedDb, metaData, settabledata,firstLastName,sessionId, } = useAuth();
    // Initialize state with empty arrays
    const [carrierOptions, setCarrierOptions] = useState<string[]>([]);
    const [dataConditionOptions, setDataConditionOptions] = useState<string[]>([]);
    const [dataUnitOptions, setDataUnitOptions] = useState<string[]>(['GB', 'MB', 'KB']);
    const [statusOptions, setStatusOptions] = useState<string[]>([]);
    const [actionOptions, setActionOptions] = useState<string[]>([]);
    const [featureOptions, setFeatureOptions] = useState<string[]>([]);
    const [datePeriodOptions, setDatePeriodOptions] = useState<string[]>([]);

    const [loading, setLoading] = useState(true);
    // Function to map string arrays to react-select's format
    const mapToSelectOptions = (options: string[]) =>
        options.map((option) => ({ value: option, label: option }));

    const refetchTableData = async () => {
        setLoading(true);
        settabledata([])
        try {
            const url = ENV_ROUTES.AUTOMATION_RULE;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_automation_rule_data",
                table: "automation_rule",
                role_name: role,
                module_name: "Automation rule",
                feature_module_name: "Automation",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ... metaData,
                sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const tableData_ = parsedData?.automation_rule_data || []
                settabledata(tableData_)
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);

        }
    };
    const [ruleNameError, setRuleNameError] = useState<string | null>(null);
    const [descriptionError, setDescriptionError] = useState<string | null>(null);
    console.log('row', row)
    const fetchData = async () => {
        try {
            setLoading(true);
            const url = ENV_ROUTES.AUTOMATION_RULE
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_automation_rule_create_pop_up_data",
                role_name: role,
                module_name: "Automation",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ... metaData,
                sessionID: sessionId,
                action: 'edit',
                automation_rule_id: row?.id || null
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const automation_rule_condition_dict = parsedData?.automation_rule_condition_dict || []
                setRuleConditionMap(automation_rule_condition_dict)
                const dataConditionOptions_ = automation_rule_condition_dict.map((item: any) => item.automation_rule_condition_name);
                setDataConditionOptions(dataConditionOptions_)

                const automation_rule_action_dict = parsedData?.automation_rule_action_dict || []
                setRuleActionMap(automation_rule_action_dict)
                const actionOptions_ = automation_rule_action_dict.map((item: any) => item.automation_rule_action_name);
                setActionOptions(actionOptions_)

                const automation_rule_followup_effective_date_type_dict = parsedData?.automation_rule_followup_effective_date_type_dict || []
                setRuleDatePeriodMap(automation_rule_followup_effective_date_type_dict)
                const datePeriodOptions_ = automation_rule_followup_effective_date_type_dict.map((item: any) => item.description);
                setDatePeriodOptions(datePeriodOptions_)

                const Has_Current_status_values = parsedData?.Has_Current_status_values || []
                setRuleStatusMap(Has_Current_status_values)
                const statusOptions_ = Has_Current_status_values.map((item: any) => item.display_name);
                setStatusOptions(statusOptions_)

                const service_provider_name_dict = parsedData?.service_provider_name_dict || []
                setRuleProviderMap(service_provider_name_dict)
                const carrierOptions_ = service_provider_name_dict.map((item: any) => item.service_provider_name);
                setCarrierOptions(carrierOptions_)

                const features_data = parsedData?.features_data || []
                setRuleFeatureMap(features_data)
                const featureOptions_ = features_data.map((item: any) => `${item.friendly_name} ${item.soc_code}`);
                setFeatureOptions(featureOptions_)

                const automation_rule_detail_data = parsedData?.automation_rule_detail_data || []
                const automation_rule_followup_details = parsedData?.automation_rule_followup_details || []


                const steps_ = transformToSteps(automation_rule_detail_data, automation_rule_followup_details, automation_rule_action_dict, Has_Current_status_values, automation_rule_condition_dict, features_data)
                setSteps(steps_)

                const ruleName_ = row?.automation_rule_name || ''
                const service_provider_name = row?.service_provider_name || ''
                const description_ = row?.description || ''

                setRuleName(ruleName_)
                setCarrier(service_provider_name)
                setDescription(description_)
                const object: any = service_provider_name_dict.find((item: any) => (
                    item.service_provider_name === service_provider_name
                ));
                const selectedId = object?.id || ''
                setCarrierId(selectedId)
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isOpen) {
            fetchData();
        }

    }, [isOpen]);

    // This function transforms your input data into the desired structure
    const transformData = (steps: any) => {
        // Mapping over the input data to reshape it
        const object: any = ruleDatePeriodMap.find((item: any) => (
            item.name === datePeriodOptions[0]
        ));
        const selectedId = object?.id || 1
        const blockDetails = steps.map((step: any, index: number) => {
            if (step.followUpActions.length>0) {
                return {
                    automation_rule_followup: {
                        rule_followup_effective_date_type_id: selectedId || 1,
                        description: description || '',
                        is_active: isActive,
                        created_by: row.created_by,
                        modified_by: firstLastName
                    },
                    automation_rule_followup_detail: step.followUpActions.map((action: any) => ({
                        rule_followup_id: '',
                        rule_action_id: action.actionId || '',
                        rule_action_value: action.action === 'Change Status' ? action.statusId : action.featureId,
                        is_active: isActive,
                        created_by: row.created_by,
                        modified_by: firstLastName
                    })),
                    automation_rule_detail: {
                        automation_rule_id: '',
                        rule_condition_id: step.dataConditionId || '',
                        rule_condition_value: step.dataCondition === 'Has Current Status' ?
                            step.dataStatusId :
                            step.dataCondition === 'Has feature' ? step.dataFeatureId
                                : `${step.dataAmount} ${step.dataUnit}`,
                        rule_action_id: step.thenActionId || '',
                        rule_action_value: step.thenAction === 'Change Status' ? step.thenStatusId : step.thenFeatureId,
                        condition_step: `${index + 1}`,
                        rule_followup_id: '',
                        is_active: isActive,
                        created_by: row.created_by,
                        modified_by: firstLastName
                    },
                };
            }
            else {
                return {
                    automation_rule_detail: {
                        automation_rule_id: '',
                        rule_condition_id: step.dataConditionId || '',
                        rule_condition_value: step.dataCondition === 'Has Current Status' ?
                            step.dataStatusId :
                            step.dataCondition === 'Has feature' ? step.dataFeatureId
                                : `${step.dataAmount} ${step.dataUnit}`,
                        rule_action_id: step.thenActionId || '',
                        rule_action_value: step.thenAction === 'Change Status' ? step.thenStatusId : step.thenFeatureId,
                        condition_step: `${index + 1}`,
                        rule_followup_id: '',
                        is_active: isActive,
                        created_by: row.created_by,
                        modified_by: firstLastName
                    },
                };
            }

        });

        // Return the complete transformed structure
          const formattedCreatedDate = dayjs(row.created_date).format('YYYY-MM-DD HH:mm:ss');
        return {
            automation_data: {
                automation_rule: {
                    automation_rule_name: ruleName,
                    service_provider_name: carrier,
                    service_provider_id: carrierId || '',
                    description: description,
                    is_active: isActive,
                    created_by: row.created_by,
                    created_date: formattedCreatedDate,
                    modified_by: firstLastName
                },
                block_details: blockDetails,
            },
        };
    };


    function transformToSteps(automationRuleDetailData: any[], automationRuleFollowupDetails: any[], ruleActionMap: any[], ruleStatusMap: any[], ruleConditionMap: any[], ruleFeatureMap: any[]) {
        return automationRuleDetailData.map((ruleDetail: any, ruleIndex: number) => {
            // Filter the follow-up actions that match the current step based on rule_followup_id
            const followUpActions = automationRuleFollowupDetails
                .filter((followup: any) => followup.rule_followup_id === ruleDetail.rule_followup_id)
                .map((followup: any, followupIndex: number) => {
                    const is_active = followup.is_active || false
                    setIsActive(is_active)
                    const actionObject: any = ruleActionMap.find((item: any) => followup.rule_action_id === item.id);
                    const selectedAction = actionObject?.automation_rule_action_name || '';
                    let selectedStatus, selectedStatusId, selectedFeature, selectedFeatureId
                    if (selectedAction === 'Change Status') {
                        const statusObject: any = ruleStatusMap.find((item: any) => (
                            followup.rule_action_value === (item.id).toString()
                        ));
                        selectedStatus = statusObject?.display_name || ''
                        selectedStatusId = statusObject?.id || ''
                        selectedFeature = ''
                        selectedFeatureId = ''
                    }
                    else {
                        const featureObject: any = ruleFeatureMap.find((item: any) => (
                            followup.rule_action_value === item.soc_code
                        ));
                        selectedFeature = `${featureObject?.friendly_name} ${featureObject?.soc_code}` || ''
                        selectedFeatureId = featureObject?.soc_code || ''
                        selectedStatus = ''
                        selectedStatusId = ''

                    }

                    return {
                        id: followupIndex, // Assuming the index can act as an ID
                        action: selectedAction,
                        status: selectedStatus,
                        feature: selectedFeature,
                        actionId: followup.rule_action_id || '',
                        statusId: selectedStatusId,
                        featureId: selectedFeatureId,
                    };
                });

            // Construct the step with its follow-up actions
            const conditionObject: any = ruleConditionMap.find((item: any) => ruleDetail.rule_condition_id === item.id);
            const selectedCondition = conditionObject?.automation_rule_condition_name || '';
            const selectedConditionId = conditionObject?.id || '';

            const actionObject: any = ruleActionMap.find((item: any) => ruleDetail.rule_action_id === item.id);
            const selectedAction = actionObject?.automation_rule_action_name || '';

            let selectedStatus, selectedStatusId, selectedFeature, selectedFeatureId
            if (selectedAction === 'Change Status') {
                const statusObject: any = ruleStatusMap.find((item: any) => (
                    ruleDetail.rule_action_value === (item.id).toString()
                ));
                selectedStatus = statusObject?.display_name || ''
                selectedStatusId = statusObject?.id || ''
                selectedFeature = ''
                selectedFeatureId = ''
            }
            else {
                const featureObject: any = ruleFeatureMap.find((item: any) => (
                    ruleDetail.rule_action_value === item.soc_code
                ));
                selectedFeature = `${featureObject?.friendly_name} ${featureObject?.soc_code}` || ''
                selectedFeatureId = featureObject?.soc_code || ''
                selectedStatus = ''
                selectedStatusId = ''

            }

            const conditionValue = ruleDetail.rule_condition_value
            let selectedAmount, selectedUnit, selectedDataStatus, selectedDataStatusId, selectedDataFeature, selectedDataFeatureId

            if (selectedCondition === "Has Current Status") {
                const statusObject: any = ruleStatusMap.find((item: any) => (
                    ruleDetail.rule_condition_value === (item.id).toString()
                ));
                selectedAmount = ''
                selectedUnit = ''
                selectedDataStatus = statusObject?.display_name || ''
                selectedDataStatusId = statusObject?.id || ''
                selectedDataFeature = ''
                selectedDataFeatureId = ''
            }
            else if (selectedCondition === "Has feature") {
                const featureObject: any = ruleFeatureMap.find((item: any) => (
                    ruleDetail.rule_condition_value === item.soc_code
                ));
                selectedAmount = ''
                selectedUnit = ''
                selectedDataStatus = ''
                selectedDataStatusId = ''
                selectedDataFeature = `${featureObject?.friendly_name} ${featureObject?.soc_code}` || ''
                selectedDataFeatureId = featureObject?.soc_code || ''
            }
            else {

                selectedAmount = conditionValue.split(' ')[0]
                selectedUnit = conditionValue.split(' ')[1]
                selectedDataStatus = ''
                selectedDataStatusId = ''
                selectedDataFeature = ''
                selectedDataFeatureId = ''
            }
            return {
                id: ruleIndex,
                dataCondition: selectedCondition,
                dataConditionId: selectedConditionId,
                thenStatus: selectedStatus,
                thenStatusId: selectedStatusId,
                thenFeature: selectedFeature,
                thenFeatureId: selectedFeatureId,
                thenAction: selectedAction,
                thenActionId: ruleDetail.rule_action_id || '',
                datePeriod: '',
                datePeriodId: '',
                dataAmount: selectedAmount,
                dataUnit: selectedUnit,
                dataStatus: selectedDataStatus,
                dataStatusId: selectedDataStatusId,
                dataFeature: selectedDataFeature,
                dataFeatureId: selectedDataFeatureId,
                followUpActions: followUpActions,

            };
        });
    }

    const callRunDBScript = async () => {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/run_db_script",
          role_name: role,
          module_name: "Automation",
          access_token: token,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          update_flag: true,
          delete_flag: false,
          request_received_at: getCurrentDateTime(),
          Partner: partner || "default_value",
          data: {
            input_data: [{
                automation_data:{
                    id:row?.id || ''
                }
            }]
          },
        };
    
        try {
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
        } catch (error) {
        }
    
      }
    

    const callLambdaSync = async () => {
        const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
        const data = {
          path: "/lambda_sync_jobs_",
          key_name: "automation_reverse_sync",
          tenant_name:partner
        };
    
        try {
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
        } catch (error) {
        }
    
      }

    const submitData = async () => {
        const created_data = transformData(steps)
        try {
            setLoading(true);
            const url = ENV_ROUTES.AUTOMATION_RULE;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/insert_automation_data",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ... metaData,
                sessionID: sessionId,
                automation_rule_id: row?.id || '',
                action: 'edit',
                data: created_data
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                if(parsedData.error_type && parsedData.error_type=="Warning"){
                          console.log("parsedData.error_type",parsedData.error_type)
                          Modal.warning({
                            title: 'Warning',
                            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                            centered: true,
                          });
                        }
                        else{
                          Modal.error({
                            title: "Submit Error",
                            content:
                              parsedData.message ||
                              "An error occurred while submitting data. Please try again.",
                            centered: true,
                          });
                        }
            } else {
                setLoading(false);
                onSuccess()
                refetchTableData()
                notification.success({
                    message: 'Success',
                    description: 'Successfully saved.',
                    style: messageStyle,
                    placement: 'top',
                });
                fireSideCannons();
                await callRunDBScript()
                await callLambdaSync()
            }
        } catch (error) {
            Modal.error({
                title: "Data Fetch Error",
                content:
                    error instanceof Error
                        ? error.message
                        : "An unexpected error occurred while submitting data. Please try again.",
                centered: true,
            });
        }
        finally {
            // refetchTableData()
            handleCancel()
        }
    };

    // Add a new step
    // const addStep = () => {
    //     if (steps.length < 3) {
    //         const newId = steps.length + 1;
    //         setSteps([...steps, { id: newId, dataCondition: '', dataAmount: '0', dataUnit: 'GB', dataStatus: '', followUpActions: [], thenAction: '', thenStatus: '', thenFeature: '', datePeriod: '', dataConditionId: '', dataStatusId: '', thenActionId: '', thenStatusId: '', thenFeatureId: '', datePeriodId: '' }]);
    //     }
    // };
    const addStep = () => {
        if (steps.length < 3) {
          const dataCondition_ = dataConditionOptions.length > 0 ? dataConditionOptions[0] : ''
          const thenFeature_ = featureOptions.length > 0 ? featureOptions[0] : ''
          const thenAction_ = actionOptions.length > 0 ? actionOptions[0] : ''
          const thenStatus_ = statusOptions.length > 0 ? statusOptions[0] : ''
          const dataStatus_ = statusOptions.length > 0 ? statusOptions[0] : ''
          const datePeriod_ = datePeriodOptions.length > 0 ? datePeriodOptions[0] : ''
    
          const conditionObject: any = ruleConditionMap.find((item: any) => (
            item.automation_rule_condition_name === dataCondition_
          ));
          const conditionId = conditionObject?.id || ''
    
          const actionObject: any = ruleActionMap.find((item: any) => (
            item.automation_rule_action_name === thenAction_
          ));
          const actionId_ = actionObject?.id || ''
    
          const statusObject: any = ruleStatusMap.find((item: any) => (
            item.display_name === thenStatus_
          ));
          const statusId_ = statusObject?.id || ''
    
          const featureObject: any = ruleFeatureMap.find((item: any) => (
            `${item.friendly_name} ${item.soc_code}` === thenFeature_
          ));
          const featureId_ = featureObject?.soc_code || ''
    
          const datePeriodObject: any = ruleDatePeriodMap.find((item: any) => (
            item.description === datePeriod_
          ));
          const datePeriodId_ = datePeriodObject?.id || ''
    
          const newId = steps.length + 1;
          setSteps([...steps, { id: newId, dataCondition: dataCondition_, dataAmount: '0', dataUnit: 'GB', dataStatus: dataStatus_, followUpActions: [], thenAction: thenAction_, thenStatus: thenStatus_, thenFeature: thenFeature_, datePeriod: datePeriod_, dataConditionId: conditionId, dataStatusId: statusId_, thenActionId: actionId_, thenStatusId: statusId_, thenFeatureId: featureId_, datePeriodId: datePeriodId_, dataFeature: thenFeature_, dataFeatureId: featureId_ }]);
        }
      };


    // Remove a step
    const removeStep = (id: number) => {
        if (steps.length > 1) {
            setSteps(steps.filter((step) => step.id !== id));
        }
    };
    
    // const addFollowUpAction = (stepId: number) => {
    //     setSteps(
    //         steps.map((step: any) =>
    //             step.id === stepId
    //                 ? {
    //                     ...step,
    //                     followUpActions: [
    //                         ...step.followUpActions,
    //                         { id: step.followUpActions.length + 1, action: '', status: '', feature: '', actionId: '', statusId: '', featureId: '' },
    //                     ],
    //                 }
    //                 : step
    //         )
    //     );
    // };

    const addFollowUpAction = (stepId: number) => {
        const feature_ = featureOptions.length > 0 ? featureOptions[0] : ''
        const action_ = actionOptions.length > 0 ? actionOptions[0] : ''
        const status_ = statusOptions.length > 0 ? statusOptions[0] : ''
    
        const actionObject: any = ruleActionMap.find((item: any) => (
          item.automation_rule_action_name === action_
        ));
        const actionId_ = actionObject?.id || ''
    
        const statusObject: any = ruleStatusMap.find((item: any) => (
          item.display_name === status_
        ));
        const statusId_ = statusObject?.id || ''
    
        const featureObject: any = ruleFeatureMap.find((item: any) => (
          `${item.friendly_name} ${item.soc_code}` === feature_
        ));
        const featureId_ = featureObject?.soc_code || ''
    
        setSteps(
          steps.map((step: any) =>
            step.id === stepId
              ? {
                ...step,
                followUpActions: [
                  ...step.followUpActions,
                  { id: step.followUpActions.length + 1, action: action_, status: status_, feature: feature_, actionId: actionId_, statusId: statusId_, featureId: featureId_ },
                ],
              }
              : step
          )
        );
      };
      
    const removeLastFollowUpAction = (stepId: number) => {
        setSteps(
            steps.map((step: any) =>
                step.id === stepId
                    ? {
                        ...step,
                        followUpActions: step.followUpActions.slice(0, -1), // Remove the last follow-up action
                    }
                    : step
            )
        );
    };

    // Handle change for follow-up action dropdowns
    const handleFollowUpActionChange = (stepId: number, actionId: number, field: string, value: string) => {
        let changedData: any;
        if (field === 'action') {
            const object: any = ruleActionMap.find((item: any) => (
                item.automation_rule_action_name === value
            ));
            const selectedId = object?.id || ''
            changedData = { action: value, actionId: selectedId }
        }
        if (field === 'status') {
            const object: any = ruleStatusMap.find((item: any) => (
                item.display_name === value
            ));
            const selectedId = object?.id || ''
            changedData = { status: value, statusId: selectedId }
        }
        if (field === 'feature') {
            const object: any = ruleFeatureMap.find((item: any) => (
                `${item.friendly_name} ${item.soc_code}` === value
            ));
            const selectedId = object?.soc_code || ''
            changedData = { feature: value, featureId: selectedId }
        }
        setSteps(
            steps.map((step: any) =>
                step.id === stepId
                    ? {
                        ...step,
                        followUpActions: step.followUpActions.map((action: any) =>
                            action.id === actionId ? { ...action, ...changedData } : action
                        ),
                    }
                    : step
            )
        );

    };
    // Handle change for dataLimitStatus
    const handleDataConditionChange = (id: number, value: string) => {
        const object: any = ruleConditionMap.find((item: any) => (
            item.automation_rule_condition_name === value
        ));
        const selectedId = object?.id || ''
        setSteps(steps.map((step) => (step.id === id ? { ...step, dataCondition: value, dataConditionId: selectedId } : step)));
    };

    // Handle change for dataAmount
    const handleDataAmountChange = (id: number, value: string) => {
        setSteps(steps.map((step) => (step.id === id ? { ...step, dataAmount: value } : step)));
    };

    // Handle change for dataUnit
    const handleDataUnitChange = (id: number, value: string) => {
        setSteps(steps.map((step) => (step.id === id ? { ...step, dataUnit: value } : step)));
    };
    const handleDataStatusChange = (id: number, value: string) => {
        const object: any = ruleStatusMap.find((item: any) => (
            item.display_name === value
        ));
        const selectedId = object?.id || ''
        setSteps(steps.map((step) => (step.id === id ? { ...step, dataStatus: value, dataStatusId: selectedId } : step)));
    };
    const handleDataFeatureChange = (id: number, value: string) => {
        const object: any = ruleFeatureMap.find((item: any) => (
          `${item.friendly_name} ${item.soc_code}` === value
        ));
        const selectedId = object?.soc_code || ''
        setSteps(steps.map((step) => (step.id === id ? { ...step, dataFeature: value, dataFeatureId: selectedId } : step)));
      };
    const handleThenActionChange = (id: number, value: string) => {
        const object: any = ruleActionMap.find((item: any) => (
            item.automation_rule_action_name === value
        ));
        const selectedId = object?.id || ''
        setSteps(steps.map((step) => (step.id === id ? { ...step, thenAction: value, thenActionId: selectedId } : step)));
    };
    const handleThenStatusChange = (id: number, value: string) => {
        const object: any = ruleStatusMap.find((item: any) => (
            item.display_name === value
        ));
        const selectedId = object?.id || ''
        setSteps(steps.map((step) => (step.id === id ? { ...step, thenStatus: value, thenStatusId: selectedId } : step)));
    };
    const handleThenFeatureChange = (id: number, value: string) => {
        const object: any = ruleFeatureMap.find((item: any) => (
            `${item.friendly_name} ${item.soc_code}` === value
        ));
        const selectedId = object?.soc_code || ''
        setSteps(steps.map((step) => (step.id === id ? { ...step, thenFeature: value, thenFeatureId: selectedId } : step)));
    };
    const handleDatePeriodChange = (id: number, value: string) => {
        const object: any = ruleDatePeriodMap.find((item: any) => (
            item.name === value
        ));
        const selectedId = object?.id || ''
        setSteps(steps.map((step) => (step.id === id ? { ...step, datePeriod: value, datePeriodId: selectedId } : step)));
    };
    // Handle carrier change
    const handleCarrierChange = (value: string) => {
        const object: any = ruleProviderMap.find((item: any) => (
            item.service_provider_name === value
        ));
        const selectedId = object?.id || ''
        setCarrier(value);
        setCarrierId(selectedId)
    };

    const cleadrFields = () => {
        setRuleNameError(null)
        setDescriptionError(null)
    };

    // Handle saving
    const handleSave = () => {
        let isValid = true;
        if (!ruleName) {
            setRuleNameError("Rule name is required.");
            isValid = false;
        }
        else {
            setRuleNameError("");
        }
        if (!description) {
            setDescriptionError("Description is required.")
            isValid = false;
        }
        else {
            setDescriptionError("")
        }
        if (isValid) {
            submitData();
        }
    };

    const handleCancel = () => {
        cleadrFields()
        onClose(); // Close the modal
    };

   const multiplyFactor= (typeof window !== "undefined" && window.innerWidth < 700) ? 3.5 :2.5
   const modalWidth =
    typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;

    return (
        <Modal
            visible={isOpen}
            onCancel={handleCancel}
            title="Edit Automation"
            width={modalWidth}
            styles={{ body: { height: modalHeight, padding: "4px" } }}
            footer={[
                <div className='flex justify-center space-x-2.5' key="footer">
                    <button key="cancel" className="cancel-btn" onClick={handleCancel}>
                        Cancel
                    </button>
                    <button key="save" className="save-btn" onClick={handleSave}>
                        Save
                    </button>
                </div>
            ]}
        >
            <>
                {loading ? (
                    <div className="flex justify-center items-center h-full">
                        <Spin size="large" />
                    </div>
                ) : (
                    <div className='popup'>
                        <div className='mb-4'>
                            <div className='flex flex-col md:flex-row md:space-x-8 mb-4'>
                                {/* Rule Name Label and Input */}
                                <div className=''>
                                    <label className='field-label'>Rule Name<span className='text-red-500'>*</span></label>
                                    <Input
                                        value={ruleName}
                                        onChange={(e) => setRuleName(e.target.value)}
                                        placeholder="Enter Rule Name"
                                        className="input"
                                    />
                                    {ruleNameError && (
                                        <p className="text-red-500 text-sm">{ruleNameError}</p>
                                    )}
                                </div>

                                {/* Carrier Label and Dropdown */}
                                <div className=''>
                                    <label className='field-label'>Carrier</label>
                                    <Select
                                        value={{ value: carrier, label: carrier }}
                                        onChange={(selectedOption) => handleCarrierChange(selectedOption?.value || '')}
                                        options={mapToSelectOptions(carrierOptions)}
                                        placeholder="Select Carrier"
                                        styles={DropdownStyles}
                                        className='md:w-[320px]'
                                    />
                                </div>

                                {/* Active/Inactive Switch */}
                                <div>
                                    <label className="field-label">Status</label>
                                    <div className="flex items-center mt-2">
                                        <Switch
                                            checked={isActive}
                                            onChange={(checked) => setIsActive(checked)}
                                            className="scale-[0.8] md:scale-[1.3]"
                                        />
                                        <span className="font-semibold ml:2 md:ml-4 toggle-span">{isActive ? 'Active' : 'Inactive'}</span>
                                    </div>
                                </div>
                            </div>

                            {/* Description Label and Text Area */}
                            <div className='mb-6'>
                                <label className='field-label'>Description<span className='text-red-500'>*</span></label>
                                <Input.TextArea
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    placeholder="Enter description"
                                    className='w-full'
                                    rows={4}
                                />
                                {descriptionError && (
                                    <p className="text-red-500 text-sm">{descriptionError}</p>
                                )}
                            </div>
                        </div>



                        {steps.map((step, index) => (
                            <div key={step.id} className='border border-gray-300 p-2.5 mb-5 rounded-md'>
                                <div key={step.id}>
                                    <>
                                        <h1 className="font-semibold">{index === 0 ? 'When this happens' : 'And'}</h1>
                                        <div
                                            key={step.id}
                                            className='border border-gray-300 rounded-md bg-[#F4F7FA] p-4 mt-2 automation-step-div'
                                        >

                                            <div className='flex flex-col md:flex-row space-y-4 md:space-y-0 md:gap-4 items-normal md:items-center'>
                                                <span>If any SIM </span>
                                                <Select
                                                    value={{ value: step.dataCondition, label: step.dataCondition }}
                                                    onChange={(selectedOption) => handleDataConditionChange(step.id, selectedOption?.value || '')}
                                                    options={mapToSelectOptions(dataConditionOptions)}
                                                    placeholder="Select Status"
                                                    styles={DropdownStyles}
                                                    className='md:w-[200px]'
                                                />
                                                {step.dataCondition === "Has Current Status" ? (
                                                    <div>
                                                        <Select
                                                            value={{ value: step.dataStatus, label: step.dataStatus }}
                                                            onChange={(selectedOption) => handleDataStatusChange(step.id, selectedOption?.value || '')}
                                                            options={mapToSelectOptions(statusOptions)}
                                                            placeholder="Select Unit"
                                                            styles={DropdownStyles}
                                                            className='md:w-[200px]'
                                                        />
                                                    </div>
                                                ) : step.dataCondition === "Has feature" ? (
                                                    <Select
                                                        value={{ value: step.dataFeature, label: step.dataFeature }}
                                                        onChange={(selectedOption) =>
                                                            handleDataFeatureChange(step.id, selectedOption?.value || '')
                                                        }
                                                        options={mapToSelectOptions(featureOptions)}
                                                        placeholder="Select Feature"
                                                        styles={DropdownStyles}
                                                        className='md:w-[300px]'
                                                    />
                                                ) : (
                                                    <div className='flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4'>
                                                        <Input
                                                            placeholder="Amount"
                                                            type="number"
                                                            value={step.dataAmount || ''}
                                                            onChange={(e) => handleDataAmountChange(step.id, e.target.value)}
                                                            className=" md:w-[150px]"
                                                        />

                                                        <Select
                                                            value={{ value: step.dataUnit, label: step.dataUnit }}
                                                            onChange={(selectedOption) => handleDataUnitChange(step.id, selectedOption?.value || '')}
                                                            options={mapToSelectOptions(dataUnitOptions)}
                                                            placeholder="Select Unit"
                                                            styles={DropdownStyles}
                                                            className='md:w-[200px]'
                                                        />
                                                    </div>
                                                )}


                                            </div>
                                        </div>
                                    </>
                                    <>
                                        <h1 className="font-semibold mt-2">Then</h1>
                                        <div
                                            key={step.id}
                                            className='border border-gray-300 rounded-md bg-[#F4F7FA] p-4 mt-2 automation-step-div'
                                        >
                                            <div key={step.id} className='flex flex-col md:flex-row space-y-4 md:space-y-0 md:gap-4 items-normal md:items-center mb-4'>
                                                <Select
                                                    value={{ value: step.thenAction, label: step.thenAction }}
                                                    onChange={(selectedOption) =>
                                                        handleThenActionChange(step.id, selectedOption?.value || '')
                                                    }
                                                    options={mapToSelectOptions(actionOptions)} // Add real action options here
                                                    placeholder="Select Action"
                                                    styles={DropdownStyles}
                                                    className='md:w-[200px]'
                                                />
                                                {step.thenAction === "Change Status" ? (

                                                    <Select
                                                        value={{ value: step.thenStatus, label: step.thenStatus }}
                                                        onChange={(selectedOption) =>
                                                            handleThenStatusChange(step.id, selectedOption?.value || '')
                                                        }
                                                        options={mapToSelectOptions(statusOptions)}
                                                        placeholder="Select Status"
                                                        styles={DropdownStyles}
                                                        className='md:w-[200px]'
                                                    />
                                                ) : (
                                                    <Select
                                                        value={{ value: step.thenFeature, label: step.thenFeature }}
                                                        onChange={(selectedOption) =>
                                                            handleThenFeatureChange(step.id, selectedOption?.value || '')
                                                        }
                                                        options={mapToSelectOptions(featureOptions)}
                                                        placeholder="Select Feature"
                                                        styles={DropdownStyles}
                                                        className='md:w-[300px]'
                                                    />
                                                )}

                                            </div>
                                            {step.followUpActions.map((action: any, actionIndex: any) => (
                                                <>
                                                    <h1 className="font-semibold mb-2">{actionIndex === 0 ? 'Follow up with' : 'And'}</h1>
                                                    <div key={action.id} className='flex flex-col md:flex-row space-y-4 md:space-y-0 md:gap-4 items-normal md:items-center mb-4'>
                                                        <Select
                                                            value={{ value: action.action, label: action.action }}
                                                            onChange={(selectedOption) =>
                                                                handleFollowUpActionChange(step.id, action.id, 'action', selectedOption?.value || '')
                                                            }
                                                            options={mapToSelectOptions(actionOptions)} // Add real action options here
                                                            placeholder="Select Action"
                                                            styles={DropdownStyles}
                                                            className='md:w-[200px]'
                                                        />
                                                        {action.action === "Change Status" ? (
                                                            <Select
                                                                value={{ value: action.status, label: action.status }}
                                                                onChange={(selectedOption) =>
                                                                    handleFollowUpActionChange(step.id, action.id, 'status', selectedOption?.value || '')
                                                                }
                                                                options={mapToSelectOptions(statusOptions)}
                                                                placeholder="Select Status"
                                                                styles={DropdownStyles}
                                                                className='md:w-[200px]'
                                                            />
                                                        ) : (
                                                            <Select
                                                                value={{ value: action.feature, label: action.feature }}
                                                                onChange={(selectedOption) =>
                                                                    handleFollowUpActionChange(step.id, action.id, 'feature', selectedOption?.value || '')
                                                                }
                                                                options={mapToSelectOptions(featureOptions)}
                                                                placeholder="Select Feature"
                                                                styles={DropdownStyles}
                                                                className='md:w-[300px]'
                                                            />
                                                        )}


                                                    </div>
                                                </>
                                            ))}
                                            {/* Show remove button only for the last follow-up block */}
                                            <div className='flex flex-col md:flex-row space-x-4'>
                                                {step.followUpActions.length < 3 && (
                                                    <button onClick={() => addFollowUpAction(step.id)} className="text-blue-500 hover:text-green-500 automation-step-btns">
                                                        + Add Follow up Action
                                                    </button>
                                                )}
                                                {step.followUpActions.length > 1 && (
                                                    <button onClick={() => removeLastFollowUpAction(step.id)} className="text-blue-500 hover:text-red-500">
                                                        - Remove Follow up Action
                                                    </button>
                                                )}


                                            </div>
                                            {step.followUpActions.length > 0 && (
                                                <div>
                                                    <h1 className="font-semibold my-2">Only When</h1>
                                                    <Select
                                                        // value={{ value: step.datePeriod, label: step.datePeriod }}
                                                        value={{ value: datePeriodOptions[0], label: datePeriodOptions[0] }}
                                                        onChange={(selectedOption) =>
                                                            handleDatePeriodChange(step.id, selectedOption?.value || '')
                                                        }
                                                        options={mapToSelectOptions(datePeriodOptions)}
                                                        placeholder="Select Feature"
                                                        styles={DropdownStyles}
                                                        className='md:w-[300px]'
                                                    />
                                                </div>

                                            )}

                                            <div className='flex items-center gap-4'>

                                            </div>
                                        </div></>
                                </div>
                            </div>
                        ))}


                        <div className='flex justify-start gap-2.5'>
                            {steps.length < 3 && (
                                <button onClick={addStep} className="text-blue-500 hover:text-green-500 automation-step-btns">
                                    + Add Step
                                </button>
                            )}
                            {steps.length > 1 && (
                                <button onClick={() => removeStep(steps[steps.length - 1].id)} className="text-blue-500 hover:text-red-500 automation-step-btns">
                                    - Remove Step
                                </button>
                            )}
                        </div>
                    </div>
                )}

            </>
        </Modal>
    );
};

export default EditAutomation;
