import React from 'react';
import { Row, Col, Input } from 'antd';

interface StatusDetailsProps {
  isOpen: boolean;
  onClose: () => void;
  row: any;
}

const StatusDetails: React.FC<StatusDetailsProps> = ({ row }) => {
  return (
    <div className=''>
      <Row gutter={[16, 16]}>
        <Col xs={24} sm={24} md={12}>
          <label>ICCID</label>
          <Input
            value={row?.sim || ''}
            className='non-editable-input'
          />
        </Col>

        <Col xs={24} sm={24} md={12}>
          <label>Status</label>
          <Input
            value={row?.status || ''}
            className='non-editable-input'

          />
        </Col>

        <Col xs={24} sm={24} md={12}>
          <label>Request</label>
          <Input.TextArea
            rows={8}
            value={
              row?.request_body|| ''
            }
            className='non-editable-input'
          />
        </Col>

        <Col xs={24} sm={24} md={12}>
          <label>Response</label>
          <Input.TextArea
            rows={8}
            value={
              row?.response_body || ''
            }
            className='non-editable-input'
          />
        </Col>
      </Row>
    </div>
  );
};

export default StatusDetails;
