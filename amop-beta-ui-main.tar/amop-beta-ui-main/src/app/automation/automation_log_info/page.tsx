"use client";
import React, { useEffect, useState, lazy, Suspense } from 'react';
// import dynamic from 'next/dynamic';
import { useSidebarStore } from '@/app/stores/navBarStore';
import { useLogoStore } from "@/app/stores/logoStore";
import { Modal, Spin } from 'antd';


const RuleDetails = lazy(() => import('./rule_details'));
const StatusDetails = lazy(() => import('./status_details'));

interface InfoProps {
  isOpen: boolean;
  onClose: () => void;
  row:any
}

const AutomationInfo: React.FC<InfoProps> = ({ isOpen, onClose ,row}) => {
  const [activeTab, setActiveTab] = useState('rule');
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);

  const [loading, setLoading] = useState(false); // State to manage loading


  const multiplyFactor= (typeof window !== "undefined" && window.innerWidth < 700) ? 3.5 :2.5
  const modalWidth =
    typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;

  return (
    <Modal
    visible={isOpen}
    onCancel={onClose}
    title="Automation Log Details"
    width={modalWidth}
    styles={{ body: { height: modalHeight, padding: "4px" } }}
    footer={[
      <div className='flex justify-end space-x-2.5' key="footer">
        <button key="cancel" className="save-btn" onClick={onClose}>
          Ok
        </button>
      </div>
    ]}
  >
    <>
      {loading ? (
        <div className="flex justify-center items-center h-full">
          <Spin size="large" />
        </div>
      ) : (
        <div className='popup'>
          <div className="">
        <div className={`bg-white shadow-md mb-4 gap-4 sticky tabs-color`}>


          <button
            className={`tab-headings ${activeTab === 'rule' ? 'active-tab-heading' : ''}`}
            onClick={() => setActiveTab('rule')}
          >
            Rule Details
          </button>
          <button
            className={`tab-headings ${activeTab === 'status' ? 'active-tab-heading' : ''}`}
            onClick={() => setActiveTab('status')}
          >
            Status Details
          </button>


        </div>
        <div className="container">
          {activeTab === 'rule' && <RuleDetails isOpen={isOpen} onClose={onClose} row={row}/>}
          {activeTab === 'status' && <StatusDetails isOpen={isOpen} onClose={onClose} row={row}/>}


        </div>
      </div>
        </div>
      )}

    </>
  </Modal>
  );
};

export default AutomationInfo;

