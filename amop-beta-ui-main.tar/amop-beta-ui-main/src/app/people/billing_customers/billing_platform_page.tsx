"use client";

import React, { useEffect, useState, useCallback, useRef } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  ArrowUpTrayIcon,
} from "@heroicons/react/24/outline";
import TableComponent from "@/app/components/TableComponent/page";
import CreateModal from "@/app/components/createPopup";
import ColumnFilter from "@/app/components/columnfilter";
import { usePartnerStore } from "@/app/partner/partner_info/partnerStore";
import {
  Button,
  DatePicker,
  Modal,
  notification,
  message,
  Upload,
  Spin,
} from "antd";
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import TableSearch from "@/app/components/entire_table_search";
import AdvancedMultiFilter from "@/app/components/advanced_search";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";

const { RangePicker } = DatePicker;

interface ExcelData {
  [key: string]: any;
}

type HeaderMap = Record<string, [string, number]>;

const BillingFormPage: React.FC = () => {
  const [data, setData] = useState<ExcelData[]>([]);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<any>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, selectedDb, metaData,advancedStoredpagination, storedpagination, tenantId, tenantName, firstLastName,sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns} = useAuth();
  const [headers, setHeaders] = useState<string[]>([]);
  const [headerMap, setHeadersMap] = useState<HeaderMap>({});
  const [createModalData, setCreateModalData] = useState<any[]>([]);
  const [generalFields, setGeneralFields] = useState<any>({});
  const [filteredData, setFilteredData] = useState([]);
  const [pagination, setPagination] = useState<any>({});
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [loading, setLoading] = useState(true);
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  //export functionality
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport,exports } = exportLoadingStore();
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const hasFetchedData = useRef(false);
  
  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a?.[1][1] - b?.[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  };

 

  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Billing Customers":visibleColumns}))
      }, [visibleColumns]);
 useEffect(() => {
    if (!hasFetchedData.current) { // Check if data has already been fetched
      fetchData();
      hasFetchedData.current = true; // Set to true after fetching
    }
  }, [])

  const handleFilter = (advancedFilters: any) => {
    // setFilteredData(advancedFilters);
    setAdvancedFilters(advancedFilters)
    
  };

  const handleReset = (EmptyFilters: any) => {
    setFilteredData(EmptyFilters);
  };

  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };


  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
    setNewRowData({});
  };

  const handleCreateRow = (newRow: any,tableData:any) => {
    // console.log("New Row Data:", newRow,tableData);
    // const updatedData = [...data, newRow];
    handleCreateModalClose();
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    setDateRange([null, null]); // Reset date range
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        // parent_module: "Partner",
        module_name: "Billing Customers Export",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
       // removeExport(exportKey); // Remove the export from the store
    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
  const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
  const export_data = {
    tenant_name: partner || "default_value",
    username,
    path: "/get_export_status",
    role_name: role,
    // parent_module: "Partner",
    module_name:"Billing Customers Export",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    ... metaData,
    sessionID: sessionId,
  };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Billing Customers.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };
  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

  const handleExport = async (key:string, heading:string) => {
    try {
      // setExportLoading(true)
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          module_name: "Billing Customers",
          index_name: "Billing Customers",
        }
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
     else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Billing Customers",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Billing Customers",
          pages: {
            start: 0,
            end: 100
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Billing Customers",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Billing Customers",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        // ExportWithoutSearch()
        await ExportWithoutSearch();
        return;
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        // if (parsedData.flag === true) {
        //   const s3Url = parsedData?.download_url || null;
        //   if (s3Url) {
        //     window.location.href = s3Url;
        //     setExportLoading(false)
        //     notification.success({
        //       message: 'Success',
        //       description: 'Successfully exported the record!',
        //       style: messageStyle,
        //       placement: 'top',
        //     });
        //   }
        //   else {
        //     setExportLoading(false)
        //     Modal.error({
        //       title: "Export Error",
        //       content: parsedData.message || "An error occurred while exporting data. Please try again.",
        //       centered: true,
        //     });
        //   }


        if (parsedData.flag) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // notification.success({
            //   message: "Success",
            //   description: "Successfully exported the  record!",
            //   style: messageStyle,
            //   placement: "top",
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Billing Customers.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          }

        } else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      
    } else {
      Modal.error({
        title: "Export Error",
        content: parsedData.message || "An error occurred while exporting data. Please try again.",
        centered: true,
      });
    }

    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
  const fetchData = async (selectedOption: string | number = "all") => {
    const bp_status = localStorage.getItem('bp_flag');
    // console.log("billingPlatformStatus",bp_status)
    setCombineAdnvaceStoredpagination(null)
    setLoading(true)
    try {
      const url =ENV_ROUTES.PEOPLE_MODULE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path:  "/get_billing_platform_customer_list_view_data",
        role_name: role,
        parent_module: "People",
        module_name: "Billing Customers",
        feature_module_name:"Billing Customers",
        mod_pages: {
          start: 0,
          end: 100,
        },
        // dropdown_options: { label: filterOptions.find(option => option.value === selectedOption)?.label || "All", value: selectedOption },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching Billing customers data. Please try again.',
          centered: true,
        });
      } else {
        const tableData_ = parsedData.data;
        const headerMap = parsedData.headers_map["Billing Customers"]["header_map"]
        const features =parsedData.headers_map["Billing Customers"]["module_features"] 
        setFeatures(features)
        // const allowedActions_:any=[]
        // if(features.includes("Info-Billing customers")){
        //   allowedActions_.push("info")
        // }
        // if(features.includes("Edit-Billing customers")){
        //   allowedActions_.push("edit")
        // }
        // setAllowedActions(allowedActions_)
        const createModalData = parsedData.headers_map["Billing Customers"]["pop_up"] 
        const sortedheaderMap = sortHeaderMap(headerMap)
        const generalFields = parsedData
        const pagination_ = parsedData.pages
        // const filteredData_ = parsedData.dropdown_options
        // console.log(filteredData_,"Show the filtered data");
        // setIsFilteredTableData(filteredData_)
        // setFilterOptions([
        //   { label: "All", value: "all" },
        //   ...filteredData_.map((option: any) => ({
        //     label: option.label,
        //     value: option.value
        //   }))
        // ].filter((option, index, self) => 
        //   index === self.findIndex((t) => t.label === option.label && t.value === option.value)
        // ));
        setPagination(pagination_)
        setGeneralFields(generalFields)
        setHeadersMap(headerMap)
        setCreateModalData(createModalData)
        setTableData(tableData_);
        settabledata(tableData_)
         const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
                setHeaders(headers_)
               const dynamic_cols=dynamicColumns?.["Billing Customers"] && dynamicColumns["Billing Customers"].length>0 ?dynamicColumns["Billing Customers"] :headers_ || headers_
               setVisibleColumns(dynamic_cols)
        setLoading(false)
        // setServiceProviderList([
        //   { label: "All", value: "all" },
        //   ...filteredData_.map((option: any) => ({
        //     label: option.label,
        //     value: option.value
        //   }))
        // ].filter((option, index, self) => 
        //   index === self.findIndex((t) => t.label === option.label && t.value === option.value)
        // ));

      }

    } catch (error) {

      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false); // Ensure loading is set to false in the finally block
    }
  };
 
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day");
  };
 if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <div className="relative">
      <div>
      <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
          {features.includes("Search-Billing customers") && (
            <TableSearch
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              tableName={"Billing Customers"}
              headerMap={headerMap}
            />
          )}
          {features.includes("Advanced filter-Billing customers") && (
            <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"Billing Customers"}
            />
          )}
          </div>

          {/* Export and ColumnFilter Container */}
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
          {features.includes("Create-Billing customers") &&  (
            <button className="save-btn" onClick={handleCreateModalOpen}>
              <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
              Create
            </button>
          )}
          
            {features.includes("Export-Billing customers") &&  (
            <button className="save-btn"
            onClick={() => {
              if (!exports.some((exportItem) => exportItem.popupHeading === "Billing Customers")) {
                handleExport("Billing Customers", "Billing Customers");
              }
            }}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              <span>Export</span>
            </button>
            )}
             
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
        <div className=" mb-4 space-x-2"></div>
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={data}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            popupHeading="Billing Customers"
            createModalData={createModalData}
            generalFields={generalFields}
            pagination={pagination || {}}
            advancedFilters={filteredData}
            height = {showAdvanced?300:240}
          />
        </div>
        <CreateModal
          isOpen={isCreateModalOpen}
          onClose={handleCreateModalClose}
          onSave={handleCreateRow}
          columnNames={createModalData}
          heading="Customer"
          header={data.length > 0 ? Object.keys(data[0]) : []}
          generalFields={generalFields}
        />
        {/* Sticky Footer for Small Screens */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
        {features.includes("Create-Billing Customers") && (
            <button className="save-btn" onClick={handleCreateModalOpen}>
              <PlusIcon className="h-5 w-5 text-black-500" />
            </button>
          )}
          
           {features.includes("Export-Billing Customers") && (
            <button className="save-btn"
            onClick={() => {
              if (!exports.some((exportItem) => exportItem.popupHeading === "Billing Customers")) {
                handleExport("BillingPlatformCustomers", "Billing Customers");
              }
            }}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 " />
            </button>
            )}  
             <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />                                      
        </div>   
        <Modal
          title={
            <span className="font-semibold text-xl space-y-3">
              Export Output
            </span>
          }
          visible={isExportModalOpen}
          onCancel={() => {
            handleExportModalClose();
            setDateRange([null, null]);
          }}
          footer={null}
          centered
          afterClose={() => setDateRange([null, null])}
          style={{ top: "-4%" }}
        >
          <div className="flex flex-col space-y-4">
            <span>Select Date Range</span>
            <RangePicker
              value={
                dateRange[0] && dateRange[1]
                  ? [dateRange[0], dateRange[1]]
                  : null
              } // Bind the date range
              onChange={(dates) => {
                console.log("Selected dates:", dates); // Debug log
                if (dates && dates.length === 2) {
                  setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                } else {
                  setDateRange([null, null]); // Reset to null if dates are not both available
                }
              }}
              format="YYYY-MM-DD"
              disabledDate={disableFutureDates}
              popupClassName="custom-range-popup"
            />
            <div
              style={{ marginTop: "2rem" }}
              className="flex  justify-center gap-2 space-x-2"
            >
              <button
                className="cancel-btn text-[16px] font-medium "
                onClick={handleExportModalClose}
                style={{ fontFamily: "Calibri" }}
              >
                <span>Cancel</span>
              </button>
              {/* <button
                className="save-btn text-[16px] font-medium"
                onClick={handleExport}
                style={{ fontFamily: "Calibri" }}
              >
                Export
              </button> */}
            </div>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default BillingFormPage;
