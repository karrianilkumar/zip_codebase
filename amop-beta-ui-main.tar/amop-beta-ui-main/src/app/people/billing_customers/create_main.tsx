"use client";

import React, { FC, useEffect, useMemo, useState } from "react";
import Select from "react-select";
import { Modal, Spin } from "antd";
import CreateRevIoCustomer from "./create_rev_io_customer";
import CreateModal from "@/app/components/createPopup";
import { useRevStore } from "@/app/stores/revStore";
import { DropdownStyles } from "@/app/components/css/dropdown";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";

// Types
interface CreateMainProps {
    createModalData: any[];
    headers: any[];
    generalFields: any;
    isOpen: boolean;
    onClose: () => void;
}

const DROPDOWN_OPTIONS = [
    { value: "revio", label: "Rev.IO customer" },
    { value: "billing", label: "Billing Customer" },
] as const;

type OptionValue = (typeof DROPDOWN_OPTIONS)[number]["value"];

const CreateMain: FC<CreateMainProps> = ({ createModalData, headers, generalFields, isOpen, onClose }) => {

    const [selected, setSelected] = useState<OptionValue | null>(null);
    const [isRevIoCustomerModalOpen, setIsRevIoCustomerModalOpen] = useState(false);
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const { setselectedCreateCustomer } = useRevStore()
    const [isBPEnabled, setIsBPEnabled] = useState<null | boolean>(null);
    const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId } = useAuth();
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (isOpen) {
            fetchBpFlag()
        }
    }, [isOpen])
    // When parent closes, reset everything
    const handleParentClose = () => {
        setSelected(null);
        setIsRevIoCustomerModalOpen(false);
        setIsCreateModalOpen(false);
        onClose?.();
    };

    // Open the appropriate child flow as soon as an option is chosen
    useEffect(() => {
        if (!selected) return;
        setselectedCreateCustomer(selected)
        if (selected === "revio") {
            setIsRevIoCustomerModalOpen(true);
            setIsCreateModalOpen(false);
        } else if (selected === "billing") {
            setIsCreateModalOpen(true);
            setIsRevIoCustomerModalOpen(false);
        }
    }, [selected]);

    const fetchBpFlag = async () => {
        setLoading(true);
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_cross_provider_optimization_status",
                role_name: role,
                parent_module: "Sim Management",
                module_name: "Active Customer Rate Plan",
                feature_module_name: "Customer Rate Plans",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const billing_plaform_flag = parsedData?.billing_platform_flag || false;
                setIsBPEnabled(billing_plaform_flag);
                if (!billing_plaform_flag) {
                    setSelected("revio")
                }
                else {
                    setSelected(null)
                }
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };

    // Handlers
    const handleFormSubmitSuccess = () => {
        setIsRevIoCustomerModalOpen(false);
    };

    const handleCreateModalClose = () => {
        setIsCreateModalOpen(false);
    };

    const handleCreateRow = (row: Record<string, any>) => {
        setIsCreateModalOpen(false);
    };

    const multiplyFactor = (typeof window !== "undefined" && window.innerWidth < 700) ? 3.5 : 2.5
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
    const modalWidth =
        typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;

    return (
        <Modal
            title="Create Customer"
            open={isOpen}
            onCancel={handleParentClose}
            footer={null}
            destroyOnClose
            maskClosable={false}
            width={modalWidth}
        >
            <div className="w-full space-y-4 overflow" style={{ height: modalHeight, overflow: "auto" }}>
                {loading ? (
                    <div className="flex justify-center items-center" style={{ height: modalHeight }}>
                        <Spin size="large" />
                    </div>
                ) : (
                    <>
                        {isBPEnabled && (
                            <div className="max-w-sm p-2">
                                <label className="block mb-1 text-sm font-semibold">Customer Type</label>
                                <Select
                                    options={DROPDOWN_OPTIONS as unknown as { value: string; label: string }[]}
                                    value={DROPDOWN_OPTIONS.find((o) => o.value === selected) as any}
                                    onChange={(opt) => setSelected((opt?.value as OptionValue) ?? null)}
                                    placeholder="Choose..."
                                    styles={DropdownStyles}
                                />
                            </div>
                        )}


                        {/* These are separate modals that open on top of the parent modal */}
                        {selected === "revio" && (
                            <CreateRevIoCustomer
                                isOpen={isRevIoCustomerModalOpen}
                                onClose={onClose}
                                onSuccess={handleFormSubmitSuccess}
                                dropdownData={generalFields}
                            />
                        )}

                        {selected === "billing" && (
                            <CreateModal
                                isOpen={isCreateModalOpen}
                                onClose={onClose}
                                onSave={handleCreateRow}
                                columnNames={createModalData}
                                heading="Customer"
                                header={headers}
                                generalFields={{ ...generalFields, state: [...generalFields?.state ? Object.keys(generalFields?.state) || [] : []] }}
                            />
                        )}
                    </>
                )}
            </div>
        </Modal>
    );
};

export default CreateMain;
