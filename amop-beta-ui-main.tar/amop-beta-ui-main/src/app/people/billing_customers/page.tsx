"use client";

import React, { useEffect, useState } from "react";
import RevioComponent from "./rev.io.page";
import BillingPlatformComponent from "./billing_platform_page";
import modal from "antd/es/modal";

const Page = () => {
  const [bpStatus, setBpStatus] = useState<null | boolean>(null);

  useEffect(() => {
    const status = localStorage.getItem("bp_flag");
    console.log("Billing Status:", status);
    setBpStatus(status === "true" ? true : status === "false" ? false : null);
  }, []);

  // if (bpStatus === null) {
  //   // modal.error ({
  //   //   title: "Status Error ",
  //   //   content: "Error while fetching the Billing status.",
  //   //   centered: true,
  //   // });
  //   console.error("Billing status is null. Please check the local storage value.");
  //   return null;
  // }

  return (
    <>
      {/* {bpStatus ? <RevioComponent /> : <BillingPlatformComponent />} */}
      {/* {bpStatus ? <BillingPlatformComponent /> : < RevioComponent/>} */}
      < RevioComponent/>

    </>
  );
};

export default Page;
