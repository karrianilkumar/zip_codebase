'use client'
import React, { useState, useEffect } from "react";
import { Modal, Select, Button, Form, notification, Input, Spin, Checkbox } from "antd";
import type { SelectProps } from 'antd/es/select';
import { DropdownStyles } from "@/app/components/css/dropdown";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { fireSideCannons } from "@/app/components/confetti";
const { Option } = Select;

interface CreateRevIoCustomerProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
   dropdownData?: any;
}

interface DropdownOption {
  label: string;
  value: string;
  id?: string;
}

const CreateRevIoCustomer: React.FC<CreateRevIoCustomerProps> = ({
  isOpen,
  onClose,
  onSuccess,
  dropdownData
}) => {
  const [form] = Form.useForm();
  const editableDrp = DropdownStyles;
  const [loading, setLoading] = useState(false);
  const [revIoAccounts, setRevIoAccounts] = useState<DropdownOption[]>([]);
  const [agentOptions, setAgentOptions] = useState<DropdownOption[]>([]);
  const [agentOptionsMap, setAgentOptionsMap] = useState<any>({});
  const [billProfiles, setBillProfiles] = useState<DropdownOption[]>([]);
  const [parentCustomers, setParentCustomers] = useState<DropdownOption[]>([]);
  const [useServiceAsBilling, setUseServiceAsBilling] = useState(true);
  const [useServiceAsListing, setUseServiceAsListing] = useState(true);
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isParent, setIsParent] = useState(false);
  const [stateOptions, setStateOptions] = useState<DropdownOption[]>([]);

  const { username, token, partner, role, selectedDb, metaData, firstLastName, sessionId } = useAuth();

  useEffect(() => {
    if (isOpen) {
      fetchDropdownData();
      // Extract states dynamically
      const statesData: Record<string, string[]> = dropdownData?.state || {};

      const states = Object.entries(statesData).map(([label, arr]) => ({
        label,
        value: arr[0]
      }));

  setStateOptions(states);
      form.setFieldsValue({
        useServiceAddressAsBilling: true,
        useServiceAddressAsListing: true,
        status: "Open",
        isParent: false,
      });
      setUseServiceAsBilling(true);
      setUseServiceAsListing(true);
      setIsParent(false);
    } else {
      form.resetFields();
      setUseServiceAsBilling(true);
      setUseServiceAsListing(true);
      setIsParent(false);
    }
  }, [isOpen, form]);

  const fetchDropdownData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.PEOPLE_MODULE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/add_people_revcustomer_dropdown_data",
        role_name: role,
        parent_module: "People",
        module_name: "Rev.IO customer",
        feature_module_name:"Billing Customers",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "Error fetching data. Please try again.",
          centered: true,
        });
      } else {
        const responseData = parsedData?.response_data;

        const accounts = responseData.rev_io_account?.map((item: string) => {
          const [name, id] = item.split(" -- ");
          return { label: name, value: name };
        }) || [];

        setRevIoAccounts(accounts);

         const agent_options_map = responseData.agent || {};

        setAgentOptionsMap(agent_options_map);

        const agent_options = Object.keys(agent_options_map)?.map((item: string) => ({ label: item, value: item })
        ) || [];

        setAgentOptions(agent_options);

        if(agent_options.length === 1){
          form.setFieldsValue({ agent: agent_options[0].value });
        }
        if (accounts.length > 0) {
          form.setFieldsValue({ revIoAccount: accounts[0].value });
        }

        const profiles = responseData.rev_bill_profile?.map((item: string) => {
          const parts = item.split(" -- ");
          const name = parts[0];
          const id = parts[1];
          return { 
            label: name, 
            value: id,
            id: id 
          };
        }) || [];

        setBillProfiles(profiles);

        // --- NEW: default-select first bill profile when available ---
        if (profiles.length > 0) {
          form.setFieldsValue({ billProfile: profiles[0].value });
        }
        // -------------------------------------------------------------

        // Filter parent customers - only those marked as parent
        setParentCustomers(
          responseData.customer_names?.map((item: string) => {
            return { label: item, value: item };
          }) || []
        );
      }
      
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content: "Error fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const callCustomersLambdaSync = async () => {
    const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
    const data = {
      path: "/lambda_sync_jobs_",
      key_name: "customers_sub_tenant_insert",
      tenant_name: partner
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }
  }

  const onFinish = async (values: any) => {
    setLoading(true);
    if (isSubmitting) return;
    setIsSubmitting(true);

    const formData = {
      status: values.status,
      rev_io_account: values.revIoAccount,
      bill_profile: values.billProfile,
      parent_customer: values.parentCustomer,
      service_address: {
        first_name: "",
        middle_initial: "",
        last_name: "",
        company_name: values.serviceCompanyName,
        address_line_1: values.serviceAddressLine1,
        address_line_2: values.serviceAddressLine2,
        city: values.serviceCity,
        state: values.serviceState,
        postal_code: values.servicePostalCode,
        postal_code_extension: values.servicePostalCodeExtension,
        country_code: "USA",
      },
      billing_address: useServiceAsBilling
        ? null
        : {
            first_name: "",
            middle_initial: "",
            last_name: "",
            company_name: values.billingCompanyName,
            address_line_1: values.billingAddressLine1,
            address_line_2: values.billingAddressLine2,
            city: values.billingCity,
            state: values.billingState,
            postal_code: values.billingPostalCode,
            postal_code_extension: values.billingPostalCodeExtension,
            country_code: "USA",
          },
      listing_address: useServiceAsListing
        ? null
        : {
            first_name: "",
            middle_initial: "",
            last_name: "",
            company_name: values.listingCompanyName,
            address_line_1: values.listingAddressLine1,
            address_line_2: values.listingAddressLine2,
            city: values.listingCity,
            state: values.listingState,
            postal_code: values.listingPostalCode,
            postal_code_extension: values.listingPostalCodeExtension,
            country_code: "USA",
          },
      use_service_address_as_billing_address: useServiceAsBilling,
      use_service_address_as_listing_address: useServiceAsListing,
      is_parent: values.parentCustomer ? "true" : "false",
      created_by: firstLastName,
      modified_by: firstLastName,
      modified_date: getCurrentDateTime(),
      created_date: getCurrentDateTime(),
    };

    const new_form = {
      agent_id:agentOptionsMap?.[values?.agent || ""] || "",
      status: values.status,
      rev_io_account: values.revIoAccount,
      bill_profile: values.billProfile,
      parent_customer: values.parentCustomer,
      service_address_first_name: "",
      service_address_middle_initial: "",
      service_address_last_name: "",
      service_address_company_name: values.serviceCompanyName,
      service_address_address_line_1: values.serviceAddressLine1,
      service_address_address_line_2: values.serviceAddressLine2,
      service_address_city: values.serviceCity,
      service_address_state: values.serviceState,
      service_address_postal_code: values.servicePostalCode,
      service_address_postal_code_extension: values.servicePostalCodeExtension,
      service_address_country_code: "USA",
      billing_address_first_name: "",
      billing_address_middle_initial: "",
      billing_address_last_name: "",
      billing_address_company_name: values.billingCompanyName,
      billing_address_address_line_1: values.billingAddressLine1,
      billing_address_address_line_2: values.billingAddressLine2,
      billing_address_city: values.billingCity,
      billing_address_state: values.billingState,
      billing_address_postal_code: values.billingPostalCode,
      billing_address_postal_code_extension: values.billingPostalCodeExtension,
      billing_address_country_code: "USA",
      listing_address_first_name: "",
      listing_address_middle_initial: "",
      listing_address_last_name: "",
      listing_address_company_name: values.listingCompanyName,
      listing_address_address_line_1: values.listingAddressLine1,
      listing_address_address_line_2: values.listingAddressLine2,
      listing_address_city: values.listingCity,
      listing_address_state: values.listingState,
      listing_address_postal_code: values.listingPostalCode,
      listing_address_postal_code_extension: values.listingPostalCodeExtension,
      listing_address_country_code: "USA",
      use_service_address_as_billing_address: false,
      use_service_address_as_listing_address: false,
      is_parent: values.parentCustomer ? "false" : "true",
      created_by: firstLastName,
      modified_by: firstLastName,
      modified_date: getCurrentDateTime(),
      created_date: getCurrentDateTime(),
    };

    const api_payload_ = {
      service_address: {
        first_name: "",
        middle_initial: "",
        last_name: "",
        company_name: values?.serviceCompanyName || "",
        line_1: values?.serviceAddressLine1 || "",
        line_2: values?.serviceAddressLine2 || "",
        city: values?.serviceCity || "",
        state_or_province: values?.serviceState || "",
        postal_code: values?.servicePostalCode || "",
        postal_code_extension: values?.servicePostalCodeExtension || "",
        country_code: "USA",
        created_date: getCurrentDateTime(),
      },
      billing_address: {
        first_name: "",
        middle_initial: "",
        last_name: "",
        company_name: !useServiceAsBilling ? values?.billingCompanyName || "" : values?.serviceCompanyName || "",
        line_1: !useServiceAsBilling ? values?.billingAddressLine1 || "" : values?.serviceAddressLine1 || "",
        line_2: !useServiceAsBilling ? values?.billingAddressLine2 : values?.serviceAddressLine2 || "",
        city: !useServiceAsBilling ? values?.billingCity || "" : values?.serviceCity || "",
        state_or_province: !useServiceAsBilling ? values?.billingState || "" : values?.serviceState || "",
        postal_code: !useServiceAsBilling ? values?.billingPostalCode || "" : values?.servicePostalCode || "",
        postal_code_extension: !useServiceAsBilling ? values?.billingPostalCodeExtension : values?.servicePostalCodeExtension || "",
        country_code: "USA",
        created_date: getCurrentDateTime(),
      },
      listing_address: {
        first_name: "",
        middle_initial: "",
        last_name: "",
        company_name: !useServiceAsListing ? values?.listingCompanyName || "" : values?.serviceCompanyName || "",
        line_1: !useServiceAsListing ? values?.listingAddressLine1 || "" : values?.serviceAddressLine1 || "",
        line_2: !useServiceAsListing ? values?.listingAddressLine2 || "" : values?.serviceAddressLine2 || "",
        city: !useServiceAsListing ? values?.listingCity || "" : values?.serviceCity || "",
        state_or_province: !useServiceAsListing ? values?.listingState || "" : values?.serviceState || "",
        postal_code: !useServiceAsListing ? values?.listingPostalCode || "" : values?.servicePostalCode || "",
        postal_code_extension: !useServiceAsListing ? values?.listingPostalCodeExtension || "" : values?.servicePostalCodeExtension || "",
        country_code: "USA",
        created_date: getCurrentDateTime(),
      },
      email:values?.email || "",
      status: values.status,
      parent_customer_id: (values.parentCustomer || '').split(' - ').pop() || '',
      is_parent:values.accountType === "Parent" ? "true" : "false",
      agent:values?.agent || "",
      finance: {
        bill_profile_id: values?.billProfile || "",
        billing_method:"EMAIL_ONLY"
      },
    }

    const requestData = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/submit_update_info_people_revcustomer",
      module_name: "Rev.IO Customer",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      new_data: formData,
      new_payload: new_form,
      api_payload: api_payload_,
      action: "create",
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      table_name: "rev_io_customer",
      user_type: "Rev IO Customer"
    };

    try {
      const response = await axios.post(ENV_ROUTES.PEOPLE_MODULE, {
        data: requestData,
      });

      const parsedResponse = JSON.parse(response.data.body);

      if (parsedResponse.flag === false) {
        Modal.error({
          title: "Saving Error",
          content: parsedResponse.message || "An error occurred while saving data. Please try again.",
          centered: true,
        });
      } else {
        callCustomersLambdaSync()
        notification.success({
          message: "Success",
          description: "Customer created successfully!",
          placement: "top",
        });
        fireSideCannons()
        onSuccess();
        onClose();
      }
    } catch (err) {
      console.error("Error saving data:", err);
      notification.error({
        message: "Error",
        description: "Failed to create the customer. Please try again.",
        placement: "top",
      });
    } finally {
      setLoading(false);
      setIsSubmitting(false);
    }
  };

  const handleSubmit = (e: { preventDefault: () => void; }) => {
    e?.preventDefault();
    form
      .validateFields()
      .then(() => {
        setShowConfirmation(true);
      })
      .catch((error) => {
        // Validation failed
      });
  };

  const confirmSubmit = () => {
    if (!isSubmitting) {
      setShowConfirmation(false);
      form.submit();
    }
  };

  const cancelConfirmation = () => {
    setShowConfirmation(false);
  };

  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const renderAddressFields = (prefix: string) => (
    <>
      <Form.Item
        label={renderLabel("Company Name", true)}
        name={`${prefix}CompanyName`}
        rules={[{ required: true, message: "Company Name is Required" }]}
      >
        <Input className="input" placeholder="Enter Company Name" />
      </Form.Item>
      <Form.Item
        label={renderLabel("Address Line 1", true)}
        name={`${prefix}AddressLine1`}
        rules={[{ required: true, message: "Address Line 1 is Required" }]}
      >
        <Input className="input" placeholder="Enter Address Line 1" />
      </Form.Item>
      <Form.Item label="Address Line 2" name={`${prefix}AddressLine2`} className="mt-1">
        <Input className="input" placeholder="Enter Address Line 2" />
      </Form.Item>
      <Form.Item
        label={renderLabel("City", true)}
        name={`${prefix}City`}
        rules={[{ required: true, message: "City is Required" }]}
      >
        <Input className="input" placeholder="Enter City" />
      </Form.Item>
      <Form.Item
        label={renderLabel("State", true)}
        name={`${prefix}State`}
        rules={[{ required: true, message: "State is Required" }]}
        className="mt-1"
      >
        <Input className="input" placeholder="Enter State" />
      </Form.Item>
      <Form.Item
        label={renderLabel("Postal Code", true)}
        name={`${prefix}PostalCode`}
        rules={[
          { required: true, message: "Postal Code is Required" },
          {
            pattern: /^[0-9]{5}$/,
            message: "Postal Code must be Exactly 5 Numerical Digits"
          }
        ]}
      >
        <Input className="input" placeholder="Enter Postal Code" />
      </Form.Item>
      <Form.Item 
        label="Postal Code Extension" 
        name={`${prefix}PostalCodeExtension`} 
        className="mt-1"
        help="Zip+4 for USA"
      >
        <Input className="input" placeholder="Enter Postal Code Extension" />
      </Form.Item>
    </>
  );

  const filterOption: SelectProps['filterOption'] = (input, option) => {
    const label = option?.label;
    return typeof label === 'string'
      ? label.toLowerCase().includes(input.toLowerCase())
      : false;
  };

  const agentFilterOption: SelectProps['filterOption'] = (input, option:any) => {
    const customLabel =   `${option?.value || ""}--${agentOptionsMap[option.value]}`
    return typeof customLabel === 'string'
      ? customLabel.toLowerCase().includes(input.toLowerCase())
      : false;
  };



  const accountType = Form.useWatch("accountType", form);
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;

  return (
    <>
      {/* <Modal
        title="Create Billing Customer"
        open={isOpen}
        onCancel={onClose}
        footer={null}
        centered
        width="90%"
        className="max-w-3xl sm:max-w-4xl md:max-w-[800px]"
      > */}
      {/* <div className="max-w-3xl sm:max-w-4xl md:max-w-[800px]"> */}
      {loading ? (
        <div className="flex justify-center items-center" style={{ height: modalHeight }}>
          <Spin size="large" />
        </div>
      ) : (
        <div
          style={{
            height: modalHeight,
              // overflowY: 'auto',
              // overflowX: 'hidden',
          }}
        >
          <Form
            form={form}
            layout="vertical"
            onFinish={onFinish}
            requiredMark={false}
            initialValues={{
              useServiceAddressAsBilling: true,
              useServiceAddressAsListing: true,
              status: 'Open',
              isParent: false,
            }}
            onValuesChange={(changedValues, allValues) => {
              if (changedValues.useServiceAddressAsBilling !== undefined) {
                setUseServiceAsBilling(changedValues.useServiceAddressAsBilling);
              }
              if (changedValues.useServiceAddressAsListing !== undefined) {
                setUseServiceAsListing(changedValues.useServiceAddressAsListing);
              }
              if (changedValues.isParent !== undefined) {
                setIsParent(changedValues.isParent);
                if (changedValues.isParent) {
                  form.setFieldsValue({ parentCustomer: undefined });
                }
              }
              if (changedValues.accountType === "Child") {
                setIsParent(false);
                form.setFieldsValue({ isParent: false });

                // immediately validate parentCustomer so the message appears right away
                form.validateFields(['parentCustomer']).catch(() => {
                  // ignore; validation messages are displayed on the form
                });
              }
            }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* <Form.Item
                label={renderLabel('Status', true)}
                name="status"
                rules={[{ required: true, message: 'Status is Required' }]}

              >
                <Select
                  placeholder="Select Status"
                  suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                >
                  <Option value="Prospect">Prospect</Option>
                  <Option value="Open">Open</Option>
                </Select>
              </Form.Item> */}

              <Form.Item
                label={renderLabel('Status', true)}
                name="status"
                rules={[{ required: true, message: 'Status is Required' }]}

              >
                <Input className="non-editable-input !text-gray-600" disabled/>
              </Form.Item>

              <Form.Item
                label={renderLabel('Company Name', true)}
                name="serviceCompanyName"
                rules={[{ required: true, message: 'Company Name is Required' }]}
              >
                <Input className="input" placeholder="Enter Company Name" />
              </Form.Item>

              {/* <Form.Item name="isParent" valuePropName="checked">
                <Checkbox disabled={accountType === "Child"} >Is Parent</Checkbox>
              </Form.Item> */}

              <Form.Item
                label={renderLabel('Account Type', true)}
                name="accountType"
                className="mb-8"
                rules={[{ required: true, message: 'Account Type is Required' }]}

              >
                <Select
                  placeholder="Select Account Type"
                  className="mb-2"
                  showSearch
                  suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                  virtual={false}
                    onChange={(val) => {
                      if (val !== "Child") {
                        form.setFieldsValue({ parentCustomer: undefined });
                      }
                    }}
                >
                  <Option value="Standard">Standard</Option>
                  <Option value="Parent">Parent</Option>
                  <Option value="Child">Child</Option>

                </Select>
              </Form.Item>
              <Form.Item
                label={renderLabel('Bill Profile', true)}
                name="billProfile"
                className="mb-8"
                rules={[{ required: true, message: 'Bill Profile is Required' }]}
              >
                <Select
                  placeholder="Select Bill Profile"
                  showSearch
                  filterOption={filterOption}
                  suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                  className="mb-2"
                  virtual={false}
                  // --- NEW: disable the dropdown if there is 0 or 1 option so user cannot open it ---
                  disabled={billProfiles.length <= 1}
                >
                  {billProfiles.map((profile) => (
                    <Option key={profile.value} value={profile.value}>
                      {profile.label}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
                <Form.Item
                  label="Parent Customer"
                  name="parentCustomer"
                  className="mb-8"
                  dependencies={['accountType']}
                  rules={[
                    ({ getFieldValue }) => ({
                      validator(_, value) {
                        if (getFieldValue('accountType') === "Child" && !value) {
                          return Promise.reject(new Error("Parent Customer is required for Child account type"));
                        }
                        return Promise.resolve();
                      },
                    }),
                  ]}
                >
                  <Select
                    placeholder="Select Parent Customer"
                    className="mb-2"
                    showSearch
                    suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                    virtual={false}
                    disabled={form.getFieldValue('accountType') !== "Child"}  
                  >
                    {parentCustomers.map((customer) => (
                      <Option key={customer.value} value={customer.value}>
                        {customer.label}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>

                <Form.Item
                  label={renderLabel('Agent', false)}
                  name="agent"
                  rules={[{ required: false, message: 'Agent is Required' }]}
                  className="mb-8"
                >
                  <Select
                    placeholder="Select Agent"
                    showSearch
                    filterOption={agentFilterOption}
                    suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                    onChange={(value) => {
                      form.setFieldsValue({ agent: value });
                    }}
                    className="mb-2"
                    disabled={agentOptions.length <= 1}
                  >
                    {agentOptions.map((option) => (
                      <Option key={option.value} value={option.value}>
                        {`${option.label}--${agentOptionsMap[option.label]}`}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>

            </div>

              <fieldset className="border border-gray-300 p-5 rounded-md mb-5 mt-4">
                <h2 className="text-base font-bold">Service Address</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Form.Item
                  label={renderLabel('Address Line 1', true)}
                  name="serviceAddressLine1"
                  rules={[{ required: true, message: 'Address Line 1 is Required' }]}
                >
                  <Input className="input" placeholder="Enter Address Line 1" />
                </Form.Item>

                <Form.Item label="Address Line 2" name="serviceAddressLine2" className="mt-1">
                  <Input className="input" placeholder="Enter Address Line 2" />
                </Form.Item>

                <Form.Item
                  label={renderLabel('City', true)}
                  name="serviceCity"
                  rules={[{ required: true, message: 'City is Required' }]}
                >
                  <Input className="input" placeholder="Enter City" />
                </Form.Item>

                <Form.Item
                  label={renderLabel('State', true)}
                  name="serviceState"
                  rules={[{ required: true, message: 'State is Required' }]}
                  // className="mt-1"
                >
                   <Select
                  placeholder="Select State"
                  className="mb-4"
                  showSearch
                  suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                  virtual={false}
                >
                   {stateOptions.map((item) => (
    <Option key={item.value} value={item.value} label={item.label}>
      {item.label}
    </Option>
  ))}

                </Select>
                </Form.Item>

                <Form.Item
                  label={renderLabel('Postal Code', true)}
                  name="servicePostalCode"
                  rules={[
                    { required: true, message: 'Postal Code is Required' },
                    {
                      pattern: /^[0-9]{5}$/,
                      message: 'Postal Code must be Exactly 5 Numerical Digits'
                    }
                  ]}
                >
                  <Input className="input" placeholder="Enter Postal Code" />
                </Form.Item>

                <Form.Item 
                  label="Postal Code Extension" 
                  name="servicePostalCodeExtension" 
                  className="mt-1"
                  help="Zip+4 for USA"
                >
                  <Input className="input" placeholder="Enter Postal Code Extension" />
                </Form.Item>

                  <Form.Item
                    label={renderLabel('Email', true)}
                    name="email"
                    rules={[
                      { required: true, message: "Email is Required" },
                      {
                        validator(_, value) {
                          if (!value) return Promise.resolve();

                          // ❗ Strict split by comma (no spaces allowed)
                          if (/\s/.test(value)) {
                            return Promise.reject(
                              new Error("Spaces are not allowed. Use comma without spaces.")
                            );
                          }

                          // ❗ No leading or trailing comma
                          if (value.startsWith(",") || value.endsWith(",")) {
                            return Promise.reject(
                              new Error("Email list cannot start or end with a comma.")
                            );
                          }

                          const emails = value.split(",");
                          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                          // ❗ Validate each email
                          const invalidEmails = emails.filter((email: string) => !emailRegex.test(email));

                          if (invalidEmails.length) {
                            return Promise.reject(
                              new Error(
                                `Invalid email(s): ${invalidEmails.join(", ")}`
                              )
                            );
                          }

                          return Promise.resolve();
                        }
                      }
                    ]}
                  >
                    <Input
                      className="input"
                      placeholder="Enter emails like abc@gmail.com,xyz@gmail.com"
                    />
                  </Form.Item>

                </div>
              </fieldset>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Form.Item name="useServiceAddressAsBilling" valuePropName="checked">
                  <Checkbox>Use Service Address as Billing Address</Checkbox>
                </Form.Item>

                <Form.Item name="useServiceAddressAsListing" valuePropName="checked">
                  <Checkbox>Use Service Address as Listing Address</Checkbox>
                </Form.Item>
              </div>

              {!useServiceAsBilling && (
                <fieldset className="border border-gray-300 p-5 rounded-md mb-5">
                  <h2 className="text-base font-bold">Billing Address</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {renderAddressFields('billing')}
                  </div>
                </fieldset>
              )}

              {!useServiceAsListing && (
                <fieldset className="border border-gray-300 p-5 rounded-md mb-5">
                  <h2 className="text-base font-bold">Listing Address</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {renderAddressFields('listing')}
                  </div>
                </fieldset>
              )}

              {/* Hidden fields for Billing Platform Account and Bill Profile */}
            <div style={{ display: 'none' }}>
              <Form.Item name="revIoAccount">
                <Input />
              </Form.Item>
              <Form.Item name="billProfile">
                <Input />
              </Form.Item>
            </div>

            <div className="flex justify-center gap-2">
              <button onClick={onClose} className="cancel-btn px-4 py-2">
                Cancel
              </button>
              <button onClick={handleSubmit} className="save-btn px-4 py-2">
                Submit
              </button>
            </div>
          </Form>
        </div>
      )}
      {/* </div> */}
      {/* </Modal> */}

      <Modal
        title="Submit Data"
        open={showConfirmation}
        onCancel={cancelConfirmation}
        centered
        footer={
          <div className="flex justify-center space-x-2">
            <Button key="cancel" className="cancel-btn px-4 py-2" onClick={cancelConfirmation}>
              Cancel
            </Button>
            <Button key="confirm" className="save-btn px-4 py-2" onClick={confirmSubmit}>
              OK
            </Button>
          </div>
        }
        width="90%"
        className="max-w-sm sm:max-w-md"
      >
        <p>Are you sure you want to submit this data?</p>
      </Modal>
    </>
  );
};

export default CreateRevIoCustomer;