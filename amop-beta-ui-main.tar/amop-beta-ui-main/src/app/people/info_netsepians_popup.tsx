// info_popup.tsx

import React, { useEffect, useState } from "react";
import Select from "react-select"; // Import react-select
import { Typography, Space,Modal } from "antd";
import { useRouter } from "next/navigation";
import { useLogoStore } from "../stores/logoStore";
import { DropdownStyles } from "../components/css/dropdown";
import { useAuth } from "../components/auth_context";
import axios from "axios";
import { ENV_ROUTES } from "../components/routes/route_constants";
import { usePartnerStore } from "../partner/partner_info/partnerStore";
import { getCurrentDateTime } from "../components/header_constants";
import { useCustomerRatePlanStore } from "../stores/customerRateplanStore";
const { Title } = Typography;


interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  rate_plan: any[];
  rowData:any,
}

const InfoNetsepiansPopup: React.FC<InfoModalProps> = ({ isOpen,
  onClose, rate_plan = [], rowData}) => {
  console.log("rowdata", rowData.customer_rate_plans)
  
  const router = useRouter();
  const { settabledata ,selectedDb,metaData,sessionId} = useAuth();
  const setTitle = useLogoStore((state) => state.setTitle);
  const [selectedOption, setSelectedOption] = useState(null);
  const { username, partner, role, token, firstLastName } = useAuth();
  const setPartnerUsers = usePartnerStore((state) => state.setPartnerUsers);
  const [deviceCount, setDeviceCount] = useState("0"); // State to hold the device count
  const [loading, setLoading] = useState(false); // State to manage loading status
  const {  partnerUsersShowActive } = useCustomerRatePlanStore();
  const fetchTabData = async (tab: {
    module: string;
    setter: (data: any) => void;
    setLoaded: (loaded: boolean) => void;
  }) => {
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/get_partner_info",
      role_name: role,
      parent_module: "Partner",
      modules_list: ["Partner users"],
      feature_module_name: "Partner Info",
      pages: {
        "Customer groups": { start: 0, end: 100 },
        "Partner users": { start: 0, end: 100 },
      },
      access_token: token,
      db_name: selectedDb,
      ... metaData,
      sessionID: sessionId,
      active_toggle:partnerUsersShowActive ?? false
    };
  
    try {
      const response = await axios.post(
        ENV_ROUTES.MODULE_MANAGEMENT,
        { data }
      );
      if (response && response.status === 200) {
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag) {
          setPartnerUsers(parsedData);
          tab.setter(parsedData);
          tab.setLoaded(true);
        } else {
          tab.setter(parsedData.message);
          Modal.error({
            title: "Error",
            content: parsedData.message,
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Error",
          content: "An error occurred during fetching data.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching", tab.module, ":", error);
      Modal.error({
        title: "Error",
        content: "An error occurred during fetching data.",
        centered: true,
      });
    }
  };
  

  const navigateToSimManagement = () => {
    setTitle("Inventory");
    settabledata([]);
    router.push("/sim_management/inventory");
  };

  const onSelection = (option: any) => {
    setSelectedOption(option);
  };

  const navigateToUsers =async() => {
    onClose()
    setTitle("Partner Users");
    settabledata([]);
    await fetchTabData({
      module: "Partner users",
      setter: (data) => {
        // Handle the data here, for example:
        console.log(data);
        // or
        // setSomeState(data);
      },
      setLoaded: (loaded) => {
        // Handle the loaded state here, for example:
        console.log(loaded);
        // or
        // setSomeOtherState(loaded);
      },
    });
    router.push('/partner/partner_info/users/createUser');
  };

  // Convert rate_plan options for react-select
  const options = rate_plan.map((option) => ({
    value: option,
    label: option,
  }));

  useEffect(() => {
    setSelectedOption(null);
  }, []);
  const fetchDeviceCount = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.PEOPLE_MODULE; // Replace with the actual backend endpoint
      const data = {
        tenant_name: partner || "Altaworx", // Replace with actual tenant name if dynamic
        username: username || "superadmin",
        path: "/submit_update_info_people_revcustomer",
        role_name: role || "Super Admin",
        parent_module: "People",
        module_name: "NetSapiens Customers",
        action: "info",
        info_data: {
          id: rowData.id, // The ID you provided
        },
        request_received_at: getCurrentDateTime(),
        access_token: token || "access_token", // Provide a real token
        db_name: selectedDb || null, // Optional database name
        ... metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag) {
        setDeviceCount(parsedData.line_item_count || "0"); // Set the device count from response
      } else {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "Failed to fetch device count. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false); // Ensure loading is set to false in the finally block
    }
  };
  useEffect(() => {
    if (isOpen) {
      fetchDeviceCount();
    }
  }, [isOpen]); 

  return (
    <>
  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
    }}
  >
    {/* Top Left Section */}
    <div style={{ flex: 1, marginBottom:"10px"}}>
      <button
        className="save-btn w-[150px]"
        onClick={navigateToSimManagement}
       
      >
        SIM Management
      </button>
      </div>
      <div style={{ flex: 1}}>
      <button
        className="save-btn w-[150px]"
        onClick={navigateToUsers}
      >
        Add New Customer
      </button>
    </div>
  </div>
  <div
            className="flex flex-row justify-center m-4"
          >
            {/* Middle Left Section */}
            <div style={{ flex: 1 }}>
              <Title level={5}>Device Count</Title>
              <Space direction="vertical" >
                <input type="text" value={deviceCount} disabled   />
              </Space>
            </div>
        
            {/* Middle Right Section */}
            <div style={{ flex: 1 }}>
              <Title level={5}>Default Rate Plan</Title>
              <Space direction="vertical">
                <input type="text" value={rowData.customer_rate_plans} disabled />
              </Space>
            </div>
          </div>

</>
  );
};

export default InfoNetsepiansPopup;
