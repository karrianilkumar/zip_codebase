"use client";
import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import * as XLSX from "xlsx";
import { PlusIcon, ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification } from "antd";

import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { useLogoStore } from "@/app/stores/logoStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
const { RangePicker } = DatePicker;
import { fireSideCannons } from "@/app/components/confetti";

//Lazy Loading Components
const TableComponent = lazy(() => import("@/app/components/TableComponent/page"));
const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(() => import("@/app/components/advanced_search"));


const NetSapiensCustomers: React.FC = () => {
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<any>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true); // State to manage loading

  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  // const createColumns = createModalData;
  const { username, partner, role, settabledata, token, selectedDb,metaData, advancedStoredpagination, storedpagination, tenantId, tenantName,sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns} = useAuth();
  const [tableData, setTableData] = useState<any[]>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const title = useLogoStore((state) => state.title);
  const [pagination, setpagination] = useState<any>({});
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
   //export functionality
  //  const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport,exports } = exportLoadingStore();
  const exportKey = "NetsapiensCustomers";
   const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});

  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters)
    setAdvancedFilters(advancedFilters)
    
  };
  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters)
    setFilteredData(EmptyFilters);
  };
  //   useEffect(() => {
  //     if(title!="People"){
  //         setLoading(true)
  //     }
  // },[title])


  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    // Convert the object to an array of [key, value] pairs
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    // Sort the array based on the second item of each value
    entries.sort((a, b) => a[1][1] - b[1][1]);

    // Convert the sorted array back to an object
    return Object.fromEntries(entries) as HeaderMap;
  }


  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf('day'));
    return current && current > dayjs().endOf('day'); // Disable future dates
  };

  const sortPopup = (fields: any[]): any[] => {
    return fields.sort((a: any, b: any) => a?.id - b?.id);
  };

  const hasFetchedData = useRef(false); // Ref to track if data has been fetched
  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"NetSapiens Customers":visibleColumns}))
      }, [visibleColumns]);
  useEffect(() => {
    const fetchData = async () => {
      setCombineAdnvaceStoredpagination(null)
      setLoading(true); // Set loading to true at the start
      try {
        const url =ENV_ROUTES.PEOPLE_MODULE;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          path: "/people_list_view",
          role_name: role,
          parent_module: "People", // Corrected spelling from 'poeple'
          module_name: "NetSapiens Customers",
          feature_module_name:"NetSapiens Customers",
          mod_pages: {
            start: 0,
            end: 100,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
        };
        console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
     
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
        // Check if the flag is false in the parsed data

        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching NetSapiens Customers data. Please try again.',
            centered: true,
          });
        } else {
          const tableData = parsedData.data;
          console.log(tableData,"Table data....")
          const headerMap = parsedData.headers_map["NetSapiens Customers"]["header_map"]
          const features = parsedData.headers_map["NetSapiens Customers"]["module_features"]

          setFeatures(features)
          const allowedActions_:any=[]
          if(features.includes("Info-NetSapiens customers")){
            allowedActions_.push("info")
          }
          if(features.includes("Edit-NetSapiens customers")){
            allowedActions_.push("edit")
          }
          setAllowedActions(allowedActions_)
          const createModalData = parsedData.headers_map["NetSapiens Customers"]["pop_up"]
          const sortedheaderMap = sortHeaderMap(headerMap)
          const generalFields = parsedData
          const pagination_ = parsedData.pages
          setpagination(pagination_)
          setgeneralFields(generalFields)
          setHeaderMap(sortedheaderMap)
          setcreateModalData(sortPopup(createModalData))
          // setTable(tableData);
           const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
          const dynamic_cols=dynamicColumns?.["NetSapiens Customers"] && dynamicColumns["NetSapiens Customers"].length>0 ?dynamicColumns["NetSapiens Customers"] :headers_ || headers_
          setVisibleColumns(dynamic_cols)
          setTableData(tableData);
          settabledata(tableData)
          setLoading(false)
        }

      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
        });
      } finally {
        setLoading(false); // Ensure loading is set to false in the finally block
      }
    };

    // fetchData();
    if (!hasFetchedData.current) { // Check if data has already been fetched
      fetchData();
      hasFetchedData.current = true; // Set to true after fetching
    }
  }, []);

  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
    setNewRowData({});
  };

  const handleCreateRow = (newRow: any, tableData: any) => {
    const updatedData = [...tableData, newRow];
    // setTable(tableData);
    // setTableData(tableData);
    handleCreateModalClose();
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    setDateRange([null, null]);
    console.log("daterange:", dateRange)
  };

  const messageStyle = {
    fontSize: '14px',  // Adjust font size
    fontWeight: 'bold', // Make the text bold
    padding: '16px',
    // Add padding
  };

  // const handleExport = async () => {
  //   if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
  //     Modal.error({ title: 'Error', content: 'Please select a date range.' });
  //     return;
  //   }

  //   const [startDate, endDate] = dateRange;

  //   const data = {
  //     path: "/export",
  //     username: username,
  //     table: "customers",
  //     module_name: "NetSapiens Customers",
  //     request_received_at: getCurrentDateTime(),
  //     start_date: startDate.format("YYYY-MM-DD 00:00:00"), // Start of the day
  //     end_date: endDate.format("YYYY-MM-DD 23:59:59"),
  //     Partner: partner,
  //     access_token: token,
  //     db_name: selectedDb,
  //   };

  //   try {
  //     const url =ENV_ROUTES.PEOPLE_MODULE;
  //     const response = await axios.post(url, { data: data }, {
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //     });

  //     const resp = JSON.parse(response.data.body);
  //     const blob = resp.blob;

  //     // Close the modal after exporting
  //     if (response.data.statusCode === 200) {
  //       if (resp.flag === true) {
  //         notification.success({
  //           message: 'Success',
  //           description: 'Successfully exported the record!',
  //           style: messageStyle,
  //           placement: 'top',
  //         });

  //         // Trigger the download after a successful export
  //         downloadBlob(blob);
  //       } else {
  //         // Log and show error message
  //         console.log('Error message:', resp.message);
  //         Modal.error({
  //           title: 'Export Error',
  //           content: resp.message,
  //           centered: true,
  //         });

  //       }
  //     } else {
  //       // Handle unexpected status codes
  //       console.log('Unexpected status code:', response.data.statusCode);
  //       Modal.error({
  //         title: 'Export Error',
  //         content: resp.message,
  //         centered: true,
  //       });
  //     }

  //     // Close the modal after exporting
  //     handleExportModalClose();
  //   } catch (error) {
  //     console.error("Error downloading the file:", error);
  //     Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
  //   }
  // };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "People",
        module_name: "NetSapiens Customers",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
        // removeExport(exportKey); // Remove the export from the store
    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
  const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
  const export_data = {
    tenant_name: partner || "default_value",
    username,
    path: "/get_export_status",
    role_name: role,
    parent_module: "People",
    module_name:"NetSapiens Customers",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    ... metaData,
    sessionID: sessionId,
  };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'NetSapiens Customers.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                            fireSideCannons()
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };


  const handleExport = async (key:string , heading:string) => {
    try {
      // setExportLoading(true)
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          module_name: "NetSapiens Customers",
          index_name: "people_netsapiens_customers",
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "NetSapiens Customers",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "people_netsapiens_customers",
          pages: {
            start: 0,
            end: 100
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId, 
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "NetSapiens Customers",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "people_netsapiens_customers",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId, 
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        // ExportWithoutSearch()
        await ExportWithoutSearch();
        return;
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        // if (parsedData.flag === true) {
        //   const s3Url = parsedData?.download_url || null;
        //   if (s3Url) {
        //     window.location.href = s3Url;
        //     setExportLoading(false)
        //     notification.success({
        //       message: 'Success',
        //       description: 'Successfully exported the record!',
        //       style: messageStyle,
        //       placement: 'top',
        //     });
        //   }
        //   else {
        //     setExportLoading(false)
        //     Modal.error({
        //       title: "Export Error",
        //       content: parsedData.message || "An error occurred while exporting data. Please try again.",
        //       centered: true,
        //     });
          // }

          if (parsedData.flag) {
            const s3Url = parsedData?.download_url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
                              .then(response => response.blob())
                              .then(blob => {
                                const url = window.URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.href = url;
                                a.download = 'NetSapiens Customers.xlsx';
                                a.click();
                                a.remove();
                                window.URL.revokeObjectURL(url);
                                notification.success({
                                  message: "Success",
                                  description: "Successfully exported the record!",
                                  style: messageStyle,
                                  placement: "top",
                                });
                                fireSideCannons()
                              })
                            .catch((err) => {
                              console.log("error",err)
                              Modal.error({
                                title: "Export Error",
                                content: "An error occurred while exporting data. Please try again.",
                                centered: true,
                              });
                            });
            }
        } else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }

    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };

  const downloadBlob = (base64Blob: string) => {
    // Decode the Base64 string
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = 'NetSapiens Customers.xlsx'; // Set the file name to .xlsx
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>
      <div className="relative">
      <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
            {/* <SearchInput searchTerm={searchTerm} setSearchTerm={setSearchTerm} /> */}
            {features.includes("Search-NetSapiens customers") && (

              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"people_netsapiens_customers"}
                headerMap={headerMap}
              />)}
            {features.includes("Advanced filter-NetSapiens customers") && (
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"people_netsapiens_customers"}
              />)}
          </div>

        
           {/* Export and ColumnFilter Container */}
           <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
            {features.includes("Add customer-NetSapiens customers") && (

              <button className="save-btn" onClick={handleCreateModalOpen}>
                <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                Add Customer
              </button>)}
            {features.includes("Export-NetSapiens customers") && (

              <button className="save-btn" 
              onClick={() => {
                if (!exports.some((exportItem) => exportItem.popupHeading === "NetSapiens Customers")) {
                  handleExport("NetsapiensCustomers", "NetSapiens Customers");
                }
              }}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                <span>Export</span>
              </button>)}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
        <div className=' mb-4 space-x-2'>
          {/* {features.includes("Advance Filter-NetSapiens Customers") && (
            <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"netsapiens_customers"}
            />)} */}
        </div>
        <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            allowedActions={allowedActions}
            popupHeading="NetSapien Customer"
            createModalData={createModalData}
            pagination={pagination}
            generalFields={generalFields}
            advancedFilters={filteredData}
            height = {showAdvanced?280:230}
          />
        </div>
        <CreateModal
          isOpen={isCreateModalOpen}
          onClose={handleCreateModalClose}
          onSave={handleCreateRow}
          columnNames={createModalData}
          heading="NetSapien Customer"
          header={tableData && tableData.length > 0 ? Object.keys(tableData[0]) : []}
          generalFields={generalFields}
          tableData={tableData}
        />
         {/* Sticky Footer for Small Screens */}
                            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                            {features.includes("Add customer-NetSapiens customers") && (
                              <button className="save-btn" onClick={handleCreateModalOpen}>
                                <PlusIcon className="h-5 w-5 text-black-500" />
                              </button>)}
                              {features.includes("Export-NetSapiens customers") && (

                              <button className="save-btn" 
                              onClick={() => {
                                if (!exports.some((exportItem) => exportItem.popupHeading === "NetSapiens Customers")) {
                                  handleExport("NetsapiensCustomers", "NetSapiens Customers");
                                }
                              }}>
                                <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
                              </button>)}
                              <ColumnFilter
                              headers={headers}
                              visibleColumns={visibleColumns}
                              setVisibleColumns={setVisibleColumns}
                              headerMap={headerMap}
                              />
                            </div>
        <Modal
          title="Export Output"
          visible={isExportModalOpen}
          onCancel={() => {
            handleExportModalClose();
            setDateRange([null, null]); // Reset date range here for good measure
          }}
          footer={null}
          centered
          afterClose={() => setDateRange([null, null])}
        >
          <div className="flex flex-col space-y-4">
            <span>Select Date Range</span>
            <RangePicker
              value={dateRange[0] && dateRange[1] ? [dateRange[0], dateRange[1]] : null} // Bind the date range
              onChange={(dates) => {
                console.log("Selected dates:", dates); // Debug log
                if (dates && dates.length === 2) {
                  setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                } else {
                  setDateRange([null, null]); // Reset to null if dates are not both available
                }
              }}
              format="YYYY-MM-DD"
              disabledDate={disableFutureDates}
              popupClassName="custom-range-popup"
            />
            <div className="flex justify-center space-x-2">
              <Button onClick={handleExportModalClose}>Cancel</Button>
              {/* <Button type="primary" onClick={handleExport}>Export</Button> */}
            </div>
          </div>
        </Modal>
        {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
          )} */}
      </div>
    </Suspense>
  );
};

export default NetSapiensCustomers;
