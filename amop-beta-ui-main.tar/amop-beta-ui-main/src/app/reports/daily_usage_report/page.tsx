"use client";
import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  AdjustmentsHorizontalIcon,
  ArrowUpTrayIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Popover, Spin, DatePicker, notification } from "antd";
import { CalendarOutlined } from '@ant-design/icons';
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useDateRangeStore } from "@/app/stores/dateStoreDailyUsageReport";
import Select from 'react-select'; // Importing react-select
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { DropdownStyles, NonEditableDropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";
const { RangePicker } = DatePicker;

//Lazy Loading Components
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const CreateModal = lazy(() => import("@/app/components/createPopup"));

const DailyUsageReport: React.FC = () => {
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<any>({});
  const [features, setFeatures] = useState<string[]>([]);
  const hasFetchedData = useRef(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, tenantId, tenantName, selectedDb, metaData, advancedStoredpagination, storedpagination, firstLastName, sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination, dynamicColumns, setDynamicColumns } =
    useAuth();
  const [tableData, setTableData] = useState<any[]>([]);
  const title = useLogoStore((state) => state.title);
  const [pagination, setpagination] = useState<any>({});
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [selectedButton, setSelectedButton] = useState("today");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const {
    startDateDailyReport,
    endDateDailyReport,
    setToday,
    setCurrentWeek,
    setCurrentMonth,
    setCustomRange,
  } = useDateRangeStore();
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const [isRangeSeleced, setIsRangeSelected] = useState(false);
  //export functionality
  //  const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const dataKey = "Daily Usage Report"
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});

  // Add these state variables at the top of the component
  const [isConfirmationModalVisible, setConfirmationModalVisible] = useState(false);
  const [serviceProviders, setServiceProviders] = useState<string[]>([]);
  const [billingCyclePeriods, setBillingCyclePeriods] = useState<string[]>([]);
  // Add this to your state variables
  const [billingPeriodDates, setBillingPeriodDates] = useState<Record<string, string[]>>({});
  // Add this default value to your serviceProviders state
  const [selectedServiceProvider, setSelectedServiceProvider] = useState<{ value: string; label: string } | null>({
    value: "All service providers",
    label: "All service providers",
  });
  const [selectedBillingCyclePeriod, setSelectedBillingCyclePeriod] = useState<{ value: string; label: string } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>(""); // State to hold error messages
  const [showBillingCyclePeriod, setShowBillingCyclePeriod] = useState(true);
  // Add this state at the top of your component
  const [activeDateFilter, setActiveDateFilter] = useState<'today' | 'week' | 'month' | 'custom'>('today');

  //Remove columns based on role
  // useEffect(() => {
  //   if (role?.toLowerCase() !== "super admin" && role?.toLowerCase() !== "partner admin" && role?.toLowerCase() !== "agent partner admin") {
  //     const removeHeaderList = Object.keys(headerMap).filter(
  //       (key) =>
  //         ["communication plan"].includes(
  //           headerMap[key][0]?.toLowerCase()
  //         )
  //     );

  //     setHeaders((prevHeaders) =>
  //       prevHeaders.filter((header) => !removeHeaderList.includes(header))
  //     );
  //   }
  // }, [role, headerMap]);
  // Add a new function to fetch dropdown data
  const fetchExportDropdownData = async () => {
    setLoading(true)
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/reports_dropdown_data_export",
        role_name: role,
        parent_module: "Reports",
        module: "Daily usage report",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag) {
        setServiceProviders(parsedData.unique_service_providers || []);
        setBillingPeriodDates(parsedData.billing_period_dates || {});

        // Set default provider logic
        if (parsedData.unique_service_providers?.length > 0) {
          const defaultProvider = parsedData.unique_service_providers[0];
          setSelectedServiceProvider(defaultProvider);

          const defaultPeriods = parsedData.billing_period_dates[defaultProvider] || [];
          setBillingCyclePeriods(defaultPeriods);
        }
      } else {
        Modal.error({
          title: "Error",
          content: parsedData.message || "Failed to fetch export dropdown data",
        });
      }
    } catch (error) {
      Modal.error({
        title: "Error",
        content: "An error occurred while fetching export dropdown data",
      });
    }
    finally{
      setLoading(false)
    }
  };

  const handleExportModalOpen = () => {
    fetchExportDropdownData().then(() => {
      setSelectedServiceProvider({
        value: "All service providers",
        label: "All service providers",
      });
      setExportModalOpen(true);
    });
  };

  // const handleServiceProviderChange = (selectedOption: any) => {
  //   setSelectedServiceProvider(selectedOption);
  //   setSelectedBillingCyclePeriod(null); // Reset billing cycle period when changing service provider

  //   const periods = billingPeriodDates[selectedOption.value] || [];
  //   setBillingCyclePeriods(periods);
  // };

  const handleServiceProviderChange = (selectedOption: any) => {
    setSelectedServiceProvider(selectedOption);

    // Reset billing cycle period when changing service provider
    const periods = billingPeriodDates[selectedOption.value] || [];
    setBillingCyclePeriods(periods);

    // Set the first value as default if it's not "All service providers"
    if (selectedOption.value !== "All service providers" && periods.length > 0) {
      setSelectedBillingCyclePeriod({ value: periods[0], label: periods[0] }); // Set first value as default
    } else {
      setSelectedBillingCyclePeriod(null); // Clear selection if "All service providers" is selected
    }
  };
  const handleExportClick = () => {
    // Clear previous error message
    setErrorMessage("");

    // Immediate validation when the export button is clicked
    if (!selectedServiceProvider) {
      setErrorMessage("Please select a Service Provider.");
      return; // Stop further execution
    }

    if (selectedServiceProvider.value !== "All service providers" && !selectedBillingCyclePeriod && !isRangeSeleced) {
      setErrorMessage("Please select a billing cycle Period.");
      return; // Stop further execution
    }

    // If all validations pass, show the confirmation modal
    setConfirmationModalVisible(true);
  };
  const handleExportModalClose = () => {
    setExportModalOpen(false);
    setDateRange([null, null]); // Reset date range
    setSelectedServiceProvider(null);
    setSelectedBillingCyclePeriod(null);
  };
  const confirmExport = async () => {
    setConfirmationModalVisible(false);
    await ExportWithoutSearch("daily usage", "Daily Usage Report"); // Call the export function with the selected values
  };
  useEffect(() => {
    setDynamicColumns((prev: any) => ({ ...prev, "Daily usage report": visibleColumns }))
  }, [visibleColumns]);
  const fetchData = async (startDate: string, endDate: string) => {
    settabledata([])
    setCombineAdnvaceStoredpagination(null)
    setLoading(true);
    console.log(startDateDailyReport, endDateDailyReport, "Show the start and end dates")
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        role_name: role,
        start_date: startDate,
        end_date: endDate,
        path: "/reports_data_with_date_filter",
        parent_module: "Reports",
        module_name: "Daily usage report",
        feature_module_name: "Daily Usage Report",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        table_name: "vw_daily_usage_report",
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        const tableData = parsedData?.data || [];
        const headerMap =
          parsedData.headers_map?.["Daily usage report"]?.["header_map"] || {};
        // const features = parsedData.headers_map["Bandwidth Customers"]["module_features"]

        // console.log("features", features)
        // setFeatures(features)
        // const createModalData = parsedData.headers_map["Bandwidth Customers"]["pop_up"]
        const sortedheaderMap = sortHeaderMap(headerMap);
        // const generalFields = parsedData.data
        const pagination_ = parsedData?.pages || {};
        setpagination(pagination_);
        // setgeneralFields(generalFields)
        const features_ = parsedData?.headers_map?.["Daily usage report"]?.module_features || [];
        setFeatures(features_);
        setHeaderMap(headerMap);
        // setcreateModalData(sortPopup(createModalData))
        setTableData(tableData);
        // settabledata(tableData)
        const headers_ =
          Object.keys(sortedheaderMap).length > 0
            ? Object.keys(sortedheaderMap)
            : [];
        setHeaders(headers_);
        const dynamic_cols = dynamicColumns?.["Daily usage report"] && dynamicColumns["Daily usage report"].length > 0 ? dynamicColumns["Daily usage report"] : headers_ || headers_
        setVisibleColumns(dynamic_cols)
        setLoading(false);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false); // Ensure loading is set to false in the finally block
    }
  };

  const handleTodayClick = () => {
    setStartDate(null);
    setEndDate(null);
    const today = dayjs().format("YYYY-MM-DD");
    setToday(); // update store
    setIsRangeSelected(false);  // Reset range selection flag
    setShowBillingCyclePeriod(true); // Show billing cycle period
    setActiveDateFilter('today'); // Track active filter
    fetchData(today, today);
  };

  const handleCurrentWeekClick = () => {
    setStartDate(null);
    setEndDate(null);
    const startOfWeek = dayjs().startOf("week").format("YYYY-MM-DD");
    const endOfWeek = dayjs().endOf("week").format("YYYY-MM-DD");
    setCurrentWeek();
    setIsRangeSelected(false);  // Not a custom range
    setShowBillingCyclePeriod(false); // Hide billing cycle period
    setActiveDateFilter('week'); // Track active filter
    fetchData(startOfWeek, endOfWeek);
  };

  const handleCurrentMonthClick = () => {
    setStartDate(null);
    setEndDate(null);
    const startOfMonth = dayjs().startOf("month").format("YYYY-MM-DD");
    const endOfMonth = dayjs().endOf("month").format("YYYY-MM-DD");
    setCurrentMonth();
    setIsRangeSelected(false);  // Not a custom range
    setShowBillingCyclePeriod(false); // Hide billing cycle period
    setActiveDateFilter('month'); // Track active filter
    fetchData(startOfMonth, endOfMonth);
  };

  const handleClickRangePicker = (range: any) => {
    if (!range) {
      setStartDate(null);
      setEndDate(null);
      setCustomRange(null, null);
      setIsRangeSelected(false);  // No range selected
      setShowBillingCyclePeriod(true); // Show billing cycle period
      setActiveDateFilter('today'); // Reset to today
      return;
    }

    const [rangeStart, rangeEnd] = range;

    if (rangeStart && rangeEnd) {
      setIsRangeSelected(true);  // Custom range selected
      const formattedStart = rangeStart.format('YYYY-MM-DD');
      const formattedEnd = rangeEnd.format('YYYY-MM-DD');

      setStartDate(rangeStart);
      setEndDate(rangeEnd);
      setCustomRange(formattedStart, formattedEnd);
      setShowBillingCyclePeriod(false); // Hide billing cycle period
      setActiveDateFilter('custom'); // Track active filter
      fetchData(formattedStart, formattedEnd);
    }
  };



  useEffect(() => {
    handleTodayClick();
  }, []);
  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  };

  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  };

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };
  const sortPopup = (fields: any[]): any[] => {
    return fields.sort((a: any, b: any) => a?.id - b?.id);
  };

  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
    setNewRowData({});
  };
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const handleCreateRow = (newRow: any, tableData: any) => {
    handleCreateModalClose();
  };


  // const handleExport = async () => {
  //   // Check for a valid date range
  //   if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
  //     Modal.error({ title: "Error", content: "Please select a date range." });
  //     return;
  //   }

  //   const [startDate, endDate] = dateRange;

  //   const data = {
  //     path: "/export",
  //     username: username,
  //     table: "customers",
  //     module_name: "Daily usage report export",
  //     request_received_at: getCurrentDateTime(),
  //     start_date: startDate.format("YYYY-MM-DD 00:00:00"), // Start of the day
  //     end_date: endDate.format("YYYY-MM-DD 23:59:59"),
  //     Partner: partner,
  //     access_token: token,
  //     db_name: selectedDb,
  //   };

  //   try {
  //     const url = ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(
  //       url,
  //       { data: data },
  //       {
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //       }
  //     );

  //     const resp = JSON.parse(response.data.body);
  //     const blob = resp.blob;

  //     // Log the response to check its structure
  //     console.log("Response:", resp);

  //     // Handle response based on status code
  //     if (response.data.statusCode === 200) {
  //       if (resp.flag === true) {
  //         notification.success({
  //           message: "Success",
  //           description: "Successfully exported the record!",
  //           style: messageStyle,
  //           placement: "top",
  //         });

  //         // Trigger the download after a successful export
  //         downloadBlob(blob);
  //       } else {
  //         // Log and show error message
  //         console.log("Error message:", resp.message);
  //         Modal.error({
  //           title: "Export Error",
  //           content: resp.message,
  //           centered: true,
  //         });
  //       }
  //     } else {
  //       // Handle unexpected status codes
  //       console.log("Unexpected status code:", response.data.statusCode);
  //       Modal.error({
  //         title: "Export Error",
  //         content: resp.message,
  //         centered: true,
  //       });
  //     }

  //     // Close the modal after processing the export
  //     handleExportModalClose();
  //   } catch (error) {
  //     // console.error("Error downloading the file:", error);
  //     // Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
  //   }
  // };


  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch_ = async (key: string, heading: string) => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      addExport(key, heading);

      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Reports",
        module_name: "Daily usage report Export",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        feature_module_name: "Daily Usage Report",
        ...(activeDateFilter === 'today' && selectedBillingCyclePeriod ? {
          billing_cycle_period: selectedBillingCyclePeriod.value
        } : {}),
        ...(activeDateFilter !== 'today' ? {
          start_date: startDateDailyReport,
          end_date: endDateDailyReport
        } : {}),
        service_provider: selectedServiceProvider?.value === "All service providers"
          ? ""
          : selectedServiceProvider?.value,
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));

      // Polling for the second API

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
      removeExport(key); // Remove the export from the store
    }
  }

  const convertDate = (value:any) =>{

// Split and rearrange
const [year, month, day] = value.split("-");
const formattedDate = `${month}-${day}-${year}`;
return formattedDate || ""
  }
  
  const displayNoDataPopup = (providers: any) => {
    if (!providers || providers.length === 0) return;

    // Normalize providers (handles array of strings or objects)
    const providerList = providers.map((p: any) =>
      typeof p === "string" ? p : p.provider_name || p.name || "Unknown"
    );

    const notAvailableProviders = serviceProviders.filter((provider:any)=>!providerList.includes(provider) && provider.toLowerCase()!== "all service providers")

    Modal.info({
      title: "No Data Available",
      content: (
        <div>
          <p>Provider data is not available for:</p>
          <ul style={{ paddingLeft: "20px" }}>
            {notAvailableProviders.map((provider: string, index: number) => (
              <li key={index}>{provider}</li>
            ))}
          </ul>
        </div>
      ),
      centered: true,
    });
  };

  const ExportWithoutSearch = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response

      let startDate, endDate

      if (activeDateFilter === 'today' && selectedBillingCyclePeriod) {
        const value = selectedBillingCyclePeriod.value
        // Parse to Date object
        // Parse to Date object
        const endDateObj = new Date(value);

        // Format helper
        const formatDate = (date: Date) => {
          const month = String(date.getMonth() + 1).padStart(2, "0");
          const day = String(date.getDate()).padStart(2, "0");
          const year = date.getFullYear();
          return `${month}/${day}/${year}`;
        };

        // End date
        endDate = formatDate(endDateObj);

        // Start date (subtract 1 month)
        const startDateObj = new Date(endDateObj);
        startDateObj.setMonth(startDateObj.getMonth() - 1);
        startDate = formatDate(startDateObj);
      }
      else {
        startDate = convertDate(startDateDailyReport || "")
        endDate = convertDate(endDateDailyReport || "")
      }

      url = ENV_ROUTES.OPEN_SEARCH;
      data = {
        path: "/search_export",
        search: "advanced",
        filters: {
          service_provider: [selectedServiceProvider?.value === "All service providers"
            ? ""
            : selectedServiceProvider?.value],
          billing_cycle_end_date: [(selectedServiceProvider?.value === "All service providers" && activeDateFilter === 'today')
            ? ""
            : activeDateFilter === 'today' && selectedBillingCyclePeriod
            ?`${endDate}`
            :`${startDate}:${endDate}`]

        },
        all_service_provider_flag: selectedServiceProvider?.value === "All service providers",
        tenant_id: tenantId,
        pages: {
          start: 0,
          end: 100,
        },
        partner: partner,
        username: username,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        index_name: "daily_usage_report_export",
        module_name: "Daily usage report Export",
      };
      console.log("combineAdnvaceStoredpagination", data)
      response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === true) {
        const s3Url = parsedData?.download_url || null;
        const service_providers = parsedData?.service_provider || [];

        if (s3Url) {
          //  window.location.href = s3Url;
          //  // setExportLoading(false)
          //  notification.success({
          //    message: 'Success',
          //    description: 'Successfully exported the record!',
          //    style: messageStyle,
          //    placement: 'top',
          //  });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Daily Usage Report.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons()
              if (service_providers && service_providers.length > 0) {
                displayNoDataPopup(service_providers)
              }
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        }
        else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      }
      else {
        console.log("parseddata",parsedData)
          if (parsedData.message === "No data found for export.") {
          Modal.info({
            title: "Export Information",
            content: "No Data Found for export",
            centered: true,
          });
          return true; // Stop polling
        }
        // setExportLoading(false)
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    }
    catch (error) {
      await startPolling();
      // setExportLoading(false)
      // setLoading(false);
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }

  }
  const pollExportStatus = async () => {
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_export_status",
      role_name: role,
      parent_module: "Reports",
      module_name: "Daily usage report Export",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ... metaData,
      sessionID: sessionId,
    };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        const service_providers = export_parsedData?.service_provider || []
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Daily Usage Report.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons()
              if (service_providers && service_providers.length > 0) {
                displayNoDataPopup(service_providers)
              }
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      // Check for "No Data Found for export"
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
        Modal.info({
          title: "Export Information",
          content: "No Data Found for export",
          centered: true,
        });
        return true; // Stop polling
      }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };


  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          index_name: "daily_usage_report_export",
          module_name: "Daily usage report Export",
        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        // setExportLoading(true)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Daily usage report Export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "daily_usage_report_export",
          pages: {
            start: 0,
            end: 100
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        // setExportLoading(true)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Daily usage report Export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "daily_usage_report_export",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        handleExportModalOpen()
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        if (parsedData.flag === true) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            //  window.location.href = s3Url;
            //  // setExportLoading(false)
            //  notification.success({
            //    message: 'Success',
            //    description: 'Successfully exported the record!',
            //    style: messageStyle,
            //    placement: 'top',
            //  });
            fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Daily Usage Report.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
                fireSideCannons()
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
          }
          else {
            // setExportLoading(false)
            Modal.error({
              title: "Export Error",
              content: parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }
        }
        else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      }
    } catch (error) {
      await startPolling();
      // setExportLoading(false)
      // setLoading(false);
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
  const downloadBlob = (base64Blob: string) => {
    // Decode the Base64 string
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Daily Usage Report.xlsx"; // Set the file name to .xlsx
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day"); // Disable future dates
  };

  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="relative">
        {/* Date Selection Buttons - Hidden on small screens */}
        <div className="hidden md:flex flex-col pr-4 pt-4 pl-4 md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:justify-end md:order-none order-first">
          <Button
            className={`${selectedButton === 'today' ? 'save-btn' : ''} min-h-[40px]`}
            onClick={() => {
              setSelectedButton("today");
              handleTodayClick();
            }}
          >
            Today
          </Button>
          <Button
            className={`${selectedButton === 'currentWeek' ? 'save-btn' : ''} min-h-[40px]`}
            onClick={() => {
              setSelectedButton("currentWeek");
              handleCurrentWeekClick();
            }}
          >
            Current Week
          </Button>
          <Button
            className={`${selectedButton === 'currentMonth' ? 'save-btn' : ''} min-h-[40px]`}
            onClick={() => {
              setSelectedButton("currentMonth");
              handleCurrentMonthClick();
            }}
          >
            Current Month
          </Button>
          {/* 
          <RangePicker
            format="YYYY-MM-DD"
            placeholder={["Start Date", "End Date"]}
            value={startDate && endDate ? [startDate, endDate] : [null, null]}
            style={{ width: "20%", marginLeft: "10px" }}
            onChange={(dates) => {
              setSelectedButton("customDate");
              handleClickRangePicker(dates)
              // handle date change here
            }}
            disabledDate={disableFutureDates}
            className={`${selectedButton === 'customDate' ? 'save-btn' : ''} min-h-[40px]`}
          /> */}
          <RangePicker
            format="YYYY-MM-DD"
            placeholder={["Start Date", "End Date"]}
            value={startDate && endDate ? [startDate, endDate] : [null, null]}
            onChange={(dates) => {
              setSelectedButton("customDate");
              handleClickRangePicker(dates);
            }}
            disabledDate={disableFutureDates}
            className={`${selectedButton === 'customDate' ? 'save-btn' : ''} min-h-[40px] w-full ml-0 lg:w-[20%] lg:ml-[10px]`}
            popupClassName="custom-range-popup"
          />
        </div>

        {/* Search and Filter Section */}
        <div className="pr-4 pl-4 flex md:flex-row md:items-center md:justify-between mb-4 space-y-4">
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            {features.includes("Search-Daily usage report") && (
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"daily_usage_report"}
                headerMap={headerMap}
              />
            )}
            {features.includes("Advanced filter-Daily usage report") && (
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"daily_usage_report"}
              />
            )}
          </div>
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-first pb-2 md:pb-4">
            {features.includes("Export-Daily usage report") && (
              <button className="save-btn" onClick={() => handleExport("DailyUsageReport", "Daily Usage Report")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-1" />
                <span>Export</span>
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>

        <div className=" mb-4 space-x-2">
          {/* {features.includes("Advance Filter-Bandwidth Customers") && (
            <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"bandwidth_customers"} />
          )} */}
        </div>

        {/* Table and Other Components */}
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            popupHeading="Daily usage report"
            createModalData={createModalData}
            pagination={pagination}
            generalFields={generalFields}
            advancedFilters={filteredData}
            height={showAdvanced ? 360 : 300}
          />
        </div>
        <CreateModal
          isOpen={isCreateModalOpen}
          onClose={handleCreateModalClose}
          onSave={handleCreateRow}
          columnNames={createModalData}
          heading="Daily usage report"
          header={
            tableData && tableData.length > 0 ? Object.keys(tableData[0]) : []
          }
          generalFields={generalFields}
          tableData={tableData}
        />

        {/* Sticky Footer for Small Screens */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
          {features.includes("Export-Daily usage report") && (
            <button className="save-btn" onClick={() => handleExport("DailyUsageReport", "Daily Usage Report")}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
            </button>
          )}
          <button className="save-btn" onClick={() => setIsDateModalOpen(true)}>
            <CalendarOutlined className="h-5 w-5 text-black-500" />
          </button>
          <ColumnFilter
            headers={headers}
            visibleColumns={visibleColumns}
            setVisibleColumns={setVisibleColumns}
            headerMap={headerMap}
          />
        </div>
        {/* <Modal
          title={
            <span className="font-semibold text-xl space-y-3">
              Export output
            </span>
          }
          visible={isExportModalOpen}
          onCancel={() => {
            handleExportModalClose();
            setDateRange([null, null]); // Reset date range here for good measure
          }}
          footer={null}
          centered
          afterClose={() => setDateRange([null, null])}
        >
          <div className="flex flex-col space-y-4">
            <span>Select date range</span>
            <RangePicker
              value={
                dateRange[0] && dateRange[1]
                  ? [dateRange[0], dateRange[1]]
                  : null
              } // Bind the date range
              onChange={(dates) => {
                console.log("Selected dates:", dates); // Debug log
                if (dates && dates.length === 2) {
                  setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                } else {
                  setDateRange([null, null]); // Reset to null if dates are not both available
                }
              }}
              format="YYYY-MM-DD"
              disabledDate={disableFutureDates}
            />
            <div
              style={{ marginTop: "2rem" }}
              className="flex  justify-center gap-2 space-x-2"
            >
              <button
                className="cancel-btn text-[16px] font-medium "
                onClick={handleExportModalClose}
                style={{ fontFamily: "Calibri" }}
              >
                <span>Cancel</span>
              </button>
              <button
                className="save-btn text-[16px] font-medium"
                onClick={handleExport}
                style={{ fontFamily: "Calibri" }}
              >
                Export
              </button>
            </div>
          </div>
        </Modal> */}


        {/* Date Selection Modal for Small Screens */}
        <Modal
          title="Select Date Range"
          visible={isDateModalOpen}
          onCancel={() => setIsDateModalOpen(false)}
          footer={null}
          centered
        >
          <div className="flex flex-col space-y-2">
            <Button
              className={`${selectedButton === 'today' ? 'save-btn' : ''} min-h-[40px]`}
              onClick={() => {
                setSelectedButton("today");
                handleTodayClick();
                setIsDateModalOpen(false);
              }}
            >
              Today
            </Button>
            <Button
              className={`${selectedButton === 'currentWeek' ? 'save-btn' : ''} min-h-[40px]`}
              onClick={() => {
                setSelectedButton("currentWeek");
                handleCurrentWeekClick();
                setIsDateModalOpen(false);
              }}
            >
              Current Week
            </Button>
            <Button
              className={`${selectedButton === 'currentMonth' ? 'save-btn' : ''} min-h-[40px]`}
              onClick={() => {
                setSelectedButton("currentMonth");
                handleCurrentMonthClick();
                setIsDateModalOpen(false);
              }}
            >
              Current Month
            </Button>
            <RangePicker
              format="YYYY-MM-DD"
              placeholder={["Start Date", "End Date"]}
              value={startDate && endDate ? [startDate, endDate] : [null, null]}
              onChange={(dates) => {
                setSelectedButton("customDate");
                handleClickRangePicker(dates);
                setIsDateModalOpen(false);
              }}
              disabledDate={disableFutureDates}
              popupClassName="custom-range-popup"
              className={`${selectedButton === 'customDate' ? 'save-btn' : ''} min-h-[40px] w-full`}
            />
          </div>
        </Modal>

        {/* Existing Modals (Export and Confirm Export) */}
        <Modal
          title="Export Output"
          visible={isExportModalOpen}
          onCancel={handleExportModalClose}
          footer={null}
          centered
        >
          <div className="flex flex-col space-y-3">
            <label>Service Provider</label>
            <Select
              options={serviceProviders.map(provider => ({ value: provider, label: provider }))}
              onChange={handleServiceProviderChange}
              placeholder="Select Service Provider"
              value={selectedServiceProvider}
              styles={DropdownStyles}
            />
            <>
              {!isRangeSeleced && showBillingCyclePeriod && (
                <>
                  <label>Billing Cycle Period</label>
                  <Select
                    options={billingCyclePeriods.map(period => ({ value: period, label: period }))}
                    onChange={setSelectedBillingCyclePeriod}
                    placeholder="Select Billing Cycle Period"
                    isDisabled={selectedServiceProvider?.value === "All service providers"}
                    value={selectedBillingCyclePeriod}
                    styles={selectedServiceProvider?.value === "All service providers" ? NonEditableDropdownStyles : DropdownStyles}
                  />
                </>
              )}

            </>

            {errorMessage && <p className="text-red-500">{errorMessage}</p>} {/* Display error message */}
            <div className="flex justify-center space-x-2">
              <Button className="cancel-btn" onClick={handleExportModalClose}>Cancel</Button>
              <Button className="save-btn" onClick={handleExportClick}>
                Export
              </Button>
            </div>
          </div>
        </Modal>
        <Modal
          title="Confirm Export"
          visible={isConfirmationModalVisible}
          footer={null}
          centered
          onCancel={() => setConfirmationModalVisible(false)}
        >
          <p>Are you sure you want to export this data?</p>
          <div className="justify-center flex space-x-2">
            <Button className="cancel-btn" onClick={() => setConfirmationModalVisible(false)}>
              Cancel
            </Button>
            <Button
              className="save-btn"
              onClick={() => {
                confirmExport();
                handleExportModalClose();
              }}
            >
              OK
            </Button>
          </div>
        </Modal>
        {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
          )} */}
      </div>
    </Suspense>
  );
};
export default DailyUsageReport;
