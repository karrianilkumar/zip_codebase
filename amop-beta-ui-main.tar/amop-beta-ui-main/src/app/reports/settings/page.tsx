"use client";

import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button, List, message, Modal, Spin, Typography } from "antd";
import { DeleteOutlined, EditOutlined, PlusOutlined } from "@ant-design/icons";
import { REPORT_QUERY_KEY } from "@/common/constants/report-constant";
import { ReportSubscriptionType } from "@/types/report/report-subscription-types";
import SubscriberModal from "@/app/reports/tax_reports/components/subscriber-modal";
import { isAxiosError } from "axios";
import {
  deleteSubscriber,
  getSubscribers,
  saveSubscribers,
} from "@/api/report-api";
import { TaxReportTemplateLabels } from "@/common/constants/tax-report-constants";
import { FeatureFlag } from "@/components/feature-flag/feature-flag";
import { ReportFeaturesReportSettingsFeatures } from "@/common/enums/module-feature-enum";

const { Title } = Typography;

interface EmailReceiverSettingsProps {}

const EmailReceiverSettings: React.FC<EmailReceiverSettingsProps> = () => {
  const queryClient = useQueryClient();
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const [currentData, setCurrentData] = useState<ReportSubscriptionType | null>(
    null,
  );
  const [editingId, setEditingId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const {
    data: subscribers,
    isLoading,
    error,
  } = useQuery({
    queryKey: [REPORT_QUERY_KEY.SUBSCRIBERS, currentPage, pageSize],
    queryFn: () => getSubscribers(currentPage, pageSize),
  });

  const saveSubscriberMutation = useMutation({
    mutationFn: saveSubscribers,
    onSuccess: async () =>
      await queryClient.invalidateQueries({
        queryKey: [REPORT_QUERY_KEY.SUBSCRIBERS, currentPage, pageSize],
      }),
  });

  const deleteSubscriberMutation = useMutation({
    mutationFn: deleteSubscriber,
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: [REPORT_QUERY_KEY.SUBSCRIBERS, currentPage, pageSize],
      }),
  });

  const handleAddOrUpdateSubscriber = async (
    values: ReportSubscriptionType,
  ) => {
    try {
      if (typeof values.emails === "string") {
        values.emails = (values.emails as string)
          ?.split(",")
          .map((email) => email.trim());
      }
      if (editingId) {
        values._id = editingId;
      }
      await saveSubscriberMutation.mutateAsync(values);
      setEditingId(null);
      setCurrentData(null);
      setIsModalVisible(false);
      setCurrentPage(1);
      message.success("Subscriber saved successfully");
    } catch (error) {
      if (isAxiosError(error)) {
        message.error(`There was an error! ${error.response?.data.message}`);
      } else {
        message.error(`There was an error! ${error}`);
      }
    }
  };

  const handleDeleteSubscriber = async (id: string) => {
    try {
      await deleteSubscriberMutation.mutateAsync(id);
      message.success("Subscriber deleted successfully");
    } catch (error) {
      if (isAxiosError(error)) {
        message.error(`There was an error! ${error.response?.data.message}`);
      } else {
        message.error(`There was an error! ${error}`);
      }
    }
  };

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    setCurrentData(null);
    setEditingId(null);
  };

  const handlePageChange = (page: number, pageSize?: number) => {
    setCurrentPage(page);
    if (pageSize) {
      setPageSize(pageSize);
    }
  };

  const showDeleteConfirm = (data: ReportSubscriptionType) => {
    Modal.confirm({
      title: "Are you sure you want to delete this subscriber?",
      okText: "Yes, delete it",
      okType: "danger",
      cancelText: "No, cancel",
      onOk() {
        handleDeleteSubscriber(data._id || "");
      },
    });
  };

  if (error) {
    message.error("There was an error fetching the data");
    console.error(error);
    return null;
  }

  return (
    <div className="p-6 bg-white rounded-lg shadow-md max-w-2xl mx-auto">
      <Title level={3} className="text-center">
        Schedule Report Email Subscribers
      </Title>
      <FeatureFlag
        feature={ReportFeaturesReportSettingsFeatures.AddSubscriptions}
      >
        <Button
          icon={<PlusOutlined />}
          onClick={showModal}
          className="my-4"
          type={"primary"}
        >
          Add Subscriptions
        </Button>
      </FeatureFlag>
      <Spin spinning={isLoading}>
        {!isLoading && (
          <List
            pagination={{
              current: currentPage,
              pageSize: pageSize,
              total: subscribers?.totalResults ?? 0,
              align: "center",
              onChange: handlePageChange,
            }}
            grid={{ gutter: 16, column: 1 }}
            dataSource={subscribers?.results || []}
            renderItem={(data: ReportSubscriptionType, index: number) => (
              <List.Item key={index}>
                <div className="flex justify-between items-center p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
                  <div>
                    <p className="mb-2">
                      <strong>Template ID:</strong> {data.templateId} -{" "}
                      {TaxReportTemplateLabels[+data.templateId]}
                    </p>
                    <p>
                      <strong>Emails:</strong> {[data.emails].flat().join(", ")}
                    </p>
                    <p>
                      <strong>Email Subject:</strong> {data.emailSubject}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <FeatureFlag
                      feature={
                        ReportFeaturesReportSettingsFeatures.EditSubscriber
                      }
                    >
                      <Button
                        key="edit"
                        icon={<EditOutlined />}
                        onClick={() => {
                          setCurrentData(data);
                          setEditingId(data._id || null);
                          setIsModalVisible(true);
                        }}
                      />
                    </FeatureFlag>
                    <FeatureFlag
                      feature={
                        ReportFeaturesReportSettingsFeatures.DeleteSubscriber
                      }
                    >
                      <Button
                        key="delete"
                        danger
                        icon={<DeleteOutlined />}
                        onClick={() => showDeleteConfirm(data)}
                      />
                    </FeatureFlag>
                  </div>
                </div>
              </List.Item>
            )}
          />
        )}
      </Spin>

      {isModalVisible && (
        <SubscriberModal
          handleCancel={handleCancel}
          handleAddOrUpdateSubscriber={handleAddOrUpdateSubscriber}
          currentData={currentData}
          editingId={editingId}
        />
      )}
    </div>
  );
};

export default EmailReceiverSettings;
