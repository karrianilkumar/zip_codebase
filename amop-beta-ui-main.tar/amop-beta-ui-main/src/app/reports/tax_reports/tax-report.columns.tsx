import { TableColumnType } from "antd";
import { dateTimeCellRenderer } from "@/components/data-grid-cell-renderers/date-time-cell-renderer";

export const taxReportColumns: TableColumnType<any>[] = [
  {
    title: "Transaction ID",
    dataIndex: "transactionID",
    key: "transactionID",
  },
  {
    title: "Date",
    dataIndex: "dateOfTransaction",
    key: "dateOfTransaction",
    render: dateTimeCellRenderer,
  },
  {
    title: "MRC",
    dataIndex: "mrc",
    key: "mrc",
  },
  {
    title: "Tax Amount",
    dataIndex: "taxAmount",
    key: "taxAmount",
  },
  {
    title: "Sale Amount",
    dataIndex: "saleAmount",
    key: "saleAmount",
  },
  // TODO: Temporarily commented out due to comment on ADM-340
  // {
  //   title: "Profile",
  //   dataIndex: "profile",
  //   key: "profile",
  // },
];
