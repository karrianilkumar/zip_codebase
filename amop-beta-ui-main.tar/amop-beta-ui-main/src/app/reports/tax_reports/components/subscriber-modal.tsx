import { ReportSubscriptionType } from "@/types/report/report-subscription-types";
import { Button, Form, Input, List, Modal, Popover, Select, Tag } from "antd";
import { RuleObject } from "antd/es/form";
import React, { useEffect } from "react";
import { TaxReportTemplate } from "@/common/constants/tax-report-constants";
import { QuestionOutlined } from "@ant-design/icons";
import {
  taxReportSubjectNameCompute,
  TaxReportSubjectNameVars,
} from "@/common/helper/template-helper";

interface SubscriberModalProps {
  handleCancel: () => void;
  handleAddOrUpdateSubscriber: (values: any) => void;
  currentData: ReportSubscriptionType | null;
  editingId: string | null;
}

const createValidationPromise = (isValid: boolean, errorMessage: string) =>
  isValid ? Promise.resolve() : Promise.reject(new Error(errorMessage));

const validateTemplateId = (_: RuleObject, value: any): Promise<void> => {
  const isNumber = !isNaN(value);
  return createValidationPromise(isNumber, "Template ID must be a number");
};

const validateEmails = (_: RuleObject, value: any): Promise<void> => {
  if (!value) {
    return Promise.reject(new Error("Emails field cannot be empty"));
  }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const emails = value.split(",").map((email: string) => email.trim());
  const isValid = emails.every((email: string) => emailRegex.test(email));
  return createValidationPromise(
    isValid,
    "Enter valid emails, separated by commas",
  );
};

const SubscriberModal: React.FC<SubscriberModalProps> = ({
  handleCancel,
  handleAddOrUpdateSubscriber,
  currentData,
  editingId,
}) => {
  const [form] = Form.useForm<ReportSubscriptionType>();

  const emailSubjectComputed = Form.useWatch((values) => {
    return taxReportSubjectNameCompute(values.emailSubject ?? "");
  }, form);

  useEffect(() => {
    if (currentData) {
      form.setFieldsValue({
        templateId: currentData.templateId,
        emails: [currentData.emails].flat().join(", "),
        emailSubject:
          currentData.emailSubject ??
          "Your monthly tax report is ready for {{MMMM}} {{YYYY}}",
      });
    } else {
      form.resetFields();
    }
  }, [currentData, form]);

  return (
    <Modal
      className="adm-wrapper"
      title={editingId !== null ? "Edit Subscriber" : "Add Subscriber"}
      open={true}
      footer={null}
      onCancel={handleCancel}
    >
      <Form<ReportSubscriptionType>
        form={form}
        name="subscriberForm"
        onFinish={handleAddOrUpdateSubscriber}
        layout={"vertical"}
        initialValues={{
          templateId: "",
          emails: [],
          emailSubject:
            "Your monthly tax report is ready for {{MMMM}} {{YYYY}}",
        }}
      >
        <Form.Item
          label={"Template ID"}
          name="templateId"
          rules={[
            { required: true, message: "Please input a template ID!" },
            {
              validator: validateTemplateId,
            },
          ]}
        >
          <Select placeholder="Select a Template ID">
            {Object.entries(TaxReportTemplate).map(([label, value]) => (
              <Select.Option key={value} value={value}>
                {label} - {value}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          label={"Emails"}
          name="emails"
          rules={[
            { required: true, message: "Please input at least one email!" },
            () => ({
              validator: validateEmails,
            }),
          ]}
        >
          <Input placeholder="Enter Emails Separated by Commas" />
        </Form.Item>
        <Form.Item
          label={"Email Subject"}
          name="emailSubject"
          rules={[
            {
              required: true,
              message: "Please input email subject",
            },
          ]}
          help={`Preview: ${emailSubjectComputed}`}
        >
          <Input suffix={<SubjectNameHelpText />} />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Submit
          </Button>
        </Form.Item>
      </Form>
    </Modal>
  );
};

function SubjectNameHelpText() {
  return (
    <Popover
      content={
        <List
          size="small"
          header={"Supported template:"}
          itemLayout={"vertical"}
          dataSource={TaxReportSubjectNameVars}
          renderItem={(varDef) => (
            <List.Item>
              <Tag>{varDef.var}</Tag> {varDef.description}
            </List.Item>
          )}
          rowKey="var"
        />
      }
    >
      <QuestionOutlined />
    </Popover>
  );
}

export default SubscriberModal;
