import { create } from "zustand";

export type RequestExportReportModalStore = {
  open: boolean;
  isSubmitting: boolean;
  isFetching: boolean;
};
export type RequestExportReportModalActions = {
  openModal: () => void;
  closeModal: () => void;
  setIsSubmitting: (isSubmitting: boolean) => void;
  setIsFetching: (isFetching: boolean) => void;
};

const initialState: RequestExportReportModalStore = {
  open: false,
  isSubmitting: false,
  isFetching: false,
};

export const useExportTaxReportStore = create<
  RequestExportReportModalStore & RequestExportReportModalActions
>((set) => ({
  ...initialState,
  openModal: () => set({ open: true }),
  closeModal: () => set(initialState),
  setIsSubmitting: (isSubmitting) => set({ isSubmitting }),
  setIsFetching: (isFetching) => set({ isFetching }),
}));
