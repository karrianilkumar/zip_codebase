import { exportTaxReport } from "@/api/tax-api";
import { EMAIL_SUBJECT_PREFIX } from "@/common/constants/report-constant";
import { TaxReportTemplate } from "@/common/constants/tax-report-constants";
import { useUserInfoStore } from "@/stores/user.store";
import { useMutation } from "@tanstack/react-query";
import { DatePicker, Form, Input, Modal, Select, notification } from "antd";
import dayjs from "dayjs";
import { FC } from "react";
import { useExportTaxReportStore } from "./request-export-report-modal.store";

export const RequestExportReportForm: FC = () => {
  const [form] = Form.useForm<ExportFormValues>();
  const { setIsSubmitting, closeModal } = useExportTaxReportStore();
  const userEmail = useUserInfoStore((state) => state.userInfo?.email || "");

  const { mutateAsync: handleSubmit } = useMutation({
    mutationFn: async (formValues: ExportFormValues) => {
      setIsSubmitting(true);
      return await exportTaxReport({
        reportTemplateId: formValues.reportTemplate,
        dateRange: {
          contentMonth: formValues.month.format("MM"),
          contentYear: formValues.month.format("YYYY"),
        },
        fileType: "xlsx",
        emailSubject: formValues.emailSubject,
      });
    },
    onSuccess: () => {
      setIsSubmitting(false);
      notification.success({
        message: "Report Requested",
        description: <SuccessMessage userEmail={userEmail} />,
      });
      closeModal();
    },
    onError: (error) => {
      setIsSubmitting(false);
      notification.error({
        message: "Failed to request report",
        description: `Error: ${error}`,
      });
    },
  });

  const handleFormValuesChange = (changedValues: Partial<ExportFormValues>) => {
    if (changedValues.month) {
      const emailSubject = `${EMAIL_SUBJECT_PREFIX} ${changedValues.month.format("MMMM YYYY")}`;
      form.setFieldsValue({
        emailSubject,
      });
    }
  };

  return (
    <Form<ExportFormValues>
      form={form}
      id="request-export-tax-reports"
      layout={"vertical"}
      initialValues={{
        reportTemplate: TaxReportTemplate["Invoice Line Detail Report"],
        month: dayjs(),
        emailSubject: `${EMAIL_SUBJECT_PREFIX} ${dayjs().format("MMMM YYYY")}`,
      }}
      onFinish={handleSubmit}
      onValuesChange={handleFormValuesChange}
    >
      <Form.Item
        label="Report Template"
        name="reportTemplate"
        rules={[
          {
            required: true,
            message: "Please select a report template",
          },
        ]}
      >
        <Select>
          {Object.entries(TaxReportTemplate).map(([label, value]) => (
            <Select.Option key={value} value={value}>
              {label}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>
      <Form.Item
        label="Month"
        name={"month"}
        rules={[
          {
            required: true,
            message: "Please select a month",
          },
        ]}
      >
        <DatePicker picker="month" className="w-full" maxDate={dayjs()} />
      </Form.Item>
      <Form.Item
        label="Email Subject"
        name="emailSubject"
        rules={[
          {
            required: true,
            message: "Please enter an email subject",
          },
        ]}
      >
        <Input />
      </Form.Item>
    </Form>
  );
};

export const RequestExportReportModal: FC = () => {
  const { open, isSubmitting, isFetching, closeModal } =
    useExportTaxReportStore();

  return (
    <Modal
      title="Request Export Report"
      open={open}
      destroyOnClose
      maskClosable={false}
      className="adm-wrapper"
      okButtonProps={{
        form: "request-export-tax-reports",
        htmlType: "submit",
        disabled: isSubmitting || isFetching,
        type: "primary",
      }}
      confirmLoading={isSubmitting}
      onCancel={closeModal}
    >
      <RequestExportReportForm />
    </Modal>
  );
};

function SuccessMessage({ userEmail }: { userEmail: string }) {
  return (
    <>
      <p>
        Your Report has been Requested. You will Receive an Email at{" "}
        <strong>{userEmail}</strong> once the Report is Ready.
      </p>
      <p>
        <small>
          Note: The Report may take a few Minutes to Generate. Please Check your
          Spam folder if you do not Receive an Email.
        </small>
      </p>
    </>
  );
}

type ExportFormValues = {
  month: dayjs.Dayjs;
  reportTemplate: number;
  reportName: string;
  emailSubject: string;
};
