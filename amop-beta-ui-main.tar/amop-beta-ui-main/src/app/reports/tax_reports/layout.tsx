import { PropsWithChildren } from "react";
import { FeatureFlagProvider } from "@/components/feature-flag/feature-flag-provider";
import {
  ModuleFeatures,
  ReportFeatures,
} from "@/common/enums/module-feature-enum";

export default function TaxReportsLayout(props: PropsWithChildren) {
  return (
    <div className="p-4 h-full overflow-auto adm-wrapper">
      <FeatureFlagProvider
        parentModule={ModuleFeatures.Reports}
        module={ReportFeatures.TaxReports}
      >
        {props.children}
      </FeatureFlagProvider>
    </div>
  );
}
