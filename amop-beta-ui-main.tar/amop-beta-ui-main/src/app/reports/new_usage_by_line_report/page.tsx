"use client";

import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  AdjustmentsHorizontalIcon,
  ArrowUpTrayIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Popover, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Select,{ MenuListProps } from 'react-select'; // Importing react-select
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import useCrossProviderStore from "@/app/stores/useCrossProviderStore";
import { FilterOutlined } from '@ant-design/icons'; // Import FilterOutlined for the filter icon
import { fireSideCannons } from "@/app/components/confetti";
const { RangePicker } = DatePicker;

//Lazy Loading Components
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const CreateModal = lazy(() => import("@/app/components/createPopup"));
import { FixedSizeList as List } from 'react-window';
import { DropdownStyles, NonEditableDropdownStyles } from "@/app/components/css/dropdown";
// Define the type for options (adjust based on your data structure)
interface OptionType {
  value: string | number;
  label: string;
  children?: any;
}

const NewUsageByLineReport: React.FC = () => {

  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<any>({});
  const [features, setFeatures] = useState<string[]>([]);
  const hasFetchedData = useRef(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, tenantId, tenantName, selectedDb, metaData,advancedStoredpagination, storedpagination, firstLastName, sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns } = useAuth();
  const [tableData, setTableData] = useState<any[]>([]);
  const title = useLogoStore((state) => state.title);
  const [pagination, setpagination] = useState<any>({});
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isFilterClicked, setIsFilterClicked] = useState(false);

  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  //export functionality
  const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport, exports } = exportLoadingStore();
  const { setUsageByLineFilter, setUsageByLineFilterData, usageByLineFilter ,usageByLineFilterData} = useCrossProviderStore();
  const exportKey = "New Usage By Line Report";
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  // Add these state variables at the top of the component
  const [isConfirmationModalVisible, setConfirmationModalVisible] = useState(false);
  const [isCrossCarrier, setIsCrossCarrier] = useState(false);
  const [serviceProviders, setServiceProviders] = useState<string[]>([]);
  const [billingCyclePeriods, setBillingCyclePeriods] = useState<string[]>([]);
  // Add this to your state variables
  const [billingPeriodDates, setBillingPeriodDates] = useState<Record<string, string[]>>({});
  // Add this default value to your serviceProviders state
  const [selectedServiceProvider, setSelectedServiceProvider] = useState<{ value: any; label: string } | null>({
    value: "All service providers",
    label: "All service providers",
  });
  const [selectedBillingCyclePeriod, setSelectedBillingCyclePeriod] = useState<any>([]);
  const [selectedCrossBillingPeriod, setSelectedCrossBillingPeriod] = useState<{ value: any; label: string } | null>();
  const [errorMessage, setErrorMessage] = useState<string>(""); // State to hold error messages
 
// Virtualized MenuList Component with proper TypeScript types
const VirtualizedMenuList: React.FC<MenuListProps<OptionType>> = ({
  options,
  children,
  maxHeight,
  getValue,
}) => {
  const itemHeight = 35; // Height of each option in pixels
  const [value] = getValue();
  const initialOffset = options.indexOf(value) * itemHeight;

  return (
    <List
      height={Math.min(maxHeight, 300)} // Set max height for the dropdown
      itemCount={Array.isArray(children) ? children.length : 0}
      itemSize={itemHeight}
      initialScrollOffset={initialOffset}
      width="100%"
    >
       {({ index, style }) => <div style={style}>{(children as React.ReactChild[])[index]}</div>}

    </List>
  );
};
  
  //Remove columns based on role
      // useEffect(() => {
      //   if (role?.toLowerCase() !== "super admin" && role?.toLowerCase() !== "partner admin" && role?.toLowerCase() !== "agent partner admin") {
      //     const removeHeaderList = Object.keys(headerMap).filter(
      //       (key) =>
      //         [ "cycle end date"].includes(
      //           headerMap[key][0]?.toLowerCase()
      //         )
      //     );
      
      //     setHeaders((prevHeaders) =>
      //       prevHeaders.filter((header) => !removeHeaderList.includes(header))
      //     );
      //   }
      //   // if (role?.toLowerCase() === "agent") {
      //   //   const removeHeaderList = Object.keys(headerMap).filter(
      //   //     (key) =>
      //   //       ["cycle end date"].includes(
      //   //         headerMap[key][0]?.toLowerCase()
      //   //       )
      //   //   );
      
      //   //   setHeaders((prevHeaders) =>
      //   //     prevHeaders.filter((header) => !removeHeaderList.includes(header))
      //   //   );
      //   // }
      // }, [role,headerMap]);

  //Remove Cycle End Date when Cross provider is on
  useEffect(() => {
    if (isCrossCarrier) {
      const removeHeaderList = Object.keys(headerMap).filter(
            (key) =>
              ["cycle end date"].includes(
                headerMap[key][0]?.toLowerCase()
              )
          );
      
          setHeaders((prevHeaders) =>
            prevHeaders.filter((header) => !removeHeaderList.includes(header))
          );
    }
    else{
      const removeHeaderList = Object.keys(headerMap).filter(
            (key) =>
              ["customer cycle end date"].includes(
                headerMap[key][0]?.toLowerCase()
              )
          );
      
          setHeaders((prevHeaders) =>
            prevHeaders.filter((header) => !removeHeaderList.includes(header))
          );
    }
  }, [isCrossCarrier,headerMap]);

  // Add a new function to fetch dropdown data
//  const fetchExportDropdownData = async () => {
//   setExportModalOpen(true);
//   try {
//     setExportLoading(true);

//     const url = ENV_ROUTES.MODULE_MANAGEMENT;

//     // Step 1: Define base payload (without is_size_exceeded)
//     const basePayload = {
//       tenant_name: partner || "default_value",
//       username,
//       path: "/reports_dropdown_data_export",
//       role_name: role,
//       parent_module: "Reports",
//       module: "New Usage By Line Report",
//       request_received_at: getCurrentDateTime(),
//       access_token: token,
//       db_name: selectedDb,
//       sessionID: sessionId,
//     };

//     let parsedData: any;

//     // Step 2: First attempt – normal call
//     try {
//       const response = await axios.post(url, { data: basePayload });

//       parsedData = JSON.parse(response.data.body);

//       // Step 2a: If we receive the size error – go to fallback
//       if (parsedData?.errorMessage?.includes("Response payload size exceeded")) {
//         throw new Error("SIZE_LIMIT");
//       }
//     } catch (err: any) {
//       // Step 3: Handle fallback case with is_size_exceeded: true
//       if (err.message === "SIZE_LIMIT") {
//         try {
//           const retryResponse = await axios.post(url, {
//             data: { ...basePayload, is_size_exceeded: true },
//           });

//           const retryData = JSON.parse(retryResponse.data.body);

//           if (!retryData?.s3_path) {
//             throw new Error("No s3_path provided in large payload fallback");
//           }

//           const s3Response = await axios.get(retryData.s3_path);
//           parsedData = s3Response.data;
//         } catch (fallbackError) {
//           throw new Error("Failed to load large export data from S3.");
//         }
//       } else {
//         // Non size-related errors
//         console.error("Dropdown fetch error:", err);
//         throw new Error("An error occurred while fetching export dropdown data.");
//       }
//     }

//     // Step 4: Use parsedData to populate dropdowns
//     if (
//       !parsedData ||
//       !parsedData.unique_service_providers ||
//       !parsedData.billing_period_dates
//     ) {
//       throw new Error("Invalid response. Required data is missing.");
//     }

//     setServiceProviders(parsedData.unique_service_providers || []);
//     setBillingPeriodDates(parsedData.billing_period_dates || {});
//     const cross_carrier_optimization = parsedData?.cross_provider || false;
//     setIsCrossCarrier(cross_carrier_optimization);

//     if (parsedData.unique_service_providers.length > 0) {
//       const firstProvider = parsedData.unique_service_providers[0];
//       const defaultProvider = {
//         value: firstProvider || "",
//         label: firstProvider || "",
//       };
//       setSelectedServiceProvider(defaultProvider);

//       const defaultPeriods = parsedData.billing_period_dates[defaultProvider.value] || [];

//       if (cross_carrier_optimization) {
//         const defaultPeriodsOptions = Object.keys(defaultPeriods) || [];
//         setBillingCyclePeriods(defaultPeriodsOptions);
//       } else {
//         setBillingCyclePeriods(defaultPeriods);
//       }
//     }
//   } catch (error: any) {
//     console.error("Export dropdown error:", error);
//     Modal.error({
//       title: "Error",
//       content: error?.message || "An error occurred while fetching export dropdown data",
//     });
//   } finally {
//     setExportLoading(false);
//   }
// };
const fetchExportDropdownData = async () => {
  
  // Helper function
  const sleep = (ms: number) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
  };

  // setExportModalOpen(true);
  setExportLoading(true);

  const baseUrl = ENV_ROUTES.MODULE_MANAGEMENT;

  const basePayload = {
    tenant_name: partner || "default_value",
    username,
    path: "/reports_dropdown_data_export",
    role_name: role,
    parent_module: "Reports",
    module: "New Usage By Line Report",
    request_received_at: getCurrentDateTime(),
    access_token: token,
    db_name: selectedDb,
    ... metaData,
    sessionID: sessionId,
  };

  const isTimeoutError = (error: any) => {
    const status = error?.response?.status;
    const message = error?.response?.data?.message;
    return status === 504 || message === "Endpoint request timed out";
  };

  const pollExportStatus = async () => {
    console.info("🔃 Polling /get_export_status for completion...");
    const MAX_POLLS = 36; // 36 * 5s = 3 minutes
    
    for (let i = 0; i < MAX_POLLS; i++) {
      await sleep(5000); // Wait 5 seconds before each poll
      
      try {
        const statusPayload = {
          tenant_name: partner || "default_value",
          username,
          path: "/get_export_status", // ✅ Changed path for status polling
          role_name: role,
          parent_module: "Reports",
          module_name: "New Usage By Line Report",
          access_token: token,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
        };

        const statusResp = await axios.post(baseUrl, {
          data: statusPayload
        });
        
        let statusBody = statusResp.data.body;
        if (typeof statusBody === "string") {
          statusBody = JSON.parse(statusBody);
        }


        // ✅ Check the actual response structure you provided
        if (statusBody.flag && statusBody.export_status_data) {
          const exportData = statusBody.export_status_data;
          
          // Check for success
          if (exportData.status_flag === "Success" && exportData.url) {
            console.info(`✅ Export completed! URL: ${exportData.url}`);
            return exportData.url;
          }
          
          // Still waiting
          if (exportData.status_flag === "Waiting") {
            console.debug(`⏳ Still waiting... (${i + 1}/${MAX_POLLS}) - ID: ${exportData.id}`);
            continue;
          }
          
          // Check for failure
          if (exportData.status_flag === "Failure") {
            throw new Error(`Export failed with status: ${exportData.status_flag} - ID: ${exportData.id}`);
          }

          // Unknown status
        } else {
          console.warn("⚠️ Unexpected response structure:", statusBody);
        }
        
      } catch (statusErr: any) {
        if (i === MAX_POLLS - 1) {
          throw new Error("Failed to get export status after multiple attempts");
        }
      }
    }

    throw new Error("Export did not complete within expected time (3 minutes).");
  };

  try {
    let parsedData: any;
    let firstResponse :any;
    let didFallback = false;

    // ─── STEP 1: Try normal invocation ─────────────────────────────────────────────
    try {
      firstResponse = await axios.post(baseUrl, { data: basePayload });
    } catch (err: any) {
      if (!isTimeoutError(err)) {
        throw err; // Some other error → bubble up
      }
      console.warn("⏱️ First call timed out. Retrying with is_size_exceeded: true...");
      didFallback = true;
    }

    // ─── STEP 2: Fallback with is_size_exceeded: true ──────────────────────────────
    let fallbackBody: any;
    let fallbackTimedOut = false;
    
    if (didFallback) {
      try {
        const fallbackResp = await axios.post(baseUrl, {
          data: { ...basePayload, is_size_exceeded: true },
        });
        fallbackBody = typeof fallbackResp.data.body === "string"
          ? JSON.parse(fallbackResp.data.body)
          : fallbackResp.data.body;
      } catch (fallbackErr: any) {
        if (isTimeoutError(fallbackErr)) {
          console.warn("⏱️ Second call also timed out. Will poll /get_export_status...");
          fallbackTimedOut = true;
        } else {
          throw fallbackErr;
        }
      }
    } else {
      // No timeout → check if function flagged response too large
      const errType = firstResponse.data.errorType;
      if (errType === "Function.ResponseSizeTooLarge") {
        console.warn("📦 Response too large. Retrying with is_size_exceeded: true...");
        try {
          const fallbackResp = await axios.post(baseUrl, {
            data: { ...basePayload, is_size_exceeded: true },
          });
          fallbackBody = typeof fallbackResp.data.body === "string"
            ? JSON.parse(fallbackResp.data.body)
            : fallbackResp.data.body;
        } catch (fallbackErr: any) {
          if (isTimeoutError(fallbackErr)) {
            console.warn("⏱️ Second call also timed out. Will poll /get_export_status...");
            fallbackTimedOut = true;
          } else {
            throw fallbackErr;
          }
        }
      } else {
        // Normal success
        let body = firstResponse.data.body;
        if (typeof body === "string") body = JSON.parse(body);
        parsedData = body;
      }
    }

    // ─── STEP 3: Handle second timeout by polling status ───────────────────────────
    if (fallbackTimedOut) {
      const exportUrl = await pollExportStatus();
      const s3Resp = await axios.get(exportUrl);
      parsedData = s3Resp.data;
    }
    // ─── STEP 4: Handle normal fallback response ────────────────────────────────────
    else if (!parsedData && fallbackBody) {
      // Case A: immediate S3 URL
      if (fallbackBody.s3_path) {
        const s3Resp = await axios.get(fallbackBody.s3_path);
        parsedData = s3Resp.data;
      }
      // Case B: jobId + polling (if your API returns job_id)
      else if (fallbackBody.job_id) {
        const exportUrl = await pollExportStatus();
        const s3Resp = await axios.get(exportUrl);
        parsedData = s3Resp.data;
      }
      else {
        throw new Error("Fallback did not return s3_path or job_id. Unable to proceed.");
      }
    }

    // ─── STEP 5: Validate & set state ───────────────────────────────────────────────
    if (
      !parsedData ||
      !Array.isArray(parsedData.unique_service_providers) ||
      typeof parsedData.billing_period_dates !== "object"
    ) {
      console.warn("⚠️ Unexpected shape:", parsedData);
      throw new Error("Invalid response. Missing required keys.");
    }

    setServiceProviders(parsedData.unique_service_providers);
    setBillingPeriodDates(parsedData.billing_period_dates);
    if(!isCrossCarrier){
    setIsCrossCarrier(parsedData.cross_provider || false);
    }

    // Pick defaults
    const firstProv = parsedData.unique_service_providers[0];
    if (firstProv) {
      const defaultProv = { value: firstProv, label: firstProv };
      setSelectedServiceProvider(defaultProv);

      const periods = parsedData.billing_period_dates[firstProv] || [];
      setBillingCyclePeriods(
        parsedData.cross_provider ? Object.keys(periods) : periods
      );
    }

  } catch (error: any) {
    console.error("❌ fetchExportDropdownData error:", error);
    Modal.error({
      title: "Error fetching export data",
      content: error.message || String(error),
    });
  } finally {
    setExportLoading(false);
  }
};
  const handleExportModalOpen = () => {
    // fetchExportDropdownData().then(() => {
      setExportModalOpen(true);
    // });
    if(!isCrossCarrier){
      fetchExportDropdownData()
    }
  };

  // const handleServiceProviderChange = (selectedOption: any) => {
  //   setSelectedServiceProvider(selectedOption);
  //   setSelectedBillingCyclePeriod(null); // Reset billing cycle period when changing service provider

  //   const periods = billingPeriodDates[selectedOption.value] || [];
  //   setBillingCyclePeriods(periods);
  // };

  const handleServiceProviderChange = (selectedOption: any) => {
    setSelectedCrossBillingPeriod(null)
    setSelectedBillingCyclePeriod([])
    setSelectedServiceProvider(selectedOption);
    console.log("selectedOption",selectedOption)
    // Reset billing cycle period when changing service provider
    // setBillingCyclePeriods(periods);

    const defaultProvider = isCrossCarrier ? `${selectedOption.label}-${selectedOption.value}` : selectedOption.value

    const periods = billingPeriodDates[defaultProvider] || [];
    if (isCrossCarrier) {
      const defaultPeriodsOptions = Object.keys(periods) || [];
      setBillingCyclePeriods(defaultPeriodsOptions);
      if (selectedOption.label !== "All Customers" && defaultPeriodsOptions.length > 0) {
        const defaultPeriodsOptions = Object.keys(periods) || [];
        const label: any = defaultPeriodsOptions[0] || ""
        const value = periods[label] || ""
        console.log("isCrossCarrier", { value: value, label: label })
        // setSelectedBillingCyclePeriod([{ value: value, label: label }]); // Set first value as default
      }
    }
    else {
      setBillingCyclePeriods(periods);
      if (selectedOption.value !== "All service providers" && periods.length > 0) {
        // setSelectedBillingCyclePeriod([{ value: periods[0], label: periods[0] }]); // Set first value as default
      }
    }
  };


  const handleExportClick = () => {
    // Clear previous error message
    setErrorMessage("");

    // Immediate validation when the export button is clicked
    if (!selectedServiceProvider) {
      setErrorMessage(`Please select a ${isCrossCarrier ? "Customer" : "Service Provider"}.`);
      return; // Stop further execution
    }

    if (selectedServiceProvider.value !== "All service providers" && selectedServiceProvider.label !== "All Customers" && selectedBillingCyclePeriod.length === 0 && !selectedCrossBillingPeriod) {
      setErrorMessage("Please select a billing cycle Period.");
      return; // Stop further execution
    }

    // If all validations pass, show the confirmation modal
    if (isFilterClicked) {
      handleFilterClicked()
    }
    else {
      setConfirmationModalVisible(true);
    }

  };
  const handleExportModalClose = () => {
    setExportModalOpen(false);
    setDateRange([null, null]); // Reset date range
    setSelectedServiceProvider(null);
    setSelectedBillingCyclePeriod([]);
    setSelectedCrossBillingPeriod(null)
  };
  const confirmExport = async () => {
    setConfirmationModalVisible(false);
    await ExportWithoutSearch("New Usage By Line Report", "New Usage By Line Report") // Call the export function with the selected values
  };
  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"New Usage By Line Report":visibleColumns}))
      }, [visibleColumns]);
  const fetchData = async () => {
    setCombineAdnvaceStoredpagination(null);
    setLoading(true);
    settabledata([])
    setUsageByLineFilter(false)
    setUsageByLineFilterData([])
    try {
      const url =
        ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/reports_data",
        role_name: role,
        parent_module: "Reports",
        module_name: "New Usage By Line Report",
        feature_module_name: "New Usage By Line Report",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        table_name: "vw_usage_by_line_report2_v20",
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        const tableData = parsedData?.data || [];
        const headerMap =
          parsedData.headers_map?.["New Usage By Line Report"]?.[
          "header_map"
          ] || {};
        // const features = parsedData.headers_map["Bandwidth Customers"]["module_features"]

        // console.log("features", features)
        // setFeatures(features)
        // const createModalData = parsedData.headers_map["Bandwidth Customers"]["pop_up"]
        const sortedheaderMap = sortHeaderMap(headerMap);
        // const generalFields = parsedData.data
        const features_ = parsedData?.headers_map?.["New Usage By Line Report"]?.module_features || []
        setFeatures(features_)
        const pagination_ = parsedData?.pages || {};
        setpagination(pagination_);
        // setgeneralFields(generalFields)
        setHeaderMap(headerMap);
        // setcreateModalData(sortPopup(createModalData))
        setTableData(tableData);
        // settabledata(tableData)
        const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
          const dynamic_cols=dynamicColumns?.["New Usage By Line Report"] && dynamicColumns["New Usage By Line Report"].length>0 ?dynamicColumns["New Usage By Line Report"] :headers_ || headers_
          setVisibleColumns(dynamic_cols)
        setLoading(false);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false); // Ensure loading is set to false in the finally block
    }
  };
  const fetchCrossProviderValue = async () => {
    // setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_carrier_optimization",
        role_name: role,
        parent_module: "Reports",
        module_name: "New Usage By Line Report",
        feature_module_name: "New Usage By Line Report",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const crossProvider_ = parsedData?.cross_carrier_optimization || false
        if(crossProvider_){
          fetchExportDropdownData()
        }
        setIsCrossCarrier(crossProvider_)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      // setLoading(false);

    }
  };

  useEffect(() => {

    if (!hasFetchedData.current) {
      // Check if data has already been fetched
      fetchData();
      fetchCrossProviderValue()
      hasFetchedData.current = true; // Set to true after fetching
    }
  }, []);
  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  };

  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  };

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
    setNewRowData({});
  };
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const handleCreateRow = (newRow: any, tableData: any) => {
    handleCreateModalClose();
  };



  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async (key: string, heading: string) => {
    try {
      // setExportLoading(true)
      if(!usageByLineFilter){
        addExport(key, heading);
      }

      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };

      const periodsList = isCrossCarrier ? selectedCrossBillingPeriod?.value || 0 : selectedBillingCyclePeriod.map((period: any) => period.value);
      console.log("selectedCrossBillingPeriod", selectedCrossBillingPeriod)
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data_ = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Reports",
        module_name: "New Usage By Line Report",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        feature_module_name: "New Usage By Line Report",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        service_provider: selectedServiceProvider?.value === "All service providers" || selectedServiceProvider?.label === "All Customers" ? "" : selectedServiceProvider?.value, // Send only the value
        billing_cycle_period: isCrossCarrier ? periodsList : selectedBillingCyclePeriod.length > 0 ? periodsList : "", // Send only the value
      };

      const data=!usageByLineFilter?data_:{...usageByLineFilterData,path:"/export_to_s3_bucket"}
      console.log("data_",data)
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));

      // Polling for the second API

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
      removeExport(key); // Remove the export from the store
    }
  }

  const pollExportStatus = async () => {
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_export_status",
      role_name: role,
      parent_module: "Reports",
      module_name: "New Usage By Line Report",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ... metaData,
      sessionID: sessionId,
    };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'New Usage By Line Report.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                            fireSideCannons()
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      // Check for "No Data Found for export"
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
        Modal.info({
          title: "Export Information",
          content: "No Data Found for export",
          centered: true,
        });
        return true; // Stop polling
      }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

 const pollFilterStatus = async (payload: any) => {
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_export_status",
      role_name: role,
      parent_module: "Reports",
      module_name: payload.module_name || "New Usage By Line Report",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ... metaData,
      sessionID: sessionId,
    };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        console.log("s3Url........", s3Url)
        if (s3Url) {
          fetch(s3Url)
            .then((response) => response.json())
            .then((data) => {
              console.log("if     data", data)
              if (data.length === 0) {
                Modal.info({
                  title: "Filter Information",
                  content: "No Data Found for filter",
                  centered: true,
                });
              }
              else {
                setUsageByLineFilter(true)
                setUsageByLineFilterData(payload)
                settabledata(data)
              }
              // settabledata(data); // Update the state with the fetched JSON data
            })
            .catch((error) => {
              console.error("Error fetching JSON data:", error);
              Modal.error({
                title: "Filter Error",
                content: "Failed to fetch the filtered data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Filter Error",
            content: export_parsedData.message || "An error occurred while filtering data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Filter Error",
          content: export_parsedData.message || "An error occurred while filtering data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      // Check for "No Data Found for export"
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for Filter") {
        Modal.info({
          title: "Filter Information",
          content: "No Data Found for filter",
          centered: true,
        });
        return true; // Stop polling
      }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Filter Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };
  const startFilterPolling = async (data: any) => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollFilterStatus(data);
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

 const handleFilterClicked = async () => {
    let data;
    try {
      setLoading(true)

      const periodsList = isCrossCarrier ? selectedCrossBillingPeriod?.value || 0 : selectedBillingCyclePeriod.map((period: any) => period.value);
      console.log("selectedCrossBillingPeriod", selectedCrossBillingPeriod)
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      data = {
        tenant_name: partner || "default_value",
        username,
        path: "/get_customer_user_by_line_report_view_data",
        role_name: role,
        parent_module: "Reports",
        module_name: "New Usage By Line Report",
        request_received_at: getCurrentDateTime(),
        mod_pages: {
          start: 0,
          end: 100,
        },
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        feature_module_name: "New Usage By Line Report",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        service_provider: selectedServiceProvider?.value === "All service providers" || selectedServiceProvider?.label === "All Customers" ? "" : selectedServiceProvider?.value, // Send only the value
        billing_cycle_period: isCrossCarrier ? periodsList : selectedBillingCyclePeriod.length > 0 ? periodsList : "", // Send only the value
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        setUsageByLineFilter(true)
        setUsageByLineFilterData({ ...data })
        const tableData_ = parsedData?.data || [];
        if (tableData_.length === 0) {
          Modal.info({
            title: "Filter Information",
            content: "No Data Found for filter",
            centered: true,
          });
        }
        else {
          settabledata(tableData_)
        }
      }

    } catch (error) {
      if(data){
        data.module_name = "New Usage By Line Report View"
      }
      await startFilterPolling(data);
      // Modal.error({
      //   title: "Filter Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      //   centered: true,
      // });
    } finally {
      setLoading(false);
      handleExportModalClose()
    }
  }

  const handleExport = async (key: string, heading: string) => {
    setIsFilterClicked(false)
    try {
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          index_name: "usage_by_line_report2",
          module_name: "New Usage By Line Report",
        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        // setExportLoading(true)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "New Usage By Line Report",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "usage_by_line_report2",
          pages: {
            start: 0,
            end: 100
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        // setExportLoading(true)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "New Usage By Line Report",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "usage_by_line_report2",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if(usageByLineFilter){
        await ExportWithoutSearch("New Usage By Line Report", "New Usage By Line Report")
      }
      else {
        handleExportModalOpen()
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        if (parsedData.flag === true) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // // setExportLoading(false)
            // notification.success({
            //   message: 'Success',
            //   description: 'Successfully exported the record!',
            //   style: messageStyle,
            //   placement: 'top',
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'New Usage By Line Report.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                              fireSideCannons()
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          }
          else {
            // setExportLoading(false)
            Modal.error({
              title: "Export Error",
              content: parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }
        }
        else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      }
    } catch (error) {
      await startPolling();
      // setExportLoading(false)
      // setLoading(false);
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
  const downloadBlob = (base64Blob: string) => {
    // Decode the Base64 string
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "New Usage By Line Report.xlsx"; // Set the file name to .xlsx
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day"); // Disable future dates
  };

  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="relative">
        <div className="px-4 flex  md:flex-row md:items-center md:justify-between  space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            <>
              {features.includes("Search-New Usage by line report") && !usageByLineFilter && (
                <TableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"usage_by_line_report2"}
                  headerMap={headerMap}
                />
              )}
            </>
            <>
              {isCrossCarrier ? (
                <div className="hidden md:flex relative w-full md:w-auto">
                  <button
                    className="save-btn"
                    onClick={() => {
                      setIsFilterClicked(true);
                      handleExportModalOpen();
                    }}
                  >
                    <span>Customer Billing Filter</span>
                  </button>
                  {usageByLineFilter && !storedpagination && (
                    <div
                      className="absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center bg-red-500 cursor-pointer"
                      onClick={fetchData}
                    >
                      <span>X</span>
                    </div>
                  )}
                </div>
              ) : (
                <>
                  {features.includes("Advanced filter-New Usage by line report") && (
                    <AdvancedMultiFilter
                      showAdvanced={showAdvanced}
                      setShowAdvanced={setShowAdvanced}
                      onFilter={handleFilter}
                      onReset={handleReset}
                      headers={headers}
                      headerMap={headerMap}
                      tableName={"usage_by_line_report2"}
                    />
                  )}
                </>
              )}
            </>
          </div>
          {/* Export and ColumnFilter Container */}
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-first pb-2 md:pb-4">
            {features.includes("Export-New Usage by line report") && (
              <button
                className="save-btn"
                onClick={() => {
                  if (!exports.some((exportItem) => exportItem.popupHeading === "New Usage By Line Report")) {
                    handleExport("NewUsageByLineReport", "New Usage By Line Report");
                  }
                }}
              >
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-1" />
                <span>Export</span>
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
  
        <div className="mb-4 space-x-2">
          {/* Commented out section remains unchanged */}
        </div>
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            popupHeading="New Usage By Line Report"
            createModalData={createModalData}
            pagination={pagination}
            generalFields={generalFields}
            advancedFilters={filteredData}
            height={showAdvanced ? 280 : 230}
          />
        </div>
        <CreateModal
          isOpen={isCreateModalOpen}
          onClose={handleCreateModalClose}
          onSave={handleCreateRow}
          columnNames={createModalData}
          heading="New Usage By Line Report"
          header={tableData && tableData.length > 0 ? Object.keys(tableData[0]) : []}
          generalFields={generalFields}
          tableData={tableData}
        />
        {/* Sticky Footer for Small Screens */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
          {features.includes("Export-New Usage by line report") && (
            <button
              className="save-btn"
              onClick={() => {
                if (!exports.some((exportItem) => exportItem.popupHeading === "New Usage By Line Report")) {
                  handleExport("NewUsageByLineReport", "New Usage By Line Report");
                }
              }}
            >
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
            </button>
          )}
          {isCrossCarrier && (
            <button
              className="save-btn"
              onClick={() => {
                setIsFilterClicked(true);
                handleExportModalOpen();
              }}
              aria-label="Open customer billing filter"
            >
              <FilterOutlined className="h-5 w-5 text-black-500" />
            </button>
          )}
          <ColumnFilter
            headers={headers}
            visibleColumns={visibleColumns}
            setVisibleColumns={setVisibleColumns}
            headerMap={headerMap}
          />
       </div>                                
        <Modal
          title={isFilterClicked ? "Filter Output" : "Export Output"}
          visible={isExportModalOpen}
          onCancel={handleExportModalClose}
          footer={null}
          centered
        >
          {exportLoading ? (
            <div className="flex justify-center items-center h-64">
              <Spin size="large" />
            </div>
          ) : (
            // <div className="flex flex-col space-y-3">
            //   <label>{isCrossCarrier ? "Customer" : "Service Provider"}</label>
            //   <Select
            //     options={serviceProviders.map(provider => {
            //       if (isCrossCarrier) {
            //         const parts = provider.split("-");
            //         return {
            //           value: Number(parts.pop() ?? 0), // Convert to number, default to 0
            //           label: parts.join("-") || provider // Use original provider if empty
            //         };
            //       }
            //       return { value: provider, label: provider };
            //     })}
            //     onChange={handleServiceProviderChange}
            //     placeholder="Select Service Provider"
            //     value={selectedServiceProvider}
            //   />      
            //   <label>Billing Cycle Period</label>
            //   <Select
            //     isMulti={!isCrossCarrier}
            //     options={billingCyclePeriods.some(period => !period || period === "null")
            //       ? []: // If any period is null, return an empty options array
            //       billingCyclePeriods.map(period => {
            //       const defaultProvider: any = isCrossCarrier ? `${selectedServiceProvider?.label || ""}-${selectedServiceProvider?.value || ""}` : selectedServiceProvider?.value
            //       const periods = billingPeriodDates[defaultProvider] || [];
            //       const label_: any = period
            //       const value_ = periods[label_] || ""
            //       if (isCrossCarrier) {
            //         return {
            //           value: value_, // Ensure value is always a string
            //           label: label_ || period // Use original provider if empty
            //         };
            //       }
            //       return { value: period, label: period };
            //     })}
            //     // options={billingCyclePeriods.map(period => ({ value: period, label: period }))}
            //     onChange={(selectedOptions: any) => {
            //       if (isCrossCarrier) {
            //         setSelectedCrossBillingPeriod(selectedOptions);
            //       } else {
            //         setSelectedBillingCyclePeriod(selectedOptions || null);
            //       }
            //     }}
            //     placeholder="Select Billing Cycle Period"
            //     isDisabled={
            //       selectedServiceProvider?.value === "All service providers" ||
            //       selectedServiceProvider?.label === "All Customers"
            //     }
            //     value={isCrossCarrier ? selectedCrossBillingPeriod : selectedBillingCyclePeriod}
            //   />
            //   {errorMessage && <p className="text-red-500">{errorMessage}</p>}
            //   <div className="flex justify-center space-x-2">
            //     <button className="cancel-btn" onClick={handleExportModalClose}>
            //       Cancel
            //     </button>
            //     <button className="save-btn" onClick={handleExportClick}>
            //       {isFilterClicked ? "Filter" : "Export"}
            //     </button>
            //   </div>
            // </div>
            <div className="flex flex-col space-y-3">
      <label>{isCrossCarrier ? 'Customer' : 'Service Provider'}</label>
      <Select
        components={{ MenuList: VirtualizedMenuList }}
        options={serviceProviders.map((provider) => {
          if (isCrossCarrier) {
            const parts = provider.split('-');
            return {
              value: Number(parts.pop() ?? 0),
              label: parts.join('-') || provider,
            };
          }
          return { value: provider, label: provider };
        })}
        onChange={handleServiceProviderChange}
        styles={DropdownStyles}
        placeholder="Select Service Provider"
        value={selectedServiceProvider}
        filterOption={(option, rawInput) => {
          // Faster, case-insensitive match
          return option.label.toLowerCase().includes(rawInput.toLowerCase());
        }}
      />
      <label>Billing Cycle Period</label>
      <Select
        components={{ MenuList: VirtualizedMenuList }}
        isMulti={!isCrossCarrier}
        styles={selectedServiceProvider?.value === 'All service providers' ||
          selectedServiceProvider?.label === 'All Customers'?NonEditableDropdownStyles:DropdownStyles}
        options={
          billingCyclePeriods.some((period) => !period || period === 'null')
            ? []
            : billingCyclePeriods.map((period) => {
                const defaultProvider = isCrossCarrier
                  ? `${selectedServiceProvider?.label || ''}-${selectedServiceProvider?.value || ''}`
                  : selectedServiceProvider?.value;
                const periods = billingPeriodDates[defaultProvider] || [];
                const label_ = period as any;
                const value_ = periods[label_] || '';
                if (isCrossCarrier) {
                  return {
                    value: value_,
                    label: label_ || period,
                  };
                }
                return { value: period, label: period };
              })
        }
        onChange={(selectedOptions: any) => {
          if (isCrossCarrier) {
            setSelectedCrossBillingPeriod(selectedOptions);
          } else {
            setSelectedBillingCyclePeriod(selectedOptions || null);
          }
        }}
        placeholder="Select Billing Cycle Period"
        isDisabled={
          selectedServiceProvider?.value === 'All service providers' ||
          selectedServiceProvider?.label === 'All Customers'
        }
        value={isCrossCarrier ? selectedCrossBillingPeriod : selectedBillingCyclePeriod}
        filterOption={(option, rawInput) => {
          // Faster, case-insensitive match
          return option.label.toLowerCase().includes(rawInput.toLowerCase());
        }}
      />
      {errorMessage && <p className="text-red-500">{errorMessage}</p>}
      <div className="flex justify-center space-x-2">
        <button className="cancel-btn" onClick={handleExportModalClose}>
          Cancel
        </button>
        <button className="save-btn" onClick={handleExportClick}>
          {isFilterClicked ? 'Filter' : 'Export'}
        </button>
      </div>
    </div>
          )}
        </Modal>
        <Modal
          title="Confirm Export"
          visible={isConfirmationModalVisible}
          footer={null}
          centered
        >
          <p>Are you sure want to Export this data</p>
          <div className="justify-center flex space-x-2">
            <Button
              className="cancel-btn"
              onClick={() => {
                setConfirmationModalVisible(false);
              }}
            >
              Cancel
            </Button>
            <Button
              className="save-btn"
              onClick={() => {
                confirmExport();
                handleExportModalClose();
              }}
            >
              OK
            </Button>
          </div>
        </Modal>
      </div>
    </Suspense>
  );
};
export default NewUsageByLineReport;
