"use client";

import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import {
    ArrowDownTrayIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Select from 'react-select'; // Importing react-select
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import TableComponent from "@/app/components/TableComponent/page";
import { fireSideCannons } from "@/app/components/confetti";

//Lazy Loading Components
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);
// const TableComponent = lazy(
//   () => import("@/app/components/TableComponent/page")
// );

const ActiveLinesReport: React.FC = () => {
    const [features, setFeatures] = useState<string[]>([]);
    const hasFetchedData = useRef(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [loading, setLoading] = useState(true);
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const { username, partner, role, settabledata, token, tenantId, tenantName, selectedDb, metaData, advancedStoredpagination, storedpagination, firstLastName, sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination, dynamicColumns, setDynamicColumns } = useAuth();
    const [tableData, setTableData] = useState<any[]>([]);
    const [pagination, setpagination] = useState<any>({});
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [filteredData, setFilteredData] = useState([]);
    const [showAdvanced, setShowAdvanced] = useState(false);
    const { addExport, removeExport, exports } = exportLoadingStore();
    const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
    useEffect(() => {
        setDynamicColumns((prev: any) => ({ ...prev, "Active Lines Report": visibleColumns }))
    }, [visibleColumns]);

    const fetchData = async () => {
        settabledata([])
        setLoading(true);
        try {
            const url =
                ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/reports_data",
                role_name: role,
                parent_module: "Reports",
                module_name: "Active Lines Report",
                feature_module_name: "Active Lines Report",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                table_name: "vw_zero_usage_report",
                db_name: selectedDb,
                ... metaData,
                sessionID: sessionId,
            };
            console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
            if (parsedData.flag === false) {
                Modal.error({
                    title: "Data Fetch Error",
                    content:
                        parsedData.message ||
                        "An error occurred while fetching data. Please try again.",
                    centered: true,
                });
            } else {
                const tableData = parsedData?.data || [];
                const headerMap =
                    parsedData.headers_map?.["Active Lines Report"]?.[
                    "header_map"
                    ] || {};
                const sortedheaderMap = sortHeaderMap(headerMap);
                const headers = Object.keys(sortedheaderMap);
                const pagination_ = parsedData?.pages || {};
                setpagination(pagination_);
                const features_ = parsedData?.headers_map?.["Active Lines Report"]?.module_features || [];
                setFeatures(features_);
                setHeaders(headers);
                setHeaderMap(headerMap);
                setTableData(tableData);
                const headers_ =
                    Object.keys(sortedheaderMap).length > 0
                        ? Object.keys(sortedheaderMap)
                        : [];
                setHeaders(headers_);
                const dynamic_cols = dynamicColumns?.["Active Lines Report"] && dynamicColumns["Active Lines Report"].length > 0 ? dynamicColumns["Active Lines Report"] : headers_ || headers_
                setVisibleColumns(dynamic_cols)
                setLoading(false);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: "Data Fetch Error",
                content:
                    error instanceof Error
                        ? error.message
                        : "An unexpected error occurred while fetching data. Please try again.",
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {

        fetchData();
    }, [username, role]);
    const handleFilter = (advancedFilters: any) => {
        console.log(advancedFilters);
        setAdvancedFilters(advancedFilters)
    };

    const handleReset = (EmptyFilters: any) => {
        console.log(EmptyFilters);
        setFilteredData(EmptyFilters);
    };

    type HeaderMap = Record<string, [string, number]>;

    const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];

        entries.sort((a, b) => a[1][1] - b[1][1]);

        return Object.fromEntries(entries) as HeaderMap;
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }

    const messageStyle = {
        fontSize: "14px",
        fontWeight: "bold",
        padding: "16px",
    };

    function getFirstDayOfCurrentMonth() {
        const now = new Date();
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
        return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
    }

    function getLastDayOfCurrentMonth() {
        const now = new Date();
        const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
    }

    const ExportWithoutSearch = async () => {
        const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
            return new Promise((resolve, reject) => {
                const timer = setTimeout(() => {
                    reject(new Error("Request timed out"));
                }, timeout);

                promise
                    .then((res) => {
                        clearTimeout(timer);
                        resolve(res);
                    })
                    .catch((err) => {
                        clearTimeout(timer);
                        reject(err);
                    });
            });
        };
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username,
                path: "/export_to_s3_bucket",
                role_name: role,
                parent_module: "Reports",
                module_name: "Active Lines Report Export",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ... metaData,
                sessionID: sessionId,
                feature_module_name: "Active Lines Report",
                // start_date: getFirstDayOfCurrentMonth(),
                // end_date: getLastDayOfCurrentMonth(),
            };
            try {
                await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
            } catch (err) {
                console.warn("First API request failed or timed out:", err);
            }

            await new Promise((resolve) => setTimeout(resolve, 20000));

            // Polling for the second API


            await startPolling();
        } catch (error) {
            Modal.error({
                title: "Export Error",
                content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
                centered: true,
            });
        } finally {
            // setExportLoading(false);
            //  removeExport(key); // Remove the export from the store
        }
    }
    const pollExportStatus = async () => {
        const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
        const export_data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_export_status",
            role_name: role,
            parent_module: "Reports",
            module_name: "Active Lines Report Export",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ... metaData,
            sessionID: sessionId,
        };

        try {
            const export_response = await axios.post(export_url, { data: export_data });
            const export_parsedData = JSON.parse(export_response.data.body);

            if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
                const s3Url = export_parsedData?.export_status_data?.url || null;
                if (s3Url) {
                    fetch(s3Url)
                        .then(response => response.blob())
                        .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Active Lines Report.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                            });
                            fireSideCannons()
                        })
                        .catch((err) => {
                            console.log("error", err)
                            Modal.error({
                                title: "Export Error",
                                content: "An error occurred while exporting data. Please try again.",
                                centered: true,
                            });
                        });
                } else {
                    Modal.error({
                        title: "Export Error",
                        content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                        centered: true,
                    });
                }
                return true; // Stop polling
            }

            if (export_parsedData?.export_status_data?.status_flag === "Failure") {
                Modal.error({
                    title: "Export Error",
                    content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                    centered: true,
                });
                return true; // Stop polling
            }
            // Check for "No Data Found for export"
            if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                    title: "Export Information",
                    content: "No Data Found for export",
                    centered: true,
                });
                return true; // Stop polling
            }

            return false; // Continue polling
        } catch (error) {
            Modal.error({
                title: "Export Error",
                content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
                centered: true,
            });
            return true; // Stop polling
        }
    };

    const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
            isPollingComplete = await pollExportStatus();
            if (!isPollingComplete) {
                await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
            }
        }
    };

    const handleExport = async (key: string, heading: string) => {
        try {
            addExport(key, heading);
            let parsedData
            let url
            let data: any
            let response
            if (combineAdnvaceStoredpagination) {
                url = ENV_ROUTES.OPEN_SEARCH;
                data = {
                    path: "/search_export",
                    search: "combined",
                    filters: advancedMultiFilters,
                    search_word: searchTerm,
                    search_all_columns: "True",
                    tenant_id: tenantId,
                    pages: {
                        start: 0,
                        end: 100,
                    },
                    partner: partner,
                    username: username,
                    db_name: selectedDb,
                    ... metaData,
                    sessionID: sessionId,
                    module_name: "Active Lines Report Export",
                    index_name: "Active_lines_report",
                };
                console.log("combineAdnvaceStoredpagination", data)
                response = await axios.post(url, { data });
                parsedData = JSON.parse(response.data.body);
            }
            else if (advancedStoredpagination && !storedpagination) {
                // setExportLoading(true)
                url = ENV_ROUTES.OPEN_SEARCH;
                data = {
                    // data: {
                    path: "/search_export",
                    search: "advanced",
                    filters: advancedMultiFilters,
                    module_name: "Active Lines Report Export",
                    index_name: "Active_lines_report",
                    pages: {
                        start: 0,
                        end: 100
                    },
                    partner: partner,
                    username: username,
                    db_name: selectedDb,
                    ... metaData,
                    sessionID: sessionId,
                    tenant_id: tenantId,
                    // }
                }
                response = await axios.post(url, { data });
                parsedData = JSON.parse(response.data.body);

            }
            else if (storedpagination && !advancedStoredpagination) {
                // setExportLoading(true)
                url = ENV_ROUTES.OPEN_SEARCH;
                data = {
                    // data: {
                    path: "/search_export",
                    search_word: searchTerm,
                    search_all_columns: "True",
                    index_name: "Active_lines_report",
                    module_name: "Active Lines Report Export",
                    search: "whole",
                    pages: {
                        start: 0,
                        end: 100,
                    },
                    partner: partner,
                    username: username,
                    db_name: selectedDb,
                    ... metaData,
                    sessionID: sessionId,
                    tenant_id: tenantId,
                }
                response = await axios.post(url, { data });
                parsedData = JSON.parse(response.data.body);

            }
            else {
                // confirmExport()
                await ExportWithoutSearch();
                return;

            }

            if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
                if (parsedData.flag === true) {
                    const s3Url = parsedData?.download_url || null;
                    if (s3Url) {
                        fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                                const url = window.URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.href = url;
                                a.download = 'Active Lines Report.xlsx';
                                a.click();
                                a.remove();
                                window.URL.revokeObjectURL(url);
                                notification.success({
                                    message: "Success",
                                    description: "Successfully exported the record!",
                                    style: messageStyle,
                                    placement: "top",
                                });
                                fireSideCannons()
                            })
                            .catch((err) => {
                                console.log("error", err)
                                Modal.error({
                                    title: "Export Error",
                                    content: "An error occurred while exporting data. Please try again.",
                                    centered: true,
                                });
                            });
                    }
                    else {
                        // setExportLoading(false)
                        Modal.error({
                            title: "Export Error",
                            content: parsedData.message || "An error occurred while exporting data. Please try again.",
                            centered: true,
                        });
                    }
                }
                else {
                    // setExportLoading(false)
                    Modal.error({
                        title: "Export Error",
                        content: parsedData.message || "An error occurred while exporting data. Please try again.",
                        centered: true,
                    });
                }
            }

        } catch (error) {
            await startPolling();
        } finally {
            removeExport(key);
        }
    };
    return (
        <Suspense
            fallback={
                <div className="flex justify-center items-center h-screen">
                    <Spin size="large" />
                </div>
            }
        >
            <div className="relative">
                <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
                    {/* Search and Advanced Filter Container */}
                    <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                        <>
                            {features.includes("Search-Active Lines Report") && (
                                <TableSearch
                                    searchTerm={searchTerm}
                                    setSearchTerm={setSearchTerm}
                                    tableName={"Active_lines_report"}
                                    headerMap={headerMap}
                                />
                            )}
                        </>
                        <>
                            {features.includes("Advanced filter-Active Lines Report") && (
                                <AdvancedMultiFilter
                                    showAdvanced={showAdvanced}
                                    setShowAdvanced={setShowAdvanced}
                                    onFilter={handleFilter}
                                    onReset={handleReset}
                                    headers={headers}
                                    headerMap={headerMap}
                                    tableName={"Active_lines_report"}
                                />
                            )}
                        </>
                    </div>
                    {/* Export and ColumnFilter Container */}
                    <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
                        {features.includes("Export-Active Lines Report") && (
                            <button className="save-btn"
                                onClick={() => {
                                    if (!exports.some((exportItem) => exportItem.popupHeading === "Active Lines Report")) {
                                        handleExport("activeLinesReport", "Active Lines Report");
                                    }
                                }}>
                                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-1" />
                                <span>Export</span>
                            </button>
                        )}
                        <ColumnFilter
                            headers={headers}
                            visibleColumns={visibleColumns}
                            setVisibleColumns={setVisibleColumns}
                            headerMap={headerMap}
                        />
                    </div>
                </div>

                <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
                    <TableComponent
                        headers={headers}
                        headerMap={headerMap}
                        initialData={tableData}
                        searchQuery={searchTerm}
                        visibleColumns={visibleColumns}
                        itemsPerPage={100}
                        popupHeading="Active Lines Report"
                        pagination={pagination}
                        advancedFilters={filteredData}
                        height={showAdvanced ? 280 : 230}
                    />
                </div>
                {/* Sticky Footer for Small Screens */}
                <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                    {features.includes("Export-Active Lines Report") && (
                        <button className="save-btn"
                            onClick={() => {
                                if (!exports.some((exportItem) => exportItem.popupHeading === "Active Lines Report")) {
                                    handleExport("activeLinesReport", "Active Lines Report");
                                }
                            }}>
                            <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
                        </button>
                    )}
                    <ColumnFilter
                        headers={headers}
                        visibleColumns={visibleColumns}
                        setVisibleColumns={setVisibleColumns}
                        headerMap={headerMap}
                    />
                </div>
            </div>
        </Suspense>
    );
};
export default ActiveLinesReport;
