"use client";

import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  AdjustmentsHorizontalIcon,
  ArrowUpTrayIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Popover, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Select,{ MenuListProps } from 'react-select'; // Importing react-select
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { FixedSizeList as List } from 'react-window';
import { DropdownStyles, NonEditableDropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";

const { RangePicker } = DatePicker;

interface OptionType {
  value: string | number;
  label: string;
  children?: any;
}

//Lazy Loading Components
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const CreateModal = lazy(() => import("@/app/components/createPopup"));

const CustomerRatePoolUsageReport: React.FC = () => {
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<any>({});
  const [features, setFeatures] = useState<string[]>([]);
  const hasFetchedData = useRef(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token ,tenantId, tenantName, selectedDb, metaData, advancedStoredpagination, storedpagination, firstLastName,sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination , dynamicColumns,setDynamicColumns} = useAuth();
  const [tableData, setTableData] = useState<any[]>([]);
  const title = useLogoStore((state) => state.title);
  const [pagination, setpagination] = useState<any>({});
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  //export functionality
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport,exports } = exportLoadingStore();
  const exportKey = "Customer Rate Pool Usage Report";
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});

               // Add these state variables at the top of the component
const [isConfirmationModalVisible, setConfirmationModalVisible] = useState(false);
const [serviceProviders, setServiceProviders] = useState<string[]>([]);
const [billingCyclePeriods, setBillingCyclePeriods] = useState<string[]>([]);
// Add this to your state variables
const [billingPeriodDates, setBillingPeriodDates] = useState<Record<string, string[]>>({});
// Add this default value to your serviceProviders state
const [selectedServiceProvider, setSelectedServiceProvider] = useState<{ value: string; label: string } | null>({
  value: "All service providers",
  label: "All service providers",
});
const [selectedBillingCyclePeriod, setSelectedBillingCyclePeriod] = useState<{ value: string; label: string } | null>(null);
const [errorMessage, setErrorMessage] = useState<string>(""); // State to hold error messages
// Add a new function to fetch dropdown data
const [isCrossCarrier, setIsCrossCarrier] = useState(false);
const [exportLoading, setExportLoading] = useState(false);
const [selectedCrossBillingPeriod, setSelectedCrossBillingPeriod] = useState<{ value: any; label: string } | null>();

// Virtualized MenuList Component with proper TypeScript types
const VirtualizedMenuList: React.FC<MenuListProps<OptionType>> = ({
  options,
  children,
  maxHeight,
  getValue,
}) => {
  const itemHeight = 35; // Height of each option in pixels
  const [value] = getValue();
  const initialOffset = options.indexOf(value) * itemHeight;

  return (
    <List
      height={Math.min(maxHeight, 300)} // Set max height for the dropdown
      itemCount={Array.isArray(children) ? children.length : 0}
      itemSize={itemHeight}
      initialScrollOffset={initialOffset}
      width="100%"
    >
       {({ index, style }) => <div style={style}>{(children as React.ReactChild[])[index]}</div>}

    </List>
  );
};

// const fetchExportDropdownData = async () => {
//   try {
//     const url = ENV_ROUTES.MODULE_MANAGEMENT;
//     const data = {
//       tenant_name: partner || "default_value",
//       username,
//       path: "/reports_dropdown_data_export",
//       role_name: role,
//       parent_module: "Reports",
//       module: "Customer Rate Pool Usage Report",
//       request_received_at: getCurrentDateTime(),
//       access_token: token,
//       db_name: selectedDb,
//       sessionID: sessionId,
//     };

//     const response = await axios.post(url, { data });
//     const parsedData = JSON.parse(response.data.body);

//     if (parsedData.flag) {
//       setServiceProviders(parsedData.unique_service_providers || []);
//       setBillingPeriodDates(parsedData.billing_period_dates || {});

//       // Set default provider logic
//       if (parsedData.unique_service_providers?.length > 0) {
//         const defaultProvider = parsedData.unique_service_providers[0];
//         setSelectedServiceProvider(defaultProvider);

//         const defaultPeriods = parsedData.billing_period_dates[defaultProvider] || [];
//         setBillingCyclePeriods(defaultPeriods);
//       }
//     } else {
//       Modal.error({
//         title: "Error",
//         content: parsedData.message || "Failed to fetch export dropdown data",
//       });
//     }
//   } catch (error) {
//     Modal.error({
//       title: "Error",
//       content: "An error occurred while fetching export dropdown data",
//     });
//   }
// };

// const handleExportModalOpen = () => {
//   fetchExportDropdownData().then(() => {
//     setSelectedServiceProvider({
//       value: "All service providers",
//       label: "All service providers",
//     });
//     setExportModalOpen(true);
//   });
// };

const fetchExportDropdownData = async () => {
  
  // Helper function
  const sleep = (ms: number) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
  };

  // setExportModalOpen(true);
  setExportLoading(true);

  const baseUrl = ENV_ROUTES.MODULE_MANAGEMENT;

  const basePayload = {
    tenant_name: partner || "default_value",
    username,
    path: "/reports_dropdown_data_export",
    role_name: role,
    parent_module: "Reports",
    module: "Usage By Line Report",
    request_received_at: getCurrentDateTime(),
    access_token: token,
    db_name: selectedDb,
    ... metaData,
    sessionID: sessionId,
  };

  const isTimeoutError = (error: any) => {
    const status = error?.response?.status;
    const message = error?.response?.data?.message;
    return status === 504 || message === "Endpoint request timed out";
  };

  const pollExportStatus = async () => {
    console.info("🔃 Polling /get_export_status for completion...");
    const MAX_POLLS = 24; // 24 * 5s = 2 minutes
    
    for (let i = 0; i < MAX_POLLS; i++) {
      await sleep(5000); // Wait 5 seconds before each poll
      
      try {
        const statusPayload = {
          tenant_name: partner || "default_value",
          username,
          path: "/get_export_status", // ✅ Changed path for status polling
          role_name: role,
          parent_module: "Reports",
          module_name: "Usage By Line Report",
          access_token: token,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
        };

        const statusResp = await axios.post(baseUrl, {
          data: statusPayload
        });
        
        let statusBody = statusResp.data.body;
        if (typeof statusBody === "string") {
          statusBody = JSON.parse(statusBody);
        }


        // ✅ Check the actual response structure you provided
        if (statusBody.flag && statusBody.export_status_data) {
          const exportData = statusBody.export_status_data;
          
          // Check for success
          if (exportData.status_flag === "Success" && exportData.url) {
            console.info(`✅ Export completed! URL: ${exportData.url}`);
            return exportData.url;
          }
          
          // Still waiting
          if (exportData.status_flag === "Waiting") {
            console.debug(`⏳ Still waiting... (${i + 1}/${MAX_POLLS}) - ID: ${exportData.id}`);
            continue;
          }
          
          // Check for failure
          if (exportData.status_flag === "Failure") {
            throw new Error(`Export failed with status: ${exportData.status_flag} - ID: ${exportData.id}`);
          }

          // Unknown status
        } else {
          console.warn("⚠️ Unexpected response structure:", statusBody);
        }
        
      } catch (statusErr: any) {
        if (i === MAX_POLLS - 1) {
          throw new Error("Failed to get export status after multiple attempts");
        }
      }
    }

    throw new Error("Export did not complete within expected time (2 minutes).");
  };

  try {
    let parsedData: any;
    let firstResponse :any;
    let didFallback = false;

    // ─── STEP 1: Try normal invocation ─────────────────────────────────────────────
    try {
      firstResponse = await axios.post(baseUrl, { data: basePayload });
    } catch (err: any) {
      if (!isTimeoutError(err)) {
        throw err; // Some other error → bubble up
      }
      console.warn("⏱️ First call timed out. Retrying with is_size_exceeded: true...");
      didFallback = true;
    }

    // ─── STEP 2: Fallback with is_size_exceeded: true ──────────────────────────────
    let fallbackBody: any;
    let fallbackTimedOut = false;
    
    if (didFallback) {
      try {
        const fallbackResp = await axios.post(baseUrl, {
          data: { ...basePayload, is_size_exceeded: true },
        });
        fallbackBody = typeof fallbackResp.data.body === "string"
          ? JSON.parse(fallbackResp.data.body)
          : fallbackResp.data.body;
      } catch (fallbackErr: any) {
        if (isTimeoutError(fallbackErr)) {
          console.warn("⏱️ Second call also timed out. Will poll /get_export_status...");
          fallbackTimedOut = true;
        } else {
          throw fallbackErr;
        }
      }
    } else {
      // No timeout → check if function flagged response too large
      const errType = firstResponse.data.errorType;
      if (errType === "Function.ResponseSizeTooLarge") {
        console.warn("📦 Response too large. Retrying with is_size_exceeded: true...");
        try {
          const fallbackResp = await axios.post(baseUrl, {
            data: { ...basePayload, is_size_exceeded: true },
          });
          fallbackBody = typeof fallbackResp.data.body === "string"
            ? JSON.parse(fallbackResp.data.body)
            : fallbackResp.data.body;
        } catch (fallbackErr: any) {
          if (isTimeoutError(fallbackErr)) {
            console.warn("⏱️ Second call also timed out. Will poll /get_export_status...");
            fallbackTimedOut = true;
          } else {
            throw fallbackErr;
          }
        }
      } else {
        // Normal success
        let body = firstResponse.data.body;
        if (typeof body === "string") body = JSON.parse(body);
        parsedData = body;
      }
    }

    // ─── STEP 3: Handle second timeout by polling status ───────────────────────────
    if (fallbackTimedOut) {
      const exportUrl = await pollExportStatus();
      const s3Resp = await axios.get(exportUrl);
      parsedData = s3Resp.data;
    }
    // ─── STEP 4: Handle normal fallback response ────────────────────────────────────
    else if (!parsedData && fallbackBody) {
      // Case A: immediate S3 URL
      if (fallbackBody.s3_path) {
        const s3Resp = await axios.get(fallbackBody.s3_path);
        parsedData = s3Resp.data;
      }
      // Case B: jobId + polling (if your API returns job_id)
      else if (fallbackBody.job_id) {
        const exportUrl = await pollExportStatus();
        const s3Resp = await axios.get(exportUrl);
        parsedData = s3Resp.data;
      }
      else {
        throw new Error("Fallback did not return s3_path or job_id. Unable to proceed.");
      }
    }

    // ─── STEP 5: Validate & set state ───────────────────────────────────────────────
    if (
      !parsedData ||
      !Array.isArray(parsedData.unique_service_providers) ||
      typeof parsedData.billing_period_dates !== "object"
    ) {
      console.warn("⚠️ Unexpected shape:", parsedData);
      throw new Error("Invalid response. Missing required keys.");
    }

    setServiceProviders(parsedData.unique_service_providers);
    setBillingPeriodDates(parsedData.billing_period_dates);
    if(!isCrossCarrier){
    setIsCrossCarrier(parsedData.cross_provider || false);
    }

    // Pick defaults
    const firstProv = parsedData.unique_service_providers[0];
    if (firstProv) {
      const defaultProv = { value: firstProv, label: firstProv };
      setSelectedServiceProvider(defaultProv);

      const periods = parsedData.billing_period_dates[firstProv] || [];
      setBillingCyclePeriods(
        parsedData.cross_provider ? Object.keys(periods) : periods
      );
    }

  } catch (error: any) {
    console.error("❌ fetchExportDropdownData error:", error);
    Modal.error({
      title: "Error fetching export data",
      content: error.message || String(error),
    });
  } finally {
    setExportLoading(false);
  }
};
  const handleExportModalOpen = async() => {
    // fetchExportDropdownData().then(() => {
      setExportModalOpen(true);
    // });
     const firstProv = serviceProviders.length>0 ? serviceProviders[0] : null;
    if (firstProv) {
      const defaultProv = { value: firstProv, label: firstProv };
      setSelectedServiceProvider(defaultProv);
    }
    const new_cross_carrier = await fetchCrossCarrierStatus()
    if(new_cross_carrier !== isCrossCarrier){
      fetchExportDropdownData()
    }
  };
  const handleServiceProviderChange = (selectedOption: any) => {
    setSelectedCrossBillingPeriod(null)
    setSelectedServiceProvider(selectedOption);
    console.log("selectedOption", selectedOption)
    // Reset billing cycle period when changing service provider
    // setBillingCyclePeriods(periods);

    const defaultProvider = isCrossCarrier ? `${selectedOption.label}` : selectedOption.value

    const periods = billingPeriodDates[defaultProvider] || [];
    if (isCrossCarrier) {
      const defaultPeriodsOptions = Object.keys(periods) || [];
      setBillingCyclePeriods(defaultPeriodsOptions);
      if (selectedOption.label !== "All Customers" && defaultPeriodsOptions.length > 0) {
        const defaultPeriodsOptions = Object.keys(periods) || [];
        const label: any = defaultPeriodsOptions[0] || ""
        const value = periods[label] || ""
        console.log("isCrossCarrier", { value: value, label: label })
        setSelectedBillingCyclePeriod({ value: value, label: label }); // Set first value as default
      }
    }
    else {
      setBillingCyclePeriods(periods);
      if (selectedOption.value !== "All service providers" && periods.length > 0) {
        setSelectedBillingCyclePeriod({ value: periods[0], label: periods[0] }); // Set first value as default
      } else {
        setSelectedBillingCyclePeriod(null); // Clear selection if "All service providers" is selected
      }
    }
  };
const handleExportClick = () => {
  // Clear previous error message
  setErrorMessage("");

  // Immediate validation when the export button is clicked
  if (!selectedServiceProvider) {
    setErrorMessage("Please select a Service Provider.");
    return; // Stop further execution
  }

  if (selectedServiceProvider.value !== "All service providers" && selectedServiceProvider.label !== "All Customers" && !selectedBillingCyclePeriod) {
      setErrorMessage("Please select a billing cycle Period.");
    return; // Stop further execution
  }

  // If all validations pass, show the confirmation modal
  setConfirmationModalVisible(true);
};
const handleExportModalClose = () => {
  setExportModalOpen(false);
  setDateRange([null, null]); // Reset date range
  setSelectedServiceProvider(null);
  setSelectedBillingCyclePeriod(null);
};
const confirmExport = async () => {
  setConfirmationModalVisible(false);
  await ExportWithoutSearch("customer rate pool usage","Customer Rate Pool Usage Report"); // Call the export function with the selected values
};
 
useEffect(() => {
      setDynamicColumns((prev:any)=>({...prev,"Customer Rate Pool Usage Report":visibleColumns}))
    }, [visibleColumns]);
  useEffect(() => {
    const fetchData = async () => {
      setCombineAdnvaceStoredpagination(null)
      setLoading(true);
      try {
        const url =
        ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Customer Rate Pool Usage Report",
          feature_module_name:"Customer Rate Pool Usage Report",
          mod_pages: {
            start: 0,
            end: 100,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name:"vw_customer_rate_pool_usage_report",
          db_name:selectedDb,
          ... metaData,
          sessionID: sessionId,
        };
        console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          const headerMap =
            parsedData.headers_map?.["Customer Rate Pool Usage Report"]?.[
              "header_map"
            ] || {};
          // const features = parsedData.headers_map["Bandwidth Customers"]["module_features"]

          // console.log("features", features)
          // setFeatures(features)
          // const createModalData = parsedData.headers_map["Bandwidth Customers"]["pop_up"]
          const sortedheaderMap = sortHeaderMap(headerMap);
          // const generalFields = parsedData.data
          const pagination_ = parsedData?.pages || {};
          setpagination(pagination_);
          const features_ = parsedData?.headers_map?.["Customer Rate Pool Usage Report"]?.module_features || [];
          setFeatures(features_);
          // setgeneralFields(generalFields)
          setHeaderMap(headerMap);
          // setcreateModalData(sortPopup(createModalData))
          setTableData(tableData);
          // settabledata(tableData)
           const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
          const dynamic_cols=dynamicColumns?.["Customer Rate Pool Usage Report"] && dynamicColumns["Customer Rate Pool Usage Report"].length>0 ?dynamicColumns["Customer Rate Pool Usage Report"] :headers_ || headers_
          setVisibleColumns(dynamic_cols)
          setLoading(false);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false); // Ensure loading is set to false in the finally block
      }
    };

    if (!hasFetchedData.current) {
      // Check if data has already been fetched
      fetchData();
      fetchExportDropdownData()
      hasFetchedData.current = true; // Set to true after fetching
    }
  }, []);

  const fetchCrossCarrierStatus = async () => {
        setExportLoading(true);
        try {
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_cross_carrier_optimization",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Customer Rate Pool",
            feature_module_name:"Customer Rate Pools",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
    
          if (parsedData.flag === false) {
            console.error("error while fetching cross carrier status")
            return false
          } else {
            const crossProvider_ = parsedData?.cross_carrier_optimization || false
            return crossProvider_
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          return false
        } finally {
          setExportLoading(false);
        }
      };
  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  };

  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  };

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };
  const sortPopup = (fields: any[]): any[] => {
    return fields.sort((a: any, b: any) => a?.id - b?.id);
  };

  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
    setNewRowData({});
  };
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const handleCreateRow = (newRow: any, tableData: any) => {
    handleCreateModalClose();
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async (key: string, heading: string) => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      addExport(key, heading);

      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const periodsList = isCrossCarrier ? selectedCrossBillingPeriod?.value || "" :selectedBillingCyclePeriod?.value ||  ""
      console.log("selectedCrossBillingPeriod", selectedCrossBillingPeriod)
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
              tenant_name: partner || "default_value",
              username,
              path: "/export_to_s3_bucket",
              role_name: role,
              parent_module: "Reports",
              module_name: isCrossCarrier ? "Customer Rate Pool Usage Crrossprovider Export" : "Customer Rate Pool Usage Report Export",
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ... metaData,
              sessionID: sessionId,
        feature_module_name: "Customer Rate Pool Usage Report",
              start_date: getFirstDayOfCurrentMonth(),
              end_date: getLastDayOfCurrentMonth(),
              service_provider: selectedServiceProvider?.value === "All service providers" || selectedServiceProvider?.label === "All Customers" ? "" : selectedServiceProvider?.value, // Send only the value
              billing_cycle_period: isCrossCarrier ? periodsList : selectedBillingCyclePeriod ? periodsList : "", // Send only the value
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));

      // Polling for the second API
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
       removeExport(key); // Remove the export from the store
    }
  }
  const pollExportStatus = async () => {
    const is_search_call = (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination)
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_export_status",
      role_name: role,
      parent_module: "Reports",
      module_name:(isCrossCarrier && !is_search_call)?"Customer Rate Pool Usage Crrossprovider Export": "Customer Rate Pool Usage Report Export",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ... metaData,
      sessionID: sessionId,
    };

      try {
        const export_response = await axios.post(export_url, { data: export_data });
        const export_parsedData = JSON.parse(export_response.data.body);

        if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
          const s3Url = export_parsedData?.export_status_data?.url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // notification.success({
            //   message: "Success",
            //   description: "Successfully exported the record!",
            //   style: messageStyle,
            //   placement: "top",
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Customer Rate Pool Usage Report.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                              fireSideCannons()
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          } else {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }
          return true; // Stop polling
        }

        if (export_parsedData?.export_status_data?.status_flag === "Failure") {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
         // Check for "No Data Found for export"
                  if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                    Modal.info({
                      title: "Export Information",
                      content: "No Data Found for export",
                      centered: true,
                    });
                    return true; // Stop polling
                  }

        return false; // Continue polling
      } catch (error) {
        Modal.error({
          title: "Export Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
    };

    const startPolling = async () => {
      let isPollingComplete = false;

      while (!isPollingComplete) {
        isPollingComplete = await pollExportStatus();
        if (!isPollingComplete) {
          await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
        }
      }
    };

  const handleExport = async (key:string, heading:string) => {
    try {
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          index_name: "customer_rate_pool_usage_report",
          module_name:"Customer Rate Pool Usage Report",
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        // setExportLoading(true)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name:"Customer Rate Pool Usage Report",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "customer_rate_pool_usage_report",
          pages: {
            start: 0,
            end: 100
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        // setExportLoading(true)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name:"Customer Rate Pool Usage Report",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "customer_rate_pool_usage_report",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        handleExportModalOpen()
        
      }
if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        if (parsedData.flag === true) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // // setExportLoading(false)
            // notification.success({
            //   message: 'Success',
            //   description: 'Successfully exported the record!',
            //   style: messageStyle,
            //   placement: 'top',
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Customer Rate Pool Usage Report.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                              fireSideCannons()
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          }
          else {
            // setExportLoading(false)
            Modal.error({
              title: "Export Error",
              content: parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }
        }
        else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      }

    } catch (error) {
      await startPolling();
      // setExportLoading(false)
      // setLoading(false);
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
  const downloadBlob = (base64Blob: string) => {
    // Decode the Base64 string
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Customer Rate Pool Usage Report.xlsx"; // Set the file name to .xlsx
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day"); // Disable future dates
  };



  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="relative">
      <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
            <>
            {features.includes("Search-Customer rate pool usage report") && (
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"customer_rate_pool_usage_report"}
                headerMap={headerMap}
              />
            )}
            </>
            <>
            {features.includes("Advanced filter-Customer rate pool usage report") && (
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"customer_rate_pool_usage_report"}
              />
            )}
            </>
          </div>
            {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
            {features.includes("Export-Customer rate pool usage report") && (
              <button className="save-btn" 
              onClick={() => {
                if (!exports.some((exportItem) => exportItem.popupHeading === "Customer Rate Pool Usage Report")) {
                  handleExport("CustomerRatePoolUsageReport", "Customer Rate Pool Usage Report");
                }
              }}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-1" />
                <span>Export</span>
              </button>
            )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
        </div>

        <div className=" mb-4 space-x-2">
          {/* {features.includes("Advance Filter-Bandwidth Customers") && (
            <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"bandwidth_customers"} />
          )} */}
        </div>
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            popupHeading="Customer rate pool usage report"
            createModalData={createModalData}
            pagination={pagination}
            generalFields={generalFields}
            advancedFilters={filteredData}
            height = {showAdvanced?280:230}
          />
        </div>
        <CreateModal
          isOpen={isCreateModalOpen}
          onClose={handleCreateModalClose}
          onSave={handleCreateRow}
          columnNames={createModalData}
          heading="Customer rate pool usage report"
          header={
            tableData && tableData.length > 0 ? Object.keys(tableData[0]) : []
          }
          generalFields={generalFields}
          tableData={tableData}
        />
          {/* Sticky Footer for Small Screens */}
                    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                         {features.includes("Export-Customer rate pool usage report") && (
                          <button className="save-btn" 
                          onClick={() => {
                            if (!exports.some((exportItem) => exportItem.popupHeading === "Customer Rate Pool Usage Report")) {
                              handleExport("CustomerRatePoolUsageReport", "Customer Rate Pool Usage Report");
                            }
                          }}>
                            <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
                          </button>
                        )}
                        <ColumnFilter
                          headers={headers}
                          visibleColumns={visibleColumns}
                          setVisibleColumns={setVisibleColumns}
                          headerMap={headerMap}
                        />
                    </div>
        <Modal
          title="Export Output"
          visible={isExportModalOpen}
          onCancel={handleExportModalClose}
          footer={null}
          centered
        >
          {exportLoading ? (
            <div className="flex justify-center items-center h-64">
              <Spin size="large" />
            </div>
          ) : (
            <div className="flex flex-col space-y-3">
              <label>{isCrossCarrier ? 'Customer' : 'Service Provider'}</label>
              <Select
                components={{ MenuList: VirtualizedMenuList }}
                options={serviceProviders.map((provider) => {
                  if (isCrossCarrier) {
                    const parts = provider.split('-');
                    return {
                      value: (Number(parts.pop() ?? 0)).toString(),
                      label: provider,
                    };
                  }
                  return { value: provider, label: provider };
                })}
                onChange={handleServiceProviderChange}
                styles={DropdownStyles}
                // placeholder="Select Service Provider"
                value={selectedServiceProvider}
                filterOption={(option, rawInput) => {
                    // Faster, case-insensitive match
                    return option.label.toLowerCase().includes(rawInput.toLowerCase());
                  }}
              />
              <label>Billing Cycle Period</label>
              <Select
              components={{ MenuList: VirtualizedMenuList }}
        styles={selectedServiceProvider?.value === 'All service providers' ||
          selectedServiceProvider?.label === 'All Customers'?NonEditableDropdownStyles:DropdownStyles}
        options={
          billingCyclePeriods.some((period) => !period || period === 'null')
            ? []
            : billingCyclePeriods.map((period) => {
                const defaultProvider:any = isCrossCarrier
                  ? `${selectedServiceProvider?.label || ''}`
                  : selectedServiceProvider?.value;
                const periods = billingPeriodDates[defaultProvider] || [];
                const label_ = period as any;
                const value_ = periods[label_] || '';
                if (isCrossCarrier) {
                  return {
                    value: value_,
                    label: label_ || period,
                  };
                }
                return { value: period, label: period };
              })
        }
        onChange={(selectedOptions: any) => {
          if (isCrossCarrier) {
            setSelectedCrossBillingPeriod(selectedOptions);
          } else {
            setSelectedBillingCyclePeriod(selectedOptions || null);
          }
        }}
        placeholder="Select Billing Cycle Period"
        isDisabled={
          selectedServiceProvider?.value === 'All service providers' ||
          selectedServiceProvider?.label === 'All Customers'
        }
        value={isCrossCarrier ? selectedCrossBillingPeriod : selectedBillingCyclePeriod}
        filterOption={(option, rawInput) => {
          // Faster, case-insensitive match
          return option.label.toLowerCase().includes(rawInput.toLowerCase());
        }}
      />
              {errorMessage && <p className="text-red-500">{errorMessage}</p>}
              <div className="flex justify-center space-x-2">
                <button className="cancel-btn" onClick={handleExportModalClose}>
                  Cancel
                </button>
                <button className="save-btn" onClick={handleExportClick}>
                  {'Export'}
                </button>
              </div>
            </div>
          )}

        </Modal>
        <Modal
          title="Confirm Export"
          visible={isConfirmationModalVisible}
         footer={null}
         centered
         >
          
          <p>Are you sure want to Export this data</p>
          <div className="justify-center flex space-x-2">
            <Button  className="cancel-btn" onClick={() =>{
            setConfirmationModalVisible(false)
           
          }}>
              Cancel
            </Button>
            <Button 
              className="save-btn"
              onClick={()=>{
                confirmExport()
                handleExportModalClose()
              }}
            >
              OK
            </Button>
          </div>
          
        </Modal>
        {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
          )} */}
      </div>
    </Suspense>
  );
};
export default CustomerRatePoolUsageReport;
