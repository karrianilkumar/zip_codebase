"use client";
import React, {
    useEffect,
    useState,
    lazy,
    Suspense,
    useCallback,
} from "react";
import { Modal, Spin, DatePicker, notification, message, Upload } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useMutation } from "@tanstack/react-query";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import { useRevStore } from "@/app/stores/revStore";
import moment from "moment";
import Select from 'react-select';
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import OptimizationTableComponent from "@/app/components/optimizationTableComponent/page";
type ExportData = {
    path: string;
    username: string | null;
    module_name: string;
    request_received_at: string;
    start_date: string;
    end_date: string;
    Partner: string | null;
    access_token: string | null;
    db_name: string | null;
};

const RevTableComponent = lazy(
    () => import("@/app/components/revTableComponent/page")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
    () => import("@/app/components/advanced_search")
);

const CustomerCharges: React.FC = () => {
    const { RangePicker } = DatePicker;
    const [isExportModalOpen, setExportModalOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const { username, partner, role, token, selectedDb } = useAuth();
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [features, setFeatures] = useState<string[]>([]);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});

    const [filteredData, setFilteredData] = useState([]);
    const [showAdvanced, setShowAdvanced] = useState(false);
    const { setRevRows, setRevHeaders, setRevHeaderMap } = useRevStore();
    const [loading, setLoading] = useState(true);
    const [exportLoading, setExportLoading] = useState(true);
    const [customerSessionsMap, setCustomerSessionsMap] = useState<any>({})
    const [customerOptions, setCustomerOptions] = useState<any[]>([])
    const [sessionOptions, setSessionOptions] = useState<any[]>([])
    const [billPeriodOptions, setBillPeriodOptions] = useState<any[]>([])
    const [selectedCustomers, setSelectedCustomers] = useState<any[]>([]);
    const [selectedSessions, setSelectedSessions] = useState<any[]>([]);
    const [selectedBillPeriods, setSelectedBillPeriods] = useState<any[]>([]);
    const [exportCustomerError, setExportCustomerError] = useState<boolean>(false);
    const [errorMessage, setErrorMessage] = useState<boolean>(false);

    const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);

    type HeaderMap = Record<string, [string, number]>;

    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
    }, []);

    const fetchExportData = async () => {
        setExportCustomerError(false)
        setErrorMessage(false)
        setCustomerOptions([])
        setSelectedCustomers([])
        setSessionOptions([])
        setSelectedSessions([])
        setCustomerSessionsMap({})
        try {
            setExportLoading(true);
            const url = ENV_ROUTES.CHARGES_HISTORY
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                path: "/customers_sessions_customer_charges_export_dropdown_data",
                role_name: role,
                module_name: "Charge history",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching Charge history data. Please try again.',
                    centered: true,
                });
            } else {
                const customerSessionsMap_ = parsedData?.customer_sessions || {}
                setCustomerSessionsMap(customerSessionsMap_)
                const customerOptions_ = Object.keys(customerSessionsMap_) || []
                setCustomerOptions(customerOptions_)

            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setExportLoading(false);
        }
    };
    const fetchData = async () => {
        try {
            setLoading(true);
            const url = ENV_ROUTES.CHARGES_HISTORY
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                path: "/get_charge_history_data",
                role_name: role,
                module_name: "Charge history",
                feature_module_name: "Charge history",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const headersMap_ = parsedData?.headers_map?.["Charge history"]?.header_map || {}
                const sortedheaderMap = sortHeaderMap(headersMap_)
                setHeaderMap(sortedheaderMap)
                setRevHeaderMap(sortedheaderMap)
                const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
                setHeaders(headers_)
                setRevHeaders(headers_)
                setVisibleColumns(headers_)
                const tableData_ = parsedData?.customer_charges_data || []
                setTableData(tableData_)
                setRevRows([])
                const features_ = parsedData?.header_map?.["Charge history"]?.module_features || []
                setFeatures(features_)
                const pagination_ = parsedData?.pages || {}
                setPagination(pagination_)
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [partner]);

    const handleCustomerChange = (selectedOptions: any) => {
        const selectedCustomerList = selectedOptions.map((option: any) => option.value);
        setSelectedCustomers(selectedCustomerList);

        // Collect sessions and bill periods for all selected customers
        let allSessions: any[] = [];
        let allBillPeriods: any[] = [];

        selectedCustomerList.forEach((customer: string) => {
            const customerSessions = customerSessionsMap[customer];
            allSessions = [...allSessions, ...customerSessions.map((item: any) => item.session_id)];
            allBillPeriods = [...allBillPeriods, ...customerSessions.map((item: any) => item.billing_period_end_date)];
        });

        setSessionOptions(allSessions);
        setBillPeriodOptions(allBillPeriods);

        // Reset selected sessions and bill periods
        setSelectedSessions([]);
        setSelectedBillPeriods([]);
        setErrorMessage(false); // Reset error message
    };

    const handleSessionChange = (selectedOptions: any) => {
        setSelectedSessions(selectedOptions.map((option: any) => option.value));
        checkSelectedMappings(selectedOptions.map((option: any) => option.value), selectedBillPeriods);
    };

    const handleBillPeriodChange = (selectedOptions: any) => {
        setSelectedBillPeriods(selectedOptions.map((option: any) => option.value));
        checkSelectedMappings(selectedSessions, selectedOptions.map((option: any) => option.value));
    };

    // Check if the selected sessions and bill periods belong to the same customer
    const checkSelectedMappings = (selectedSessions: any, selectedBillPeriods: any) => {
        if (selectedSessions.length === 1 && selectedBillPeriods.length === 1) {
            const selectedSession = selectedSessions[0];
            const selectedBillPeriod = selectedBillPeriods[0];

            // Loop through all selected customers to check if the session and bill period match
            const matchingCustomer = selectedCustomers.find((customer: string) => {
                const customerSessions = customerSessionsMap[customer];
                return customerSessions.some(
                    (session: any) => session.session_id === selectedSession && session.billing_period_end_date === selectedBillPeriod
                );
            });

            if (!matchingCustomer) {
                setErrorMessage(true);
            } else {
                setErrorMessage(false);  // Reset error if they belong to the same mapping
            }
        }
    };

    const exportMutation = useMutation<any, Error, ExportData>({
        mutationFn: async (exportData) => {
            const url = ENV_ROUTES.CHARGES_HISTORY;
            const response = await axios.post(
                url,
                { data: exportData },
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            );
            return JSON.parse(response.data.body);
        },
        onSuccess: (data) => {
            if (data.flag === true) {
                notification.success({
                    message: "Success",
                    description: "Successfully exported the record!",
                    style: messageStyle,
                    placement: "top",
                });
                downloadZipBlob(data.blob);
            } else {
                Modal.error({
                    title: "Export Error",
                    content: data.message,
                    centered: true,
                });
            }
            handleExportModalClose();
        },
        onError: (error) => {
            console.error("Error downloading the file:", error);
            Modal.error({
                title: "Export Error",
                content:
                    "An error occurred while exporting the file. Please try again.",
            });
        },
    });

    const handleFilter = useCallback((advancedFilters: any) => {
    }, []);

    const handleReset = useCallback((EmptyFilters: any) => {
        setFilteredData(EmptyFilters);
    }, []);

    const messageStyle = {
        fontSize: "14px",
        fontWeight: "bold",
        padding: "16px",
    };

    const handleExportModalOpen = () => {
        fetchExportData()
        setExportModalOpen(true);
    };

    const handleExportModalClose = () => {
        setExportModalOpen(false);
    };

    const handleExport = () => {

        let isValid=true;

        const exportData: any = {
            path: "/export_customer_charges",
            username: username,
            module_name: "Charge history",
            request_received_at: getCurrentDateTime(),
            customer_name: selectedCustomers || null,
            session_ids: selectedSessions.length > 0 ? selectedSessions : sessionOptions,
            bill_period:selectedBillPeriods.length > 0 ? selectedBillPeriods : billPeriodOptions,
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
        };

        if( selectedCustomers.length=== 0){
            isValid=false
            setExportCustomerError(true)
        }
        if(errorMessage){
            isValid=false
        }
        if (isValid) {
            exportMutation.mutate(exportData);
        }
        console.log("isValid",exportCustomerError,errorMessage,isValid)
    };

    const downloadZipBlob = (base64Blob: string) => {
        // Convert base64 string to binary data
        const byteCharacters = atob(base64Blob);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);

        // Create a Blob from the byteArray with a type of zip
        const blobObject = new Blob([byteArray], {
            type: "application/zip",
        });

        // Create a download link and trigger it to download the .zip file
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blobObject);
        link.download = "Charge history.zip"; // Ensure to download as .zip
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const disableFutureDates = (current: any) => {
        console.log("future dates:", current && current > dayjs().endOf('day'));
        return current && current > dayjs().endOf('day');
    };


    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }

    return (
        <>
            <Suspense
                fallback={
                    <div className="flex justify-center items-center h-screen">
                        <Spin size="large" />
                    </div>
                }
            >
                <div className="relative">
                    <div className="p-4 flex items-center justify-between mt-1 mb-2">
                        <div className="flex space-x-2">
                            {features.includes("Search-Charge history") && (
                                <TableSearch
                                    searchTerm={searchTerm}
                                    setSearchTerm={setSearchTerm}
                                    tableName={"optimization_smi_result"}
                                    headerMap={headerMap}
                                // loader={loading}
                                />
                            )}
                            {features.includes("Advanced filter-Charge history") && (
                                <AdvancedMultiFilter
                                    showAdvanced={showAdvanced}
                                    setShowAdvanced={setShowAdvanced}
                                    onFilter={handleFilter}
                                    onReset={handleReset}
                                    headers={headers}
                                    headerMap={headerMap}
                                    tableName={"optimization_smi_result"}
                                />
                            )}
                        </div>
                        <div className="flex space-x-2">
                            {/* {features.includes("Export-Charge history") && ( */}
                            <button className="save-btn" onClick={handleExportModalOpen}>
                                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                                <span>Export</span>
                            </button>
                            {/* )} */}
                            <ColumnFilter
                                headers={headers}
                                visibleColumns={visibleColumns}
                                setVisibleColumns={setVisibleColumns}
                                headerMap={headerMap}
                            />

                        </div>
                    </div>

                    <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
                        <OptimizationTableComponent
                            headers={headers}
                            headerMap={headerMap}
                            initialData={tableData}
                            searchQuery={searchTerm}
                            visibleColumns={visibleColumns}
                            itemsPerPage={100}
                            moduleName="Charge history"
                            pagination={pagination}
                            advancedFilters={filteredData}
                        />
                    </div>
                    <Modal
                        title={
                            <span className="font-semibold text-xl space-y-3">
                                Export output
                            </span>
                        }
                        visible={isExportModalOpen}
                        onCancel={() => {
                            handleExportModalClose();
                            setDateRange([null, null]);
                        }}
                        footer={null}
                        centered
                        afterClose={() => setDateRange([null, null])}
                        style={{ top: "-4%" }}
                    >
                        {exportLoading ? (
                            <div className="flex justify-center items-center h-56">
                                <Spin size="large" />
                            </div>
                        ) : (

                            <div className="flex flex-col space-y-4">
                                <div>
                                    <label>
                                        Customers<span className="text-red-500">*</span>
                                    </label>
                                    <Select
                                        options={customerOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        }))}
                                        onChange={handleCustomerChange}
                                        value={selectedCustomers.map((customer: string) => ({ label: customer, value: customer }))}
                                        isMulti
                                        isClearable
                                    />
                                    {exportCustomerError && <span className="text-red-500">Please select customer</span>}
                                </div>

                                <div>
                                    <label>Sessions</label>
                                    <Select
                                        options={sessionOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        }))}
                                        onChange={handleSessionChange}
                                        value={selectedSessions.map((option: any) => ({ label: option, value: option }))}
                                        isMulti
                                        isDisabled={selectedCustomers.length === 0}
                                    />
                                </div>

                                <div>
                                    <label>Bill periods</label>
                                    <Select
                                        options={billPeriodOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        }))}
                                        onChange={handleBillPeriodChange}
                                        value={selectedBillPeriods.map((option: any) => ({ label: option, value: option }))}
                                        isMulti
                                        isDisabled={selectedCustomers.length === 0}
                                    />
                                </div>

                                {errorMessage && <span className="text-red-500">Select session and bill period from the same mapping</span>}

                                <div className="flex space-x-4 justify-center">
                                    <button className="cancel-btn" onClick={handleExportModalClose}>
                                        Cancel
                                    </button>
                                    <button className="save-btn" onClick={handleExport}>
                                        Export
                                    </button>
                                </div>
                            </div>


                        )}

                    </Modal>
                </div>
            </Suspense>
            <div>
            </div>
        </>

    );

};

export default CustomerCharges;
