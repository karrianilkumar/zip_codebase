"use client";
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
} from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Optimize from "@/app/sim_management/optimize";
const { RangePicker } = DatePicker;
const OptimizationTableComponent = lazy(() => import("@/app/components/optimizationTableComponent/page"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(() => import("@/app/components/advanced_search"));

const CustomerOptimization: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, selectedDb } = useAuth();
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isOptimizeModalVisible, setIsOptimizeModalVisible] = useState(false);
  const hasFetchedData = useRef(false);
  const {features:moduleFeatures,setFeatures:setModuleFeatures} = useFeatureStore();

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/get_optimization_data",
        role_name: role,
        parent_module: "Optimization",
        module_name: "Optimization",
        feature_module_name: "Optimization",
        optimization_type:"Customer",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const headersMap_ = parsedData?.headers_map?.["Customer"]?.header_map || {}
        const sortedheaderMap = sortHeaderMap(headersMap_)
        setHeaderMap(sortedheaderMap)
        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
        setHeaders(headers_)
        setVisibleColumns(headers_)
        const tableData_ = parsedData?.data || []
        setTableData(tableData_)
        const features_ = parsedData?.headers_map?.["Customer"]?.module_features || []
        setFeatures(features_)
        setModuleFeatures(features_)
        const pagination_ = parsedData?.pages || {}
        setPagination(pagination_)
      }
      // addLog('BulkChange Table Data Processing Data Completed');
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  }, [username, partner, role, token]);

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };
  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  const handleExport = async () => {
    if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
      Modal.error({ title: 'Error', content: 'Please select a date range.' });
      return;
    }

    const [startDate, endDate] = dateRange;

    const data = {
      path: "/export",
      username: username,
      module_name: "Customer Optimization",
      request_received_at: getCurrentDateTime(),
      start_date: startDate.format("YYYY-MM-DD 00:00:00"),
      end_date: endDate.format("YYYY-MM-DD 23:59:59"),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
    };

    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const response = await axios.post(url, { data: data }, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const resp = JSON.parse(response.data.body);
      const blob = resp.blob;
      console.log(resp);

      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          notification.success({
            message: 'Success',
            description: 'Successfully exported the record!',
            style: messageStyle,
            placement: 'top',
          });
          downloadBlob(blob);
        } else {
          console.log('Error message:', resp.message);
          Modal.error({
            title: 'Export Error',
            content: resp.message,
            centered: true,
          });
        }
      } else {
        console.log('Unexpected status code:', response.data.statusCode);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }

      handleExportModalClose();
    } catch (error) {
      console.error("Error downloading the file:", error);
      Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
    }
  };

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = 'Customer Optimization.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleOpenOptimizeModal = () => {
    setIsOptimizeModalVisible(true);
  };

  const handleOptimizeCancel = () => {
    setIsOptimizeModalVisible(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf('day'));
    return current && current > dayjs().endOf('day');
  };


  return (
    <>
      <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>
        <div className="relative">
          <div className="p-4 flex items-center justify-between mt-1 mb-4">
            <div className="flex space-x-2">

              {features.includes("Search-Customer optimization") && (
                <TableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"sim_management_bulk_change"}
                  headerMap={headerMap}
                />
              )}

              {features.includes("Advanced filter-Customer optimization") && (
                <AdvancedMultiFilter
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"sim_management_bulk_change"} />
              )}
            </div>


            <div className="flex space-x-2 items-center">
              {features.includes("Optimize-Customer optimization") && (
                <button className="save-btn" onClick={handleOpenOptimizeModal}>
                  <span>Optimize</span>
                </button>
              )}
              {features.includes("Export-Customer optimization") && (
                <button className="save-btn" onClick={handleExportModalOpen}>

                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />

            </div>
          </div>
          <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
            <OptimizationTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              moduleName="Customer optimization"
              pagination={pagination}
              advancedFilters={filteredData}

            />
          </div>
          <Modal
            title={<span className="font-semibold text-xl space-y-3">Export output</span>}
            visible={isExportModalOpen}
            onCancel={() => {
              handleExportModalClose();
              setDateRange([null, null]);
            }}
            footer={null}
            centered
            afterClose={() => setDateRange([null, null])}
            style={{ top: '-4%' }}
          >
            <div className="flex flex-col space-y-3">
              <span>Select date range</span>
              <RangePicker
                value={dateRange[0] && dateRange[1] ? [dateRange[0], dateRange[1]] : null}
                onChange={(dates) => {
                  console.log("Selected dates:", dates);
                  if (dates && dates.length === 2) {
                    setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                  } else {
                    setDateRange([null, null]);
                  }
                }}
                format="YYYY-MM-DD"
                disabledDate={disableFutureDates}
              />
              <div style={{ marginTop: '2rem' }} className="flex  justify-center gap-2 space-x-2">
                <button className="cancel-btn " onClick={handleExportModalClose} style={{ fontFamily: 'Calibre, sans-serif' }}>
                  <span className="font-[500]" >Cancel</span></button>
                <button className="save-btn font-[500]" onClick={handleExport} style={{ fontFamily: 'Calibre, sans-serif' }}>Export</button>
              </div>
            </div>
          </Modal>
          {isOptimizeModalVisible && (
            <Optimize
              isOpen={isOptimizeModalVisible}
              onCancel={handleOptimizeCancel}
              module_name={'Optimization'}
            />
          )}
        </div>
      </Suspense>
    </>
  );
};

export default CustomerOptimization;
