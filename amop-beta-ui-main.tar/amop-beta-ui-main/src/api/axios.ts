import {
  APPLICATION_JSON,
  AUTHORIZATION_HEADER,
  CONTENT_TYPE_HEADER,
  TENANT_ID_HEADER,
} from "@/common/constants/header-keys";
import axios, {
  AxiosInstance,
  AxiosRequestHeaders,
  InternalAxiosRequestConfig,
} from "axios";
import { stringify } from "qs";

export const BASE_API_URL = process.env.NEXT_PUBLIC_ADM_API_URL;
export const AMOP_CORE_URL = process.env.NEXT_PUBLIC_AMOP_1_BASE_URL;
export const AMOP_BASE_URL = process.env.NEXT_PUBLIC_AMOP_2_BASE_URL;

export const REFRESH_WAITING_TIME = 2000;

export const axiosClientConfigInstance = {
  isRefreshing: false,
  needRelogin: false,
};

export const axiosClientInstance: AxiosInstance = axios.create({
  baseURL: BASE_API_URL,
  headers: {
    "Content-Type": "application/json",
  },
  paramsSerializer: (params) =>
    stringify(params, {
      arrayFormat: "repeat", // to work with Fastify backend
      skipNulls: true,
    }),
});

//NextJS client side with Axios attaching authentication token on request
axiosClientInstance.interceptors.request.use(
  async (
    config: InternalAxiosRequestConfig<any>,
  ): Promise<InternalAxiosRequestConfig<any>> => {
    const token = localStorage.getItem("access_token");
    const tenantId = localStorage.getItem("tenant_id");
    const tenantName = localStorage.getItem("tenant_name");
    const dbName = localStorage.getItem("db_name");

    while (axiosClientConfigInstance.isRefreshing) {
      console.log("waiting for refresh token", config.url);

      await new Promise((resolve) => setTimeout(resolve, REFRESH_WAITING_TIME));
    }

    if (token) {
      config.headers = {
        ...config.headers,
        [AUTHORIZATION_HEADER]: `Bearer ${token}`,
        [CONTENT_TYPE_HEADER]: APPLICATION_JSON,
        [TENANT_ID_HEADER]: tenantId,
        "x-db-name": dbName,
        "x-tenant-name": tenantName,
      } as unknown as AxiosRequestHeaders;
    }

    return config;
  },
);
