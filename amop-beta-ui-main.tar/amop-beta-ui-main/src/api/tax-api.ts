import { axiosClientInstance } from "@/api/axios";
import { TAX_API } from "@/common/constants/api-constants";
import {
  TaxReportQueryParams,
  TaxReportRequest,
} from "@/types/tax-report-types";

export async function getTaxReportTransactions(query: TaxReportQueryParams) {
  const response = await axiosClientInstance.get(TAX_API.TRANSACTIONS, {
    params: query,
  });
  return response.data;
}

export async function exportTaxReportTransactions() {
  return await axiosClientInstance.get(TAX_API.TRANSACTIONS_EXPORT, {
    responseType: "blob",
  });
}

export async function exportTaxReport(request: TaxReportRequest) {
  return await axiosClientInstance.post(TAX_API.REPORTS_EXPORT, {
    ...request,
  });
}

export const getProfiles = async (): Promise<string[]> => {
  const response = await axiosClientInstance.get(TAX_API.PROFILE);
  return response.data;
};
