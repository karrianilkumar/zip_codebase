import { QualifyFormValues } from "@/app/service_qualification/qualification_tool/components/qualify-new-address-modal";
import { QUALIFICATION_API } from "@/common/constants/api-constants";
import {
  ServiceQualification,
  ServiceQualificationAddress,
  ServiceQualificationLog,
} from "@/types/qualification-types";
import { axiosClientInstance } from "./axios";

export async function getServiceQualificationHistory(
  page: number,
  limit: number,
  search?: string,
): Promise<{
  results: ServiceQualification[];
  totalResults: number;
  page: number;
}> {
  return axiosClientInstance
    .get(QUALIFICATION_API.LIST, {
      params: {
        page,
        limit,
        search,
      },
    })
    .then((response) => response.data);
}

export async function createServiceQualification(
  data: QualifyFormValues,
): Promise<ServiceQualification> {
  const { serviceType, ...address } = data;

  return axiosClientInstance
    .post(QUALIFICATION_API.CREATE, {
      serviceType,
      addresses: [
        {
          ...address,
        },
      ],
    })
    .then((response) => response.data);
}

export async function getServiceQualificationById(
  id: string,
): Promise<ServiceQualification> {
  return axiosClientInstance
    .get(QUALIFICATION_API.DETAIL(id))
    .then((response) => response.data);
}

export async function getAddressesQualificationById(
  id: string,
  page: number,
  limit: number,
): Promise<{
  results: ServiceQualificationAddress[];
  totalResults: number;
  page: number;
}> {
  return axiosClientInstance
    .get(QUALIFICATION_API.ADDRESSES(id), {
      params: {
        page,
        limit,
      },
    })
    .then((response) => response.data);
}

export async function checkAuthorization(): Promise<boolean> {
  return axiosClientInstance
    .get(QUALIFICATION_API.CHECK_AUTHORIZATION)
    .then((response) => {
      if (response.data?.status === "ok") {
        return true;
      }
      return false;
    })
    .catch(() => {
      return false;
    });
}

export async function exportResults(id: string): Promise<void> {
  return axiosClientInstance
    .get(QUALIFICATION_API.EXPORT_RESULTS(id), {
      responseType: "blob",
    })
    .then((response) => {
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `qualification-results-${id}.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    })
    .catch((error) => {
      console.error("Error exporting results:", error);
    });
}

export async function getQualificationAddressLogs(
  qualificationAddressId: number,
): Promise<ServiceQualificationLog[]> {
  return axiosClientInstance
    .get(QUALIFICATION_API.LOGS(qualificationAddressId))
    .then((response) => response.data)
    .catch((error) => {
      console.error("Error getting qualification logs:", error);
      return {
        results: [],
        totalResults: 0,
        page: 1,
      };
    });
}

export async function downloadUploadTemplate(): Promise<void> {
  const response = await axiosClientInstance.get(
    QUALIFICATION_API.DOWNLOAD_TEMPLATE,
    {
      responseType: "blob",
    },
  );

  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", "upload-template-qualification.xlsx");
  document.body.appendChild(link);
  link.click();
  link.remove();
}

export async function uploadQualification(file: File): Promise<void> {
  const formData = new FormData();
  formData.append("file", file);

  return axiosClientInstance.post(QUALIFICATION_API.UPLOAD, formData);
}

export async function requalifyQualification(
  id: number,
): Promise<ServiceQualification> {
  return axiosClientInstance
    .post(QUALIFICATION_API.REQUALIFY(id))
    .then((response) => response.data);
}

export function exportActivationTemplate(id: number): void {
  const url = QUALIFICATION_API.EXPORT_ACTIVATION_TEMPLATE(id);
  window.open(url, "_blank");
}
