import {
  PROVISION_API,
  PROVISION_API_ERROR,
} from "@/common/constants/api-constants";
import { axiosClientInstance } from "./axios";
import { ValidationError } from "@/common/errors/validation-error";
import { ProvisionParamState } from "@/types/provision-types";

export const getProvisionModelOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.MODEL, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.MODEL, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getProvisionGroupOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.GROUP, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.GROUP, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getProvisionLicenseOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.LICENSE, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API.LICENSE, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getCustomerOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.CUSTOMER, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.CUSTOMER, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getProviderOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.PROVIDER, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.PROVIDER, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getServiceOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.SERVICE, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.SERVICE, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getProductOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.PRODUCT, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.PRODUCT, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getPackageOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.PACKAGE, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.PACKAGE, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getPackageProducts = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(
      PROVISION_API.PACKAGE_PRODUCT,
      {
        params: options,
      },
    );
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.PACKAGE_PRODUCT, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getCustomerRatePlanOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(
      PROVISION_API.CUSTOMER_RATE_PLAN,
      {
        params: options,
      },
    );
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.CUSTOMER_RATE_PLAN, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getCustomerPoolOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(
      PROVISION_API.CUSTOMER_POOL,
      {
        params: options,
      },
    );
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.CUSTOMER_POOL, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const postProvisionData = async (data: object) => {
  const response = await axiosClientInstance.post(
    PROVISION_API.PROVISIONING_CREATE_V2,
    data,
  );
  return response;
};

export const postValidateProvisionData = async (data: object) => {
  try {
    const response = await axiosClientInstance.post(
      PROVISION_API.PROVISIONING_VALIDATE,
      data,
    );
    return response;
  } catch (error: any) {
    if (error?.response?.status === 400 && error?.response?.data?.length > 0) {
      throw new ValidationError(error?.response?.data[0]);
    }
    throw new Error(PROVISION_API_ERROR.PROVISIONING_VALIDATE_POST, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const postActivateData = async (data: object) => {
  const response = await axiosClientInstance.post(
    PROVISION_API.ACTIVATE_ICCID,
    data,
  );
  return response;
};

export const getServiceProviderOptions = async (options: object) => {
  try {
    const response = await axiosClientInstance.get(
      PROVISION_API.SERVICE_PROVIDER,
      {
        params: options,
      },
    );
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.ACTIVATE_PROVIDER, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const exportProvisionData = async (params: ProvisionParamState) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.EXPORT, {
      params,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.EXPORT, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};
