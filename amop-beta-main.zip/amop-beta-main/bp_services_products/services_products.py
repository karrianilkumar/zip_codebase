"""
@Author1 : Srikanth R
Created Date: 27-12-2024
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict
#download template dependencies
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
#authorize.net dependencies
import xml.etree.ElementTree as ET
import xml.etree.ElementTree as ET
from io import StringIO
# from lxml import etree
import xml.etree.ElementTree as ET
from openpyxl.styles import Alignment, PatternFill, Font


# Dictionary to store database configuration settings retrieved from environment variables.
common_utils_database_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="services_products")

def db_config_maker(user,db_config_making):
    """
    Creates and returns an updated database configuration by adding customer 
    and service provider details for the given user.

    This function:
    - Connects to the COMMON_UTILS_DATABASE
    - Fetches the customers and service providers assigned to the user
    - Updates the db_config_making dictionary with these details

    Args:
        user (str): The username for which to fetch customer and service provider data.
        db_config_making (dict): Basic DB connection config (host, port, user, password)

    Returns:
        dict: Updated db_config with 'customers' and 'service_providers' keys added.
    """

    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config_making)

    query=f"select customers,service_provider from users where username ='{user}'"
    filters=common_utils_database.execute_query(query,True)
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting customer: {str(e)}")
      customer= None     

    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting service_provider: {str(e)}")
      service_provider=None   

    db_config_making["customers"]= customer
    db_config_making["service_providers"]=service_provider

    return db_config_making

def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    try:
        current_time = datetime.now()
        logging.info(f"###{path},time started : {current_time}, data received is : {data}")
    except Exception as e:
        logging.error(f"Error in function_caller: {e}")
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    db_config_making = db_config_maker(user, db_config)
    db_config = db_config_making
    logging.info(f"### db_config created is : {db_config}")

    # Map API paths to corresponding handler functions
    path_function_map = {
    "/services_list_view": services_list_view,
    "/products_list_view": products_list_view,
    "/product_type_list_view": product_type_list_view,
    "/services_product_package_list_view": services_product_package_list_view,
    "/product_package_pop_up_list_view": product_package_pop_up_list_view,
    "/services_built_in_fields": services_built_in_fields,
    "/add_service_type": add_service_type,
    "/update_billing_actions_data": update_billing_actions_data,
    "/add_product_type": add_product_type,
    "/add_product": add_product,
    "/add_package": add_package,
    "/product_package_pop_up_list_view_data": product_package_pop_up_list_view_data,
    "/get_token": get_token,
    "/download_bulk_upload_template": download_bulk_upload_template,
    "/import_bulk_data": import_bulk_data,
    "/products_export": products_export,
    "/get_export_status": get_export_status,
    "/download_template_reupload": download_template_reupload,
    "/download_template_for_service_types": download_template_for_service_types,
    "/bulk_upload_service_types": bulk_upload_service_types,
    "/reupload_service_types": reupload_service_types,
    "/reupload_products": reupload_products,
    "/reupload_packages": reupload_packages,
    "/update_service_type": update_service_type,
    "/update_service_type_status": update_service_type_status,
    "/copy_service_type": copy_service_type,
    "/update_products": update_products,
    "/update_product_status": update_product_status,
    "/copy_products": copy_products,
    "/update_package": update_package,
    "/update_package_status": update_package_status,
    "/copy_package": copy_package,
    "/fetch_active_customer_services_by_service_type": fetch_active_customer_services_by_service_type,
}

    # Route to the correct function based on the path
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

def get_token(data):
    try:
        amount_from_invoice = data.get('amount','100')
        account_id=data.get('account_number','128445')
        email=data.get('email','srikanth.rekkala@algonox.com')
        invoice_id=data.get('target_invoice_id','120')
        print('###data',data)
        if not account_id:
            response = {
                "flag": False,
                "message": "Account Number is empty"
            }
            return response
        if not invoice_id:
            response = {
                "flag": False,
                "message": "Invoice Id is empty"
            }
            return response
        if not email:
            response = {
                "flag": False,
                "message": "Email is empty"
            }
            return response
        # update_query = f"UPDATE invoices_payment_status SET payment_status = 'success' WHERE invoice_id = '{invoice_id}'"
        # Killbill_db_connection = DB('killbill', **db_config)
        # res=Killbill_db_connection.execute_(update_query)
        # Create the root element
        root = ET.Element('getHostedPaymentPageRequest', xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd")

        # Merchant Authentication
        merchant_authentication = ET.SubElement(root, 'merchantAuthentication')
        ET.SubElement(merchant_authentication, 'name').text = '2J3vSx5dBSG'
        ET.SubElement(merchant_authentication, 'transactionKey').text = '8kL8NkuGT8736R9P'

        # Transaction Request
        transaction_request = ET.SubElement(root, 'transactionRequest')
        ET.SubElement(transaction_request, 'transactionType').text = 'authCaptureTransaction'
        ET.SubElement(transaction_request, 'amount').text = amount_from_invoice

        profile = ET.SubElement(transaction_request, 'profile')
        # ET.SubElement(profile, 'customerProfileId').text = '926706175'
        ET.SubElement(profile, 'customerProfileId').text = '926706175'
        customer = ET.SubElement(transaction_request, 'customer')
        # ET.SubElement(customer, 'email').text = 'ellen@mail.com'
        ET.SubElement(customer, 'email').text = email
        bill_to = ET.SubElement(transaction_request, 'billTo')
        ET.SubElement(bill_to, 'firstName').text = ''
        ET.SubElement(bill_to, 'lastName').text = ''
        ET.SubElement(bill_to, 'company').text = ''
        ET.SubElement(bill_to, 'address').text = ''
        ET.SubElement(bill_to, 'city').text = ''
        ET.SubElement(bill_to, 'state').text = ''
        ET.SubElement(bill_to, 'zip').text = ''
        ET.SubElement(bill_to, 'country').text = ''

        # Hosted Payment Settings
        hosted_payment_settings = ET.SubElement(root, 'hostedPaymentSettings')

        # Hosted Payment Return Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentReturnOptions'
        # ET.SubElement(setting, 'settingValue').text = '{"showReceipt": true, "url": "https://mysite.com/receipt", "urlText": "Continue", "cancelUrl": "https://mysite.com/cancel", "cancelUrlText": "Cancel"}'
        ET.SubElement(setting, 'settingValue').text = (
    '{"showReceipt": true, '
    f'"url": "https://qa-billing.amop.services/accounts/{account_id}/payments/new?invoice_id={invoice_id}", '
    '"urlText": "Continue", '
    f'"cancelUrl": "https://qa-billing.amop.services/accounts/{account_id}/payments/new?invoice_id={invoice_id}", '
    '"cancelUrlText": "Cancel"}')

        # Hosted Payment Button Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentButtonOptions'
        ET.SubElement(setting, 'settingValue').text = '{"text": "Pay"}'

        # Hosted Payment Style Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentStyleOptions'
        ET.SubElement(setting, 'settingValue').text = '{"bgColor": "blue"}'

        # Hosted Payment Payment Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentPaymentOptions'
        ET.SubElement(setting, 'settingValue').text = '{"cardCodeRequired": false, "showCreditCard": true, "showBankAccount": true}'

        # Hosted Payment Security Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentSecurityOptions'
        ET.SubElement(setting, 'settingValue').text = '{"captcha": false}'

        # Hosted Payment Shipping Address Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentShippingAddressOptions'
        ET.SubElement(setting, 'settingValue').text = '{"show": false, "required": false}'

        # Hosted Payment Billing Address Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentBillingAddressOptions'
        ET.SubElement(setting, 'settingValue').text = '{"show": true, "required": false}'

        # Hosted Payment Customer Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentCustomerOptions'
        ET.SubElement(setting, 'settingValue').text = '{"showEmail": false, "requiredEmail": false, "addPaymentProfile": true}'

        # Hosted Payment Order Options
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentOrderOptions'
        ET.SubElement(setting, 'settingValue').text = '{"show": true, "merchantName": "Altaworx"}'

        # Hosted Payment IFrame Communicator Url
        setting = ET.SubElement(hosted_payment_settings, 'setting')
        ET.SubElement(setting, 'settingName').text = 'hostedPaymentIFrameCommunicatorUrl'
        ET.SubElement(setting, 'settingValue').text = '{"url": "https://qa-billing.amop.services/kb/iframecommunicator.html"}'

        # Convert the tree to a string
        tree = ET.ElementTree(root)
        output = StringIO()
        tree.write(output, encoding="unicode", xml_declaration=True)
        # xml_string = output.getvalue().decode('utf-8')
        print('###output.getvalue()',output.getvalue())
        # return output.getvalue()
        url = 'https://apitest.authorize.net/xml/v1/request.api'  # Replace with actual URL of the API
        headers = {'Content-Type': 'application/xml'}
        
        xml_data = output.getvalue() # Assuming the get_token function creates the XML as described earlier

        # Send the request to the payment gateway
        response = requests.post(url, headers=headers, data=xml_data)
        print('####response',response)
        print('###response.text',response.text)
    
        if response.status_code == 200:
            try:
                root = ET.fromstring(response.text)
                namespaces = {
    'ns': 'AnetApi/xml/v1/schema/AnetApiSchema.xsd'  # Replace with the actual namespace
}
                token_element = root.find('.//ns:token', namespaces)
                if token_element is not None:
                    token = token_element.text
                    print(f"Token: {token}")
                    message='Token generated successfully'
                    response = {
                                "flag": True,
                                "message": "Token generated successfully",
                                "token":token
                                }
                    print(response)
                    return response
                else:
                    print("Token element not found in the response")
                    return 'token not found'
                for elem in root.iter():
                    print(f"Element: {elem.tag}, Text: {elem.text}")
            except Exception as e:
                return f"Error parsing response: {str(e)}"
        else:
            return f"Error: Received {response.status_code} from API"
        
    except Exception as e:
        # Handle any exceptions and return an error message
        return f"An error occurred: {str(e)}"

def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")
    try:
        logging.info(f"tenant_name is {tenant_name}")
        # Retrieve tenant ID based on tenant name
        tenant_id = database.get_data(
            "tenant", {"tenant_name": tenant_name},["id"]
        )["id"].to_list()[0]
    except Exception as e:
        logging.warning(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database, parent_module_name, role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out

def convert_timestamps_without_timezone(obj):
    """Recursively convert pandas.Timestamp (or datetime) to 'MM-DD-YYYY HH:MM:SS' strings."""
    if isinstance(obj, dict):
        return {k: convert_timestamps(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_timestamps(i) for i in obj]
    elif isinstance(obj, (pd.Timestamp, datetime)):
        return obj.strftime("%m-%d-%Y %H:%M:%S")
    else:
        return obj


def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def convert_timestamp(df_dict, tenant_time_zone):
    """Convert timestamp columns in the provided dictionary list to the tenant's timezone."""
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict
def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object

def services_list_view(data):
    """
    Fetches a list of services based on tenant and filters with pagination.
    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): The tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name for header mapping.
            - tenant_name (str): The tenant name for fetching timezone and metadata.
            - mod_pages (dict): Pagination details:
                - start (int): Start index for records. Defaults to 0.
                - end (int): End index for records. Defaults to 100.
    Returns:
        dict: A dictionary containing the status, processed data, pagination info, and dropdown options.
    """
    logging.info(f'## services_list_view function called with data {data}')
    try:
        # Initialize DB connections
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        
        data = readme_api_data(common_utils_database,data)
        
        tenant_db_name = data.get('db_name', '')
        if not tenant_db_name:
            return {"flag": False,"message": "Empty Tenant Database"}
        tenant_database = DB(tenant_db_name, **db_config)

        # Extract inputs with defaults
        role_name = data.get('role_name', '')
        tenant_name =data.get('tenant_name','')
        flag =data.get('status', '')
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', 1)
        mode = os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1

        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)
        col_sort = data.get("col_sort", "")

        limit = end - start
        offset = start

        # Fetch tenant id and timezone
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["time_zone"]
        )

        if tenant_data.empty:
            raise ValueError("No valid tenant found.")

        tenant_time_zone = tenant_data["time_zone"].to_list()[0]
        if tenant_time_zone is None:
                raise ValueError("No valid timezone found for tenant.")
        
        # tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        # Query to get the total number of rows for pagination
        filter_conditions = {"is_deleted": "false", "tenant_id": tenant_id}
        if flag == 'true':
            filter_conditions["is_active"] = flag

        total_count_result = killbill_database.get_data(
            "services", filter_conditions, ["id"]
        )["id"].to_list()

        total_count=len(total_count_result)
        
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }   
        
        base_query = f"SELECT * FROM services WHERE tenant_id = '{tenant_id}'"
        if flag == 'true':
            base_query += " AND is_active = true"

        if col_sort:
            order={k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY convert_to(description, 'SQL_ASCII')"  # Default sorting

        # Add LIMIT and OFFSET
        base_query += " LIMIT %s OFFSET %s"

        # Execute query with limit and offset for pagination
        params = [limit, offset]
        df = killbill_database.execute_query(base_query, params=params)  # Get the DataFrame directly
        df_dict = df.to_dict(orient="records")
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        # --- Service Providers from tenant_database
        service_provider_query = tenant_database.get_data(
            "serviceprovider", columns=["id", "display_name"]
        )
        provider_name_dict = dict(zip(service_provider_query["id"], service_provider_query["display_name"]))
        # provider_list = {
        #     name for name in service_provider_query["display_name"].tolist() if name is not None
        # }
        provider_list = {
            f"{name} -- AMOP" for name in service_provider_query["display_name"].tolist() if name is not None
        }

        # --- Service Providers from killbill_database (bp)
        service_provider_query_bp = killbill_database.get_data(
            "serviceprovider",{'is_active': True, 'tenant_id': tenant_id}, columns=["id", "display_name"]
        )
        provider_name_dict_bp = dict(zip(service_provider_query_bp["id"], service_provider_query_bp["display_name"]))
        # provider_list_bp = {
        #     name for name in service_provider_query_bp["display_name"].tolist() if name is not None
        # }
        provider_list_bp = {
            f"{name} -- BP" for name in service_provider_query_bp["display_name"].tolist() if name is not None
        }

        # Combine lists based on unique display_name
        combined_provider_list = sorted(provider_list.union(provider_list_bp),key=str.lower)

        service_locations_query = killbill_database.get_data("service_locations", columns=["states"])
        service_location_list = sorted(list(set(service_locations_query["states"].tolist())))
        
        dropdown={
        "display_name":combined_provider_list,
        "service_location":service_location_list,
        "primary_field": ["ICCID", "IMEI", "MSISDN", "EID", "Custom"]
        }

        for record in df_dict:
            if record.get('built_in_fields'):
                record['built_in_fields']=ast.literal_eval(record.get('built_in_fields'))
            if record.get('custom_fields'):
                record['custom_fields']=ast.literal_eval(record.get('custom_fields'))

        # Prepare response data
        header_map = get_headers_mapping(killbill_database,["Billing Services"],role_name, '', '', '', '',data)
        final_data_dict=serialize_data(df_dict)
        for record in final_data_dict:
            service_provider_name_=record.get('service_provider_name', '')
            try:
                record['display_name'] = json.loads(service_provider_name_) if service_provider_name_ else service_provider_name_
                logging.info(f"record['display_name']---{record['display_name']}")
            except Exception as e:
                logging.info(f"Exception in services_list_view: {e}")
                record['display_name']=service_provider_name_

        data_dict_all = {"billing_services": final_data_dict}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown":dropdown,
            "pages": pages_data
        }
        if data.get("z_access_token", ""):
            list_view_columns = {"id", "description", "created_by", "modified_date", "modified_by", "status"}
            final_data_dict = [
                {k: d[k] for k in list_view_columns if k in d}
                for d in final_data_dict
            ]
            return {"data":{"billing_services": final_data_dict}}
        else:
            return response

    except Exception as e:
        logging.exception(f"Exception in services_list_view: {e}")
        error_data = {
            "service_name": "services_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": "Failed to fetch services list",
            "module_name": "Services",
            "request_received_at": data.get("request_received_at", "")
        }
        billing_platform_database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response


def services_built_in_fields(data):
    """
    Fetches the header mapping for billing services built-in fields.
    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): The tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name for header mapping.
            - tenant_name (str): The tenant name for fetching metadata.
    Returns:
        dict: A dictionary containing the status, header mapping, and a success or error message.
    """
    logging.info(f'## services_built_in_fields function called with data {data}')
    try:
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        # Initialize DB connections
        billing_db_name = data.get("billing_db_name", "")
        if not billing_db_name:
            return {"flag": False,"message": "Billing Database is Required"}
        killbill_database = DB(billing_db_name, **db_config)

        tenant_database = data.get('db_name','')
        if not tenant_database:
            return {"flag": False,"message": "Tenant Database is Required"}
        role_name = data.get('role_name', '')
        tenant_name =data.get('tenant_name','')
        # Prepare response data
        # header_map = get_headers_mapping(tenant_database,["Billing Services Builtin Fields"],role_name, '', '', '', '',data)
        header_map = get_headers_mapping(tenant_database,["Service Types Builtin Fields"],role_name, '', '', '', '',data)
        # if "Billing Services Builtin Fields" in header_map and "pop_up" in header_map["Billing Services Builtin Fields"]:
        if "Service Types Builtin Fields" in header_map and "pop_up" in header_map["Service Types Builtin Fields"]:
            # header_map["Billing Services Builtin Fields"]["pop_up"].sort(key=lambda x: x["display_name"].lower())
            header_map["Service Types Builtin Fields"]["pop_up"].sort(key=lambda x: x["display_name"].lower())
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "header_map": header_map
        }
        return response

    except Exception as e:
        logging.exception(f"###services_built_in_fields:Exception occurred: {e}")
        error_data = {
            "service_name": "services_built_in_fields",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": "Failed to fetch services built in fields",
            "module_name": "Services",
            "request_received_at": data.get("request_received_at", ""),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching service built in fields",
            "data": {}  # Return empty dictionary on error
        }
        return response

def add_service_type(data):
    logging.info(f'## add_service_type function called with data {data}')
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

    data=readme_api_data(common_utils_database,data)
    if data.get("z_access_token", ""):
        # prepare custom_fields list
        custom_fields_str = data.get("custom_fields", "")
        built_in_fields=data.get("built_in_fields", "")
        custom_fields_list = []
        built_in_fields_list=[]
        if custom_fields_str:
            custom_fields_list = [
                {"field": field.strip(),"type":"text","db_column_name":field.strip()} for field in custom_fields_str.split(",")
            ]
        if built_in_fields:
            built_in_fields_list=[
                {"field": field,"type":"text", "db_column_name":field} for field in built_in_fields
            ]

        

        # final changed_data
        data["changed_data"] = {
            "description": data.get("description", ""),
            "primary_field": data.get("primary_field", ""),
            "display_name": data.get("service_provider", ""),
            "service_location": data.get("service_location", ""),
            "custom_fields": custom_fields_list,
            "built_in_fields":built_in_fields_list
        }

    tenant_db_name = data.get('db_name', '')
    if tenant_db_name == "null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    # Basic request context info
    created_by = data.get('username', '')
    modified_by = data.get('username', '')
    modified_date = data.get('request_received_at', '')
    Partner = data.get("Partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    request_received_at = data.get("request_received_at", "")
    start_time = time.time()
    action = data.get("action", "")
    tenant_name = data.get('tenant_name', '')
    tenant_id = data.get('tenant_id', 1)

    mode = os.getenv('ENV', 'UAT')
    if mode == 'UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    try:
        # Extract changed fields
        changed_data = data['changed_data']
        builtInFields = changed_data.pop('builtInFields', {})
        customFields = changed_data.pop('customFields', {})
        display_name = changed_data.pop('display_name', None)
        logging.info(f"## add_service_type display_name: {display_name}")
        if display_name:
            # Remove " -- AMOP" or " -- BP" at the end
            cleaned = [re.sub(r"\s*--\s*(AMOP|BP)$", "", name) for name in display_name]
            changed_data["service_provider_name"] = json.dumps(cleaned)
        else:
            changed_data["service_provider_name"] = None
        #changed_data['service_provider_name'] = json.dumps(display_name) if display_name else None
        logging.info(f"## add_service_type service_provider_name: {changed_data['service_provider_name']}")

        # Remove 'id' if it's present
        changed_data.pop('id', None)


        # not allowing duplicat service types
        service_type=changed_data.get('description')
        service_type = service_type.strip()
        service_type_query = killbill_database.get_data(
            "services", {"description": service_type,"tenant_id":tenant_id}, ["id"]
        )
        if not service_type_query.empty:
            error_data = {
                "service_name": "add_service_type",
                "error_message": "Duplicate Service Type",
                "error_type": "Duplicate Service Type",
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"Duplicate Service Type-- {service_type}",
                "module_name": "Billing Services",
                "request_received_at": request_received_at
            }
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag":True,"message":"Service Type already exists","validation": True}
        

        # Merge built-in fields for 'create' action
        if action.lower() == 'create':
            for i in builtInFields:
                if i not in changed_data:
                    changed_data[i] = builtInFields[i]
            changed_data['custom_field'] = customFields

        # Fetch provider_id
        provider_id = None
        if display_name:
            # Try tenant_database first
            serviceprovider_result = tenant_database.get_data(
                "serviceprovider", {"display_name": display_name}, ["id"]
            )
            if not serviceprovider_result.empty:
                provider_id = serviceprovider_result["id"].to_list()[0]
            else:
                # Check killbill_database
                serviceprovider_result_bp = killbill_database.get_data(
                    "serviceprovider", {"display_name": display_name}, ["id"]
                )
                if not serviceprovider_result_bp.empty:
                    provider_id = serviceprovider_result_bp["id"].to_list()[0]

        logging.info(f"## add_service_type provider_id: {provider_id}")

        changed_data['provider_id'] = provider_id if provider_id is not None else None
        changed_data['status'] = 'Active'
        changed_data['created_by'] = created_by
        changed_data['modified_by'] = modified_by
        changed_data['tenant_id'] = tenant_id if tenant_name else None
        changed_data['tenant_name'] = tenant_name if tenant_name else None

        # Filter out invalid values
        changed_data = {
            k: (v if k == "service_provider_name" else str(v))
            for k, v in changed_data.items()
            if v not in (None, "None", "")
        }
        logging.info(f"## add_service_type changed_data: {changed_data}")

        # Execute insert
        status = killbill_database.insert_data(changed_data, 'services')

        if status:
            response = {"flag": True, "message": "Successfully added Service Type"}

            # Audit success
            end_time = time.time()
            time_consumed = int(float(f"{end_time - start_time:.4f}"))
            audit_data_user_actions = {
                "service_name": "add_service_type",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f'Successfully added Service Type----{service_type}',
                "module_name": "Billing Services",
                "request_received_at": request_received_at,
                "service_provider_id": provider_id,
                "request_data":json.dumps(changed_data),
                "response_data":json.dumps(response)
            }
            database.update_audit(audit_data_user_actions, "audit_user_actions")
        else:
            response = {"flag": False, "message": "Error adding Service Type"}

            # Audit failure (business logic issue)
            error_data = {
                "service_name": "add_service_type",
                "error_message": "Insert returned False",
                "error_type": "InsertError",
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"DB insert failed while adding service type.Tried inserting:{changed_data} ",
                "module_name": "Billing Services",
                "request_received_at": request_received_at
            }
            database.log_error_to_db(error_data, "error_log_table")

        return response

    except Exception as e:
        logging.exception(f"Exception in add_service_type: {e}")
        response = {"flag": False, "message": "Failed to add the data"}

        # Audit exception
        error_data = {
            "service_name": "add_service_type",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": "Exception occurred while adding service type",
            "module_name": "Billing Services",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return response

def ps_codes_list_new(data):
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)

    ps_codes_df = killbill_database.get_data(
        "ps_bundle_codes",
        {},
        ["rule_name", "label", "ps_code"],
        {'rule_name':'asc'}
    )
    if ps_codes_df.empty:
        return []

    # Build the list with required format
    bundle_code_list = [
            f"{row['rule_name']}"
            for _, row in ps_codes_df.iterrows()
        ]


    ps_codes_list = [
            f"{row['ps_code']} - {row['label']}"
            for _, row in ps_codes_df.iterrows()
        ]


    return ps_codes_list, bundle_code_list

def ps_codes(data):
    """
    Generate a sorted list of product service (ps) codes and their descriptions 
    by combining data from a database and an external API.
    Args:
        data (dict): A dictionary containing the following key:
            - "billing_db_name" (str): The name of the billing database.
    Returns:
        list: A sorted list of strings, where each string represents a ps code 
        in the format "rule_name - ps_code - label" for database entries or 
        "No BundleCode - ps_code - description" for API entries not found in 
        the database. The list is sorted by the ps_code.
    """
    try:
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)

        # Fetch DB ps codes
        ps_codes_df = killbill_database.get_data(
            "ps_bundle_codes",
            {},
            ["rule_name", "label", "ps_code"],
            {"ps_code": "asc"}
        )

        # Convert DB ps_codes to set for comparison
        db_ps_code_set = set(ps_codes_df["ps_code"].dropna().astype(str)) if not ps_codes_df.empty else set()

        # Call API
        ceratx_response = ps_codes_list()
        api_ps_codes_description_list = ceratx_response.get("ps_codes_description_list", [])

        final_list = []

        # Add DB ps codes in required format
        if not ps_codes_df.empty:
            for _, row in ps_codes_df.iterrows():
                final_list.append(
                    f"{row['rule_name']} - {row['ps_code']} - {row['label']}"
                )

        # Add API ps codes which are NOT in DB
        for item in api_ps_codes_description_list:
            # item format: "psCode - description"
            ps_code, description = item.split(" - ", 1)

            if ps_code not in db_ps_code_set:
                final_list.append(
                    f"No BundleCode - {ps_code} - {description}"
                )

        # Sort final list using ps_code
        def extract_ps_code(value):
            return value.split(" - ")[1]

        final_list.sort(key=extract_ps_code)

        return final_list
    except Exception as e:
        logging.exception(f"###pscodes Exception in ps_codes: {e}")
        billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        error_data = {
            "service_name": "ps_codes",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": "Failed to fetch PsCodes list",
            "module_name": "Proucts",
            "request_received_at": data.get("request_received_at", "")
        }
        billing_platform_database.log_error_to_db(error_data, "error_log_table")
        return []

def products_list_view(data):
    """
    Fetches a paginated list of products along with dropdown data for filtering.
    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name.
            - tenant_name (str): Tenant name to determine timezone.
            - mod_pages (dict): Pagination details, with keys:
                - start (int): Start index for pagination. Defaults to 0.
                - end (int): End index for pagination. Defaults to 100.
    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation.
            - message (str): Success or failure message.
            - data (dict): Contains `billing_products` as a list of serialized product records.
            - header_map (dict): Header mapping for the frontend.
            - dropdown (dict): Dropdown values for filtering options.
            - pages (dict): Pagination details including start, end, and total record count.
    """
    try:
        # Setup DB connections
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_name = data.get('db_name', '')
        if tenant_db_name=="null":
            tenant_db_name = "altaworx_test"
        tenant_database = DB(tenant_db_name, **db_config)

        # Input values
        role_name = data.get('role_name', '')
        tenant_name = data.get('tenant_name', '')
        col_sort = data.get("col_sort", "")
        status_is = data.get('status', '')
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)
        limit, offset = end - start, start
        tenant_id = data.get('tenant_id', 1)
        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1

        # Get timezone from tenant table
        tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["time_zone"])
        if tenant_data.empty:
            raise ValueError("No valid tenant found.")

        tenant_time_zone = tenant_data["time_zone"].to_list()[0]
        if tenant_time_zone is None:
                raise ValueError("No valid timezone found for tenant.")
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly 

        
        # Build total count query
        count_query = (
            "SELECT COUNT(*) AS total FROM products_list_view "
            "WHERE tenant_id = %s AND is_deleted = false"
        )
        if status_is == 'true':
            count_query += " AND is_active = true"
        
        total_count_result = killbill_database.execute_query(count_query, params=[tenant_id], flag=True)
        total_count = int(total_count_result.iloc[0]['total'])

        pages_data = {"start": start, "end": end, "total": total_count}    

        
        # Build main product query
        base_query = (
            "SELECT * FROM products_list_view WHERE tenant_id = %s AND is_deleted = false"
        )
        if status_is == 'true':
            base_query += " AND is_active = true"

        if col_sort:
            col, direction = next(iter({k: v.lower() for k, v in col_sort.items()}.items()))
            base_query += f" ORDER BY {col} {direction}"
        else:
            base_query += " ORDER BY description"

        base_query += " LIMIT %s OFFSET %s"
        df = killbill_database.execute_query(base_query, params=[tenant_id, limit, offset])
        df_dict = df.to_dict(orient="records")

        # Fetch dropdowns
        gl_codes = list(set(killbill_database.get_data("gl_code", {"is_active":True,"sub_tenant_id":tenant_id}, ["gl_codes"])["gl_codes"].to_list()))
        
        product_type_df = killbill_database.get_data(
            "product_types", {"is_active": True, "tenant_id": tenant_id}, ["description", "tax_class", "tax_type", "ps_code"]
        )
        product_type = dict(zip(product_type_df["description"], product_type_df["tax_class"]))
        product_type_1 = dict(zip(product_type_df["description"], product_type_df["tax_type"]))
        product_type_2 = dict(zip(product_type_df["description"], product_type_df["ps_code"]))
        # sorting
        if product_type:
            product_type = {key: product_type[key] for key in sorted(product_type.keys())}

        service_type = killbill_database.get_data(
            "services", {"is_active": True, "tenant_id": tenant_id}, ["description"]
        )["description"].to_list()
        print(f"service_type33--{service_type}")
        service_type = sorted(
        {item for item in service_type if isinstance(item, str)},
        key=str.lower
        )
        print(f"service_type--{service_type}")

        provider_accounts = sorted(set(
        account for account in killbill_database.get_data("products", None, ["provider_accounts"])["provider_accounts"].to_list()
        if account  # Excludes None and empty strings
        ))

        # --- Service Providers from tenant_database
        service_provider_query = tenant_database.get_data(
            "serviceprovider", columns=["id", "display_name"]
        )
        provider_name_dict = dict(zip(service_provider_query["id"], service_provider_query["display_name"]))
        provider_list = {
            name for name in service_provider_query["display_name"].tolist() if name is not None
        }

        # --- Service Providers from killbill_database (bp)
        service_provider_query_bp = killbill_database.get_data(
            "serviceprovider",{'is_active': True,'tenant_id': tenant_id} ,columns=["id", "display_name"]
        )
        provider_name_dict_bp = dict(zip(service_provider_query_bp["id"], service_provider_query_bp["display_name"]))
        provider_list_bp = {
            name for name in service_provider_query_bp["display_name"].tolist() if name is not None
        }

        # Combine lists based on unique display_name
        combined_provider_list = sorted(provider_list.union(provider_list_bp), key=str.lower)
        dropdown_result = killbill_database.get_data("products", None, ["apply_to", "rate"])
        apply_to = list(set(dropdown_result["apply_to"].to_list()))
        rate = list(set(dropdown_result["rate"].to_list()))
        
        # Static dropdowns
        also_apply_to = ["New Allowance Scope", "SMS/MMS free minutes"]
        bill_every = [
            "Follow Account", "1 Month", "3 Months", "6 Months", "1 Year",
            "2 Years", "3 Years", "4 Years", "5 Years", "6 Years", "7 Years",
            "8 Years", "9 Years", "10 Years"
        ]
        # pt_code_df = killbill_database.get_data("product_type_code", None, ["id", "product_type_codes"])
        # pt_code_df=sorted(set(pt_code_df["product_type_codes"].to_list()))
        pt_code_df=["Onetime","Recurring"]

        #get tenant based  product descriptions for editable dropdown
        # descriptions = sorted(set(record["description"] for record in df_dict))

        dropdown = {
            "multi_provider_accounts": provider_accounts,
            "product_type": product_type,
            "product_type_1": product_type_1,
            "product_type_2": product_type_2,
            "tax_class": tax_class_list(),
            "tax_type": tax_types_list(),
            #"ps_code": ps_codes_list(),
            "ps_code": ps_codes(data),
            "multi_service_id": service_type,
            "service_provider": combined_provider_list,
            "apply_to": also_apply_to,
            "bill_every": bill_every,
            "rate": rate,
            "g_l_code": gl_codes,
            "business_type": [
                "10-CLEC",
                "11-IXC",
                "12-CMRS/Wireless",
                "14-Prepaid Wireless",
                "15-VoIP"],
            "product_type_code":pt_code_df
        }
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        # Prepare response data
        header_map = get_headers_mapping(killbill_database,["Billing Products"],role_name, '', '', '', '',data)
        # data_dict_all = {"billing_products": serialize_data(df_dict)}
        final_df_dict=serialize_data(df_dict)
        try:
            for product in final_df_dict:
                product['product_type']=product.get('product_type')
                for key in ["multi_options", "multi_service_id", "multi_provider_accounts"]:
                    value = product.get(key)
                    if value not in [None, 'null', '']:
                        try:
                            product[key] = json.loads(value)
                        except Exception as e:
                            logging.error(f"Error parsing  using json.loads {key}: {e}")
                            try:
                                product[key] = ast.literal_eval(value)
                            except Exception as e:
                                logging.error(f"Error parsing literal_eval {key}: {e}")
                                product[key] = []
                    else:
                        product[key] = []
        except Exception as e:
            pass
        data_dict_all = {"billing_products": final_df_dict}
        
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown" : dropdown,
            "pages": pages_data
        }
        return response

    except Exception as e:
        logging.exception(f"###products_list_view :Exception occurred: {e}")
        error_data = {
            "service_name": "products_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": "Failed to fetch Products list",
            "module_name": "Services",
            "request_received_at": data.get("request_received_at", "")
        }
        billing_platform_database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Products list",
            "data": {}  # Return empty dictionary on error
        }

        return response
def add_product(data):
    """
    Adds a new product to the database and stores related data for package.
    """
    try:
        logging.info(f"###add_product---data-{data}")
        start_time = time.time()
        # DB connections
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # Validate access token
        data=readme_api_data(common_utils_database,data)
        if data.get("z_access_token"):
            allowed_keys = ["description", "product_type", "ps_code", "product_type_code", 
                            "business_type", "service_provider", "apply_to", "rate", 
                            "automatic_expiration", "free_period", "g_l_code", "buy_rate", 
                            "cost", "multi_service_id", "prorate", "is_surcharge"]

            changed_data = {}
            for k in allowed_keys:
                value = data.get(k)
                if value not in (None, "", [], {}):
                    # special handling for multi_service_id
                    if k == "multi_service_id" and isinstance(value, str):
                        changed_data[k] = [v.strip() for v in value.split(",") if v.strip()]
                    else:
                        changed_data[k] = value

            data["changed_data"] = changed_data

        tenant_db_name = data.get('db_name', '')
        if tenant_db_name == "null":
            tenant_db_name = "altaworx_test"
        tenant_database = DB(tenant_db_name, **db_config)

        # Metadata
        tenant_name = data.get('tenant_name', '')
        role_name = data.get('role_name', '')
        username = data.get('username', '')
        session_id = data.get('session_id', '')
        request_time = data.get('request_received_at', '')
        partner = data.get('Partner', '')
        tenant_id = data.get('tenant_id', 1)

        mode = os.getenv('ENV', 'UAT')
        if mode == 'UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1

        changed_data = data.get('changed_data', {}).copy()
        logging.info(f'### add_product input changed_data: {changed_data}')

        description = changed_data.get('description', '')
        description = description.strip()
        if description:
            # Fetch category ID from database
            description_df = killbill_database.get_data("products", {"description": description}, ["id","description"]).to_dict(orient="records")
            if description_df:
                # Category already exists — return error response
                error_data = {
                "service_name": "add_product",
                "error_message": "Duplicate Product",
                "error_type": "Duplicate Product",
                "users": data.get('username', ''),
                "session_id": data.get('session_id', ''),
                "tenant_name": data.get('Partner', ''),
                "comments": f"Duplicate Product---{description}",
                "module_name": "Billing Products",
                "request_received_at": data.get('request_received_at', ''),
                }
                
                # Log error to database
                database.log_error_to_db(error_data, "error_log_table")
                return {
                    "flag": True,
                    "message": "Product Name already exists",
                    "status": False,
                    "validation": True
                }
        else:
            logging.info("No description provided, proceeding without description check.")


        # Extract product-specific fields
        service_provider = changed_data.get('service_provider', '')
        service_type = changed_data.get('service_type', [])
        product_type = changed_data.get('product_type', '')
        provider_accounts = changed_data.get('provider_accounts', [])
        options = changed_data.get('options', [])
        multi_service_id = changed_data.get('multi_service_id', [])
        g_l_code = changed_data.get('g_l_code', '')

        # Defaults for override fields
        for key in ["override_tax_type", "override_ps_code", "override_tax_class"]:
            changed_data.setdefault(key, 'false')

        # Remove unwanted keys
        for key in ['id', 'g_l_code', 'builtInFields', 'customFields']:
            changed_data.pop(key, None)

        # Map service_provider to provider_id
        if service_provider:
            changed_data['service_provider_name'] = service_provider
            df = tenant_database.get_data("serviceprovider", {"display_name": service_provider}, ["id"])
            if not df.empty:
                changed_data['provider_id'] = str(df['id'].iloc[0])
            else:
                df_bp = killbill_database.get_data("serviceprovider", {"display_name": service_provider}, ["id"])
                if not df_bp.empty:
                    changed_data['provider_id'] = df_bp["id"].to_list()[0]

        # Map options to provider_account_option
        if options:
            df = killbill_database.get_data("provider_account_options", {"option_value": tuple(options)}, ["id"])
            if not df.empty:
                changed_data['provider_acount_option_id'] = df['id'].tolist()[0]
                changed_data['multi_options'] = str(options)

        # Map g_l_code
        if g_l_code:
            df = killbill_database.get_data("gl_code", {"gl_codes": g_l_code}, ["id"])
            if not df.empty:
                changed_data['gl_code_id'] = str(df['id'].iloc[0])

        # Handle provider_accounts
        if provider_accounts:
            changed_data['provider_accounts'] = provider_accounts[0]
            changed_data['multi_provider_accounts'] = str(provider_accounts)

        # Add audit fields
        changed_data.update({
            'tenant_id': tenant_id,
            'created_by': username,
            'modified_by': username,
            'tenant_name': tenant_name,
        })

        # Drop UI-related fields
        removable_columns = ['service_type', 'service_provider', 'options', 'g_l_code', 'automatic_expression']
        changed_data = {
            k: json.dumps(v) if k == 'multi_service_id' and not isinstance(v, str) else str(v)
            for k, v in changed_data.items()
            if v not in (None, "None", "") and k not in removable_columns
        }
        status = killbill_database.insert_data(changed_data, 'products')

        if status:
            response = {"flag": True, "message": "Successfully added Product"}

            # Audit success
            end_time = time.time()
            time_consumed = int(float(f"{end_time - start_time:.4f}"))
            provider_id = changed_data.get('provider_id', '')

            audit_data_user_actions = {
                "service_name": "add_product",
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id":  data.get("username"),
                "tenant_name": tenant_name,
                "comments": f"Successfully added Product---{changed_data.get('description')}",
                "module_name": "Billing Services",
                "request_received_at": request_time,
                "service_provider_id": provider_id,
                "request_data":json.dumps(changed_data),
                "response_data": json.dumps(response)
            }
            database.update_audit(audit_data_user_actions, "audit_user_actions")

        else:
            response = {"flag": False, "message": "Error adding Product"}
            logging.info("###got error just above")
            # Audit failure (business logic)
            error_data = {
                "service_name": "add_product",
                "error_message": "Insert returned False",
                "error_type": "InsertError",
                "users": data.get("username"),
                "session_id": data.get("session_id"),
                "tenant_name": data.get("tenant_name"),
                "comments": f"DB insert failed while adding product.Tried Inserting {changed_data}",
                "module_name": "Billing Products",
                "request_received_at": data.get("request_received_at"),
            }
            database.log_error_to_db(error_data, "error_log_table")

        return response

    except Exception as e:
        logging.exception(f"Exception in add_product: {e}")
        response = {"flag": False, "message": "Failed to add the data"}

        # Audit exception
        error_data = {
            "service_name": "add_product",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Exception occurred while adding product",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")

        return response

#ceratax integration
def to_camel_case(text):
    if not text:
        return ""
    words = text.split()
    return ''.join(word.capitalize() for word in words)

def tax_class_list():
    # API endpoint
    #url = "https://data.cert.ceretax.net/taxTypeClasses"
    url = os.environ["TAX_CLASS_API_URL"]
    api_key = os.environ["X_API_KEY"]

    # Headers (Add authentication if required)
    headers = {
        "accept": "application/json",
        "x-api-key": f"{api_key}"
    }
    # Make the request
    response = requests.get(url, headers=headers)
    # Process response
    if response.status_code == 200:
        tax_classes = response.json()
        print(tax_classes)  # List of tax type classes
        tax_class=[]
        for i in tax_classes:
            class_code=i['taxTypeClass']
            class_description=(i['taxTypeClassDescription']).title()
            class_res=class_code+' '+class_description
            tax_class.append(class_res)
        print('###tax_class',tax_class)
        return tax_class
    else:
        print("Failed to fetch tax classes:", response.status_code, response.text)

def tax_types_list():
    #fetch url and api_key from .env
    url = os.environ["TAX_TYPE_API_URL"]
    api_key = os.environ["X_API_KEY"]

    # Headers (Add authentication if required)
    headers = {
        "accept": "application/json",
        "x-api-key": api_key
    }

    # Make the request
    response = requests.get(url, headers=headers)

    #fetch the response
    if response.status_code == 200:
        tax_list = response.json()
        formatted_list = [f"{item['taxType']} {item['taxTypeDescription']}" for item in tax_list]
        return formatted_list
    else:
        logging.info(f'Failed to fetch data')

def ps_codes_list():
    """
    Fetches a list of PS codes and their descriptions from an external API.

    This function makes a GET request to an external API to retrieve a list of PS codes and their corresponding descriptions.
    It formats the response into a list of strings combining the PS code and its description.

    Returns:
        list: A list of formatted strings combining PS codes and their descriptions.
    """
    #fetch url and api_key from .env
    url = os.environ["PS_CODES_API_URL"]
    api_key = os.environ["X_API_KEY"]

    # Headers (Add authentication if required)
    headers = {
        "accept": "application/json",
        "x-api-key": api_key
    }

    # Make the request
    response = requests.get(url, headers=headers)

    #fetch the response
    if response.status_code == 200:
        ps_codes = response.json()
        formatted_list = [f"{item.get('psCode', 'Unknown')} - {item.get('psCodeDescription', 'Unknown')}" for item in ps_codes]
        return {
            "ps_codes_description_list": formatted_list
        }
    else:
        logging.info(f'###ps_codes_list Failed to fetch data FROM API, status code: {response.status_code}, response: {response.text}')
        return {
            "ps_codes_description_list": []
     }

def product_type_list_view(data):
    """
    Retrieves a paginated list of product types from the database, including related data such as product type codes, descriptions, and tax classes. The function also maps product type codes to their respective product type IDs, converts timestamps to the tenant's timezone, and handles pagination for the results.
    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name for permissions and data access.
            - tenant_name (str): Tenant name to determine timezone and other specific settings.
            - mod_pages (dict): Pagination details, including:
                - start (int): Starting index for pagination. Defaults to 0.
                - end (int): Ending index for pagination. Defaults to 100.
    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message.
            - data (dict): A dictionary with the key 'billing_product_types' containing the paginated list of product types.
            - header_map (dict): A dictionary of headers mapped based on the user's role.
            - dropdown (dict): A dictionary containing lists of distinct product type codes, descriptions, and tax classes for dropdown options.
            - pages (dict): Pagination information, including start, end, and total count of records.
    """
    # Database setup
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    # tenant database Connection
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    tenant_db_name = data.get('db_name', '')
    if tenant_db_name=="null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    role_name = data.get('role_name', '')
    tenant_name = data.get('tenant_name', '')
    col_sort = data.get("col_sort", {})
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    flag = data.get('status', '')
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    # Get tenant ID and time zone
    tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["time_zone"])
    if tenant_data.empty:
        raise ValueError("No valid tenant found.")

    tenant_time_zone = tenant_data["time_zone"].to_list()[0]
    if not tenant_time_zone:
        raise ValueError("No valid timezone found for tenant.")

    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    
    # Filtering and pagination
    condition = {"tenant_id": tenant_id}
    if flag == 'true':
        condition["is_active"] = flag

    order = {k: v.lower() for k, v in col_sort.items()} if col_sort else {"description": "asc"}

    total_count = killbill_database.get_data("product_types", condition, ["id"])["id"].to_list()
    total_count = len(total_count)
    pages_data = {"start": start, "end": end, "total": total_count}

    df_dict = killbill_database.get_data(
        table_name="product_types",
        condition=condition,
        columns=None,
        order=order,
        mod_pages={"start": start, "end": end}
    ).to_dict(orient="records")
    
    # Dropdown values
    pt_code_df = killbill_database.get_data("product_type_code", None, ["id", "product_type_codes"])
    desc_tax_df = killbill_database.get_data("product_types", None, ["description", "tax_class"])

    dropdown = {
        "product_type_codes": sorted(set(pt_code_df["product_type_codes"].tolist())),
        "description": sorted(set(desc_tax_df["description"].tolist())),
        "tax_class": sorted(tax_class_list()),
        "tax_type": sorted(tax_types_list()),
        "ps_code": sorted(ps_codes_list())
    }

    # Convert timestamps
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    try:
        
        header_map = get_headers_mapping(killbill_database,["Billing Product Types"],role_name, '', '', '', '',data)
        final_data_dict=serialize_data(df_dict)
        data_dict_all = {"billing_product_types": final_data_dict}
  
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown":dropdown,
            "pages": pages_data
        }
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response

def add_product_type(data):
    """
    Adds a new product type to the database by inserting provided details into the 'product_types' table. The function processes the product type code, handles any necessary data cleaning, and ensures that only relevant fields are included in the insertion query. It also checks for an existing product type code and updates the relevant data before performing the insert operation.
    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name for permissions and data access.
            - tenant_name (str): Tenant name to determine context for the operation.
            - changed_data (dict): A dictionary containing the product type details to be added, such as:
                - product_type_codes (str): Product type code associated with the new product type.
                - Other product-related fields (e.g., name, description, etc.).
    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message.
    """
    # Initialize DB connections
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    # tenant database Connection
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    tenant_db_name = data.get('db_name', '')
    if tenant_db_name=="null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    # Metadata extraction
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    modified_date = data.get("request_received_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    role_name = data.get("role_name", "")
    tenant_name = data.get("tenant_name", "")
    partner_name = data.get("Partner", "")
    changed_data = data.get("changed_data", {})
    start_time = time.time()
    tenant_id = data.get('tenant_id', '')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    # Enrich changed_data
    changed_data['created_by'] = username
    changed_data['modified_by'] = username
    changed_data['tenant_id'] = str(tenant_id) if tenant_id else None
    changed_data['tenant_name'] = tenant_name

    # Map product_type_code_id
    product_type_codes = changed_data.get('product_type_codes', '')
    if product_type_codes:
        code_result = killbill_database.get_data("product_type_code", {"product_type_codes": product_type_codes}, ["id"])
        if not code_result.empty:
            changed_data['product_type_code_id'] = str(code_result["id"].to_list()[0])

    is_active = changed_data.get('is_active', True)
    changed_data['status'] = 'Active' if is_active else 'Inactive'
    changed_data['is_active'] = bool(is_active)

    # Clean final payload
    changed_data = {
        k: str(v) for k, v in changed_data.items()
        if v not in (None, "None", "")
    }

    try:
        # Execute the query with parameters
        status=killbill_database.insert_dict(changed_data, 'product_types')
        if status:
            response = {
                    "flag": True,
                    "message": "Successfully added Product Type"
                }
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "Billing Platform",
                "created_date": modified_date,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(changed_data),
                "module_name": "Billing Services",
                "request_received_at": modified_date,
            }
            database.update_audit(audit_data_user_actions, "audit_user_actions")
        else:
            response = {
                    "flag": False,
                    "message": "Error adding Product Type"
                }

        return response
    except Exception as e:
        response = {
                "flag": False,
                "message": "Failed to add the data"
            }
        return response
        
def create_json(row):
    return json.dumps({
        "generalData": {
            "desc_on_bill": row["desc_on_bill"],
            "service_type": row["service_type"],
            "display_name": row["display_name"],
            "category": row["category"],
            "one_time": str(row["one_time"])  # Ensuring one_time is a string
        },
        "productsData": {
            "description": row["product_descriptions"],  # Dynamic list
            "product_type": row["product_types"],  # Dynamic list
            "UpdatedTableData": row["updated_table_data"]
        }
    })

def clean_package_record(record):
    cleaned = {}

    # Define field groups by types based on packages schema
    int_fields = {
        'id', 'provider_id', 'product_type_id', 'service_id', 'tenant_id'
    }
    bool_fields = {
        'is_active', 'is_deleted'
    }
    timestamp_fields = {
        'created_date', 'modified_date'  # add more timestamp fields if any
    }

    for k, v in record.items():
        if k in int_fields:
            try:
                if v in (None, '', 'None', 'nan') or (isinstance(v, float) and (v != v)):  # NaN check
                    cleaned[k] = None
                else:
                    cleaned[k] = int(float(v))
            except Exception:
                cleaned[k] = None

        elif k in bool_fields:
            if v in (None, '', 'None', 'nan'):
                cleaned[k] = None
            elif isinstance(v, str):
                cleaned[k] = v.lower() in ('true', '1', 'yes')
            else:
                cleaned[k] = bool(v)

        elif k in timestamp_fields:
            if v in (None, '', 'None', 'nan'):
                cleaned[k] = None
            elif isinstance(v, datetime):
                cleaned[k] = v.isoformat()
            else:
                try:
                    dt = datetime.fromisoformat(str(v))
                    cleaned[k] = dt.isoformat()
                except Exception:
                    cleaned[k] = None

        else:
            # For VARCHAR and TEXT fields, convert None-like values to empty string
            cleaned[k] = str(v) if v not in (None, '', 'None', 'nan') else ''

    return cleaned

def clean_service_record(record):
    cleaned = {}

    # Define type sets according to your products schema
    int_fields = {
        'id', 'free_period', 'product_type_id', 'provider_id', 'gl_code_id', 'service_id',
        'quantity', 'provider_acount_option_id', 'tenant_id'
    }
    float_fields = {
        'rate', 'buy_rate', 'cost'  # NUMERIC columns treated as float strings
    }
    bool_fields = {
        'automatic_expiration', 'is_active', 'is_deleted',
        'override_tax_type', 'override_ps_code', 'override_tax_class',
        'prorate', 'is_surcharge'
    }
    timestamp_fields = {
        'created_date', 'modified_date'  # Add more timestamp fields if applicable
    }

    for k, v in record.items():
        if k in int_fields:
            try:
                if v in (None, '', 'None', 'nan') or (isinstance(v, float) and (v != v)):  # check NaN
                    cleaned[k] = None
                else:
                    cleaned[k] = int(float(v))  # Handles '0', '0.0' etc correctly
            except Exception:
                cleaned[k] = None

        elif k in float_fields:
            try:
                if v in (None, '', 'None', 'nan') or (isinstance(v, float) and (v != v)):
                    cleaned[k] = None
                else:
                    cleaned[k] = str(float(v))  # Store as string but valid float
            except Exception:
                cleaned[k] = None

        elif k in bool_fields:
            if v in (None, '', 'None', 'nan'):
                cleaned[k] = None
            elif isinstance(v, str):
                cleaned[k] = v.lower() in ('true', '1', 'yes')
            else:
                cleaned[k] = bool(v)

        elif k in timestamp_fields:
            if v in (None, '', 'None', 'nan'):
                cleaned[k] = None
            elif isinstance(v, datetime):
                cleaned[k] = v.isoformat()
            else:
                try:
                    dt = datetime.fromisoformat(str(v))
                    cleaned[k] = dt.isoformat()
                except Exception:
                    cleaned[k] = None

        else:
            # For VARCHAR and other string fields, convert None/'None' to empty string
            cleaned[k] = str(v) if v not in (None, '', 'None', 'nan') else ''

    return cleaned

def clean_record(record):
    """Cleans record values for product data rows."""
    for k, v in record.items():
        if isinstance(v, float):
            record[k] = int(v)
        elif isinstance(v, pd.Timestamp):
            record[k] = v.strftime("%m-%d-%y %H:%M:%S")
        elif isinstance(v, str) and v.startswith("[") and v.endswith("]"):
            try:
                parsed = ast.literal_eval(v)
                if isinstance(parsed, list):
                    record[k] = parsed
            except Exception:
                pass
    return record

def is_null(v):
    """Universal null/empty checker."""
    if v is None:
        return True
    if isinstance(v, float) and pd.isna(v):
        return True
    if isinstance(v, str) and v.strip().lower() in ('none', 'nan', 'null', ''):
        return True
    return False


def process_products_upload(uploaded_dataframe, created_date, username, tenant_id, tenant_name, database, killbill_database, table_name, tenant_database):
    """
    Handles Billing Products specific pipeline:
    - Validates mandatory columns
    - provider name to ID lookup
    - handles service_id -> multi_service_id transformation
    - adds default columns/values
    - normalize with clean_service_record
    - insert into DB
    """
    try:
        biling_common_utils_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        duplicate_products_count=0

        # ---- Mandatory Column Validation ---- #
        mandatory_columns = [
            "description",
            "product_type_code",
            "business_type",
            "service_provider_name",
            "rate"
        ]

        uploaded_dataframe.columns = uploaded_dataframe.columns.str.strip().str.lower()
        logging.info(f'uploaded_dataframe----------{uploaded_dataframe}')
        uploaded_dataframe = uploaded_dataframe.rename(
            columns={
                "provider": "service_provider_name",
                "tax_code": "ps_code"
            }
        )
        logging.info(f"uploaded_dataframe columns after rename: {uploaded_dataframe.columns.tolist()}")
        # Validate columns exist
        missing_columns = [col for col in mandatory_columns if col not in uploaded_dataframe.columns]
        if missing_columns:
            message = f"Missing mandatory columns: {', '.join(missing_columns)}"
            # return {
            #     "flag": False,
            #     "message": f"Missing mandatory columns: {', '.join(missing_columns)}"
            # }
            return True, 0, message, True

        # Validate mandatory values are not empty
        for col in mandatory_columns:
            if uploaded_dataframe[col].isnull().any() or uploaded_dataframe[col].astype(str).str.strip().eq("").any():
                message = f"Column '{col}' contains missing or empty values. Please fill all mandatory fields."
                # return {
                #     "flag": False,
                #     "message": f"Column '{col}' contains missing or empty values. Please fill all mandatory fields."
                # }
                return True, 0, message,True

        skip_columns = [
            "description",
            "product_type_code",
            "business_type",
            "service_provider_name",
            "rate"
        ]

        uploaded_dataframe[skip_columns] = (
            uploaded_dataframe[skip_columns]
                .apply(lambda col: col.astype(str).str.strip())
                .replace({"": None, "nan": None})
        )

        duplicate_products_count += uploaded_dataframe[skip_columns].isnull().any(axis=1).sum()

        uploaded_dataframe = uploaded_dataframe[
            ~uploaded_dataframe[skip_columns].isnull().any(axis=1)
        ]

        # ---- Duplicate filtering (row-by-row: DB first, then Excel) ---- #
        # Normalize description for consistent comparison
        uploaded_dataframe["description"] = uploaded_dataframe["description"].astype(str).str.strip()
        logging.info(f'uploaded_dataframe----------{uploaded_dataframe}')

        # Fetch DB ps bundle codes
        ps_bundle_df = killbill_database.get_data(
            "ps_bundle_codes",
            {},
            ["rule_name", "ps_code", "label"]
        )

        # Clean DB ps_codes properly
        db_ps_bundle_df = ps_bundle_df.dropna(subset=["ps_code"])

        # Build DB composite format: "ps_code - label"
        db_ps_composite_set = set(
            db_ps_bundle_df.apply(
                lambda row: f"{str(row['ps_code']).strip()} - {str(row['label']).strip()}",
                axis=1
            )
        )

        # Build valid bundle codes
        valid_bundle_codes = set(
            ps_bundle_df["rule_name"]
                .dropna()
                .astype(str)
                .str.strip()
        )

        # Fetch API ps codes
        api_response = ps_codes_list()
        api_ps_description_list = api_response.get("ps_codes_description_list", [])

        # Find DB ps_code set for comparison
        db_ps_code_set = set(
            db_ps_bundle_df["ps_code"]
                .astype(str)
                .str.strip()
        )

        # Add API-only ps codes
        api_only_ps_set = set()

        for item in api_ps_description_list:
            ps_code, description = item.split(" - ", 1)
            ps_code = ps_code.strip()
            description = description.strip()

            if ps_code not in db_ps_code_set:
                api_only_ps_set.add(f"{ps_code} - {description}")

        # Final valid PS codes (DB + API-only)
        valid_ps_bundle_codes = db_ps_composite_set.union(api_only_ps_set)


        for idx, row in uploaded_dataframe.iterrows():
            ps_code = row.get("ps_code")
            bundle_code = row.get("bundle_code")

            ps_code_present = pd.notna(ps_code) and str(ps_code).strip()
            bundle_code_present = pd.notna(bundle_code) and str(bundle_code).strip()

            # neither present
            if not ps_code_present and not bundle_code_present:
                return True, 0, (
                    f"Either Tax Code or Bundle Code must be provided."
                ), True

            # both present
            if ps_code_present and bundle_code_present:
                return True, 0, (
                    f"Only one of Bundle Code or Tax Code can be entered"
                ),True

            # validate bundle_code
            if bundle_code_present:
                bundle_code = str(bundle_code).strip()
                if bundle_code not in valid_bundle_codes:
                    return True, 0, f"Invalid PS bundle code: {bundle_code}",True

            # validate ps_code
            else:
                ps_code_label = str(ps_code).strip()  # Excel already sends ps_code + " - " + label
                # Validate against DB composite strings
                if ps_code_label not in valid_ps_bundle_codes:
                    return True, 0, f"Invalid PS code: {ps_code_label}",True


        # ---- Product Type Code Validation ---- #
        valid_product_types = {"onetime", "recurring"}

        invalid_product_types = (
            uploaded_dataframe[
                ~uploaded_dataframe["product_type_code"]
                .astype(str)
                .str.strip()
                .str.lower()
                .isin(valid_product_types)
            ]["product_type_code"]
            .unique()
        )

        if len(invalid_product_types) > 0:
            message = (
                "Invalid Product Type Code found. "
                "Allowed values are only 'Onetime' or 'Recurring'. "
                f"Invalid values: {', '.join(map(str, invalid_product_types))}"
            )
            return True, 0, message,True


        # Fetch existing product names for this tenant
        existing_products= killbill_database.get_data("products", {"tenant_id": tenant_id}, ["description"])["description"].to_list()
        logging.info(f"## process_products_upload existing_products: {existing_products}")
        provided_product_names = []
        for _, row in uploaded_dataframe.iterrows():
            product_name = str(row.get("description", "")).strip()
            product_name_lower = product_name
            logging.info(f'product_name_lower------{product_name_lower}')
            if product_name_lower in existing_products:
                logging.info(f"Skipping {product_name_lower}, already exists in DB")
                duplicate_products_count+=1
                continue
            if product_name_lower in provided_product_names:
                logging.info(f"Skipping {product_name_lower}, duplicate in Excel sheet")
                duplicate_products_count+=1
                continue
            provided_product_names.append(product_name_lower)
        logging.info(f"Products to insert ({len(provided_product_names)}): {provided_product_names}")
        uploaded_dataframe = uploaded_dataframe[
            uploaded_dataframe["description"].astype(str).str.strip().isin(provided_product_names)
        ]
        #--------------------------------------------------------------  

        # ---- Provider Lookup ---- #
        if "service_provider_name" in uploaded_dataframe.columns:
            unique_provider_names = uploaded_dataframe["service_provider_name"].dropna().unique().tolist()
            tenant_providers_df = tenant_database.get_data("serviceprovider", {"display_name": unique_provider_names}, ["id","display_name"])
            tenant_provider_names = tenant_providers_df["display_name"].tolist() if not tenant_providers_df.empty else []
            missing_provider_names = list(set(unique_provider_names) - set(tenant_provider_names))
            main_providers_df = pd.DataFrame()
            if missing_provider_names:
                main_providers_df = killbill_database.get_data("serviceprovider", {"display_name": missing_provider_names}, ["id","display_name"])
            combined_providers_df = pd.concat([tenant_providers_df, main_providers_df], ignore_index=True)
            provider_name_to_id = dict(zip(combined_providers_df["display_name"], combined_providers_df["id"]))
            uploaded_dataframe["provider_id"] = uploaded_dataframe["service_provider_name"].map(provider_name_to_id)

        # ---- Handle service_id -> multi_service_id ---- #
        if "service_id" in uploaded_dataframe.columns:
            uploaded_dataframe["service_id"] = uploaded_dataframe["service_id"].apply(lambda x: str(x).strip())

            # extract only numeric groups per row
            def build_multi_service_id(service_id_str):
                logging.info(f"## process_products_upload service_id_str: {service_id_str}")
                # get all number groups even if no comma
                ids = re.findall(r'\d+', str(service_id_str))
                return json.dumps([f"{i} {id_to_desc.get(int(i), '')}".strip()
                                for i in ids if int(i) in id_to_desc])

            # collect all ids from all rows
            all_ids = uploaded_dataframe["service_id"].apply(lambda x: re.findall(r'\d+', str(x)))
            flat_ids = [int(i) for sub in all_ids for i in sub if i.isdigit()]
            logging.info(f"## process_products_upload flat_ids: {flat_ids}")

            if flat_ids:
                services_df = killbill_database.get_data("services", {"id": flat_ids}, ["id", "description"])
                id_to_desc = dict(zip(services_df["id"], services_df["description"])) if not services_df.empty else {}

            uploaded_dataframe["multi_service_id"] = uploaded_dataframe["service_id"].apply(build_multi_service_id)
            uploaded_dataframe.drop(columns=["service_id"], inplace=True)


        # ---- Add default fields ---- #
        uploaded_dataframe["created_by"] = username
        uploaded_dataframe["created_date"] = created_date
        uploaded_dataframe["modified_by"] = username
        uploaded_dataframe["modified_date"] = created_date
        uploaded_dataframe["is_active"] = True
        uploaded_dataframe["code_2_fid"] = ""
        uploaded_dataframe["is_deleted"] = False
        uploaded_dataframe["credit"] = ""
        uploaded_dataframe["itemize"] = ""
        uploaded_dataframe["tax_incl"] = ""
        uploaded_dataframe["group"] = ""
        uploaded_dataframe["quantity"] = None
        uploaded_dataframe["state"] = ""
        uploaded_dataframe["type"] = ""
        uploaded_dataframe["multi_provider_accounts"] = ""
        uploaded_dataframe["override_tax_type"] = False
        uploaded_dataframe["override_tax_class"] = False
        uploaded_dataframe["override_ps_code"] = False
        uploaded_dataframe["rate_type"] = ""
        uploaded_dataframe["tenant_id"] = tenant_id
        uploaded_dataframe["tenant_name"] = tenant_name
        uploaded_dataframe["free_period"] = ""
        uploaded_dataframe["apply_to"] = ""
        uploaded_dataframe["multi_options"] = ""
        uploaded_dataframe["provider_accounts"] = ""
        uploaded_dataframe["provider_acount_option_id"] = None
        if "product_type_code" in uploaded_dataframe.columns:
            uploaded_dataframe["prorate"] = uploaded_dataframe["product_type_code"].apply(
                lambda x: False if isinstance(x, str) and "onetime" in x.lower() else True
            )

        uploaded_dataframe = uploaded_dataframe.replace({np.nan: None})

        # Clean and insert
        uploaded_dict = uploaded_dataframe.to_dict(orient="records")
        cleaned_uploaded_dict = [clean_service_record(record) for record in uploaded_dict]
        logging.info(f"## process_products_upload cleaned_uploaded_dict: {cleaned_uploaded_dict}")
        if cleaned_uploaded_dict:
            status = killbill_database.insert_data(cleaned_uploaded_dict, table_name)
            #message = f"Successfully uploaded the records Duplicates count: {duplicate_products_count}"
            message = f"Successfully uploaded the records\nDuplicates count: {duplicate_products_count}"
            logging.info(f"## process_products_upload duplicate_products_count: {duplicate_products_count}")
            return True, duplicate_products_count, message, False
        else:
            #message = f"Successfully uploaded the records Duplicates count: {duplicate_products_count}"
            message = f"Successfully uploaded the records\nDuplicates count: {duplicate_products_count}"
            return True,duplicate_products_count, message, False

    except Exception as e:
        logging.info(f"## process_products_upload error: {e}")
        biling_common_utils_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        message = f"process_products_upload error: {e}"
        error_data = {
            "service_name": "process_products_upload",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": username,
            "session_id": None,
            "tenant_name": tenant_name,
            "comments": "Unhandled exception during products upload",
            "module_name": "Billing Products",
            "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        biling_common_utils_database.log_error_to_db(error_data, "error_log_table")
        return False,0,message, False



def process_packages_upload(
    uploaded_dataframe,
    created_date,
    username,
    tenant_id,
    tenant_name,
    killbill_database,
    table_name,
    tenant_database,
):
    try:
        logging.info(f"## process_packages_upload function called")
        biling_common_utils_database = DB(
            os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config
        )

        # Initialize duplicate counter
        duplicate_packages_count = 0

        # 1. Map 'description_on_bill' to 'desc_on_bill' if 'description_on_bill' exists
        if "description_on_bill" in uploaded_dataframe.columns:
            uploaded_dataframe["desc_on_bill"] = uploaded_dataframe[
                "description_on_bill"
            ]
            uploaded_dataframe.drop(columns=["description_on_bill"], inplace=True)
        # Ensure 'desc_on_bill' column exists even if no mapping done (optional safe default)
        elif "desc_on_bill" not in uploaded_dataframe.columns:
            uploaded_dataframe["desc_on_bill"] = ""

        # UPDATED: Check for duplicates using 'category' column instead of 'desc_on_bill'
        # Normalize category for consistent comparison
        uploaded_dataframe["category"] = uploaded_dataframe["category"].astype(str).str.strip()

        # Fetch existing package categories for this tenant (changed from desc_on_bill to category)
        existing_packages = killbill_database.get_data(
            "packages", {"tenant_id": tenant_id}, ["category"]
        )["category"].to_list()
        logging.info(
            f"## process_packages_upload existing_packages: {existing_packages}"
        )
        
        provided_package_names = []
        for _, row in uploaded_dataframe.iterrows():
            package_name = str(row.get("category", "")).strip()  # Changed from desc_on_bill to package_name
            if package_name in existing_packages:
                logging.info(f"Skipping {package_name}, already exists in DB")
                duplicate_packages_count += 1
                continue
            if package_name in provided_package_names:
                logging.info(f"Skipping {package_name}, duplicate in Excel sheet")
                duplicate_packages_count += 1
                continue
            provided_package_names.append(package_name)
        logging.info(
            f"Packages to insert ({len(provided_package_names)}): {provided_package_names}"
        )
        
        # Filter dataframe to only include non-duplicate packages (using category)
        uploaded_dataframe = uploaded_dataframe[
            uploaded_dataframe["category"]
            .astype(str)
            .str.strip()
            .isin(provided_package_names)
        ]

        # Check if dataframe is empty after filtering duplicates
        if uploaded_dataframe.empty:
            logging.info(f"## process_packages_upload: All packages are duplicates, skipping processing")
            logging.info(f"## process_packages_upload duplicate_packages_count: {duplicate_packages_count}")
            return True, duplicate_packages_count

        # --- Provider Lookup (same as in products) ---
        if "service_provider_name" in uploaded_dataframe.columns:
            unique_provider_names = (
                uploaded_dataframe["service_provider_name"].dropna().unique().tolist()
            )
            logging.info(
                f"## process_packages_upload unique_provider_names: {unique_provider_names}"
            )
            
            # Only proceed with provider lookup if we have provider names
            if unique_provider_names:
                tenant_providers_df = tenant_database.get_data(
                    "serviceprovider",
                    {"display_name": unique_provider_names},
                    ["id", "display_name"],
                )
                tenant_provider_names = (
                    tenant_providers_df["display_name"].tolist()
                    if not tenant_providers_df.empty
                    else []
                )
                missing_provider_names = list(
                    set(unique_provider_names) - set(tenant_provider_names)
                )
                main_providers_df = pd.DataFrame()
                if missing_provider_names:
                    main_providers_df = killbill_database.get_data(
                        "serviceprovider",
                        {"display_name": missing_provider_names},
                        ["id", "display_name"],
                    )
                combined_providers_df = pd.concat(
                    [tenant_providers_df, main_providers_df], ignore_index=True
                )
                provider_name_to_id = dict(
                    zip(combined_providers_df["display_name"], combined_providers_df["id"])
                )
                uploaded_dataframe["provider_id"] = uploaded_dataframe[
                    "service_provider_name"
                ].map(provider_name_to_id)
            else:
                # Set default provider_id if no provider names
                uploaded_dataframe["provider_id"] = None
            
            logging.info(
                f"## process_packages_upload uploaded_dataframe['provider_id']: {uploaded_dataframe['provider_id']}"
            )

        # --- Column mapping ---
        col_map = {
            "desc_on_bill": "desc_on_bill",
            "product_type": "product_type",  # keep for internal use only
            "service_id": "service_id",
            "category": "category",
            "service_provider_name": "service_provider_name",
            "product_id": "product_id",
        }
        uploaded_dataframe.rename(columns=col_map, inplace=True)

        # Parse product_id list
        uploaded_dataframe["product_id_list"] = (
            uploaded_dataframe["product_id"]
            .fillna("")
            .apply(
                lambda x: [
                    int(pid.strip())
                    for pid in str(x).split(",")
                    if pid.strip().isdigit()
                ]
            )
        )

        # --- Lookup dicts from DB ---
        service_ids = (
            uploaded_dataframe["service_id"].dropna().astype(int).unique().tolist()
        )
        unique_product_ids = sorted(
            {pid for lst in uploaded_dataframe["product_id_list"] for pid in lst}
        )
        logging.info(
            f"## process_packages_upload unique_product_ids: {unique_product_ids}"
        )

        # Initialize empty DataFrames to handle empty cases
        services_df = pd.DataFrame(columns=["id", "description"])
        products_df = pd.DataFrame()
        
        # Only query if we have IDs to look up
        if service_ids:
            services_df = killbill_database.get_data(
                "services", {"id": service_ids}, ["id", "description"]
            )
        
        if unique_product_ids:
            products_df = killbill_database.get_data(
                "products", {"id": unique_product_ids}, columns=None
            )
        
        logging.info(f"## process_packages_upload services_df: {services_df}")
        logging.info(f"## process_packages_upload products_df: {products_df}")

        # Clean product rows - handle empty DataFrame
        products_dicts = []
        if not products_df.empty:
            products_dicts = [
                clean_record(r) for r in products_df.to_dict(orient="records")
            ]
        
        service_id_to_desc = {}
        if not services_df.empty:
            service_id_to_desc = dict(zip(services_df["id"], services_df["description"]))
        
        product_id_to_record = {r["id"]: r for r in products_dicts}
        logging.info(
            f"## process_packages_upload product_id_to_record: {product_id_to_record}"
        )

        # --- Build package_products and calculate grouped/ungrouped totals per row ---
        def build_package_products(row):
            desc_on_bill = row.get("desc_on_bill", "")
            category = row.get("category", "")
            display_name = row.get("service_provider_name", "")
            service_type_name = (
                service_id_to_desc.get(int(row["service_id"]), "")
                if not is_null(row["service_id"]) and service_id_to_desc
                else ""
            )

            # Parse product_type comma-separated string to list for productsData only
            product_type_desc = []
            if "product_type" in row and pd.notnull(row["product_type"]):
                product_type_desc = [
                    pt.strip()
                    for pt in str(row["product_type"]).split(",")
                    if pt.strip()
                ]

            product_ids = row["product_id_list"]
            updated_table_data = [
                product_id_to_record[pid]
                for pid in product_ids
                if pid in product_id_to_record
            ]

            # Calculate grouped and ungrouped totals
            grouped_total = 0
            ungrouped_total = 0
            for product in updated_table_data:
                rate = float(product.get("rate", 0) or 0)
                if product.get("group"):
                    grouped_total += rate
                if product.get("itemize"):
                    ungrouped_total += rate

            # Store totals in the row itself (added if needed elsewhere)
            row["grouped_total"] = grouped_total
            row["ungrouped_total"] = ungrouped_total

            return {
                "generalData": {
                    "category": category,
                    "desc_on_bill": desc_on_bill,
                    "display_name": display_name,
                    "service_type": service_type_name,
                },
                "productsData": {
                    "product_type": product_type_desc,  # list of descriptions only here
                    "description": [
                        f"{category} -- {prod.get('id')}" for prod in updated_table_data
                    ],
                    "UpdatedTableData": updated_table_data,
                },
            }

        # Apply to create package_products JSON and calculate totals - only if DataFrame is not empty
        if not uploaded_dataframe.empty:
            uploaded_dataframe["package_products"] = uploaded_dataframe.apply(
                build_package_products, axis=1
            )
            logging.info(
                f"## process_packages_upload uploaded_dataframe['package_products']: {uploaded_dataframe['package_products']}"
            )

            # Inject grouped and ungrouped totals into dataframe columns
            uploaded_dataframe["grouped"] = uploaded_dataframe["package_products"].apply(
                lambda pkg: sum(
                    float(prod.get("rate", 0) or 0)
                    for prod in pkg.get("productsData", {}).get("UpdatedTableData", [])
                    if prod.get("group")
                )
            )
            uploaded_dataframe["ungrouped"] = uploaded_dataframe["package_products"].apply(
                lambda pkg: sum(
                    float(prod.get("rate", 0) or 0)
                    for prod in pkg.get("productsData", {}).get("UpdatedTableData", [])
                    if prod.get("itemize")
                )
            )

            # Drop temp cols: drop 'product_type' from dataframe so it does not go to DB
            uploaded_dataframe = uploaded_dataframe.drop(
                columns=["product_id", "product_id_list", "product_type"], errors="ignore"
            )

            # --- Add defaults ---
            uploaded_dataframe["created_date"] = created_date
            uploaded_dataframe["created_by"] = username
            uploaded_dataframe["modified_date"] = created_date
            uploaded_dataframe["modified_by"] = username
            uploaded_dataframe["deleted_by"] = username
            uploaded_dataframe["is_active"] = True
            uploaded_dataframe["is_deleted"] = False
            uploaded_dataframe["bill_profile"] = ""
            uploaded_dataframe["zone"] = ""
            uploaded_dataframe["status"] = "Active"
            uploaded_dataframe["description"] = ""
            uploaded_dataframe["tenant_id"] = tenant_id
            uploaded_dataframe["tenant_name"] = tenant_name

            # Insert cleaned data
            uploaded_dataframe = uploaded_dataframe.where(
                pd.notnull(uploaded_dataframe), None
            )
            
            if "package_products" in uploaded_dataframe.columns:
                def force_valid_json(value):
                    """
                    Convert dict-like or string-like input into clean JSON.
                    Removes NaN, inf, single quotes, etc.
                    """
                    # If it's already a string, attempt to normalize quotes
                    if isinstance(value, str):
                        value = value.replace("'", '"')  # single → double quotes
                        value = value.replace("nan", "null")  # fix invalid NaN
                        try:
                            parsed = json.loads(value)
                            return json.dumps(parsed, ensure_ascii=False)
                        except Exception:
                            # If parsing still fails, store a safe string fallback
                            return json.dumps({"invalid_format": value}, ensure_ascii=False)

                    # If it's a dict/list, clean it recursively
                    elif isinstance(value, (dict, list)):
                        def clean_value(v):
                            # Handle NaN/inf → None
                            if isinstance(v, float):
                                return None
                            # Recursively clean dict
                            elif isinstance(v, dict):
                                return {k: clean_value(sub_v) for k, sub_v in v.items()}
                            # Recursively clean list
                            elif isinstance(v, list):
                                return [clean_value(sub_v) for sub_v in v]
                            # Leave other scalars as is
                            return v
                        safe_value = clean_value(value)
                        return json.dumps(safe_value, ensure_ascii=False, default=str)
                    else:
                        # For other scalar types
                        return json.dumps(value, ensure_ascii=False)

                uploaded_dataframe["package_products"] = uploaded_dataframe["package_products"].apply(force_valid_json)


            # --- 🔍 STEP 3: Convert to dict and continue as before ---
            uploaded_dict = uploaded_dataframe.to_dict(orient="records")
            logging.info(f"## process_packages_upload sanitized uploaded_dict: {uploaded_dict}")

            # uploaded_dict = uploaded_dataframe.to_dict(orient="records")
            # logging.info(f"## process_packages_upload uploaded_dict: {uploaded_dict}")
            cleaned_uploaded_dict = [
                clean_package_record(record) for record in uploaded_dict
            ]
            logging.info(
                f"## process_packages_upload cleaned_uploaded_dict: {cleaned_uploaded_dict}"
            )
            if cleaned_uploaded_dict:
                status = killbill_database.insert_data(cleaned_uploaded_dict, table_name)
                logging.info(
                    f"## process_packages_upload duplicate_packages_count: {duplicate_packages_count}"
                )
                result = status, duplicate_packages_count
                logging.info(f"###process_packages_upload result  : {result}")
                return result
            else:
                return True, duplicate_packages_count
        else:
            # DataFrame is empty after processing, return success with duplicate count
            logging.info(f"## process_packages_upload: No data to insert after processing")
            return True, duplicate_packages_count

    except Exception as e:
        logging.error(f"## process_packages_upload error: {e}")
        error_data = {
            "service_name": "process_packages_upload",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": username,
            "session_id": None,
            "tenant_name": tenant_name,
            "comments": "Unhandled exception during packages upload",
            "module_name": "Billing Packages",
            "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        biling_common_utils_database.log_error_to_db(error_data, "error_log_table")
        return False, 0


def import_bulk_data(data):
    # database connections  
    start_time = time.time()
    billing_common_utils_database= DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    try:
        logging.info(f"## import_bulk_data function called with data {data}")
        username = data.get("username"); table_name = data.get("table_name")
        created_date = data.get("request_received_at")
        module_name = data.get("module_name")
        tenant_database_name = data.get("db_name"); tenant_name = data.get("tenant_name")

        if not tenant_database_name:
            return {"flag": False,"message":"Tenant Database is Required"}

        tenant_database = DB(tenant_database_name, **db_config)
        common_utils_main_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        # Initialize DB connections
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        mode = os.getenv("ENV","")

        # tenant_id lookup
        try:
            tenant_id = common_utils_main_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"])["id"].to_list()[0]
        except Exception as e:
            logging.exception(f"## import_bulk_data failed tenant lookup: {e}")
            tenant_id = None
        if mode=="UAT" and tenant_id in ['212',212]:
            tenant_name,tenant_id = "Altaworx", 1

        # decode Excel
        blob_data = data.get("blob")
        if not blob_data:
            error_data = {
                "service_name": "import_bulk_data",
                "error_message": "Blob data not provided",
                "error_type": "MissingBlobError",
                "users": data.get("username"),
                "session_id": None,
                "tenant_name": data.get("tenant_name"),
                "comments": "Blob data missing during Import Bulk data",
                "module_name": module_name,
                "request_received_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S") ,
            }
            billing_common_utils_database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False,"message":"Blob data not provided"}
        blob_data = blob_data.split(",",1)[1]
        blob_data += "="*(-len(blob_data)%4) # padding
        file_stream = BytesIO(base64.b64decode(blob_data))
        uploaded_dataframe = pd.read_excel(file_stream, engine="openpyxl",dtype=str)
        if uploaded_dataframe.empty:
            error_data = {
                "service_name": "import_bulk_data",
                "error_message": "Uploaded file is empty",
                "error_type": "EmptyFileError",
                "users": data.get("username"),
                "session_id": None,
                "tenant_name": data.get("tenant_name"),
                "comments": "Empty file uploaded during Import Bulk data",
                "module_name": module_name,
                "request_received_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S") ,
            }
            billing_common_utils_database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": "Uploaded Excel has no data"}
            

        uploaded_dataframe.columns = uploaded_dataframe.columns.str.replace(" ","_").str.lower()
        duplicate_products_count=0
        duplicate_packages_count=0
        # Delegate
        message=''
        if module_name=="Billing Packages":
            if "package_name" in uploaded_dataframe.columns:
                uploaded_dataframe.rename(columns={"package_name": "category"}, inplace=True)
            status, duplicate_packages_count = process_packages_upload(uploaded_dataframe, created_date, username, tenant_id, tenant_name, killbill_database, table_name,tenant_database)
            logging.info(f"## import_bulk_data function {duplicate_packages_count} with status {status}")
        elif module_name=="Billing Products":
            status,duplicate_products_count, message, validation = process_products_upload(uploaded_dataframe, created_date, username, tenant_id, tenant_name, tenant_database, killbill_database, table_name,tenant_database)
            logging.info(f"## import_bulk_data function {duplicate_products_count} with status {status}")
        else:
            error_data = {
                "service_name": "import_bulk_data",
                "error_message": "Invalid module name provided",
                "error_type": "InvalidModuleError",
                "users": data.get("username"),
                "session_id": None,
                "tenant_name": data.get("tenant_name"),
                "comments": "Unhandled exception during Import Bulk data",
                "module_name": module_name,
                "request_received_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S") ,
            }
            billing_common_utils_database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False,"message":"Invalid Module flag"}
        if not status: 
            error_data = {
                "service_name": "import_bulk_data",
                "error_message": "Data insertion failed",
                "error_type": "DataInsertionError",
                "users": data.get("username"),
                "session_id": None,
                "tenant_name": data.get("tenant_name"),
                "comments": "Unhandled exception during Import Bulk data",
                "module_name": module_name,
                "request_received_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S") ,
            }
            billing_common_utils_database.log_error_to_db(error_data, "error_log_table")
            if not message:
                message="Upload failed"
            if duplicate_products_count:
                message+=' ,Duplicate Count -'+str(duplicate_products_count)
                logging.info(f"## import_bulk_data function completed with duplicate_products_count {duplicate_products_count}")
            elif duplicate_packages_count:
                message+=' ,Duplicate Count -'+str(duplicate_packages_count)
                logging.info(f"## import_bulk_data function completed with duplicate_packages_count {duplicate_packages_count}")

            logging.info(f"## import_bulk_data function completed with message {message}")
            return {"flag": False,"message":message}
        
        # Audit success
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data_user_actions = {
            "service_name": "import_bulk_data",
            "status": True,
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": f'Successfully Bulk Upload for module {module_name}',
            "module_name": module_name,
            "request_received_at": data.get("request_received_at"),
        }
        billing_common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        if not message:
            message='Upload operation is done'
        # if duplicate_products_count:
        #     message+=' ,Duplicate Count: '+str(duplicate_products_count)
        #     logging.info(f"## import_bulk_data function completed with duplicate_products_count {duplicate_products_count}")
        elif duplicate_packages_count:
            message+=' ,Duplicate Count: '+str(duplicate_packages_count)
            logging.info(f"## import_bulk_data function completed with duplicate_packages_count {duplicate_packages_count}")

        logging.info(f"## import_bulk_data function completed with message {message}")
        if module_name=="Billing Products":
            return {"flag": status,"message":message,"Validation": validation}
        else:
            return {"flag": False,"message":message}

    except Exception as e:
        logging.exception(f"## import_bulk_data Exception: {e}")
        error_data = {
            "service_name": "import_bulk_data",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": username,
            "session_id": None,
            "tenant_name": tenant_name,
            "comments": "Unhandled exception during Import Bulk data",
            "module_name": module_name,
            "request_received_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S") ,
        }
        billing_common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": f"An error occurred during import: {e}"}

def capitalize_columns(df):
    """Capitalizes the column names of the DataFrame."""
    df.columns = df.columns.str.replace("_", " ").str.title()
    return df
def dataframe_to_blob_bulk_upload_packages(
    data_frame, package_data_final=None,service_type_sheet_df=None,service_provider_sheet_df=None,products_sheet_df=None,sample_data_df = None
):
    """
    Description: The Function is used to convert the dataframe to blob
    """
    # Create a BytesIO buffer
    def style_and_adjust_columns(sheet):
        """
        Apply header styles and adjust column widths for the given sheet.
        """
        # Apply header styles
        for cell in sheet[1]:
            cell.alignment = Alignment(horizontal="center", vertical="center")  # Center align
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")  # Grey background

        # Adjust column widths based on content
        for col_idx, col_cells in enumerate(sheet.columns, 1):
            max_length = max(len(str(cell.value or "")) for cell in col_cells)
            sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2
    data_frame["Product Id"] = range(1, len(data_frame) + 1)
    # Create a BytesIO buffer
    excel_buffer = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
        # Write main data frame to the first sheet
        data_frame.to_excel(writer, index=False, sheet_name="Template")

        # Apply styles to the Template sheet
        workbook = writer.book
        sheet = workbook["Template"]
        style_and_adjust_columns(sheet)

        # Write tenant sheet if data exists and apply styles package_data_final
        if package_data_final is not None and not package_data_final.empty:
            package_data_final.to_excel(writer, sheet_name="Packages", index=False)
            sheet = workbook["Packages"]
        if service_type_sheet_df is not None and not service_type_sheet_df.empty:
            service_type_sheet_df.to_excel(writer, sheet_name="Service Types", index=False)
            sheet = workbook["Service Types"]
            style_and_adjust_columns(sheet)
        if service_provider_sheet_df is not None and not service_provider_sheet_df.empty:
            service_provider_sheet_df.to_excel(writer, sheet_name="Service Provider", index=False)
            sheet = workbook["Service Provider"]
            style_and_adjust_columns(sheet)
        # if product_type_sheet_df is not None and not product_type_sheet_df.empty:
        #     product_type_sheet_df.to_excel(writer, sheet_name="Product Types", index=False)
        #     sheet = workbook["Product Types"]
        #     style_and_adjust_columns(sheet)
        if products_sheet_df is not None and not products_sheet_df.empty:
            products_sheet_df.to_excel(writer, sheet_name="Products", index=False)
            sheet = workbook["Products"]
            style_and_adjust_columns(sheet)
        if sample_data_df is not None and not sample_data_df.empty:
            sample_data_df.to_excel(writer, sheet_name="Sample Data", index=False)
            sample_sheet = workbook["Sample Data"]
            style_and_adjust_columns(sample_sheet)
    # Convert Excel data to base64 blob
    excel_buffer.seek(0)
    blob_data = base64.b64encode(excel_buffer.read())
    return blob_data

def dataframe_to_blob_bulk_upload_products(
    data_frame, ps_code_df = None, product_types_code_sheet_df = None, business_type_df = None, combined_service_provider_df = None, sample_data_df = None
):
    """
    Description: The Function is used to convert the dataframe to blob
    """
    # Create a BytesIO buffer
    def style_and_adjust_columns(sheet):
        """
        Apply header styles and adjust column widths for the given sheet.
        """
        # Apply header styles
        for cell in sheet[1]:
            cell.alignment = Alignment(horizontal="center", vertical="center")  # Center align
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")  # Grey background

        # Adjust column widths based on content
        for col_idx, col_cells in enumerate(sheet.columns, 1):
            max_length = max(len(str(cell.value or "")) for cell in col_cells)
            sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

    # Create a BytesIO buffer
    excel_buffer = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
        # Write main data frame to the first sheet
        data_frame.to_excel(writer, index=False, sheet_name="Template")

        # Apply styles to the Template sheet
        workbook = writer.book
        sheet = workbook["Template"]
        style_and_adjust_columns(sheet)

        # Write tenant sheet if data exists and apply styles
        # if bundle_code_df is not None and not bundle_code_df.empty:
        #     bundle_code_df.to_excel(writer, sheet_name="Bundle Codes", index=False)
        #     sheet = workbook["Bundle Codes"]
        #     style_and_adjust_columns(sheet)
        if ps_code_df is not None and not ps_code_df.empty:
            ps_code_df.to_excel(writer, sheet_name="Tax Codes", index=False)
            sheet = workbook["Tax Codes"]
            style_and_adjust_columns(sheet)
        if product_types_code_sheet_df is not None and not product_types_code_sheet_df.empty:
            product_types_code_sheet_df.to_excel(writer, sheet_name="Product Type Codes", index=False)
            sheet = workbook["Product Type Codes"]
            style_and_adjust_columns(sheet)

        if business_type_df is not None and not business_type_df.empty:
            business_type_df.to_excel(writer, sheet_name="Business Types", index=False)
            sheet = workbook["Business Types"]
            style_and_adjust_columns(sheet)
        if combined_service_provider_df is not None and not combined_service_provider_df.empty:
            combined_service_provider_df.to_excel(writer, sheet_name="Providers", index=False)
            sheet = workbook["Providers"]
            style_and_adjust_columns(sheet)
        
        if sample_data_df is not None and not sample_data_df.empty:
            sample_data_df.to_excel(writer, sheet_name="Sample Data", index=False)
            sample_sheet = workbook["Sample Data"]
            style_and_adjust_columns(sample_sheet)
        

    # Convert Excel data to base64 blob
    excel_buffer.seek(0)
    blob_data = base64.b64encode(excel_buffer.read())
    return blob_data
def download_bulk_upload_template(data):
    """
    Generates a bulk upload template for a specified module and table. The function fetches
    the columns for the specified table, removes unnecessary columns based on the module type,
    and organizes the data in the desired order for a bulk upload template. It also fetches and
    formats additional tenant and service provider data, then converts the generated template
    to a binary blob for download.

    Parameters:
        data (dict): A dictionary containing the following keys:
            - 'module_name' (str): The name of the module (e.g., 'Users', 'Customer Rate Pool').
            - 'table_name' (str): The name of the table for which to generate the bulk upload template.
            - 'db_name' (str): The name of the database for the tenant (e.g., 'tenant_database').

    Returns:
        dict: A response dictionary with the following structure:
            - 'flag' (bool): Indicates whether the operation was successful.
            - 'blob' (str, optional): A string representing the binary-encoded blob data of the template if successful.
            - 'message' (str, optional): An error message if the operation failed.
    """
    try:
        start_time = time.time()
        # Get columns for the specific table
        module_name = data.get("module_name", "")
        table_name = data.get("table_name", "")
        tenant_database_name = data.get("db_name", "")
        if tenant_database_name=='billing_platform':
            tenant_database_name='altaworx_test'
        tenant_name = data.get("tenant_name", "")
        mode = os.getenv('ENV', 'UAT')
        if mode == 'UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'

        # Database Connection
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_database = DB(tenant_database_name, **db_config)

        # Fetch tenant id and timezone
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )

        if tenant_data.empty:
            raise ValueError("No valid tenant found.")

        tenant_id = tenant_data["id"].to_list()[0]

        if module_name == 'Billing Products':
            columns_df = pd.DataFrame(
                {"column_name": ["description", "bundle_code","tax_code", "product_type_code", "business_type", "provider", "rate"]}
            )
        else:
            columns_df = killbill_database.get_table_columns(table_name)

        # Specify columns to remove if the module name is 'Customer Rate Pool'
        if module_name == 'Billing Packages':
            columns_to_remove = [
                "created_by", "created_date", "modified_by", "modified_date", "is_active", "bill_profile",
                "zone", "is_deleted", "deleted_by", "status", "package_products", "description",
                "tenant_id", "tenant_name", "service_type","provider_id","one_time","grouped","ungrouped"
            ]
            columns_df = columns_df[
                ~columns_df["column_name"].str.lower().isin([col.lower() for col in columns_to_remove])
            ]

        # Remove the 'id' column if it exists
        columns_df = columns_df[columns_df["column_name"] != "id"]

        # Capitalize column names
        columns_df["column_name"] = (
            columns_df["column_name"].str.replace("_", " ").str.title()
        )
        if module_name == 'Billing Packages':
            # Force define the required columns explicitly
            required_columns = [
                "Package Name",
                "Product Type",
                "Service Id",  # instead of Category
                "Description On Bill",
                "Service Provider Name",
                "Product Id"
            ]

            # Create empty template DataFrame with only these columns
            result_df = pd.DataFrame(columns=required_columns)
        else:
            # Create an empty DataFrame with the column names as columns
            result_df = pd.DataFrame(columns=columns_df["column_name"].values)

        # Fetch tenant and service provider data

        # Fetch service providers separately from both tenant and main DB and combine
        service_provider_tenant_df = tenant_database.get_data("serviceprovider", None, ["id", "display_name"])
        service_provider_tenant_df = capitalize_columns(service_provider_tenant_df)

        service_provider_main_df = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
        service_provider_main_df = capitalize_columns(service_provider_main_df)

        combined_display_names = pd.concat([
            service_provider_main_df['Display Name'],
            service_provider_tenant_df['Display Name']
        ]).drop_duplicates().reset_index(drop=True)

        combined_service_provider_df = pd.DataFrame({"Display Name": combined_display_names})

        if module_name == "Billing Products":
            product_types_code_sheet_df = pd.DataFrame({
                "Product Type Codes": ["Onetime", "Recurring"]
            })
            product_types_code_sheet_df = capitalize_columns(product_types_code_sheet_df)

            ps_code_query_list_df = ps_codes(data)
            ps_code_df = pd.DataFrame(ps_code_query_list_df, columns=["raw_code"])

            # Split only on the first dash
            ps_code_df[["Bundle Code", "Tax Code"]] = (
                ps_code_df["raw_code"]
                .str.split(" - ", n=1, expand=True)
            )
            ps_code_df.drop(columns=["raw_code"], inplace=True)

            # Optional: trim spaces just in case
            ps_code_df["Bundle Code"] = ps_code_df["Bundle Code"].str.strip()
            ps_code_df["Tax Code"] = ps_code_df["Tax Code"].str.strip()
            
            #ps_code_df = pd.DataFrame(ps_code_query_list_df, columns=["Tax Code"])
            #bundle_code_df = pd.DataFrame(bundle_code_list_df, columns=["Bundle Code"])
            
            business_type_df = pd.DataFrame({
                "Business Type": ["10-CLEC","11-IXC","12-CMRS/Wireless","14-Prepaid Wireless","15-VoIP"]})

            sample_data_df = pd.DataFrame({
                "Description": ["Upload Prod1"],
                "Bundle Code":["C0001"],
                "Tax Code": ["62040400 - Usage-Based Charges - Nomadic VOIP Service"],
                "Product Type Code": ["Onetime"],
                "Business Type": ["12-CMRS/Wireless"],
                "Provider": ["Test Provider"],
                "Rate": [10]
                })
            blob_data = dataframe_to_blob_bulk_upload_products(
                result_df, ps_code_df, product_types_code_sheet_df,business_type_df, combined_service_provider_df,sample_data_df
            )
            file_name = f"Upload {data.get('module_name', 'Billing Products')}"

        elif module_name == 'Billing Packages':
            service_type_sheet_df = killbill_database.get_data(
                "services", {"is_active": True, "tenant_id": tenant_id}, ["id", "description"]
            )
            service_type_sheet_df = capitalize_columns(service_type_sheet_df)

            product_type_sheet_df = killbill_database.get_data(
                "product_types", {"is_active": True, "tenant_id": tenant_id}, ["id", "description"]
            )
            product_type_sheet_df = capitalize_columns(product_type_sheet_df)

            products_sheet_df = killbill_database.get_data(
                "products", {"is_active": True, "tenant_id": tenant_id}, ["id", "description", "product_type_id"]
            )
            products_sheet_df = capitalize_columns(products_sheet_df)
            sample_data_df = pd.DataFrame({
                "Package Name": ["Upload Test2"],
                "Product Type": ["Product Type Test2"],
                "Service Id":[10] ,
                "Description On Bill": ["Upload Test2"],
                "Service Provider Name": ["Test Provider Test"],
                "Product Id": ["102,104,105"],
            })

            blob_data = dataframe_to_blob_bulk_upload_packages(
                result_df, service_type_sheet_df, combined_service_provider_df, product_type_sheet_df, products_sheet_df,sample_data_df
            )
            file_name = f"Upload {data.get('module_name', 'Billing Packages')}"
        else:
            response = {"flag": False, "message": f"Invalid Module Name"}
            error_data = {
                "service_name": "download_bulk_upload_template",
                "error_message": "Invalid Module Name",
                "error_type": "Invalid Module Name",
                "users": data.get("username"),
                "session_id": data.get("session_id"),
                "tenant_name": data.get("tenant_name"),
                "comments": "Invalid Module Name",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at"),
            }
            database.log_error_to_db(error_data, "error_log_table")
            return response
        
        # Audit success
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data_user_actions = {
            "service_name": "download_bulk_upload_template",
            "created_by": data.get("username"),
            "status":"True",
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": f'Successfully downloaded {module_name} Template',
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at"),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        response = {"flag": True, "blob": blob_data.decode("utf-8"),"file_name":file_name}
        return response

    except Exception as e:
        logging.exception(f"###download_bulk_upload_template Exception occurred: {e}")
        response = {"flag": False, "message": f"Failed to download the Template !! {e}"}
        error_data = {
            "service_name": "download_bulk_upload_template",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during download_bulk_upload_template",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response





def add_package(data):
    """
    Adds a new package to the database by processing the provided details and inserting them into the appropriate tables. The function handles different sections of package data, such as general details (stored in the 'packages' table) and product-specific details (stored in the 'product_packages' table). It also ensures that related fields like provider, service type, and category are properly mapped using existing data from other tables.
    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name for permissions and data access.
            - tenant_name (str): Tenant name to determine context for the operation.
            - changed_data (dict): A dictionary containing the package details to be added, such as:
                - provider (str): The name of the provider for the package.
                - service_type (str): The service type associated with the package.
                - category (str): The category of the package.
            - module_name (str): The name of the module from which the request is coming, used to determine the type of data being saved.
    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message.
    """
    print(f"request_data--{data}")
    # Initialize DB connections
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    logging.info(f"###add_package function called {data}")
    data=readme_api_data(common_utils_database,data)
    logging.info(f"###add_package result {data}")
    if data.get("z_access_token"):
        changed_data=fetch_products_payload(
            {
                "product_id_list": data.get("product_id_list", ""),
                "category": data.get("package_name", ""),
                "desc_on_bill": data.get("desc_on_bill", ""),
                "display_name": data.get("service_provider", ""),
                "service_type": data.get("service_type", ""),
                "db_name": killbill_database,
            },killbill_database
        )
        data["changed_data"]=changed_data


    tenant_db_name = data.get('db_name', '')
    if tenant_db_name=="null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    # Extract meta data
    tenant_name = data.get('tenant_name', '')
    username = data.get('username', '')
    session_id = data.get('session_id', '')
    module_name = data.get('module_name', '')
    modified_date = data.get('request_received_at', '')
    partner_name = data.get('Partner', '')
    start_time = time.time()
    tenant_id = data.get('tenant_id', 1)
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1
    if tenant_db_name=="null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    try:
        pop_up_data = data.get('changed_data', {})
        general_data = pop_up_data.get('generalData', {})
        products_data = pop_up_data.get('productsData', {})
        category = general_data.get('category', '')
        category = category.strip()
        if category:
            # Fetch category ID from database
            category_df = killbill_database.get_data("packages", {"category": category}, ["id","category"]).to_dict(orient="records")
            if category_df:
                # Category already exists — return error response
                error_data = {
                "service_name": "add_package",
                "error_message": "Duplicate Package",
                "error_type": "Duplicate Package",
                "users": username,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": f"Duplicate Package---{category}",
                "module_name": "Billing Services",
                "request_received_at": modified_date,
                }
                
                # Log error to database
                database.log_error_to_db(error_data, "error_log_table")
                return {
                    "flag": True,
                    "message": "Package Name already exists",
                    "status": False,
                    "validation": True
                }
        else:
            logging.info("No category provided, proceeding without category check.")

        # Build general tab data for 'packages' table
        general_tab = {
            "desc_on_bill": general_data.get('desc_on_bill', ''),
            "category": general_data.get('category', ''),
            "one_time": general_data.get('one_time', ''),
            "created_by": username,
            "modified_by": username,
            "status": 'Active',
            "tenant_id": str(tenant_id),
            "tenant_name": tenant_name,
        }

        # # Map provider to ID
        # if "display_name" in general_data:
        #     provider = general_data['display_name']
        #     provider_data = tenant_database.get_data("serviceprovider", {"display_name": provider}, ["id"])
        #     if not provider_data.empty:
        #         general_tab['provider_id'] = str(provider_data["id"].to_list()[0])

        # Map provider to ID
        if "display_name" in general_data:
            provider = general_data['display_name']
            general_tab['service_provider_name'] = provider
            provider_data = tenant_database.get_data("serviceprovider", {"display_name": provider}, ["id"])
            if not provider_data.empty:
                general_tab['provider_id'] = str(provider_data["id"].to_list()[0])
            else:
                # Not found in tenant_database, check killbill_database
                provider_data = killbill_database.get_data(
                    "serviceprovider", {"display_name": provider}, ["id"]
                )
            if not provider_data.empty:
                general_tab['provider_id'] = str(provider_data["id"].to_list()[0])

        # Map service type to ID
        if "service_type" in general_data:
            service_type = general_data['service_type']
            service_data = killbill_database.get_data("services", {"description": service_type,"is_active":True,"tenant_id":tenant_id}, ["id"])
            if not service_data.empty:
                general_tab['service_id'] = str(service_data["id"].to_list()[0])

        # Calculate grouped and ungrouped totals from products table
        grouped = ungrouped = 0
        for row in products_data.get('UpdatedTableData', []):
            rate = float(row.get('rate', 0) or 0)
            if row.get('group'):
                grouped += rate
            if row.get('itemize'):
                ungrouped += rate

        general_tab['grouped'] = str(grouped)
        general_tab['ungrouped'] = str(ungrouped)
        general_tab['package_products'] = str(data.get('changed_data', {}))
        print("before insert")
        # Insert package into 'packages' table
        insert_status = killbill_database.insert_dict(general_tab, 'packages')
        logging.info(f"###add_package function called {general_tab}")
        insert_status=1
        print(f"insert_status---{insert_status}")
        if insert_status:
            # Success audit
            time_consumed = int(time.time() - start_time)
            audit_data = {
                "service_name": "add_package",
                "created_by": username,
                "status": "True",
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": partner_name,
                "comments": f"Successfully added Package:{general_data.get('category', '')}",
                "module_name": "Billing Services",
                "request_received_at": modified_date,
            }
            database.update_audit(audit_data, "audit_user_actions")

            return {"flag": True, "message": "Successfully added Package"}

        else:
            error_data = {
            "service_name": "add_package",
            "error_message": "insert query failed",
            "error_type": "Query Failure",
            "users": username,
            "session_id": session_id,
            "tenant_name": partner_name,
            "comments": f"query failed --{general_tab}",
            "module_name": "Billing Services",
            "request_received_at": modified_date,
            }
            
            # Log error to database
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": "Error adding Package"}

    except Exception as e:
        logging.exception("Exception while adding package")
        message = "Something went wrong fetching Account Details"
        response = {
            "flag": False,
            "message": "Failed to add the data"
            }
        error_type = str(type(e).__name__)
        # Prepare error data for database logging
        error_data = {
            "service_name": "add_package",
            "error_message": message,
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": partner_name,
            "comments": response.get("message", ""),
            "module_name": module_name,
            "request_received_at": modified_date,
        }
        
        # Log error to database
        database.log_error_to_db(error_data, "error_log_table")
    return response


def fetch_products_payload_back(api_data, db):
    """
    Fetch product data from products table based on product IDs and format payload.
    
    Args:
        product_id_list (str): Comma-separated product IDs e.g. "3,4,6,7,78"
        db (object): Database connection object with `get_data` method
    
    Returns:
        dict: Payload in required format
    """
    try:
        product_id_list = api_data.get("product_id_list", "")
        category = api_data.get("category", "")
        desc_on_bill = api_data.get("desc_on_bill", "")
        display_name = api_data.get("display_name", "")
        service_type = api_data.get("service_type", "")


        # Convert to list of integers
        product_ids = [int(pid.strip()) for pid in product_id_list.split(",") if pid.strip()]
        logging.info(f"Fetching products for IDs: {product_ids}")

        # comma separated ids to for select query

        query=f"select * from products where id =any(array{product_ids})"
        products_data = db.execute_query(query, params=[]).to_dict(orient="records")
        if not products_data:
            return {"flag": False, "message": "No products found for given IDs."}

        # Build description list
        description_list = [f"{p['description']} -- {p['id']}" for p in products_data]

        payload = {
                "generalData": {
                    "category": category,
                    "desc_on_bill": desc_on_bill,
                    "display_name": display_name,
                    "service_type": service_type
                },
                "productsData": {
                    "description": description_list,
                    "UpdatedTableData": products_data
                }
            }

        return payload

    except Exception as e:
        logging.error(f"Error fetching products payload: {e}", exc_info=True)
        return {}


def fetch_products_payload(api_data, db):
    """
    Fetch product data from products table based on product IDs and format payload.
    
    Args:
        api_data (dict): Dictionary containing product_id_list, category, etc.
        db (object): Database connection object with `execute_query` method
    
    Returns:
        dict: Payload with product data and parsed multi_service_id values (inside each record)
    """
    try:
        product_id_list = api_data.get("product_id_list", "")
        category = api_data.get("category", "")
        desc_on_bill = api_data.get("desc_on_bill", "")
        display_name = api_data.get("display_name", "")
        service_type = api_data.get("service_type", "")

        # Convert to list of integers
        product_ids = [int(pid.strip()) for pid in product_id_list.split(",") if pid.strip()]
        logging.info(f"Fetching products for IDs: {product_ids}")

        # Prepare SQL query
        query = f"SELECT * FROM products WHERE id = ANY(array{product_ids})"
        products_data = db.execute_query(query, params=[]).to_dict(orient="records")
        if not products_data:
            return {"flag": False, "message": "No products found for given IDs."}
        
        

        # Parse multi_service_id for each product
        for product in products_data:
            product.pop("created_date", None)
            product.pop("modified_date", None)
            m_id = product.get("multi_service_id")
            multi_options_val=product.get("multi_options_val")
            if isinstance(multi_options_val, str):
                try:
                    record["multi_options"] = ast.literal_eval(multi_options_val)
                except json.JSONDecodeError:
                    try:
                        record["multi_options"] = json.loads(multi_options_val)
                    except Exception:
                        pass
            if isinstance(m_id, str):
                try:
                    # Try JSON first
                    product["multi_service_id"] = ast.literal_eval(m_id)
                except json.JSONDecodeError:
                    try:
                        # Fallback to literal_eval
                        product["multi_service_id"] = json.loads(m_id)
                    except Exception:
                        # If still fails, keep as string but strip brackets
                        product["multi_service_id"] = m_id.strip("[]").strip()
            # If null or empty, just leave as is

        # Build description list
        description_list = [f"{p['description']} -- {p['id']}" for p in products_data]
        logging.info(f"products_data list: {products_data}")
        payload = {
            "generalData": {
                "category": category,
                "desc_on_bill": desc_on_bill,
                "display_name": display_name,
                "service_type": service_type
            },
            "productsData": {
                "description": description_list,
                "UpdatedTableData": products_data  # multi_service_id now parsed inside each record
            }
        }
        return payload

    except Exception as e:
        logging.error(f"Error fetching products payload: {e}", exc_info=True)
        return {}


def services_product_package_list_view(data):
    """
    Retrieves a paginated list of billing packages along with relevant dropdown values for service types and providers.
    The function queries the database for a list of billing packages and prepares the necessary data for display,
    including pagination information and dropdown options for selecting service types and providers.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name for permissions and data access.
            - tenant_name (str): Tenant name used to fetch tenant-specific timezone information.
            - mod_pages (dict): Pagination information, containing:
                - start (int): The starting index for records to fetch.
                - end (int): The ending index for records to fetch.
            - other fields as necessary for query execution.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message.
            - data (dict): Contains the fetched data, including:
                - billing_packages: A list of billing packages.
            - header_map (dict): Mapping for headers based on user role.
            - pages (dict): Pagination details (start, end, total).
            - dropdown (dict): Contains options for dropdowns such as 'service_type' and 'provider'.
    """
    try:
        # Database connections
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_name = data.get('db_name', '')
        if tenant_db_name=="null":
            tenant_db_name = "altaworx_test"
        tenant_database = DB(tenant_db_name, **db_config)

        # Extract inputs
        role_name = data.get('role_name', '')
        tenant_name = data.get('tenant_name', '')
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)
        flag = data.get('status', '')
        col_sort = data.get('col_sort', {})
        limit = end - start
        offset = start
        tenant_id = data.get('tenant_id', 1)
        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        
        # Get tenant ID and time zone
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["time_zone"]
        )

        if tenant_data.empty:
            raise ValueError("No valid tenant found.")

        tenant_time_zone = tenant_data["time_zone"].to_list()[0]

        if not tenant_time_zone:
            raise ValueError("No valid timezone found for tenant.")

        # Normalize timezone (remove extra text around time zone)
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')

        # Get total count for pagination
        count_query = f"""
            SELECT COUNT(*) AS total
            FROM packages_list_view
            WHERE tenant_id = {tenant_id}
        """
        if flag == 'true':
            count_query += " AND is_active = 'true'"

        total_count_result = killbill_database.execute_query(count_query, flag=True)
        total_count = int(total_count_result.iloc[0]['total'])

        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        
        # Build base query
        query = f"""
            SELECT * 
            FROM packages_list_view
            WHERE tenant_id = {tenant_id}
        """
        if flag == 'true':
            query += " AND is_active = 'true'"

        if col_sort:
            # Sort by provided column and direction
            sort_col = list(col_sort.keys())[0]
            sort_dir = col_sort[sort_col].lower()
            query += f" ORDER BY {sort_col} {sort_dir}"
        else:
            # Default sort
            query += " ORDER BY category"

        query += " LIMIT %s OFFSET %s"

        # Execute query with limit and offset for pagination
        df = killbill_database.execute_query(query, params=[limit, offset])
        df_dict = convert_timestamp(df.to_dict(orient="records"), tenant_time_zone)

        # Prepare dropdowns
        try:
            service_type_df = killbill_database.get_data(
                "services", {"is_active": True, "tenant_id": tenant_id}, ["description"]
            )
            service_type_dd_vals = sorted(set(service_type_df["description"].tolist()))
            
            # service_provider_query = tenant_database.get_data("serviceprovider", columns=["id", "display_name"])
            # provider_list = sorted(
            #     list(
            #         {name for name in service_provider_query["display_name"].tolist() if name is not None}
            #     )
            # )
            service_provider_query = tenant_database.get_data(
                "serviceprovider", columns=["id", "display_name"]
            )
            provider_name_dict = dict(zip(service_provider_query["id"], service_provider_query["display_name"]))
            provider_list = {
                name for name in service_provider_query["display_name"].tolist() if name is not None
            }

            # --- Service Providers from killbill_database (bp)
            service_provider_query_bp = killbill_database.get_data(
                "serviceprovider",{'is_active': True}, columns=["id", "display_name"]
            )
            provider_name_dict_bp = dict(zip(service_provider_query_bp["id"], service_provider_query_bp["display_name"]))
            provider_list_bp = {
                name for name in service_provider_query_bp["display_name"].tolist() if name is not None
            }

            # Combine lists based on unique display_name
            combined_provider_list = sorted(provider_list.union(provider_list_bp), key=str.lower)

            dropdown_vals = {
                "service_type": service_type_dd_vals,
                "display_name": combined_provider_list
            }

        except Exception as e:
            logging.exception(f"###services_product_package_list_view Error loading dropdowns: {e}")
            error_data = {
                "service_name": "services_product_package_list_view",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": data.get("username"),
                "session_id":  data.get("session_id"),
                "tenant_name":  data.get("tenant_name"),
                "comments": "Unhandled exception during products package list view",
                "module_name": "Billing Services",
                "request_received_at":data.get("request_received_at"),
            }
            database.log_error_to_db(error_data, "error_log_table")
            dropdown_vals = {
                "service_type": [],
                "display_name": []
            }
        # Prepare response data
        header_map = get_headers_mapping(killbill_database,["Billing Packages"],role_name, '', '', '', '',data)
        data_dict_all = {"billing_packages": serialize_data(df_dict)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "dropdown":dropdown_vals
        }
        return response

    except Exception as e:
        logging.exception(f"###services_product_package_list_view:Exception occurred: {e}")
        error_data = {
            "service_name": "services_product_package_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id":  data.get("session_id"),
            "tenant_name":  data.get("tenant_name"),
            "comments": "Unhandled exception during products package list view",
            "module_name": "Billing Services",
            "request_received_at":data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Packages List View",
            "data": {}  # Return empty dictionary on error
        }
        return response
    
def product_package_pop_up_list_view_data(data):
    """
    Retrieves a list of product packages for display in a pop-up, including pagination and filtering based on provided criteria.
    The function fetches relevant product package data from the database, applies pagination, handles timezone conversion,
    and prepares the response with necessary data, including headers and pagination information.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name, used for permissions and access control.
            - tenant_name (str): The tenant name, used for tenant-specific operations.
            - changed_data (dict): Contains the filter criteria such as product description and product type.
            - mod_pages (dict): Pagination details, including 'start' (starting index) and 'end' (ending index).

    Returns:
        dict: A dictionary containing the following:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message.
            - data (dict): Contains the fetched product package data and serialization details.
            - header_map (dict): Mapping for headers based on user role.
            - pages (dict): Pagination details (start, end, total).
    """
    logging.info(f'## product_package_pop_up_list_view_data fucntion called with data {data}')
    try:
        # Initialize DBs
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_name = data.get('db_name', '')
        tenant_database = DB(tenant_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        killbill_database = DB(billing_db_name, **db_config)
        
        # Extract metadata
        tenant_name = data.get('tenant_name', '')
        role_name = data.get('role_name', '')
        filters = data.get('changed_data', {})
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)
        mode=os.getenv('ENV','')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
        tenant_db_name=data.get("db_name",'')
        if not tenant_db_name:
            return {'flag':False,'message':'Tenant DS is Required'}
        tenant_database = DB(tenant_db_name, **db_config)

        # Extract filter values
        product_description_list = filters.get('description', [])
        product_ids = tuple(item.split("--")[1].strip() for item in product_description_list) if product_description_list else ('',)

        # Get tenant ID and time zone
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id", "time_zone"]
        )

        if tenant_data.empty:
            raise ValueError("No valid tenant found.")

        tenant_id = tenant_data["id"].to_list()[0]
        tenant_time_zone = tenant_data["time_zone"].to_list()[0]

        if not tenant_time_zone:
            raise ValueError("No valid timezone found for tenant.")

        # Normalize timezone (remove extra text around time zone)
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')

        # Get total count for pagination
        try:
            total_ids = killbill_database.get_data("products", {"is_active": True, "tenant_id": tenant_id}, ["id"])["id"].to_list()
            total_count = len(total_ids)

            # pagination not needed here
            pages_data = {
                "start": start,
                "end": end,
                "total": 1
            }
        except Exception as e:
            logging.exception("Error fetching product count")
            return {"flag": False, "message": "Error fetching product count", "data": {}, "header_map": {}, "pages": {}}
        
        try:
            product_df = killbill_database.get_data(
                table_name="products",
                condition={"id": product_ids},
                columns=None,
                order={"created_date": "desc"},
                mod_pages={"start": start, "end": end}
            ).to_dict(orient="records")
        except Exception as e:
            logging.exception("Error fetching product data")
            return {"flag": False, "message": "Error fetching products", "data": {}, "header_map": {}, "pages": pages_data}
        
        # Map provider display names
        try:
            providers_df = tenant_database.get_data("serviceprovider", columns=["id", "display_name"])
            provider_map = dict(zip(providers_df["id"], providers_df["display_name"]))
            for record in product_df:
                record["display_name"] = provider_map.get(record.get("provider_id"), "")
                multi_service_val = record.get("multi_service_id")
                multi_options_val = record.get("multi_options")
                if isinstance(multi_service_val, str):
                    record["multi_service_id"] = ast.literal_eval(multi_service_val)
                if isinstance(multi_options_val, str):
                    record["multi_options"] = ast.literal_eval(multi_options_val)
        except Exception as e:
            logging.exception("Error mapping provider display names")

        # Timezone conversion
        product_df = convert_timestamp(product_df, tenant_time_zone)

        # Prepare response data
        header_map = get_headers_mapping(killbill_database,["Product Packages"],role_name, '', '', '', '',data)
        data_dict_all = {"product_packages": serialize_data(product_df)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        return response

    except Exception as e:
        logging.exception(f"###product_package_pop_up_list_view_data Exception occurred: {e}")
        error_data = {
            "service_name": "product_package_pop_up_list_view_data",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id":  data.get("session_id"),
            "tenant_name":  data.get("tenant_name"),
            "comments": "Unhandled exception during products package pop up list view",
            "module_name": "Billing Services",
            "request_received_at":data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Product Package list",
            "data": {}  # Return empty dictionary on error
        }
        return response



def group_by_type(records):
    """
    Groups descriptions by product type from the given list of records.

    Args:
        records (list): List of dictionaries with 'type' and 'description'.

    Returns:
        dict: A dictionary mapping product types to unique descriptions.
    """
    type_description_mapping = defaultdict(list)
    for record in records:
        key = record['product_type_id'] if record['product_type_id'] else 'Unknown'
        if record['description']:
            type_description_mapping[key].append(record['description'])
    # Remove duplicates in the descriptions
    return {key: list(set(values)) for key, values in type_description_mapping.items()}


def product_package_pop_up_list_view(data):
    """
    Retrieves a list of product packages for display in a pop-up, including pagination, filtering, and dropdown options
    for products. The function fetches relevant product package data from the database, applies pagination, handles
    timezone conversion, and prepares the response with necessary data such as headers, pagination information, and
    dropdown values for selecting products.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name, used for permissions and access control.
            - tenant_name (str): The tenant name, used for tenant-specific operations.
            - mod_pages (dict): Pagination details, including 'start' (starting index) and 'end' (ending index).

    Returns:
        dict: A dictionary containing the following:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message.
            - header_map (dict): Mapping for headers based on user role.
            - pages (dict): Pagination details (start, end, total).
            - dropdown (dict): Dropdown values for products used in filtering.
    """
    try:
        # Initialize database connections
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # Extract data
        tenant_db = data.get('db_name', 'altaworx_central')
        role_name = data.get('role_name', '')
        tenant_name = data.get('tenant_name', '')
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)
        limit = end - start
        offset = start
        mode = os.getenv('ENV', 'UAT')
        if mode == 'UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'

        # Get tenant ID and time zone
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id", "time_zone"]
        )

        if tenant_data.empty:
            raise ValueError("No valid tenant found.")

        tenant_id = tenant_data["id"].to_list()[0]
        tenant_time_zone = tenant_data["time_zone"].to_list()[0]

        if not tenant_time_zone:
            raise ValueError("No valid timezone found for tenant.")

        # Normalize timezone (remove extra text around time zone)
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')

        # Count total products for pagination
        try:
            product_ids = killbill_database.get_data("products", None, ["id"])["id"].to_list()
            total_count = len(product_ids)
            pages_data = {
                "start": start,
                "end": end,
                "total": total_count
            }
        except Exception as e:
            logging.exception("Failed to fetch total product count")
            return {"flag": False, "message": "Error fetching product count", "header_map": {}, "pages": {}, "dropdown": {}}

        # Prepare dropdown values (flat list, no product_type grouping)
        try:
            product_records = killbill_database.get_data(
                table_name="products",
                condition={"is_active": True, "tenant_id": tenant_id},
                columns=["description", "id"]
            ).to_dict(orient="records")

            # Flattened list (description -- id)
            products_list = [
                f"{record.get('description', '')} -- {record.get('id', '')}"
                for record in product_records
            ]

            dropdown_vals = {"description": products_list}
        except Exception as e:
            logging.exception("Error building dropdown values")
            dropdown_vals = {"products": []}

        # Prepare response data
        header_map = get_headers_mapping(killbill_database, ["Product Packages"], role_name, '', '', '', '', data)

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "header_map": header_map,
            "pages": pages_data,
            "dropdown": dropdown_vals
        }
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        error_data = {
            "service_name": "product_package_pop_up_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during products package pop up list view",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Product Packages Pop List View",
            "data": {}
        }
        return response
def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """
    print(f"***update_data 1 {changed_data}")
    try:
        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }
            
            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            print(f"***update_data {update_data}")
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False
def extract_sort_key(item):
    # Special case for "First" (or similar unique values)
    if item.lower() == "follow bill profile":
        return (0, 0, "Follow Bill Profile")  # Place it at the beginning

    # Extract numbers and time units using regex
    match = re.match(r'(\d+)\s*(Year|Month|Years|Months)', item)
    if match:
        number = int(match.group(1))  # Extract the number
        unit = match.group(2).lower()  # Extract the unit

        # Convert Years to months for uniform comparison
        months = number * 12 if "year" in unit else number
        return (1, months, item)  # Sorting key based on months

    # Handle unexpected cases (e.g., items without numbers)
    return (2, float('inf'), item)

def update_billing_actions_data(data):
    start_time = time.time()
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    tenant_db_name = data.get('db_name', '')
    if tenant_db_name=="null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    module_name = data.get("module_name", "")
    changed_data = data.get("changed_data", {})
    active_status = changed_data.get("is_active", '')
    action = data.get("action", "")
    unique_id = changed_data.get("id", None)
    table_name = data.get("table_name", "")

    changed_data['modified_by']=username

    try:
        #if module_name == 'Billing Services':
        if module_name == 'Service Types':
            current_timestamp = datetime.now().strftime("%m-%d-%Y %H:%M:%S")
            changed_data = data.get('changed_data', {})
            
            if action == 'copy':
                # Set created_date only if present in changed_data
                if 'created_date' in changed_data:
                    changed_data['created_date'] = current_timestamp

                # Extract and reassign fields
                custom_fields = changed_data.pop('customFields', {})
                built_in_fields = changed_data.pop('builtInFields', {})

                changed_data['custom_field'] = custom_fields
                changed_data.update(built_in_fields)

                return add_service_type(data)

            elif action == 'update':
                # Extract and reassign fields
                custom_fields = changed_data.pop('customFields', {})
                built_in_fields = changed_data.pop('builtInFields', {})
                changed_data['custom_field'] = custom_fields
                changed_data.update(built_in_fields)

                # Clean empty values
                changed_data = {
                    k: str(v)
                    for k, v in changed_data.items()
                    if v not in (None, "None", "")
                }
                # Handle display_name to provider_id conversion
                display_name = changed_data.pop('display_name', '')
                # if display_name:
                #     result = tenant_database.get_data(
                #         "serviceprovider", {"display_name": display_name}, ["id"]
                #     )
                #     provider_id = result["id"].to_list()[0] if not result.empty else None
                #     changed_data['provider_id'] = provider_id
                if display_name:
                    changed_data['service_provider_name'] = display_name
                    result = tenant_database.get_data(
                        "serviceprovider", {"display_name": display_name}, ["id"]
                    )
                    if not result.empty:
                        provider_id = result["id"].to_list()[0] if not result.empty else None
                        changed_data['provider_id'] = provider_id
                    else:
                        result = killbill_database.get_data(
                        "serviceprovider", {"display_name": display_name}, ["id"]
                    )
                    if not result.empty:
                        provider_id = result["id"].to_list()[0] if not result.empty else None
                        changed_data['provider_id'] = provider_id
            elif action == 'deactivate':
                custom_fields = changed_data.pop('customFields', {})
                built_in_fields = changed_data.pop('builtInFields', {})
                changed_data['custom_field'] = custom_fields
                changed_data.update(built_in_fields)

                # Clean empty values
                changed_data = {
                    k: str(v)
                    for k, v in changed_data.items()
                    if v not in (None, "None", "")
                }
                changed_data['status'] = 'Inactive'
                changed_data.pop('display_name', None)

            elif action == 'activate':
                custom_fields = changed_data.pop('customFields', {})
                built_in_fields = changed_data.pop('builtInFields', {})
                changed_data['custom_field'] = custom_fields
                changed_data.update(built_in_fields)

                # Clean empty values
                changed_data = {
                    k: str(v)
                    for k, v in changed_data.items()
                    if v not in (None, "None", "")
                }
                changed_data['status'] = 'Active'
                changed_data.pop('display_name', None)
        
        elif module_name == 'Billing Product Types':
            current_timestamp = datetime.now().strftime("%m-%d-%Y %H:%M:%S")
            changed_data = data.get('changed_data', {})
            if action == 'copy':
                id = changed_data.pop('id', None)
                if 'created_date' in changed_data:
                    changed_data['created_date'] = current_timestamp
                    return add_product_type(data)
            elif action == 'update':
                if active_status is True:
                    changed_data['status']='Active'
                else:
                    changed_data['status']='Inactive'
                boolean_list=['is_surcharge','ps_code','tax_class','is_active']
                for item in boolean_list:
                    if changed_data.get(item)=='':
                        changed_data[item]=None
                # temporary need to change later
                remove_column=["override_ps_code","override_tax_type","override_tax_class","_doc_modified_date"]
                for item in remove_column:
                    if item in changed_data:
                        changed_data.pop(item)

                if "product_type_codes" in changed_data:
                    product_type_codes=changed_data['product_type_codes']
                    # prod_id_qry="""select id from product_type_code where product_type_codes= %s"""
                    # prod_id_df=db.execute_query(prod_id_qry, params=[product_type_codes])
                    prod_id_df=killbill_database.get_data("product_type_code",{"product_type_codes":product_type_codes},["id"])
                    try:
                        changed_data['product_type_code_id']=prod_id_df['id'].tolist()[0]
                    except:
                        pass
        
        elif module_name == 'Billing Products':
            current_timestamp = datetime.now().strftime("%m-%d-%Y %H:%M:%S")
            changed_data = data.get('changed_data', {})
            
            if action == 'copy':
                return add_product(data)

            elif action == 'update':
                # Process service_type -> map to service ID
                if "service_type" in changed_data:
                    service_type = changed_data.pop("service_type", None)
                    service_type_df = killbill_database.get_data("services", {"description": service_type}, ["id"])
                    if not service_type_df.empty:
                        changed_data["product_type_code_id"] = service_type_df["id"].to_list()[0]

                # Process service_provider -> map to provider ID
                if "service_provider" in changed_data:
                    service_provider = changed_data.pop("service_provider", None)
                    changed_data['service_provider_name'] = service_provider
                    provider_df = tenant_database.get_data("serviceprovider", {"display_name": service_provider}, ["id"])
                    if not provider_df.empty:
                        changed_data["provider_id"] = provider_df["id"].to_list()[0]
                    else:
                        provider_df = killbill_database.get_data(
                        "serviceprovider", {"display_name": display_name}, ["id"]
                        )
                    if not provider_df.empty:
                        provider_id = provider_df["id"].to_list()[0] if not provider_df.empty else None
                        changed_data['provider_id'] = provider_id

                # Process g_l_code -> map to GL code ID
                if "g_l_code" in changed_data:
                    g_l_code = changed_data.pop("g_l_code", None)
                    gl_code_df = killbill_database.get_data("gl_code", {"gl_codes": g_l_code}, ["id"])
                    if not gl_code_df.empty:
                        changed_data["gl_code_id"] = gl_code_df["id"].to_list()[0]

                # Remove irrelevant frontend field
                changed_data.pop("code", None)

                # Process product_type -> map to product_type_id
                # if "product_type" in changed_data:
                #     product_type = changed_data.pop("product_type", None)
                #     logging.info(f"***** product_type: {product_type}")
                #     product_df = killbill_database.get_data("product_types", {"description": product_type}, ["id"])
                #     if not product_df.empty:
                #         changed_data["product_type_id"] = product_df["id"].to_list()[0]

                # Normalize multi-select fields into JSON strings
                multi_select_fields = ["multi_options", "multi_provider_accounts", "multi_service_id"]
                for field in multi_select_fields:
                    if field in changed_data:
                        # Ensure it's a clean list, then convert to JSON string
                        if isinstance(changed_data[field], list):
                            cleaned_list = [str(value).replace('[', '').replace(']', '') for value in changed_data[field]]
                            changed_data[field] = json.dumps(cleaned_list)

        elif module_name == 'Billing Packages':
            current_timestamp = datetime.now().strftime("%m-%d-%Y %H:%M:%S")
            changed_data = data.get('changed_data', {})
            if action == 'copy':
                # Set created_date only if present in changed_data
                if 'created_date' in changed_data:
                    changed_data['created_date'] = current_timestamp
                return add_package(data)

            elif action == 'update':
                table_name = 'packages'
                # Extract metadata
                modified_by = data.get('modified_by', '')
                id = changed_data.pop('id', None)
                changed_data = data.get('changed_data', {})
                package_products = changed_data if changed_data else ''
                # Extract general and product data
                pop_up_data = data.get('changed_data', {})
                general_tab_data = pop_up_data.get('generalData', {})
                package_name = general_tab_data.get('category', '')
                if package_name:
                    category_df = killbill_database.get_data("packages", {"category": package_name}, ["id","category"]).to_dict(orient="records")
                    if category_df:
                        #get the id from the category_df
                        unique_id = category_df[0]["id"]
                        if unique_id != id:
                            # Category already exists — return error response
                            return {
                                "flag": False,
                                "message": "Package Name already exists",
                                "status": False
                            }
                        else:
                            # Category exists but it's the same as the current package — proceed without update
                            logging.info("Category already exists, proceeding without update.")
                    else:
                        logging.info("No category provided, proceeding without category check.")
                
                else:
                    return {
                        "flag": False,
                        "message": "Package Name cannot be empty"                    
                    }

                products_data = pop_up_data.get('productsData', {})
                list_view_data = products_data.get('UpdatedTableData', [])
                product_description = products_data.get('description', '')
                # Initialize data containers
                general_tab = {
                    'desc_on_bill': general_tab_data.get('desc_on_bill', ''),
                    'category': general_tab_data.get('category', ''),
                    'one_time': general_tab_data.get('one_time', '')
                }
                product_tab_data = {'description': product_description}

                # Resolve provider ID
                provider = general_tab_data.get('display_name')
                if provider:
                    logging.info(f"Provider: {provider}")
                    changed_data['service_provider_name'] = provider
                    provider_df = tenant_database.get_data("serviceprovider", {"display_name": provider}, ["id"])
                    if not provider_df.empty:
                        general_tab['provider_id'] = str(provider_df["id"].to_list()[0])
                    else:
                        provider_df = killbill_database.get_data(
                        "serviceprovider", {"display_name": provider}, ["id"]
                        )
                    if not provider_df.empty:
                        provider_id = provider_df["id"].to_list()[0] if not provider_df.empty else None
                        changed_data['provider_id'] = provider_id
                # Resolve service type ID
                service_type = general_tab_data.get("service_type")
                if "service_type" in general_tab_data:
                    logging.info("Processing service type...")
                    if service_type:
                        logging.info("Fetching service ID...")
                        service_df = killbill_database.get_data("services", {"description": service_type}, ["id"])
                        if not service_df.empty:
                            general_tab['service_id'] = str(service_df["id"].to_list()[0])
                            logging.info("Service ID added to general_tab")
                    else:
                        # Service type key is present but value is None — update service_id to NULL in DB
                        logging.info("Service type is empty. Updating service_id to NULL in DB.")
                        update_query = f"UPDATE packages SET service_id=NULL WHERE id=%s"
                        killbill_database.execute_query(update_query, params=[unique_id])
                else:
                    # Service type key is missing — update service_id to NULL in DB
                    logging.info("Service type key missing. Updating service_id to NULL in DB.")
                    update_query = f"UPDATE packages SET service_id=NULL WHERE id=%s"
                    killbill_database.execute_query(update_query, params=[unique_id])

                # Calculate grouped and ungrouped totals
                grouped, ungrouped = 0, 0
                try:
                    for row in list_view_data:
                        rate = float(row.get('rate', 0))
                        if row.get('group', False):
                            grouped += rate
                        if row.get('itemize', False):
                            ungrouped += rate
                except Exception as e:
                    logging.exception(f"Exception calculating grouped/ungrouped totals: {e}")
                
                # Finalize general_tab with remaining values
                try:
                    general_tab.update({
                        'modified_by': modified_by,
                        'status': 'Active',
                        'package_products': str(package_products),
                        'grouped': str(grouped),
                        'ungrouped': str(ungrouped)
                    })

                    logging.info(f"Final General Tab Data: {general_tab}")
                    logging.info(f"Updating table: {table_name}")

                    status = data_update_db(general_tab, unique_id, table_name, killbill_database)
                    logging.info(f"Update Status: {status}")
                except Exception as e:
                    logging.exception(f"Failed to update package: {e}")
                    response = {
                        "flag": False,
                        "message": "Failed to update the data"
                    }

            elif action == 'deactivate':
                changed_data['status']='Inactive'
                if "package_category" in changed_data:
                    changed_data.pop('package_category')
                if "provider" in changed_data:
                    changed_data.pop('provider')
                if "service" in changed_data:
                    changed_data.pop('service')
                changed_data={k:str(v) for k,v in changed_data.items() if v not in (None,"None","")}
            
            elif action == 'activate':
                changed_data['status']='Active'
                if "package_category" in changed_data:
                    changed_data.pop('package_category')
                if "provider" in changed_data:
                    changed_data.pop('provider')
                if "service" in changed_data:
                    changed_data.pop('service')
                changed_data={k:str(v) for k,v in changed_data.items() if v not in (None,"None","")}

        logging.info(f'changed_data-----------{changed_data}')
        status = data_update_db(changed_data, unique_id, table_name, killbill_database)
        if status:
            logging.info("Action Done successfully")
            message = f"{action.capitalize()}d Successfully"
            response_data = {"flag": True, "message": message}
            audit_message=f"{module_name} {message}"
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "update_billing_actions_data",
                "created_by":username,
                "status": str(response_data["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": audit_message,
                "module_name": module_name,
                "request_received_at": request_received_at,
                "request_data":json.dumps(changed_data),
                "response_data": json.dumps(response_data)
            }
            database.update_audit(audit_data_user_actions, "audit_user_actions")
        else:
            logging.info("Action Done successfully")
            message = f"Failed to {action.capitalize()}"
            response_data = {"flag": False, "message": message}
            error_type = str(type(e).__name__)
            error_data = {
                "service_name": "update_billing_actions_data",
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "",
                "module_name": "Billing Services",
                "request_received_at": request_received_at,

            }
            database.log_error_to_db(error_data, "error_log_table")
        return response_data
    
    except Exception as e:
        logging.info(f"An error occurred: {e}")
        message = f"Unable to save the data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_billing_actions_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "",
                "module_name": "Billing Services",
                "request_received_at": request_received_at,

            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass
        return response

def products_export(data):
    try:
        # data base connection
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)

        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_name=data.get('tenant_name', '')
        module_name = data.get('module_name', '')
        
        # Get tenant's timezone
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])
        # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")
        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly
    
        try:
            tenant_id = database.get_data(
                    "tenant", {"tenant_name": tenant_name},["id"]
                )["id"].to_list()[0]
            logging.info(f"**tenant_id {tenant_id}")
        except Exception as e:
            logging.exception(f"An error occurred: {e}")
            tenant_id = None
        
        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        # query to fetch data from products_list_view 
        if module_name == 'Billing Products':
            query = "select id as product_id, description as description ,rate as rate,service_provider as provider,g_l_code as gl_code,bundle_code,ps_code as tax_code, prorate, created_by as created_by,modified_date as modified_date, modified_by as modified_by, is_active as status from products_list_view WHERE tenant_id= %s order by convert_to(description, 'SQL_ASCII')"
        elif module_name == 'Active Billing Products':
            query = "select id as product_id, description as description ,rate as rate,service_provider as provider,g_l_code as gl_code,bundle_code, ps_code as tax_code, prorate, created_by as created_by,modified_date as modified_date, modified_by as modified_by, is_active as status from products_list_view WHERE tenant_id= %s and is_active = true order by convert_to(description, 'SQL_ASCII')"    
        try:
            df = killbill_database.execute_query(query, params=[tenant_id])
            df_dict = df.to_dict(orient="records")
            df_dict = convert_timestamp(df_dict, tenant_time_zone)
            df = pd.DataFrame(df_dict)
            df = df.fillna('')
        except Exception as e:
            logging.exception(f"An error occurred: {e}")
            df = pd.DataFrame()
        data["dfs"]={
            "Products":df
        }
        # Export the processed data to an S3 bucket and return the response
        return export_to_s3_bucket_(data)
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        error_data = {
            "service_name": "products_export",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id":  data.get("session_id"),
            "tenant_name":  data.get("tenant_name"),
            "comments": "Unhandled exception during products upload",
            "module_name": "Billing Services",
            "request_received_at":  data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Failed to export data to S3 bucket"}

def products_export_24_11_2025(data):
    try:
        # data base connection
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)

        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_name=data.get('tenant_name', '')
        module_name = data.get('module_name', '')
        
        # Get tenant's timezone
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])
        # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")
        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly
    
        try:
            tenant_id = database.get_data(
                    "tenant", {"tenant_name": tenant_name},["id"]
                )["id"].to_list()[0]
            logging.info(f"**tenant_id {tenant_id}")
        except Exception as e:
            logging.exception(f"An error occurred: {e}")
            tenant_id = None
        
        mode=os.getenv('ENV','UAT')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        # query to fetch data from products_list_view 
        if module_name == 'Billing Products':
            query = "select id as product_id, description as description ,rate as rate, product_type as type,service_provider as provider,g_l_code as gl_code,ps_code as bundle_code, prorate, created_by as created_by,modified_date as modified_date, modified_by as modified_by from products_list_view WHERE tenant_id= %s order by convert_to(description, 'SQL_ASCII')"
        elif module_name == 'Active Billing Products':
            query = "select id as product_id, description as description ,rate as rate, product_type as type,service_provider as provider,g_l_code as gl_code, ps_code as tax_code, prorate, created_by as created_by,modified_date as modified_date, modified_by as modified_by from products_list_view WHERE tenant_id= %s and is_active = true order by convert_to(description, 'SQL_ASCII')"    
        try:
            df = killbill_database.execute_query(query, params=[tenant_id])
            df_dict = df.to_dict(orient="records")
            df = pd.DataFrame(df_dict)
            df = df.fillna('')
        except Exception as e:
            logging.exception(f"An error occurred: {e}")
            df = pd.DataFrame()
        data["dfs"]={
            "Products":df
        }
        # Export the processed data to an S3 bucket and return the response
        return export_to_s3_bucket_(data)
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        error_data = {
            "service_name": "products_export",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id":  data.get("session_id"),
            "tenant_name":  data.get("tenant_name"),
            "comments": "Unhandled exception during products upload",
            "module_name": "Billing Services",
            "request_received_at":  data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Failed to export data to S3 bucket"}



def get_export_status(data):
    """
    The get_export_status function retrieves the export status of a specific module from a database.
    It queries the export_status table based on the given module name and returns the corresponding status data.
    """
    try:
        # DB Connections
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # UI Parameter's
        module_name = data.get("module_name",None)
        username=data.get("username",None)
        tenant_id=data.get("tenant_id",None)
        # Export data fetch query
        export_status_data=common_utils_database.get_data('export_status',{"module_name":module_name,"user_name":username,"tenant_id":tenant_id},None).to_dict(orient="records")
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        error_data = {
            "service_name": "get_export_status",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": f"Failed! While checking export status {module_name}",
            "module_name": module_name,
            "request_received_at": data.get("request_received_at"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "export_status_data": []}

def export_to_s3_bucket_(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    logging.info(f"###export_to_s3_bucket_ Exporting to S3 bucket... {data}")
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("username", "")
    session_id = data.get("session_id", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}
    tenant_id = data.get("tenant_id", "")


    file_name = f"exports/uat/{module_name_snake_case}/{module_name}_{tenant_id}_{user_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # Update export status to 'Waiting'
    updated_flag=db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
    )
    if not updated_flag:
        db.insert_data({"status_flag": "Waiting", "url": "","tenant_id": tenant_id,"user_name": user_name,"module_name":module_name},"export_status")


    try:
        if not data_frames :
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                if df.empty:
                    df = pd.DataFrame(columns=df.columns)

                # Format column names
                acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "SIM", "ID", "GL"}
                special_replacements = {"Att": "AT&T", "And": "and"}

                df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                    for col in df.columns
                ]
                df.columns = [
                    " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
                ]

                df.to_excel(writer, index=False, sheet_name=sheet_name)

                # Apply styles
                workbook = writer.book
                sheet = workbook[sheet_name]

                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = header_font

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )


        
        db.update_dict(
        "export_status",
        {"status_flag": "Success", "url": download_url},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name})
            
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name}
        )
        db.log_error_to_db(
            {
                "service_name": "export_to_s3_bucket_",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"Failed while exporting Excel {module_name}",
                "module_name": module_name,
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}

def download_template_reupload(data):
    """
    Generates a bulk reupload template for Customer Services with only Service ID and Rate Plan ID,
    including reference data for Rate Plans.

    Args:
        data (dict): A dictionary with the following keys:
            - 'module_name', 'table_name', 'db_name', 'flag', 'request_received_at',
              'username', 'session_id', 'Partner', 'row_data'

    Returns:
        dict: A dictionary with 'flag', and either 'blob' or 'message'
    """
    try:
        module_name = data.get("module_name", "")
        request_received_at = data.get("request_received_at", "")
        username = data.get("username", "")
        session_id = data.get("session_id", "")
        partner = data.get("Partner", "")
        tenant_database_name = data.get("db_name", "")
        tenant_id = data.get("tenant_id", "")
        if tenant_id in ['212', 212]:
            tenant_id = '1'
        if tenant_database_name == "billing_platform":
            tenant_database_name = 'altaworx_test'

        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        tenant_db = DB(tenant_database_name, **db_config)
        table_name = data.get("table_name", "")
        flag = data.get("flag", "")

        start_time = time.time()

        is_active = data.get("status","")
        if flag == "Billing Services":
            query = f"SELECT id, description, provider_id, primary_field, built_in_fields, custom_fields FROM services WHERE tenant_id = %s "
            if is_active:
                query += " AND is_active = True"
            query += " ORDER BY id DESC"
            services_df = killbill_database.execute_query(query, params=[tenant_id])
            logging.info(f'##services_query{query}')
            services_data = pd.DataFrame(services_df)

            services_data["built_in_fields"] = services_data["built_in_fields"].apply(
                lambda x: ",".join(
                    [i["field"] for i in ast.literal_eval(x) if isinstance(i, dict) and "field" in i]
                ) if isinstance(x, str)
                else (",".join([i["field"] for i in x if isinstance(i, dict) and "field" in i]) if isinstance(x, list) else "")
            )

            services_data["custom_fields"] = services_data["custom_fields"].apply(
                lambda x: ",".join(
                    [i["field"] for i in ast.literal_eval(x) if isinstance(i, dict) and "field" in i]
                ) if isinstance(x, str)
                else (",".join([i["field"] for i in x if isinstance(i, dict) and "field" in i]) if isinstance(x, list) else "")
            )
            services_data.columns = ["ID", "Description", "Provider ID", "Primary Identifier", "Built In Fields", "Custom Fields"]

            service_provider_sheet_df_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_main = capitalize_columns(service_provider_sheet_df_main)
            service_provider_sheet_df_tenant = tenant_db.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_tenant = capitalize_columns(service_provider_sheet_df_tenant)
            combined_display_names = pd.concat([
                service_provider_sheet_df_main['Display Name'],
                service_provider_sheet_df_tenant['Display Name']
            ]).drop_duplicates().reset_index(drop=True)
            service_provider_sheet_df = pd.DataFrame({"Display Name": combined_display_names})

            built_in_fields = database.get_data(
                "field_column_mapping",
                {"module_name": "Service Types Builtin Fields"},
                ["display_name"]
            )
            logging.info(f'##built_in_fields{built_in_fields}')
            built_in_fields = capitalize_columns(built_in_fields)

            result_df = pd.DataFrame(columns=["ID", "Custom Fields"])
            for _, row in services_data.iterrows():
                # Handle both list and string values
                if isinstance(row["Custom Fields"], list):
                    custom_fields_str = ",".join(row["Custom Fields"])
                elif isinstance(row["Custom Fields"], str):
                    custom_fields_str = row["Custom Fields"]
                else:
                    custom_fields_str = ""

                result_df = pd.concat(
                    [result_df, pd.DataFrame([{"ID": row["ID"], "Custom Fields": custom_fields_str}])],
                    ignore_index=True
                )

            blob_data = dataframe_to_blob_reupload_service_types(
                result_df, services_data, service_provider_sheet_df, built_in_fields
            )
            file_name = f"Edit {data.get('module_name', 'Billing Services')}"

        elif flag == "Billing Products":
            products_query = f"select id,description,product_type_code, bundle_code, ps_code as tax_code, business_type,service_provider, rate, multi_service_id, prorate, is_surcharge, is_active from products_list_view where tenant_id = %s"
            if is_active:
                products_query += " AND is_active = True"
            products_query += " ORDER BY id DESC"
            products_df = killbill_database.execute_query(products_query, params=[tenant_id])
            logging.info(f'##products_df---{products_df}')
            products_data = pd.DataFrame(products_df)
            products_data.columns = ["ID", "Description", "Product Type Code", "Bundle Code", "Tax Code", "Business Type", "Service Provider", "Rate", "Multi Service ID", "Prorate", "Is Surcharge", "Status"]

            service_provider_sheet_df_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_main = capitalize_columns(service_provider_sheet_df_main)
            service_provider_sheet_df_tenant = tenant_db.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_tenant = capitalize_columns(service_provider_sheet_df_tenant)
            combined_display_names = pd.concat([
                service_provider_sheet_df_main['Display Name'],
                service_provider_sheet_df_tenant['Display Name']
            ]).drop_duplicates().reset_index(drop=True)
            service_provider_sheet_df = pd.DataFrame({"Display Name": combined_display_names})

            # product_type_sheet_df = killbill_database.get_data(
            #     "product_type_code", {}, ["id", "product_type_codes"]
            # )
            # product_type_sheet_df = capitalize_columns(product_type_sheet_df)

            product_type_sheet_df = pd.DataFrame({
                "Product Type Codes": ["Onetime", "Recurring"]
            })
            product_type_sheet_df = capitalize_columns(product_type_sheet_df)


            #ps_code_query_list_df, bundle_code_list_df = ps_codes_list_new(data)
            #bundle_code_df = pd.DataFrame(bundle_code_list_df, columns=["Bundle Code"])
            #ps_code_df = pd.DataFrame(ps_code_query_list_df, columns=["Ps Code"])
            ps_code_query_list_df = ps_codes(data)
            ps_code_df = pd.DataFrame(ps_code_query_list_df, columns=["raw_code"])

            # Split only on the first dash
            ps_code_df[["Bundle Code", "Tax Code"]] = (
                ps_code_df["raw_code"]
                .str.split(" - ", n=1, expand=True)
            )
            ps_code_df.drop(columns=["raw_code"], inplace=True)

            # Optional: trim spaces just in case
            ps_code_df["Bundle Code"] = ps_code_df["Bundle Code"].str.strip()
            ps_code_df["Tax Code"] = ps_code_df["Tax Code"].str.strip()
            

            service_type_sheet_df = killbill_database.get_data(
                "services", {"is_active": True, "tenant_id": tenant_id}, ["id", "description"]
            )
            service_type_sheet_df = capitalize_columns(service_type_sheet_df)

            business_type = [
                "01-Retail", "10-CLEC", "11-IXC", "12-CMRS/Wireless", "13-ILEC", "14-Prepaid Wireless",
                "15-VoIP", "16-TV Provider"
            ]
            business_type_df = pd.DataFrame(business_type, columns=["Business Type"])

            result_df = pd.DataFrame(columns=["ID", "Product Type Code", "Bundle Code", "Tax Code", "Business Type", "Provider Name", "Rate", "Multi Service ID", "Prorate", "Is Surcharge", "Status"])

            sample_data = {
                "ID": [101, 102],
                "Product Type Code": ["PT001", "PT002"],
                "Bundle Code":["C0001", "C0001"],
                "Tax Code": ["62040400 - Usage-Based Charges - Nomadic VOIP Service", "62030133 - Nomadic VoIP - Vertical Features - Amount Attributable to Intrastate Revenues"],
                "Business Type": ["01-Retail", "15-VoIP"],
                "Service Provider": ["ProviderA", "ProviderB"],
                "Rate": [9.99, 19.99],
                "Multi Service ID": ["201,202", "203,204"],
                "Prorate": ["Yes", "No"],
                "Is Surcharge": ["No", "Yes"],
                "Status": ["Active", "InActive"]
            }
            sample_data_df = pd.DataFrame(sample_data)

            blob_data = dataframe_to_blob_reupload_products(
                result_df, products_data, service_type_sheet_df,
                service_provider_sheet_df, ps_code_df, business_type_df,
                sample_data_df,product_type_sheet_df
            )
            file_name = f"Edit {data.get('module_name', 'Billing Products')}"

        elif flag == "Billing Packages":
            package_query = f"""
                SELECT id, desc_on_bill, provider_id, service_id, category, package_products
                FROM packages
                WHERE tenant_id = %s 
            """
            if is_active:
                package_query += " AND is_active = True"
            package_query += " ORDER BY id DESC"
            package_df = killbill_database.execute_query(package_query, params=[tenant_id])
            logging.info(f'##package_df---{package_df}')
            package_data = pd.DataFrame(package_df)
            logging.info(f'##package_data---{package_data}')
            # Extract product_ids from JSON field "package_products"
            product_id_map = {}
            for _, row in package_data.iterrows():
                pkg_id = row["id"]
                product_ids = []
                try:
                    if row["package_products"]:
                        parsed_data = ast.literal_eval(str(row["package_products"]))
                        updated_table_data = parsed_data.get("productsData", {}).get("UpdatedTableData", [])
                        if isinstance(updated_table_data, list):
                            for prod in updated_table_data:
                                prod_id = prod.get("id")
                                if prod_id:
                                    product_ids.append(str(prod_id))
                except Exception as e:
                    logging.warning(f"## Error parsing package_products for package_id={pkg_id}: {e}")
                product_id_map[pkg_id] = product_ids
            # Build final dataframe for template with required 6 columns
            package_data_final = pd.DataFrame({
                "ID": package_data["id"],
                "Description On Bill": package_data["desc_on_bill"],
                # "Product Type": '',
                "Service Id": package_data["service_id"],
                "Package Name": package_data["category"],  # <-- rename Category -> Package Name
                "Service Provider Name": package_data["provider_id"], 
                "Product Id": package_data["id"].map(
                    lambda pkg_id: ", ".join(product_id_map.get(pkg_id, []))
                )
            })
            
            # Create empty template structure (headers only, no data)
            result_df = pd.DataFrame(columns=package_data_final.columns)

            # Lookup sheets for dropdowns
            service_type_sheet_df = killbill_database.get_data(
                "services", {"is_active": True, "tenant_id": tenant_id},
                ["id", "description"]
            )
            service_type_sheet_df = capitalize_columns(service_type_sheet_df)

            service_provider_sheet_df_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_main = capitalize_columns(service_provider_sheet_df_main)
            service_provider_sheet_df_tenant = tenant_db.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_tenant = capitalize_columns(service_provider_sheet_df_tenant)
            combined_display_names = pd.concat([
                service_provider_sheet_df_main['Display Name'],
                service_provider_sheet_df_tenant['Display Name']
            ]).drop_duplicates().reset_index(drop=True)
            service_provider_sheet_df = pd.DataFrame({"Display Name": combined_display_names})

            # product_type_sheet_df = killbill_database.get_data(
            #     "product_types", {"is_active": True, "tenant_id": tenant_id},
            #     ["id", "description"]
            # )
            # product_type_sheet_df = capitalize_columns(product_type_sheet_df)

            products_sheet_df = killbill_database.get_data(
                "products", {"is_active": True, "tenant_id": tenant_id},
                ["id", "description"]
            )
            products_sheet_df = capitalize_columns(products_sheet_df)

            blob_data = dataframe_to_blob_bulk_upload_packages(
                result_df,
                package_data_final,
                service_type_sheet_df,
                service_provider_sheet_df,
                # product_type_sheet_df,
                products_sheet_df
            )
            file_name = f"Edit {data.get('module_name', 'Billing Packages')}"
       
        elif flag == "Billing Packages Backup":
            # Billing Packages addition requested:
            package_query = f"""
                SELECT id, desc_on_bill, grouped, ungrouped, one_time,
                    provider_id, product_type_id, service_id,
                    category, package_products
                FROM packages
                WHERE tenant_id = %s
            """
            if is_active:
                package_query += " AND is_active = True"
            package_query += " ORDER BY id DESC"

            package_df = killbill_database.execute_query(package_query, params=[tenant_id])
            package_data = pd.DataFrame(package_df)

            product_id_map = {}
            for _, row in package_data.iterrows():
                pkg_id = row["id"]
                product_ids = []
                try:
                    if row["package_products"]:
                        parsed_data = ast.literal_eval(str(row["package_products"]))
                        logging.info(f"## parsed_data for package_id={pkg_id} -> {parsed_data}")
                        updated_table_data = parsed_data.get("productsData", {}).get("UpdatedTableData", [])
                        logging.info(f"## updated_table_data for package_id={pkg_id} -> {updated_table_data}")
                        if isinstance(updated_table_data, list):
                            for prod in updated_table_data:
                                prod_id = prod.get("id")
                                logging.info(f"## Found prod_id for package_id={pkg_id} -> {prod_id}")
                                if prod_id:
                                    product_ids.append(str(prod_id))
                except Exception as e:
                    logging.warning(f"## Error parsing package_products for package_id={pkg_id}: {e}")

                product_id_map[pkg_id] = product_ids

            package_data = package_data.drop(columns=["package_products"])
            package_data.columns = ["ID", "Description On Bill","Service Provider Name", "Product Type Id", "Service Id","Category"]
            package_data["Product Id"] = package_data["ID"].map(product_id_map)

            logging.info(f"## Final package_data for Excel:\n{package_data}")

            result_df = pd.DataFrame(columns=package_data.columns)

            service_type_sheet_df = killbill_database.get_data(
                "services", {"is_active": True, "tenant_id": tenant_id},
                ["id", "device_description"]
            )
            service_type_sheet_df = capitalize_columns(service_type_sheet_df)

            service_provider_sheet_df_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_main = capitalize_columns(service_provider_sheet_df_main)
            service_provider_sheet_df_tenant = tenant_db.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_tenant = capitalize_columns(service_provider_sheet_df_tenant)
            combined_display_names = pd.concat([
                service_provider_sheet_df_main['Display Name'],
                service_provider_sheet_df_tenant['Display Name']
            ]).drop_duplicates().reset_index(drop=True)
            service_provider_sheet_df = pd.DataFrame({"Display Name": combined_display_names})

            product_type_sheet_df = killbill_database.get_data(
                "product_types", {"is_active": True, "tenant_id": tenant_id},
                ["id", "description"]
            )
            product_type_sheet_df = capitalize_columns(product_type_sheet_df)

            products_sheet_df = killbill_database.get_data(
                "products", {"is_active": True, "tenant_id": tenant_id},
                ["id", "description", "product_type_id"]
            )
            products_sheet_df = capitalize_columns(products_sheet_df)

            blob_data = dataframe_to_blob_bulk_upload_packages(
                result_df,
                service_type_sheet_df,
                service_provider_sheet_df,
                product_type_sheet_df,
                products_sheet_df
            )

        else:
            response = {"flag": False, "message": "Invalid flag value provided"}
            return response

        response = {"flag": True, "blob": blob_data.decode("utf-8"), "file_name": file_name}
        time_consumed = int(time.time() - start_time)
        logging.info(
            f"before download template"
        )
        audit_data = {
            "service_name": "download_template_reupload",
            "created_by": username,
            "status": "True",
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": partner,
            "comments": json.dumps({"message": "Template Downloaded successfully"}),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        database.update_audit(audit_data, "audit_user_actions")
        logging.info(
            f"after download template"
        )

        return response

    except Exception as e:
        logging.exception("Exception occurred in download_template_reupload")

        response = {"flag": False, "message": "Failed to download the Template"}
        error_data = {
            "service_name": "download_template_reupload",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": data.get("module_name", ""),
            "request_received_at": data.get("request_received_at", ""),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def download_template_reupload_22_12_2025(data):
    """
    Generates a bulk reupload template for Customer Services with only Service ID and Rate Plan ID,
    including reference data for Rate Plans.

    Args:
        data (dict): A dictionary with the following keys:
            - 'module_name', 'table_name', 'db_name', 'flag', 'request_received_at',
              'username', 'session_id', 'Partner', 'row_data'

    Returns:
        dict: A dictionary with 'flag', and either 'blob' or 'message'
    """
    try:
        module_name = data.get("module_name", "")
        request_received_at = data.get("request_received_at", "")
        username = data.get("username", "")
        session_id = data.get("session_id", "")
        partner = data.get("Partner", "")
        tenant_database_name = data.get("db_name", "")
        tenant_id = data.get("tenant_id", "")
        if tenant_id in ['212', 212]:
            tenant_id = '1'
        if tenant_database_name == "billing_platform":
            tenant_database_name = 'altaworx_test'

        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        tenant_db = DB(tenant_database_name, **db_config)
        table_name = data.get("table_name", "")
        flag = data.get("flag", "")

        start_time = time.time()

        if flag == "Billing Services":
            services_query = killbill_database.get_data(
                table_name,
                {"tenant_id": tenant_id},
                ["id", "description", "provider_id", "primary_field", "built_in_fields", "custom_fields"],
                {"description": "asc"}
            )
            logging.info(f'##services_query{services_query}')
            services_data = pd.DataFrame(services_query)

            services_data["built_in_fields"] = services_data["built_in_fields"].apply(
                lambda x: ",".join(
                    [i["field"] for i in ast.literal_eval(x) if isinstance(i, dict) and "field" in i]
                ) if isinstance(x, str)
                else (",".join([i["field"] for i in x if isinstance(i, dict) and "field" in i]) if isinstance(x, list) else "")
            )

            services_data["custom_fields"] = services_data["custom_fields"].apply(
                lambda x: ",".join(
                    [i["field"] for i in ast.literal_eval(x) if isinstance(i, dict) and "field" in i]
                ) if isinstance(x, str)
                else (",".join([i["field"] for i in x if isinstance(i, dict) and "field" in i]) if isinstance(x, list) else "")
            )
            services_data.columns = ["ID", "Description", "Provider ID", "Primary Identifier", "Built In Fields", "Custom Fields"]

            service_provider_sheet_df_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_main = capitalize_columns(service_provider_sheet_df_main)
            service_provider_sheet_df_tenant = tenant_db.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_tenant = capitalize_columns(service_provider_sheet_df_tenant)
            combined_display_names = pd.concat([
                service_provider_sheet_df_main['Display Name'],
                service_provider_sheet_df_tenant['Display Name']
            ]).drop_duplicates().reset_index(drop=True)
            service_provider_sheet_df = pd.DataFrame({"Display Name": combined_display_names})

            built_in_fields = database.get_data(
                "field_column_mapping",
                {"module_name": "Service Types Builtin Fields"},
                ["display_name"]
            )
            logging.info(f'##built_in_fields{built_in_fields}')
            built_in_fields = capitalize_columns(built_in_fields)

            result_df = pd.DataFrame(columns=["ID", "Custom Fields"])
            for _, row in services_data.iterrows():
                # Handle both list and string values
                if isinstance(row["Custom Fields"], list):
                    custom_fields_str = ",".join(row["Custom Fields"])
                elif isinstance(row["Custom Fields"], str):
                    custom_fields_str = row["Custom Fields"]
                else:
                    custom_fields_str = ""

                result_df = pd.concat(
                    [result_df, pd.DataFrame([{"ID": row["ID"], "Custom Fields": custom_fields_str}])],
                    ignore_index=True
                )

            blob_data = dataframe_to_blob_reupload_service_types(
                result_df, services_data, service_provider_sheet_df, built_in_fields
            )
            file_name = f"Edit {data.get('module_name', 'Billing Services')}"

        elif flag == "Billing Products":
            products_query = f"select id,description,product_type_code, ps_code, business_type,service_provider, rate, multi_service_id, prorate, is_surcharge, is_active from products_list_view where tenant_id = %s and is_active = True"
            products_df = killbill_database.execute_query(products_query, params=[tenant_id])
            logging.info(f'##products_df---{products_df}')
            products_data = pd.DataFrame(products_df)
            products_data.columns = ["ID", "Description", "Product Type Code", "Ps Code", "Business Type", "Service Provider", "Rate", "Multi Service ID", "Prorate", "Is Surcharge", "Status"]

            service_provider_sheet_df_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_main = capitalize_columns(service_provider_sheet_df_main)
            service_provider_sheet_df_tenant = tenant_db.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_tenant = capitalize_columns(service_provider_sheet_df_tenant)
            combined_display_names = pd.concat([
                service_provider_sheet_df_main['Display Name'],
                service_provider_sheet_df_tenant['Display Name']
            ]).drop_duplicates().reset_index(drop=True)
            service_provider_sheet_df = pd.DataFrame({"Display Name": combined_display_names})

            # product_type_sheet_df = killbill_database.get_data(
            #     "product_type_code", {}, ["id", "product_type_codes"]
            # )
            # product_type_sheet_df = capitalize_columns(product_type_sheet_df)

            product_type_sheet_df = pd.DataFrame({
                "Product Type Codes": ["Onetime", "Recurring"]
            })
            product_type_sheet_df = capitalize_columns(product_type_sheet_df)

            ps_code_query_list_df = ps_codes_list_new(data)
            logging.info(f'##ps_code_query_list_df{ps_code_query_list_df}')
            ps_code_df = pd.DataFrame(ps_code_query_list_df, columns=["Ps Code"])

            service_type_sheet_df = killbill_database.get_data(
                "services", {"is_active": True, "tenant_id": tenant_id}, ["id", "description"]
            )
            service_type_sheet_df = capitalize_columns(service_type_sheet_df)

            business_type = [
                "01-Retail", "10-CLEC", "11-IXC", "12-CMRS/Wireless", "13-ILEC", "14-Prepaid Wireless",
                "15-VoIP", "16-TV Provider"
            ]
            business_type_df = pd.DataFrame(business_type, columns=["Business Type"])

            result_df = pd.DataFrame(columns=["ID", "Product Type Code", "Ps Code", "Business Type", "Provider Name", "Rate", "Multi Service ID", "Prorate", "Is Surcharge", "Status"])

            sample_data = {
                "ID": [101, 102],
                "Product Type Code": ["PT001", "PT002"],
                "Ps Code": ["PSA", "PSB"],
                "Business Type": ["01-Retail", "15-VoIP"],
                "Service Provider": ["ProviderA", "ProviderB"],
                "Rate": [9.99, 19.99],
                "Multi Service ID": ["201,202", "203,204"],
                "Prorate": ["Yes", "No"],
                "Is Surcharge": ["No", "Yes"],
                "Status": ["Active", "InActive"]
            }
            sample_data_df = pd.DataFrame(sample_data)

            blob_data = dataframe_to_blob_reupload_products(
                result_df, products_data, service_type_sheet_df,
                service_provider_sheet_df, ps_code_df, business_type_df,
                sample_data_df,product_type_sheet_df
            )
            file_name = f"Edit {data.get('module_name', 'Billing Products')}"

        elif flag == "Billing Packages":
            package_query = f"""
                SELECT id, desc_on_bill, provider_id, product_type_id, service_id, category, package_products
                FROM packages
                WHERE tenant_id = %s AND is_active = True
                ORDER BY id DESC
            """
            package_df = killbill_database.execute_query(package_query, params=[tenant_id])
            logging.info(f'##package_df---{package_df}')
            package_data = pd.DataFrame(package_df)
            logging.info(f'##package_data---{package_data}')
            # Extract product_ids from JSON field "package_products"
            product_id_map = {}
            for _, row in package_data.iterrows():
                pkg_id = row["id"]
                product_ids = []
                try:
                    if row["package_products"]:
                        parsed_data = ast.literal_eval(str(row["package_products"]))
                        updated_table_data = parsed_data.get("productsData", {}).get("UpdatedTableData", [])
                        if isinstance(updated_table_data, list):
                            for prod in updated_table_data:
                                prod_id = prod.get("id")
                                if prod_id:
                                    product_ids.append(str(prod_id))
                except Exception as e:
                    logging.warning(f"## Error parsing package_products for package_id={pkg_id}: {e}")
                product_id_map[pkg_id] = product_ids
            # Build final dataframe for template with required 6 columns
            package_data_final = pd.DataFrame({
                "ID": package_data["id"],
                "Description On Bill": package_data["desc_on_bill"],
                "Product Type": '',
                "Service Id": package_data["service_id"],
                "Package Name": package_data["category"],  # <-- rename Category -> Package Name
                "Service Provider Name": package_data["provider_id"], 
                "Product Id": package_data["id"].map(
                    lambda pkg_id: ", ".join(product_id_map.get(pkg_id, []))
                )
            })
            
            # Create empty template structure (headers only, no data)
            result_df = pd.DataFrame(columns=package_data_final.columns)

            # Lookup sheets for dropdowns
            service_type_sheet_df = killbill_database.get_data(
                "services", {"is_active": True, "tenant_id": tenant_id},
                ["id", "description"]
            )
            service_type_sheet_df = capitalize_columns(service_type_sheet_df)

            service_provider_sheet_df_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_main = capitalize_columns(service_provider_sheet_df_main)
            service_provider_sheet_df_tenant = tenant_db.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_tenant = capitalize_columns(service_provider_sheet_df_tenant)
            combined_display_names = pd.concat([
                service_provider_sheet_df_main['Display Name'],
                service_provider_sheet_df_tenant['Display Name']
            ]).drop_duplicates().reset_index(drop=True)
            service_provider_sheet_df = pd.DataFrame({"Display Name": combined_display_names})

            # product_type_sheet_df = killbill_database.get_data(
            #     "product_types", {"is_active": True, "tenant_id": tenant_id},
            #     ["id", "description"]
            # )
            # product_type_sheet_df = capitalize_columns(product_type_sheet_df)

            products_sheet_df = killbill_database.get_data(
                "products", {"is_active": True, "tenant_id": tenant_id},
                ["id", "description", "product_type_id"]
            )
            products_sheet_df = capitalize_columns(products_sheet_df)

            blob_data = dataframe_to_blob_bulk_upload_packages(
                result_df,
                package_data_final,
                service_type_sheet_df,
                service_provider_sheet_df,
                # product_type_sheet_df,
                products_sheet_df
            )
            file_name = f"Edit {data.get('module_name', 'Billing Packages')}"
       
        elif flag == "Billing Packages Backup":
            # Billing Packages addition requested:
            package_query = f"""
                SELECT id, desc_on_bill, grouped, ungrouped, one_time,
                    provider_id, product_type_id, service_id,
                    category, package_products
                FROM packages
                WHERE tenant_id = %s AND is_active = True
                ORDER BY id DESC
            """
            package_df = killbill_database.execute_query(package_query, params=[tenant_id])
            package_data = pd.DataFrame(package_df)

            product_id_map = {}
            for _, row in package_data.iterrows():
                pkg_id = row["id"]
                product_ids = []
                try:
                    if row["package_products"]:
                        parsed_data = ast.literal_eval(str(row["package_products"]))
                        logging.info(f"## parsed_data for package_id={pkg_id} -> {parsed_data}")
                        updated_table_data = parsed_data.get("productsData", {}).get("UpdatedTableData", [])
                        logging.info(f"## updated_table_data for package_id={pkg_id} -> {updated_table_data}")
                        if isinstance(updated_table_data, list):
                            for prod in updated_table_data:
                                prod_id = prod.get("id")
                                logging.info(f"## Found prod_id for package_id={pkg_id} -> {prod_id}")
                                if prod_id:
                                    product_ids.append(str(prod_id))
                except Exception as e:
                    logging.warning(f"## Error parsing package_products for package_id={pkg_id}: {e}")

                product_id_map[pkg_id] = product_ids

            package_data = package_data.drop(columns=["package_products"])
            package_data.columns = ["ID", "Description On Bill","Service Provider Name", "Product Type Id", "Service Id","Category"]
            package_data["Product Id"] = package_data["ID"].map(product_id_map)

            logging.info(f"## Final package_data for Excel:\n{package_data}")

            result_df = pd.DataFrame(columns=package_data.columns)

            service_type_sheet_df = killbill_database.get_data(
                "services", {"is_active": True, "tenant_id": tenant_id},
                ["id", "device_description"]
            )
            service_type_sheet_df = capitalize_columns(service_type_sheet_df)

            service_provider_sheet_df_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_main = capitalize_columns(service_provider_sheet_df_main)
            service_provider_sheet_df_tenant = tenant_db.get_data("serviceprovider", None, ["id", "display_name"])
            service_provider_sheet_df_tenant = capitalize_columns(service_provider_sheet_df_tenant)
            combined_display_names = pd.concat([
                service_provider_sheet_df_main['Display Name'],
                service_provider_sheet_df_tenant['Display Name']
            ]).drop_duplicates().reset_index(drop=True)
            service_provider_sheet_df = pd.DataFrame({"Display Name": combined_display_names})

            product_type_sheet_df = killbill_database.get_data(
                "product_types", {"is_active": True, "tenant_id": tenant_id},
                ["id", "description"]
            )
            product_type_sheet_df = capitalize_columns(product_type_sheet_df)

            products_sheet_df = killbill_database.get_data(
                "products", {"is_active": True, "tenant_id": tenant_id},
                ["id", "description", "product_type_id"]
            )
            products_sheet_df = capitalize_columns(products_sheet_df)

            blob_data = dataframe_to_blob_bulk_upload_packages(
                result_df,
                service_type_sheet_df,
                service_provider_sheet_df,
                product_type_sheet_df,
                products_sheet_df
            )

        else:
            response = {"flag": False, "message": "Invalid flag value provided"}
            return response

        response = {"flag": True, "blob": blob_data.decode("utf-8"), "file_name": file_name}
        time_consumed = int(time.time() - start_time)
        logging.info(
            f"before download template"
        )
        audit_data = {
            "service_name": "download_template_reupload",
            "created_by": username,
            "status": "True",
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": partner,
            "comments": json.dumps({"message": "Template Downloaded successfully"}),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        database.update_audit(audit_data, "audit_user_actions")
        logging.info(
            f"after download template"
        )

        return response

    except Exception as e:
        logging.exception("Exception occurred in download_template_reupload")

        response = {"flag": False, "message": "Failed to download the Template"}
        error_data = {
            "service_name": "download_template_reupload",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": data.get("module_name", ""),
            "request_received_at": data.get("request_received_at", ""),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def dataframe_to_blob_reupload_service_types(
    data_frame,service_type_sheet_df=None,service_provider_sheet_df=None, built_in_fields = None
):
    """
    Description: The Function is used to convert the dataframe to blob
    """
    # Create a BytesIO buffer
    def style_and_adjust_columns(sheet):
        """
        Apply header styles and adjust column widths for the given sheet.
        """
        # Apply header styles
        for cell in sheet[1]:
            cell.alignment = Alignment(horizontal="center", vertical="center")  # Center align
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")  # Grey background

        # Adjust column widths based on content
        for col_idx, col_cells in enumerate(sheet.columns, 1):
            max_length = max(len(str(cell.value or "")) for cell in col_cells)
            sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

    # Create a BytesIO buffer
    excel_buffer = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
        # Write main data frame to the first sheet
        data_frame.to_excel(writer, index=False, sheet_name="Template")

        # Apply styles to the Template sheet
        workbook = writer.book
        sheet = workbook["Template"]
        style_and_adjust_columns(sheet)

        # Write tenant sheet if data exists and apply styles
        if service_type_sheet_df is not None and not service_type_sheet_df.empty:
            service_type_sheet_df.to_excel(writer, sheet_name="Service Types", index=False)
            sheet = workbook["Service Types"]
            style_and_adjust_columns(sheet)

        if service_provider_sheet_df is not None and not service_provider_sheet_df.empty:
            service_provider_sheet_df.to_excel(writer, sheet_name="Service Provider", index=False)
            sheet = workbook["Service Provider"]
            style_and_adjust_columns(sheet)

        if built_in_fields is not None and not built_in_fields.empty:
            built_in_fields.to_excel(writer, sheet_name="Built In Fields", index=False)
            sheet = workbook["Built In Fields"]
            style_and_adjust_columns(sheet)

    # Convert Excel data to base64 blob
    excel_buffer.seek(0)
    blob_data = base64.b64encode(excel_buffer.read())
    return blob_data

def dataframe_to_blob_reupload_products(
    data_frame,products_data,service_type_sheet_df=None,service_provider_sheet_df=None,ps_code_df = None, business_type_df = None,sample_data_df = None, product_type_sheet_df = None
):
    """
    Description: The Function is used to convert the dataframe to blob
    """
    # Create a BytesIO buffer
    def style_and_adjust_columns(sheet):
        """
        Apply header styles and adjust column widths for the given sheet.
        """
        # Apply header styles
        for cell in sheet[1]:
            cell.alignment = Alignment(horizontal="center", vertical="center")  # Center align
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")  # Grey background

        # Adjust column widths based on content
        for col_idx, col_cells in enumerate(sheet.columns, 1):
            max_length = max(len(str(cell.value or "")) for cell in col_cells)
            sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

    # Create a BytesIO buffer
    excel_buffer = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
        # Write main data frame to the first sheet
        data_frame.to_excel(writer, index=False, sheet_name="Template")

        # Apply styles to the Template sheet
        workbook = writer.book
        sheet = workbook["Template"]
        style_and_adjust_columns(sheet)

        # Write tenant sheet if data exists and apply styles
        if products_data is not None and not products_data.empty:
            products_data.to_excel(writer, sheet_name="Products", index=False)
            sheet = workbook["Products"]
            style_and_adjust_columns(sheet)

        if service_type_sheet_df is not None and not service_type_sheet_df.empty:
            service_type_sheet_df.to_excel(writer, sheet_name="Service Types", index=False)
            sheet = workbook["Service Types"]
            style_and_adjust_columns(sheet)

        if service_provider_sheet_df is not None and not service_provider_sheet_df.empty:
            service_provider_sheet_df.to_excel(writer, sheet_name="Service Provider", index=False)
            sheet = workbook["Service Provider"]
            style_and_adjust_columns(sheet)

        if ps_code_df is not None and not ps_code_df.empty:
            ps_code_df.to_excel(writer, sheet_name="Tax Codes", index=False)
            sheet = workbook["Tax Codes"]
            style_and_adjust_columns(sheet)

        if business_type_df is not None and not business_type_df.empty:
            business_type_df.to_excel(writer, sheet_name="Business Type", index=False)
            sheet = workbook["Business Type"]
            style_and_adjust_columns(sheet)
        if sample_data_df is not None and not sample_data_df.empty:
            sample_data_df.to_excel(writer, sheet_name="Sample Data", index=False)
            sheet = workbook["Sample Data"]
            style_and_adjust_columns(sheet)
        if product_type_sheet_df is not None and not product_type_sheet_df.empty:
            product_type_sheet_df.to_excel(writer, sheet_name="Product Type Codes", index=False)
            sheet = workbook["Product Type Codes"]
            style_and_adjust_columns(sheet)

    # Convert Excel data to base64 blob
    excel_buffer.seek(0)
    blob_data = base64.b64encode(excel_buffer.read())
    return blob_data


def dataframe_to_blob_reupload_products_20_08_2025(
    data_frame,products_data,service_type_sheet_df=None,service_provider_sheet_df=None,ps_code_df = None, business_type_df = None
):
    """
    Description: The Function is used to convert the dataframe to blob
    """
    # Create a BytesIO buffer
    def style_and_adjust_columns(sheet):
        """
        Apply header styles and adjust column widths for the given sheet.
        """
        # Apply header styles
        for cell in sheet[1]:
            cell.alignment = Alignment(horizontal="center", vertical="center")  # Center align
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")  # Grey background

        # Adjust column widths based on content
        for col_idx, col_cells in enumerate(sheet.columns, 1):
            max_length = max(len(str(cell.value or "")) for cell in col_cells)
            sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

    # Create a BytesIO buffer
    excel_buffer = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
        # Write main data frame to the first sheet
        data_frame.to_excel(writer, index=False, sheet_name="Template")

        # Apply styles to the Template sheet
        workbook = writer.book
        sheet = workbook["Template"]
        style_and_adjust_columns(sheet)

        # Write tenant sheet if data exists and apply styles
        if products_data is not None and not products_data.empty:
            products_data.to_excel(writer, sheet_name="Products", index=False)
            sheet = workbook["Products"]
            style_and_adjust_columns(sheet)

        if service_type_sheet_df is not None and not service_type_sheet_df.empty:
            service_type_sheet_df.to_excel(writer, sheet_name="Service Types", index=False)
            sheet = workbook["Service Types"]
            style_and_adjust_columns(sheet)

        if service_provider_sheet_df is not None and not service_provider_sheet_df.empty:
            service_provider_sheet_df.to_excel(writer, sheet_name="Service Provider", index=False)
            sheet = workbook["Service Provider"]
            style_and_adjust_columns(sheet)

        if ps_code_df is not None and not ps_code_df.empty:
            ps_code_df.to_excel(writer, sheet_name="PS Code", index=False)
            sheet = workbook["PS Code"]
            style_and_adjust_columns(sheet)

        if business_type_df is not None and not business_type_df.empty:
            business_type_df.to_excel(writer, sheet_name="Business Type", index=False)
            sheet = workbook["Business Type"]
            style_and_adjust_columns(sheet)
    # Convert Excel data to base64 blob
    excel_buffer.seek(0)
    blob_data = base64.b64encode(excel_buffer.read())
    return blob_data

def download_template_for_service_types(data):
    """
    Generates a multi-sheet Excel template for service types and returns it
    as a blob string along with a status response.
    """
    start_time = time.time()
    logging.info(f"### download_template_for_service_types called with data {data}")

    try:
        # --- Get tenant DB name ---
        tenant_db_name = data.get("db_name")
        if not tenant_db_name:
            return {"flag": False, "message": "Tenant DB name not provided"}

        # --- DB connections ---
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)


        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        tenant_database = DB(tenant_db_name, **db_config)

        # --- 1. Main sheet ---
        main_df = pd.DataFrame(columns=["Service Type", "Provider Name", "Service Location", "Primary Identifier", "Built In Fields", "Custom Fields"])

        # --- 2. Service Providers from Killbill DB ---
        sp_killbill_df = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
        sp_killbill_df.columns = ["Id", "Display Name"]  # rename
        if not sp_killbill_df.empty:
            sp_killbill_df["Platform"] = "Billing"

        # --- 3. Service Providers from Tenant DB ---
        sp_tenant_df = tenant_database.get_data("serviceprovider", None, ["id", "display_name"])
        sp_tenant_df.columns = ["Id", "Display Name"]
        if not sp_tenant_df.empty:
            sp_tenant_df["Platform"] = "AMOP"

        # --- 4. Combine Service Providers ---
        combined_service_provider_df = pd.concat([sp_killbill_df, sp_tenant_df], ignore_index=True)
        if not combined_service_provider_df.empty:
            combined_service_provider_df.drop_duplicates(subset=["Display Name", "Platform"], inplace=True)
            combined_service_provider_df.sort_values(by=["Display Name", "Platform"], inplace=True)

        # --- 5. Product type sheet ---
        # product_type_sheet_df = killbill_database.get_data("product_type_code", {}, ["id", "product_type_codes"])
        # product_type_sheet_df.columns = ["Id", "Product Type Codes"]
        # --- 6. Primary Field sheet ---
        primary_field_df = pd.DataFrame({"Primary Identifier": ["ICCID", "IMEI", "MSISDN", "EID","Custom"]})

        # --- 7. Built In Fields sheet ---
        built_in_fields_df = pd.DataFrame({
            "Built In Fields": [
                "Customer Cycle Usage", "Customer Rate Plan", "Date Activated", "EID",
                "ICCID", "IMEI", "Modified Date", "MSISDN",
                "Service Provider Name", "SIM Status", "Username"
            ]
        })

        # --- 8. Service Locations sheet ---
        service_locations_query = killbill_database.get_data("service_locations", columns=["states"])
        service_location_list = sorted(list(set(service_locations_query["states"].tolist())))
        service_locations_df = pd.DataFrame({"States": service_location_list})

        # --- 9. Sample Data sheet ---
        sample_data_df = pd.DataFrame({
            "Service Type": ["Mobile", "Internet"],
            "Provider Name": ["Provider A", "Provider B"],
            "Service Location": ["California", "Texas"],
            "Primary Identifier": ["IMEI", "MSISDN"],
            "Built In Fields": ["Customer Cycle Usage, Customer Rate Plan", "Date Activated, EID"],
            "Custom Fields": ["Custom1, Custom2", "Custom3, Custom4"]
        })

        # --- Helper: format sheet headers & widths ---
        def style_and_adjust_columns(sheet):
            from openpyxl.styles import Alignment, PatternFill
            from openpyxl.utils import get_column_letter

            for cell in sheet[1]:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")

            for col_idx, col_cells in enumerate(sheet.columns, 1):
                max_length = max(len(str(cell.value or "")) for cell in col_cells)
                sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        # --- Create Excel file in memory ---
        output = BytesIO()
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            main_df.to_excel(writer, sheet_name="Main Sheet", index=False)
            combined_service_provider_df.to_excel(writer, sheet_name="Service Provider Sheet", index=False)
            # product_type_sheet_df.to_excel(writer, sheet_name="Product Types", index=False)
            primary_field_df.to_excel(writer, sheet_name="Primary Identifier", index=False)
            built_in_fields_df.to_excel(writer, sheet_name="Built In Fields", index=False)
            service_locations_df.to_excel(writer, sheet_name="Service Locations", index=False)
            sample_data_df.to_excel(writer, sheet_name="Sample Data", index=False)

            workbook = writer.book
            for sheet_name in workbook.sheetnames:
                style_and_adjust_columns(workbook[sheet_name])

        # --- Encode to base64 ---
        output.seek(0)
        blob_data = base64.b64encode(output.read()).decode("utf-8")
        file_name = f"Upload {data.get('module_name', 'Billing Services')}"
        # --- Audit log ---
        try:
            time_consumed = round(time.time() - start_time, 2)
            audit_data = {
                "service_name": "download_template_for_service_types",
                "created_by": data.get("username", ""),
                "status": "True",
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "Downloaded excel for service type template",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", ""),
            }
            database.update_audit(audit_data, "audit_user_actions")
        except Exception as log_err:
            logging.exception(f"Audit logging failed: {log_err}")

        return {"flag": True, "blob": blob_data, "file_name":file_name}

    except Exception as e:
        logging.exception(f"Exception while generating template: {e}")
        try:
            database.log_error_to_db({
                "service_name": "download_template_for_service_types",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "Error Downloading excel for service type template",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", ""),
            }, "error_log_table")
        except Exception as db_err:
            logging.exception(f"Error logging failed: {db_err}")

        return {"flag": False, "message": f"Failed to generate template: {e}"}



def bulk_upload_service_types(data):
    """
    Processes a bulk upload of Service Types from an Excel file blob.

    Debug version with detailed logging.
    """

    start_time = time.time()
    logging.info(f"### bulk_upload_service_types called with data keys: {list(data.keys())}")

    REQUIRED_COLUMNS = [
        "Service Type", "Provider Name", "Service Location", "Primary Identifier", "Built In Fields", "Custom Fields"
    ]

    BUILT_IN_MAP = {
        "Modified Date": "modified_date",
        "Date Activated": "date_activated",
        "Customer Rate Plan": "customer_rate_plan_name",
        "SIM Status": "sim_status",
        "Customer Cycle Usage": "customer_cycle_usage_mb",
        "Username": "created_by",
        "IMEI": "imei",
        "EID": "eid",
        "MSISDN": "msisdn",
        "Service Provider Name": "service_provider_name",
        "ICCID": "iccid"
    }

    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    # Initialize DB connections
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

    try:
        # --- decode Excel ---
        file_blob = data.get("file_blob") or data.get("blob") or ""
        if not file_blob:
            logging.error("### No file blob provided")
            return {"flag": False, "message": "No file blob provided"}

        if "," in file_blob:
            file_blob = file_blob.split(",", 1)[1]
        file_blob += "=" * (-len(file_blob) % 4)
        file_stream = BytesIO(base64.b64decode(file_blob))

        logging.info("### File blob successfully decoded into BytesIO stream")

        # Read all sheets
        excel_sheets = pd.read_excel(file_stream, sheet_name=None, engine="openpyxl")
        sheet_names = list(excel_sheets.keys())
        logging.info(f"### Excel sheets found: {sheet_names}")

        # Debug sheet name comparison
        logging.info(f"### Checking for required sheets: 'Main Sheet' and 'Service Provider Sheet'")
        has_main = "Main Sheet" in excel_sheets
        has_provider = "Service Provider Sheet" in excel_sheets
        logging.info(f"### Has Main Sheet? {has_main}")
        logging.info(f"### Has Service Provider Sheet? {has_provider}")

        if not has_main or not has_provider:
            logging.error(f"### Missing required sheets. Found: {sheet_names}")
            return {"flag": False, "message": "Template must have 'Main Sheet' and 'Service Provider Sheet'"}

        df = excel_sheets["Main Sheet"]
        providers_df = excel_sheets["Service Provider Sheet"]
        total_rows = len(df)

        logging.info(f"### Main Sheet shape: {df.shape}")
        logging.info(f"### Provider Sheet shape: {providers_df.shape}")

        if df.empty:
            logging.error("### Uploaded file contains no valid data")
            return {"flag": False, "message": "Uploaded file contains no valid data"}

        missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
        logging.info(f"### Columns in Main Sheet: {list(df.columns)}")
        if missing_cols:
            logging.error(f"### Missing required columns: {missing_cols}")
            return {"flag": False, "message": f"Missing required columns: {', '.join(missing_cols)}"}

        # tenant_db_name = data.get('db_name', 'altaworx_test') or 'altaworx_test'
        tenant_db_name = data.get('db_name', None)
        tenant_id = data.get('tenant_id', None)
        if tenant_db_name is None or tenant_id is None:
            logging.error("### Missing tenant_db_name in the bulk_upload_service_types request data")
            return {"flag":False, "message":"Something went wrong!"}
        tenant_database = DB(tenant_db_name, **db_config)

        created_by = data.get('username', '')
        tenant_name = data.get('tenant_name', '')
        # tenant_id = data.get('tenant_id', 1)
        mode = os.getenv('ENV', 'UAT')
        if tenant_id in ["212",212] and mode =='UAT':
            tenant_id   = 1
            tenant_name = "Altaworx"

        # --- Fetch existing service types ---
        logging.info("### Fetching existing service types")
        df_existing = killbill_database.get_data("services", {}, ["description"])
        if isinstance(df_existing, pd.DataFrame) and "description" in df_existing.columns:
            existing_service_types = {
                str(desc).strip().lower()
                for desc in df_existing["description"].dropna().tolist()
            }
        else:
            existing_service_types = set()
        logging.info(f"### Found {len(existing_service_types)} existing service types")

        all_new_records = []
        fail_count, success_count = 0, 0
        
        # Error counters for different types
        error_counts = {
            "mandatory_fields_missing": 0,
            "invalid_primary_identifier": 0,
            "invalid_service_location": 0,
            "invalid_provider": 0,
            "duplicate_service_type": 0,
            "no_valid_providers": 0,
            "mixed_platforms": 0,
            "amop_custom_not_allowed": 0,
            "billing_custom_no_fields": 0,
            "processing_errors": 0
        }

        # --- Process rows ---
        for idx, row in df.iterrows():
            logging.info(f"### Processing row {idx+2}: {row.to_dict()}")
            try:
                # Extract and validate mandatory fields
                service_type_raw = str(row["Service Type"]).strip() if pd.notna(row["Service Type"]) else ""
                provider_name_raw = str(row["Provider Name"]).strip() if pd.notna(row["Provider Name"]) else ""
                primary_identifier_raw = str(row["Primary Identifier"]).strip() if pd.notna(row["Primary Identifier"]) else ""
                
                # Check for mandatory fields
                mandatory_fields_missing = []
                if not service_type_raw or service_type_raw.lower() in ["nan", ""]:
                    mandatory_fields_missing.append("Service Type")
                if not provider_name_raw or provider_name_raw.lower() in ["nan", ""]:
                    mandatory_fields_missing.append("Provider Name")
                if not primary_identifier_raw or primary_identifier_raw.lower() in ["nan", ""]:
                    mandatory_fields_missing.append("Primary Identifier")
                
                # If any mandatory fields are missing, skip this row
                if mandatory_fields_missing:
                    fail_count += 1
                    error_counts["mandatory_fields_missing"] += 1
                    logging.info(f"Row {idx+2}: Missing mandatory fields: {mandatory_fields_missing}")
                    continue
                
                service_type_name = service_type_raw
                service_location = str(row["Service Location"]).strip() if pd.notna(row["Service Location"]) else None
                
                logging.info(f"Row {idx+2}: ServiceType={service_type_name}, PrimaryId={primary_identifier_raw}, ServiceLocation={service_location}")

                # Validate and normalize the primary identifier
                valid_identifiers = {"iccid": "ICCID", "eid": "EID", "msisdn": "MSISDN", "imei": "IMEI", "custom": "Custom"}
                primary_identifier_key = primary_identifier_raw.lower().strip()

                if primary_identifier_key not in valid_identifiers:
                    fail_count += 1
                    error_counts["invalid_primary_identifier"] += 1
                    logging.info(f"Row {idx+2}: Invalid primary identifier '{primary_identifier_raw}'. Valid options: {list(valid_identifiers.values())}")
                    continue

                primary_identifier = valid_identifiers[primary_identifier_key]

                # Validate Service Location if provided
                if service_location and service_location.lower() not in ["nan", ""]:
                    # Fetch valid service locations from database
                    try:
                        service_locations_query = killbill_database.get_data("service_locations", columns=["states"])
                        valid_locations = [loc.strip().lower() for loc in service_locations_query["states"].tolist() if pd.notna(loc)]
                        
                        if service_location.lower() not in valid_locations:
                            fail_count += 1
                            error_counts["invalid_service_location"] += 1
                            logging.info(f"Row {idx+2}: Invalid service location '{service_location}'. Must be one of the valid states.")
                            continue
                    except Exception as e:
                        logging.warning(f"Row {idx+2}: Could not validate service location: {e}")
                        # Continue processing even if validation fails
                else:
                    service_location = None

                # Duplicate check
                if service_type_name.lower() in existing_service_types:
                    fail_count += 1
                    error_counts["duplicate_service_type"] += 1
                    logging.info(f"Row {idx+2}: Duplicate service type '{service_type_name}'")
                    continue

                # Providers validation
                provider_names = [p.strip() for p in provider_name_raw.split(",") if p.strip()]
                logging.info(f"Row {idx+2}: Provider names parsed = {provider_names}")
                
                # Check if providers exist in the provider sheet
                available_providers = providers_df["Display Name"].tolist()
                invalid_providers = [p for p in provider_names if p not in available_providers]
                
                if invalid_providers:
                    fail_count += 1
                    error_counts["invalid_provider"] += 1
                    logging.info(f"Row {idx+2}: Invalid providers found: {invalid_providers}. Available providers: {available_providers}")
                    continue
                
                matched_providers = providers_df[providers_df["Display Name"].isin(provider_names)]
                logging.info(f"Row {idx+2}: Matched providers = {matched_providers.to_dict(orient='records')}")

                if matched_providers.empty:
                    fail_count += 1
                    error_counts["no_valid_providers"] += 1
                    logging.info(f"Row {idx+2}: No valid providers found for: {provider_names}")
                    continue

                platforms = set(matched_providers["Platform"].tolist())
                logging.info(f"Row {idx+2}: Platforms found = {platforms}")

                if len(platforms) != 1:
                    fail_count += 1
                    error_counts["mixed_platforms"] += 1
                    if "Billing" in platforms and "AMOP" in platforms:
                        logging.info(f"Row {idx+2}: Cannot mix Billing and AMOP providers")
                    else:
                        logging.info(f"Row {idx+2}: Providers must belong to the same platform")
                    continue

                platform = list(platforms)[0]
                service_provider_name = matched_providers["Display Name"].tolist()
                service_provider_name = json.dumps(service_provider_name) if service_provider_name else None

                changed_data = {
                    "description": service_type_name,
                    "primary_field": primary_identifier,
                    "service_provider_name": service_provider_name,
                    "service_location": service_location,
                    "created_by": created_by,
                    "modified_by": created_by,
                    "tenant_id": tenant_id,
                    "tenant_name": tenant_name,
                    "status": "Active"
                }

                # Custom fields
                cf_raw = str(row["Custom Fields"]).strip()
                cf_list = []
                if cf_raw and cf_raw.lower() not in ["nan", ""]:
                    cf_list = [{"field": f, "type": "text", "db_column_name": f}
                               for f in [x.strip() for x in cf_raw.split(",") if x.strip()]]

                # Built-in fields
                bf_raw = str(row["Built In Fields"]).strip()
                bf_list = []
                if bf_raw and bf_raw.lower() not in ["nan", ""]:
                    bf_fields = [x.strip() for x in bf_raw.split(",") if x.strip()]
                    
                    # Check if primary identifier exists in built-in fields
                    primary_field_names = {
                        "ICCID": ["iccid", "ICCID"],
                        "IMEI": ["imei", "IMEI"], 
                        "MSISDN": ["msisdn", "MSISDN"],
                        "EID": ["eid", "EID"]
                    }
                    
                    # Get possible field names for the primary identifier
                    primary_variants = primary_field_names.get(primary_identifier, [])
                    
                    # Filter out built-in fields that match the primary identifier
                    filtered_bf_fields = []
                    skipped_fields = []
                    
                    for field in bf_fields:
                        field_lower = field.lower().strip()
                        # Check if this built-in field matches the primary identifier
                        if any(variant.lower() == field_lower for variant in primary_variants):
                            skipped_fields.append(field)
                            logging.info(f"Row {idx+2}: Skipping built-in field '{field}' as it matches primary identifier '{primary_identifier}'")
                        else:
                            filtered_bf_fields.append(field)
                    
                    # Create built-in fields list from filtered fields
                    bf_list = [{"field": f, "type": "text", "db_column_name": f} for f in filtered_bf_fields]
                    
                    # Log the filtering if any fields were skipped
                    if skipped_fields:
                        logging.info(f"Row {idx+2}: Skipped {len(skipped_fields)} duplicate built-in fields: {skipped_fields}")
                        logging.info(f"Row {idx+2}: Remaining built-in fields: {filtered_bf_fields}")
                
                changed_data["built_in_fields"] = str(bf_list)

                # Rule i: AMOP + custom not allowed
                if platform == "AMOP" and primary_identifier == "Custom":
                    fail_count += 1
                    error_counts["amop_custom_not_allowed"] += 1
                    logging.info(f"Row {idx+2}: AMOP provider cannot use custom primary field")
                    continue

                # Rule ii: Billing + custom → only first custom field
                if platform == "Billing" and primary_identifier == "Custom":
                    if cf_list:
                        changed_data["custom_primary_field"] = cf_list[0]['field']
                        # Remove the first custom field from the list
                        cf_list = cf_list[1:]
                    else:
                        fail_count += 1
                        error_counts["billing_custom_no_fields"] += 1
                        logging.info(f"Row {idx+2}: Billing + custom requires at least one custom field")
                        continue
                changed_data["custom_fields"] = str(cf_list) if cf_list else None

                logging.info(f"Row {idx+2}: Final changed_data = {changed_data}")
                all_new_records.append(changed_data)

            except Exception as e:
                logging.exception(f"Row {idx+2} failed: {e}")
                fail_count += 1
                error_counts["processing_errors"] += 1

        # --- Bulk insert ---
        logging.info(f"### Preparing to insert {len(all_new_records)} new records")
        if all_new_records:
            try:
                # normalizing all records
                all_new_records = normalize_records(all_new_records)
                status = killbill_database.insert_data(all_new_records, 'services')
                logging.info(f"### Bulk insert status: {status}")
                if status:
                    success_count = len(all_new_records)
                else:
                    fail_count += len(all_new_records)
                    error_counts["processing_errors"] += len(all_new_records)
            except Exception as e:
                logging.exception(f"Bulk insert failed: {e}")
                fail_count += len(all_new_records)
                error_counts["processing_errors"] += len(all_new_records)

        # --- Create error summary ---
        error_summary = []
        if error_counts["mandatory_fields_missing"] > 0:
            error_summary.append(f"Mandatory fields not filled - {error_counts['mandatory_fields_missing']}")
        if error_counts["invalid_primary_identifier"] > 0:
            error_summary.append(f"Invalid primary identifier - {error_counts['invalid_primary_identifier']}")
        if error_counts["invalid_service_location"] > 0:
            error_summary.append(f"Invalid service location - {error_counts['invalid_service_location']}")
        if error_counts["invalid_provider"] > 0:
            error_summary.append(f"Invalid provider - {error_counts['invalid_provider']}")
        if error_counts["duplicate_service_type"] > 0:
            error_summary.append(f"Duplicate service type - {error_counts['duplicate_service_type']}")
        if error_counts["no_valid_providers"] > 0:
            error_summary.append(f"No valid providers found - {error_counts['no_valid_providers']}")
        if error_counts["mixed_platforms"] > 0:
            error_summary.append(f"Can't have AMOP and Billing provider - {error_counts['mixed_platforms']}")
        if error_counts["amop_custom_not_allowed"] > 0:
            error_summary.append(f"AMOP provider cannot use custom primary field - {error_counts['amop_custom_not_allowed']}")
        if error_counts["billing_custom_no_fields"] > 0:
            error_summary.append(f"Billing + custom requires at least one custom field - {error_counts['billing_custom_no_fields']}")
        if error_counts["processing_errors"] > 0:
            error_summary.append(f"Processing errors - {error_counts['processing_errors']}")

        # --- Audit logging ---
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        logging.info(f"### Finished processing. Success={success_count}, Fail={fail_count}, Time={time_consumed}s")

        if success_count and not fail_count:
            logging.info("### Final result: Full Success")
            database.update_audit({
                "service_name": "bulk_upload_service_types",
                "created_by": created_by,
                "status": "True",
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": tenant_name,
                "comments": f"Total Rows: {total_rows} | Success: {success_count} | Fail: {fail_count}",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }, "audit_user_actions")
            return {"flag": True, "message": f"Successfully uploaded {success_count} service types"}

        elif success_count and fail_count:
            logging.info("### Final result: Partial Success")
            database.update_audit({
                "service_name": "bulk_upload_service_types",
                "created_by": created_by,
                "status": "Partial Success",
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": tenant_name,
                "comments": f"Uploaded {success_count} service types, {fail_count} failed",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }, "audit_user_actions")
            error_text = "; ".join(error_summary)
            return {"flag": True, "message": f"Total Rows: {total_rows} | Success: {success_count} | Fail: {fail_count}.\nErrors: {error_text}"}

        else:
            logging.error("### Final result: All rows failed")
            database.log_error_to_db({
                "service_name": "bulk_upload_service_types",
                "error_message": f"All rows failed. Error summary: {error_summary}",
                "error_type": "BulkInsertError",
                "users": created_by,
                "session_id": data.get("session_id", ""),
                "tenant_name": tenant_name,
                "comments": "Exception occurred while bulk uploading service types",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }, "error_log_table")
            error_text = "; ".join(error_summary)
            return {"flag": True, "message": f"Total Rows: {total_rows} | Success: {success_count} | Fail: {fail_count}.\nErrors: {error_text}"}

    except Exception as e:
        logging.exception(f"Exception in bulk_upload_service_types: {e}")
        database.log_error_to_db({
            "service_name": "bulk_upload_service_types",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": "Exception occurred while bulk uploading service types",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at", "")
        }, "error_log_table")
        return {"flag": False, "message": f"Error processing upload: {e}"}






def normalize_records(records):
    """
    Ensure all dicts in `records` have the same keys.
    Fill missing keys with None.
    """
    # Collect all keys from all records
    all_keys = set()
    for rec in records:
        all_keys.update(rec.keys())

    # Normalize each record
    normalized = []
    for rec in records:
        norm = {}
        for key in all_keys:
            norm[key] = rec.get(key, None)
        normalized.append(norm)

    return normalized
def reupload_service_types(data):
    """
    Reuploads and updates service types' custom fields from a UI-uploaded Excel blob.
    Expects an Excel file with columns: ID, Custom Fields.
    'Custom Fields' can be a comma-separated string of field names.

    Parameters:
        data (dict): Contains the base64 encoded Excel blob under the key "blob".

    Returns:
        dict: Contains a flag indicating success or failure, a status message,
              and a list of updated service IDs when successful.
    """
    logging.info(f'## reupload_service_types function called with data {data}')
    try:
        start_time = time.time() # Record start time for performance tracking
        # Step 1: Establish database connections for billing platform and common utilities
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        
        blob_data = data.get("blob")
        if not blob_data:
            return {"flag": False, "message": "Blob data not provided"}

        blob_data = blob_data.split(",", 1)[1]
        blob_data += "=" * (-len(blob_data) % 4)
        file_stream = BytesIO(base64.b64decode(blob_data))

        df = pd.read_excel(file_stream, engine="openpyxl")
        if df.empty:
            error_data = {
                "service_name": "reupload_service_types",
                "error_message": "Empty Excel",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": f"Uploaded Excel is empty",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": "Uploaded Excel is empty"}

        logging.info(f'## reupload_service_types dataframe {df}')

        df.columns = df.columns.str.strip()
        if "ID" not in df.columns or "Custom Fields" not in df.columns:
            error_data = {
                "service_name": "reupload_service_types",
                "error_message": "Missing Columns",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": f"Messing 'ID' or 'Custom Fields' columns in uploaded Excel",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")

            return {"flag": False, "message": "Excel must have 'ID' and 'Custom Fields' columns"}

        updated_service_data = {}
        updated_service_id_list = []

        for _, row in df.iterrows():
            service_id = row["ID"]
            custom_fields_str = row["Custom Fields"]

            structured_fields = []
            if isinstance(custom_fields_str, str):
                fields_list = [f.strip() for f in custom_fields_str.split(",") if f.strip()]
                for fname in fields_list:
                    structured_fields.append({
                        "field": fname,
                        "type": "text",
                        "db_column_name": fname
                    })
            elif isinstance(custom_fields_str, list):
                for fname in custom_fields_str:
                    fname = str(fname).strip()
                    if fname:
                        structured_fields.append({
                            "field": fname,
                            "type": "text",
                            "db_column_name": fname
                        })
            else:
                structured_fields = []

            updated_service_data[service_id] = structured_fields
            updated_service_id_list.append(service_id)

        logging.info(f"## reupload_service_types Updated service data: {updated_service_data}")
        logging.info(f"## reupload_service_types Updated service ID list: {updated_service_id_list}")

        update_count = 0
        for service_id, custom_fields in updated_service_data.items():
            try:
                killbill_database.update_dict(
                    "services",
                    {"custom_fields": str(custom_fields)},
                    {"id": service_id}
                )
                update_count += 1
            except Exception as e:
                logging.warning(f"## reupload_service_types Failed to update service {service_id}: {e}")
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        # Prepare audit log data for successful operation
        audit_data_user_actions = {
            "service_name": "reupload_service_types",
            "created_by": data.get("username", ""),
            "status": "True",
            "time_consumed_secs": time_consumed,  
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": json.dumps({
                "updated_service_count": update_count,
                "updated_service_ids": updated_service_id_list
            }),
            "module_name": data.get("module_name", ""),
            "request_received_at": data.get("request_received_at", "")
        }
        # Log successful update operation to audit table
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")

        return {
            "flag": True,
            "message": f"Successfully updated {update_count} service types",
            "updated_service_ids": updated_service_id_list
        }

    except Exception as e:
        logging.exception(f"## reupload_service_types Exception in reupload_service_types: {e}")
        common_utils_db = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
        # Prepare error logging data for database logging
        error_data = {
            "service_name": "reupload_service_types",
            "error_message": f"Exception: {str(e)}",
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": json.dumps({"input_data": data}),
            "module_name": data.get("module_name", ""),
            "request_received_at": data.get("request_received_at", "")
        }
        # Log error details to error log table
        common_utils_db.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": f"Error occurred: {str(e)}"}



def reupload_products(data):
    """
    Reuploads and updates products from an uploaded Excel template.

    Expected columns in template:
    ID, Product Type Code, Ps Code, Business Type, Provider Name,
    Rate, Multi Service ID, Prorate, Is Surcharge

    Args:
        data (dict):
            - blob: base64 Excel string (with optional prefix)
            - username: user performing update
    Returns:
        dict: {flag: True/False, message: str}
    """
    start_time = time.time() # Record start time for performance tracking
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    logging.info(f"## reupload_products called with data: {list(data.keys())}")
    try:
        blob_data = data.get("blob")
        if not blob_data:
            return {"flag": False, "message": "Blob data not provided"}

        # Decode Excel blob
        blob_data = blob_data.split(",", 1)[1]
        blob_data += "=" * (-len(blob_data) % 4)
        file_stream = BytesIO(base64.b64decode(blob_data))

        df = pd.read_excel(file_stream, engine="openpyxl")
        if df.empty:
            error_data = {
                "service_name": "reupload_products",
                "error_message": "Uploaded Excel has no data",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Uploaded Excel has no data",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": "Uploaded Excel has no data"}
        logging.info(f"## reupload_products dataframe: {df}")

        df.columns = df.columns.str.strip()

        required_cols = [
            "ID", "Product Type Code", "Business Type",
            "Provider Name", "Rate", "Multi Service ID", "Prorate", "Is Surcharge"
        ]
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            error_data = {
                "service_name": "reupload_products",
                "error_message": "Missing columns",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Missing columns: {', '.join(missing_cols)}",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": f"Missing columns: {', '.join(missing_cols)}", "Validation": True}
        
        valid_product_types = {"onetime", "recurring"}

        invalid_product_types = (
            df[
                ~df["Product Type Code"]
                .astype(str)
                .str.strip()
                .str.lower()
                .isin(valid_product_types)
            ]["Product Type Code"]
            .unique()
        )

        if len(invalid_product_types) > 0:
            message = (
                "Invalid Product Type Code found. "
                "Allowed values are only 'Onetime' or 'Recurring'. "
                f"Invalid values: {', '.join(map(str, invalid_product_types))}"
            )
            return {"flag": False, "message": message, "Validation": True}

        
        # DB connection
        billing_db_name= data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        tenant_db_name = data.get('db_name', '')
        tenant_database = DB(tenant_db_name, **db_config)

        # Cache provider name to id for efficiency
        provider_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
        provider_tenant = tenant_database.get_data("serviceprovider", None, ["id", "display_name"])
        combined_providers = pd.concat([provider_main, provider_tenant]).drop_duplicates("id")
        provider_name_to_id = dict(zip(combined_providers["display_name"], combined_providers["id"]))

        ps_bundle_df = killbill_database.get_data(
            "ps_bundle_codes",
            {},
            ["rule_name", "ps_code", "label"]
        )
        valid_ps_bundle_codes = set(
            ps_bundle_df.apply(
                lambda row: f"{row['ps_code']} - {row['label']}",
                axis=1
            )
        )

        valid_bundle_codes = set(
            ps_bundle_df["rule_name"]
                .astype(str)
                .str.strip()
        )

        update_count = 0
        failed_updates = []

        for _, row in df.iterrows():
            try:
                product_id = row["ID"]
                bundle_code = row.get("Bundle Code")
                ps_code = row.get("Tax Code")  # will become ps_code later
                ps_code_present = pd.notna(ps_code) and str(ps_code).strip()
                bundle_code_present = pd.notna(bundle_code) and str(bundle_code).strip()

                # ❌ neither present
                if not ps_code_present and not bundle_code_present:
                    return {
                        "flag": True,
                        "message": f"Either Tax Code or Bundle Code must be provided",
                        "Validation": True
                    }

                # ❌ both present
                if ps_code_present and bundle_code_present:
                    return {
                        "flag": True,
                        "message": f"Only one of Bundle Code or Tax Code can be entered",
                        "Validation": True
                    }

                # ✅ validate bundle_code
                if bundle_code_present:
                    bundle_code = str(bundle_code).strip()
                    if bundle_code not in valid_bundle_codes:
                        return {
                            "flag": True,
                            "message": f"Invalid PS bundle code: {bundle_code}",
                            "Validation": True
                        }

                # ✅ validate ps_code
                else:
                    ps_code_label = str(ps_code).strip()  # Excel already sends ps_code + " - " + label
                    # Validate against DB composite strings
                    if ps_code_label not in valid_ps_bundle_codes:
                        return {
                            "flag": True,
                            "message": f"Invalid PS code: {ps_code_label}",
                            "Validation": True
                        }
                update_data = {}

                bundle_code = row.get("Bundle Code")
                update_data["bundle_code"] = "" if pd.isna(bundle_code) else str(bundle_code).strip()

                if pd.notna(row["Product Type Code"]):
                    update_data["product_type_code"] = str(row["Product Type Code"]).strip()

                # if pd.notna(row["Bundle Code"]):
                #     update_data["bundle_code"] = str(row["Bundle Code"]).strip()

                if pd.notna(row["Tax Code"]):
                    update_data["tax_code"] = str(row["Tax Code"]).strip()

                if pd.notna(row["Business Type"]):
                    update_data["business_type"] = str(row["Business Type"]).strip()

                provider_name = str(row["Provider Name"]).strip() if pd.notna(row["Provider Name"]) else None
                if provider_name:
                    update_data["service_provider_name"] = provider_name
                provider_id = provider_name_to_id.get(provider_name)
                if provider_id:
                    update_data["provider_id"] = int(provider_id)
                else:
                    logging.warning(f"Provider name '{provider_name}' not found for product {product_id}")

                if pd.notna(row["Rate"]):
                    try:
                        update_data["rate"] = float(row["Rate"])
                    except ValueError:
                        logging.warning(f"Invalid Rate for product {product_id}")

                if pd.notna(row["Multi Service ID"]):
                    if isinstance(row["Multi Service ID"], str):
                        service_ids = [x.strip() for x in row["Multi Service ID"].split(",") if x.strip()]
                    elif isinstance(row["Multi Service ID"], list):
                        service_ids = [str(x).strip() for x in row["Multi Service ID"] if str(x).strip()]
                    else:
                        service_ids = []
                    update_data["multi_service_id"] = json.dumps(service_ids)  # JSON array string

                if pd.notna(row["Prorate"]):
                    update_data["prorate"] = str(row["Prorate"]).strip().lower() in ["true", "yes", "y", "1"]

                if pd.notna(row["Is Surcharge"]):
                    update_data["is_surcharge"] = str(row["Is Surcharge"]).strip().lower() in ["true", "yes", "y", "1"]
                
                if "Status" in df.columns and pd.notna(row["Status"]):
                    status_val = row["Status"]

                    if isinstance(status_val, bool):
                        is_active = status_val
                    else:
                        status_str = str(status_val).strip().lower()
                        if status_str in ["true", "1", "yes", "y"]:
                            is_active = True
                        elif status_str in ["false", "0", "no", "n"]:
                            is_active = False
                        else:
                            return {"flag": False, "message": "Invalid Status value for product. Allowed values: True or False"}

                    update_data["is_active"] = is_active

                if update_data:
                    update_data["ps_code"] = update_data.pop("tax_code", "")
                    logging.info(f"## reupload_products Updating product {product_id}: {update_data}")
                    killbill_database.update_dict("products", update_data, {"id": int(product_id)})
                    update_count += 1

            except Exception as e:
                logging.warning(f"## reupload_products Failed to update product {row.get('ID')}: {e}")
                failed_updates.append(str(row.get("ID")))
                try:
                    error_data = {
                        "service_name": "reupload_products",
                        "error_message": str(e),
                        "error_type": str(type(e).__name__),
                        "users": data.get("username", ""),
                        "session_id": data.get("session_id", ""),
                        "tenant_name": data.get("tenant_name", ""),
                        "comments": f"Failed to update product ID {row.get('ID')}: {e}  ---{update_data}",
                        "module_name": "Billing Services",
                        "request_received_at": data.get("request_received_at", "")
                    }
                    database.log_error_to_db(error_data, "error_log_table")
                except Exception as log_e:
                    logging.exception(f"Failed to log error for product {row.get('ID')}: {log_e}")

        msg = f"Successfully Updated {update_count} products"
        if failed_updates:
            msg += f". Failed to update: {', '.join(failed_updates)}"
        
        
        # Audit success
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data_user_actions = {
            "service_name": "reupload_products",
            "created_by": data.get("username", ""),
            "status": "True",
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f'msg: {msg}',
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at", "")
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return {"flag": True, "message": msg}

    except Exception as e:
        logging.exception("Exception in reupload_products")
        error_data = {
            "service_name": "reupload_products",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Exception in reupload_products",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at", "")
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": f"Error: {e}"}



def reupload_products_07_01_26(data):
    """
    Reuploads and updates products from an uploaded Excel template.

    Expected columns in template:
    ID, Product Type Code, Ps Code, Business Type, Provider Name,
    Rate, Multi Service ID, Prorate, Is Surcharge

    Args:
        data (dict):
            - blob: base64 Excel string (with optional prefix)
            - username: user performing update
    Returns:
        dict: {flag: True/False, message: str}
    """
    start_time = time.time() # Record start time for performance tracking
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    logging.info(f"## reupload_products called with data: {list(data.keys())}")
    try:
        blob_data = data.get("blob")
        if not blob_data:
            return {"flag": False, "message": "Blob data not provided"}

        # Decode Excel blob
        blob_data = blob_data.split(",", 1)[1]
        blob_data += "=" * (-len(blob_data) % 4)
        file_stream = BytesIO(base64.b64decode(blob_data))

        df = pd.read_excel(file_stream, engine="openpyxl")
        if df.empty:
            error_data = {
                "service_name": "reupload_products",
                "error_message": "Uploaded Excel has no data",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Uploaded Excel has no data",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": "Uploaded Excel has no data"}
        logging.info(f"## reupload_products dataframe: {df}")

        df.columns = df.columns.str.strip()

        required_cols = [
            "ID", "Product Type Code", "Bundle Code", "Tax Code", "Business Type",
            "Provider Name", "Rate", "Multi Service ID", "Prorate", "Is Surcharge"
        ]
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            error_data = {
                "service_name": "reupload_products",
                "error_message": "Missing columns",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Missing columns: {', '.join(missing_cols)}",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": f"Missing columns: {', '.join(missing_cols)}"}
        
        valid_product_types = {"onetime", "recurring"}

        invalid_product_types = (
            df[
                ~df["Product Type Code"]
                .astype(str)
                .str.strip()
                .str.lower()
                .isin(valid_product_types)
            ]["Product Type Code"]
            .unique()
        )

        if len(invalid_product_types) > 0:
            message = (
                "Invalid Product Type Code found. "
                "Allowed values are only 'Onetime' or 'Recurring'. "
                f"Invalid values: {', '.join(map(str, invalid_product_types))}"
            )
            return {"flag": False, "message": message}

        
        # DB connection
        billing_db_name= data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        tenant_db_name = data.get('db_name', '')
        tenant_database = DB(tenant_db_name, **db_config)

        # Cache provider name to id for efficiency
        provider_main = killbill_database.get_data("serviceprovider", None, ["id", "display_name"])
        provider_tenant = tenant_database.get_data("serviceprovider", None, ["id", "display_name"])
        combined_providers = pd.concat([provider_main, provider_tenant]).drop_duplicates("id")
        provider_name_to_id = dict(zip(combined_providers["display_name"], combined_providers["id"]))

        ps_bundle_df = killbill_database.get_data(
            "ps_bundle_codes",
            {},
            ["rule_name", "ps_code", "label"]
        )
        valid_ps_bundle_codes = set(
            ps_bundle_df.apply(lambda row: f"{row['rule_name']} - {row['ps_code']} - {row['label']}", axis=1)
        )

        update_count = 0
        failed_updates = []

        for _, row in df.iterrows():
            try:
                product_id = row["ID"]
                bundle_code = row.get("Bundle Code")
                ps_code = row.get("Tax Code")  # will become ps_code later
                if pd.notna(bundle_code) and str(bundle_code).strip():
                    combined_code = f"{str(bundle_code).strip()} - {str(ps_code).strip()}"
                    if not any(combined_code in valid_code for valid_code in valid_ps_bundle_codes):
                        message = f"Invalid PS bundle code: {combined_code}"
                        logging.info(message)
                        return {"flag": False, "message": message}
                else:
                    ps_code_str = str(ps_code).strip()
                    if not any(ps_code_str in valid_code for valid_code in valid_ps_bundle_codes):
                        message = f"Invalid PS code: {ps_code_str}"
                        logging.info(message)
                        return {"flag": False, "message": message}
                update_data = {}

                bundle_code = row.get("Bundle Code")
                update_data["bundle_code"] = "" if pd.isna(bundle_code) else str(bundle_code).strip()

                if pd.notna(row["Product Type Code"]):
                    update_data["product_type_code"] = str(row["Product Type Code"]).strip()

                # if pd.notna(row["Bundle Code"]):
                #     update_data["bundle_code"] = str(row["Bundle Code"]).strip()

                if pd.notna(row["Tax Code"]):
                    update_data["tax_code"] = str(row["Tax Code"]).strip()

                if pd.notna(row["Business Type"]):
                    update_data["business_type"] = str(row["Business Type"]).strip()

                provider_name = str(row["Provider Name"]).strip() if pd.notna(row["Provider Name"]) else None
                if provider_name:
                    update_data["service_provider_name"] = provider_name
                provider_id = provider_name_to_id.get(provider_name)
                if provider_id:
                    update_data["provider_id"] = int(provider_id)
                else:
                    logging.warning(f"Provider name '{provider_name}' not found for product {product_id}")

                if pd.notna(row["Rate"]):
                    try:
                        update_data["rate"] = float(row["Rate"])
                    except ValueError:
                        logging.warning(f"Invalid Rate for product {product_id}")

                if pd.notna(row["Multi Service ID"]):
                    if isinstance(row["Multi Service ID"], str):
                        service_ids = [x.strip() for x in row["Multi Service ID"].split(",") if x.strip()]
                    elif isinstance(row["Multi Service ID"], list):
                        service_ids = [str(x).strip() for x in row["Multi Service ID"] if str(x).strip()]
                    else:
                        service_ids = []
                    update_data["multi_service_id"] = json.dumps(service_ids)  # JSON array string

                if pd.notna(row["Prorate"]):
                    update_data["prorate"] = str(row["Prorate"]).strip().lower() in ["true", "yes", "y", "1"]

                if pd.notna(row["Is Surcharge"]):
                    update_data["is_surcharge"] = str(row["Is Surcharge"]).strip().lower() in ["true", "yes", "y", "1"]
                
                if "Status" in df.columns and pd.notna(row["Status"]):
                    status_val = row["Status"]

                    if isinstance(status_val, bool):
                        is_active = status_val
                    else:
                        status_str = str(status_val).strip().lower()
                        if status_str in ["true", "1", "yes", "y"]:
                            is_active = True
                        elif status_str in ["false", "0", "no", "n"]:
                            is_active = False
                        else:
                            return {"flag": False, "message": "Invalid Status value for product. Allowed values: True or False"}

                    update_data["is_active"] = is_active

                if update_data:
                    update_data["ps_code"] = update_data.pop("tax_code", "")
                    logging.info(f"## reupload_products Updating product {product_id}: {update_data}")
                    killbill_database.update_dict("products", update_data, {"id": int(product_id)})
                    update_count += 1

            except Exception as e:
                logging.warning(f"## reupload_products Failed to update product {row.get('ID')}: {e}")
                failed_updates.append(str(row.get("ID")))
                try:
                    error_data = {
                        "service_name": "reupload_products",
                        "error_message": str(e),
                        "error_type": str(type(e).__name__),
                        "users": data.get("username", ""),
                        "session_id": data.get("session_id", ""),
                        "tenant_name": data.get("tenant_name", ""),
                        "comments": f"Failed to update product ID {row.get('ID')}: {e}  ---{update_data}",
                        "module_name": "Billing Services",
                        "request_received_at": data.get("request_received_at", "")
                    }
                    database.log_error_to_db(error_data, "error_log_table")
                except Exception as log_e:
                    logging.exception(f"Failed to log error for product {row.get('ID')}: {log_e}")

        msg = f"Successfully Updated {update_count} products"
        if failed_updates:
            msg += f". Failed to update: {', '.join(failed_updates)}"
        
        
        # Audit success
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data_user_actions = {
            "service_name": "reupload_products",
            "created_by": data.get("username", ""),
            "status": "True",
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f'msg: {msg}',
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at", "")
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return {"flag": True, "message": msg}

    except Exception as e:
        logging.exception("Exception in reupload_products")
        error_data = {
            "service_name": "reupload_products",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Exception in reupload_products",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at", "")
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": f"Error: {e}"}



def serialize_timestamps(products_list):
    logging.info(f"## serialize_timestamps called products_list {products_list}")
    for prod in products_list:
        logging.info(f"## serialize_timestamps called prod {prod}")
        for dt_key in ['created_date', 'modified_date']:
            dt_value = prod.get(dt_key)
            logging.info(f"## serialize_timestamps checking dt_key {dt_key} value {dt_value}")
            if dt_value is None or pd.isna(dt_value):
                logging.info(f"## serialize_timestamps setting None for key {dt_key}")
                prod[dt_key] = None
            elif isinstance(dt_value, (pd.Timestamp, datetime.datetime)):
                logging.info(f"## serialize_timestamps converting {dt_value} to isoformat")
                prod[dt_key] = dt_value.isoformat()
    return products_list

def reupload_packages(data):
    """
    Reupload and update packages data from uploaded Excel blob.
    """
    start_time = time.time() # Record start time for performance tracking
    logging.info(f"## reupload_packages called data {data}")

    try:
        # DB Connections
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)

        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        tenant_database_name = data.get("db_name", "")
        tenant_database = DB(tenant_database_name, **db_config)

        # Step 1: Decode uploaded Excel blob
        blob_data = data.get("blob")
        if not blob_data:
            error_data = {
                "service_name": "reupload_packages",
                "error_message": "No blob data provided",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"No blob data provided",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": "No blob data provided"}

        blob_data = blob_data.split(",", 1)[1]
        blob_data += "=" * (-len(blob_data) % 4)  # padding
        file_stream = BytesIO(base64.b64decode(blob_data))

        # Step 2: Read Excel to DataFrame
        df = pd.read_excel(file_stream, engine="openpyxl")
        if df.empty:
            error_data = {
                "service_name": "reupload_packages",
                "error_message": "Empty uploaded file",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Empty uploaded file",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": "Uploaded file is empty"}
        logging.info(f"## reupload_packages dataframe {df}")

        df.columns = df.columns.str.strip()

        # Rename "Package Name" to "category" if present
        if "Package Name" in df.columns:
            df.rename(columns={"Package Name": "category"}, inplace=True)

        required_cols = [
            "ID", "Description On Bill", "Service Provider Name",
             "Service Id", "category", "Product Id"
        ]
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            error_data = {
                "service_name": "reupload_packages",
                "error_message": "Missing columns",
                "error_type": "ValueError",
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Missing columns: {', '.join(missing)}",
                "module_name": "Billing Services",
                "request_received_at": data.get("request_received_at", "")
            }
            database.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": f"Missing columns: {', '.join(missing)}"}

        # Step 3: Batch fetch provider IDs for unique service provider names
        unique_provider_names = df["Service Provider Name"].dropna().unique().tolist()

        tenant_providers_df = tenant_database.get_data(
            "serviceprovider", {"display_name": tuple(unique_provider_names)}, ["id", "display_name"]
        )
        tenant_provider_names = tenant_providers_df["display_name"].tolist() if not tenant_providers_df.empty else []

        missing_provider_names = list(set(unique_provider_names) - set(tenant_provider_names))
        main_providers_df = pd.DataFrame()
        if missing_provider_names:
            main_providers_df = killbill_database.get_data(
                "serviceprovider", {"display_name": tuple(missing_provider_names)}, ["id", "display_name"]
            )

        combined_providers_df = pd.concat([tenant_providers_df, main_providers_df], ignore_index=True)
        provider_name_to_id = dict(zip(combined_providers_df["display_name"], combined_providers_df["id"]))

        # Map provider_id for all rows once
        df["provider_id"] = df["Service Provider Name"].map(provider_name_to_id)

        update_count = 0
        failures = []

        # Step 4: Process each row and update DB
        for _, row in df.iterrows():
            try:
                pkg_id = int(row["ID"])
                # Map 'Description On Bill' to desc_on_bill
                desc_on_bill = row.get("Description On Bill", "")
                category = row["category"]
                provider_id = row["provider_id"]
                provider_name = row["Service Provider Name"]

                # # Parse product_type descriptions from 'Product Type Id' column (comma-separated)
                # raw_product_type = row.get("Product Type Id", "")
                # product_type_ids = []
                # if pd.notna(raw_product_type):
                #     if isinstance(raw_product_type, str):
                #         product_type_ids = [pt.strip() for pt in raw_product_type.split(",") if pt.strip()]

                service_id = int(row["Service Id"]) if not pd.isna(row["Service Id"]) else None

                product_ids = [pid.strip() for pid in str(row["Product Id"]).split(",") if pid.strip()]
                logging.info(f"## reupload_packages product_ids {product_ids}")
                updated_table_data = []
                if product_ids:
                    product_df = killbill_database.get_data("products", {"id": product_ids}, None)
                    if not product_df.empty:
                        df_dict = product_df.to_dict(orient="records")

                        # Normalize values in df_dict
                        for record in df_dict:
                            for key, value in record.items():
                                if isinstance(value, float):
                                    record[key] = int(value) if value.is_integer() else value
                                elif isinstance(value, pd.Timestamp):
                                    record[key] = value.strftime("%m-%d-%y %H:%M:%S")
                                elif isinstance(value, str) and value.startswith("[") and value.endswith("]"):
                                    try:
                                        parsed_list = ast.literal_eval(value)
                                        if isinstance(parsed_list, list):
                                            record[key] = parsed_list
                                    except (ValueError, SyntaxError):
                                        pass
                        updated_table_data = df_dict

                logging.info(f"## reupload_packages after normalization {updated_table_data}")
                grouped_total, ungrouped_total = 0, 0
                for prod in updated_table_data:
                    rate = float(prod.get('rate', 0) or 0)
                    if prod.get('group'):
                        grouped_total += rate
                    if prod.get('itemize'):
                        ungrouped_total += rate
                logging.info(f"## reupload_packages grouped_total {grouped_total} ungrouped_total {ungrouped_total}")

                display_name = ""
                if provider_id:
                    sp_df = killbill_database.get_data("serviceprovider", {"id": provider_id}, ["display_name"])
                    if not sp_df.empty:
                        display_name = sp_df.iloc[0]["display_name"]
                logging.info(f"## reupload_packages display_name {display_name}")

                service_type_name = ""
                if service_id:
                    st_df = killbill_database.get_data("services", {"id": str(service_id)}, ["description"])
                    if not st_df.empty:
                        service_type_name = st_df.iloc[0]["description"]
                logging.info(f"## reupload_packages service_type_name {service_type_name}")

                package_products = {
                    "generalData": {
                        "category": category,
                        "desc_on_bill": desc_on_bill,
                        "display_name": display_name,
                        "service_type": service_type_name,
                    },
                    "productsData": {
                        # "product_type": product_type_ids,
                        "description": [f"{category} -- {prod.get('id')}" for prod in updated_table_data],
                        "UpdatedTableData": updated_table_data,
                    },
                }
                logging.info(f"## reupload_packages package_products {package_products}")

                update_payload = {
                    "desc_on_bill": desc_on_bill,
                    "category": category,
                    "provider_id": provider_id,
                    "service_id": service_id,
                    "grouped": grouped_total,
                    "ungrouped": ungrouped_total,
                    "package_products": json.dumps(package_products, default=str),
                    "service_provider_name": provider_name,
                }
                logging.info(f"## reupload_packages update_payload {update_payload}")

                killbill_database.update_dict("packages", update_payload, {"id": pkg_id})
                update_count += 1

            except Exception as e:
                logging.exception(f"## Failed to update package {row.get('ID')}: {e}")
                failures.append(str(row.get("ID")))
                try:
                    error_data = {
                        "service_name": "reupload_packages",
                        "error_message": str(e),
                        "error_type": str(type(e).__name__),
                        "users": data.get("username", ""),
                        "session_id": data.get("session_id", ""),
                        "tenant_name": data.get("tenant_name", ""),
                        "comments": f"Failed to update package ID {row.get('ID')}: {e}",
                        "module_name": "Billing Services",
                        "request_received_at": data.get("request_received_at", "")
                    }
                    database.log_error_to_db(error_data, "error_log_table")
                except Exception as log_e:
                    logging.exception(f"Failed to log error for package {row.get('ID')}: {log_e}")

        msg = f"Updated {update_count} packages"
        if failures:
            msg += f". Failed: {', '.join(failures)}"

        # Audit success
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data_user_actions = {
            "service_name": "reupload_packages",
            "created_by": data.get("username", ""),
            "status": "True",
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f'msg: {msg}',
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at", "")
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

        return {"flag": True, "message": msg}

    except Exception as e:
        logging.exception("## Exception in reupload_packages")
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        # Audit failure (business logic issue)
        error_data = {
            "service_name": "reupload_packages",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Exception in reupload_packages",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at", "")
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": str(e)}

def readme_api_data(common_utils_database, data):
    """
    Fetches tenant_name based on the provided access token and client_id.
    Args:
        z_access_token (str): The access token for authentication.
        data (dict): A dictionary containing the following
            - client_id (str): The client ID to fetch the tenant name.
    Returns:
        dict: Updated data dictionary with tenant_name if found.
    """
    logging.info(f'## readme_api_data function called with data {data}')
    try:
        mode = os.getenv('ENV', '')
        z_access_token=data.get("z_access_token", "")
        # Fetch tenant_name using access token and client_id
        if z_access_token:
            username = data.get("client_id", "")
            page   =  data.get("page", 1)
            if page:
                data['mod_pages']={"start":(page-1)*100 ,"end":page*100}
 
            # Fetch service account details
            service_account = common_utils_database.get_data(
                "service_accounts", {"client_id": username}
            ).to_dict(orient="records")[0]
 
            # Update data dictionary with tenant and role information
            data['role_name'] = service_account["role"]
            tenant = service_account["tenant"]
 
            # Handle special case for UAT environment
            if mode == 'UAT' and tenant == 'Altaworx Test':
                tenant_id = '1'
                tenant = 'Altaworx Test'
 
            # Fetch tenant details
            data["tenant_name"] = tenant
            logging.info(f"## readme_api_data tenant_name {tenant}")
            # Fetch tenant database details
            tenant_database_df = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant}, ["db_name", 'id']
            )
            logging.info(f"## readme_api_data tenant_database_df {tenant_database_df}")
 
            # Update data dictionary with tenant_id and db_name
            data['tenant_id'] = tenant_database_df['id'].to_list()[0]
            data['db_name'] = tenant_database_df["db_name"].to_list()[0]
            data["session_id"] = data.get("session_id", "client_call")
            data["username"] = data.get("client_id", "client_call")
        return data
    except Exception as e:
        logging.info(f"## readme_api_data Exception occured as: {e}")
        return False
    
def update_service_type_status(data):
    """
    Handles activate/deactivate actions for Service Types.
    Takes full `data` dict as input.
    Performs update, auditing, and error logging.
    Returns response dict.
    """
    start_time = time.time()


    # Initialize DB connections
    billing_db_name = data.get("billing_db_name", "")
    if not billing_db_name:
        return {"flag": False, "message": "Billing DB is Required"}
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    common_utils_database=DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    
    # for readme api
    data=readme_api_data(common_utils_database,data)
    if data.get("z_access_token",""):
        data["changed_data"] = {
            "id": data.get("id")}
        data["action"]= "activate" if data.get("status", "") else "deactivate"

    tenant_db_name = data.get('db_name', '')


    if tenant_db_name == "null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    # Extract metadata
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    unique_id = changed_data.get("id", None)
    table_name = data.get("table_name", "services")
    action = data.get("action", "").lower()
    data_to_update={}

    try:
        # Extract and reassign fields
        # custom_fields = changed_data.pop('customFields', {})
        # built_in_fields = changed_data.pop('builtInFields', {})
        # changed_data['custom_field'] = custom_fields
        # changed_data.update(built_in_fields)

        # Clean empty values
        # changed_data = {
        #     k: str(v)
        #     for k, v in changed_data.items()
        #     if v not in (None, "None", "")
        # }
       
        # Set status depending on action
        if action == "activate":
            changed_data['status'] = 'Active'
            changed_data['is_active']=True
            data_to_update['status']='Active'
            data_to_update['is_active']=True
        elif action == "deactivate":
            changed_data['status'] = 'Inactive'
            changed_data['is_active']=False
            data_to_update['status']='Inactive'
            data_to_update['is_active']=False

        # Remove display_name if present
        # changed_data.pop('display_name', None)
        data_to_update={
            k: str(v)
            for k, v in data_to_update.items()
            if v not in (None, "None", "")
        }

        logging.info(f"## update_service_type_status changed_data {data_to_update}")
        # Save to DB
        status = data_update_db(data_to_update, unique_id, table_name, killbill_database)

        if status:
            message = f"{action.capitalize()}d Successfully"
            flag = True
        else:
            message = f"Failed to {action.capitalize()}"
            flag = False

        # Audit success
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "update_service_type_status",
            "created_by": username,
            "status": str(flag),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Service Types {message}",
            "module_name": "Service Types",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps({"flag": flag, "message": message})
        }
        database.update_audit(audit_data, "audit_user_actions")

        return {"flag": flag, "message": message}

    except Exception as e:
        logging.exception(f"Error in update_service_type_status: {e}")
        message = f"Unable to {action} Service Types"
        error_type = str(type(e).__name__)

        # Log error
        error_data = {
            "service_name": "update_service_type_status",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Service Types",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}

def copy_service_type(data):
    """
    Handles copy action for Service Types.
    Mirrors the original inline copy block inside update_billing_actions_data.
    Includes auditing and error logging.
    """
    start_time = time.time()
    # Initialize DB connections
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

    tenant_db_name = data.get("db_name", "")
    if tenant_db_name == "null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    table_name = data.get("table_name", "services")

    try:
        # timestamp
        current_timestamp = datetime.now().strftime("%m-%d-%Y %H:%M:%S")

        # created_date reset
        if "created_date" in changed_data:
            changed_data["created_date"] = current_timestamp

        # Extract and reassign fields
        custom_fields = changed_data.pop("customFields", {})
        built_in_fields = changed_data.pop("builtInFields", {})
        changed_data["custom_field"] = custom_fields
        changed_data.update(built_in_fields)

        # Insert using existing add_service_type
        response = add_service_type(data)

        # Audit success/failure
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "copy_service_type",
            "created_by": username,
            "status": str(response.get("flag", False)),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Service Types Copied Successfully",
            "module_name": "Service Types",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps(response),
        }
        database.update_audit(audit_data, "audit_user_actions")

        return response

    except Exception as e:
        logging.exception(f"Error in copy_service_type: {e}")
        message = "Unable to Copy Service Type"
        error_type = str(type(e).__name__)

        # Log error
        error_data = {
            "service_name": "copy_service_type",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Service Types",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}

def update_products(data):
    """
    Handles update action for Billing Products.
    Mirrors the inline 'update' block from update_billing_actions_data.
    Includes auditing and error logging.
    """
    logging.info(f'### update_products fucntion called with {data}')
    start_time = time.time()
    # Initialize DB connections
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    common_utils_database=DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    # Validate access token
    data = readme_api_data(common_utils_database, data)
    if data.get("z_access_token"):
        allowed_keys = [
            "description", "product_type", "ps_code", "product_type_code",
            "business_type", "service_provider", "apply_to", "rate",
            "automatic_expiration", "free_period", "g_l_code", "buy_rate",
            "cost", "multi_service_id", "prorate", "is_surcharge"
        ]

        changed_data = {}
        for k in allowed_keys:
            value = data.get(k)

            # Skip if value is None or "empty"
            if value in (None, "", [], {}):
                continue

            # Special handling for multi_service_id
            if k == "multi_service_id" and isinstance(value, str):
                changed_data[k] = [v.strip() for v in value.split(",") if v.strip()]
            else:
                changed_data[k] = value

        data["changed_data"] = changed_data


    tenant_db_name = data.get("db_name", "")
    if tenant_db_name == "null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    table_name = data.get("table_name", "products")
    unique_id = changed_data.get("id")
    description = changed_data.get("description", "")

    try:
        if description:
            logging.info(f'## update_products description {description}')
            description_df = killbill_database.get_data("products", {"description": description}, ["id","description"]).to_dict(orient="records")
            if description_df:
                logging.info(f'## update_products description_df {description_df}')
                #get the id from the category_df
                existed_id = description_df[0]["id"]
                logging.info(f'## update_products unique_id {unique_id} existed_id {existed_id}')
                if unique_id != existed_id:
                    # Category already exists — return error response
                    return {
                        "flag": False,
                        "message": "Product Name already exists",
                        "status": False,
                        "validation": True
                    }
                else:
                    # Product exists but it's the same as the current package — proceed without update
                    logging.info("Product already exists, proceeding without update.")
            else:
                logging.info("No Product provided, proceeding without Product check.")
        
        else:
            return {
                "flag": False,
                "message": "Product Name cannot be empty"                    
            }
        # --- Service Type mapping ---
        if "service_type" in changed_data:
            service_type = changed_data.pop("service_type", None)
            service_type_df = killbill_database.get_data("services", {"description": service_type}, ["id"])
            if not service_type_df.empty:
                changed_data["product_type_code_id"] = service_type_df["id"].to_list()[0]

        # --- Service Provider mapping ---
        if "service_provider" in changed_data:
            service_provider = changed_data.pop("service_provider", None)
            changed_data["service_provider_name"] = service_provider
            provider_df = tenant_database.get_data("serviceprovider", {"display_name": service_provider}, ["id"])
            if not provider_df.empty:
                changed_data["provider_id"] = provider_df["id"].to_list()[0]
            else:
                provider_df = killbill_database.get_data("serviceprovider", {"display_name": service_provider}, ["id"])
                if not provider_df.empty:
                    changed_data["provider_id"] = provider_df["id"].to_list()[0]

        # --- GL Code mapping ---
        if "g_l_code" in changed_data:
            g_l_code = changed_data.pop("g_l_code", None)
            gl_code_df = killbill_database.get_data("gl_code", {"gl_codes": g_l_code}, ["id"])
            if not gl_code_df.empty:
                changed_data["gl_code_id"] = gl_code_df["id"].to_list()[0]

        # --- Remove irrelevant frontend fields ---
        changed_data.pop("code", None)

        # --- Normalize multi-select fields ---
        multi_select_fields = ["multi_options", "multi_provider_accounts", "multi_service_id"]
        for field in multi_select_fields:
            if field in changed_data and isinstance(changed_data[field], list):
                cleaned_list = [str(value).replace("[", "").replace("]", "") for value in changed_data[field]]
                changed_data[field] = json.dumps(cleaned_list)

        # --- Final DB Update ---
        #status = data_update_db(changed_data, unique_id, table_name, killbill_database)
        status = killbill_database.update_dict(table_name, changed_data, {"id": unique_id})

        # --- Build response ---
        if status:
            message = "Updated Products Successfully"
            flag = True
        else:
            message = "Failed to Update Products"
            flag = False

        # --- Audit logging ---
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "update_products",
            "created_by": username,
            "status": str(flag),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Billing Products {message}",
            "module_name": "Billing Products",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps({"flag": flag, "message": message}),
        }
        database.update_audit(audit_data, "audit_user_actions")

        return {"flag": flag, "message": message}

    except Exception as e:
        logging.exception(f"Error in update_products: {e}")
        message = "Unable to Update Billing Products"
        error_type = str(type(e).__name__)

        error_data = {
            "service_name": "update_products",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Billing Products",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}

def update_product_status(data):
    """
    Handles activate/deactivate action for Billing Products.
    Includes auditing and error logging.
    """
    start_time = time.time()
    # Initialize DB connections
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    common_utils_database=DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    
    # --- for readme api ---
    data=readme_api_data(common_utils_database,data)
    if data.get("z_access_token",""):
        data["changed_data"] = {
            "id": data.get("id")}
        data["action"]= "activate" if data.get("status", "") else "deactivate"

    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    table_name = data.get("table_name", "products")
    unique_id = changed_data.get("id")

    changed_data["modified_by"] = username
    data_to_update={}

    try:
        # --- Extract fields ---
        # custom_fields = changed_data.pop("customFields", {})
        # built_in_fields = changed_data.pop("builtInFields", {})
        # changed_data["custom_field"] = custom_fields
        # changed_data.update(built_in_fields)

        
        # --- Status handling ---
        action = data.get("action", "")
        if action == "deactivate":
            changed_data["status"] = "Inactive"
            changed_data.pop("display_name", None)
            data_to_update["status"] = "Inactive"
            data_to_update["is_active"] = False
        elif action == "activate":
            changed_data["status"] = "Active"
            changed_data.pop("display_name", None)
            data_to_update["is_active"] = True
            data_to_update["status"] = "Active"

        # --- Clean empty values ---
        data_to_update = {
            k: str(v)
            for k, v in data_to_update.items()
            if v not in (None, "None", "")
        }


        # --- Update DB ---
        status = data_update_db(data_to_update, unique_id, table_name, killbill_database)

        # --- Build response ---
        if status:
            message = f"Product {action.capitalize()}d Successfully"
            flag = True
        else:
            message = f"Failed to {action.capitalize()} Product"
            flag = False

        # --- Audit logging ---
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "update_product_status",
            "created_by": username,
            "status": str(flag),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Billing Products {message}",
            "module_name": "Billing Products",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps({"flag": flag, "message": message}),
        }
        database.update_audit(audit_data, "audit_user_actions")

        return {"flag": flag, "message": message}

    except Exception as e:
        logging.exception(f"Error in update_product_status: {e}")
        message = "Unable to Update Product Status"
        error_type = str(type(e).__name__)

        error_data = {
            "service_name": "update_product_status",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Billing Products",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}
def copy_products(data):
    """
    Handles copy action for Billing Products.
    Includes auditing and error logging.
    """
    start_time = time.time()
    # Initialize DB connections
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    logging.info(f'data to copy products-------{data}')

    tenant_db_name = data.get("db_name", "")
    if tenant_db_name == "null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    table_name = data.get("table_name", "products")

    changed_data["modified_by"] = username
    current_timestamp = datetime.now().strftime("%m-%d-%Y %H:%M:%S")

    try:
        # --- Reset created_date if present ---
        if "created_date" in changed_data:
            changed_data["created_date"] = current_timestamp

        # --- Insert as new Product ---
        status = add_product(data)

        

        # --- Audit logging ---
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "copy_products",
            "created_by": username,
            "status": str(status.get("flag")),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Billing Products {status.get('message')}",
            "module_name": "Billing Products",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps({"flag": status.get("flag"), "message": status.get("message")}),
        }
        database.update_audit(audit_data, "audit_user_actions")

        return status

    except Exception as e:
        logging.exception(f"Error in copy_products: {e}")
        message = "Unable to Copy Product"
        error_type = str(type(e).__name__)

        error_data = {
            "service_name": "copy_products",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Billing Products",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}

def update_package(data):
    """
    Handles update action for Billing Packages.
    Includes auditing and error logging.
    """
    start_time = time.time()
    # Initialize DB connections
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    common_utils_database=DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = readme_api_data(common_utils_database, data)
    if data.get("z_access_token"):
        service_type = data.get("service_type", "")
        if service_type:
            #check it is valid or not
            service_type_df = killbill_database.get_data("services", {"description": service_type}, ["id"])
            if service_type_df.empty:
                return {
                    "flag": False,
                    "message": "Invalid Service Type"
                }
        data["changed_data"] = {
            "id": int(data.get("id", 0)),
            "generalData": {
                "category": data.get("package_name", ""),
                "desc_on_bill": data.get("desc_on_bill", ""),
                "display_name": data.get("service_provider", ""),
                "service_type": data.get("service_type", "")
            }
        }
        #get product details-
        products_list = data.get("product_id_list", [])
        if isinstance(products_list, str):
            products_list = [p.strip() for p in products_list.split(",") if p.strip()]

        products_list = [int(i) for i in products_list]

        # fetch product details for given IDs
        products_df = killbill_database.get_data(
            "products",
            {"id": products_list},
            []  # fetch all columns
        )

        if products_df.empty or len(products_df) != len(products_list):
            return {
                "flag": False,
                "message": "One or more Product IDs are invalid"
            }

        # build productsData
        descriptions = [
            f"{row['description']} -- {row['id']}"
            for _, row in products_df.iterrows()
        ]

        updated_table_data = products_df.to_dict(orient="records")
        updated_table_data=serialize_data(updated_table_data)

        data["changed_data"]["productsData"] = {
            "description": descriptions,
            "UpdatedTableData": updated_table_data
        }

    tenant_db_name = data.get("db_name", "")
    if tenant_db_name == "null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    table_name = data.get("table_name", "packages")
    unique_id = changed_data.get("id")

    changed_data["modified_by"] = username

    try:
        table_name = 'packages'
        # Extract metadata
        modified_by = data.get('modified_by', '')
        id = changed_data.pop('id', None)
        changed_data = data.get('changed_data', {})
        package_products = changed_data if changed_data else ''
        # Extract general and product data
        pop_up_data = data.get('changed_data', {})
        general_tab_data = pop_up_data.get('generalData', {})
        package_name = general_tab_data.get('category', '').strip()
        if package_name:
            category_df = killbill_database.get_data("packages", {"category": package_name}, ["id","category"]).to_dict(orient="records")
            if category_df:
                #get the id from the category_df
                unique_id = category_df[0]["id"]
                if unique_id != id:
                    # Category already exists — return error response
                    return {
                        "flag": False,
                        "message": "Package Name already exists",
                        "status": False,
                        "validation": True
                    }
                else:
                    # Category exists but it's the same as the current package — proceed without update
                    logging.info("Category already exists, proceeding without update.")
            else:
                logging.info("No category provided, proceeding without category check.")
        
        else:
            return {
                "flag": False,
                "message": "Package Name cannot be empty"                    
            }

        products_data = pop_up_data.get('productsData', {})
        list_view_data = products_data.get('UpdatedTableData', [])
        product_description = products_data.get('description', '')
        # Initialize data containers
        general_tab = {
            'desc_on_bill': general_tab_data.get('desc_on_bill', ''),
            'category': general_tab_data.get('category', ''),
            'one_time': general_tab_data.get('one_time', '')
        }
        product_tab_data = {'description': product_description}

        # Resolve provider ID
        provider = general_tab_data.get('display_name')
        if provider:
            logging.info(f"Provider: {provider}")
            changed_data['service_provider_name'] = provider
            provider_df = tenant_database.get_data("serviceprovider", {"display_name": provider}, ["id"])
            if not provider_df.empty:
                general_tab['provider_id'] = str(provider_df["id"].to_list()[0])
            else:
                provider_df = killbill_database.get_data(
                "serviceprovider", {"display_name": provider}, ["id"]
                )
            if not provider_df.empty:
                provider_id = provider_df["id"].to_list()[0] if not provider_df.empty else None
                changed_data['provider_id'] = provider_id
        # Resolve service type ID
        service_type = general_tab_data.get("service_type")
        if "service_type" in general_tab_data:
            logging.info("Processing service type...")
            if service_type:
                logging.info("Fetching service ID...")
                service_df = killbill_database.get_data("services", {"description": service_type}, ["id"])
                if not service_df.empty:
                    general_tab['service_id'] = str(service_df["id"].to_list()[0])
                    logging.info("Service ID added to general_tab")
            else:
                # Service type key is present but value is None — update service_id to NULL in DB
                logging.info("Service type is empty. Updating service_id to NULL in DB.")
                update_query = f"UPDATE packages SET service_id=NULL WHERE id=%s"
                killbill_database.execute_query(update_query, params=[unique_id])
        else:
            # Service type key is missing — update service_id to NULL in DB
            logging.info("Service type key missing. Updating service_id to NULL in DB.")
            update_query = f"UPDATE packages SET service_id=NULL WHERE id=%s"
            killbill_database.execute_query(update_query, params=[unique_id])

        # Calculate grouped and ungrouped totals
        grouped, ungrouped = 0, 0
        try:
            for row in list_view_data:
                rate = float(row.get('rate', 0))
                if row.get('group', False):
                    grouped += rate
                if row.get('itemize', False):
                    ungrouped += rate
        except Exception as e:
            logging.exception(f"Exception calculating grouped/ungrouped totals: {e}")
        
        # Finalize general_tab with remaining values
        try:
            general_tab.update({
                'modified_by': modified_by,
                'status': 'Active',
                'package_products': str(package_products),
                'grouped': str(grouped),
                'ungrouped': str(ungrouped)
            })
        except Exception as e:
            logging.exception(f"Failed to update package: {e}")
            response = {
                "flag": False,
                "message": "Failed to update the data"
            }
        # --- Final DB Update ---
        status = data_update_db(general_tab, unique_id, table_name, killbill_database)
        # --- Build response ---
        if status:
            message = "Package Updated Successfully"
            flag = True
        else:
            message = "Failed to Update Package"
            flag = False

        # --- Audit logging ---
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "update_package",
            "created_by": username,
            "status": str(flag),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Billing Packages {message}",
            "module_name": "Billing Packages",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps({"flag": flag, "message": message}),
        }
        database.update_audit(audit_data, "audit_user_actions")

        return {"flag": flag, "message": message}

    except Exception as e:
        logging.exception(f"Error in update_package: {e}")
        message = "Unable to Update Billing Package"
        error_type = str(type(e).__name__)

        error_data = {
            "service_name": "update_package",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Billing Packages",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}

def update_package_status(data):
    """
    Handles activate/deactivate action for Billing Packages.
    Includes auditing and error logging.
    """
    start_time = time.time()
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    common_utils_database=DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data=readme_api_data(common_utils_database,data)
    if data.get("z_access_token",""):
        data["changed_data"] = {
            "id": data.get("id"),
            "is_active": True if data.get("status", "") else False}
        data["action"]= "activate" if data.get("status", "") else "deactivate"

    tenant_db_name = data.get("db_name", "")
    if tenant_db_name == "null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    table_name = data.get("table_name", "packages")
    unique_id = changed_data.get("id")

    changed_data["modified_by"] = username

    try:
        # --- Status Handling ---
        action = data.get("action", "")
        if "package_category" in changed_data:
            changed_data.pop('package_category')
        if "provider" in changed_data:
            changed_data.pop('provider')
        if "service" in changed_data:
            changed_data.pop('service')
            
        if action == "deactivate":
            changed_data["status"] = "Inactive"
            changed_data.pop("display_name", None)
        elif action == "activate":
            changed_data["status"] = "Active"
            changed_data.pop("display_name", None)

        # --- Update DB ---
        status = data_update_db(changed_data, unique_id, table_name, killbill_database)

        # --- Build Response ---
        if status:
            message = f"Package {action.capitalize()}d Successfully"
            flag = True
        else:
            message = f"Failed to {action.capitalize()} Package"
            flag = False

        # --- Audit Logging ---
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "update_package_status",
            "created_by": username,
            "status": str(flag),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Billing Packages {message}",
            "module_name": "Billing Packages",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps({"flag": flag, "message": message}),
        }
        database.update_audit(audit_data, "audit_user_actions")

        return {"flag": flag, "message": message}

    except Exception as e:
        logging.exception(f"Error in update_package_status: {e}")
        message = "Unable to Update Package Status"
        error_type = str(type(e).__name__)

        error_data = {
            "service_name": "update_package_status",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Billing Packages",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}

def copy_package(data):
    """
    Handles copy action for Billing Packages.
    Includes auditing and error logging.
    """
    start_time = time.time()
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)

    tenant_db_name = data.get("db_name", "")
    if tenant_db_name == "null":
        tenant_db_name = "altaworx_test"
    tenant_database = DB(tenant_db_name, **db_config)

    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    table_name = data.get("table_name", "packages")

    changed_data["modified_by"] = username
    current_timestamp = datetime.now().strftime("%m-%d-%Y %H:%M:%S")

    try:
        # --- Reset created_date ---
        if "created_date" in changed_data:
            changed_data["created_date"] = current_timestamp

        # --- Extract custom & built-in fields ---
        custom_fields = changed_data.pop("customFields", {})
        built_in_fields = changed_data.pop("builtInFields", {})
        changed_data["custom_field"] = custom_fields
        changed_data.update(built_in_fields)

        # --- Call existing add_package function ---
        response = add_package(data)

        # --- Audit Logging ---
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "copy_package",
            "created_by": username,
            "status": str(response.get("flag", False)),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "Billing Packages Copied Successfully" if response.get("flag") else "Failed to Copy Billing Package",
            "module_name": "Billing Packages",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps(response),
        }
        database.update_audit(audit_data, "audit_user_actions")

        return response

    except Exception as e:
        logging.exception(f"Error in copy_package: {e}")
        message = "Unable to Copy Package"
        error_type = str(type(e).__name__)

        error_data = {
            "service_name": "copy_package",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Billing Packages",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")

        return {"flag": False, "message": message}




def fetch_active_customer_services_by_service_type(data):
    """
    Fetch active customer services by service type
    1. Connect to the database using DB class.
    2. Query the customer_services table for active services matching the given service type.
    3. Handle exceptions and log errors if any occur.
    4. Return the result with appropriate flags and messages.
    """
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    tenant_id=data.get("tenant_id", "")
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_id in ['212',212]:
            tenant_name = 'Altaworx'
            tenant_id = 1
    try:
        service_type = data.get("description", "")
        customer_services=killbill_database.get_data("customer_services",{"service_type":service_type,"status":"Active","is_active":True,"tenant_id":tenant_id},["id"])
        if not customer_services.empty:
            message = "Active services are associated with this service type. Do you want to update all of them"
            flag = True
        else:
            result = []
            message = "No active customer services found for the given service type"
            flag = False
        
        return {"flag": flag, "message": message}

    except Exception as e:
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
        logging.exception(f"Error in fetch_active_customer_services_by_service_type: {e}")
        message = "Unable to fetch active customer services"
        error_type = str(type(e).__name__)

        # Log error
        error_data = {
            "service_name": "fetch_active_customer_services_by_service_type",
            "error_message": str(e),
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Service Types",
            "request_received_at": data.get("request_received_at", ""),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message}




def update_service_type(data):
    """
    Handles update action for Service Types module.
    Extracts customFields, builtInFields, maps provider_id, 
    and cleans changed_data before DB update.
    """
    start_time = time.time()
    try:
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        common_utils_database=DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)


        # Read and validate API data
        data=readme_api_data(common_utils_database,data)
        if data.get("z_access_token"):
            custom_fields = [
                {"field": f.strip(), "type": "text", "db_column_name": f.strip()}
                for f in data.get("custom_fields", "").split(",") if f.strip()
            ]


            built_in_fields = [
                {"field": f, "type": "text", "db_column_name": f}
                for f in data.get("built_in_fields", []) if f
            ]

            data["changed_data"] = {
                **({"description": data["description"]} if data.get("description") else {}),
                **({"primary_field": data["primary_field"]} if data.get("primary_field") else {}),
                **({"display_name": data["service_provider"]} if data.get("service_provider") else {}),
                **({"service_location": data["service_location"]} if data.get("service_location") else {}),
                **({"custom_fields": custom_fields} if custom_fields else {}),
                **({"built_in_fields": built_in_fields} if built_in_fields else {}),
                **({"id": data["id"]} if data.get("id") else {})
            }
            logging.info(f"## update_service_type data {data['changed_data']}")
    
        
        tenant_db_name = data.get('db_name', '')
        if tenant_db_name == "null":
            tenant_db_name = "altaworx_test"

        # Extract metadata
        Partner = data.get("Partner", "")
        request_received_at = data.get("request_received_at", "")
        session_id = data.get("session_id", "")
        username = data.get("username", "")
        changed_data = data.get("changed_data", {})
        unique_id = changed_data.get("id", None)
        table_name = data.get("table_name", "services")
        description = changed_data.get("description", "")

        if "custom_fields" not in changed_data:
            changed_data["custom_fields"] = []
        if "built_in_fields" not in changed_data:
            changed_data["built_in_fields"] = []
            
        if "custom_fields" in changed_data and isinstance(changed_data["custom_fields"], list):
            changed_data["custom_fields"] = deduplicate_field_dicts(changed_data["custom_fields"])
        if "built_in_fields" in changed_data and isinstance(changed_data["built_in_fields"], list):
            changed_data["built_in_fields"] = deduplicate_field_dicts(changed_data["built_in_fields"])

        changed_data = {
            k: json.dumps(v) if isinstance(v, (list, dict)) else str(v)
            for k, v in changed_data.items()
            if v not in (None, "None", "")
        }

        # Save to DB
        status = killbill_database.update_dict(table_name,changed_data, {"description":description})

        if status:
            message = "Service Type Updated Successfully"
            flag = True
            update_customer_fields = update_customer_fields_in_services(data, killbill_database, database)
        else:
            message = "Unable to update Service Type"
            flag = False

        # Audit success
        end_time = time.time()
        time_consumed = int(float(f"{end_time - start_time:.4f}"))
        audit_data = {
            "service_name": "update_service_type",
            "created_by": username,
            "status": str(flag),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": f"Service Types {message}",
            "module_name": "Service Types",
            "request_received_at": request_received_at,
            "request_data": json.dumps(changed_data),
            "response_data": json.dumps({"flag": flag, "message": message})
        }
        database.update_audit(audit_data, "audit_user_actions")

        return {"flag": flag, "message": message}

    except Exception as e:
        logging.exception(f"Error in update_service_type: {e}")
        message = "Unable to update Service Type"
        error_type = str(type(e).__name__)

        # Log error
        error_data = {
            "service_name": "update_service_type",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "Service Types",
            "request_received_at": request_received_at,
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message}





def update_customer_fields_in_services(data, killbill_database, database):
    """
    Update built-in fields and custom fields in the services table for a given service type.
    Runs update only if there is a change.
    """
    logging.info(f"## update_customer_fields_in_services--{data}")
    try:
        mode=os.getenv('ENV','UAT')
        tenant_id=data.get("tenant_id", "")
        if mode=='UAT':
            if tenant_id in ['212',212]:
                tenant_name = 'Altaworx'
                tenant_id = 1
        changed_data=data.get("changed_data",{})
        service_type = changed_data.get("description", "")
        custom_fields_list = extract_field_names(changed_data.get("custom_fields", []))
        built_in_fields_list = extract_field_names(changed_data.get("built_in_fields", []))
        if not service_type:
            return {"flag": False, "message": "Service type is required"}

        # fetch both json columns
        customer_services = killbill_database.get_data(
            "customer_services",
            {"service_type": service_type, "status": "Active", "is_active": True,"tenant_id":tenant_id},
            ["id", "custom_fields", "built_in_fields"]
        )
        logging.info(f"## update_customer_fields_in_services")
        if customer_services.empty:
            return {"flag": False, "message": "No active customer services found for the given service type"}

        # helper to safely load JSON or literal
        def load_json(s):
            if not s:
                return {}
            try:
                d = json.loads(s)
            except Exception:
                d = ast.literal_eval(s)
            return d if isinstance(d, dict) else {}
        logging.info(f"## update_customer_fields_in_services222")
        # loop records
        for _, row in customer_services.iterrows():
            record_id = row["id"]

            # --- custom fields ---
            current_custom = load_json(row.get("custom_fields", ""))
            updated_custom = {f: current_custom.get(f, "") for f in custom_fields_list}
            updated_custom_str = json.dumps(updated_custom)

            # --- built-in fields ---
            current_built_in = load_json(row.get("built_in_fields", ""))
            updated_built_in = {f: current_built_in.get(f, "") for f in built_in_fields_list}
            updated_built_in_str = json.dumps(updated_built_in)

            # --- compare ---
            updates_to_push = {}
            if updated_custom_str != row.get("custom_fields", ""):
                logging.info(f"## update_customer_fields_in_services--{updated_custom_str}--{row.get('custom_fields', '')}")
                updates_to_push["custom_fields"] = updated_custom_str
            if updated_built_in_str != row.get("built_in_fields", ""):
                logging.info(f"## update_customer_fields_in_services--{updated_built_in_str}--{row.get('built_in_fields', '')}")
                updates_to_push["built_in_fields"] = updated_built_in_str

            # --- only update if something changed ---
            if updates_to_push:
                killbill_database.update_dict("customer_services", updates_to_push, {"id": record_id})

        # Audit logging
        audit_data = {
            "service_name": "update_customer_fields_in_services",
            "created_by": data.get("username", ""),
            "status": "True",
            "time_consumed_secs": 0,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": f"Customer fields updated successfully in services for service type {service_type}",
            "module_name": "Service Types",
            "request_received_at": data.get("request_received_at", ""),
            "request_data": json.dumps(data),
            "response_data": json.dumps({"flag": True, "message": "Customer fields updated successfully in services"})
        }
        database.log_audit_data(audit_data, "audit_log_table")
        return {"flag": True, "message": "Customer fields updated successfully in services"}

    except Exception as e:
        logging.exception(f"Error in update_customer_fields_in_services: {e}")
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "update_customer_fields_in_services",
            "error_message": str(e),
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Service Types",
            "request_received_at": data.get("request_received_at", ""),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Failed to update customer fields in services"}


def extract_field_names(fields):
    """
    Convert list of dicts with 'field' key -> list of field names.
    Example: [{"field":"F1","type":"text"}] -> ["F1"]
    """
    names = []
    for f in fields:
        if isinstance(f, dict) and "field" in f:
            names.append(f["field"])
        elif isinstance(f, str):
            names.append(f)
    return names


def deduplicate_field_dicts(items):
    """
    Deduplicate list of {"field": <name>, "type": <type>} dicts by field.
    Keeps first occurrence.
    """
    seen = set()
    deduped = []
    for item in items:
        field_name = item.get("field")
        if field_name and field_name not in seen:
            seen.add(field_name)
            deduped.append(item)
    return deduped