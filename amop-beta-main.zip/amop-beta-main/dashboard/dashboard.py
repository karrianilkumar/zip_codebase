"""
@Author1 : Mohammad Burhan
Created Date: 01-07-25
"""

# Importing the necessary Libraries
from collections import defaultdict
from requests.auth import HTTPBasicAuth
import time 
from datetime import datetime, timedelta, timezone, date
import pandas as pd
import numpy as np
from dateutil.parser import parse
import os
from dateutil.parser import parse as dtparse
import pandas as pd
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import logging
import re
import redis
import json
import requests
from common_utils.timezone_conversion import fetch_tenant_timezone, convert_timestamp_data, serialize_data
from calendar import monthrange
from dateutil.relativedelta import relativedelta
import dashboard_old_charts as old
import base64

logging = Logging(name="dashboard")

common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }

def clean_tuple(tpl):
    """ Cleans and formats a tuple, returning a string representation or an empty tuple if invalid."""
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
       logging.exception(f"###Exception while converting tuple: {e}")
       return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name):
    """
    customer and provider info to the DB settings based on user role and tenant.
    """

    if role_name in ('Super Admin','Partner Admin'):
        return db_config_making
    common_utils_database = DB('common_utils', **common_utils_database_config)
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)
    query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"
    filters = common_utils_database.execute_query(query, True)

    database = DB(tenant_database, **db_config)
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception(f"###Error extracting rate_plan_name :{e}")
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception(f"###Error extracting rate_plan_name: {e}")
                customer_names=None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception(f"###Error extracting billing_account_number:{e}")
                billing_account_number=None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"###Error extracting feature_codes :{e}")
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    customer=clean_tuple(customer)
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    logging.info(f"###customerscustomerscustomerscustomers:{customer}")
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                if isinstance(customer, str):
                    customer = customer.strip("()'")  # Clean customer from extra parentheses and quotes
                    customer = (customer,)  # Convert it into a tupl


                # Now convert tuple to list
                customer_list = list(customer)
                # Clean and fix the list by splitting the elements and ensuring they are correctly quoted
                fixed_customer_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info(f'###customer_list before extend:{fixed_customer_list}')

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info(f'###customer_list after extend:{fixed_customer_list}')

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info(f'###final customer tuple:{customer}')
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_name = customer_rate_plan_name.strip("()'")  # Remove ( and ) and ' from start and end
                    customer_rate_plan_name = (customer_rate_plan_name,)  # Now correctly convert it to tuple

                # Now convert tuple to list
                customer_rate_plan_list = list(customer_rate_plan_name)
                fixed_customer_rate_plan_list = []

                # Split the string into items and strip any unwanted characters
                for item in customer_rate_plan_list[0].split("', '"):
                    fixed_customer_rate_plan_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info(f'###customer_list before extend:{customer_rate_plan_list}')

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info(f'###customer_list after extend:{fixed_customer_rate_plan_list}')

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info(f'###final customer tuple:{customer_rate_plan_name}')

    except Exception as e:
        logging.exception(f"###Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")

    logging.info(f'###customer at the end of customer:{customer}')
    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    return db_config_making

def function_caller(data, path):
    """
    Main dispatcher function that builds DB config and routes requests.

    This function:
    1. Initializes database configuration from environment variables.
    2. Determines user/tenant-specific configuration (with service account/token support).
    3. Routes the request to the appropriate handler function based on the path.

    Args:
        data (dict): Request payload containing user/tenant information.
        path (str): API endpoint path.

    Returns:
        dict: Result of the invoked handler function or an error response.
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config

    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    user = data.get("username") or data.get("user_name")
    tenant_database = data.get("db_name")
    tenant_name = data.get("tenant_name", "") or data.get("tenant", "") or data.get("Partner", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    
    role_name = data.get("role_name") or data.get("role") or "Super Admin"
    db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name)
    db_config=db_config_making
    logging.info(f"####db_config created is : {db_config}")


    logging.info("### db_config is created")

    # Step 2: Path → Function mapping
    path_function_map = {
        "/update_device_history_s3":update_device_history_s3,
        "/store_device_history_excel_in_redis_from_buffer":store_device_history_excel_in_redis_from_buffer,
        "/update_mobility_device_history_s3":update_mobility_device_history_s3,

        "/count_of_sim_overview": count_of_sim_overview,
        "/store_excel_in_redis_from_buffer":store_excel_in_redis_from_buffer,
        "/update_device_status_s3":update_device_status_s3,
        "/create_first_100_records_excel":create_first_100_records_excel,
        "/get_sim_count_by_service_provider": get_sim_count_by_service_provider,
        "/get_sim_activations_by_service_provider": get_sim_activations_by_service_provider,
        "/get_all_related_tenants": get_all_related_tenants,
        "/get_organization_dropdown_data": get_organization_dropdown_data,
        "/get_service_provider_vs_status": get_service_provider_vs_status,
        "/total_usage_card": total_usage_card,
        "/total_usage_sims_count": total_usage_sims_count,
        "/total_usage_cost": total_usage_cost,
        "/average_usage_card": average_usage_card,
        "/get_usage_trend_by_provider": get_usage_trend_by_provider,
        "/get_service_type_usage_distribution": get_service_type_usage_distribution,
        "/get_usage_by_carrier_weekly_distribution": get_usage_by_carrier_weekly_distribution,
        "/update_device_total_cost_s3": update_device_total_cost_s3,
        "/update_device_count_s3": update_device_count_s3,
        "/get_plan_utilisation_summary": get_plan_utilisation_summary,
        "/get_revenue_metrics_cards": get_revenue_metrics_cards,
        "/get_revenue_by_carrier": get_revenue_by_carrier,
        "/get_revenue_by_rate_plan": get_revenue_by_rate_plan,
        "/get_profit_margin_trend": get_profit_margin_trend,
        "/get_revenue_by_usage_trend": get_revenue_by_usage_trend,
        "/get_status_count_of_tickets": get_status_count_of_tickets,
        "/insert_new_zendesk_tickets_batch": insert_new_zendesk_tickets_batch,
        "/get_ticket_status_distribution": get_ticket_status_distribution,
        "/get_ticket_resolution_time": get_ticket_resolution_time,
        "/get_ticket_severity_overview": get_ticket_severity_overview,
        "/get_ticket_category_distribution": get_ticket_category_distribution,
        "/sync_usage_insight": sync_usage_insight,
        "/get_dashboard_last_sync_time": get_dashboard_last_sync_time,
        "/refresh_dashboard_all_caches": refresh_dashboard_all_caches,
        "/clear_usage_cache": clear_usage_cache,
        "/get_all_service_providers_and_billing_cycle_dates_dropdown_data": get_all_service_providers_and_billing_cycle_dates_dropdown_data,
        "/get_update_module_features": get_update_module_features,
        "/get_ticket_compilance_by_module": get_ticket_compilance_by_module,
        "/run_populate_revenue_metrics": run_populate_revenue_metrics,
        "/run_populate_revenue_metrics_diff": run_populate_revenue_metrics_diff,
        "/run_populate_revenue_metrics_by_plan": run_populate_revenue_metrics_by_plan,
        "/run_fn_get_sim_inventory_altaworx_test": run_fn_get_sim_inventory,
        "/run_inventory_status_history_insert": run_inventory_status_history_insert,
        "/run_fn_get_usage_summary_by_plan_by_provider_rate_plan": run_fn_get_usage_summary_by_plan_by_provider_rate_plan,
        "/run_fn_get_usage_summary_by_plan_by_customer_3months": run_fn_get_usage_summary_by_plan_by_customer_3months,
        "/run_fn_get_usage_summary_by_plan_by_provider_rate_plan_3months": run_fn_get_usage_summary_by_plan_by_provider_rate_plan_3months,
        "/run_fn_get_usage_summary_by_plan_by_provider_3months": run_fn_get_usage_summary_by_plan_by_provider_3months,
        "/run_fn_get_usage_summary_by_plan_by_provider": run_fn_get_usage_summary_by_plan_by_provider,
        "/run_fn_get_rate_plan_name_by_provider": run_fn_get_rate_plan_name_by_provider,
        "/run_fn_get_usage_summary_by_plan_by_customer": run_fn_get_usage_summary_by_plan_by_customer,
        "/run_fn_get_rate_plan_name_by_customer": run_fn_get_rate_plan_name_by_customer,
        "/sync_sla_from_zendesk":sync_sla_from_zendesk,
        #### old paths ####
        "/get_service_providers": lambda data:old.get_service_providers(data,db_config),
        "/count_of_service_provider": lambda data:old.count_of_service_provider(data,db_config),
        "/count_of_active_sims": lambda data:old.count_of_active_sims(data,db_config),
        "/count_of_pending_sim_activations": lambda data:old.count_of_pending_sim_activations(data,db_config),
        "/device_status_chart": lambda data:old.device_status_chart(data,db_config),
        "/activated_vs_deactivated_pie_chart": lambda data:old.activated_vs_deactivated_pie_chart(data,db_config),
        "/service_provider_change_request_stack_bar": lambda data:old.service_provider_change_request_stack_bar(data,db_config),
        "/count_of_active_customers": lambda data:old.count_of_active_customers(data,db_config),
        "/rev_assurance_record_discrepancy_card": lambda data:old.rev_assurance_record_discrepancy_card(data,db_config),
        "/daily_sync_card": lambda data:old.daily_sync_card(data,db_config),
        "/live_sessions_table": lambda data:old.live_sessions_table(data,db_config),
        "/get_usage_details_card": lambda data:old.get_usage_details_card(data,db_config),
        "/getm2m_high_usage_chart_data": lambda data:old.getm2m_high_usage_chart_data(data,db_config),
        "/get_device_status_card": lambda data:old.get_device_status_card(data,db_config),
        "/generate_empty_excel": lambda data:old.generate_empty_excel(data,db_config),
        "/mobility_usage_per_group_pool": lambda data:old.mobility_usage_per_group_pool(data,db_config),
        "/mobility_usage_per_customer_pool": lambda data:old.mobility_usage_per_customer_pool(data,db_config),
        "/mobility_high_usage_chart": lambda data:old.mobility_high_usage_chart(data,db_config),
        "/get_carrier_rate_plan_data": lambda data:old.get_carrier_rate_plan_data(data,db_config),
        "/get_customer_rate_plan_data": lambda data:old.get_customer_rate_plan_data(data,db_config),
        "/get_rate_plan_data": lambda data:old.get_rate_plan_data(data,db_config),
        "/get_compare_cards": lambda data:old.get_compare_cards(data,db_config),
        "/get_high_usage_chart_data": lambda data:old.get_high_usage_chart_data(data,db_config),
    }

    # Step 3: Route request
    handler = path_function_map.get(path)
    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


redis_client = redis.Redis(
    host=os.getenv('REDIS_HOST'),
    port=os.getenv('REDIS_PORT'),
    ssl=True,
    ssl_cert_reqs=None,
    decode_responses=False
)

def get_cache_key(db_name, function):
    """
    Generates a unique cache key string for storing or retrieving cached data in Redis.
    """
    return f"{db_name}:{function}"

def get_start_date_for_label(label, today):
    """Calculate start date for a given label, considering today and the month boundaries."""
    if label == "1_month":
        # 1st day of current month
        return today.replace(day=1)
    elif label == "3_month":
        # 1st day of month 2 months before current month (for last 3 months including current)
        return (today.replace(day=1) - relativedelta(months=2))
    elif label == "6_month":
        # 1st day of month 5 months before current month (last 6 months including current)
        return (today.replace(day=1) - relativedelta(months=5))
    elif label == "1_year":
        # 1st day of current year
        start_1_year = (today.replace(day=1) - relativedelta(months=11))
        #today - timedelta(weeks=52)
        return start_1_year
    else:
        # Default fallback
        return today

def get_time_format_by_label(label, column=None):
    """Return SQL-safe time format for grouping by label."""
    if label == "1_day":
        # Group in 4-hour blocks
        return f"DATE_TRUNC('hour', {column}) + INTERVAL '1 hour' * (FLOOR(EXTRACT(HOUR FROM {column}) / 4) * 4)"
    elif label == "5_day":
        # Daily
        return f"DATE_TRUNC('day', {column})"
    elif label in ["1_month", "3_month", "6_month", "1_year"]:
        # Weekly grouping by week number in the month or year
        # Formula: (day_of_month -1) / 7 + 1 to get week number in month
        # So group by year, month, and week number inside month
        return (
            f"DATE_TRUNC('month', {column}) + "
            f"INTERVAL '1 day' * (FLOOR((EXTRACT(DAY FROM {column}) - 1) / 7) * 7)"
        )
    
    elif label in ["5_years", "max"]:
        # Yearly grouping
        return f"DATE_TRUNC('year', {column})"
   
    else:
        # Default daily grouping
        return f"DATE_TRUNC('day', {column})"

def execute_all_time_buckets(tenant_time_zone,start_date=None, end_date=None, min_date=None, column=None):
    """Return time bucket configurations based on given or predefined ranges."""
   
    try:
        tz = pytz.timezone(tenant_time_zone or "UTC")
        now = pd.Timestamp.now(tz=tz)      # timezone-aware timestamp in tenant TZ
        today = now.normalize().date()  
        logging.info(f"### Using tenant timezone {tenant_time_zone}: now={now}, today={today}")
    except Exception as tz_conv_exc:
        logging.warning(f"Failed to convert to tenant timezone: {tz_conv_exc}. Using UTC.")
        now = pd.Timestamp.now()
        today = datetime.now().date()
    
    if start_date and end_date:
        days = (end_date - start_date).days
        if days <= 1:
            label = "1_day"
            interval = "4 hours"
            start = start_date
        elif days <= 6:
            label = "5_day"
            interval = "1 day"
            start = start_date
        elif days <= 31:
            label = "1_month"
            interval = "7 days"
            start = get_start_date_for_label("1_month", start_date)
        elif days <= 92:
            label = "3_month"
            interval = "7 days"
            start = get_start_date_for_label("3_month", start_date)
        elif days <= 183:
            label = "6_month"
            interval = "7 days"
            start = get_start_date_for_label("6_month", start_date)
        elif days <= 366:
            label = "1_year"
            interval = "7 days"
            start = get_start_date_for_label("1_year", start_date)
        elif days <= 5 * 366:
            label = "5_years"
            interval = "1 year"
            start = today.replace(year=today.year - 5, month=1, day=1)
        else:
            label = "max"
            interval = "1 year"
            start = min_date or datetime(today.year - 10, 1, 1).date()

        return [
            {
                "start": start,
                "end": end_date,
                "format": get_time_format_by_label(label, column),
                "label": label,
                "interval": interval
            },
            {
                "start": start,
                "end": end_date,
                "format": get_time_format_by_label(label, column),
                "label": "custom_range",
                "interval": interval
            }
        ], label

    # Static buckets if no date range provided
    buckets = [
        {"label": "1_day", "start": today, "interval": "4 hours"},
        {"label": "5_day", "start": today - timedelta(days=4), "interval": "1 day"},
        {"label": "1_month", "start": get_start_date_for_label("1_month", today), "interval": "7 days"},
        {"label": "3_month", "start": get_start_date_for_label("3_month", today), "interval": "7 days"},
        {"label": "6_month", "start": get_start_date_for_label("6_month", today), "interval": "7 days"},
        {"label": "1_year", "start": get_start_date_for_label("1_year", today), "interval": "7 days"},
        {"label": "5_years", "start": datetime(today.year - 5, 1, 1).date(), "interval": "1 year"},
        {"label": "max", "start": min_date or datetime(today.year - 10, 1, 1).date(), "interval": "1 year"},
    ]

    time_buckets = []
    for bucket in buckets:
        time_buckets.append({
            "start": bucket["start"],
            "end": today,
            "format": get_time_format_by_label(bucket["label"], column),
            "label": bucket["label"],
            "interval": bucket["interval"]
        })

    return time_buckets, "max"

########### dropdowns ################

def get_all_related_tenants(data):
    """
    Returns a dictionary mapping tenant names to their IDs, including:
    - the specified tenant
    - other tenants sharing the same parent (siblings)

    Args:
        data (dict): Contains 'tenant_name' (str): Name of the tenant to start from.

    Returns:
        dict: Mapping of tenant_name -> id
    """
    tenant_name = data.get("tenant_name")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    sessionID = data.get("sessionID")
    username = data.get("username")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.now().date()
    if not tenant_name:
        return {"error": "tenant_name is required"}
    result = {}
    # result["All Tenants"] = "All"

    try:
        # Step 1: Get current tenant's ID and parent_tenant_id
        query = f"""SELECT id, parent_tenant_id FROM tenant WHERE tenant_name = '{tenant_name}' and is_active = true"""
        tenant_data = common_utils_database.execute_query(query, True)

        if tenant_data.empty:
            return {}

        tenant_id = tenant_data["id"].iloc[0]
        parent_tenant_id = tenant_data["id"].iloc[0]

        # Override ID for Altaworx Test
        if tenant_name == "Altaworx Test":
            result[tenant_name] = 1
        else:
            result[tenant_name] = int(tenant_id)
            

        # Step 2: Get sibling tenants (other tenants with same parent)
        if parent_tenant_id:
            sibling_query = f"""SELECT tenant_name, id FROM tenant WHERE parent_tenant_id = '{parent_tenant_id}' and is_active = true """
            sibling_data = common_utils_database.execute_query(sibling_query, True)

            for _, row in sibling_data.iterrows():
                sibling_name = row["tenant_name"]
                sibling_id = row["id"]
                if sibling_name != tenant_name:
                    result[sibling_name] = int(sibling_id)

        # return result
        # Prepare response
        response = {
            "flag": True,
            "data": result
        }

        # Auditing success
        try:
 
            audit_data = {
                "service_name": "get_all_related_tenants",
                "created_date": request_received_at,
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Retrieved SIM count for tenant {tenant_name}",
                "module_name": "get_sim_count_by_service_provider",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")

        return response

    except Exception as e:
        logging.warning(f"Error in get_sim_count_by_service_provider: {e}")

        # Generate fallback response
        response = {
            "flag": False,
            "data": [],
            "message": f"Error retrieving SIM count by service_provider : {e}"
        }
 
        # Auditing error
        try:
            error_data = {
                "service_name": "SIM Vs Service Provider",
                "created_date": data.get("request_received_at"),
                "error_messag": f"Error retrieving SIM count: {e}",
                "error_type": str(type(e).__name__),
                "users": data.get("username"),
                "tenant_name": data.get("tenant_name"),
                "comments": str(e),
                "module_name": "get_sim_count_by_service_provider",
                "request_received_at": data.get("request_received_at"),
                "session_id": data.get("sessionID"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as error_logging_exception:
            logging.warning(f"Error logging audit failed: {error_logging_exception}")

        return response

def get_all_service_providers_and_billing_cycle_dates_dropdown_data(data):
    """
  
        Returns dropdown data for service providers and their billing cycle end dates for a given tenant, including:

        - a list of unique service providers (with "All service providers" added at the top)
        - a mapping of each service provider to their billing cycle end dates
       

        Args:
            data (dict): Contains the following keys:
                - 'module' (str): Name of the module requesting the data.
                - 'db_name' (str): Database name of the tenant.
                - 'tenant_name' (str): Name of the tenant.
                

        Returns:
            dict: Contains:
                - 'flag' (bool): True if data retrieval was successful, False otherwise.
                - 'unique_service_providers' (list): Sorted list of unique service providers with "All service providers" at the top.
                - 'billing_period_dates' (dict): Mapping of service_provider -> list of billing_cycle_end_dates (formatted as "YYYY-MM-DD HH:MM:SS").
              
    """

   
    module_name = data.get("module", "")
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id", "")
    # database Connection
    try:
        database = DB(database=tenant_database, **db_config)
        dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        if tenant_name == "Altaworx Test":
            tenant_name = 'Altaworx'

        billing_period_query = f"""
            SELECT service_provider, billing_cycle_end_date
            FROM billing_period
            WHERE is_active = 'true' 
            ORDER BY
                CASE
                    WHEN CURRENT_DATE BETWEEN billing_cycle_start_date
                    AND billing_cycle_end_date THEN 0
                    ELSE 1
                END,
                billing_cycle_end_date DESC
        """
        billing_period_dates = database.execute_query(billing_period_query, True)
        billing_period_dates["billing_cycle_end_date"] = pd.to_datetime(
            billing_period_dates["billing_cycle_end_date"], errors="coerce"
        )

        # Remove NaT (null) values before processing
        billing_period_dates = billing_period_dates.dropna(subset=["billing_cycle_end_date"])

        # Format valid dates as YYYY-MM-DD HH:MM:SS
        billing_period_dates["billing_cycle_end_date"] = billing_period_dates["billing_cycle_end_date"].dt.strftime("%Y-%m-%d %H:%M:%S")
        billing_period_dates = billing_period_dates.to_dict(orient="records")

        # Extract only the service_provider values
        service_providers = [row["service_provider"] for row in billing_period_dates]

        # Create a dictionary where the key is service_provider and
        # the value is a list of billing_cycle_end_dates
        service_provider_dict = {}
        for row in billing_period_dates:
            if row["service_provider"] in service_provider_dict:
                service_provider_dict[row["service_provider"]].append(
                    row["billing_cycle_end_date"]
                )
            else:
                service_provider_dict[row["service_provider"]] = [
                    row["billing_cycle_end_date"]
                ]

        # Optionally, remove duplicates
        unique_service_providers = sorted(list(set(service_providers)))

        # Add "All" to the list of unique service providers
        unique_service_providers.insert(0, "All service providers")

        try:
            audit_data_user_actions = {
                "service_name": "get_all_service_providers_and_billing_cycle_dates_dropdown_data",
                "created_by": data.get("username", ""),
                "status": 'True',
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Dashboard",
                "comments": f"dropdown data exported of service providers - {module_name}",
                "request_received_at": data.get("request_received_at", ""),
            }
            dbs.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        response = {
            "flag": True,
            "unique_service_providers": unique_service_providers,
            "billing_period_dates": service_provider_dict,
            "cross_provider": False
        }
        return response

    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"### error in reports dropdown data export : {e}")
        message = "Something went wrong while fetching reports dropdown data export"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_all_service_providers_and_billing_cycle_dates_dropdown_data",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at", ""),
            }
            dbs.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### Exception while updating audit and exception is:  {e}")

        response = {
            "flag": False,
            "unique_service_providers": [],
            "billing_period_dates": {},
            "cross_provider": False,
            "message": "Something went wrong while fetching service providers dropdown data ",
            "error": str(e)  # Optional: include only in non-production
        }
        return response

def get_organization_dropdown_data(data):
    """
    Fetches organization names and IDs from Zendesk and returns them
    in a dictionary format suitable for a dropdown.

    Returns:
        dict: {organization_name: organization_id}
    """
    sessionID = data.get("sessionID", "")
    username = data.get("username", "")
    organisation_name = data.get("organisation_name", "")
    request_received_at = datetime.now().date()
    #database connection
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)  
    url = f"https://{ZENDESK_SUBDOMAIN}.zendesk.com/api/v2/organizations.json"
    
    headers = {
        "Content-Type": "application/json",
    }
    auth = HTTPBasicAuth(f'{ZENDESK_EMAIL}/token', ZENDESK_API_TOKEN)

    try:
        response = requests.get(url, headers=headers, auth=auth)
        if response.status_code == 200:
            data = response.json()
            organizations = data.get("organizations", [])
            result = {"All Tenants": "All"}  
            for org in organizations:
                org_name = org.get("name")
                org_id = org.get("id")
                if org_name and org_id:
                    result[org_name] = org_id
            return {
                "flag": True,
                "data": result
            }
        else:
            logging.warning(f"Error fetching organizations: {response.status_code} - {response.text}")
            return {
                "flag": False,
                "data": {},
                "message": f"Zendesk API error: {response.status_code}"
            }
    except Exception as exception:
        response["flag"] = False
        response["message"] = "Unexpected error occurred during data preparation"
        logging.error(f"[get_organization_dropdown_data] Unexpected error: {exception}")
        try:
            error_data = {
                "service_name": "get_organization_dropdown_data",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": data.get("tenant_name"),
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                try:
                    common_utils_database.log_error_to_db(error_data, "error_log_table")  
                except:
                    logging.warning("Error table doesn't exist or logging failed.")
        except Exception as exception:
            logging.info(f"Failed to get_organization_dropdown_data: {exception}")
            pass

    return response

def clear_usage_cache(data):
    """
    Manually clears the Redis cache for the usage data (all 4 views and timestamp).
    """
    try:
        cache_key = "sim_provider_count:altaworx_test"
        redis_client.delete(cache_key)
        redis_client.delete(f"{cache_key}:timestamp")
        logging.info(f"Cache cleared for keys: {cache_key}, {cache_key}:timestamp")
        return {"flag": True, "message": "Cache cleared successfully"}
    except Exception as e:
        logging.info(f"Failed to clear cache: {e}")
        return {"flag": False, "message": f"Failed to clear cache: {e}"}

####################################  sim Overview code ########################


def count_of_sim_overview(data):
    """
    Fetches the total number of active SIMs and counts per sim_status from sim_management_inventory.
    Returns only total_active_sims, Activated, Suspended, and Active.
    Adds audit and error logs.
    Uses Redis caching with 2:30 hours expiration.
    When refresh=True, appends new records to existing cache with deduplication.
    """
    tenant_database = data.get("db_name", "")
    start_date = data.get("start_date", None)
    end_date = data.get("end_date", None)
    tenant_id = data.get("tenant_id", "All")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get("service_provider", "")
    billing_cycle_end_period = data.get("billing_cycle_end_period", None)

    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as db_exc:
        logging.exception(f"Failed to connect to database in count_of_sim_overview: {db_exc}")
        return {
            "flag": False,
            "data": {"total": 0, "Activated": 0, "Suspended": 0, "Active": 0, "title": "Count of SIM Overview"},
            "message": "Database connection error",
        }

    # Generate cache key
    function = "count_of_sim_overview"
    cache_key = get_cache_key(tenant_database, function)

    # Always try fetching cache (even if refresh=True)
    cached_data = None
    try:
        cached_response = redis_client.get(cache_key)
        if cached_response:
            cached_data = json.loads(cached_response)
            logging.info(f"Cache hit for key: {cache_key}")
    except Exception as cache_exc:
        logging.warning(f"Cache retrieval failed: {cache_exc}")

    # If cache miss or refresh requested, fetch fresh data from DB
    if refresh or cached_data is None:
        try:
            query = """
                SELECT 
                    status_text,
                    count,
                    tenant_id,
                    modified_date,
                    service_provider_display_name
                FROM inventory_status_history
            """
            result_df = database.execute_query(query, True)

            if isinstance(result_df, pd.DataFrame) and not result_df.empty:
                # Parse modified_date as datetime - keep full timestamp!
                result_df["modified_date"] = pd.to_datetime(result_df["modified_date"], errors='coerce')

                # Pre-normalize status_text
                result_df["status_lower"] = result_df["status_text"].astype(str).str.lower().str.strip()
                
                # get max modified_date (pandas Timestamp or NaT)
                max_modified = result_df["modified_date"].max()
                logging.info(f"[DB FETCH] Max modified_date: {max_modified} (type: {type(max_modified)})")

                cached_data = result_df.to_dict(orient="records")

                # Store in Redis WITH 2:30 hours expiration
                try:
                    redis_client.setex(cache_key, 9000, json.dumps(cached_data, default=str))
                    logging.info(f"Redis cache updated expires in 2:30 Hours for key: {cache_key}")
                except Exception as redis_exc:
                    logging.warning(f"Redis setex failed: {redis_exc}")

                # Audit refresh after setting cache
                try:
                    audit_data = {
                        "function_name": function,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")

            else:
                # No cache and no DB data
                cached_data = []
                logging.info("No data from DB and no existing cache")
        except Exception as db_exc:
            logging.info(f"Database query failed in count_of_sim_overview: {db_exc}")
            if refresh and cached_data is not None:
                # Keep existing cache on DB error during refresh
                logging.info("DB error during refresh, keeping existing cache")
            else:
                cached_data = []

    # Early return if no data
    if not cached_data:
        logging.info("No cached data found, returning zeros")
        response = {
            "flag": True,
            "data": {"total": "0", "Activated": "0", "Suspended": "0", "Active": "0", "title": "Count of SIM Overview"},
        }
        return response

    # Convert to DataFrame once
    df_all = pd.DataFrame(cached_data)
    
    # CRITICAL FIX: Handle mixed datetime formats (with and without microseconds)
    if not df_all.empty and "modified_date" in df_all.columns:
        # Convert to datetime with robust handling for mixed formats
        df_all["modified_date"] = pd.to_datetime(
            df_all["modified_date"],
            errors='coerce'
        )

    # Add status_lower column if not exists (it should exist from cache, but just in case)
    if "status_lower" not in df_all.columns and "status_text" in df_all.columns:
        df_all["status_lower"] = df_all["status_text"].astype(str).str.lower().str.strip()

    original_count = len(df_all)
    
    # Tenant filter
    if tenant_id != "All" and not df_all.empty:
        try:
            filter_tenant_id = int(tenant_id)
            before_count = len(df_all)
            df_all = df_all[df_all["tenant_id"] == filter_tenant_id]
            logging.info(f"[FILTER] After tenant filter (tenant_id={filter_tenant_id}): {len(df_all)} records (filtered out {before_count - len(df_all)})")
        except (ValueError, TypeError) as e:
            logging.warning(f"Invalid tenant_id format: '{tenant_id}' - Error: {e}")

    # Service provider filter
    if service_provider and not df_all.empty and "service_provider_display_name" in df_all.columns:
        before_count = len(df_all)
        df_all = df_all[df_all["service_provider_display_name"] == service_provider]
        logging.info(f"[FILTER] After service provider filter ('{service_provider}'): {len(df_all)} records (filtered out {before_count - len(df_all)})")

    # Billing cycle filter - get latest date <= billing cycle, then latest timestamp on that date
    if billing_cycle_end_period and not df_all.empty:
        try:
            # Parse billing cycle date
            billing_ts = pd.to_datetime(billing_cycle_end_period, errors="coerce")
            if pd.isna(billing_ts):
                raise ValueError(f"Could not parse billing_cycle_end_period: {billing_cycle_end_period!r}")

            # Define period (last 30 days, inclusive)
            billing_date = billing_ts.date()  # datetime.date object for comparisons
            period_start_date = (billing_ts - pd.Timedelta(days=30)).date()

            logging.info(f"[BILLING CYCLE] Target billing date: {billing_date}, period start: {period_start_date}")

            # Ensure modified_date is datetime dtype
            if not pd.api.types.is_datetime64_any_dtype(df_all["modified_date"]):
                df_all["modified_date"] = pd.to_datetime(df_all["modified_date"], errors="coerce")

            # Add date-only column for easy comparisons
            df_all["date_only"] = df_all["modified_date"].dt.date

            # Filter rows that fall inside the billing window (inclusive)
            df_in_period = df_all[
                (df_all["date_only"] >= period_start_date) &
                (df_all["date_only"] <= billing_date)
            ].copy()

            unique_dates = df_in_period["date_only"].dropna().unique()

            if len(unique_dates) == 0:
                logging.info(f"[BILLING CYCLE] No valid dates found in billing period {period_start_date} to {billing_date}")
                df_all = pd.DataFrame()
            else:
                # Get the latest date within the billing window
                latest_available_date = max(unique_dates)
                logging.info(f"[BILLING CYCLE] Latest available date in period: {latest_available_date}")

                # Filter to the rows on that date
                df_same_day = df_in_period[df_in_period["date_only"] == latest_available_date].copy()
                logging.info(f"[BILLING CYCLE] Records found on {latest_available_date}: {len(df_same_day)}")

                if not df_same_day.empty:
                    # Pick the maximum timestamp on that date and keep rows that match it
                    max_timestamp = df_same_day["modified_date"].max()
                    logging.info(f"[BILLING CYCLE] Max timestamp on {latest_available_date}: {max_timestamp}")

                    if pd.notna(max_timestamp):
                        df_all = df_same_day[df_same_day["modified_date"] == max_timestamp].copy()
                        logging.info(f"[BILLING CYCLE] Filtered to {len(df_all)} records with latest timestamp on {latest_available_date}")
                    else:
                        logging.warning(f"[BILLING CYCLE] Max timestamp is NaT for date {latest_available_date}, keeping all records from that date")
                        df_all = df_same_day
                else:
                    logging.info(f"[BILLING CYCLE] No records found on date {latest_available_date}")
                    df_all = pd.DataFrame()

            # Clean up temporary column if present
            df_all = df_all.drop(columns=["date_only"], errors="ignore")

        except Exception as cycle_exc:
            logging.warning(f"[BILLING CYCLE] Filtering failed: {cycle_exc}")
            import traceback
            logging.info(f"[BILLING CYCLE ERROR] Exception: {traceback.format_exc()}")


    # DATE FILTER: Pick latest available date <= end_date, but WITHIN SAME MONTH
    if end_date and end_date.strip() and not df_all.empty:
        logging.info(f"[DATE FILTER] Applying month-bounded nearest-date logic for end_date: {end_date}")
        logging.info(f"[DATE FILTER] Records before filter: {len(df_all)}")

        try:
            end_ts = pd.to_datetime(end_date, errors="coerce")
            if pd.isna(end_ts):
                raise ValueError(f"Invalid end_date: {end_date}")

            end_date_only = end_ts.date()
            end_year = end_ts.year
            end_month = end_ts.month

            # Ensure datetime
            df_all["modified_date"] = pd.to_datetime(df_all["modified_date"], errors="coerce")
            df_all = df_all[df_all["modified_date"].notna()]

            # Date-only column
            df_all["date_only"] = df_all["modified_date"].dt.date

            # ✅ SAME MONTH + <= end_date
            df_month = df_all[
                (df_all["modified_date"].dt.year == end_year) &
                (df_all["modified_date"].dt.month == end_month) &
                (df_all["date_only"] <= end_date_only)
            ]

            logging.info(
                f"[DATE FILTER] Records in {end_year}-{end_month:02d} up to {end_date_only}: {len(df_month)}"
            )

            if df_month.empty:
                logging.info(
                    f"[DATE FILTER] No data found in {end_year}-{end_month:02d} up to {end_date_only}"
                )
                df_all = pd.DataFrame()
            else:
                # Latest available date in that month
                latest_available_date = df_month["date_only"].max()
                logging.info(f"[DATE FILTER] Latest available date in month: {latest_available_date}")

                df_latest_day = df_month[
                    df_month["date_only"] == latest_available_date
                ].copy()

                # Latest timestamp on that date
                max_ts = df_latest_day["modified_date"].max()
                logging.info(f"[DATE FILTER] Max timestamp on {latest_available_date}: {max_ts}")

                df_all = df_latest_day[
                    df_latest_day["modified_date"] == max_ts
                ].copy()

            # Cleanup
            df_all.drop(columns=["date_only"], inplace=True, errors="ignore")

        except Exception as date_exc:
            logging.warning(f"[DATE FILTER] Failed: {date_exc}")
            import traceback
            logging.info(traceback.format_exc())



    # Early return if filtered data is empty
    if df_all.empty:
        logging.info(f"No data after filtering (started with {original_count} records)")
        response = {
            "flag": True,
            "data": {"total": "0", "Activated": "0", "Suspended": "0", "Active": "0", "title": "Count of SIM Overview"},
        }
        return response

    # STATUS AGGREGATION
    activated_statuses = {"activated", "active", "activate", "a"}
    suspended_statuses = {"suspended", "s"}
    active_statuses = {"active", "activated", "pending activation", "activation ready", "restore suspended", "a", "activate", "suspended", "r", "s"}

    activated_mask = df_all["status_lower"].isin(activated_statuses)
    suspended_mask = df_all["status_lower"].isin(suspended_statuses)
    active_mask = df_all["status_lower"].isin(active_statuses)

    status_counts = {
        "Activated": df_all[activated_mask]["count"].sum(),
        "Suspended": df_all[suspended_mask]["count"].sum(),
        "Active": df_all[active_mask]["count"].sum()
    }

    status_counts = {k: int(v) if pd.notna(v) else 0 for k, v in status_counts.items()}
    sum_of_key_statuses = sum(df_all["count"])

    logging.info(f"Processed {len(df_all)} records. Final counts: {status_counts}, Total: {sum_of_key_statuses}")

    response = {
        "flag": True,
        "data": {
            "total": f"{sum_of_key_statuses:,}",
            "Activated": f"{status_counts['Activated']:,}",
            "Suspended": f"{status_counts['Suspended']:,}",
            "Active": f"{status_counts['Active']:,}",
            "title": "Count of SIM Overview",
        },
    }

    # Audit log on success
    try:
        audit_data = {
            "service_name": "count_of_sim_overview",
            "created_date": request_received_at,
            "created_by": username,
            "status": "Success",
            "tenant_name": tenant_name,
            "comments": f"Retrieved SIM overview for tenant {tenant_name}",
            "module_name": "Dashboard",
            "request_received_at": request_received_at,
            "session_id": sessionID,
        }
        common_utils_database.update_audit(audit_data, "audit_user_actions")
    except Exception as audit_exc:
        logging.error(f"Audit logging failed: {audit_exc}")

    return response



 
def get_sim_count_by_service_provider(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_count_by_service_provider: {data}")
    username= data.get("username", "")
    tenant_name= data.get("tenant_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    try:
        data["path"] = "/get_sim_count_by_service_provider"
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)

 
        if response.status_code != 200:
            try:
                error_json = response.json()
                api_message = error_json.get("message") or \
                            error_json.get("data", {}).get("message", "Unknown API error")
            except Exception:
                api_message = response.text  

            logging.error(f"API Error {response.status_code}: {api_message}")

            return {
                "flag": False,
                "meta": {},
                "data": {},
                "message": api_message
            }
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            res = response.json()

            # unwrap nested structure
            inner = res.get("data", {})
            try:
                audit_data_user_actions = {
                    "module_name": "Dashboard",
                    "created_by": username,
                    "status": "True",
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": tenant_name,
                    "comments": f"Fetched SIM count by service provider successfully through container",
                    "service_name": "get_sim_count_by_service_provider",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### get_sim_count_by_service_provider Exception is {e}")

            return {
                "data": inner.get("data", {}),
                "flag":True,
                "meta": inner.get("meta", {})
            }
            
        except Exception as e: 
            return {"data":{},"meta":{},"message":f"value error as {e}"}
 
    
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        error_type = str(type(e).__name__)
        message=f"Failed to fetch the data through  container "
        try:
            # Log error to database
            error_data = {
                "service_name": "get_sim_count_by_service_provider",
                "created_date": data.get("request_received_at"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at") ,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### get_sim_count_by_service_provider Exception is {e}")
        return {"flag": False, "message": str(e)}
 


def get_sim_activations_by_service_provider(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_activations_by_service_provider: {data}")
    username= data.get("username", "")
    tenant_name= data.get("tenant_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    try:
        data["path"] = "/get_sim_activations_by_service_provider"
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)

 
        if response.status_code != 200:
            try:
                error_json = response.json()
                api_message = error_json.get("message") or \
                            error_json.get("data", {}).get("message", "Unknown API error")
            except Exception:
                api_message = response.text  

            logging.error(f"API Error {response.status_code}: {api_message}")

            return {
                "flag": False,
                "meta": {},
                "data": {},
                "message": api_message
            }
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            res = response.json()

            # unwrap nested structure
            inner = res.get("data", {})
            try:
                audit_data_user_actions = {
                    "module_name": "Dashboard",
                    "created_by": username,
                    "status": "True",
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": tenant_name,
                    "comments": f"Fetched SIM count by service provider successfully through container",
                    "service_name": "get_sim_activations_by_service_provider",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### get_sim_activations_by_service_provider Exception is {e}")


            return {
                "data": inner.get("data", {}),
                "flag":True,
                "meta": inner.get("meta", {})
            }
            
        except Exception as e: 
            return {"data":{},"meta":{},"message":f"value error as {e}"}
 

 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        error_type = str(type(e).__name__)
        message=f"Failed to fetch the data through  container "
        try:
            # Log error to database
            error_data = {
                "service_name": "get_sim_activations_by_service_provider",
                "created_date": data.get("request_received_at"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at") ,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### get_sim_activations_by_service_provider Exception is {e}")
        return {"flag": False, "message": str(e)}
 



def get_service_provider_vs_status(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_service_provider_vs_status: {data}")
    username= data.get("username", "")
    tenant_name= data.get("tenant_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    try:
        data["path"] = "/get_service_provider_vs_status"
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)

 
        
        if response.status_code != 200:
            try:
                error_json = response.json()
                api_message = error_json.get("message") or \
                            error_json.get("data", {}).get("message", "Unknown API error")
            except Exception:
                api_message = response.text  

            logging.error(f"API Error {response.status_code}: {api_message}")

            return {
                "flag": False,
                "meta": {},
                "data": {},
                "message": api_message
            }
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            res = response.json()

            # unwrap nested structure
            inner = res.get("data", {})
            try:
                audit_data_user_actions = {
                    "module_name": "Dashboard",
                    "created_by": username,
                    "status": "True",
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": tenant_name,
                    "comments": f"Fetched SIM count by service provider successfully through container",
                    "service_name": "get_service_provider_vs_status",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### get_service_provider_vs_status Exception is {e}")

            return {
                "data": inner.get("data", {}),
                "flag":True,
                "meta": inner.get("meta", {})
            }
            
        except Exception as e: 
            return {"data":{},"meta":{},"message":f"value error as {e}"}
 

 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        error_type = str(type(e).__name__)
        message=f"Failed to fetch the data through  container "
        try:
            # Log error to database
            error_data = {
                "service_name": "get_service_provider_vs_status",
                "created_date": data.get("request_received_at"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at") ,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### get_service_provider_vs_status Exception is {e}")
        return {"flag": False, "message": str(e)}
 


def update_device_status_s3(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_count_by_service_provider: {data}")
    try:
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)
 
        # Raise HTTP errors automatically (e.g., 404, 500)
        response.raise_for_status()
        print("✅ Response Status:", response.status_code)
        try:
            print("📦 Raw Response JSON:", json.dumps(response.json(), indent=2))
        except ValueError:  # Not JSON
            print("📦 Raw Response Text:", response.text)
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            return response.json()
        except ValueError:
            return response.json()
 
    except requests.RequestException as req_err:
        print(f"⚠️ Request error: {req_err}")
        return {
            "flag": False,"message": str(req_err)
        }
 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return {"flag": False, "message": str(e)}



def store_device_history_excel_in_redis_from_buffer(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_count_by_service_provider: {data}")
    try:
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)
 
        # Raise HTTP errors automatically (e.g., 404, 500)
        response.raise_for_status()
        print("✅ Response Status:", response.status_code)
        try:
            print("📦 Raw Response JSON:", json.dumps(response.json(), indent=2))
        except ValueError:  # Not JSON
            print("📦 Raw Response Text:", response.text)
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            return response.json()
        except ValueError:
            return response.json()
 
    except requests.RequestException as req_err:
        print(f"⚠️ Request error: {req_err}")
        return {
            "flag": False,"message": str(req_err)
        }
 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return {"flag": False, "message": str(e)}



def update_device_history_s3(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_count_by_service_provider: {data}")
    try:
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)
 
        # Raise HTTP errors automatically (e.g., 404, 500)
        response.raise_for_status()
        print("✅ Response Status:", response.status_code)
        try:
            print("📦 Raw Response JSON:", json.dumps(response.json(), indent=2))
        except ValueError:  # Not JSON
            print("📦 Raw Response Text:", response.text)
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            return response.json()
        except ValueError:
            return response.json()
 
    except requests.RequestException as req_err:
        print(f"⚠️ Request error: {req_err}")
        return {
            "flag": False,"message": str(req_err)
        }
 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return {"flag": False, "message": str(e)}



def update_mobility_device_history_s3(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_count_by_service_provider: {data}")
    try:
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)
 
        # Raise HTTP errors automatically (e.g., 404, 500)
        response.raise_for_status()
        print("✅ Response Status:", response.status_code)
        try:
            print("📦 Raw Response JSON:", json.dumps(response.json(), indent=2))
        except ValueError:  # Not JSON
            print("📦 Raw Response Text:", response.text)
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            return response.json()
        except ValueError:
            return response.json()
 
    except requests.RequestException as req_err:
        print(f"⚠️ Request error: {req_err}")
        return {
            "flag": False,"message": str(req_err)
        }
 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return {"flag": False, "message": str(e)}


def create_first_100_records_excel(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_count_by_service_provider: {data}")
    try:
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)
 
        # Raise HTTP errors automatically (e.g., 404, 500)
        response.raise_for_status()
        print("✅ Response Status:", response.status_code)
        try:
            print("📦 Raw Response JSON:", json.dumps(response.json(), indent=2))
        except ValueError:  # Not JSON
            print("📦 Raw Response Text:", response.text)
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            return response.json()
        except ValueError:
            return response.json()
 
    except requests.RequestException as req_err:
        print(f"⚠️ Request error: {req_err}")
        return {
            "flag": False,"message": str(req_err)
        }
 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return {"flag": False, "message": str(e)}



def store_excel_in_redis_from_buffer(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] store_excel_in_redis_from_buffer: {data}")
    try:
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
        print("🌐 URL:", url)
 
        response = requests.post(url, json=data, timeout=30)
        print("📦 Raw Response Text:", response.text)
 
        # Raise HTTP errors automatically (e.g., 404, 500)
        response.raise_for_status()
        print("✅ Response Status:", response.status_code)
        try:
            print("📦 Raw Response JSON:", json.dumps(response.json(), indent=2))
        except ValueError:  # Not JSON
            print("📦 Raw Response Text:", response.text)

        
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            print(response.json(), "response.json()response.json()")
            return response.json()
        except ValueError:
            return response.json()
    
        
 
    except requests.RequestException as req_err:
        print(f"⚠️ Request error: {req_err}")
        return {
            "flag": False,"message": str(req_err)
        }
 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return {"flag": False, "message": str(e)}
 
####################################  sim Overview code ########################

##################### Usage Insights code  ############################ 
import pickle


def get_usage_insights_cache_key(db_name):
    """Returns a cache key string for  usage insights for the specified database."""

    return f"usage_insights_cache:{db_name}"



def update_device_count_s3(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_count_by_service_provider: {data}")
    try:
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)
 
        # Raise HTTP errors automatically (e.g., 404, 500)
        response.raise_for_status()
        print("✅ Response Status:", response.status_code)
        try:
            print("📦 Raw Response JSON:", json.dumps(response.json(), indent=2))
        except ValueError:  # Not JSON
            print("📦 Raw Response Text:", response.text)
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            return response.json()
        except ValueError:
            return response.json()
 
    except requests.RequestException as req_err:
        print(f"⚠️ Request error: {req_err}")
        return {
            "flag": False,"message": str(req_err)
        }
 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return {"flag": False, "message": str(e)} 


def update_device_total_cost_s3(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] get_sim_count_by_service_provider: {data}")
    try:
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)
 
        # Raise HTTP errors automatically (e.g., 404, 500)
        response.raise_for_status()
        print("✅ Response Status:", response.status_code)
        try:
            print("📦 Raw Response JSON:", json.dumps(response.json(), indent=2))
        except ValueError:  # Not JSON
            print("📦 Raw Response Text:", response.text)
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            return response.json()
        except ValueError:
            return response.json()
 
    except requests.RequestException as req_err:
        print(f"⚠️ Request error: {req_err}")
        return {
            "flag": False,"message": str(req_err)
        }
 
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return {"flag": False, "message": str(e)} 


def sync_usage_insight(data):
    """
        Synchronizes usage insights for a tenant by updating the cache, 
        records success or failure in audit tables, and logs any errors.

        Args:
            data (dict): Contains keys like 'function_name', 'username', 'tenant_database','cache_key'.

        Returns:
            dict: {'flag': True/False, 'message': str} indicating success or failure of the sync operation.
    """

    tenant_database = data.get("db_name", "") 
    function_name = "sync_usage_insights"
    cache_key = get_usage_insights_cache_key(tenant_database)
    username = data.get("username", "")
    try:    
        # Use timezone-aware UTC datetime
        request_received_at = data.get("request_received_at", "")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(tenant_database, **db_config)

        #  Run update_usage_cache — if this fails, audits will be skipped
        update_usage_cache(
            database, cache_key, function_name, username, request_received_at, common_utils_database
        )

        # Only if update_usage_cache succeeds, do audits
        try:
            audit_data = {
                "function_name": "refresh_usage_insights_caches",
                "created_by": username,
                "last_synced_by": username,
            }
            common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
        except Exception as audit_exc:
            logging.warning(f"Dashboard cache audit insert failed for {function_name}: {audit_exc}")

        try:
            audit_data = {
                "service_name": function_name,
                "created_date": request_received_at,
                "created_by": username,
                "status": "Success",
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Synced usage insights for tenant {tenant_database}",
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": data.get("sessionID", ""),
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.warning(f"[sync_usage_insights] Audit logging failed: {audit_exc}")

        return {"flag": True, "message": "Synced usage insights successfully"}

    except Exception as exc:
        logging.error(f"[sync_usage_insights] Error: {exc}")
        try:
            error_data = {
                "service_name": function_name,
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": username,
                "tenant_name": data.get("tenant_name", ""),
                "comments": str(exc),
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at", ""),
                "session_id": data.get("sessionID", ""),
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"[sync_usage_insights] Error logging to DB: {log_exc}")
        return {"flag": False, "message": "Error syncing usage insights"}






def update_usage_cache(database, cache_key, function_name, username, request_received_at, common_utils_database):
    """
    Updates Redis cache by fetching data from 5 usage-related stored procedures and
    REPLACING existing cached tables (no appending or deduplication).

    All cached keys are stored in Redis with an expiry (TTL) of 90,000 seconds.
    """

    CACHE_TTL_SECONDS = 90000

    cache_data = {
        "rate_plan_name_customer": pd.DataFrame(),
        "usage_summary_customer": pd.DataFrame(),

        "usage_summary_provider": pd.DataFrame(),
        "usage_summary_by_plan_by_provider_rate_plan": pd.DataFrame(),
        "total_cost_customer":pd.DataFrame(),
        "sync_time": datetime.utcnow(),
    }

    try:
        # ------------------- Skipping LOAD of existing cache -------------------
        # We will always REPLACE the cached tables with fresh data from the database.
        table_keys = [
            "rate_plan_name_customer",
            "usage_summary_customer",
            "usage_summary_provider",
            "usage_summary_by_plan_by_provider_rate_plan",
            "total_cost_customer"
        ]
        # initialize old_data as empty frames (kept for compatibility but not used for fallback)
        old_data = {k: pd.DataFrame() for k in table_keys}

        # ------------------- Fetch new data from DB -------------------
        queries = {
            "rate_plan_name_customer": "SELECT * FROM fn_get_rate_plan_name_by_customer;",
            "usage_summary_customer": "SELECT * FROM fn_get_usage_summary_by_plan_by_provider;",
            "usage_summary_provider": "SELECT * FROM fn_get_usage_summary_by_plan_by_provider;",
            "usage_summary_by_plan_by_provider_rate_plan": "SELECT * FROM fn_get_usage_summary_by_plan_by_provider_rate_plan;",
            "total_cost_customer": """select * from get_usage_by_rate_plan_by_provider"""
        }

        for key, sql in queries.items():
            df = database.execute_query(sql, True)

            if isinstance(df, pd.DataFrame) and not df.empty:
                logging.info(f"\n--- {key.upper()} ---")
                logging.info(f"Columns: {list(df.columns)}")
                logging.info(f"Total rows: {len(df)}")

                # Data type conversions
                if "device_count" in df.columns:
                    # df["device_count"] = pd.to_numeric(df.get("device_count", 0), errors="coerce").fillna(0)

                    df["device_count"] = pd.to_numeric(df["device_count"], errors="coerce").fillna(0)
                else:
                    df["device_count"] = 0

                logging.info("device_count column dtype: %s", df["device_count"].dtype)
                if "total_data_usage" in df.columns:
                    df["total_data_usage"] = pd.to_numeric(df.get("total_data_usage", 0), errors="coerce").fillna(0)
                if "usage_day" in df.columns:
                    df["usage_day"] = df["usage_day"].astype(str)
                if "usage_hour_group" in df.columns:
                    df["usage_hour_group"] = df["usage_hour_group"].astype(str)
                if "total_cost" in df.columns:
                    df["total_cost"] = pd.to_numeric(df.get("total_cost", 0), errors="coerce").fillna(0)

                # if "total_cost" in df.columns:
                #     df["total_cost"] = df["total_cost"].apply(lambda x: Decimal(str(x)) if x is not None else Decimal("0"))
                    


                # REPLACE behavior for all tables (no append)
                cache_data[key] = df
                logging.info(f"REPLACED cache for {key} with {len(df)} rows")
            else:
                logging.info(f"\n--- {key.upper()} ---")
                logging.info("No new data retrieved from database; keeping previous cache")
                cache_data[key] = old_data[key]

        logging.info("\n=== FINAL CACHE SUMMARY ===")
        for key in table_keys:
            total_rows = len(cache_data[key])
            logging.info(f"{key} (REPLACE): {total_rows} total rows in cache")

        # ------------------- Store each table separately in Redis with TTL -------------------
        try:
            for key in table_keys:
                if not cache_data[key].empty:
                    # Print max usage_day before pickling
                    if "usage_day" in cache_data[key].columns:
                        try:
                            max_usage_day = cache_data[key]["usage_day"].max()
                            logging.info(f"[MAX_USAGE_DAY] {key}: {max_usage_day} and {len(cache_data[key])} rows")
                        except Exception as e:
                            logging.warning(f"Could not determine max usage_day for {key}: {e}")

                    # Pickle is much faster than JSON for serialization/deserialization
                    pickled_data = pickle.dumps(cache_data[key], protocol=pickle.HIGHEST_PROTOCOL)
                    logging.info(f"{cache_key}:{key} saving to redis (with TTL={CACHE_TTL_SECONDS}s)")

                    # Use set with expiration so cached data expires after CACHE_TTL_SECONDS
                    try:
                        redis_client.set(f"{cache_key}:{key}", pickled_data, ex=CACHE_TTL_SECONDS)
                    except TypeError as e:
                        logging.info(f"❌ Redis set() failed for key {cache_key}:{key} -> {e}")
                        # Some redis clients (older) use setex
                        redis_client.setex(f"{cache_key}:{key}", CACHE_TTL_SECONDS, pickled_data)

                    size_mb = len(pickled_data) / (1024 ** 2)
                    logging.info(f"Stored {key}: {size_mb:.2f} MB (expires in {CACHE_TTL_SECONDS}s)")

            logging.info(f"Redis set successful for all tables: {cache_key}")

        except Exception as redis_exc:
            logging.warning(f"Redis set failed: {redis_exc}")

        # ------------------- Audit Logging -------------------
        try:
            audit_data = {
                "function_name": function_name,
                "created_by": username,
                "last_synced_by": username,
                "last_sync_date": cache_data["sync_time"],
            }
            common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
        except Exception as audit_exc:
            logging.warning(f"Audit logging failed: {audit_exc}")

        return cache_data

    except Exception as e:
        logging.error(f"Error updating usage cache: {e}")
        raise e

           

           




def get_usage_data_from_cache(cache_key, use_carrier, return_rate_plan_name=False, return_usage_summary_by_plan=False,return_total_cost_updated=False):
    """
    Get usage data from Redis cache.
    
    If return_rate_plan_name is True, returns rate_plan_name_* data.
    Otherwise, returns usage_summary_* data.
    
    Returns tuple: (result_df, cache_miss)
    """
    try:
        # Track total time
        total_start = time.time()
        try:
            redis_client.ping()
            print("✅ Redis is connected.")
        except Exception as e:
            print(f"❌ Redis connection failed: {e}")


        # Determine which table to load
        if return_total_cost_updated:
            data_key = "total_cost_customer"
        elif return_usage_summary_by_plan:
            data_key = "usage_summary_by_plan_by_provider_rate_plan"
        else:
            data_key = "usage_summary_provider" if use_carrier else "usage_summary_customer"

        # 1. Redis fetch - load ONLY the specific table
        start = time.time()
        # logging.info(f"{cache_key}:{data_key}", "fetching from redis")
        logging.info(f"{cache_key}:{data_key} - fetching from redis")
        # logging.info(redis_client, "redis_clientredis_clientredis_clientredis_client")
        logging.info(f"Redis client: {redis_client}")
        cached_data = redis_client.get(f"{cache_key}:{data_key}")
        end = time.time()
        logging.info(f"[TIME] Redis fetch (single table) took: {end - start:.4f} sec")

        if not cached_data:
            logging.info(f"[TIME]  execution time: {time.time() - total_start:.4f} sec")
            return pd.DataFrame(), True

        # 2. Unpickle directly to DataFrame - MUCH faster than JSON
        start = time.time()
        result_df = pickle.loads(cached_data)
        end = time.time()
        logging.info(f"[TIME] Pickle load (DataFrame ready) took: {end - start:.4f} sec")

        # Print max usage_day after unpickling
        if not result_df.empty and "usage_day" in result_df.columns:
            try:
                max_usage_day = result_df["usage_day"].max()
                logging.info(f"[MAX_USAGE_DAY] {data_key}: {max_usage_day} and {len(result_df)} rows")
                logging.info(f"Max usage_day for {data_key}: {max_usage_day}")
            except Exception as e:
                logging.warning(f"Could not determine max usage_day for {data_key}: {e}")

        logging.info(f"[TIME] Total execution time: {time.time() - total_start:.4f} sec")
        logging.info(f"[INFO] Loaded {len(result_df)} rows, {result_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        
        return result_df, False

    except Exception as redis_exc:
        logging.warning(f"Redis fetch error: {redis_exc}")
        return pd.DataFrame(), True
    


def total_usage_card(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] total_usage_cost: {data}")
    username= data.get("username", "")
    tenant_name= data.get("tenant_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    try:
        data["path"] = "/total_usage_card"
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)

 
        if response.status_code != 200:
            try:
                error_json = response.json()
                api_message = error_json.get("message") or \
                            error_json.get("data", {}).get("message", "Unknown API error")
            except Exception:
                api_message = response.text  

            logging.error(f"API Error {response.status_code}: {api_message}")

            return {
                "flag": False,
                "meta": {},
                "data": {},
                "message": api_message
            }
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            res = response.json()

            # unwrap nested structure
            inner = res.get("data", {})

            # Audit Log
            try:
                audit_data_user_actions = {
                    "module_name": "Dashboard",
                    "created_by": username,
                    "status": "True",
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": tenant_name,
                    "comments": "Fetched usage cost successfully through container",
                    "service_name": "total_usage_gb",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### total_usage_gb Exception is {e}")

            # TOTAL USAGE COST FROM CONTAINER (THIS IS CORRECT)
            total_usage_gb = inner.get("data", {}).get("total_usage_gb", 0)
            logging.info(f"### TOTAL USAGE COST FROM CONTAINER: {total_usage_gb}")

            return {
                "flag": True,
                "data": {
                    "total_usage_gb": total_usage_gb,
                    "title": "Total Usage (GB)",
                },
                "meta": res.get("meta", {}),
                "message": "Success"
            }
     
        except Exception as e: 
            return {"data":{},"meta":{},"message":f"value error as {e}"}
 
    
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        error_type = str(type(e).__name__)
        message=f"Failed to fetch the data through  container "
        try:
            # Log error to database
            error_data = {
                "service_name": "total_usage_cost",
                "created_date": data.get("request_received_at"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at") ,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### total_usage_cost Exception is {e}")
        return {"flag": False, "message": str(e)}



def total_usage_sims_count(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] total_usage_sims_count: {data}")
    username= data.get("username", "")
    tenant_name= data.get("tenant_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    try:
        data["path"] = "/total_usage_sims_count"
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)

 
        if response.status_code != 200:
            try:
                error_json = response.json()
                api_message = error_json.get("message") or \
                            error_json.get("data", {}).get("message", "Unknown API error")
            except Exception:
                api_message = response.text  

            logging.error(f"API Error {response.status_code}: {api_message}")

            return {
                "flag": False,
                "meta": {},
                "data": {},
                "message": api_message
            }
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            res = response.json()

            # unwrap nested structure
            inner = res.get("data", {})
            try:
                audit_data_user_actions = {
                    "module_name": "Dashboard",
                    "created_by": username,
                    "status": "True",
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": tenant_name,
                    "comments": f"Fetched usage sim count successfully through container",
                    "service_name": "total_usage_sims_count",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### total_usage_sims_count Exception is {e}")

            usage_count = inner.get("data", {}).get("usage_sims_count", 0)

            # format number as 1,000,000
            formatted_count = f"{int(usage_count):,}" if str(usage_count).isdigit() else usage_count

            return {
                "flag": True,
                "data": {
                    "usage_sims_count": formatted_count,
                    "usage_type": inner.get("data", {}).get("usage_type", "s3_parquet_unique_devices"),
                    "title": "Total Usage SIMs Count"
                },
                "message": ""
            }

            
        except Exception as e: 
            return {"data":{},"meta":{},"message":f"value error as {e}"}
 
    
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        error_type = str(type(e).__name__)
        message=f"Failed to fetch the data through  container "
        try:
            # Log error to database
            error_data = {
                "service_name": "total_usage_sims_count",
                "created_date": data.get("request_received_at"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at") ,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### total_usage_sims_count Exception is {e}")
        return {"flag": False, "message": str(e)}
 




def total_usage_cost(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] total_usage_cost: {data}")
    username= data.get("username", "")
    tenant_name= data.get("tenant_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    try:
        data["path"] = "/total_usage_cost"
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)

 
        if response.status_code != 200:
            try:
                error_json = response.json()
                api_message = error_json.get("message") or \
                            error_json.get("data", {}).get("message", "Unknown API error")
            except Exception:
                api_message = response.text  

            logging.error(f"API Error {response.status_code}: {api_message}")

            return {
                "flag": False,
                "meta": {},
                "data": {},
                "message": api_message
            }
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            res = response.json()

            # unwrap nested structure
            inner = res.get("data", {})

            # Audit Log
            try:
                audit_data_user_actions = {
                    "module_name": "Dashboard",
                    "created_by": username,
                    "status": "True",
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": tenant_name,
                    "comments": "Fetched usage cost successfully through container",
                    "service_name": "total_usage_cost",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### total_usage_cost Exception is {e}")

            # TOTAL USAGE COST FROM CONTAINER (THIS IS CORRECT)
            total_usage_cost = inner.get("data", {}).get("total_usage_cost", 0)
            logging.info(f"### TOTAL USAGE COST FROM CONTAINER: {total_usage_cost}")

            return {
                "data": {
                    "total_usage_cost": total_usage_cost,
                    "title": "Total Usage Cost"
                },
                "meta": res.get("meta", {}),
                "message": "Success"
            }
     
        except Exception as e: 
            return {"data":{},"meta":{},"message":f"value error as {e}"}
 
    
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        error_type = str(type(e).__name__)
        message=f"Failed to fetch the data through  container "
        try:
            # Log error to database
            error_data = {
                "service_name": "total_usage_cost",
                "created_date": data.get("request_received_at"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at") ,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### total_usage_cost Exception is {e}")
        return {"flag": False, "message": str(e)}
 




def average_usage_card(data):
    """
    Retrieves cumulative SIM counts per service provider over multiple time ranges.
   
    - Provider IDs used in output (provider_id).
    - Month-based buckets (1_month, 3_month, 6_month, 1_year) are split into weekly cutoffs:
        Week 1 => days 1–7
        Week 2 => days 8–14
        Week 3 => days 15–21
        Week 4 => days 22–EOM
      For the current month, the ongoing partial week is represented by 'today' (included).
    - 5_years: yearly cutoffs (past years = Dec 31, current year = today)
    - max: also uses yearly cutoffs (past years = Dec 31, current year = today)
   
    Keeps Redis cache, audit logging, filters, and output format as before.
   
    Returns:
        dict: The JSON response from the remote Dashboard handler if successful.
        None: If the request fails or no response is returned.
    """
    logging.info(f"[START] total_usage_cost: {data}")
    username= data.get("username", "")
    tenant_name= data.get("tenant_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    try:
        data["path"] = "/average_usage_card"
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("EC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"
 
        response = requests.post(url, json=data, timeout=30)

 
        if response.status_code != 200:
            try:
                error_json = response.json()
                api_message = error_json.get("message") or \
                            error_json.get("data", {}).get("message", "Unknown API error")
            except Exception:
                api_message = response.text  

            logging.error(f"API Error {response.status_code}: {api_message}")

            return {
                "flag": False,
                "meta": {},
                "data": {},
                "message": api_message
            }
    
        # Try to parse JSON; fallback to text if not valid JSON
        try:
            res = response.json()

            # unwrap nested structure
            inner = res.get("data", {})

            # Audit Log
            try:
                audit_data_user_actions = {
                    "module_name": "Dashboard",
                    "created_by": username,
                    "status": "True",
                    "session_id": data.get("sessionID", ""),
                    "tenant_name": tenant_name,
                    "comments": "Fetched usage cost successfully through container",
                    "service_name": "average_usage_gb",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### average_usage_gb Exception is {e}")

            # TOTAL USAGE COST FROM CONTAINER (THIS IS CORRECT)
            average_usage_gb = inner.get("data", {}).get("average_usage_gb", 0)
            logging.info(f"### TOTAL USAGE COST FROM CONTAINER: {total_usage_cost}")

            return {
                "flag": True,
                "data": {
                    "average_usage_gb": average_usage_gb,
                    "title": "Average Usage per SIM (GB)"
                },
                "meta": res.get("meta", {}),
                "message": "Success"
            }
     
        except Exception as e: 
            return {"data":{},"meta":{},"message":f"value error as {e}"}
 
    
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        error_type = str(type(e).__name__)
        message=f"Failed to fetch the data through  container "
        try:
            # Log error to database
            error_data = {
                "service_name": "total_usage_cost",
                "created_date": data.get("request_received_at"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": "Dashboard",
                "request_received_at": data.get("request_received_at") ,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### total_usage_cost Exception is {e}")
        return {"flag": False, "message": str(e)}





def generate_bucket_ranges(tenant_time_zone, df, date_column='modified_date', min_date=None):
    """Generates predefined date bucket ranges (daily, weekly, monthly, yearly) based on a DataFrame and minimum date."""
    # NEW: Calculate 'now' and 'today' in tenant timezone for 1_day bucket
    try:
        tz = pytz.timezone(tenant_time_zone or "UTC")
        today = datetime.now(tz).date()   # same as old .date(), but tenant timezone applied
        logging.info(f"### Using tenant timezone {tenant_time_zone}: today={today}")
    except Exception as e:
        logging.warning(f"Failed to get tenant timezone: {e}. Using UTC.")
        today = datetime.now().date()
   
   
    if min_date is None and not df.empty:
        min_date = df[date_column].min()
    if min_date is None:
        min_date = today
    if hasattr(min_date, 'date'):
        min_date = min_date.date()
    start_1_year = (today.replace(day=1) - relativedelta(months=11))

    ranges = {
        '1_day': {'start': today, 'end': today, 'type': 'hourly'},
        '5_day': {'start': today - timedelta(days=4), 'end': today, 'type': 'daily'},
        '1_month': {'start': today.replace(day=1), 'end': today, 'type': 'weekly'},
        '3_month': {'start': (today.replace(day=1) - timedelta(days=60)).replace(day=1), 'end': today, 'type': 'weekly'},
        '6_month': {'start': (today.replace(day=1) - timedelta(days=150)).replace(day=1), 'end': today, 'type': 'weekly'},
        '1_year': {'start': start_1_year, 'end': today, 'type': 'weekly'},
        '5_years': {'start': today.replace(year=today.year-4, month=1, day=1), 'end': today, 'type': 'yearly'},
        'max': {'start': min_date, 'end': today, 'type': 'yearly'},
        'custom_range': {'start': min_date, 'end': today, 'type': 'weekly'}
    }
    return ranges, '1_month'


def assign_week_label(day):
    """Return the week number in a month (1-4)"""
    d = day.day
    if d <= 7:
        return 1
    elif d <= 14:
        return 2
    elif d <= 21:
        return 3
    elif d <= 28:
        return 4
    else:
        return 5



def process_grouped(df_filtered, bucket_type):
    """
    Groups usage data by bucket_type.
    Returns:
    { (tenant_id, provider_id): [ {time_key: usage_gb}, ... ] }
    """

    grouped = defaultdict(list)

    # Ensure usage_day is datetime ONCE
    if 'usage_day' in df_filtered.columns:
        df_filtered = df_filtered.copy()
        df_filtered['usage_day'] = pd.to_datetime(
            df_filtered['usage_day'],
            errors='coerce'
        )

    # -------------------------
    # HOURLY
    # -------------------------
    if bucket_type == 'hourly':
        grouped_df = (
            df_filtered
            .groupby(
                [
                    'tenant_id',
                    'service_provider_id',
                    'service_provider_display_name',
                    'usage_hour_group'
                ],
                as_index=False
            )['usage_gb']
            .sum()
        )

        for _, row in grouped_df.iterrows():
            grouped[(int(row.tenant_id), int(row.service_provider_id))].append(
                {str(row.usage_hour_group): float(row.usage_gb)}
            )
            
    # -------------------------
    # DAILY
    # -------------------------
    elif bucket_type == 'daily':
        grouped_df = (
            df_filtered
            .groupby(
                [
                    'tenant_id',
                    'service_provider_id',
                    'service_provider_display_name',
                    'usage_day'
                ],
                as_index=False
            )['usage_gb']
            .sum()
        )

        for _, row in grouped_df.iterrows():
            grouped[(int(row.tenant_id), int(row.service_provider_id))].append(
                {row.usage_day.strftime('%Y-%m-%d'): float(row.usage_gb)}
            )

    # -------------------------
    # WEEKLY ✅ FIXED
    # -------------------------
    elif bucket_type == 'weekly':
        df_copy = df_filtered.copy()

        # Canonical week end (Sunday)
        df_copy['week_end'] = (
            df_copy['usage_day']
            - pd.to_timedelta(df_copy['usage_day'].dt.weekday, unit='D')
            + pd.Timedelta(days=6)
        )

        grouped_df = (
            df_copy
            .groupby(
                ['tenant_id', 'service_provider_id', 'week_end'],
                as_index=False
            )['usage_gb']
            .sum()
        )

        # Hard guard against double counting
        assert not grouped_df.duplicated(
            ['tenant_id', 'service_provider_id', 'week_end']
        ).any(), "Duplicate provider/week detected"

        for _, row in grouped_df.iterrows():
            grouped[(int(row.tenant_id), int(row.service_provider_id))].append(
                {row.week_end.strftime('%Y-%m-%d'): float(row.usage_gb)}
            )

    # -------------------------
    # YEARLY
    # -------------------------
    elif bucket_type == 'yearly':
        df_copy = df_filtered.copy()
        df_copy['year'] = df_copy['usage_day'].dt.year

        grouped_df = (
            df_copy
            .groupby(
                ['tenant_id', 'service_provider_id', 'year'],
                as_index=False
            )['usage_gb']
            .sum()
        )

        for _, row in grouped_df.iterrows():
            grouped[(int(row.tenant_id), int(row.service_provider_id))].append(
                {str(int(row.year)): float(row.usage_gb)}
            )

    return grouped

def get_matching_bucket(bucket_ranges, start_date, end_date):
    """
    Decide which predefined bucket a given date range belongs to.
    Matches bucket definitions from generate_bucket_ranges
    """
    logging.info(f"get_matching_bucket: start_date: {start_date}, end_date: {end_date}")
    start_ts = pd.to_datetime(start_date)
    end_ts = pd.to_datetime(end_date)
    date_diff = (end_ts - start_ts).days + 1
    logging.info(f"date_diff: {date_diff}")
    
    # Match based on the bucket definitions:
    # '1_day': today to today (1 day)
    # '5_day': today-4 to today (5 days)
    # '1_month': first of month to today (varies, ~28-31 days)
    # '3_month': ~90 days
    # '6_month': ~180 days
    # '1_year': ~365 days
    
    if date_diff == 1:  # Single day
        return "1_day"
    elif 2 <= date_diff <= 5:  # 2-5 days
        return "5_day"
    elif 5 <= date_diff <= 7:  # 2-5 days
        return "5_day"
    elif 5 <= date_diff <= 32:  # Up to 1 month
        return "1_month"
    elif 32 <= date_diff <= 93:  # Up to 3 months
        return "3_month"
    elif 94 <= date_diff <= 186:  # Up to 6 months
        return "6_month"
    elif 187 <= date_diff <= 366:  # Up to 1 year
        return "1_year"
    elif 367 <= date_diff <= 1826:  # Up to 5 years
        return "5_years"
    else:
        return "max"  


def safe_date_parse(date_str):
    """Helper function to safely parse dates"""
    if not date_str:
        return None
    try:
        return datetime.strptime(str(date_str), "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None    
    



def get_usage_trend_by_provider(data):
    """
        Retrieves usage trends by service provider for a tenant, optionally filtered by date, tenant, service provider, 
        or billing cycle. It handles caching, bucketed aggregation (daily/weekly/monthly/yearly), and audit/error logging.

        Args:
            data (dict): Contains keys such as:
                - 'db_name' (str): Tenant database name.
                - 'tenant_name' (str, optional): Tenant display name.
                - 'tenant_id' (str/int, optional): Tenant ID filter.
                - 'start_date', 'end_date' (str/datetime, optional): Date range for filtering.
                - 'service_provider' (str, optional): Filter for a specific provider.
                - 'billing_cycle_end_period' (str, optional): Filter by billing cycle end date.
                - 'refresh' (bool/str, optional): Force cache refresh.
                - 'username', 'sessionID', 'request_received_at' (str, optional): Audit info.

        Returns:
            dict: Response containing:
                - 'flag' (bool): True if successful, False on error.
                - 'data' (dict): Chart configuration and aggregated usage data.
                - 'meta' (dict): Tenant and provider metadata, default time range.
                - 'message' (str, optional): Error message if operation failed.
    """

    response = {
        "flag": False,
        "data": {
            "title": "Usage Trend",
            "chart_type": "stacked_bar",
            "data": [],
            "xField": "time",
            "yField": "usage_gb",
            "smooth": True,
            "height": 300,
            "width": 500,
        }
    }

    FUNCTION_NAME = "get_usage_trend_by_provider"
    logging.info(f"[{FUNCTION_NAME}] START")

    try:
        params = {
            'tenant_name': str(data.get("tenant_name", "")),
            'tenant_id': str(data.get("tenant_id", "")),
            'db_name': str(data.get("db_name", "")),
            'start_date': safe_date_parse(data.get("start_date")),
            'end_date': safe_date_parse(data.get("end_date")),
            'refresh': str(data.get("refresh", "False")).lower() == "true",
            'username': str(data.get("username", "")),
            'sessionID': str(data.get("sessionID", "")),
            'request_received_at': str(data.get("request_received_at", "")),
            'billing_cycle_end_period': str(data.get("billing_cycle_end_period", "")),
            'service_provider': str(data.get("service_provider", "")),
        }

        if params['start_date']:
            params['start_date'] = pd.to_datetime(params['start_date'])
        if params['end_date']:
            params['end_date'] = pd.to_datetime(params['end_date'])

        if not params['db_name']:
            response["message"] = "Database name is required"
            return response

        database = DB(params['db_name'], **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
        except Exception:
            tenant_time_zone = "UTC"

        cache_key = get_usage_insights_cache_key(params['db_name'])

        if params['refresh']:
            cache_data = update_usage_cache(
                database, cache_key, FUNCTION_NAME,
                params['username'], params['request_received_at'], common_utils_database
            )
            df = cache_data.get("usage_summary_provider", pd.DataFrame())
        else:
            df, cache_miss = get_usage_data_from_cache(cache_key, False)
            if cache_miss:
                cache_data = update_usage_cache(
                    database, cache_key, FUNCTION_NAME,
                    params['username'], params['request_received_at'], common_utils_database
                )
                df = cache_data.get("usage_summary_provider", pd.DataFrame())

        if df.empty:
            response["flag"] = True
            response["message"] = "No data available"
            return response

        df = df.copy()
        df['usage_day'] = pd.to_datetime(df['usage_day'], errors='coerce')
        df['usage_gb'] = (df['total_data_usage'] / 1024).round(2)

        # =====================
        # FILTERING
        # =====================
        df_filtered = df.copy()

        if params['tenant_id'] and params['tenant_id'] != "All":
            df_filtered = df_filtered[df_filtered['tenant_id'] == int(params['tenant_id'])]

        # -------- PROVIDER FILTER (FIXED) --------
        allowed_provider_ids = None
        if params['service_provider']:
            provider_mask = (
                df_filtered['service_provider_display_name']
                .str.lower()
                .eq(params['service_provider'].lower())
            )

            if not provider_mask.any():
                provider_mask = df_filtered['service_provider_display_name'] \
                    .str.contains(params['service_provider'], case=False, na=False)

            df_filtered = df_filtered[provider_mask]

            allowed_provider_ids = (
                df_filtered['service_provider_id']
                .dropna()
                .unique()
                .tolist()
            )

        billing_start_date = billing_end_date = None
        if params['billing_cycle_end_period'] and params['billing_cycle_end_period'] != "All":
            billing_end_date = pd.to_datetime(params['billing_cycle_end_period'])
            billing_start_date = billing_end_date - pd.DateOffset(months=1)
            df_filtered = df_filtered[
                (df_filtered['usage_day'] >= billing_start_date) &
                (df_filtered['usage_day'] <= billing_end_date)
            ]

        if params['start_date'] and params['end_date']:
            df_filtered = df_filtered[
                (df_filtered['usage_day'] >= params['start_date']) &
                (df_filtered['usage_day'] <= params['end_date'])
            ]

        if df_filtered.empty:
            response["flag"] = True
            response["message"] = "No data available (all data filtered out)"
            return response

        # =====================
        # BUCKETING
        # =====================
        min_date = df_filtered['usage_day'].min()
        bucket_ranges, default_label = generate_bucket_ranges(
            tenant_time_zone, df_filtered, 'usage_day', min_date
        )

        for cfg in bucket_ranges.values():
            cfg['start'] = pd.to_datetime(cfg.get('start'))
            cfg['end'] = pd.to_datetime(cfg.get('end'))

        all_buckets = {label: [] for label in bucket_ranges}

        provider_names = (
            df_filtered[['service_provider_id', 'service_provider_display_name']]
            .drop_duplicates()
            .set_index('service_provider_id')['service_provider_display_name']
            .to_dict()
        )

        meta_providers = {int(k): str(v) for k, v in provider_names.items()}
        meta_tenants = {}

        def apply_provider_guard(df_slice):
            if allowed_provider_ids is not None:
                return df_slice[df_slice['service_provider_id'].isin(allowed_provider_ids)]
            return df_slice

        # -------- RANGE HANDLING --------
        if params['start_date'] and params['end_date']:
            label = get_matching_bucket(bucket_ranges, params['start_date'], params['end_date']) or default_label
            cfg = bucket_ranges[label]

            df_range = apply_provider_guard(df_filtered[
                (df_filtered['usage_day'] >= params['start_date']) &
                (df_filtered['usage_day'] <= params['end_date'])
            ])

            grouped = process_grouped(df_range, cfg['type'])

            for (tid, pid), records in grouped.items():
                all_buckets[label].append({
                    "tenant_id": int(tid),
                    "provider_id": int(pid),
                    "records": serialize_data(records)
                })
                meta_tenants[int(tid)] = ""

        elif billing_start_date and billing_end_date:
            label = get_matching_bucket(bucket_ranges, billing_start_date, billing_end_date) or default_label
            cfg = bucket_ranges[label]

            df_range = apply_provider_guard(df_filtered[
                (df_filtered['usage_day'] >= billing_start_date) &
                (df_filtered['usage_day'] <= billing_end_date)
            ])

            grouped = process_grouped(df_range, cfg['type'])

            for (tid, pid), records in grouped.items():
                all_buckets[label].append({
                    "tenant_id": int(tid),
                    "provider_id": int(pid),
                    "records": serialize_data(records)
                })
                meta_tenants[int(tid)] = ""

        else:
            for label, cfg in bucket_ranges.items():
                df_range = apply_provider_guard(df_filtered[
                    (df_filtered['usage_day'] >= cfg['start']) &
                    (df_filtered['usage_day'] <= cfg['end'])
                ])

                grouped = process_grouped(df_range, cfg['type'])

                for (tid, pid), records in grouped.items():
                    all_buckets[label].append({
                        "tenant_id": int(tid),
                        "provider_id": int(pid),
                        "records": serialize_data(records)
                    })
                    meta_tenants[int(tid)] = ""

        if meta_tenants:
            tenant_ids = list(meta_tenants.keys())
            query = f"""
                SELECT id AS tenant_id, tenant_name
                FROM tenant
                WHERE id IN ({','.join(['%s'] * len(tenant_ids))})
            """
            tenant_df = common_utils_database.execute_query(query, params=tenant_ids)
            if isinstance(tenant_df, pd.DataFrame) and not tenant_df.empty:
                meta_tenants.update(
                    tenant_df.set_index('tenant_id')['tenant_name'].astype(str).to_dict()
                )

        response.update({
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": default_label,
            },
            "data": {
                "title": "Usage Trend",
                "chart_type": "stacked_bar",
                "xField": "time",
                "yField": "usage_gb",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            }
        })

        # Audit logging
        try:
            audit_data = {
                "service_name": FUNCTION_NAME,
                "created_by": params['username'],
                "status": "Success",
                "tenant_name": params['tenant_name'],
                "comments": f"Retrieved usage trend by provider for tenant {params['tenant_name']}",
                "module_name": "Dashboard",
                "request_received_at": params['request_received_at'],
                "session_id": params['sessionID'],
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.exception(f"[{FUNCTION_NAME}] Error logging audit: {str(e)}")

        logging.info(f"\n{'='*80}")
        logging.info(f"[{FUNCTION_NAME}] SUCCESS - Returning data")
        logging.info(f"{'='*80}")
        
        return response

    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}"
        logging.error(f"[{FUNCTION_NAME}] {error_msg}", exc_info=True)
        response["message"] = f"Error retrieving usage trend by provider: {error_msg}"
        
        try:
            if 'common_utils_database' in locals():
                error_data = {
                    "service_name": FUNCTION_NAME,
                    "created_date": params.get('request_received_at', ''),
                    "error_message": str(e),
                    "error_type": type(e).__name__,
                    "users": params['username'],
                    "tenant_name": params['tenant_name'],
                    "comments": str(e),
                    "module_name": "Dashboard",
                    "request_received_at": params['request_received_at'],
                    "session_id": params['sessionID'],
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"[{FUNCTION_NAME}] Failed to log error: {str(log_err)}")
        
        return response



def get_service_type_usage_distribution(data):
    
    """
        Retrieves service type usage distribution for tenants and service providers, performs filtering by tenant, service provider, 
        billing cycle, and date range, computes bucketed aggregations (daily/weekly/monthly/yearly), calculates percentage usage per period, 
        and returns data in a JSON-serializable format suitable for charting.

        Args:
            data (dict): Input parameters including:
                - 'db_name' (str): Tenant database name.
                - 'tenant_name' (str, optional): Display name of the tenant.
                - 'tenant_id' (str/int, optional): Tenant ID filter.
                - 'start_date', 'end_date' (str, optional): Date range for filtering.
                - 'service_provider' (str, optional): Filter by provider name.
                - 'billing_cycle_end_period' (str, optional): Filter by billing cycle end date.
                - 'refresh' (bool/str, optional): Force cache refresh.
                - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.

        Returns:
            dict: JSON-serializable response containing:
                - 'flag' (bool): True if successful, False on error.
                - 'meta' (dict): Tenant and provider metadata, default time range.
                - 'data' (dict): Chart-ready data with bucketed usage percentages.
                - 'message' (str): Error message if applicable.
    """

    response = {
        "flag": False,
        "data": {
            "title": "Service Type Usage Distribution",
            "chart_type": "stacked_bar",
            "data": {},
            "xField": "date",
            "yField": "usage",
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": ""
    }
    try:
        # Initialization and input parsing
        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "")
        tenant_database = data.get("db_name", "")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        request_received_at = data.get("request_received_at", "")
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = str(data.get("service_provider", ""))
        billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"
        function = "get_service_type_usage_distribution"
        cache_key = get_usage_insights_cache_key(tenant_database)
        billing_start_date=None
        billing_end_date=None
        use_customer = False  # placeholder

        # Fetch data
        if refresh:
            cache_data = update_usage_cache(database, cache_key, function, username, request_received_at, common_utils_database)
            result_df = cache_data["usage_summary_provider"] if use_customer else cache_data["usage_summary_customer"]
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_customer)
            if cache_miss:
                cache_data = update_usage_cache(database, cache_key, function, username, request_received_at, common_utils_database)
                result_df = cache_data["usage_summary_provider"] if use_customer else cache_data["usage_summary_customer"]

        # Convert to DataFrame
        df_all = pd.DataFrame(result_df) if not result_df.empty else pd.DataFrame()
        
        if not df_all.empty:
            df_all['usage_day'] = pd.to_datetime(df_all['usage_day']).dt.date
            
            # Rename column total_data_usage → usage_gb for shared functions
            if 'total_data_usage' in df_all.columns:
                df_all = df_all.rename(columns={'total_data_usage': 'usage_gb'})
            
            # CRITICAL FIX: Filter out negative usage values BEFORE any calculations
            if 'usage_gb' in df_all.columns:
                logging.info(f"### Before filtering negative values - row count: {len(df_all)}")
                negative_count = (df_all['usage_gb'] < 0).sum()
                if negative_count > 0:
                    logging.warning(f"### Found {negative_count} rows with negative usage_gb values - filtering them out")
                    logging.warning(f"### Negative values: {df_all[df_all['usage_gb'] < 0]['usage_gb'].tolist()}")
                df_all = df_all[df_all['usage_gb'] >= 0]
                logging.info(f"### After filtering negative values - row count: {len(df_all)}")
            
            if tenant_id != "All":
                df_all = df_all[df_all['tenant_id'] == int(tenant_id)]
            if start_date and end_date:
                df_all = df_all[(df_all['usage_day'] >= start_date) & (df_all['usage_day'] <= end_date)]
            if service_provider and service_provider != "All":
                try:
                    df_all = df_all[df_all['service_provider_display_name'] == service_provider]
                    if df_all.empty:
                        response["message"] = "No data available for specified service provider"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Service provider filtering error: {str(e)}"
                    return response

            # Filter by billing cycle end date if provided
            logging.info(f"### billing_cycle_end_period:{billing_cycle_end_period}")
            if billing_cycle_end_period and billing_cycle_end_period != "All":
                try:
                    # Convert timestamp string to pandas Timestamp (keeps timezone/format robustness)
                    billing_end_pd = pd.to_datetime(billing_cycle_end_period)
                    billing_end_date = billing_end_pd.date()

                    # Compute the start date one month earlier, preserving similar day-of-month semantics.
                    # pd.DateOffset(months=1) handles shorter months (e.g., Mar 31 -> Feb 28).
                    billing_start_pd = billing_end_pd - pd.DateOffset(months=1)
                    billing_start_date = billing_start_pd.date()

                    # Filter df_all for the inclusive range [billing_start_date, billing_end_date]
                    df_all = df_all[(df_all['usage_day'] >= billing_start_date) & (df_all['usage_day'] <= billing_end_date)]

                    logging.info(f"### Billing window: {billing_start_date} -> {billing_end_date}")
                    if df_all.empty:
                        response["message"] = f"No data available for billing cycle between {billing_start_date} and {billing_end_date}"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Billing cycle filtering error: {str(e)}"
                    return response
            
            min_date = df_all['usage_day'].min()
            
        else:
            min_date = None
            

        logging.info("Filtered DataFrame:")
        logging.info(f"###df_all:{df_all}")
        logging.info(f"###min_date:{min_date}")

        # Generate bucket ranges and initialize response structure
        bucket_ranges, default_label = generate_bucket_ranges(tenant_time_zone,df_all, 'usage_day', min_date)

        logging.info(f"### Bucket ranges:{bucket_ranges}")
        all_buckets = {label: [] for label in bucket_ranges.keys()}
        meta_tenants = {}
        meta_providers = {}
        provider_id_to_name = {}

        # Build provider name mapping once
        if not df_all.empty:
            unique_providers = df_all['service_provider_id'].unique()
            for pid in unique_providers:
                provider_rows = df_all[df_all['service_provider_id'] == pid]
                if not provider_rows.empty:
                    provider_id_to_name[pid] = provider_rows.iloc[0]['service_provider_display_name']
        
        

        # Process each time bucket - FIXED DATE RANGE HANDLING
        if start_date and end_date:
            # Determine the main bucket for the custom date range
            main_bucket = get_matching_bucket(bucket_ranges, start_date, end_date)

            if main_bucket:
                default_label = main_bucket

            cfg = bucket_ranges.get(main_bucket, {})
            logging.info(f"### Bucket config: {cfg}")
            logging.info(f"### start_date:{start_date}")
            logging.info(f"### end_date:{end_date}")

            user_cfg = {
                'start': start_date,
                'end': end_date,
                'type': cfg.get('type', 'daily')
            }

            # ✅ ALWAYS define df_filtered first
            df_filtered = df_all[
                (df_all['usage_day'] >= start_date) &
                (df_all['usage_day'] <= end_date)
            ]

            # -----------------------------
            # SPECIAL HANDLING FOR 1_DAY
            # -----------------------------
            if main_bucket == '1_day':
                if (
                    'usage_hour_group' in df_all.columns and
                    not df_filtered.empty and
                    df_filtered['usage_hour_group'].notna().any()
                ):
                    user_cfg['type'] = 'hourly'
                    logging.info(
                        f"Using hourly aggregation for 1_day bucket on {start_date}"
                    )
                else:
                    user_cfg['type'] = 'daily'
                    logging.info(
                        f"No hourly data, using daily aggregation for 1_day bucket"
                    )

            logging.info(f"### Filtered data count: {len(df_filtered)}")
            logging.info(f"### Aggregation type: {user_cfg['type']}")

            if not df_filtered.empty:
                grouped = process_grouped(df_filtered, user_cfg['type'])

                # -------- NORMALIZE PERIOD KEYS (CRITICAL) --------
                period_totals = defaultdict(float)
                for (_, _), records in grouped.items():
                    for rec in records:
                        period_key = str(list(rec.keys())[0])
                        usage_val = float(list(rec.values())[0] or 0)
                        usage_val = max(0.0, usage_val)
                        period_totals[period_key] += usage_val

                # -------- PERCENTAGE CALC --------
                for (tid, pid), records in grouped.items():
                    formatted_records = []

                    for rec in records:
                        period_key = str(list(rec.keys())[0])
                        usage_val = float(list(rec.values())[0] or 0)
                        usage_val = max(0.0, usage_val)

                        total_for_period = period_totals.get(period_key, 0.0)
                        percentage = (
                            (usage_val / total_for_period) * 100
                            if total_for_period > 0 else 0.0
                        )

                        formatted_records.append(
                            [period_key, f"{percentage:.2f}%"]
                        )

                    all_buckets[main_bucket].append({
                        "tenant_id": tid,
                        "provider_id": pid,
                        "records": serialize_data(formatted_records)
                    })

                    meta_tenants[tid] = ""
                    if pid in provider_id_to_name:
                        meta_providers[pid] = provider_id_to_name[pid]
            else:
                logging.warning(
                    f"No data found for date range {start_date} to {end_date}"
                )

            # Keep only the main bucket
            for k in all_buckets.keys():
                if k != main_bucket:
                    all_buckets[k] = []

        
        # Process each time bucket - FIXED DATE RANGE HANDLING
        elif billing_end_date and billing_start_date:
            # Determine the main bucket for the custom date range
            main_bucket = get_matching_bucket(bucket_ranges, billing_start_date, billing_end_date)

            if main_bucket:
                default_label = main_bucket

            cfg = bucket_ranges.get(main_bucket, {})
            logging.info(f"### Bucket config: {cfg}")

            user_cfg = {
                'start': billing_start_date,
                'end': billing_end_date,
                'type': cfg.get('type', 'daily')
            }

            # --- Ensure datetime only once ---
            if 'usage_hour_group' in df_all.columns:
                df_all['usage_hour_group'] = pd.to_datetime(
                    df_all['usage_hour_group'], errors='coerce'
                )

            # --- Filter ONLY ONCE ---
            df_filtered = df_all[
                (df_all['usage_day'] >= user_cfg['start']) &
                (df_all['usage_day'] <= user_cfg['end'])
            ]

            # If weekly bucket but too little data → fallback
            if df_filtered.empty:
                logging.info(
                    f"No data for {user_cfg['start']} -> {user_cfg['end']}, skipping bucket"
                )
            else:
                grouped = process_grouped(df_filtered, user_cfg['type'])

                # -------- FIX #1: NORMALIZE PERIOD KEYS --------
                period_totals = defaultdict(float)
                for (_, _), records in grouped.items():
                    for rec in records:
                        period_key = str(list(rec.keys())[0])   # 🔑 normalize
                        usage_val = float(list(rec.values())[0] or 0)
                        usage_val = max(0.0, usage_val)
                        period_totals[period_key] += usage_val

                # -------- FIX #2: SAFE PERCENT CALC --------
                for (tid, pid), records in grouped.items():
                    formatted_records = []

                    for rec in records:
                        period_key = str(list(rec.keys())[0])
                        usage_val = float(list(rec.values())[0] or 0)
                        usage_val = max(0.0, usage_val)

                        total_for_period = period_totals.get(period_key, 0.0)
                        percentage = (
                            (usage_val / total_for_period) * 100.0
                            if total_for_period > 0 else 0.0
                        )

                        formatted_records.append(
                            [period_key, f"{percentage:.2f}%"]
                        )

                    all_buckets[main_bucket].append({
                        "tenant_id": tid,
                        "provider_id": pid,
                        "records": serialize_data(formatted_records)
                    })

                    meta_tenants[tid] = ""
                    if pid in provider_id_to_name:
                        meta_providers[pid] = provider_id_to_name[pid]

            # Keep only the active bucket
            for k in all_buckets.keys():
                if k != main_bucket:
                    all_buckets[k] = []

        
        else:
            # Original logic for when no specific date range is provided
            for label, cfg in bucket_ranges.items():
                bucket_data = []
                logging.info("==== Raw df_all head ====")
                logging.info(df_all.head(10))  # Show first 10 rows
                logging.info(f"### Columns: {df_all.columns.tolist()}")
                logging.info(f"### dtypes: {df_all.dtypes}")
                logging.info("==== After conversion usage_day ====")
                logging.info(df_all['usage_day'].head(10))
                if not df_all.empty:
                    df_filtered = df_all[(df_all['usage_day'] >= cfg['start']) & (df_all['usage_day'] <= cfg['end'])]
                    logging.info(f"df_filtered:{df_filtered}")
                    if not df_filtered.empty:
                        grouped = process_grouped(df_filtered, cfg['type'])
                        
                        # NEW: Calculate period-wise totals across all providers
                        period_totals = defaultdict(float)
                        for (tid, pid), records in grouped.items():
                            for rec in records:
                                period = list(rec.keys())[0]
                                usage_val = list(rec.values())[0]
                                # Additional safety: ensure non-negative
                                usage_val = max(0, usage_val)
                                period_totals[period] += usage_val
                        
                        # Calculate cross-provider percentages
                        for (tid, pid), records in grouped.items():
                            formatted_records = []
                            for rec in records:
                                period = list(rec.keys())[0]
                                usage_val = list(rec.values())[0]
                                # Additional safety: ensure non-negative
                                usage_val = max(0, usage_val)
                                
                                # Calculate percentage as share of ALL providers in this period
                                total_for_period = period_totals[period]
                                percentage = (usage_val / total_for_period * 100) if total_for_period > 0 else 0
                                
                                formatted_records.append([period, f"{percentage:.2f}%"])
                            
                            bucket_data.append({
                                "tenant_id": tid,
                                "provider_id": pid,
                                "records": serialize_data(formatted_records)
                            })
                            
                            meta_tenants[tid] = ""
                            if pid in provider_id_to_name:
                                meta_providers[pid] = provider_id_to_name[pid]
                
                all_buckets[label] = bucket_data

        # Populate tenant names
        if meta_tenants:
            tenant_ids = list(meta_tenants.keys())
            query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(tenant_ids))})"
            df_tenants = common_utils_database.execute_query(query, params=tenant_ids)
            if isinstance(df_tenants, pd.DataFrame):
                for _, row in df_tenants.iterrows():
                    meta_tenants[row["tenant_id"]] = row["tenant_name"]

        # Build final response
        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": default_label
            },
            "data": {
                "title": "Service Type Usage Distribution",
                "chart_type": "stacked_bar",
                "xField": "date",
                "yField": list(meta_providers.values()),
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            },
            "message": ""
        }
        return response

    except Exception as exception:
        # Error handling
        logging.error(f"[get_service_type_usage_distribution] Unexpected error: {exception}")
        response["message"] = f"Error retrieving service type usage distribution: {exception}"
        try:
            error_data = {
                "service_name": "get_service_type_usage_distribution",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"### Failed to log error: {log_err}")
        return response




def get_usage_by_carrier_weekly_distribution(data):
    """
    Retrieves total data usage in GB grouped by service provider (on each day) for a given tenant with optional date filters.
    Implements Redis caching mechanism for improved performance.
    Ensures robust exception handling and always returns all expected keys in the response.
    Args:
        data (dict): Input parameters including:  
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'billing_cycle_end_period' (str, optional): Filter by billing cycle end date
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'data' (dict): Chart-ready data with usage by carrier/provider.
            - 'message' (str): Error message if applicable.
            
    
    """
    response = {
        "flag": False,
        "data": {
            "title": "Usage by Carrier / Provider",
            "chart_type": "bar",
            "data": [],
            "yField": [],
            "xField": "usage_gb",
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }
    try:
        logging.info(f"get_usage_by_carrier_weekly_distribution request data : {data}")
        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "")
        tenant_database = data.get("db_name", "")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        request_received_at = data.get("request_received_at", "")
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = str(data.get("service_provider", ""))
        billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))


        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"
        function = "get_service_type_usage_distribution"
        cache_key = get_usage_insights_cache_key(tenant_database)
        # Generate cache key and retrieve optimization
        billing_start_date=None
        billing_end_date=None
        use_customer = False  # placeholder for optimization logic
 
        # Fetch data
        if refresh:
            cache_data = update_usage_cache(database, cache_key, function, username, request_received_at, common_utils_database)
            result_df = cache_data["usage_summary_provider"] if use_customer else cache_data["usage_summary_customer"]
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_customer)
            if cache_miss:
                cache_data = update_usage_cache(database, cache_key, function, username, request_received_at, common_utils_database)
                result_df = cache_data["usage_summary_provider"] if use_customer else cache_data["usage_summary_customer"]

        df_all = pd.DataFrame(result_df) if not result_df.empty else pd.DataFrame()
        if not df_all.empty:
            df_all['usage_day'] = pd.to_datetime(df_all['usage_day']).dt.date
            df_all['usage_gb'] = (df_all['total_data_usage']/1024).round(2)
            df_all['tenant_id'] = df_all['tenant_id'].astype(int)
            df_all['service_provider_id'] = df_all['service_provider_id'].astype(int)
            if tenant_id != "All":
                df_all = df_all[df_all['tenant_id']==int(tenant_id)]
            if start_date and end_date:
                df_all = df_all[(df_all['usage_day']>=start_date) & (df_all['usage_day']<=end_date)]
            if service_provider and service_provider != "All":
                try:
                    df_all = df_all[df_all['service_provider_display_name'] == service_provider]
                    if df_all.empty:
                        response["message"] = "No data available for specified service provider"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Service provider filtering error: {str(e)}"
                    return response

            # Filter by billing cycle end date if provided
            logging.info("billing_cycle_end_period:", billing_cycle_end_period)
            if billing_cycle_end_period and billing_cycle_end_period != "All":
                try:
                    # Convert timestamp string to pandas Timestamp (keeps timezone/format robustness)
                    billing_end_pd = pd.to_datetime(billing_cycle_end_period)
                    billing_end_date = billing_end_pd.date()

                    # Compute the start date one month earlier, preserving similar day-of-month semantics.
                    # pd.DateOffset(months=1) handles shorter months (e.g., Mar 31 -> Feb 28).
                    billing_start_pd = billing_end_pd - pd.DateOffset(months=1)
                    billing_start_date = billing_start_pd.date()

                    # Filter df_all for the inclusive range [billing_start_date, billing_end_date]
                    df_all = df_all[(df_all['usage_day'] >= billing_start_date) & (df_all['usage_day'] <= billing_end_date)]

                    logging.info(f"Billing window: {billing_start_date} -> {billing_end_date}")
                    if df_all.empty:
                        response["message"] = f"No data available for billing cycle between {billing_start_date} and {billing_end_date}"
                        response["flag"] = True
                        return response
                except Exception as e:
                    response["message"] = f"Billing cycle filtering error: {str(e)}"
                    return response
            min_date = df_all['usage_day'].min()
        else:
            min_date = None

        bucket_ranges, default_label = generate_bucket_ranges(tenant_time_zone,df_all, 'usage_day', min_date)
       
        all_buckets = {label: [] for label in bucket_ranges.keys()}
        meta_tenants, meta_providers = {}, {}

        # FIXED DATE RANGE HANDLING
        if start_date and end_date:
            # Determine the main bucket for the custom date range
            main_bucket = get_matching_bucket(bucket_ranges, start_date, end_date)

            # >>> NEW: if user provided start/end and we found a matching bucket,
            # override the default_label so meta['default_time_range'] reflects it.
            if main_bucket:
                default_label = main_bucket
            df_all['usage_hour_group'] = pd.to_datetime(df_all['usage_hour_group'], errors='coerce')

            # Use the actual user-provided dates, not the bucket's predefined dates
            cfg = bucket_ranges.get(main_bucket, {})
            user_cfg = {
                'start': start_date,
                'end': end_date,
                'type': cfg.get('type', 'daily')  # Use bucket's grouping type
            }

            requested_range_exists = df_all['usage_hour_group'].between(
                pd.Timestamp(user_cfg['start']),
                pd.Timestamp(user_cfg['end'])
            ).any()


            if not requested_range_exists:
                logging.info(f"Provided dates {user_cfg['start']} -> {user_cfg['end']} not found in usage_hour_group, switching to daily aggregation")
                
                # Update the type to daily
                user_cfg['type'] = 'daily'
                # Use all available data
                df_filtered = df_all.copy()
            else:
                # Normal filtering for requested range
                df_filtered = df_all[
                    (df_all['usage_hour_group'] >= pd.Timestamp(user_cfg['start'])) &
                    (df_all['usage_hour_group'] <= pd.Timestamp(user_cfg['end']))
                ]

            # Filter df for this bucket
            df_filtered = df_all[(df_all['usage_day'] >= user_cfg['start']) & (df_all['usage_day'] <= user_cfg['end'])] if not df_all.empty else pd.DataFrame()

            # Process grouped data if any, else grouped is empty dict
            grouped = process_grouped(df_filtered, user_cfg['type']) if not df_filtered.empty else {}

            formatted = []
            if grouped:
                for (tid, pid), records in grouped.items():
                    formatted.append({
                        "tenant_id": tid,
                        "provider_id": pid,
                        "records": serialize_data(records)
                    })
                    meta_tenants[tid] = ""
                    meta_providers[pid] = df_filtered[df_filtered['service_provider_id']==pid]['service_provider_display_name'].iloc[0]

            # Assign formatted data (empty list if no data)
            all_buckets[main_bucket] = formatted
            
            # Debug logging
            logging.info(f"[get_usage_by_carrier_weekly_distribution] Date range {start_date} to {end_date} matched to bucket: {main_bucket}")
            logging.info(f"[get_usage_by_carrier_weekly_distribution] Records found: {len(df_filtered)}")
            logging.info(f"[get_usage_by_carrier_weekly_distribution] Bucket data: {len(all_buckets[main_bucket])} entries")
            
            # Keep only the main bucket
            for k in all_buckets.keys():
                if k != main_bucket:
                    all_buckets[k] = []
        elif billing_end_date and billing_start_date:
            # Determine the main bucket for the billing cycle date range
            main_bucket = get_matching_bucket(bucket_ranges, billing_start_date, billing_end_date)

            if main_bucket:
                default_label = main_bucket
            
            # Use the actual billing cycle dates
            cfg = bucket_ranges.get(main_bucket, {})
            logging.info(f"### Bucket config: {cfg}")
            logging.info(f"### billing_start_date: {billing_start_date}")
            logging.info(f"### billing_end_date: {billing_end_date}")
            
            user_cfg = {
                'start': billing_start_date,
                'end': billing_end_date,
                'type': cfg.get('type', 'daily')  # Use bucket's grouping type
            }
            
            # SPECIAL HANDLING FOR 1_DAY BUCKET (same as start_date/end_date path)
            if main_bucket == '1_day':
                if 'usage_hour_group' in df_all.columns and not df_all.empty:
                    # Filter by usage_day to get the specific date
                    df_filtered = df_all[
                        (df_all['usage_day'] >= billing_start_date) & 
                        (df_all['usage_day'] <= billing_end_date)
                    ]
                    
                    # Check if we have hourly data for this date
                    has_hourly_data = (
                        not df_filtered.empty and 
                        'usage_hour_group' in df_filtered.columns and
                        df_filtered['usage_hour_group'].notna().any()
                    )
                    
                    if has_hourly_data:
                        user_cfg['type'] = 'hourly'
                        logging.info(f"Using hourly aggregation for 1_day bucket on {billing_start_date}")
                    else:
                        user_cfg['type'] = 'daily'
                        logging.info(f"No hourly data available, using daily aggregation for 1_day bucket")
                else:
                    df_filtered = df_all[
                        (df_all['usage_day'] >= billing_start_date) & 
                        (df_all['usage_day'] <= billing_end_date)
                    ]
                    user_cfg['type'] = 'daily'
                    logging.info(f"No hourly data column, using daily aggregation for 1_day bucket")
            else:
                # For non-1_day buckets, simple date filtering
                df_filtered = df_all[
                    (df_all['usage_day'] >= billing_start_date) & 
                    (df_all['usage_day'] <= billing_end_date)
                ]
            
            logging.info(f"### Filtered data count: {len(df_filtered)}")
            logging.info(f"### Aggregation type: {user_cfg['type']}")
            
            if not df_filtered.empty:
                grouped = process_grouped(df_filtered, user_cfg['type'])
                
                # Calculate period-wise totals across all providers
                period_totals = defaultdict(float)
                for (tid, pid), records in grouped.items():
                    for rec in records:
                        period = list(rec.keys())[0]
                        usage_val = list(rec.values())[0]
                        usage_val = max(0, usage_val)
                        period_totals[period] += usage_val
                
                # Calculate cross-provider percentages
                for (tid, pid), records in grouped.items():
                    formatted_records = []
                    for rec in records:
                        period = list(rec.keys())[0]
                        usage_val = list(rec.values())[0]
                        usage_val = max(0, usage_val)
                        
                        total_for_period = period_totals[period]
                        percentage = (usage_val / total_for_period * 100) if total_for_period > 0 else 0
                        
                        formatted_records.append([period, f"{percentage:.2f}%"])
                    
                    all_buckets[main_bucket].append({
                        "tenant_id": tid,
                        "provider_id": pid,
                        "records": serialize_data(formatted_records)
                    })
                    
                    meta_tenants[tid] = ""
                    if pid in provider_id_to_name:
                        meta_providers[pid] = provider_id_to_name[pid]
            else:
                logging.warning(f"No data found for billing cycle {billing_start_date} to {billing_end_date}")
            
            # Keep only the main bucket
            for k in all_buckets.keys():
                if k != main_bucket:
                    all_buckets[k] = []
        else:
            # Original logic for when no specific date range is provided
            for label, cfg in bucket_ranges.items():
                # Filter df for this bucket
                df_filtered = df_all[(df_all['usage_day'] >= cfg['start']) & (df_all['usage_day'] <= cfg['end'])] if not df_all.empty else pd.DataFrame()

                # Process grouped data if any, else grouped is empty dict
                grouped = process_grouped(df_filtered, cfg['type']) if not df_filtered.empty else {}

                formatted = []
                if grouped:
                    for (tid, pid), records in grouped.items():
                        formatted.append({
                            "tenant_id": tid,
                            "provider_id": pid,
                            "records": serialize_data(records)
                        })
                        meta_tenants[tid] = ""
                        meta_providers[pid] = df_filtered[df_filtered['service_provider_id']==pid]['service_provider_display_name'].iloc[0]

                # Assign formatted data (empty list if no data)
                all_buckets[label] = formatted

        # Populate tenant names from DB
        if meta_tenants:
            ids = list(meta_tenants.keys())
            q = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
            df = common_utils_database.execute_query(q, params=ids)
            if isinstance(df, pd.DataFrame):
                for row in df.to_dict(orient="records"):
                    meta_tenants[int(row["tenant_id"])] = str(row["tenant_name"])

        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": default_label
            },
            "data": {
                "title": "Usage by Carrier / Provider",
                "chart_type": "bar",
                "xField": "usage_gb",
                "yField": list(meta_providers.values()),
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            },
            "message": ""
        }
        return response

    except Exception as exception:
        logging.error(f"[get_usage_by_carrier_weekly_distribution] Unexpected error: {exception}")
        response["message"] = f"Error retrieving weekly usage distribution: {exception}"
        try:
            error_data = {
                "service_name": "get_usage_by_carrier_weekly_distribution",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"Failed to log error: {log_err}")
        return response
    
    

def get_plan_utilisation_summary(data):
    """
    Returns a bar chart showing total usage (in GB) for each customer_rate_plan across service providers.
    Uses process_grouped, generate_bucket_ranges, and assign_week_label for proper bucket formatting.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'billing_cycle_end_period' (str, optional): Filter by billing cycle end date.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant, provider, and plan metadata, default time range.
            - 'data' (dict): Chart-ready data with usage by plan and provider.
            - 'message' (str): Error message if applicable.
    """

    response = {
        "flag": False,
        "meta": {"tenants": {}, "providers": {}, "plans": {}, "default_time_range": "custom_range"},
        "data": {
            "title": "Plan Usage by Service Provider",
            "chart_type": "bar",
            "xField": "usage_count",
            "yField": [],
            "data": {},
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        tenant_id = data.get("tenant_id", "")
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        request_received_at = data.get("request_received_at", "")
        tenant_name = data.get("tenant_name", "")
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
        refresh = str(data.get("refresh", "False")).lower() == "true"
        service_provider = str(data.get("service_provider", ""))
        billing_cycle_end_period = str(data.get("billing_cycle_end_period", ""))

        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"
        function = "get_plan_utilisation_summary"
        cache_key = get_usage_insights_cache_key(tenant_database)
        billing_start_date = None
        billing_end_date = None
        use_customer = False



        if refresh:
            cache_data = update_usage_cache(
                database, cache_key, function, username, request_received_at, common_utils_database
            )
            result_df = cache_data["usage_summary_by_plan_by_provider_rate_plan"]
        else:
            result_df, cache_miss = get_usage_data_from_cache(cache_key, use_customer, return_usage_summary_by_plan=True)
            if cache_miss:
                cache_data = update_usage_cache(
                    database, cache_key, function, username, request_received_at, common_utils_database
                )
                result_df = cache_data["usage_summary_by_plan_by_provider_rate_plan"]

        # Avoid recreating DataFrame if result_df is already a DataFrame; keep semantics for empty.
        df_all = result_df.copy() if isinstance(result_df, pd.DataFrame) and not result_df.empty else pd.DataFrame()

        if df_all.empty:
            response["flag"] = True
            response["message"] = "No data available"
            return response



        filter_start = time.time()
        df_all['usage_day'] = pd.to_datetime(df_all['usage_day']).dt.date

        # Apply all filters immediately to reduce dataset size
        filters = []

        if tenant_id != "All":
            filters.append(df_all['tenant_id'] == int(tenant_id))

        if start_date and end_date:
            filters.append((df_all['usage_day'] >= start_date) & (df_all['usage_day'] <= end_date))
        elif billing_cycle_end_period and billing_cycle_end_period != "":
            try:
                billing_end_pd = pd.to_datetime(billing_cycle_end_period)
                billing_end_date = billing_end_pd.date()
                billing_start_pd = billing_end_pd - pd.DateOffset(months=1)
                billing_start_date = billing_start_pd.date()
                filters.append((df_all['usage_day'] >= billing_start_date) & (df_all['usage_day'] <= billing_end_date))
                logging.info(f"Billing window: {billing_start_date} -> {billing_end_date}")
            except Exception as e:
                response["message"] = f"Billing cycle filtering error: {str(e)}"
                return response

        if service_provider and service_provider != "All":
            filters.append(df_all['service_provider_display_name'] == service_provider)

        # Combine all filters at once
        if filters:
            combined_filter = filters[0]
            for f in filters[1:]:
                combined_filter &= f
            df_all = df_all[combined_filter]

        logging.info(f"[FILTER TIME] {time.time() - filter_start:.4f} sec, Rows: {len(df_all)}")

        if df_all.empty:
            response["message"] = "No data available for specified filters"
            response["flag"] = True
            return response

        # Now do type conversions on the much smaller filtered dataset
        df_all['customer_rate_plan_name'] = df_all['customer_rate_plan_name'].fillna('null').astype(str)



        # Let's fix this properly:
        if 'total_data_usage' in df_all.columns:
            # Check what units we have by looking at a sample value
            sample_val = df_all['total_data_usage'].iloc[0] if len(df_all) > 0 else 0

            logging.info(f"Sample total_data_usage value: {sample_val}")

            # If values are in the billions/trillions, they're likely bytes
            # If they're in millions, they might be KB

            # Since your response shows values like 45,410,383,042 for a plan,
            # and if this is supposed to be ~45 GB, then:
            # 45,410,383,042 bytes / (1024³) = 42.3 GB (reasonable)
            # 45,410,383,042 KB / (1024²) = 43,300 GB = 43.3 TB (too large)

            # So total_data_usage is in BYTES, not KB!
            # Convert bytes to gigabytes: divide by 1024³ = 1,073,741,824
            df_all["usage_gb"] = df_all["total_data_usage"] / 1024

            # Round to 2 decimal places
            df_all["usage_gb"] = df_all["usage_gb"].round(2)

            logging.info(f"Converted bytes to GB. Sample usage_gb: {df_all['usage_gb'].iloc[0] if len(df_all) > 0 else 0}")

        df_all['tenant_id'] = df_all['tenant_id'].astype(int)
        df_all['service_provider_id'] = df_all['service_provider_id'].astype(int)



        # Calculate and log total for debugging
        total_usage_gb = df_all['usage_gb'].sum()
        logging.info(f"\nTOTAL USAGE_GB AFTER CONVERSION: {total_usage_gb:.2f} GB")
        if tenant_id == '1':
            logging.info(f"EXPECTED TOTAL FOR TENANT 1: 32994832598.12 GB")
            logging.info(f"RATIO (Actual/Expected): {total_usage_gb / 32994832598.12:.2%}")

        min_date = df_all['usage_day'].min()

        # Generate bucket ranges
        bucket_ranges, default_label = generate_bucket_ranges(tenant_time_zone, df_all, 'usage_day', min_date)
        all_buckets = {label: [] for label in bucket_ranges.keys()}

        # Pre-collect metadata from filtered dataset (much faster)
        meta_tenants = {tid: "" for tid in df_all['tenant_id'].unique()}
        meta_providers = dict(zip(df_all['service_provider_id'], df_all['service_provider_display_name']))

        # === NEW: compute top-5 plans PER service provider (within filtered df_all) ===
        # Filter out null plans and zero usage before calculating top plans
        df_for_top_plans = df_all[
            (df_all['customer_rate_plan_name'] != 'null') &
            (df_all['usage_gb'] > 0)
        ].copy()
        # Create a dataframe of total usage by provider + plan
        prov_plan_totals = (
            df_for_top_plans
            .groupby(['service_provider_id', 'customer_rate_plan_name'], as_index=False)['usage_gb']
            .sum()
        )
        # Build dict: provider_id -> list of top 5 plan names (by usage desc)
        provider_top_plans = {}
        for pid, group in prov_plan_totals.groupby('service_provider_id'):
            top_list = group.sort_values('usage_gb', ascending=False).head(5)['customer_rate_plan_name'].tolist()
            provider_top_plans[int(pid)] = top_list

        # meta_plans should include the union of selected top plans across providers
        top_plans_union = sorted({p for plans in provider_top_plans.values() for p in plans})
        meta_plans = {p: p for p in top_plans_union}

        # FIXED DATE RANGE HANDLING
        main_bucket = None
        if start_date and end_date:
            main_bucket = get_matching_bucket(bucket_ranges, start_date, end_date)
        elif billing_start_date and billing_end_date:
            main_bucket = get_matching_bucket(bucket_ranges, billing_start_date, billing_end_date)
        # >>> NEW: if user provided start/end and we found a matching bucket,
        # override the default_label so meta['default_time_range'] reflects it.
        if main_bucket:
            default_label = main_bucket

        for label, cfg in bucket_ranges.items():
            # Skip non-main buckets if filtering by date range
            if main_bucket and label != main_bucket:
                continue

            # Use user dates for filtering but bucket type for grouping when date range is provided
            if main_bucket and label == main_bucket:
                if billing_start_date and billing_end_date:
                    user_cfg = {
                        'start': billing_start_date,
                        'end': billing_end_date,
                        'type': cfg.get('type', 'daily')
                    }
                else:
                    user_cfg = {
                        'start': start_date,
                        'end': end_date,
                        'type': cfg.get('type', 'daily')
                    }

                # First filter by date range
                df_filtered = df_all[(df_all['usage_day'] >= user_cfg['start']) & (df_all['usage_day'] <= user_cfg['end'])]

                if df_filtered.empty:
                    continue

                # SPECIAL HANDLING: If the main bucket is a single day (1_day),
                # prefer hourly view but create 4-hour buckets when full timestamps exist or when we can infer them.
                if main_bucket == '1_day':
                    # Force hourly-type grouping for 1_day view (we will create 4-hour groups)
                    grouping_type = 'hourly'

                    # If there is already 'usage_hour_group' present, prefer it.
                    if 'usage_hour_group' in df_filtered.columns:
                        # ensure any existing usage_hour_group is coerced to string labels (we will keep existing)
                        df_filtered['usage_hour_group'] = df_filtered['usage_hour_group'].astype(str)
                    else:
                        # Try to detect a timestamp column to derive 4-hour bins.
                        ts_candidates = ['usage_timestamp', 'usage_time', 'modified_date', 'event_time', 'timestamp', 'created_at']
                        ts_col = next((c for c in ts_candidates if c in df_filtered.columns), None)

                        if ts_col:
                            # parse timestamp candidate
                            df_filtered[ts_col] = pd.to_datetime(df_filtered[ts_col], errors='coerce')
                            # create a 4-hour label including the date to avoid ambiguity
                            def four_hour_label(ts, fallback_date):
                                if pd.isna(ts):
                                    date_part = fallback_date
                                    start_h = 0
                                else:
                                    date_part = ts.date()
                                    start_h = (ts.hour // 4) * 4
                                end_h = (start_h + 3) % 24
                                return f"{date_part} {start_h:02d}:00-{end_h:02d}:59"

                            fallback_date = pd.to_datetime(user_cfg['start']).date() if not isinstance(user_cfg['start'], datetime) else user_cfg['start'].date()
                            df_filtered['usage_hour_group'] = df_filtered[ts_col].apply(lambda ts: four_hour_label(ts, fallback_date))
                        elif 'usage_hour' in df_filtered.columns:
                            # If there's an integer hour column, bucket it
                            def hour_col_label(h, fallback_date):
                                try:
                                    h_int = int(h)
                                    start_h = (h_int // 4) * 4
                                    end_h = (start_h + 3) % 24
                                    date_part = fallback_date
                                    return f"{date_part} {start_h:02d}:00-{end_h:02d}:59"
                                except:
                                    return f"{fallback_date} 00:00-03:59"
                            fallback_date = pd.to_datetime(user_cfg['start']).date() if not isinstance(user_cfg['start'], datetime) else user_cfg['start'].date()
                            df_filtered['usage_hour_group'] = df_filtered['usage_hour'].apply(lambda h: hour_col_label(h, fallback_date))
                        else:
                            # Can't create 4-hour groups (no usable timestamp/hour); fallback to daily
                            logging.info("No timestamp/hour column available to create 4-hour groups; switching to daily aggregation for 1_day.")
                            grouping_type = 'daily'
                else:
                    # not 1_day main bucket; use configured type
                    grouping_type = user_cfg['type']

            else:
                df_filtered = df_all[(df_all['usage_day'] >= cfg['start']) & (df_all['usage_day'] <= cfg['end'])]
                grouping_type = cfg['type']

            if df_filtered.empty:
                continue

            # Convert grouped format into final bucket structure by aggregating per-provider top plans
            # For each provider present in the filtered data, process only its top 5 plans
            providers_in_filtered = df_filtered['service_provider_id'].unique()
            for pid in providers_in_filtered:
                pid = int(pid)
                top_plans_for_provider = provider_top_plans.get(pid, [])
                if not top_plans_for_provider:
                    continue

                for plan_name in top_plans_for_provider:
                    # filter to rows for this provider + plan and call the common grouping function
                    df_plan = df_filtered[
                        (df_filtered['service_provider_id'] == pid) &
                        (df_filtered['customer_rate_plan_name'] == plan_name)
                    ]
                    if df_plan.empty:
                        continue

                    grouped_plan = process_grouped(df_plan, grouping_type)

                    # process_grouped returns keys like (tenant_id, service_provider_id)
                    for (tid, ppid), records_list in grouped_plan.items():
                        for record in records_list:
                            for date_str, usage in record.items():
                                # Ensure usage is properly rounded
                                usage_rounded = round(float(usage), 2)
                                all_buckets[label].append({
                                    "tenant_id": int(tid),
                                    "provider_id": int(ppid),
                                    "plan": plan_name,
                                    "records": serialize_data([[date_str, usage_rounded]])
                                })

        # Populate tenant names
        if meta_tenants:
            tenant_ids = [int(tid) for tid in meta_tenants.keys()]
            query = f"SELECT id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(tenant_ids))})"
            df_tenants = common_utils_database.execute_query(query, params=tenant_ids)
            if isinstance(df_tenants, pd.DataFrame):
                for _, row in df_tenants.iterrows():
                    meta_tenants[int(row["id"])] = row["tenant_name"]

        # Prepare yField (unique top plans across providers)
        yField = [p if p != 'null' else None for p in top_plans_union]

        # Calculate final total from all_buckets for debugging
        final_total = 0
        for label, bucket_items in all_buckets.items():
            for item in bucket_items:
                records = item.get('records', '[]')
                # Parse records to calculate total
                # This depends on your serialize_data format
                # Assuming it's a list of [date, usage] pairs
                try:
                    import json
                    parsed_records = json.loads(records) if isinstance(records, str) else records
                    for record in parsed_records:
                        if isinstance(record, list) and len(record) == 2:
                            final_total += float(record[1])
                except:
                    pass

        logging.info(f"\nFINAL TOTAL FROM RESPONSE: {final_total:.2f} GB")


        # Build final response
        response = {
            "flag": True,
            "meta": {
                "tenants": {int(k): v for k, v in meta_tenants.items()},
                "providers": meta_providers,
                "plans": meta_plans,
                "default_time_range": default_label
            },
            "data": {
                "title": "Plan Usage by Service Provider",
                "chart_type": "bar",
                "xField": "usage_count",
                "yField": yField,
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets
            },
            "message": ""
        }

        return response

    except Exception as exception:
        logging.error(f"[get_plan_utilisation_summary] Unexpected error: {exception}")
        response["message"] = f"Error retrieving plan usage by service provider: {exception}"
        try:
            error_data = {
                "service_name": "get_plan_utilisation_summary",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.warning(f"Failed to log error: {log_err}")

        return response

               
######################### Revenue metrics  ############################


def db_name_to_billing_platform_db(db_name,mode):
    """
    Splits the payload by '_beta' and appends '_billing_platform_beta'.
    Example: 'altaworx_central_beta' → 'altaworx_central_billing_platform_beta'
    """
    if mode.lower()=='beta':
        try:
            return db_name.split("_beta")[0] + "_billing_platform_beta"
        except Exception as e:
            logging.error(f"Failed to get billing platform db name: {e}")
            return None
    elif mode.lower()=='prod':
        try:
            return db_name + "_billing_platform"
        except Exception as e:
            logging.error(f"Failed to get billing platform db name: {e}")
            return None
    else:
        return None



def get_revenue_metrics_cards(data):
    """
    CACHE-FIRST DESIGN (CORRECT)

    1) Fetch ALL revenue data WITHOUT filters
    2) Cache raw additive rows
    3) Apply filters on cached data
    4) Aggregate ONCE
    """

    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_database = data.get("db_name", "")
    tenant_id = data.get("tenant_id", "All")

    start_date = (
        datetime.strptime(data["start_date"], "%Y-%m-%d").date()
        if data.get("start_date")
        else None
    )
    end_date = (
        datetime.strptime(data["end_date"], "%Y-%m-%d").date()
        if data.get("end_date")
        else None
    )

    service_provider = data.get("service_provider", "")
    billing_cycle_end_date = data.get("billing_cycle_end_date", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"

    response = {
        "flag": False,
        "data": {
            "title": "Revenue Metrics",
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        # ---------------- DB CONNECTIONS ----------------
        mode = os.environ.get("ENV", "")
        billing_platform_db_name = db_name_to_billing_platform_db(
            tenant_database, mode
        )

        killbill_db = DB(billing_platform_db_name, **db_config)
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"],
            **common_utils_database_config,
        )

        function = "get_revenue_metrics_cards"
        cache_key = f"{get_cache_key(tenant_database, function)}_raw"

        # ---------------- FETCH + CACHE RAW DATA ----------------
        if refresh or not redis_client.get(cache_key):
            logging.info("Cache miss / refresh → fetching raw revenue data")

            charges_query = """
                SELECT
                    ROUND(
					    SUM(
					        COALESCE(cc.charge_amount, 0)
					      + COALESCE(cc.usage_mb, 0)
					      + COALESCE(cc.sms_cost, 0)
					    )::numeric,
					    2
					) AS charge_value,
                    cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    cc.created_date AS charge_date,
                    SPLIT_PART(bill_range,' - ',1)::DATE AS bill_start_date,
                    SPLIT_PART(bill_range,' - ',2)::DATE AS bill_end_date
                FROM customer_charges cc 
                JOIN customer_services cs ON cs.id = cc.customer_service_id 
                WHERE cc.is_active = false
				  and cc.is_billed  = true
				  and cc.category = 'MRC'
                GROUP BY cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    cc.created_date,
                    cc.bill_range
            """

            bills_query = """
                SELECT
                    MAX(cb.total)               AS total,
                    MAX(cb.payments)            AS payments,
                    MAX(cb.amount_due)          AS remaining,
                    MAX(cb.due_date_of_this_bill) AS bill_date,
                    cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    MIN(SPLIT_PART(cc.bill_range,' - ',1)::DATE) AS bill_start_date,
                    MAX(SPLIT_PART(cc.bill_range,' - ',2)::DATE) AS bill_end_date
                FROM customer_charges cc
                JOIN customer_services cs
                    ON cs.id = cc.customer_service_id
                JOIN customer_bills cb
                    ON cb.id = cc.applied_to_bill
                WHERE cc.is_active = false
                AND cc.is_billed = true
                AND cc.category = 'MRC'
                GROUP BY
                    cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    cb.id;
            """

            charges_df = killbill_db.execute_query(charges_query, True)
            bills_df = killbill_db.execute_query(bills_query, True)

            raw_cache = {
                "charges": charges_df.to_dict("records")
                if isinstance(charges_df, pd.DataFrame) else [],
                "bills": bills_df.to_dict("records")
                if isinstance(bills_df, pd.DataFrame) else [],
            }

            redis_client.setex(cache_key, 9000, json.dumps(raw_cache, default=str))
        else:
            raw_cache = json.loads(redis_client.get(cache_key))

        # ---------------- LOAD FROM CACHE ----------------
        df_charges = pd.DataFrame(raw_cache.get("charges", []))
        df_bills = pd.DataFrame(raw_cache.get("bills", []))

        # normalize tenant_id input for comparisons
        tenant_id_int = None
        if tenant_id != "All":
            try:
                tenant_id_int = int(tenant_id)
            except Exception:
                # if it can't convert, leave as None so no tenant filter is applied
                tenant_id_int = None

        # ---------------- APPLY FILTERS (CACHE ONLY) ----------------
        if not df_charges.empty:
            # ensure column exists before converting
            if "charge_date" in df_charges.columns:
                df_charges["charge_date"] = pd.to_datetime(
                    df_charges["charge_date"]
                ).dt.date

            if tenant_id_int is not None and "tenant_id" in df_charges.columns:
                df_charges = df_charges[df_charges["tenant_id"] == tenant_id_int]

            if service_provider and "service_provider_name" in df_charges.columns:
                df_charges = df_charges[
                    df_charges["service_provider_name"] == service_provider
                ]

            # FIX: use parentheses around comparisons when using & to avoid dtype errors
            if start_date and end_date and "charge_date" in df_charges.columns:
                df_charges = df_charges[
                    (df_charges["charge_date"] >= start_date)
                    & (df_charges["charge_date"] <= end_date)
                ]

            if billing_cycle_end_date and "bill_start_date" and "bill_end_date" in df_charges.columns:
                end_dt = datetime.strptime(billing_cycle_end_date, "%Y-%m-%d").date()
                start_dt = end_dt - timedelta(days=30)
                df_charges = df_charges[
                    (df_charges["bill_start_date"] >= start_dt)
                    & (df_charges["bill_end_date"] <= end_dt)
                ]

        if not df_bills.empty:
            if "bill_date" in df_bills.columns:
                df_bills["bill_date"] = pd.to_datetime(df_bills["bill_date"]).dt.date

            if tenant_id_int is not None and "tenant_id" in df_bills.columns:
                df_bills = df_bills[df_bills["tenant_id"] == tenant_id_int]
                
            if service_provider and "service_provider_name" in df_bills.columns:
                df_bills = df_bills[
                    df_bills["service_provider_name"] == service_provider
                ]

            # FIX: same parentheses rule for bills date filter
            if start_date and end_date and "bill_date" in df_bills.columns:
                df_bills = df_bills[
                    (df_bills["bill_date"] <= end_date)
                ]
            
            if billing_cycle_end_date and "bill_start_date" and "bill_end_date" in df_bills.columns:
                end_dt = datetime.strptime(billing_cycle_end_date, "%Y-%m-%d").date()
                start_dt = end_dt - timedelta(days=30)
                df_bills = df_bills[
                    (df_bills["bill_start_date"] >= start_dt)
                    & (df_bills["bill_end_date"] <= end_dt)
                ]

        # ---------------- FINAL AGGREGATION (ONCE) ----------------
        total_charges = df_charges["charge_value"].sum() if (
            not df_charges.empty and "charge_value" in df_charges.columns
        ) else 0.0

        total_payments = (
            df_bills["total"].sum() if (not df_bills.empty and "total" in df_bills.columns) else 0.0
        )
        total_billed_amount = (
            df_bills["payments"].sum() if (not df_bills.empty and "payments" in df_bills.columns) else 0.0
        )
        overdue_payments = (
            df_bills["remaining"].sum() if (not df_bills.empty and "remaining" in df_bills.columns) else 0.0
        )

        # ---------------- TENANT NAME ----------------
        tenant_name_display = "All Tenants"
        if tenant_id_int is not None:
            tdf = common_utils_database.execute_query(
                "SELECT tenant_name FROM tenant WHERE id = %s",
                params=[tenant_id_int],
                dict_result=True,
            )
            if not tdf.empty:
                tenant_name_display = tdf.iloc[0]["tenant_name"]

        payload = {
            "total_charges": f"${total_charges:,.2f}",
            "total_payments": f"${total_payments:,.2f}",
            "total_billed_amount": f"${total_billed_amount:,.2f}",
            "overdue_payments": f"${overdue_payments:,.2f}",

            "raw_total_charges": total_charges,
            "raw_total_payments": total_payments,
            "raw_total_billed_amount": total_billed_amount,
            "raw_overdue_payments": overdue_payments,

            "tenant_id": int(tenant_id) if tenant_id != "All" else None,
            "tenant_name": tenant_name_display,
        }

        response["flag"] = True
        response["data"] = payload

    except Exception as exception:
        logging.exception("Revenue metrics error")
        response["flag"] = False
        response["message"] = f"Error retrieving revenue metrics: {exception}"
        try:
            error_data = {
                "service_name": "get_revenue_metrics_cards",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": data.get("tenant_name", ""),
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"Failed to log error: {log_exc}")

    return response


def get_revenue_by_carrier(data):
    """
    Returns a breakdown of revenue by carrier (service provider), including a sparkline (trend) for each.
    Bucketing logic mirrors get_sim_count_by_service_provider (week cutoffs, yearly cutoffs, 2-year cutoffs, 4-hour intervals).
    Bucketing happens BEFORE caching; cache hits only apply filters over the cached buckets.
    No cumulative grouping is used here.

    **Change (2025-08-22):**
    For multi-segment time ranges (5_day, 1_month, 3_month, 6_month, 1_year, 5_years, max, custom_range)
    the code now aggregates across the whole label period (combined start..end) instead of requiring
    each sub-segment to be populated. This ensures that if *any* record exists within the larger
    period (for example: only today's record), the larger buckets will include that provider/record.
    The 1_day bucket still preserves its 4-hour granularity.

    **Fix (2025-09-04):**
    - Removed billing_cycle_end_date from queries as it doesn't exist in the database
    - Modified billing_cycle_end_date filter to use modified_date with 30-day window
    - Fixed column references to match actual database schema

    **Fix (2025-09-08):**
    - Ensure "today's" partial segment ends at the actual current timestamp (hours preserved),
      so same-day rows (e.g. 2025-09-08T11:10:20Z) are included in non-1_day buckets.
    - Use `max` modified_date per group when choosing representative label so bucket labels reflect
      the latest record within the bucket.
    - Modified _segments_5_day to set seg_end to end of day (23:59:59.999999Z) for days prior to today,
      ensuring records with timestamps throughout the day (e.g., 2025-09-04T12:00:00Z) are included.

    **Fix applied here:**
    - Removed JSON serialization of `records` field in _aggregate_non_cumulative to prevent escaped backslashes
      in the output, storing the records list directly.

    **Update (2025-12-22):**
    - Updated revenue calculation to sum all charge components (charge_amount, usage_mb, sms_cost, 
      tax_amount, sms_tax_amount, usage_tax_amount)
    - Modified query to filter by reversal_flag=false and is_deleted=false
    - Changed to use cs.created_date instead of cc.created_date for modified_date

    **Optimization (2026-01-15):**
    - Apply filters BEFORE bucketing to reduce processing time
    - Filter trend_df before generating segments and aggregating
    - When date range filters applied: populate only the selected bucket based on date range
    - When no date range filters: populate all buckets

    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'billing_cycle_end_date' (str, optional): Filter by billing cycle end date (uses modified_date with 30-day window).
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): Chart-ready data with revenue by carrier and trend sparklines.
            - 'message' (str): Error message if applicable.
    """

    # -------- request fields --------
    tenant_id = data.get("tenant_id", "All")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = dtparse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get('service_provider', '')
    billing_cycle_end_date = data.get("billing_cycle_end_date", "")

    response = {
        "flag": False,
        "meta": {
            "tenants": {},
            "providers": {},
            "default_time_range": "1_month",
        },
        "data": {
            "title": "Revenue By Carrier",
            "columns": ["Carrier", "Revenue", "Statistic"],
            "rows": [],
            "height": 300,
            "width": 500,
        },
        "message": "",
    }
    
    try:
        mode = os.environ.get('ENV','')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"
    except Exception as exception:
        response["message"] = f"Database connection error: {exception}"
        logging.exception("DB connection error in get_revenue_by_carrier")
        return response

    # ---------- helpers ----------
    def _now_ts():
        """Returns current timestamp in UTC for segment generation."""
        return pd.Timestamp.now(tz="UTC")
    
    def _now_ts_tenant():
        """Returns current timestamp in tenant timezone for 1_day bucket."""
        try:
            import pytz    
            tz = pytz.timezone(tenant_time_zone if tenant_time_zone else "UTC")            
            now_local = pd.Timestamp.now(tz=tz)           
            now_utc = now_local.tz_convert("UTC")           
            logging.info(f"### Using tenant timezone {tenant_time_zone}: "
                        f"local_now={now_local}, utc_now={now_utc}")
            return now_utc
        except Exception as tz_conv_exc:
            logging.warning(f"Failed to convert to tenant timezone: {tz_conv_exc}. Using UTC.")
            return pd.Timestamp.now(tz="UTC")

    def _normalize_date(ts):
        """Normalizes a timestamp to midnight (start of day)."""
        try:
            t = pd.to_datetime(ts, utc=True)
            return t.normalize()
        except Exception:
            return pd.to_datetime(ts, utc=True).normalize()

    def _eom(ts):
        """Returns the end-of-month timestamp for the given date."""
        t = pd.to_datetime(ts, utc=True)
        return t + pd.offsets.MonthEnd(0)

    def _fmt_date(ts):
        """Formats a timestamp as 'YYYY-MM-DD'."""
        t = pd.to_datetime(ts, utc=True)
        return t.date().isoformat()

    def _fmt_dt(ts):
        """Formats a timestamp as ISO 8601 UTC string 'YYYY-MM-DDTHH:MM:SSZ'."""
        try:
            t = pd.to_datetime(ts, utc=True)
            return t.strftime('%Y-%m-%dT%H:%M:%SZ')
        except Exception:
            t = pd.to_datetime(ts, utc=True)
            return t.strftime('%Y-%m-dT%H:%M:%SZ')

    def _fmt_date_only(ts):
        """Formats a timestamp as 'YYYY-MM-DD' (date only)."""
        t = pd.to_datetime(ts, utc=True)
        return t.strftime('%Y-%m-%d')

    def _fmt_year_only(ts):
        """Formats a timestamp as just the year 'YYYY'."""
        t = pd.to_datetime(ts, utc=True)
        return str(t.year)

    def _generate_month_week_segments(month_start, month_end):
        """Generates weekly segments for a month: 1-7, 8-14, 15-21, 22-28, 29-EOM.
           Label is the LAST DATE of each week (normalized to midnight)."""
        segments = []
        
        # Get month info
        year = month_start.year
        month = month_start.month
        
        # Define week boundaries
        week_boundaries = [
            (1, 7),    # Week 1: 1-7
            (8, 14),   # Week 2: 8-14  
            (15, 21),  # Week 3: 15-21
            (22, 28),  # Week 4: 22-28
            (29, None) # Week 5: 29-end of month
        ]
        
        for start_day, end_day in week_boundaries:
            # Skip if start day is beyond month end
            if start_day > month_end.day:
                break
            
            # Calculate actual end day
            if end_day is None:
                # Last week: 29 to end of month
                actual_end_day = month_end.day
            else:
                actual_end_day = min(end_day, month_end.day)
            
            # Skip if start day > actual end day (for short months)
            if start_day > actual_end_day:
                continue
            
            # Create segment start (first day of week at 00:00:00)
            seg_start = pd.Timestamp(
                year=year, month=month, day=start_day,
                hour=0, minute=0, second=0, microsecond=0,
                tz="UTC"
            )
            
            # Create segment end (last day of week at 23:59:59.999999)
            seg_end = pd.Timestamp(
                year=year, month=month, day=actual_end_day,
                hour=23, minute=59, second=59, microsecond=999999,
                tz="UTC"
            )
            
            # Ensure segment end doesn't exceed month_end
            if seg_end > month_end:
                seg_end = month_end
            
            # Label is the LAST DATE of the week, normalized to midnight
            label_date = pd.Timestamp(
                year=year, month=month, day=actual_end_day,
                tz="UTC"
            ).normalize()
            
            segments.append((seg_start, seg_end, label_date))
        
        return segments

    def _month_week_segments_range(start_month_ts, end_ts, include_today_partial=True):
        """Generates weekly segments across a range of months."""
        segments = []
        
        # Start from the 1st day of the starting month
        current_month = pd.Timestamp(
            year=start_month_ts.year,
            month=start_month_ts.month,
            day=1,
            hour=0, minute=0, second=0, microsecond=0,
            tz="UTC"
        )
        
        # End at the last day of the ending month
        end_month = pd.Timestamp(
            year=end_ts.year,
            month=end_ts.month,
            day=1,
            hour=0, minute=0, second=0, microsecond=0,
            tz="UTC"
        )
        
        while current_month <= end_month:
            # Get the end of this month
            month_end = _eom(current_month)
            if month_end > end_ts:
                month_end = end_ts
            
            # Generate WEEKLY segments for this month (1-7, 8-14, 15-21, 22-28, 29-EOM)
            month_segments = _generate_month_week_segments(current_month, month_end)
            segments.extend(month_segments)
            
            # Move to next month
            next_month = current_month + pd.DateOffset(months=1)
            current_month = next_month
        
        return segments

    def _year_segments_last_n_years(n_years, end_ts):
        """Generates yearly segments for the last n years including the current year."""
        segments = []
        start_year = end_ts.year - n_years + 1
        
        for year in range(start_year, end_ts.year):
            year_start = pd.Timestamp(year=year, month=1, day=1, tz="UTC")
            year_end = pd.Timestamp(year=year, month=12, day=31, hour=23, minute=59, second=59, tz="UTC")
            # Label is just the year (normalized to Jan 1 of that year)
            label_ts = pd.Timestamp(year=year, month=1, day=1, tz="UTC").normalize()
            segments.append((year_start, year_end, label_ts))
        
        # Current year (partial)
        current_year_start = pd.Timestamp(year=end_ts.year, month=1, day=1, tz="UTC")
        # Label is just the year (normalized to Jan 1 of that year)
        label_ts = pd.Timestamp(year=end_ts.year, month=1, day=1, tz="UTC").normalize()
        segments.append((current_year_start, end_ts, label_ts))
        
        return segments

    def _segments_1_day(now_ts):
        """Splits a single day into 4-hour segments for the entire day."""
        start_of_day = _normalize_date(now_ts)
        end_of_day = start_of_day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
        
        # Create 4-hour intervals
        anchors = list(pd.date_range(
            start=start_of_day, 
            periods=7,  # 7 points for 6 intervals
            freq="4h", 
            tz="UTC"
        ))
        
        # Ensure last anchor is end of day
        anchors[-1] = end_of_day
        
        # Create segments - label is the END timestamp (with time)
        segments = []
        for i in range(len(anchors) - 1):
            seg_start = anchors[i]
            seg_end = anchors[i + 1]
            # Label is the END timestamp (with hours/minutes/seconds)
            segments.append((seg_start, seg_end, seg_end))
        
        return segments

    def _segments_5_day(now_ts):
        """Splits the last 5 days into daily segments."""
        today = _normalize_date(now_ts)
        start_day = today - pd.Timedelta(days=4)
        days = list(pd.date_range(start=start_day, end=today, freq="D", tz="UTC"))
        
        segments = []
        for i, day in enumerate(days):
            seg_start = day
            if i == len(days) - 1:  # Today
                seg_end = now_ts
                # Label is just the date (normalized)
                label_ts = now_ts.normalize()
            else:
                seg_end = day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                # Label is just the date (normalized)
                label_ts = seg_end.normalize()
            
            segments.append((seg_start, seg_end, label_ts))
        
        return segments

    def _segments_1_day_for_date(target_date):
        """Splits a specific date (not necessarily today) into 4-hour segments."""
        start_of_day = _normalize_date(target_date)
        end_of_day = start_of_day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
        
        # Create 4-hour intervals
        anchors = list(pd.date_range(
            start=start_of_day, 
            periods=7,  # 7 points for 6 intervals
            freq="4h", 
            tz="UTC"
        ))
        
        # Ensure last anchor is end of day
        anchors[-1] = end_of_day
        
        # Create segments - label is the END timestamp (with time)
        segments = []
        for i in range(len(anchors) - 1):
            seg_start = anchors[i]
            seg_end = anchors[i + 1]
            # Label is the END timestamp (with hours/minutes/seconds)
            segments.append((seg_start, seg_end, seg_end))
        
        return segments

    def _segments_5_day_for_range(start_date_obj, end_date_obj):
        """Splits a specific 5-day range into daily segments."""
        # Convert to UTC timestamps
        start_ts = pd.Timestamp(start_date_obj).tz_localize("UTC").normalize()
        end_ts = pd.Timestamp(end_date_obj).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
        
        # Create daily segments
        days = list(pd.date_range(start=start_ts, end=end_ts, freq="D", tz="UTC"))
        
        segments = []
        for i, day in enumerate(days):
            seg_start = day
            if i == len(days) - 1:  # Last day
                seg_end = end_ts
                # Label is just the date (normalized)
                label_ts = end_ts.normalize()
            else:
                seg_end = day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                # Label is just the date (normalized)
                label_ts = seg_end.normalize()
            
            segments.append((seg_start, seg_end, label_ts))
        
        return segments

    def _aggregate_non_cumulative(df, segments, time_with_hours, year_only=False):
        """
        Aggregates `df` for the provided `segments` list.
        Returns consistent time formatting:
        - 1_day: "2026-01-15T20:00:00Z"
        - 5_day, 1_month, 3_month, 6_month, 1_year: "2026-01-07"
        - 5_years, max: "2026"
        """
        if df.empty:
            return []
        
        records_by_key = defaultdict(list)
        
        for seg_start, seg_end, label_ts in segments:
            # Filter records for this segment
            mask = (df["modified_date"] >= seg_start) & (df["modified_date"] <= seg_end)
            sub_df = df.loc[mask]
            
            if sub_df.empty:
                continue
            
            # Group and aggregate
            grouped = (
                sub_df.groupby(["tenant_id", "service_provider_id", "service_provider_name"], as_index=False)
                .agg({"revenue": "sum", "modified_date": "max"})
                .rename(columns={"modified_date": "rep_modified_date"})
            )
            
            for _, row in grouped.iterrows():
                # Determine time label based on format requirements:
                # - 1_day bucket: "2026-01-13T00:00:00Z" (ISO with time)
                # - 5_day, 1_month, 3_month, 6_month, 1_year: "2026-01-07" (date only)
                # - 5_year, max: "2026" (year only)
                
                if year_only:
                    # For 5_year and max buckets
                    t_str = _fmt_year_only(label_ts)
                else:
                    if time_with_hours:
                        # For 1_day bucket (4-hour segments)
                        t_str = _fmt_dt(label_ts)
                    else:
                        # For 5_day, 1_month, 3_month, 6_month, 1_year buckets
                        # Use date only format
                        t_str = _fmt_date_only(label_ts)
                
                tid = int(row["tenant_id"])
                pid = int(row["service_provider_id"])
                pname = row["service_provider_name"] if pd.notnull(row["service_provider_name"]) and row["service_provider_name"] != "" else "Unknown provider"
                val = float(row["revenue"]) if pd.notnull(row["revenue"]) and np.isfinite(row["revenue"]) else 0.0
                
                records_by_key[(tid, pid, pname)].append([t_str, val])
        
        # Convert to final rows
        rows = []
        for (tid, pid, pname), recs in records_by_key.items():
            # Sort records by time
            recs.sort(key=lambda x: x[0])
            stat = [rv for _, rv in recs]
            
            rows.append({
                "tenant_id": tid,
                "provider_id": pid,
                "service_provider_name": pname,
                "Revenue": "$0.00",  # Will be updated later from total_map
                "Statistic": stat,
                "records": recs,
            })
        
        return rows

    def _parse_record_date(s):
        """Safely parses a string into a date object."""
        if s is None:
            return None
        try:
            if isinstance(s, (pd.Timestamp, datetime)):
                return pd.to_datetime(s, utc=True).date()
            dt = pd.to_datetime(s, utc=True)
            return dt.date()
        except Exception:
            try:
                dt = pd.to_datetime(s, utc=True, errors='coerce')
                if pd.isnull(dt):
                    return None
                return dt.date()
            except Exception:
                return None

    def _select_appropriate_bucket(start_date_obj, end_date_obj):
        """Selects the most appropriate bucket based on date range."""
        if not start_date_obj or not end_date_obj:
            return "1_month"
        
        # Calculate difference in days
        delta = (end_date_obj - start_date_obj).days
        
        if delta <= 1:
            return "1_day"
        elif delta <= 5:
            return "5_day"
        elif delta <= 7:
            return "5_day"
        elif delta <= 31:
            return "1_month"
        elif delta <= 93:
            return "3_month"
        elif delta <= 186:
            return "6_month"
        elif delta <= 366:
            return "1_year"
        elif delta <= 1826:  # 5 years
            return "5_years"
        else:
            return "max"

    try:
        function = "get_revenue_by_carrier"
        cache_key = get_cache_key(tenant_database, function)
        cached_raw_data = None

        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_raw_data = json.loads(cached_response)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Cache retrieval failed: {cache_exc}")

        if refresh or cached_raw_data is None:
            logging.info("Fetching fresh data for get_revenue_by_carrier")

            # Updated query with comprehensive revenue calculation
            revenue_query = """
                SELECT
                    ROUND(
					    SUM(
					        COALESCE(cc.charge_amount, 0)
					      + COALESCE(cc.usage_mb, 0)
					      + COALESCE(cc.sms_cost, 0)
					    )::numeric,
					    2
					) AS revenue,
                    cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    cc.created_date AS modified_date,
                    SPLIT_PART(bill_range,' - ',1)::DATE AS bill_start_date,
                    SPLIT_PART(bill_range,' - ',2)::DATE AS bill_end_date
                FROM customer_charges cc 
                JOIN customer_services cs ON cs.id = cc.customer_service_id 
                WHERE cc.is_active = false
				  and cc.is_billed  = true
				  and cc.category = 'MRC'
                GROUP BY cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    cc.created_date,
                    cc.bill_range
            """

            # Execute query for both summary and trend data
            summary_df = killbill_database.execute_query(revenue_query, flag=True)
            trend_df = killbill_database.execute_query(revenue_query, flag=True)

            # Process summary data
            if isinstance(summary_df, pd.DataFrame) and not summary_df.empty:
                summary_df["tenant_id"] = pd.to_numeric(summary_df["tenant_id"], errors="coerce").fillna(-1).astype(int)
                summary_df["service_provider_id"] = pd.to_numeric(summary_df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
                summary_df["revenue"] = pd.to_numeric(summary_df["revenue"], errors="coerce").fillna(0.0)
            else:
                summary_df = pd.DataFrame(columns=["tenant_id", "service_provider_name", "service_provider_id", "revenue"])

            # Process trend data
            if isinstance(trend_df, pd.DataFrame) and not trend_df.empty:
                trend_df["tenant_id"] = pd.to_numeric(trend_df["tenant_id"], errors="coerce").fillna(-1).astype(int)
                trend_df["service_provider_id"] = pd.to_numeric(trend_df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
                trend_df["modified_date"] = pd.to_datetime(trend_df["modified_date"], utc=True)
                trend_df["revenue"] = pd.to_numeric(trend_df["revenue"], errors="coerce").fillna(0.0)
            else:
                trend_df = pd.DataFrame(columns=["service_provider_name", "service_provider_id", "tenant_id", "modified_date", "revenue"])

            # Calculate total revenue per provider
            total_map = {}
            if not summary_df.empty:
                for _, row in summary_df.iterrows():
                    # Convert tuple key to string format for JSON serialization
                    key_str = f"{int(row['tenant_id'])}_{int(row['service_provider_id'])}"
                    total_map[key_str] = total_map.get(key_str, 0.0) + float(row["revenue"])

            # Collect tenant and provider metadata
            tenant_map, provider_map = {}, {}
            
            if not trend_df.empty:
                # Collect unique tenant IDs
                tenant_ids = trend_df["tenant_id"].unique().tolist()
                for tid in tenant_ids:
                    if tid != -1:
                        tenant_map[tid] = ""
                
                # Collect provider info
                for _, row in trend_df.iterrows():
                    pid = int(row["service_provider_id"])
                    pname = row["service_provider_name"] if pd.notnull(row["service_provider_name"]) and row["service_provider_name"] != "" else "Unknown provider"
                    provider_map[pid] = pname

            # Fetch tenant names
            if tenant_map:
                try:
                    tenant_ids = list(tenant_map.keys())
                    if tenant_ids:
                        placeholders = ','.join(['%s'] * len(tenant_ids))
                        query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({placeholders})"
                        df_tenants = common_utils_database.execute_query(query, params=tenant_ids)
                        
                        if isinstance(df_tenants, pd.DataFrame) and not df_tenants.empty:
                            for _, row in df_tenants.iterrows():
                                tenant_map[int(row["tenant_id"])] = row["tenant_name"]
                except Exception as tenant_exc:
                    logging.warning(f"Failed to fetch tenant names: {tenant_exc}")

            # Cache the raw data (not aggregated by buckets)
            cache_payload = {
                "raw_summary_df": summary_df.to_dict('records') if not summary_df.empty else [],
                "raw_trend_df": trend_df.to_dict('records') if not trend_df.empty else [],
                "total_map": total_map,
                "meta": {
                    "tenants": tenant_map,
                    "providers": provider_map,
                    "default_time_range": "1_month"
                }
            }
            
            try:
                redis_client.setex(cache_key, 9000, json.dumps(cache_payload, default=str))
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")

            # Audit logging
            try:
                audit_data = {
                    "function_name": function,
                    "created_date": request_received_at,
                    "created_by": username,
                    "last_synced_by": username
                }
                common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
            except Exception as audit_exc:
                logging.warning(f"Audit logging failed: {audit_exc}")

            cached_raw_data = cache_payload

        # -------- Extract data from cache --------
        raw_summary_records = cached_raw_data.get("raw_summary_df", [])
        raw_trend_records = cached_raw_data.get("raw_trend_df", [])
        total_map_str = cached_raw_data.get("total_map", {})
        meta_info = cached_raw_data.get("meta", {
            "tenants": {},
            "providers": {},
            "default_time_range": "1_month"
        })
        
        # Convert string keys back to tuple for use in code
        total_map = {}
        for key_str, value in total_map_str.items():
            try:
                # Parse string key back to tuple: "tenant_id_provider_id"
                parts = key_str.split('_')
                if len(parts) == 2:
                    key_tuple = (int(parts[0]), int(parts[1]))
                    total_map[key_tuple] = value
            except Exception as e:
                logging.warning(f"Failed to parse key {key_str}: {e}")

        # Convert raw data to DataFrames
        if raw_summary_records:
            summary_df = pd.DataFrame(raw_summary_records)
            summary_df["tenant_id"] = pd.to_numeric(summary_df["tenant_id"], errors="coerce").fillna(-1).astype(int)
            summary_df["service_provider_id"] = pd.to_numeric(summary_df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
            summary_df["revenue"] = pd.to_numeric(summary_df["revenue"], errors="coerce").fillna(0.0)
        else:
            summary_df = pd.DataFrame(columns=["tenant_id", "service_provider_name", "service_provider_id", "revenue"])

        if raw_trend_records:
            trend_df = pd.DataFrame(raw_trend_records)
            trend_df["tenant_id"] = pd.to_numeric(trend_df["tenant_id"], errors="coerce").fillna(-1).astype(int)
            trend_df["service_provider_id"] = pd.to_numeric(trend_df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
            trend_df["modified_date"] = pd.to_datetime(trend_df["modified_date"], utc=True)
            trend_df["bill_start_date"] = pd.to_datetime(trend_df["bill_start_date"], utc=True)
            trend_df["bill_end_date"] = pd.to_datetime(trend_df["bill_end_date"], utc=True)
            trend_df["revenue"] = pd.to_numeric(trend_df["revenue"], errors="coerce").fillna(0.0)
        else:
            trend_df = pd.DataFrame(columns=["service_provider_name", "service_provider_id", "tenant_id", "modified_date", "revenue"])

        # -------- APPLY FILTERS FIRST (BEFORE BUCKETING) --------
        
        filtered_trend_df = trend_df.copy()
        has_billing_cycle_filter = False
        has_date_range_filter = False
        selected_bucket = None
        
        # 1. Apply tenant filter
        if tenant_id and tenant_id != "All":
            try:
                tid_int = int(tenant_id)
                filtered_trend_df = filtered_trend_df[filtered_trend_df["tenant_id"] == tid_int]
            except Exception as tenant_filter_exc:
                logging.warning(f"Invalid tenant_id filter: {tenant_filter_exc}")

        # 2. Apply service provider filter
        if service_provider and service_provider != "":
            # Find provider ID from name
            provider_ids = []
            for pid, pname in meta_info.get("providers", {}).items():
                if pname == service_provider:
                    provider_ids.append(int(pid))
            
            if provider_ids:
                filtered_trend_df = filtered_trend_df[filtered_trend_df["service_provider_id"].isin(provider_ids)]

        # 3. Apply billing cycle filter
        if billing_cycle_end_date and billing_cycle_end_date != "":
            try:
                billing_end = pd.to_datetime(billing_cycle_end_date, utc=True)
                billing_start = billing_end - pd.DateOffset(months=1)
                
                # Filter trend_df by billing cycle date range
                filtered_trend_df = filtered_trend_df[
                    (filtered_trend_df["bill_start_date"] >= billing_start) & 
                    (filtered_trend_df["bill_end_date"] <= billing_end)
                ]
                
                has_billing_cycle_filter = True
                selected_bucket = "1_month"
                meta_info["default_time_range"] = "1_month"
                
            except Exception as billing_exc:
                logging.error(f"Error applying billing cycle filter: {billing_exc}")

        # 4. Apply date range filter (start_date/end_date)
        if start_date and end_date:
            try:
                # Convert to timezone-aware datetime objects covering full days
                start_dt = pd.Timestamp(start_date).tz_localize("UTC").normalize()  # Start of day
                end_dt = pd.Timestamp(end_date).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)  # End of day
                
                # Filter trend_df by date range
                filtered_trend_df = filtered_trend_df[
                    (filtered_trend_df["modified_date"] >= start_dt) & 
                    (filtered_trend_df["modified_date"] <= end_dt)
                ]
                
                # Determine which bucket to use based on date range
                date_diff =  (end_dt - start_dt).days + 1
                
                if date_diff == 1:
                    selected_bucket = "1_day"
                elif date_diff <= 5:
                    selected_bucket = "5_day"
                elif date_diff <= 7:
                    selected_bucket = "5_day"
                elif date_diff <= 31:
                    selected_bucket = "1_month"
                elif date_diff <= 93:
                    selected_bucket = "3_month"
                elif date_diff <= 186:
                    selected_bucket = "6_month"
                elif date_diff <= 366:
                    selected_bucket = "1_year"
                elif date_diff <= 1826:
                    selected_bucket = "5_years"
                else:
                    selected_bucket = "max"
                
                has_date_range_filter = True
                meta_info["default_time_range"] = selected_bucket
                
            except Exception as date_filter_exc:
                logging.error(f"Error applying date filter: {date_filter_exc}")

        # -------- NOW DO BUCKETING --------
        
        now = _now_ts()
        now_tenant = _now_ts_tenant()
        
        # Initialize grouped_data with empty arrays for all possible buckets
        all_bucket_names = ["1_day", "5_day", "1_month", "3_month", "6_month", "1_year", "5_years", "max", "custom_range"]
        grouped_data = {bucket: [] for bucket in all_bucket_names}

        # Check if we have date range filters
        if has_date_range_filter:
            # When date range filter is applied, only populate the selected bucket
            meta_info["default_time_range"] = selected_bucket
            
            # Convert date objects to timestamps for segment generation
            start_dt = pd.Timestamp(start_date).tz_localize("UTC").normalize()
            end_dt = pd.Timestamp(end_date).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            if selected_bucket == "1_day":
                # For 1-day range, generate 4-hour segments for that specific day
                # Use the start_date for segment generation (since it's a single day)
                segments = _segments_1_day_for_date(start_dt)
                time_with_hours_flag = True
                year_only = False
                
            elif selected_bucket == "5_day":
                # For 5-day range, generate daily segments for that specific range
                segments = _segments_5_day_for_range(start_dt.date(), end_dt.date())
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "1_month":
                # For 1-month range, generate weekly segments for that specific range
                segments = _month_week_segments_range(start_dt, end_dt, True)
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "3_month":
                # For 3-month range, generate weekly segments for that specific range
                segments = _month_week_segments_range(start_dt, end_dt, True)
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "6_month":
                # For 6-month range, generate weekly segments for that specific range
                segments = _month_week_segments_range(start_dt, end_dt, True)
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "1_year":
                # For 1-year range, generate weekly segments for that specific range
                segments = _month_week_segments_range(start_dt, end_dt, True)
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "5_years":
                # For multi-year range, generate yearly segments
                years_diff = (end_dt.year - start_dt.year) + 1
                segments = _year_segments_last_n_years(years_diff, end_dt)
                time_with_hours_flag = False
                year_only = True
                
            elif selected_bucket == "max":
                # For max range, generate yearly segments for the entire range
                years_diff = (end_dt.year - start_dt.year) + 1
                segments = _year_segments_last_n_years(years_diff, end_dt)
                time_with_hours_flag = False
                year_only = True
                
            else:
                segments = []
                time_with_hours_flag = False
                year_only = False
            
            if segments:
                rows = _aggregate_non_cumulative(
                    filtered_trend_df,
                    segments,
                    time_with_hours_flag,
                    year_only
                )

                # Update total revenue from the total_map
                for row in rows:
                    tid = row["tenant_id"]
                    pid = row["provider_id"]
                    total_rev = total_map.get((tid, pid), 0.0)
                    row["Revenue"] = f"${total_rev:.2f}"

                grouped_data[selected_bucket] = rows

        elif has_billing_cycle_filter:
            # When billing cycle filter is applied, populate ALL buckets
            meta_info["default_time_range"] = "1_month"
            
            # Calculate proper date ranges for each bucket (using current date)
            month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            year_start = (now - pd.DateOffset(years=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            
            # Generate segments for ALL buckets
            segments_by_label = {
                "1_day": _segments_1_day(now_tenant),
                "5_day": _segments_5_day(now),
                "1_month": _month_week_segments_range(month_start, now, True),
                "3_month": _month_week_segments_range(three_months_start, now, True),
                "6_month": _month_week_segments_range(six_months_start, now, True),
                "1_year": _month_week_segments_range(year_start, now, True),
                "5_years": _year_segments_last_n_years(5, now),
                "max": [],
                "custom_range": [],
            }

            # Generate max segments based on filtered data range
            if not filtered_trend_df.empty:
                min_date = filtered_trend_df["modified_date"].min()
                max_date = filtered_trend_df["modified_date"].max()
                if pd.notnull(min_date) and pd.notnull(max_date):
                    years_diff = max_date.year - min_date.year + 1
                    segments_by_label["max"] = _year_segments_last_n_years(years_diff, max_date)

            for label, segments in segments_by_label.items():
                if not segments:
                    grouped_data[label] = []
                    continue

                # For 1_day bucket, time_with_hours=True, for others False
                time_with_hours_flag = (label == "1_day")
                year_only_flag = (label in ["5_years", "max"])
                
                rows = _aggregate_non_cumulative(
                    filtered_trend_df,
                    segments,
                    time_with_hours_flag,
                    year_only_flag
                )

                # Update total revenue from the total_map
                for row in rows:
                    tid = row["tenant_id"]
                    pid = row["provider_id"]
                    total_rev = total_map.get((tid, pid), 0.0)
                    row["Revenue"] = f"${total_rev:.2f}"

                grouped_data[label] = rows

        else:
            # NO FILTER: Populate ALL buckets with unfiltered data
            # Calculate proper date ranges for each bucket (using current date)
            month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            year_start = (now - pd.DateOffset(years=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            
            # Generate segments for ALL buckets
            segments_by_label = {
                "1_day": _segments_1_day(now_tenant),
                "5_day": _segments_5_day(now),
                "1_month": _month_week_segments_range(month_start, now, True),
                "3_month": _month_week_segments_range(three_months_start, now, True),
                "6_month": _month_week_segments_range(six_months_start, now, True),
                "1_year": _month_week_segments_range(year_start, now, True),
                "5_years": _year_segments_last_n_years(5, now),
                "max": [],
                "custom_range": [],
            }

            # Generate max segments based on filtered data range
            if not filtered_trend_df.empty:
                min_date = filtered_trend_df["modified_date"].min()
                max_date = filtered_trend_df["modified_date"].max()
                if pd.notnull(min_date) and pd.notnull(max_date):
                    years_diff = max_date.year - min_date.year + 1
                    segments_by_label["max"] = _year_segments_last_n_years(years_diff, max_date)

            for label, segments in segments_by_label.items():
                if not segments:
                    grouped_data[label] = []
                    continue

                # Set time_with_hours_flag and year_only based on bucket
                time_with_hours_flag = (label == "1_day")
                year_only_flag = (label in ["5_years", "max"])
                
                rows = _aggregate_non_cumulative(
                    filtered_trend_df,
                    segments,
                    time_with_hours_flag,
                    year_only_flag
                )

                # Update total revenue from the total_map
                for row in rows:
                    tid = row["tenant_id"]
                    pid = row["provider_id"]
                    total_rev = total_map.get((tid, pid), 0.0)
                    row["Revenue"] = f"${total_rev:.2f}"

                grouped_data[label] = rows

        # Prepare final response - MAINTAIN ORIGINAL FORMAT
        response["flag"] = True
        response["data"]["data"] = grouped_data
        response["meta"] = meta_info
        response["message"] = ""

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error retrieving revenue by carrier: {exception}"
        logging.exception("Error in get_revenue_by_carrier")

        # Error logging
        try:
            error_data = {
                "service_name": "get_revenue_by_carrier",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"Error logging failure: {log_exc}")

    return response


def get_revenue_by_rate_plan(data):
    """
    Returns a breakdown of revenue by rateplan based on service provider.
    **Optimization (2026-01-15):**
    - Apply filters BEFORE bucketing to reduce processing time
    - Filter trend_df before generating segments and aggregating
    - When date range filters applied: populate only the selected bucket based on date range
    - When no date range filters: populate all buckets
    
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): Chart-ready data with revenue by rate plan.
            - 'message' (str): Error message if applicable.
    """
    tenant_id = data.get("tenant_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
    tenant_name = data.get("tenant_name", "")
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get("service_provider", "")
    billing_cycle_end_date = data.get("billing_cycle_end_period", "")

    response = {
        "flag": False,
        "meta": {"tenants": {}, "providers": {}, "default_time_range": "custom_range"},
        "data": {
            "title": "Revenue By Rate Plan",
            "chart_type": "",
            "xField": "revenue",
            "yField": [],
            "data": {},
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        mode = os.environ.get('ENV','')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        
        # Fetch tenant timezone
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"
        
        # ---------- helpers (always available) ----------
        def _now_ts():
            """Returns current timestamp in UTC for segment generation."""
            return pd.Timestamp.now(tz="UTC")
        
        def _now_ts_tenant():
            """Returns current timestamp in tenant timezone for 1_day bucket."""
            try:
                import pytz    
                tz = pytz.timezone(tenant_time_zone if tenant_time_zone else "UTC")            
                now_local = pd.Timestamp.now(tz=tz)           
                now_utc = now_local.tz_convert("UTC")           
                logging.info(f"### Using tenant timezone {tenant_time_zone}: "
                            f"local_now={now_local}, utc_now={now_utc}")
                return now_utc
            except Exception as tz_conv_exc:
                logging.warning(f"Failed to convert to tenant timezone: {tz_conv_exc}. Using UTC.")
                return pd.Timestamp.now(tz="UTC")

        def _normalize_date(ts):
            """Normalizes a timestamp to midnight (start of day)."""
            try:
                t = pd.to_datetime(ts, utc=True)
                return t.normalize()
            except Exception:
                return pd.to_datetime(ts, utc=True).normalize()

        def _eom(ts):
            """Returns the end-of-month timestamp for the given date."""
            t = pd.to_datetime(ts, utc=True)
            return t + pd.offsets.MonthEnd(0)

        def _fmt_date(ts):
            """Formats a timestamp as 'YYYY-MM-DD'."""
            t = pd.to_datetime(ts, utc=True)
            return t.date().isoformat()

        def _fmt_dt(ts):
            """Formats a timestamp as ISO 8601 UTC string 'YYYY-MM-DDTHH:MM:SSZ'."""
            try:
                t = pd.to_datetime(ts, utc=True)
                return t.strftime('%Y-%m-%dT%H:%M:%SZ')
            except Exception:
                t = pd.to_datetime(ts, utc=True)
                return t.strftime('%Y-%m-%dT%H:%M:%SZ')
        
        # NEW FORMATTING FUNCTIONS
        def _fmt_date_only(ts):
            """Formats a timestamp as 'YYYY-MM-DD' (date only)."""
            t = pd.to_datetime(ts, utc=True)
            return t.strftime('%Y-%m-%d')

        def _fmt_date_with_time(ts):
            """Formats a timestamp as ISO 8601 UTC string 'YYYY-MM-DDTHH:MM:SSZ'."""
            t = pd.to_datetime(ts, utc=True)
            return t.strftime('%Y-%m-%dT%H:%M:%SZ')

        def _fmt_year_only(ts):
            """Formats a timestamp as just the year 'YYYY'."""
            t = pd.to_datetime(ts, utc=True)
            return str(t.year)

        def _generate_month_week_segments(month_start, month_end):
            """Generates weekly segments for a month: 1-7, 8-14, 15-21, 22-28, 29-EOM.
               Label is the LAST DATE of each week (normalized to midnight)."""
            segments = []
            
            # Get month info
            year = month_start.year
            month = month_start.month
            
            # Define week boundaries
            week_boundaries = [
                (1, 7),    # Week 1: 1-7
                (8, 14),   # Week 2: 8-14  
                (15, 21),  # Week 3: 15-21
                (22, 28),  # Week 4: 22-28
                (29, None) # Week 5: 29-end of month
            ]
            
            for start_day, end_day in week_boundaries:
                # Skip if start day is beyond month end
                if start_day > month_end.day:
                    break
                
                # Calculate actual end day
                if end_day is None:
                    # Last week: 29 to end of month
                    actual_end_day = month_end.day
                else:
                    actual_end_day = min(end_day, month_end.day)
                
                # Skip if start day > actual end day (for short months)
                if start_day > actual_end_day:
                    continue
                
                # Create segment start (first day of week at 00:00:00)
                seg_start = pd.Timestamp(
                    year=year, month=month, day=start_day,
                    hour=0, minute=0, second=0, microsecond=0,
                    tz="UTC"
                )
                
                # Create segment end (last day of week at 23:59:59.999999)
                seg_end = pd.Timestamp(
                    year=year, month=month, day=actual_end_day,
                    hour=23, minute=59, second=59, microsecond=999999,
                    tz="UTC"
                )
                
                # Ensure segment end doesn't exceed month_end
                if seg_end > month_end:
                    seg_end = month_end
                
                # Label is the LAST DATE of the week, normalized to midnight
                # This gives us just the date part (YYYY-MM-DD)
                label_date = pd.Timestamp(
                    year=year, month=month, day=actual_end_day,
                    tz="UTC"
                ).normalize()
                
                segments.append((seg_start, seg_end, label_date))
            
            return segments

        def _month_week_segments_range(start_month_ts, end_ts, include_today_partial=True):
            """Generates weekly segments across a range of months."""
            segments = []
            
            # Start from the 1st day of the starting month
            current_month = pd.Timestamp(
                year=start_month_ts.year,
                month=start_month_ts.month,
                day=1,
                hour=0, minute=0, second=0, microsecond=0,
                tz="UTC"
            )
            
            # End at the first day of the ending month (we iterate month-by-month)
            end_month = pd.Timestamp(
                year=end_ts.year,
                month=end_ts.month,
                day=1,
                hour=0, minute=0, second=0, microsecond=0,
                tz="UTC"
            )
            
            while current_month <= end_month:
                # Get the end of this month
                month_end = _eom(current_month)
                if month_end > end_ts:
                    month_end = end_ts
                
                # Generate WEEKLY segments for this month (1-7, 8-14, 15-21, 22-28, 29-EOM)
                month_segments = _generate_month_week_segments(current_month, month_end)
                segments.extend(month_segments)
                
                # Move to next month
                next_month = current_month + pd.DateOffset(months=1)
                current_month = next_month
            
            return segments

        def _year_segments_last_n_years(n_years, end_ts):
            """Generates yearly segments for the last n years including the current year."""
            segments = []
            start_year = end_ts.year - n_years + 1
            
            for year in range(start_year, end_ts.year):
                year_start = pd.Timestamp(year=year, month=1, day=1, tz="UTC")
                year_end = pd.Timestamp(year=year, month=12, day=31, hour=23, minute=59, second=59, tz="UTC")
                # Label is just the year (normalized to Jan 1 of that year)
                label_ts = pd.Timestamp(year=year, month=1, day=1, tz="UTC").normalize()
                segments.append((year_start, year_end, label_ts))
            
            # Current year (partial)
            current_year_start = pd.Timestamp(year=end_ts.year, month=1, day=1, tz="UTC")
            # Label is just the year (normalized to Jan 1 of that year)
            label_ts = pd.Timestamp(year=end_ts.year, month=1, day=1, tz="UTC").normalize()
            segments.append((current_year_start, end_ts, label_ts))
            
            return segments

        def _segments_1_day(now_ts):
            """Splits a single day into 4-hour segments for the entire day."""
            start_of_day = _normalize_date(now_ts)
            end_of_day = start_of_day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            # Create 4-hour intervals
            anchors = list(pd.date_range(
                start=start_of_day, 
                periods=7,  # 7 points for 6 intervals
                freq="4h", 
                tz="UTC"
            ))
            
            # Ensure last anchor is end of day
            anchors[-1] = end_of_day
            
            # Create segments - label is the END timestamp (with time)
            segments = []
            for i in range(len(anchors) - 1):
                seg_start = anchors[i]
                seg_end = anchors[i + 1]
                # Label is the END timestamp (with hours/minutes/seconds)
                segments.append((seg_start, seg_end, seg_end))
            
            return segments

        def _segments_5_day(now_ts):
            """Splits the last 5 days into daily segments."""
            today = _normalize_date(now_ts)
            start_day = today - pd.Timedelta(days=4)
            days = list(pd.date_range(start=start_day, end=today, freq="D", tz="UTC"))
            
            segments = []
            for i, day in enumerate(days):
                seg_start = day
                if i == len(days) - 1:  # Today
                    seg_end = now_ts
                    # Label is just the date (normalized)
                    label_ts = now_ts.normalize()
                else:
                    seg_end = day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    # Label is just the date (normalized)
                    label_ts = seg_end.normalize()
                
                segments.append((seg_start, seg_end, label_ts))
            
            return segments

        def _segments_1_day_for_date(target_date):
            """Splits a specific date (not necessarily today) into 4-hour segments."""
            start_of_day = _normalize_date(target_date)
            end_of_day = start_of_day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            # Create 4-hour intervals
            anchors = list(pd.date_range(
                start=start_of_day, 
                periods=7,  # 7 points for 6 intervals
                freq="4h", 
                tz="UTC"
            ))
            
            # Ensure last anchor is end of day
            anchors[-1] = end_of_day
            
            # Create segments - label is the END timestamp (with time)
            segments = []
            for i in range(len(anchors) - 1):
                seg_start = anchors[i]
                seg_end = anchors[i + 1]
                # Label is the END timestamp (with hours/minutes/seconds)
                segments.append((seg_start, seg_end, seg_end))
            
            return segments

        def _segments_5_day_for_range(start_date_obj, end_date_obj):
            """Splits a specific 5-day range into daily segments."""
            # Convert to UTC timestamps
            start_ts = pd.Timestamp(start_date_obj).tz_localize("UTC").normalize()
            end_ts = pd.Timestamp(end_date_obj).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            # Create daily segments
            days = list(pd.date_range(start=start_ts, end=end_ts, freq="D", tz="UTC"))
            
            segments = []
            for i, day in enumerate(days):
                seg_start = day
                if i == len(days) - 1:  # Last day
                    seg_end = end_ts
                    # Label is just the date (normalized)
                    label_ts = end_ts.normalize()
                else:
                    seg_end = day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    # Label is just the date (normalized)
                    label_ts = seg_end.normalize()
                
                segments.append((seg_start, seg_end, label_ts))
            
            return segments

        def _aggregate_non_cumulative(df, segments, time_with_hours, year_only=False):
            """
            Aggregates `df` for the provided `segments` list.
            Returns list of dicts with tenant_id, provider_id, service_provider_name, 
            customer_rate_plan_name, revenue, statistic, and records.
            """
            if df.empty:
                return []
            
            records_by_key = defaultdict(list)
            
            for seg_start, seg_end, label_ts in segments:
                # Filter records for this segment
                mask = (df["modified_date"] >= seg_start) & (df["modified_date"] <= seg_end)
                sub_df = df.loc[mask]
                
                if sub_df.empty:
                    continue
                
                # Group and aggregate
                grouped = (
                    sub_df.groupby(["tenant_id", "service_provider_id", "service_provider_name", "customer_rate_plan_name"], as_index=False)
                    .agg({"revenue": "sum", "modified_date": "max"})
                    .rename(columns={"modified_date": "rep_modified_date"})
                )
                
                for _, row in grouped.iterrows():
                    # Determine time label based on format requirements:
                    # - 1_day bucket: "2026-01-13T00:00:00Z" (ISO with time)
                    # - 5_day, 1_month, 3_month, 6_month, 1_year: "2026-01-07" (date only)
                    # - 5_year, max: "2026" (year only)
                    
                    if year_only:
                        # For 5_year and max buckets
                        t_str = _fmt_year_only(label_ts)
                    else:
                        if time_with_hours:
                            # For 1_day bucket (4-hour segments)
                            t_str = _fmt_date_with_time(label_ts)
                        else:
                            # For 5_day, 1_month, 3_month, 6_month, 1_year buckets
                            t_str = _fmt_date_only(label_ts)
                    
                    tid = int(row["tenant_id"])
                    pid = int(row["service_provider_id"])
                    pname = row["service_provider_name"] if pd.notnull(row["service_provider_name"]) and row["service_provider_name"] != "" else "Unknown provider"
                    plan_name = row["customer_rate_plan_name"] if pd.notnull(row["customer_rate_plan_name"]) and row["customer_rate_plan_name"] != "" else "Unknown plan"
                    val = float(row["revenue"]) if pd.notnull(row["revenue"]) and np.isfinite(row["revenue"]) else 0.0
                    
                    key = (tid, pid, pname, plan_name)
                    records_by_key[key].append([t_str, val])
            
            # Convert to final rows
            rows = []
            for (tid, pid, pname, plan_name), recs in records_by_key.items():
                # Sort records by time
                recs.sort(key=lambda x: x[0])
                stat = [rv for _, rv in recs]
                
                rows.append({
                    "tenant_id": tid,
                    "provider_id": pid,
                    "service_provider_name": pname,
                    "customer_rate_plan_name": plan_name,
                    "Revenue": f"${sum(rv for _, rv in recs):.2f}",
                    "Statistic": stat,
                    "records": recs,
                })
            
            return rows

        def _select_appropriate_bucket(start_date_obj, end_date_obj):
            """Selects the most appropriate bucket based on date range."""
            if not start_date_obj or not end_date_obj:
                return "1_month"
            
            # Calculate difference in days
            delta = (end_date_obj - start_date_obj).days
            
            if delta <= 1:
                return "1_day"
            elif delta <= 5:
                return "5_day"
            elif delta <= 7:
                return "5_day"
            elif delta <= 31:
                return "1_month"
            elif delta <= 93:
                return "3_month"
            elif delta <= 186:
                return "6_month"
            elif delta <= 366:
                return "1_year"
            elif delta <= 1826:  # 5 years
                return "5_years"
            else:
                return "max"

        # Redis cache logic
        function = "get_revenue_by_rate_plan"
        cache_key = get_cache_key(tenant_database, function)
        cached_raw_data = None

        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_raw_data = json.loads(cached_response)
                    logging.info(f"Cache hit for key: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Cache retrieval failed: {cache_exc}")

        # If refresh or no cache — fetch fresh data and cache
        if refresh or cached_raw_data is None:
            logging.info("Fetching fresh revenue data from DB")

            query = """
                SELECT
                    ROUND(
                        SUM(
                            COALESCE(cc.charge_amount, 0)
                          + COALESCE(cc.usage_mb, 0)
                          + COALESCE(cc.sms_cost, 0)
                        )::numeric,
                        2
                    ) AS charges,
                    cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    cs.customer_rate_plan_name,
                    cc.created_date as modified_date,
                    SPLIT_PART(bill_range,' - ',1)::DATE AS bill_start_date,
                    SPLIT_PART(bill_range,' - ',2)::DATE AS bill_end_date
                FROM customer_charges cc 
                JOIN customer_services cs ON cs.id = cc.customer_service_id 
                WHERE cc.is_active = false
                  and cc.is_billed  = true
                  and cc.category = 'MRC'
                AND cs.customer_rate_plan_name IS NOT NULL
                GROUP BY cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    cs.customer_rate_plan_name,
                    cc.created_date,
                    cc.bill_range
            """
            
            df = killbill_database.execute_query(query, flag=True)

            if isinstance(df, pd.DataFrame) and not df.empty:
                # Process dataframe
                df["tenant_id"] = pd.to_numeric(df["tenant_id"], errors="coerce").fillna(-1).astype(int)
                df["service_provider_id"] = pd.to_numeric(df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
                df['modified_date'] = pd.to_datetime(df['modified_date'], utc=True)
                df["bill_start_date"] = pd.to_datetime(df["bill_start_date"], errors="coerce", utc=True)
                df["bill_end_date"] = pd.to_datetime(df["bill_end_date"], errors="coerce", utc=True)
                df["revenue"] = pd.to_numeric(df.get("charges", 0), errors="coerce").fillna(0).astype(float)
                df["service_provider_name"] = df["service_provider_name"].fillna("Unknown provider")
                df["customer_rate_plan_name"] = df["customer_rate_plan_name"].fillna("Unknown plan")
            else:
                df = pd.DataFrame(columns=["service_provider_id", "tenant_id", "service_provider_name", "customer_rate_plan_name", "charges", "modified_date", "revenue", "bill_start_date", "bill_end_date"])
            
            # Collect metadata
            meta_tenants = {}
            meta_providers = {}
            
            if not df.empty:
                tenant_ids = df["tenant_id"].unique()
                for tid in tenant_ids:
                    tid = int(tid)
                    if tid != -1:
                        meta_tenants[tid] = ""
                
                for _, row in df.iterrows():
                    pid = int(row["service_provider_id"])
                    pname = row["service_provider_name"]
                    meta_providers[pid] = pname
            
            # Fetch tenant names
            if meta_tenants:
                try:
                    tenant_ids = [int(k) for k in meta_tenants.keys()]
                    if tenant_ids:
                        placeholders = ','.join(['%s'] * len(tenant_ids))
                        query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({placeholders})"
                        df_tenants = common_utils_database.execute_query(query, params=tenant_ids)
                        
                        if isinstance(df_tenants, pd.DataFrame) and not df_tenants.empty:
                            for _, row in df_tenants.iterrows():
                                meta_tenants[int(row["tenant_id"])] = row["tenant_name"]
                except Exception as tenant_exc:
                    logging.warning(f"Failed to fetch tenant names: {tenant_exc}")
            
            # Cache raw data
            cache_payload = {
                "raw_trend_df": df.to_dict('records') if not df.empty else [],
                "meta": {
                    "tenants": meta_tenants,
                    "providers": meta_providers
                }
            }
            
            try:
                redis_client.setex(cache_key, 9000, json.dumps(cache_payload, default=str))
                logging.info(f"Cache set for key: {cache_key}")
                
                # Audit logging
                audit_data = {
                    "function_name": function,
                    "created_by": username,
                    "last_synced_by": username,
                }
                common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")
            
            cached_raw_data = cache_payload

        # -------- Extract data from cache --------
        raw_trend_records = cached_raw_data.get("raw_trend_df", [])
        meta_info = cached_raw_data.get("meta", {
            "tenants": {},
            "providers": {}
        })
        
        # Convert raw data to DataFrame
        if raw_trend_records:
            trend_df = pd.DataFrame(raw_trend_records)
            trend_df["tenant_id"] = pd.to_numeric(trend_df["tenant_id"], errors="coerce").fillna(-1).astype(int)
            trend_df["service_provider_id"] = pd.to_numeric(trend_df["service_provider_id"], errors="coerce").fillna(-1).astype(int)
            trend_df['modified_date'] = pd.to_datetime(trend_df['modified_date'], utc=True)
            trend_df["bill_start_date"] = pd.to_datetime(trend_df["bill_start_date"], errors="coerce", utc=True)
            trend_df["bill_end_date"] = pd.to_datetime(trend_df["bill_end_date"], errors="coerce", utc=True)
            trend_df["revenue"] = pd.to_numeric(trend_df.get("revenue", 0), errors="coerce").fillna(0).astype(float)
            trend_df["service_provider_name"] = trend_df.get("service_provider_name", "Unknown provider").fillna("Unknown provider")
            trend_df["customer_rate_plan_name"] = trend_df.get("customer_rate_plan_name", "Unknown plan").fillna("Unknown plan")
        else:
            trend_df = pd.DataFrame(columns=["service_provider_id", "tenant_id", "service_provider_name", "customer_rate_plan_name", "modified_date", "revenue", "bill_start_date", "bill_end_date"])
        
        # -------- APPLY FILTERS FIRST (BEFORE BUCKETING) --------
        
        filtered_trend_df = trend_df.copy()
        has_billing_cycle_filter = False
        has_date_range_filter = False
        selected_bucket = None
        
        # 1. Apply tenant filter
        if tenant_id and tenant_id != "All":
            try:
                tid_int = int(tenant_id)
                filtered_trend_df = filtered_trend_df[filtered_trend_df["tenant_id"] == tid_int]
            except Exception as tenant_filter_exc:
                logging.warning(f"Invalid tenant_id filter: {tenant_filter_exc}")

        # 2. Apply service provider filter
        if service_provider and service_provider != "":
            # Find provider ID from name
            provider_ids = []
            for pid, pname in meta_info.get("providers", {}).items():
                if pname == service_provider:
                    provider_ids.append(int(pid))
            
            if provider_ids:
                filtered_trend_df = filtered_trend_df[filtered_trend_df["service_provider_id"].isin(provider_ids)]

        # 3. Apply billing cycle filter
        if billing_cycle_end_date and billing_cycle_end_date != "":
            try:
                billing_end = pd.to_datetime(billing_cycle_end_date, utc=True)
                billing_start = billing_end - pd.DateOffset(months=1)
                
                # Filter trend_df by billing cycle date range
                filtered_trend_df = filtered_trend_df[
                    (filtered_trend_df["bill_start_date"] >= billing_start) & 
                    (filtered_trend_df["bill_end_date"] <= billing_end)
                ]
                
                has_billing_cycle_filter = True
                selected_bucket = "1_month"
                meta_info["default_time_range"] = "1_month"
                
            except Exception as billing_exc:
                logging.error(f"Error applying billing cycle filter: {billing_exc}")

        # 4. Apply date range filter (start_date/end_date)
        if start_date and end_date:
            try:
                # Convert to timezone-aware datetime objects covering full days
                start_dt = pd.Timestamp(start_date).tz_localize("UTC").normalize()  # Start of day
                end_dt = pd.Timestamp(end_date).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)  # End of day
                
                # Filter trend_df by date range
                filtered_trend_df = filtered_trend_df[
                    (filtered_trend_df["modified_date"] >= start_dt) & 
                    (filtered_trend_df["modified_date"] <= end_dt)
                ]
                
                # Determine which bucket to use based on date range
                date_diff = (end_dt - start_dt).days + 1
                
                if date_diff == 1:
                    selected_bucket = "1_day"
                elif date_diff <= 5:
                    selected_bucket = "5_day"
                elif date_diff <= 7:
                    selected_bucket = "5_day"
                elif date_diff <= 31:
                    selected_bucket = "1_month"
                elif date_diff <= 93:
                    selected_bucket = "3_month"
                elif date_diff <= 186:
                    selected_bucket = "6_month"
                elif date_diff <= 366:
                    selected_bucket = "1_year"
                elif date_diff <= 1826:
                    selected_bucket = "5_years"
                else:
                    selected_bucket = "max"
                
                has_date_range_filter = True
                meta_info["default_time_range"] = selected_bucket
                
            except Exception as date_filter_exc:
                logging.error(f"Error applying date filter: {date_filter_exc}")

        # -------- NOW DO BUCKETING --------
        
        now = _now_ts()
        now_tenant = _now_ts_tenant()
        
        # Initialize grouped_data with empty arrays for all possible buckets
        all_bucket_names = ["1_day", "5_day", "1_month", "3_month", "6_month", "1_year", "5_years", "max", "custom_range"]
        grouped_data = {bucket: [] for bucket in all_bucket_names}

        # If date range filter applied, populate not just the selected bucket but larger buckets too
        bucket_order = ["1_day", "5_day", "1_month", "3_month", "6_month", "1_year", "5_years", "max"]

        if has_date_range_filter:
            # When date range filter is applied, set default time range
            meta_info["default_time_range"] = selected_bucket
            
            # Convert date objects to timestamps for segment generation
            start_dt = pd.Timestamp(start_date).tz_localize("UTC").normalize()
            end_dt = pd.Timestamp(end_date).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)

            # Determine which buckets to populate: selected bucket and all larger buckets
            try:
                sel_idx = bucket_order.index(selected_bucket)
            except ValueError:
                sel_idx = 2  # default to 1_month index if unexpected

            buckets_to_populate = bucket_order[sel_idx:]  # from selected to largest

            for bucket in buckets_to_populate:
                if bucket == "1_day":
                    segments = _segments_1_day_for_date(start_dt)
                    time_with_hours_flag = True
                    year_only = False
                elif bucket == "5_day":
                    segments = _segments_5_day_for_range(start_dt.date(), end_dt.date())
                    time_with_hours_flag = False
                    year_only = False
                elif bucket in ("1_month", "3_month", "6_month", "1_year"):
                    segments = _month_week_segments_range(start_dt, end_dt, True)
                    time_with_hours_flag = False
                    year_only = False
                elif bucket == "5_years":
                    years_diff = (end_dt.year - start_dt.year) + 1
                    segments = _year_segments_last_n_years(years_diff, end_dt)
                    time_with_hours_flag = False
                    year_only = True
                elif bucket == "max":
                    years_diff = (end_dt.year - start_dt.year) + 1
                    segments = _year_segments_last_n_years(years_diff, end_dt)
                    time_with_hours_flag = False
                    year_only = True
                else:
                    segments = []
                    time_with_hours_flag = False
                    year_only = False

                if segments:
                    rows = _aggregate_non_cumulative(
                        filtered_trend_df,
                        segments,
                        time_with_hours_flag,
                        year_only
                    )
                    grouped_data[bucket] = rows

        elif has_billing_cycle_filter:
            # When billing cycle filter is applied, populate ALL buckets
            meta_info["default_time_range"] = "1_month"
            
            # Calculate proper date ranges for each bucket (using current date)
            month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            year_start = (now - pd.DateOffset(years=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            
            # Generate segments for ALL buckets
            segments_by_label = {
                "1_day": _segments_1_day(now_tenant),
                "5_day": _segments_5_day(now),
                "1_month": _month_week_segments_range(month_start, now, True),
                "3_month": _month_week_segments_range(three_months_start, now, True),
                "6_month": _month_week_segments_range(six_months_start, now, True),
                "1_year": _month_week_segments_range(year_start, now, True),
                "5_years": _year_segments_last_n_years(5, now),
                "max": [],
                "custom_range": [],
            }

            # Generate max segments based on filtered data range
            if not filtered_trend_df.empty:
                min_date = filtered_trend_df["modified_date"].min()
                max_date = filtered_trend_df["modified_date"].max()
                if pd.notnull(min_date) and pd.notnull(max_date):
                    years_diff = max_date.year - min_date.year + 1
                    segments_by_label["max"] = _year_segments_last_n_years(years_diff, max_date)

            for label, segments in segments_by_label.items():
                if not segments:
                    grouped_data[label] = []
                    continue

                # Set time_with_hours_flag and year_only based on bucket
                time_with_hours_flag = (label == "1_day")
                year_only_flag = (label in ["5_years", "max"])
                
                rows = _aggregate_non_cumulative(
                    filtered_trend_df,
                    segments,
                    time_with_hours_flag,
                    year_only_flag
                )
                grouped_data[label] = rows

        else:
            # NO FILTER: Populate ALL buckets with unfiltered data
            # Calculate proper date ranges for each bucket (using current date)
            month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            year_start = (now - pd.DateOffset(years=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            
            # Generate segments for ALL buckets
            segments_by_label = {
                "1_day": _segments_1_day(now_tenant),
                "5_day": _segments_5_day(now),
                "1_month": _month_week_segments_range(month_start, now, True),
                "3_month": _month_week_segments_range(three_months_start, now, True),
                "6_month": _month_week_segments_range(six_months_start, now, True),
                "1_year": _month_week_segments_range(year_start, now, True),
                "5_years": _year_segments_last_n_years(5, now),
                "max": [],
                "custom_range": [],
            }

            # Generate max segments based on filtered data range
            if not filtered_trend_df.empty:
                min_date = filtered_trend_df["modified_date"].min()
                max_date = filtered_trend_df["modified_date"].max()
                if pd.notnull(min_date) and pd.notnull(max_date):
                    years_diff = max_date.year - min_date.year + 1
                    segments_by_label["max"] = _year_segments_last_n_years(years_diff, max_date)

            for label, segments in segments_by_label.items():
                if not segments:
                    grouped_data[label] = []
                    continue

                # Set time_with_hours_flag and year_only based on bucket
                time_with_hours_flag = (label == "1_day")
                year_only_flag = (label in ["5_years", "max"])
                
                rows = _aggregate_non_cumulative(
                    filtered_trend_df,
                    segments,
                    time_with_hours_flag,
                    year_only_flag
                )
                grouped_data[label] = rows

        # Format the data for response - ORIGINAL FORMAT PRESERVED
        meta_tenants = {}
        meta_providers = {}
        formatted_buckets = {}
        
        for bucket_name, bucket_data in grouped_data.items():
            if not bucket_data:
                formatted_buckets[bucket_name] = []
                continue
            
            # Group by provider_id for this bucket
            provider_groups = defaultdict(list)
            for record in bucket_data:
                pid = record["provider_id"]
                provider_groups[pid].append(record)
                
                # Collect metadata
                if str(pid) not in meta_providers:
                    meta_providers[str(pid)] = record.get("service_provider_name", "Unknown provider")
            
            formatted = []
            for pid, provider_records in provider_groups.items():
                # Sort records by revenue and get top 5 plans
                sorted_records = sorted(provider_records, key=lambda x: sum(rv for _, rv in x.get("records", [])), reverse=True)[:5]
                
                # Get tenant_id from first record
                tenant_for_bucket = sorted_records[0].get("tenant_id", -1) if sorted_records else -1
                
                # Collect plans
                plans = [rec.get("customer_rate_plan_name", "Unknown plan") for rec in sorted_records]
                
                # Prepare records in the format expected by frontend
                formatted_records = []
                for rec in sorted_records:
                    formatted_records.append([
                        rec.get("records", [])[0][0] if rec.get("records") else "",  # time
                        sum(rv for _, rv in rec.get("records", [])),  # revenue
                        rec.get("customer_rate_plan_name", "Unknown plan")  # plan name
                    ])
                
                formatted.append({
                    "tenant_id": tenant_for_bucket,
                    "provider_id": pid,
                    "plans": plans,
                    "records": formatted_records
                })
                
                # Collect tenant ID
                if tenant_for_bucket not in meta_tenants:
                    meta_tenants[tenant_for_bucket] = None
                    
            formatted_buckets[bucket_name] = formatted

        # Fetch tenant names
        if meta_tenants:
            try:
                ids = [int(k) for k in meta_tenants.keys() if k != -1]
                if ids:
                    query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                    df_tenant = common_utils_database.execute_query(query, params=ids)
                    
                    if isinstance(df_tenant, pd.DataFrame):
                        for row in df_tenant.to_dict(orient="records"):
                            meta_tenants[row["tenant_id"]] = row["tenant_name"]
                
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        response["flag"] = True
        response["meta"]["tenants"] = meta_tenants
        response["meta"]["providers"] = meta_providers if meta_providers else {'-1': 'Unknown provider'}
        response["meta"]["default_time_range"] = meta_info.get("default_time_range", "1_month")
        response["data"]["data"] = formatted_buckets
        return response

    except Exception as exception:
        logging.exception(f"[get_revenue_by_rate_plan] Exception: {exception}")
        response["flag"] = False
        response["data"]["data"] = {}
        response["data"]["yField"] = []
        response["message"] = f"Error retrieving revenue by rate plan {exception}"
        try:
            error_data = {
                "service_name": "get_revenue_by_rate_plan",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[get_revenue_by_rate_plan] Error logging to DB : {e}")

    return response


def get_profit_margin_trend(data):
    """
    Returns a profit margin trend over several months for the dashboard.
    **Optimization (2026-01-15):**
    - Apply filters BEFORE bucketing to reduce processing time
    - Filter trend_df before generating segments and aggregating
    - When date range filters applied: populate only the selected bucket based on date range
    - When no date range filters: populate all buckets
    
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return profit .
            - 'message' (str): Error message if applicable.
    """
    
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
    tenant_name = data.get("tenant_name", "")
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    tenant_id = data.get("tenant_id", "All")
    refresh = str(data.get("refresh", "False")).lower() == "true"
    tenant_database = data.get("db_name", "")
    billing_cycle_end_date = data.get("billing_cycle_end_period", "")
    service_provider = data.get("service_provider", "")

    response = {
        "flag": False,
        "meta": {
            "tenants": {},
            "providers": {},
            "plans": {},
            "default_time_range": "custom_range"
        },
        "data": {
            "title": "Profit Margin Trend",
            "chart_type": "line",
            "xField": ["Jan", "Feb", "Mar"],
            "yField": "profit_margin",
            "data": {},
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        mode = os.environ.get('ENV', '')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        database = DB(data.get("db_name", ""), **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # Fetch tenant timezone
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"

        # ---------- helpers ----------
        def _now_ts():
            """Returns current timestamp in UTC for segment generation."""
            return pd.Timestamp.now(tz="UTC")
        
        def _now_ts_tenant():
            """Returns current timestamp in tenant timezone for 1_day bucket."""
            try:
                import pytz    
                tz = pytz.timezone(tenant_time_zone if tenant_time_zone else "UTC")            
                now_local = pd.Timestamp.now(tz=tz)           
                now_utc = now_local.tz_convert("UTC")           
                logging.info(f"### Using tenant timezone {tenant_time_zone}: "
                            f"local_now={now_local}, utc_now={now_utc}")
                return now_utc
            except Exception as tz_conv_exc:
                logging.warning(f"Failed to convert to tenant timezone: {tz_conv_exc}. Using UTC.")
                return pd.Timestamp.now(tz="UTC")

        def _normalize_date(ts):
            """Normalizes a timestamp to midnight (start of day)."""
            try:
                t = pd.to_datetime(ts, utc=True)
                return t.normalize()
            except Exception:
                return pd.to_datetime(ts, utc=True).normalize()

        def _eom(ts):
            """Returns the end-of-month timestamp for the given date."""
            t = pd.to_datetime(ts, utc=True)
            return t + pd.offsets.MonthEnd(0)

        def _fmt_date(ts):
            """Formats a timestamp as 'YYYY-MM-DD'."""
            t = pd.to_datetime(ts, utc=True)
            return t.date().isoformat()

        def _fmt_dt(ts):
            """Formats a timestamp as ISO 8601 UTC string 'YYYY-MM-DDTHH:MM:SSZ'."""
            try:
                t = pd.to_datetime(ts, utc=True)
                return t.strftime('%Y-%m-%dT%H:%M:%SZ')
            except Exception:
                t = pd.to_datetime(ts, utc=True)
                return t.strftime('%Y-%m-%dT%H:%M:%SZ')
        
        # NEW FORMATTING FUNCTIONS
        def _fmt_date_only(ts):
            """Formats a timestamp as 'YYYY-MM-DD' (date only)."""
            t = pd.to_datetime(ts, utc=True)
            return t.strftime('%Y-%m-%d')

        def _fmt_date_with_time(ts):
            """Formats a timestamp as ISO 8601 UTC string 'YYYY-MM-DDTHH:MM:SSZ'."""
            t = pd.to_datetime(ts, utc=True)
            return t.strftime('%Y-%m-%dT%H:%M:%SZ')

        def _fmt_year_only(ts):
            """Formats a timestamp as just the year 'YYYY'."""
            t = pd.to_datetime(ts, utc=True)
            return str(t.year)

        def _generate_month_week_segments(month_start, month_end):
            """Generates weekly segments for a month: 1-7, 8-14, 15-21, 22-28, 29-EOM.
               Label is the LAST DATE of each week (normalized to midnight)."""
            segments = []
            
            # Get month info
            year = month_start.year
            month = month_start.month
            
            # Define week boundaries
            week_boundaries = [
                (1, 7),    # Week 1: 1-7
                (8, 14),   # Week 2: 8-14  
                (15, 21),  # Week 3: 15-21
                (22, 28),  # Week 4: 22-28
                (29, None) # Week 5: 29-end of month
            ]
            
            for start_day, end_day in week_boundaries:
                # Skip if start day is beyond month end
                if start_day > month_end.day:
                    break
                
                # Calculate actual end day
                if end_day is None:
                    # Last week: 29 to end of month
                    actual_end_day = month_end.day
                else:
                    actual_end_day = min(end_day, month_end.day)
                
                # Skip if start day > actual end day (for short months)
                if start_day > actual_end_day:
                    continue
                
                # Create segment start (first day of week at 00:00:00)
                seg_start = pd.Timestamp(
                    year=year, month=month, day=start_day,
                    hour=0, minute=0, second=0, microsecond=0,
                    tz="UTC"
                )
                
                # Create segment end (last day of week at 23:59:59.999999)
                seg_end = pd.Timestamp(
                    year=year, month=month, day=actual_end_day,
                    hour=23, minute=59, second=59, microsecond=999999,
                    tz="UTC"
                )
                
                # Ensure segment end doesn't exceed month_end
                if seg_end > month_end:
                    seg_end = month_end
                
                # Label is the LAST DATE of the week, normalized to midnight
                # This gives us just the date part (YYYY-MM-DD)
                label_date = pd.Timestamp(
                    year=year, month=month, day=actual_end_day,
                    tz="UTC"
                ).normalize()
                
                segments.append((seg_start, seg_end, label_date))
            
            return segments

        def _month_week_segments_range(start_month_ts, end_ts, include_today_partial=True):
            """Generates weekly segments across a range of months."""
            segments = []
            
            # Start from the 1st day of the starting month
            current_month = pd.Timestamp(
                year=start_month_ts.year,
                month=start_month_ts.month,
                day=1,
                hour=0, minute=0, second=0, microsecond=0,
                tz="UTC"
            )
            
            # End at the last day of the ending month
            end_month = pd.Timestamp(
                year=end_ts.year,
                month=end_ts.month,
                day=1,
                hour=0, minute=0, second=0, microsecond=0,
                tz="UTC"
            )
            
            while current_month <= end_month:
                # Get the end of this month
                month_end = _eom(current_month)
                if month_end > end_ts:
                    month_end = end_ts
                
                # Generate WEEKLY segments for this month (1-7, 8-14, 15-21, 22-28, 29-EOM)
                month_segments = _generate_month_week_segments(current_month, month_end)
                segments.extend(month_segments)
                
                # Move to next month
                next_month = current_month + pd.DateOffset(months=1)
                current_month = next_month
            
            return segments

        def _year_segments_last_n_years(n_years, end_ts):
            """Generates yearly segments for the last n years including the current year."""
            segments = []
            start_year = end_ts.year - n_years + 1
            
            for year in range(start_year, end_ts.year):
                year_start = pd.Timestamp(year=year, month=1, day=1, tz="UTC")
                year_end = pd.Timestamp(year=year, month=12, day=31, hour=23, minute=59, second=59, tz="UTC")
                # Label is just the year (normalized to Jan 1 of that year)
                label_ts = pd.Timestamp(year=year, month=1, day=1, tz="UTC").normalize()
                segments.append((year_start, year_end, label_ts))
            
            # Current year (partial)
            current_year_start = pd.Timestamp(year=end_ts.year, month=1, day=1, tz="UTC")
            # Label is just the year (normalized to Jan 1 of that year)
            label_ts = pd.Timestamp(year=end_ts.year, month=1, day=1, tz="UTC").normalize()
            segments.append((current_year_start, end_ts, label_ts))
            
            return segments

        def _segments_1_day(now_ts):
            """Splits a single day into 4-hour segments for the entire day."""
            start_of_day = _normalize_date(now_ts)
            end_of_day = start_of_day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            # Create 4-hour intervals
            anchors = list(pd.date_range(
                start=start_of_day, 
                periods=7,  # 7 points for 6 intervals
                freq="4h", 
                tz="UTC"
            ))
            
            # Ensure last anchor is end of day
            anchors[-1] = end_of_day
            
            # Create segments - label is the END timestamp (with time)
            segments = []
            for i in range(len(anchors) - 1):
                seg_start = anchors[i]
                seg_end = anchors[i + 1]
                # Label is the END timestamp (with hours/minutes/seconds)
                segments.append((seg_start, seg_end, seg_end))
            
            return segments

        def _segments_5_day(now_ts):
            """Splits the last 5 days into daily segments."""
            today = _normalize_date(now_ts)
            start_day = today - pd.Timedelta(days=4)
            days = list(pd.date_range(start=start_day, end=today, freq="D", tz="UTC"))
            
            segments = []
            for i, day in enumerate(days):
                seg_start = day
                if i == len(days) - 1:  # Today
                    seg_end = now_ts
                    # Label is just the date (normalized)
                    label_ts = now_ts.normalize()
                else:
                    seg_end = day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    # Label is just the date (normalized)
                    label_ts = seg_end.normalize()
                
                segments.append((seg_start, seg_end, label_ts))
            
            return segments

        def _segments_1_day_for_date(target_date):
            """Splits a specific date (not necessarily today) into 4-hour segments."""
            start_of_day = _normalize_date(target_date)
            end_of_day = start_of_day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            # Create 4-hour intervals
            anchors = list(pd.date_range(
                start=start_of_day, 
                periods=7,  # 7 points for 6 intervals
                freq="4h", 
                tz="UTC"
            ))
            
            # Ensure last anchor is end of day
            anchors[-1] = end_of_day
            
            # Create segments - label is the END timestamp (with time)
            segments = []
            for i in range(len(anchors) - 1):
                seg_start = anchors[i]
                seg_end = anchors[i + 1]
                # Label is the END timestamp (with hours/minutes/seconds)
                segments.append((seg_start, seg_end, seg_end))
            
            return segments

        def _segments_5_day_for_range(start_date_obj, end_date_obj):
            """Splits a specific 5-day range into daily segments."""
            # Convert to UTC timestamps
            start_ts = pd.Timestamp(start_date_obj).tz_localize("UTC").normalize()
            end_ts = pd.Timestamp(end_date_obj).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            # Create daily segments
            days = list(pd.date_range(start=start_ts, end=end_ts, freq="D", tz="UTC"))
            
            segments = []
            for i, day in enumerate(days):
                seg_start = day
                if i == len(days) - 1:  # Last day
                    seg_end = end_ts
                    # Label is just the date (normalized)
                    label_ts = end_ts.normalize()
                else:
                    seg_end = day + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    # Label is just the date (normalized)
                    label_ts = seg_end.normalize()
                
                segments.append((seg_start, seg_end, label_ts))
            
            return segments

        def _aggregate_non_cumulative(df, segments, time_with_hours, year_only=False):
            """
            Aggregates `df` for the provided `segments` list.
            Returns list of dicts with tenant_id, service_provider_id, service_provider_display_name,
            profit_margin, and time.
            """
            if df.empty:
                return []
            
            records_by_key = defaultdict(list)
            
            for seg_start, seg_end, label_ts in segments:
                # Filter records for this segment
                mask = (df["modified_date"] >= seg_start) & (df["modified_date"] <= seg_end)
                sub_df = df.loc[mask]
                
                if sub_df.empty:
                    continue
                
                # Group and aggregate - average profit margin per provider
                grouped = (
                    sub_df.groupby(["tenant_id", "service_provider_id", "service_provider_display_name"], as_index=False)
                    .agg({"profit_margin": "mean", "modified_date": "max"})
                    .rename(columns={"modified_date": "rep_modified_date"})
                )
                
                for _, row in grouped.iterrows():
                    # Determine time label based on format requirements:
                    # - 1_day bucket: "2026-01-13T00:00:00Z" (ISO with time)
                    # - 5_day, 1_month, 3_month, 6_month, 1_year: "2026-01-07" (date only)
                    # - 5_year, max: "2026" (year only)
                    
                    if year_only:
                        # For 5_year and max buckets
                        t_str = _fmt_year_only(label_ts)
                    else:
                        if time_with_hours:
                            # For 1_day bucket (4-hour segments)
                            t_str = _fmt_date_with_time(label_ts)
                        else:
                            # For 5_day, 1_month, 3_month, 6_month, 1_year buckets
                            t_str = _fmt_date_only(label_ts)
                    
                    tid = int(row["tenant_id"])
                    pid = int(row["service_provider_id"])
                    pname = row["service_provider_display_name"] if pd.notnull(row["service_provider_display_name"]) and row["service_provider_display_name"] != "" else "Unknown provider"
                    val = float(row["profit_margin"]) if pd.notnull(row["profit_margin"]) and np.isfinite(row["profit_margin"]) else 0.0
                    
                    records_by_key[(tid, pid, pname)].append([t_str, val])
            
            # Convert to final rows
            rows = []
            for (tid, pid, pname), recs in records_by_key.items():
                # Sort records by time
                recs.sort(key=lambda x: x[0])
                
                rows.append({
                    "tenant_id": tid,
                    "service_provider_id": pid,
                    "service_provider_display_name": pname,
                    "profit_margin": round(np.mean([rv for _, rv in recs]), 2) if recs else 0.0,
                    "time": recs[-1][0] if recs else "",  # Use last time as representative
                    "records": recs,
                })
            
            return rows

        def _select_appropriate_bucket(start_date_obj, end_date_obj):
            """Selects the most appropriate bucket based on date range."""
            if not start_date_obj or not end_date_obj:
                return "1_month"
            
            # Calculate difference in days
            delta = (end_date_obj - start_date_obj).days
            
            if delta <= 1:
                return "1_day"
            elif delta <= 5:
                return "5_day"
            elif delta <= 7:
                return "5_day"
            elif delta <= 31:
                return "1_month"
            elif delta <= 93:
                return "3_month"
            elif delta <= 186:
                return "6_month"
            elif delta <= 366:
                return "1_year"
            elif delta <= 1826:  # 5 years
                return "5_years"
            else:
                return "max"

        # Redis caching setup
        function = "get_profit_margin_trend"
        cache_key = get_cache_key(tenant_database, function)
        cached_raw_data = None

        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_raw_data = json.loads(cached_response)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Cache fetch failed: {cache_exc}")

        # If refresh or no cache — fetch fresh data and cache
        if refresh or cached_raw_data is None:
            logging.info("Fetching fresh profit margin data from DB")

            # === Revenue Query ===
            revenue_query = """
                SELECT
                    ROUND(
					    SUM(
					        COALESCE(cc.charge_amount, 0)
					      + COALESCE(cc.usage_mb, 0)
					      + COALESCE(cc.sms_cost, 0)
					    )::numeric,
					    2
					)  AS revenue,
                    cs.tenant_id,
                    cs.service_provider_id,
                    cs.service_provider_name AS service_provider_display_name,
                    cc.created_date AS modified_date,
                    SPLIT_PART(bill_range,' - ',1)::DATE AS bill_start_date,
                    SPLIT_PART(bill_range,' - ',2)::DATE AS bill_end_date
                FROM customer_charges cc
                JOIN customer_services cs ON cs.id = cc.customer_service_id
                WHERE cc.is_active = false
                  AND cc.is_billed = true
                  AND cc.category = 'MRC'
                  AND cs.service_provider_id IS NOT NULL
                GROUP BY
                    cs.tenant_id,
                    cs.service_provider_id,
                    cs.service_provider_name,
                    cc.created_date,
                    cc.bill_range
            """

            # === Cost Query ===
            cost_query = """
                SELECT tenant_id,
                    service_provider_id,
                    total_cost,
                    bill_start_date,
                    bill_end_date
                FROM (
                SELECT DISTINCT ON (tenant_id, service_provider_id, billing_period_end_date::date)
                        tenant_id,
                        service_provider_id,
                        total_charges    AS total_cost,
                        billing_period_start_date::date AS bill_start_date,
                        billing_period_end_date::date       AS bill_end_date,
                        modified_date
                FROM vw_carrier_optimization
                WHERE optimization_type = 'Carrier'
                    AND total_charges > 0
                ORDER BY tenant_id,
                        service_provider_id,
                        billing_period_end_date::date,
                        modified_date DESC
                ) t
            """

            df_rev = killbill_database.execute_query(revenue_query, True)
            df_cost = database.execute_query(cost_query, True)

            # Process and merge data
            profit_rows = []
            if isinstance(df_rev, pd.DataFrame) and not df_rev.empty and isinstance(df_cost, pd.DataFrame) and not df_cost.empty:
                # Process dataframes
                df_rev['bill_start_date'] = pd.to_datetime(df_rev['bill_start_date'], errors='coerce', utc=True)
                df_rev['bill_end_date'] = pd.to_datetime(df_rev['bill_end_date'], errors='coerce', utc=True)
                df_cost['bill_start_date'] = pd.to_datetime(df_cost['bill_start_date'], errors='coerce')
                df_cost['bill_end_date'] = pd.to_datetime(df_cost['bill_end_date'], errors='coerce')
                df_rev['modified_date'] = pd.to_datetime(df_rev['modified_date'], errors='coerce')

                # Make tz-aware
                for col in ['bill_start_date', 'bill_end_date']:
                    if df_cost[col].dt.tz is None:
                        df_cost[col] = df_cost[col].dt.tz_localize('UTC')

                for col in ['bill_start_date', 'bill_end_date', 'modified_date']:
                    if df_rev[col].dt.tz is None:
                        df_rev[col] = df_rev[col].dt.tz_localize('UTC')

                # Find common combinations
                df_cost_keys = df_cost[['tenant_id', 'service_provider_id']].drop_duplicates()
                df_rev_keys = df_rev[['tenant_id', 'service_provider_id']].drop_duplicates()
                common_keys = pd.merge(df_cost_keys, df_rev_keys, on=['tenant_id', 'service_provider_id'], how='inner')

                for _, cost_row in df_cost.iterrows():
                    tenant_id_val = int(cost_row['tenant_id']) if pd.notnull(cost_row['tenant_id']) else -1
                    provider_id_val = int(cost_row['service_provider_id']) if pd.notnull(cost_row['service_provider_id']) else -1
                    start_date_s = cost_row['bill_start_date']
                    end_date_e = cost_row['bill_end_date']
                    total_cost = float(cost_row['total_cost'] or 0)

                    if pd.isnull(start_date_s) or pd.isnull(end_date_e):
                        continue

                    combination_exists = (
                        (common_keys['tenant_id'] == tenant_id_val) & 
                        (common_keys['service_provider_id'] == provider_id_val)
                    ).any()
                    
                    if not combination_exists:
                        continue

                    # Find matching revenue
                    subset = df_rev[
                        (df_rev['tenant_id'] == tenant_id_val) &
                        (df_rev['service_provider_id'] == provider_id_val) &
                        (
                            ((df_rev['bill_start_date'] >= start_date_s) & (df_rev['bill_start_date'] <= end_date_e)) |
                            ((df_rev['bill_end_date'] >= start_date_s) & (df_rev['bill_end_date'] <= end_date_e)) |
                            ((df_rev['bill_start_date'] <= start_date_s) & (df_rev['bill_end_date'] >= end_date_e))
                        )
                    ]
                    
                    total_revenue = subset['revenue'].sum() if not subset.empty else 0.0
                    max_modified_date = subset['modified_date'].max() if not subset.empty else None
                    
                    if total_revenue == 0 and subset.empty:
                        continue
                    
                    # Calculate profit margin
                    profit_margin = ((total_revenue - total_cost) / total_revenue * 100) if total_revenue > 0 else 0.0
                    
                    # # Cap extremely negative values
                    # if profit_margin < -1000:
                    #     profit_margin = -100.0
                    
                    provider_name = subset['service_provider_display_name'].iloc[0] if not subset.empty else "Unknown Provider"
                    
                    profit_rows.append({
                        "tenant_id": tenant_id_val,
                        "service_provider_id": provider_id_val,
                        "service_provider_display_name": provider_name,
                        "bill_start_date": start_date_s,
                        "bill_end_date": end_date_e,
                        "revenue": round(total_revenue, 2),
                        "cost": round(total_cost, 2),
                        "profit_margin": round(profit_margin, 2),
                        "modified_date": max_modified_date
                    })
            
            # Create DataFrame
            df = pd.DataFrame(profit_rows)
            if not df.empty and 'modified_date' in df.columns:
                df['modified_date'] = pd.to_datetime(df['modified_date'], errors='coerce')
                if df['modified_date'].dt.tz is None:
                    df['modified_date'] = df['modified_date'].dt.tz_localize('UTC')
            
            # Collect metadata
            meta_tenants = {}
            meta_providers = {}
            
            if not df.empty:
                tenant_ids = df['tenant_id'].unique()
                for tid in tenant_ids:
                    tid = int(tid)
                    if tid != -1:
                        meta_tenants[tid] = ""
                
                for _, row in df.iterrows():
                    pid = int(row["service_provider_id"])
                    pname = row['service_provider_display_name']
                    meta_providers[pid] = pname
            
            # Fetch tenant names
            if meta_tenants:
                try:
                    ids = [int(k) for k in meta_tenants.keys()]
                    if ids:
                        query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                        df_tenant = common_utils_database.execute_query(query, params=ids)
                        if isinstance(df_tenant, pd.DataFrame):
                            for row in df_tenant.to_dict(orient="records"):
                                meta_tenants[row["tenant_id"]] = row["tenant_name"]
                except Exception as tenant_exc:
                    logging.warning(f"Failed to fetch tenant names: {tenant_exc}")
            
            # Cache raw data
            cache_payload = {
                "raw_trend_df": df.to_dict('records') if not df.empty else [],
                "meta": {
                    "tenants": meta_tenants,
                    "providers": meta_providers
                }
            }
            
            try:
                redis_client.setex(cache_key, 9000, json.dumps(cache_payload, default=str))
                logging.info(f"Cache set for key: {cache_key}")
                
                # Audit logging
                audit_data = {
                    "function_name": function,
                    "created_date": request_received_at,
                    "created_by": username,
                    "last_synced_by": username,
                }
                common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")
            
            cached_raw_data = cache_payload

        # -------- Extract data from cache --------
        raw_trend_records = cached_raw_data.get("raw_trend_df", [])
        meta_info = cached_raw_data.get("meta", {
            "tenants": {},
            "providers": {}
        })
        
        # Convert raw data to DataFrame
        if raw_trend_records:
            trend_df = pd.DataFrame(raw_trend_records)
            if 'modified_date' in trend_df.columns:
                trend_df['modified_date'] = pd.to_datetime(trend_df['modified_date'], errors='coerce')
                if trend_df['modified_date'].dt.tz is None:
                    trend_df['modified_date'] = trend_df['modified_date'].dt.tz_localize('UTC')
            if 'bill_start_date' in trend_df.columns:
                trend_df['bill_start_date'] = pd.to_datetime(trend_df['bill_start_date'], errors='coerce', utc=True)
            if 'bill_end_date' in trend_df.columns:
                trend_df['bill_end_date'] = pd.to_datetime(trend_df['bill_end_date'], errors='coerce', utc=True)
        else:
            trend_df = pd.DataFrame(columns=["tenant_id", "service_provider_id", "service_provider_display_name", "modified_date", "profit_margin", "bill_start_date", "bill_end_date"])
        
        # -------- APPLY FILTERS FIRST (BEFORE BUCKETING) --------
        
        filtered_trend_df = trend_df.copy()
        has_billing_cycle_filter = False
        has_date_range_filter = False
        selected_bucket = None
        
        # 1. Apply tenant filter
        if tenant_id and tenant_id != "All":
            try:
                tid_int = int(tenant_id)
                filtered_trend_df = filtered_trend_df[filtered_trend_df["tenant_id"] == tid_int]
            except Exception as tenant_filter_exc:
                logging.warning(f"Invalid tenant_id filter: {tenant_filter_exc}")

        # 2. Apply service provider filter
        if service_provider and service_provider != "":
            # Find provider ID from name
            provider_ids = []
            for pid, pname in meta_info.get("providers", {}).items():
                if pname == service_provider:
                    provider_ids.append(int(pid))
            
            if provider_ids:
                filtered_trend_df = filtered_trend_df[filtered_trend_df["service_provider_id"].isin(provider_ids)]

        # 3. Apply billing cycle filter
        if billing_cycle_end_date and billing_cycle_end_date != "":
            try:
                billing_end = pd.to_datetime(billing_cycle_end_date, utc=True)
                billing_start = billing_end - pd.DateOffset(months=1)
                
                # Filter trend_df by billing cycle date range
                filtered_trend_df = filtered_trend_df[
                    (filtered_trend_df["bill_start_date"] >= billing_start) & 
                    (filtered_trend_df["bill_end_date"] <= billing_end)
                ]
                
                has_billing_cycle_filter = True
                selected_bucket = "1_month"
                meta_info["default_time_range"] = "1_month"
                
            except Exception as billing_exc:
                logging.error(f"Error applying billing cycle filter: {billing_exc}")

        # 4. Apply date range filter (start_date/end_date)
        if start_date and end_date:
            try:
                # Convert to timezone-aware datetime objects covering full days
                start_dt = pd.Timestamp(start_date).tz_localize("UTC").normalize()  # Start of day
                end_dt = pd.Timestamp(end_date).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)  # End of day
                
                # Filter trend_df by date range
                filtered_trend_df = filtered_trend_df[
                    (filtered_trend_df["modified_date"] >= start_dt) & 
                    (filtered_trend_df["modified_date"] <= end_dt)
                ]
                
                # Determine which bucket to use based on date range
                date_diff = (end_dt - start_dt).days + 1
                
                if date_diff == 1:
                    selected_bucket = "1_day"
                elif date_diff <= 5:
                    selected_bucket = "5_day"
                elif date_diff <= 7:
                    selected_bucket = "5_day"
                elif date_diff <= 31:
                    selected_bucket = "1_month"
                elif date_diff <= 93:
                    selected_bucket = "3_month"
                elif date_diff <= 186:
                    selected_bucket = "6_month"
                elif date_diff <= 366:
                    selected_bucket = "1_year"
                elif date_diff <= 1826:
                    selected_bucket = "5_years"
                else:
                    selected_bucket = "max"
                
                has_date_range_filter = True
                meta_info["default_time_range"] = selected_bucket
                
            except Exception as date_filter_exc:
                logging.error(f"Error applying date filter: {date_filter_exc}")

        # -------- NOW DO BUCKETING --------
        
        now = _now_ts()
        now_tenant = _now_ts_tenant()
        
        # Initialize grouped_data with empty arrays for all possible buckets
        all_bucket_names = ["1_day", "5_day", "1_month", "3_month", "6_month", "1_year", "5_years", "max", "custom_range"]
        grouped_data = {bucket: [] for bucket in all_bucket_names}

        # Check if we have date range filters
        if has_date_range_filter:
            # When date range filter is applied, only populate the selected bucket
            meta_info["default_time_range"] = selected_bucket
            
            # Convert date objects to timestamps for segment generation
            start_dt = pd.Timestamp(start_date).tz_localize("UTC").normalize()
            end_dt = pd.Timestamp(end_date).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            if selected_bucket == "1_day":
                # For 1-day range, generate 4-hour segments for that specific day
                segments = _segments_1_day_for_date(start_dt)
                time_with_hours_flag = True
                year_only = False
                
            elif selected_bucket == "5_day":
                # For 5-day range, generate daily segments for that specific range
                segments = _segments_5_day_for_range(start_dt.date(), end_dt.date())
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "1_month":
                # For 1-month range, generate weekly segments for that specific range
                segments = _month_week_segments_range(start_dt, end_dt, True)
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "3_month":
                # For 3-month range, generate weekly segments for that specific range
                segments = _month_week_segments_range(start_dt, end_dt, True)
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "6_month":
                # For 6-month range, generate weekly segments for that specific range
                segments = _month_week_segments_range(start_dt, end_dt, True)
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "1_year":
                # For 1-year range, generate weekly segments for that specific range
                segments = _month_week_segments_range(start_dt, end_dt, True)
                time_with_hours_flag = False
                year_only = False
                
            elif selected_bucket == "5_years":
                # For multi-year range, generate yearly segments
                years_diff = (end_dt.year - start_dt.year) + 1
                segments = _year_segments_last_n_years(years_diff, end_dt)
                time_with_hours_flag = False
                year_only = True
                
            elif selected_bucket == "max":
                # For max range, generate yearly segments for the entire range
                years_diff = (end_dt.year - start_dt.year) + 1
                segments = _year_segments_last_n_years(years_diff, end_dt)
                time_with_hours_flag = False
                year_only = True
                
            else:
                segments = []
                time_with_hours_flag = False
                year_only = False
            
            if segments:
                rows = _aggregate_non_cumulative(
                    filtered_trend_df,
                    segments,
                    time_with_hours_flag,
                    year_only
                )
                grouped_data[selected_bucket] = rows

        elif has_billing_cycle_filter:
            # When billing cycle filter is applied, populate ALL buckets
            meta_info["default_time_range"] = "1_month"
            
            # Calculate proper date ranges for each bucket (using current date)
            month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            year_start = (now - pd.DateOffset(years=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            
            # Generate segments for ALL buckets
            segments_by_label = {
                "1_day": _segments_1_day(now_tenant),
                "5_day": _segments_5_day(now),
                "1_month": _month_week_segments_range(month_start, now, True),
                "3_month": _month_week_segments_range(three_months_start, now, True),
                "6_month": _month_week_segments_range(six_months_start, now, True),
                "1_year": _month_week_segments_range(year_start, now, True),
                "5_years": _year_segments_last_n_years(5, now),
                "max": [],
                "custom_range": [],
            }

            # Generate max segments based on filtered data range
            if not filtered_trend_df.empty:
                min_date = filtered_trend_df["modified_date"].min()
                max_date = filtered_trend_df["modified_date"].max()
                if pd.notnull(min_date) and pd.notnull(max_date):
                    years_diff = max_date.year - min_date.year + 1
                    segments_by_label["max"] = _year_segments_last_n_years(years_diff, max_date)

            for label, segments in segments_by_label.items():
                if not segments:
                    grouped_data[label] = []
                    continue

                # Set time_with_hours_flag and year_only based on bucket
                time_with_hours_flag = (label == "1_day")
                year_only_flag = (label in ["5_years", "max"])
                
                rows = _aggregate_non_cumulative(
                    filtered_trend_df,
                    segments,
                    time_with_hours_flag,
                    year_only_flag
                )
                grouped_data[label] = rows

        else:
            # NO FILTER: Populate ALL buckets with unfiltered data
            # Calculate proper date ranges for each bucket (using current date)
            month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            year_start = (now - pd.DateOffset(years=1)).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            
            # Generate segments for ALL buckets
            segments_by_label = {
                "1_day": _segments_1_day(now_tenant),
                "5_day": _segments_5_day(now),
                "1_month": _month_week_segments_range(month_start, now, True),
                "3_month": _month_week_segments_range(three_months_start, now, True),
                "6_month": _month_week_segments_range(six_months_start, now, True),
                "1_year": _month_week_segments_range(year_start, now, True),
                "5_years": _year_segments_last_n_years(5, now),
                "max": [],
                "custom_range": [],
            }

            # Generate max segments based on filtered data range
            if not filtered_trend_df.empty:
                min_date = filtered_trend_df["modified_date"].min()
                max_date = filtered_trend_df["modified_date"].max()
                if pd.notnull(min_date) and pd.notnull(max_date):
                    years_diff = max_date.year - min_date.year + 1
                    segments_by_label["max"] = _year_segments_last_n_years(years_diff, max_date)

            for label, segments in segments_by_label.items():
                if not segments:
                    grouped_data[label] = []
                    continue

                # Set time_with_hours_flag and year_only based on bucket
                time_with_hours_flag = (label == "1_day")
                year_only_flag = (label in ["5_years", "max"])
                
                rows = _aggregate_non_cumulative(
                    filtered_trend_df,
                    segments,
                    time_with_hours_flag,
                    year_only_flag
                )
                grouped_data[label] = rows

        # Format output for frontend
        meta_tenants = {}
        meta_providers = {}
        
        # Collect metadata from all buckets
        for bucket_name, bucket_data in grouped_data.items():
            for rec in bucket_data:
                tenant_id_val = rec.get("tenant_id")
                if tenant_id_val is not None:
                    meta_tenants[str(tenant_id_val)] = ""
                
                sp_id = rec.get("service_provider_id")
                sp_name = rec.get("service_provider_display_name", "")
                if sp_id is not None:
                    meta_providers[str(sp_id)] = sp_name
        
        # Initialize all buckets with actual data
        all_buckets = {
            "1_day": [],
            "5_day": [],
            "1_month": [],
            "3_month": [],
            "6_month": [],
            "1_year": [],
            "5_years": [],
            "max": [],
            "custom_range": []
        }
        
        # Fill each bucket with its actual data from grouped_data
        for bucket_name in all_buckets.keys():
            bucket_data = grouped_data.get(bucket_name, [])
            
            # Group data by tenant AND provider
            tenant_provider_data = defaultdict(list)
            for record in bucket_data:
                tenant_id_val = record.get("tenant_id", -1)
                provider_id_val = record.get("service_provider_id", -1)
                provider_name = record.get("service_provider_display_name", "")
                
                # Create a unique key for tenant+provider combination
                key = f"{tenant_id_val}_{provider_id_val}"
                
                tenant_provider_data[key].append({
                    "time": record.get("time", ""),
                    "profit_margin": record.get("profit_margin", 0),
                    "tenant_id": tenant_id_val,
                    "service_provider_id": provider_id_val,
                    "service_provider_display_name": provider_name
                })
            
            # Format data for this bucket
            formatted = []
            for key, records in tenant_provider_data.items():
                # Sort records by time
                records.sort(key=lambda x: x["time"])
                
                for record in records:
                    formatted.append({
                        "tenant_id": record["tenant_id"],
                        "service_provider_id": record["service_provider_id"],
                        "service_provider_display_name": record["service_provider_display_name"],
                        "profit_margin": record["profit_margin"],
                        "time": record["time"]
                    })
            
            all_buckets[bucket_name] = formatted

        # Resolve tenant names
        if meta_tenants:
            try:
                ids = [int(k) for k in meta_tenants.keys()]
                if ids:
                    query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                    df_tenant = common_utils_database.execute_query(query, params=ids)
                    if isinstance(df_tenant, pd.DataFrame):
                        for row in df_tenant.to_dict(orient="records"):
                            meta_tenants[str(row["tenant_id"])] = row["tenant_name"]
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        # Prepare final response
        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": meta_info.get("default_time_range", "1_month"),
            },
            "data": {
                "title": "Profit Margin Trend",
                "chart_type": "line",
                "xField": ["Jan", "Feb", "Mar"],
                "yField": "profit_margin",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": all_buckets,
            },
        }
        return response

    except Exception as exception:
        logging.exception(f"[get_profit_margin_trend] Exception: {exception}")
        response["message"] = f"Error retrieving profit margin trend: {exception}"
        try:
            error_data = {
                "service_name": "get_profit_margin_trend",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"[get_profit_margin_trend] Error logging to DB: {e}")

    return response



def get_revenue_by_usage_trend(data):
    """
    Returns a bar chart showing total revenue for each usage_type across service providers.
    Caches full unfiltered DB result in Redis and applies filters only on cached data.
    
    **Optimization (2026-01-15):**
    - Apply filters BEFORE bucketing to reduce processing time
    - Filter trend_df before generating segments and aggregating
    - When date range filters applied: populate only the selected bucket based on date range
    - When no date range filters: populate all buckets

    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return revenue based on usage type.
            - 'message' (str): Error message if applicable.
    """

    tenant_id = data.get("tenant_id", "")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = parse(data.get("request_received_at")).date() if data.get("request_received_at") else datetime.utcnow().date()
    tenant_name = data.get("tenant_name", "")
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date() if data.get("start_date") else None
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date() if data.get("end_date") else None
    refresh = str(data.get("refresh", "False")).lower() == "true"
    service_provider = data.get("service_provider", "")
    billing_cycle_end_period = data.get("billing_cycle_end_period", None)

    response = {
        "flag": False,
        "meta": {
            "tenants": {},
            "providers": {},
            "plans": {},
            "default_time_range": "custom_range"
        },
        "data": {
            "title": "Revenue by Usage Type",
            "chart_type": "bar",
            "xField": ["Usage", "Sms"],
            "yField": "",
            "data": {},
            "smooth": True,
            "height": 300,
            "width": 500,
        },
        "message": "",
    }

    try:
        mode = os.environ.get('ENV','')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        
        # Fetch tenant timezone
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"

        function = "get_revenue_by_usage_trend"
        cache_key = get_cache_key(tenant_database, function)
        cached_raw_data = None

        if not refresh:
            try:
                cached_response = redis_client.get(cache_key)
                if cached_response:
                    cached_raw_data = json.loads(cached_response)
                    logging.info(f"Cache hit for key: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Cache retrieval failed: {cache_exc}")

        # ---------- OPTIMIZED HELPER FUNCTIONS ----------
        def eom(ts: pd.Timestamp) -> pd.Timestamp:
            """Returns the end-of-month timestamp for the given date."""
            ts0 = pd.to_datetime(ts)
            if getattr(ts0, "tzinfo", None) is None:
                ts0 = ts0.tz_localize("UTC")
            else:
                ts0 = ts0.tz_convert("UTC")
            return (ts0 + pd.offsets.MonthEnd(0)).normalize().tz_convert("UTC")

        def month_slots_for_month(first_of_month: pd.Timestamp, end_cap: pd.Timestamp):
            """Return list of (slot_start_ts, slot_end_ts) for the given month."""
            f = pd.to_datetime(first_of_month)
            if getattr(f, "tzinfo", None) is None:
                f = f.tz_localize("UTC")
            else:
                f = f.tz_convert("UTC")
            f = f.normalize()

            ec = pd.to_datetime(end_cap)
            if getattr(ec, "tzinfo", None) is None:
                ec = ec.tz_localize("UTC")
            else:
                ec = ec.tz_convert("UTC")
            ec = ec.normalize()

            d7 = pd.Timestamp(year=f.year, month=f.month, day=7, tz="UTC").normalize()
            d14 = pd.Timestamp(year=f.year, month=f.month, day=14, tz="UTC").normalize()
            d21 = pd.Timestamp(year=f.year, month=f.month, day=21, tz="UTC").normalize()
            d28 = pd.Timestamp(year=f.year, month=f.month, day=28, tz="UTC").normalize()
            dend = eom(f)

            s1_end = min(d7, ec)
            s2_end = min(d14, ec)
            s3_end = min(d21, ec)
            s4_end = min(d28, ec)
            s5_end = min(dend, ec)

            s1_start = f
            s2_start = pd.Timestamp(year=f.year, month=f.month, day=8, tz="UTC").normalize()
            s3_start = pd.Timestamp(year=f.year, month=f.month, day=15, tz="UTC").normalize()
            s4_start = pd.Timestamp(year=f.year, month=f.month, day=22, tz="UTC").normalize()
            s5_start = pd.Timestamp(year=f.year, month=f.month, day=29, tz="UTC").normalize()

            slots = []
            if s1_start <= s1_end:
                slots.append((s1_start, s1_end))
            if s2_start <= s2_end:
                slots.append((s2_start, s2_end))
            if s3_start <= s3_end:
                slots.append((s3_start, s3_end))
            if s4_start <= s4_end:
                slots.append((s4_start, s4_end))
            if s5_start <= s5_end:
                slots.append((s5_start, s5_end))
            
            return slots

        def month_slots_range(start_month_first: pd.Timestamp, end_ts: pd.Timestamp):
            """For each month between start_month_first and end_ts, return all slots."""
            results = []
            cursor = pd.Timestamp(year=start_month_first.year, month=start_month_first.month, day=1, tz=getattr(start_month_first, "tzinfo", None) or "UTC")
            cursor = cursor.normalize().tz_convert("UTC")
            last_month_first = pd.Timestamp(year=end_ts.year, month=end_ts.month, day=1, tz=getattr(end_ts, "tzinfo", None) or "UTC").normalize().tz_convert("UTC")
            
            while cursor <= last_month_first:
                month_slots = month_slots_for_month(cursor, end_ts)
                results.extend(month_slots)
                cursor = (cursor + pd.offsets.MonthEnd(0)) + pd.Timedelta(days=1)
                cursor = cursor.normalize().tz_convert("UTC")
            
            return results

        def yearly_points_last_n_years(n_years: int, end_ts: pd.Timestamp):
            """Return Dec-31 for each past year and 'today' for current year."""
            start_year = end_ts.year - n_years + 1
            pts = [pd.Timestamp(year=y, month=12, day=31, tz=getattr(end_ts, "tzinfo", None) or "UTC") for y in range(start_year, end_ts.year)]
            pts.append(end_ts.normalize())
            return sorted(pd.to_datetime(list(dict.fromkeys(pts))))

        def to_datestr(ts: pd.Timestamp, date_only=True, year_only=False) -> str:
            """Formats a timestamp into a date string."""
            if year_only:
                return str(ts.year)
            if date_only:
                return ts.date().isoformat()
            if getattr(ts, "tzinfo", None) is None:
                ts = ts.tz_localize("UTC")
            else:
                ts = ts.tz_convert("UTC")
            return ts.strftime('%Y-%m-%dT%H:%M:%SZ')

        def non_cumulative_grouping_optimized(df, time_points, date_only=True, year_only=False):
            """OPTIMIZED: Aggregates usage for each tenant and service provider using vectorized operations."""
            if time_points is None or df.empty:
                return []

            pts = list(time_points) if not isinstance(time_points, (pd.PeriodIndex, pd.Series)) else list(time_points)
            if len(pts) == 0:
                return []

            # Pre-sort once
            df = df.sort_values('modified_date').reset_index(drop=True)
            
            # Pre-convert all time points to timestamps
            converted_pts = []
            for t in pts:
                if isinstance(t, pd.Period):
                    t_ts = pd.to_datetime(t.start_time).tz_localize("UTC") if pd.notnull(t.start_time) else pd.Timestamp(t.asfreq('D').start_time, tz="UTC")
                else:
                    t_ts = pd.to_datetime(t)
                    if getattr(t_ts, "tzinfo", None) is None:
                        t_ts = t_ts.tz_localize("UTC")
                converted_pts.append(t_ts)
            
            # Use binary search to find indices for each time window
            records = []
            prev_end_idx = 0
            
            for i, t_ts in enumerate(converted_pts):
                # Determine segment boundaries
                if i == 0:
                    segment_start_idx = 0
                else:
                    segment_start_idx = prev_end_idx
                
                # Binary search for end index
                segment_end_idx = df['modified_date'].searchsorted(t_ts, side='right')
                
                if segment_start_idx >= segment_end_idx:
                    continue
                
                # Slice dataframe (much faster than boolean indexing)
                subset = df.iloc[segment_start_idx:segment_end_idx]
                
                # Vectorized groupby
                grouped = subset.groupby(
                    ['tenant_id', 'service_provider_id', 'service_provider_display_name'],
                    as_index=False,
                    observed=True
                ).agg({
                    'usage': 'sum',
                    'sms_usage': 'sum'
                })

                t_str = to_datestr(t_ts, date_only=date_only, year_only=year_only)

                # Convert to records using vectorized operations
                grouped['time'] = t_str
                grouped['tenant_id'] = grouped['tenant_id'].fillna(-1).astype(int)
                grouped['provider_id'] = grouped['service_provider_id'].fillna(-1).astype(int)
                grouped['service_provider'] = grouped['service_provider_display_name'].fillna('Unknown')
                grouped['usage'] = grouped['usage'].fillna(0.0).astype(float)
                grouped['sms_usage'] = grouped['sms_usage'].fillna(0).astype(int)
                
                # Select only needed columns
                result_cols = grouped[['tenant_id', 'provider_id', 'service_provider', 'usage', 'sms_usage', 'time']]
                records.extend(result_cols.to_dict('records'))
                
                prev_end_idx = segment_end_idx

            # Deduplicate using dict comprehension
            deduped = list({(r["tenant_id"], r["provider_id"], r["time"]): r for r in records}.values())
            return deduped

        def slot_grouping_for_slots_optimized(df, slots):
            """OPTIMIZED: Given list of (slot_start_ts, slot_end_ts) tuples produce aggregated records."""
            if not slots or df.empty:
                return []
            
            # Pre-sort once
            df = df.sort_values('modified_date').reset_index(drop=True)
            records = []
            
            for (s, e) in slots:
                s_ts = pd.to_datetime(s)
                e_ts = pd.to_datetime(e)
                if getattr(s_ts, "tzinfo", None) is None:
                    s_ts = s_ts.tz_localize("UTC")
                else:
                    s_ts = s_ts.tz_convert("UTC")
                if getattr(e_ts, "tzinfo", None) is None:
                    e_ts = e_ts.tz_localize("UTC")
                else:
                    e_ts = e_ts.tz_convert("UTC")

                # Use binary search for faster slicing
                start_idx = df['modified_date'].searchsorted(s_ts, side='left')
                end_idx = df['modified_date'].searchsorted(e_ts, side='right')
                
                if start_idx >= end_idx:
                    continue
                
                subset = df.iloc[start_idx:end_idx]

                grouped = subset.groupby(
                    ['tenant_id', 'service_provider_id', 'service_provider_display_name'],
                    as_index=False,
                    observed=True
                ).agg({
                    'usage': 'sum',
                    'sms_usage': 'sum'
                })

                t_str = e_ts.date().isoformat()

                # Vectorized conversion
                grouped['time'] = t_str
                grouped['tenant_id'] = grouped['tenant_id'].fillna(-1).astype(int)
                grouped['provider_id'] = grouped['service_provider_id'].fillna(-1).astype(int)
                grouped['service_provider'] = grouped['service_provider_display_name'].fillna('Unknown')
                grouped['usage'] = grouped['usage'].fillna(0.0).astype(float)
                grouped['sms_usage'] = grouped['sms_usage'].fillna(0).astype(int)
                
                result_cols = grouped[['tenant_id', 'provider_id', 'service_provider', 'usage', 'sms_usage', 'time']]
                records.extend(result_cols.to_dict('records'))
            
            deduped = list({(r["tenant_id"], r["provider_id"], r["time"]): r for r in records}.values())
            return deduped

        # If refresh or no cache — fetch fresh data and cache
        if refresh or cached_raw_data is None:
            logging.info("Fetching fresh SIM count data from DB")

            # OPTIMIZED QUERY: Filter out zero values at database level
            query = """
                SELECT
                    SUM(COALESCE(cc.usage_mb, 0)) as customer_cycle_usage_mb,
                    SUM(COALESCE(cc.sms_cost, 0)) AS ctd_sms_usage,
                    cs.service_provider_id,
                    cs.service_provider_name as service_provider_display_name,
                    cs.tenant_id,
                    cc.created_date as modified_date,
                    cc.bill_range
                FROM customer_charges cc 
                JOIN customer_services cs ON cs.id = cc.customer_service_id 
                WHERE cc.is_active = false
                  AND cc.is_billed = true
                  AND cc.category = 'MRC'
                  AND cs.service_provider_id IS NOT NULL
                GROUP BY cs.service_provider_id,
                    cs.service_provider_name,
                    cs.tenant_id,
                    cc.created_date,
                    cc.bill_range
                HAVING SUM(COALESCE(cc.usage_mb, 0)) > 0 
                    OR SUM(COALESCE(cc.sms_cost, 0)) > 0
            """

            df = killbill_database.execute_query(query, True)

            # Normalize dataframe with optimized operations
            if isinstance(df, pd.DataFrame) and not df.empty:
                # Single pass conversion
                df['modified_date'] = pd.to_datetime(df['modified_date'], errors='coerce', utc=True)
                df["usage"] = pd.to_numeric(df.get("customer_cycle_usage_mb", pd.Series(dtype=float)), errors="coerce").fillna(0.0)
                df["sms_usage"] = pd.to_numeric(df.get("ctd_sms_usage", pd.Series(dtype=float)), errors="coerce").fillna(0)
                df["tenant_id"] = pd.to_numeric(df.get("tenant_id"), errors="coerce").fillna(-1).astype(int)
                df["service_provider_id"] = pd.to_numeric(df.get("service_provider_id"), errors="coerce").fillna(-1).astype(int)
                
                if "service_provider_display_name" not in df.columns:
                    df["service_provider_display_name"] = df.get("service_provider_name", "Unknown")
                
                # Filter out zero rows after conversion (in case HAVING didn't catch all)
                df = df[(df['usage'] > 0) | (df['sms_usage'] > 0)].copy()
            else:
                df = pd.DataFrame(columns=[
                    "service_provider_id", "tenant_id", "service_provider_display_name", 
                    "customer_cycle_usage_mb", "ctd_sms_usage", "modified_date", 
                    "usage", "sms_usage"
                ])
                df["tenant_id"] = df["tenant_id"].astype(int)
                df["service_provider_id"] = df["service_provider_id"].astype(int)
                df["service_provider_display_name"] = df["service_provider_display_name"].astype(str)
                df["usage"] = df["usage"].astype(float)
                df["sms_usage"] = df["sms_usage"].astype(int)
                df['modified_date'] = pd.to_datetime(df['modified_date'], utc=True)
            
            # Collect metadata using vectorized operations
            meta_tenants = {}
            meta_providers = {}
            
            if not df.empty:
                # Get unique tenant IDs
                unique_tenants = df["tenant_id"].unique()
                for tid in unique_tenants:
                    tid = int(tid)
                    if tid != -1:
                        meta_tenants[tid] = ""
                
                # Get unique providers
                provider_info = df[['service_provider_id', 'service_provider_display_name']].drop_duplicates()
                for _, row in provider_info.iterrows():
                    pid = int(row["service_provider_id"])
                    pname = row["service_provider_display_name"]
                    meta_providers[pid] = pname
            
            # Fetch tenant names in batch
            if meta_tenants:
                try:
                    ids = [int(k) for k in meta_tenants.keys()]
                    if ids:
                        query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                        df_tenant = common_utils_database.execute_query(query, params=ids)
                        if isinstance(df_tenant, pd.DataFrame):
                            for row in df_tenant.to_dict(orient="records"):
                                meta_tenants[row["tenant_id"]] = row["tenant_name"]
                except Exception as tenant_exc:
                    logging.warning(f"Failed to fetch tenant names: {tenant_exc}")
            
            # Cache raw data
            cache_payload = {
                "raw_df": df.to_dict('records') if not df.empty else [],
                "meta": {
                    "tenants": meta_tenants,
                    "providers": meta_providers
                }
            }
            
            try:
                redis_client.setex(cache_key, 9000, json.dumps(cache_payload, default=str))
                logging.info(f"Cache set for key: {cache_key}")
                
                # Audit logging
                audit_data = {
                    "function_name": function,
                    "created_date": request_received_at,
                    "created_by": username,
                    "last_synced_by": username,
                }
                common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
            except Exception as redis_exc:
                logging.warning(f"Redis set failed: {redis_exc}")
            
            cached_raw_data = cache_payload

        # -------- Extract data from cache --------
        raw_records = cached_raw_data.get("raw_df", [])
        meta_info = cached_raw_data.get("meta", {
            "tenants": {},
            "providers": {}
        })
        
        # Convert raw data to DataFrame (single conversion)
        if raw_records:
            df = pd.DataFrame(raw_records)
            df['modified_date'] = pd.to_datetime(df['modified_date'], utc=True)
            df["usage"] = pd.to_numeric(df.get("usage", 0), errors="coerce").fillna(0.0)
            df["sms_usage"] = pd.to_numeric(df.get("sms_usage", 0), errors="coerce").fillna(0)
            df["tenant_id"] = pd.to_numeric(df.get("tenant_id", -1), errors="coerce").fillna(-1).astype(int)
            df["service_provider_id"] = pd.to_numeric(df.get("service_provider_id", -1), errors="coerce").fillna(-1).astype(int)
            df["service_provider_display_name"] = df.get("service_provider_display_name", "Unknown").fillna("Unknown")
        else:
            df = pd.DataFrame(columns=["service_provider_id", "tenant_id", "service_provider_display_name", "modified_date", "usage", "sms_usage"])
        
        # -------- APPLY FILTERS FIRST (BEFORE BUCKETING) --------
        filtered_df = df.copy()
        has_date_range_filter = False
        selected_bucket = None
        
        # 1. Apply tenant filter
        if tenant_id and tenant_id != "All" and tenant_id != "":
            try:
                tid_int = int(tenant_id)
                filtered_df = filtered_df[filtered_df["tenant_id"] == tid_int]
            except Exception as tenant_filter_exc:
                logging.warning(f"Invalid tenant_id filter: {tenant_filter_exc}")

        # 2. Apply service provider filter
        if service_provider and service_provider != "":
            sp_norm = service_provider.strip().lower()
            filtered_df = filtered_df[
                filtered_df["service_provider_display_name"].str.strip().str.lower() == sp_norm
            ]

        # 3. Apply billing cycle filter
        if billing_cycle_end_period and billing_cycle_end_period != "":
            try:
                end_dt = pd.to_datetime(str(billing_cycle_end_period), utc=True, errors='coerce')
                if pd.notnull(end_dt):
                    start_dt = end_dt - pd.Timedelta(days=30)
                    
                    filtered_df = filtered_df[
                        (filtered_df['modified_date'] >= start_dt) & 
                        (filtered_df['modified_date'] <= end_dt)
                    ]
                    
                    # When billing cycle filter is applied, we'll use 1_month as default
                    selected_bucket = "1_month"
                    meta_info["default_time_range"] = "1_month"
            except Exception as bc_exc:
                logging.warning(f"Billing cycle filtering failed: {bc_exc}")

        # 4. Apply date range filter (start_date/end_date)
        if start_date and end_date:
            try:
                # Convert to timezone-aware datetime objects covering full days
                start_dt = pd.Timestamp(start_date).tz_localize("UTC").normalize()  # Start of day
                end_dt = pd.Timestamp(end_date).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)  # End of day
                
                # Filter trend_df by date range
                filtered_df = filtered_df[
                    (filtered_df["modified_date"] >= start_dt) & 
                    (filtered_df["modified_date"] <= end_dt)
                ]
                
                # Determine which bucket to use based on date range
                date_diff = (end_dt - start_dt).days + 1
                
                if date_diff == 1:
                    selected_bucket = "1_day"
                elif date_diff <= 5:
                    selected_bucket = "5_day"
                elif date_diff <= 7:
                    selected_bucket = "5_day"
                elif date_diff <= 31:
                    selected_bucket = "1_month"
                elif date_diff <= 93:
                    selected_bucket = "3_month"
                elif date_diff <= 186:
                    selected_bucket = "6_month"
                elif date_diff <= 366:
                    selected_bucket = "1_year"
                elif date_diff <= 1826:
                    selected_bucket = "5_years"
                else:
                    selected_bucket = "max"
                
                has_date_range_filter = True
                meta_info["default_time_range"] = selected_bucket
                
            except Exception as date_filter_exc:
                logging.error(f"Error applying date filter: {date_filter_exc}")

        # -------- NOW DO BUCKETING --------
        now = pd.Timestamp.now(tz="UTC")
        today = now.normalize()
        
        # Get min and max dates from filtered data for proper historical ranges
        if not filtered_df.empty:
            min_date = filtered_df['modified_date'].min()
            max_date = filtered_df['modified_date'].max()
            min_year = int(min_date.year) if pd.notnull(min_date) else int(now.year)
            max_year = int(max_date.year) if pd.notnull(max_date) else int(now.year)
        else:
            min_date = now
            max_date = now
            min_year = int(now.year)
            max_year = int(now.year)
        
        # Initialize grouped_data with empty arrays for all possible buckets
        all_bucket_names = ["1_day", "5_day", "1_month", "3_month", "6_month", "1_year", "5_years", "max", "custom_range"]
        buckets = {bucket: [] for bucket in all_bucket_names}
        
        # Check if we have date range filters
        if has_date_range_filter:
            # When date range filter is applied, only populate the selected bucket
            start_dt = pd.Timestamp(start_date).tz_localize("UTC").normalize()
            end_dt = pd.Timestamp(end_date).tz_localize("UTC").normalize() + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
            
            if selected_bucket == "1_day":
                # For 1-day range, generate 4-hour segments for that specific day
                seg_anchors = []
                for h in [0, 4, 8, 12, 16, 20, 24]:
                    anchor_time = start_dt + pd.Timedelta(hours=h)
                    if anchor_time <= end_dt:
                        seg_anchors.append(anchor_time)
                
                buckets[selected_bucket] = non_cumulative_grouping_optimized(
                    filtered_df, seg_anchors, date_only=False, year_only=False
                )
                
            elif selected_bucket == "5_day":
                # For 5-day range, generate daily segments
                day_points = []
                current = start_dt
                while current <= end_dt:
                    day_end = min(
                                current + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1),
                                end_dt
                            )
                    if day_end > end_dt:
                        day_end = end_dt
                    day_points.append(day_end)
                    current = day_end + pd.Timedelta(microseconds=1)
                
                buckets[selected_bucket] = non_cumulative_grouping_optimized(
                    filtered_df, day_points, date_only=True, year_only=False
                )
                
            elif selected_bucket in ["1_month", "3_month", "6_month", "1_year"]:
                # FIXED: Use DAILY points instead of weekly slots for better granularity
                day_points = []
                current = start_dt
                while current <= end_dt:
                    day_end = current + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    if day_end > end_dt:
                        day_end = end_dt
                    day_points.append(day_end)
                    current = day_end + pd.Timedelta(microseconds=1)
                
                buckets[selected_bucket] = non_cumulative_grouping_optimized(
                    filtered_df, day_points, date_only=True, year_only=False
                )
                
            elif selected_bucket in ["5_years", "max"]:
                # For yearly ranges, generate year points
                if selected_bucket == "5_years":
                    start_year = end_dt.year - 4
                else:
                    start_year = min_year
                
                years_in_range = [y for y in range(start_year, end_dt.year + 1)]
                year_points = [pd.Timestamp(year=y, month=12, day=31, tz="UTC") for y in years_in_range]
                if year_points and year_points[-1] > end_dt:
                    year_points[-1] = end_dt
                
                buckets[selected_bucket] = non_cumulative_grouping_optimized(
                    filtered_df, year_points, date_only=False, year_only=True
                )
                
        else:
            # NO FILTER: Populate ALL buckets with filtered data
            # Pre-calculate date ranges
            five_days_ago = today - pd.Timedelta(days=4)
            month_start = now.replace(day=1)
            three_months_start = (now - pd.DateOffset(months=2)).replace(day=1)
            six_months_start = (now - pd.DateOffset(months=5)).replace(day=1)
            year_start = (now - pd.DateOffset(years=1)).replace(day=1)
            
            # ============================================================
            # 1_day bucket - 4-hour segments
            # ============================================================
            try:
                seg_anchors = []
                for h in [0, 4, 8, 12, 16, 20, 24]:
                    anchor_time = today + pd.Timedelta(hours=h)
                    if anchor_time <= now:
                        seg_anchors.append(anchor_time)
                
                # Always add 'now' as the final anchor if not already at end of day
                if not seg_anchors or seg_anchors[-1] < now:
                    seg_anchors.append(now)
                
                # Filter data for today only
                filtered_1_day = filtered_df[(filtered_df['modified_date'] >= today) & (filtered_df['modified_date'] <= now)].copy()
                
                buckets['1_day'] = non_cumulative_grouping_optimized(filtered_1_day, seg_anchors, date_only=False, year_only=False)
            except Exception as e:
                logging.warning(f"1_day bucket error: {e}")
                buckets['1_day'] = []
            
            # ============================================================
            # 5_day bucket - Daily points
            # ============================================================
            try:
                day_points = []
                current = five_days_ago
                while current <= now:
                    day_end = current + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    if day_end > now:
                        day_end = now
                    day_points.append(day_end)
                    current = day_end + pd.Timedelta(microseconds=1)
                
                start_ts_5day = today - pd.Timedelta(days=4)
                filtered_5day = filtered_df[(filtered_df['modified_date'] >= start_ts_5day) & (filtered_df['modified_date'] <= now)].copy()
                buckets['5_day'] = non_cumulative_grouping_optimized(filtered_5day, day_points, date_only=True)
            except Exception as e:
                logging.warning(f"5_day bucket error: {e}")
                buckets['5_day'] = []
            
            # ============================================================
            # 1_month bucket - FIXED: Daily points instead of weekly slots
            # ============================================================
            try:
                day_points = []
                current = month_start
                while current <= now:
                    day_end = current + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    if day_end > now:
                        day_end = now
                    day_points.append(day_end)
                    current = day_end + pd.Timedelta(microseconds=1)
                
                filtered_1month = filtered_df[(filtered_df['modified_date'] >= month_start) & (filtered_df['modified_date'] <= now)].copy()
                buckets['1_month'] = non_cumulative_grouping_optimized(filtered_1month, day_points, date_only=True)
            except Exception as e:
                logging.warning(f"1_month bucket error: {e}")
                buckets['1_month'] = []
            
            # ============================================================
            # 3_month bucket - FIXED: Daily points instead of weekly slots
            # ============================================================
            try:
                day_points = []
                current = three_months_start
                while current <= now:
                    day_end = current + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    if day_end > now:
                        day_end = now
                    day_points.append(day_end)
                    current = day_end + pd.Timedelta(microseconds=1)
                
                filtered_3month = filtered_df[(filtered_df['modified_date'] >= three_months_start) & (filtered_df['modified_date'] <= now)].copy()
                buckets['3_month'] = non_cumulative_grouping_optimized(filtered_3month, day_points, date_only=True)
            except Exception as e:
                logging.warning(f"3_month bucket error: {e}")
                buckets['3_month'] = []
            
            # ============================================================
            # 6_month bucket - FIXED: Daily points instead of weekly slots
            # ============================================================
            try:
                day_points = []
                current = six_months_start
                while current <= now:
                    day_end = current + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    if day_end > now:
                        day_end = now
                    day_points.append(day_end)
                    current = day_end + pd.Timedelta(microseconds=1)
                
                filtered_6month = filtered_df[(filtered_df['modified_date'] >= six_months_start) & (filtered_df['modified_date'] <= now)].copy()
                buckets['6_month'] = non_cumulative_grouping_optimized(filtered_6month, day_points, date_only=True)
            except Exception as e:
                logging.warning(f"6_month bucket error: {e}")
                buckets['6_month'] = []
            
            # ============================================================
            # 1_year bucket - FIXED: Daily points instead of weekly slots
            # ============================================================
            try:
                day_points = []
                current = year_start
                while current <= now:
                    day_end = current + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
                    if day_end > now:
                        day_end = now
                    day_points.append(day_end)
                    current = day_end + pd.Timedelta(microseconds=1)
                
                filtered_1year = filtered_df[(filtered_df['modified_date'] >= year_start) & (filtered_df['modified_date'] <= now)].copy()
                buckets['1_year'] = non_cumulative_grouping_optimized(filtered_1year, day_points, date_only=True)
            except Exception as e:
                logging.warning(f"1_year bucket error: {e}")
                buckets['1_year'] = []
            
            # ============================================================
            # 5_years bucket - Yearly points (correct behavior)
            # ============================================================
            try:
                start_year = now.year - 4
                years_in_range = [y for y in range(start_year, now.year + 1)]
                year_points = [pd.Timestamp(year=y, month=12, day=31, tz="UTC") for y in years_in_range]
                if year_points and year_points[-1] > now:
                    year_points[-1] = now
                
                start_ts_5years = pd.Timestamp(year=start_year, month=1, day=1, tz="UTC")
                filtered_5years = filtered_df[(filtered_df['modified_date'] >= start_ts_5years) & (filtered_df['modified_date'] <= now)].copy()
                buckets['5_years'] = non_cumulative_grouping_optimized(filtered_5years, year_points, year_only=True)
            except Exception as e:
                logging.warning(f"5_years bucket error: {e}")
                buckets['5_years'] = []
            
            # ============================================================
            # max bucket - Yearly points (correct behavior)
            # ============================================================
            try:
                unique_years_all = sorted(filtered_df['modified_date'].dt.year.drop_duplicates()) if not filtered_df.empty else []
                if unique_years_all:
                    year_points_max = [pd.Timestamp(year=y, month=12, day=31, tz="UTC") for y in unique_years_all]
                    if year_points_max and year_points_max[-1] > now:
                        year_points_max[-1] = now
                else:
                    year_points_max = yearly_points_last_n_years(now.year - min_year + 1, now)
                
                buckets['max'] = non_cumulative_grouping_optimized(filtered_df, year_points_max, year_only=True)
            except Exception as e:
                logging.warning(f"max bucket error: {e}")
                buckets['max'] = []
        
        # Format the data for response - ORIGINAL FORMAT PRESERVED
        meta_tenants = {}
        meta_providers = {}
        formatted_buckets = {}
        
        for bucket_name in all_bucket_names:
            bucket_data = buckets.get(bucket_name, [])
            
            # Group by (tenant_id, provider_id) - optimized with defaultdict
            grouped = defaultdict(list)
            for record in bucket_data:
                key = (record.get("tenant_id", -1), record.get("provider_id", -1))
                grouped[key].append([
                    record.get("time", ""),
                    float(record.get("usage", 0.0)),
                    int(record.get("sms_usage", 0))
                ])
                
                # Collect metadata
                tenant_id_val = record.get("tenant_id", -1)
                provider_id_val = record.get("provider_id", -1)
                provider_name = record.get("service_provider", "Unknown")
                
                if tenant_id_val not in meta_tenants:
                    meta_tenants[tenant_id_val] = ""
                
                if provider_id_val not in meta_providers:
                    meta_providers[provider_id_val] = provider_name
            
            # Format into expected structure
            formatted = []
            for (tenant_id, provider_id), records in grouped.items():
                formatted.append({
                    "tenant_id": tenant_id,
                    "provider_id": provider_id,
                    "records": records
                })
            
            formatted_buckets[bucket_name] = formatted

        # Resolve tenant names for meta_tenants (batch operation)
        if meta_tenants:
            try:
                ids = [int(k) for k in meta_tenants.keys() if k != -1]
                if ids:
                    query = f"SELECT id AS tenant_id, tenant_name FROM tenant WHERE id IN ({','.join(['%s']*len(ids))})"
                    df_tenant = common_utils_database.execute_query(query, params=ids)
                    if isinstance(df_tenant, pd.DataFrame):
                        for row in df_tenant.to_dict(orient="records"):
                            meta_tenants[row["tenant_id"]] = row["tenant_name"]
            except Exception as tenant_exc:
                logging.warning(f"Failed to resolve tenant names: {tenant_exc}")

        # Prepare final response - ORIGINAL FORMAT PRESERVED
        response = {
            "flag": True,
            "meta": {
                "tenants": meta_tenants,
                "providers": meta_providers,
                "default_time_range": meta_info.get("default_time_range", "1_month"),
            },
            "data": {
               "title": "Revenue by Usage Type",
                "chart_type": "bar",
                "xField": ["Usage", "Sms"],
                "yField": "",
                "smooth": True,
                "height": 300,
                "width": 500,
                "data": formatted_buckets
            }
        }
        return response

    except Exception as exception:
        logging.exception(f"[get_revenue_by_usage_trend] Exception: {exception}")
        response["flag"] = False
        response["data"]["data"] = {}
        response["data"]["yField"] = []
        response["message"] = f"Error retrieving plan usage by service provider{exception}"
        try:
            error_data = {
                "service_name": "get_revenue_by_usage_trend",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            logging.exception("[get_revenue_by_usage_trend] Error logging to DB")

    return response


######################### Revenue metrics  ############################

########################## zendesk Tab ####################

ZENDESK_SUBDOMAIN = os.getenv('ZENDESK_SUBDOMAIN')

BASE_URL = f'https://{ZENDESK_SUBDOMAIN}.zendesk.com/api/v2'
ZENDESK_EMAIL = os.getenv('ZENDESK_EMAIL')
ZENDESK_API_TOKEN = os.getenv('ZENDESK_API_TOKEN')

def normalize(tag):
    """
    Converts tag to lowercase and removes all non-alphanumeric characters.
    Example: "Bulk Change" → "bulkchange"
    """
    return re.sub(r'[^a-z0-9]', '', tag.lower())



def generate_intervals_for_label(label, start, end):
    """Generate start points for intervals based on label rules."""
    intervals = []

    if label == "1_day":
        # Every 4 hours
        current = datetime.combine(start, datetime.min.time())
        while current <= datetime.combine(end, datetime.max.time()):
            intervals.append(current)
            current += timedelta(hours=4)

    elif label == "5_day":
        # Every 1 day
        current = start
        while current <= end:
            intervals.append(datetime.combine(current, datetime.min.time()))
            current += timedelta(days=1)

    elif label in ["1_month", "3_month", "6_month", "1_year"]:
        today = date.today()
        # Weekly grouping 1–7, 8–14, 15–21, 22–end_of_month
        current = start
        while current <= end:
            y, m = current.year, current.month
            days_in_month = monthrange(y, m)[1]

            # If this is the current month, only go up to today
            if y == today.year and m == today.month:
                days_in_month = today.day

            cutoffs = [1, 8, 15, 22, days_in_month + 1]

            for i in range(len(cutoffs) - 1):
                week_start = date(y, m, cutoffs[i])
                if week_start < start or week_start > end:
                    continue
                intervals.append(datetime.combine(week_start, datetime.min.time()))

            # Go to next month
            if m == 12:
                current = date(y + 1, 1, 1)
            else:
                current = date(y, m + 1, 1)

    elif label == "5_years":
        today = date.today()
        # today = date.today()
        start_year = today.year - 4
        for year in range(start_year, today.year + 1):
            intervals.append(datetime.combine(date(year, 1, 1), datetime.min.time()))

    elif label == "max":
        # Every 2 years
        start_year = (start.year // 2) * 2
        current = date(start_year, 1, 1)
        while current <= end:
            intervals.append(datetime.combine(current, datetime.min.time()))
            current = date(current.year + 2, 1, 1)

    return intervals



def get_status_count_of_tickets(data):
    """
    Returns count of tickets based on status. Uses Redis caching and filters data only on cached results.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'service_provider' (str, optional): Filter by provider name.
           
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return ticket countbased on status .
            - 'message' (str): Error message if applicable.
    """

    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"

    response_data = {
        "flag": False,
        "data": {
            "title": "Ticket Status Volume",
            "columns": ["Status", "Count"],
            "organization_id": organization_id,
            "rows": [],
            "height": 100,
            "width": 300,
        },
        "message": "",
    }

    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as exception:
        response_data["message"] = f"Database connection error : {exception}"
        try:
            error_data = {
                "service_name": "get_status_count_of_tickets",
                "created_date": request_received_at,
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            common_utils_database.log_error_to_db(error_data, "error_table")
        except Exception:
            pass
        return response_data

    try:
        # Cache logic
        function = "get_status_count_of_tickets"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Redis cache retrieval failed: {cache_exc}")

        if refresh or cached_data is None:
            logging.info("Fetching fresh data for ticket status count")

            query = """
                SELECT 
                    ticket_status,
                    updated_date as created_date,
                    organization_id
                FROM public.zendesk_tickets_tracking
                WHERE ticket_status IN ('open', 'new', 'hold', 'pending', 'solved', 'closed')
            """

            result_df = common_utils_database.execute_query(query, flag=True)
            if isinstance(result_df, pd.DataFrame) and not result_df.empty:
                result_df["created_date"] = pd.to_datetime(result_df["created_date"]).dt.date
                cached_data = result_df.to_dict(orient="records")

                try:
                    redis_client.setex(cache_key, 9000, json.dumps(cached_data,default=str))  # 2 hours TTL
                    # redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
                    logging.info(f"Redis set successful: {cache_key}")
                except Exception as redis_exc:
                    logging.warning(f"Redis set failed: {redis_exc}")
                new_sync_time = datetime.now()
                #  Audit refresh after setting cache
                try:
                        audit_data = {
                            "function_name": function,
                            "created_date": request_received_at,
                            "created_by": username,
                            "last_synced_by": username,
                            "last_sync_date": new_sync_time,
                        }
                        common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                        logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        # Convert cached data to DataFrame
        df_all = pd.DataFrame(cached_data)
        if not df_all.empty:
            df_all["created_date"] = pd.to_datetime(df_all["created_date"]).dt.date

            if organization_id != "All":
                df_all = df_all[df_all["organization_id"] == str(organization_id)]

            if start_date and end_date:
                start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
                end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
                df_all = df_all[
                    (df_all["created_date"] >= start_date) &
                    (df_all["created_date"] <= end_date)
                ]

            # Define status mapping
            status_map = {
                "open": "Active",
                "new": "Active",
                "hold": "Active",
                "pending": "Inprogress",
                "solved": "Closed",
                "closed": "Closed"
            }

            df_all["status_category"] = df_all["ticket_status"].map(status_map)

            grouped = df_all.groupby("status_category").size().to_dict()

            label_display = {
                "Active": "Active Tickets",
                "Inprogress": "In progress Tickets",
                "Closed": "Closed Tickets"
            }

            status_defaults = {key: 0 for key in label_display}
            for key in grouped:
                if key in status_defaults:
                    status_defaults[key] = grouped[key]

            rows = [{
                "Status": label_display[key],
                "Count": f"{status_defaults[key]:,}"
            } for key in ["Active", "Inprogress", "Closed"]]

            total = sum(status_defaults.values())
            rows.append({"Status": "Total Tickets", "Count": f"{total:,}"})

            response_data["flag"] = True
            response_data["data"]["rows"] = serialize_data(rows)
            response_data["message"] = ""

    except Exception as exception:
        response_data["flag"] = False
        response_data["message"] = f"Error fetching status of tickets: {exception}"
        try:
            error_data = {
                "service_name": "get_status_count_of_tickets",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'common_utils_database' in locals():
                common_utils_database.log_error_to_db(error_data, "error_table")
        except Exception:
            pass

    return response_data

def fetch_zendesk(endpoint, params=None):
    """Fetches data (typically tickets) from the Zendesk API,  
    while handling authentication, pagination, and optional date filtering."""
    all_results = []
    auth = (f"{ZENDESK_EMAIL}/token", ZENDESK_API_TOKEN)
    is_incremental = "/incremental/tickets.json" in endpoint

    # Handle incremental parameters
    start_time = 0
    end_timestamp = None
    if is_incremental and params:
        start_date_str = params.get("start_date", "")
        end_date_str = params.get("end_date", "")

        if start_date_str:
            try:
                start_time = int(time.mktime(datetime.strptime(start_date_str, "%Y-%m-%d").timetuple()))
            except Exception as e:
                logging.warning(f"Invalid start_date format: {start_date_str}. Error: {e}")

        if end_date_str:
            try:
                end_timestamp = int(time.mktime(datetime.strptime(end_date_str, "%Y-%m-%d").timetuple()))
            except Exception as e:
                logging.warning(f"Invalid end_date format: {end_date_str}. Error: {e}")

    # Construct URL
    if is_incremental:
        url = f"{BASE_URL}/incremental/tickets.json?start_time={start_time}"
    else:
        url = f"{BASE_URL}{endpoint}"

 

    prev_url = None
    while url:
        if url == prev_url:
            logging.info("Detected stuck pagination loop. Exiting.")
            break
        prev_url = url
        response = requests.get(url, auth=auth, params=None if is_incremental else params)

        if response.status_code != 200:
            raise Exception(f"API Error {response.status_code}: {response.text}")

        data = response.json()
        results = data.get('tickets', data.get('results', []))
        all_results.extend(results)

        # Stop if end_timestamp is reached
        if is_incremental and end_timestamp is not None:
            latest_ticket_time = data.get('end_time', 0)
            if latest_ticket_time >= end_timestamp:
                break

        url = data.get('next_page')
        if not is_incremental:
            params = None  # Clear params after first request

    return all_results


def get_bulk_organization_names(org_ids):
    """
    Fetches organization names in bulk from Zendesk endpoint.
    Returns a dictionary mapping organization_id -> name.
    """
    if not org_ids:
        return {}
 
    org_ids = list(org_ids)  # ✅ Fix: Ensure list for slicing
    auth = (f"{ZENDESK_EMAIL}/token", ZENDESK_API_TOKEN)
    org_name_map = {}
    chunk_size = 100  # Zendesk limit per request
 
    for i in range(0, len(org_ids), chunk_size):
        chunk = org_ids[i:i + chunk_size]
        ids_param = ",".join(chunk)
        url = f"{BASE_URL}/organizations/show_many.json?ids={ids_param}"
 
        try:
            response = requests.get(url, auth=auth)
            if response.status_code == 200:
                orgs = response.json().get("organizations", [])
                for org in orgs:
                    org_id = str(org.get("id"))
                    org_name = org.get("name")
                    org_name_map[org_id] = org_name
 
            elif response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 10))
                logging.warning(f"Rate limited. Retrying after {retry_after} seconds.")
                time.sleep(retry_after)
                continue
 
            else:
                raise Exception(f"Failed to fetch organizations: {response.status_code} - {response.text}")
        except Exception as exception:
            logging.error(f"Error fetching organization names: {exception}")
 
        time.sleep(0.2)  # Prevent rate limiting
 
    return org_name_map
 
 
def get_ticket_audits(ticket_id, auth):
    """Fetch audit history for a single ticket"""
    audit_url = f"{BASE_URL}/tickets/{ticket_id}/audits.json"
    try:
        response = requests.get(audit_url, auth=auth)
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 10))
            logging.warning(f"Rate limited while fetching audits. Retrying after {retry_after} seconds.")
            time.sleep(retry_after)
            return get_ticket_audits(ticket_id, auth)  # Retry the request
        else:
            logging.warning(f"Failed to fetch audits for ticket {ticket_id}: {response.status_code}")
            return None
    except Exception as e:
        logging.error(f"Error fetching audits for ticket {ticket_id}: {e}")
        return None
 



def insert_new_zendesk_tickets_batch(data):
    """Fetch tickets from Zendesk, insert new tickets into DB, and log audit"""
    response = {
        "flag": False,
        "inserted_count": 0,
        "updated_count": 0,  # ✅ Add this field
        "message": "",
    }
    logging.info("### zendesk ticket details storing.")
    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        batch_size = 100
        auth = (f"{ZENDESK_EMAIL}/token", ZENDESK_API_TOKEN)
        url = f"{BASE_URL}/tickets.json?per_page={batch_size}"

        all_tickets = {}
        while url:
            print(url, "urlurlurl")
            response_api = requests.get(url, auth=auth)
            if response_api.status_code != 200:
                logging.error(f"Failed to fetch tickets: {response_api.status_code} - {response_api.text}")
                response["message"] = f"Failed to fetch tickets: {response_api.status_code}"
                break

            data_api = response_api.json()
            tickets = data_api.get("tickets", data_api.get("results", []))
            if not tickets:
                break

            for t in tickets:
                ticket_id = str(t["id"])
                all_tickets[ticket_id] = t

            url = data_api.get("next_page")
            print(url, ";;;;url")
            time.sleep(0.2)

        if not all_tickets:
            response["message"] = "No tickets found to insert."
            return response

        ticket_ids = list(all_tickets.keys())
        if not ticket_ids:
            response["message"] = "No ticket IDs found."
            return response

        placeholders = ','.join(['%s'] * len(ticket_ids))
        check_query = f"SELECT ticket_id FROM zendesk_tickets_tracking WHERE ticket_id IN ({placeholders})"
        existing_rows = database.execute_query(check_query, return_df=True, params=ticket_ids)
        existing_ids = set(existing_rows["ticket_id"].astype(str)) if existing_rows is not None else set()

        insert_data_in_table = []
        update_data_in_table = []

        # ✅ Collect org_ids for ALL tickets (not just new ones)
        org_ids = {
            str(t.get("organization_id"))
            for t in all_tickets.values()
            if t.get("organization_id")
        }
        org_name_cache = get_bulk_organization_names(org_ids)

        # Process all tickets
        for ticket_id in ticket_ids:
            ticket = all_tickets[ticket_id]
            org_id = str(ticket.get("organization_id")) if ticket.get("organization_id") else None
            org_name = org_name_cache.get(org_id) if org_id else None

            tags_list = ticket.get("tags") or []
            tags_pg_array = '{' + ','.join(f'"{t}"' for t in tags_list) + '}'

            created_at = ticket.get("created_at")
            created_date = None
            if created_at:
                try:
                    dt = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%SZ")
                    created_date = dt.strftime("%Y-%m-%d %H:%M:%S+00")
                except Exception:
                    created_date = created_at
                    
            custom_fields = ticket.get("custom_fields", [])
            non_null_custom_values = [str(cf["value"]).strip() for cf in custom_fields if cf.get("value") and str(cf["value"]).strip() != ""]
            interactions_json = json.dumps(non_null_custom_values) if non_null_custom_values else None

            row_data = {
                "ticket_id": ticket_id,
                "organization_id": org_id,
                "organization_name": org_name,
                "ticket_status": ticket.get("status"),
                "created_date": created_date,
                "tag": tags_pg_array,
                "priority": ticket.get("priority"),
                "subcategory": ticket.get("type"),
                "updated_date": ticket.get("updated_at"),
                "due_at": ticket.get("due_at"),
                "interaction_history": interactions_json,
            }
            
            if ticket_id in existing_ids:
                update_data_in_table.append(row_data)
            else:
                insert_data_in_table.append(row_data)

        inserted_count = 0
        updated_count = 0
        
        # ✅ Handle inserts
        if insert_data_in_table:
            batch_size = 500
            for i in range(0, len(insert_data_in_table), batch_size):
                batch = insert_data_in_table[i:i + batch_size]
                database.insert_data(batch, "zendesk_tickets_tracking")
                inserted_count += len(batch)
            logging.info(f"### Inserted {inserted_count} new tickets.")

        # ✅ Handle updates (changed from elif to if)
        if update_data_in_table:
            try:
                logging.info(f"### Performing bulk update for {len(update_data_in_table)} tickets...")
                success = database.bulk_update_data(
                    "zendesk_tickets_tracking",
                    update_data_in_table,
                    search_column="ticket_id"
                )
                if success:
                    updated_count = len(update_data_in_table)
                    logging.info(f"### Successfully updated {updated_count} tickets.")
                else:
                    logging.warning("### No rows were updated.")
            except Exception as e:
                logging.error(f"### Error while updating Zendesk tickets: {e}")

        # ✅ Set response based on what actually happened
        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["updated_count"] = updated_count
        
        if inserted_count > 0 and updated_count > 0:
            response["message"] = f"Inserted {inserted_count} new tickets, Updated {updated_count} tickets."
        elif inserted_count > 0:
            response["message"] = f"Inserted {inserted_count} new tickets."
        elif updated_count > 0:
            response["message"] = f"Updated {updated_count} tickets."
        else:
            response["message"] = "No tickets to insert or update."

        # Audit log
        try:
            audit_data = {
                "service_name": "insert_new_zendesk_tickets_batch",
                "created_by": "Lambda Sync",
                "status": "Success" if (inserted_count > 0 or updated_count > 0) else "No Changes",
                "comments": f"Inserted {inserted_count} new tickets, Updated {updated_count} tickets.",
                "module_name": "Dashboard",
            }
            database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.warning(f"[insert_new_zendesk_tickets_batch] Audit logging failed: {audit_exc}")

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error inserting Zendesk tickets: {exception}"
        logging.error(f"Exception in insert_new_zendesk_tickets_batch: {exception}", exc_info=True)
        try:
            error_data = {
                "service_name": "insert_new_zendesk_tickets_batch",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": "Lambda Sync",
                "comments": str(exception),
                "module_name": "Dashboard",
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"[insert_new_zendesk_tickets_batch] Error logging to DB: {log_exc}")

    return response



def get_ticket_status_distribution(data):
    """
    Returns ticket status distribution for an organization in multiple time buckets.
    Uses Redis caching to fetch unfiltered data, filters applied in-memory.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
           
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return ticket status distribution .
            - 'message' (str): Error message if applicable.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": ""
        },
        "data": {
            "title": "Ticket Status Distribution",
            "chart_type": "Pie chart",
            "xField": "",
            "yField": "",
            "smooth": False,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [],
                "5_day": [],
                "1_month": [],
                "3_month": [],
                "6_month": [],
                "1_year": [],
                "5_years": [],
                "max": [],
                "custom_range": []
            }
        },
        "message": ""
    }

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        # NEW: Fetch tenant timezone for 1_day bucket
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"

        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        # Redis cache key
        function = "get_ticket_status_distribution"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    logging.info(f"Cache hit: {cache_key}")
            except Exception as cache_exc:
                logging.warning(f"Redis cache retrieval failed: {cache_exc}")

        if refresh or cached_data is None:
            logging.info("Fetching fresh data for ticket status distribution")

            raw_query = """
                SELECT 
                    organization_id,
                    organization_name,
                    updated_date as created_date,
                    ticket_status
                FROM zendesk_tickets_tracking
                WHERE created_date IS NOT NULL
            """

            df = database.execute_query(raw_query, flag=True)
            df = df if isinstance(df, pd.DataFrame) else pd.DataFrame()
            if not df.empty:
                # Keep both tz-aware timestamp and date-only for downstream buckets
                df["created_datetime"] = pd.to_datetime(df["created_date"], errors="coerce", utc=True)
                df["created_date"] = df["created_datetime"].dt.date

                cached_data = df.to_dict(orient="records")

                try:
                    redis_client.setex(cache_key, 9000, json.dumps(cached_data, default=str))
                    # redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
                except Exception as redis_exc:
                    logging.warning(f"Redis set failed: {redis_exc}")
                new_sync_time = datetime.now()
                #  Audit refresh after setting cache
                try:
                    audit_data = {
                        "function_name": function,
                        "created_date": request_received_at,
                        "created_by": username,
                        "last_synced_by": username,
                        "last_sync_date": new_sync_time,
                    }
                    database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        df_all = pd.DataFrame(cached_data)
        if df_all.empty:
            return response

        # Ensure tz-aware created_datetime and date-only created_date (handles cached records too)
        if "created_datetime" in df_all.columns:
            try:
                df_all["created_datetime"] = pd.to_datetime(df_all["created_datetime"], utc=True)
            except Exception:
                df_all["created_datetime"] = pd.to_datetime(df_all["created_datetime"], errors="coerce", utc=True)
        else:
            df_all["created_datetime"] = pd.to_datetime(df_all["created_date"], errors="coerce", utc=True)

        df_all["created_date"] = df_all["created_datetime"].dt.date

        logging.info("df_all['created_date'] -> %s", df_all["created_date"].head())

        # Apply filters
        if organization_id and organization_id != "All":
            before = len(df_all)
            df_all = df_all[df_all["organization_id"] == str(organization_id)]
            after = len(df_all)
            logging.info(f"[Filter] Org filter applied: {before} -> {after} rows for org_id={organization_id}")
        logging.info("start_date %s", start_date)
        logging.info("end_date %s", end_date)
        if start_date and end_date:
            before = len(df_all)
            logging.info(f"[Filter] Date filter requested: start_date={start_date}, end_date={end_date}")

            df_all = df_all[
                (df_all["created_date"] >= start_date) & 
                (df_all["created_date"] <= end_date)
            ]
            after = len(df_all)
            logging.info(f"[Filter] After date filtering: {before} -> {after} rows")
            if df_all.empty:
                response["message"] = "No data available for the selected date range."
                response["flag"] = True   # mark as success
                return response
        logging.info("df_all-> %s", df_all.shape)

        # Determine min_date if not provided
        min_date = df_all["created_date"].min() if not (start_date and end_date) else None
        logging.info(f"[Bucket] min_date={min_date}, start_date={start_date}, end_date={end_date}")
        time_buckets, default_label = execute_all_time_buckets(tenant_time_zone,start_date, end_date, min_date, column="created_date")
        logging.info("time_buckets %s", time_buckets)
        logging.info("default_label %s", default_label)
        response["meta"]["default_time_range"] = default_label

        status_map = {
            'open': 'Open',
            'new': 'To do',
            'pending': 'Inprogress',
            'hold': 'To do',
            'solved': 'Closed',
            'closed': 'Closed'
        }

        org_id_to_name = {}
        collected_org_ids = set()

        # ---------- INLINE 1_day handling using explicit pd.date_range 4-hour edges ----------
        if any(b["label"] == "1_day" for b in time_buckets):
            bucket = next(b for b in time_buckets if b["label"] == "1_day")
            b_start = bucket["start"]
            b_end = bucket["end"]

            # Build timezone-aware timestamps in UTC (to match created_datetime)
            bucket_start_dt = datetime.combine(b_start, datetime.min.time())
            bucket_end_dt = datetime.combine(b_end, datetime.max.time())

            bucket_start_ts = pd.Timestamp(bucket_start_dt).tz_localize("UTC")
            bucket_end_ts = pd.Timestamp(bucket_end_dt).tz_localize("UTC")

            floored_start = bucket_start_ts.floor("4h")
            ceiled_end = bucket_end_ts.ceil("4H")

            edges = pd.date_range(start=floored_start, end=ceiled_end, freq="4h", tz="UTC")

            for i in range(len(edges) - 1):
                interval_start_ts = edges[i]
                interval_end_ts = edges[i + 1] - pd.Timedelta(seconds=1)

                # Filter rows for this 4-hour window using tz-aware created_datetime
                df_filtered = df_all[
                    (df_all["created_datetime"] >= interval_start_ts) &
                    (df_all["created_datetime"] <= interval_end_ts)
                ].copy()

                if df_filtered.empty:
                    continue

                # label for this window uses interval end timestamp
                date_label = interval_end_ts.strftime("%Y-%m-%d %H:%M:%S")

                df_filtered["status_category"] = df_filtered["ticket_status"].fillna("").str.lower().map(status_map).fillna("To do")

                org_records = defaultdict(lambda: defaultdict(lambda: {"Open": 0, "To do": 0, "Inprogress": 0, "Closed": 0}))
                for _, row in df_filtered.iterrows():
                    org_id = row.get("organization_id")
                    org_name = row.get("organization_name", "Unknown Organization")
                    status = row.get("status_category", "To do")

                    if not org_id:
                        continue

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name
                    org_records[org_id][date_label][status] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [{"date": date_key, "status_counts": counts} for date_key, counts in date_dict.items()]
                    response["data"]["data"]["1_day"].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })

            # Remove 1_day bucket from further processing
            time_buckets = [b for b in time_buckets if b["label"] != "1_day"]
        # ---------- END INLINE 1_day handling ----------

        # --- Updated interval/sub-bucket logic starts here (remaining labels) ---
        for bucket in time_buckets:
            start, end, label = bucket["start"], bucket["end"], bucket["label"]
            intervals = generate_intervals_for_label(label, start, end)

            for interval_start in intervals:
                # Determine interval_end based on label
                if label == "5_day":
                    interval_end = interval_start + timedelta(days=1) - timedelta(seconds=1)
                elif label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [1, 8, 15, 22,29, days_in_month + 1]
                    start_day = interval_start.day
                    idx = cutoffs.index(start_day)
                    end_day = cutoffs[idx + 1] - 1
                    interval_end = date(y, m, end_day)
                
                elif label == "5_years":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)
                elif label == "max":
                    interval_end = date(interval_start.year + 2, 1, 1) - timedelta(seconds=1)
                else:
                    interval_end = end

                start_dt = interval_start.date() if isinstance(interval_start, datetime) else interval_start
                end_dt = interval_end.date() if isinstance(interval_end, datetime) else interval_end

                df_filtered = df_all[
                    (df_all["created_date"] >= start_dt) & 
                    (df_all["created_date"] <= end_dt)
                ].copy()

                if df_filtered.empty:
                    continue

                if label in ["5_years", "max"]:
                    # Ensure created_date is datetime first
                    df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                else:
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d")  # assign all to interval end
                df_filtered["status_category"] = df_filtered["ticket_status"].str.lower().map(status_map).fillna("To do")

                org_records = defaultdict(lambda: defaultdict(lambda: {"Open": 0, "To do": 0, "Inprogress": 0, "Closed": 0}))
                for _, row in df_filtered.iterrows():
                    org_id = row["organization_id"]
                    org_name = row.get("organization_name", "Unknown Organization")
                    date_val = row["date"]
                    status = row["status_category"]

                    if not org_id:
                        continue

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name
                    org_records[org_id][date_val][status] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [{"date": date_key, "status_counts": counts} for date_key, counts in date_dict.items()]
                    response["data"]["data"][label].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })
        # --- End of updated interval/sub-bucket logic ---
        # After all loops
        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        logging.exception(f"[get_ticket_status_distribution] Error: {exception}")
        response["message"] = f"Unexpected error occurred during data preparation: {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_status_distribution",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            pass

    return response



def get_ticket_resolution_time(data):
    
    """
    Calculates the average resolution time for tickets, grouped by organization,
    and provides this data across multiple time buckets.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": ""
        },
        "data": {
            "title": "Ticket Resolution Time",
            "chart_type": "line",
            "xField": "date",
            "yField": "avg_resolution_hours",
            "smooth": True,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [],
                "5_day": [],
                "1_month": [],
                "3_month":[],
                "6_month":[],
                "1_year": [],
                "5_years": [],
                "max": [],
                "custom_range": []
            }
        },
        "message": ""
    }

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        if not (start_date and end_date):
            min_date_query = "SELECT MIN(created_date) FROM zendesk_tickets_tracking"
            min_date_result = database.execute_query(min_date_query, flag=True)
            min_date_str = min_date_result.iloc[0]["min"] if not min_date_result.empty else None
            min_date = datetime.fromisoformat(min_date_str.replace("Z", "")).date() if min_date_str else None
        else:
            min_date = None

        time_buckets, default_label = execute_all_time_buckets(start_date, end_date, min_date)
        response["meta"]["default_time_range"] = default_label

        collected_org_ids = set()
        org_id_to_name = {}

        for bucket in time_buckets:
            start = bucket["start"]
            end = bucket["end"]
            label = bucket["label"]
            time_format = bucket["format"]
            formatted_time = time_format.replace("created_date", "created_date::timestamp")

            base_query = f"""
                SELECT
                    organization_id,
                    organization_name,
                    {formatted_time} AS date,
                    AVG(EXTRACT(EPOCH FROM (updated_date - created_date))) / 3600 AS avg_resolution_hours
                FROM zendesk_tickets_tracking
                WHERE ticket_status IN ('solved', 'closed') AND updated_date IS NOT NULL
            """
            query_params = []

            if start and end:
                base_query += " AND created_date::timestamp BETWEEN %s AND %s"
                query_params.append(start.strftime("%Y-%m-%d 00:00:00"))
                query_params.append(end.strftime("%Y-%m-%d 23:59:59"))

            if organization_id and str(organization_id).lower() != "all":
                org_id_str = str(organization_id).strip()
                base_query += " AND organization_id = %s"
                query_params.append(org_id_str)

            base_query += " GROUP BY organization_id, organization_name, date ORDER BY date"

            results_df = database.execute_query(base_query, params=query_params)
            results = results_df.to_dict(orient="records") if results_df is not None else []

            for row in results:
                org_id = row.get("organization_id")
                org_name = row.get("organization_name") or "Unknown Organization"
                collected_org_ids.add(org_id)
                org_id_to_name[org_id] = org_name

                response["data"]["data"][label].append({
                    "organization_id": org_id,
                    "organization_name": org_name,
                    "date": str(row.get("date", "")).replace("'", ""),
                    "avg_resolution_hours": round(row.get("avg_resolution_hours", 0), 2)
                })

        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        response["message"] = f"Error fetching ticket resolution time : {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_resolution_time",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            database.log_error_to_db(error_data, "error_log_table")
            logging.error(f"[get_ticket_resolution_time]: {exception}")
        except Exception as e:
            logging.exception(f"[get_ticket_resolution_time] Error logging to DB : {e}")

    return response


def get_ticket_severity_overview(data):
    """
    Returns ticket severity distribution (Low, Medium, High) for an organization across time buckets,
    with interval logic and week cutoff grouping for month-based labels.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return ticket count based on severity(low,high,medium) .
            - 'message' (str): Error message if applicable.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "False")).lower() == "true"

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": ""
        },
        "data": {
            "title": "Ticket Severity Overview",
            "chart_type": "Heatmap",
            "xField": "",
            "yField": "",
            "smooth": False,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [], "5_day": [], "1_month": [], "3_month": [], "6_month": [],
                "1_year": [], "5_years": [], "max": [], "custom_range": []
            }
        },
        "message": ""
    }

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        # NEW: Fetch tenant timezone for 1_day bucket
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        # Redis cache
        function = "get_ticket_severity_overview"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    logging.info(f"[Cache Hit] {cache_key}")
            except Exception as e:
                logging.warning(f"[Redis Get Error] {e}")

        if refresh or cached_data is None:
            raw_query = """
                SELECT 
                    organization_id,
                    organization_name,
                    updated_date as created_date,
                    priority
                FROM zendesk_tickets_tracking
                WHERE created_date IS NOT NULL
            """
            df = database.execute_query(raw_query, flag=True)
            df = df if isinstance(df, pd.DataFrame) else pd.DataFrame()

            if not df.empty:
                # Keep full timestamp (tz-aware) and date-only
                df["created_datetime"] = pd.to_datetime(df["created_date"], errors="coerce", utc=True)
                df["created_date"] = df["created_datetime"].dt.date

                cached_data = df.to_dict(orient="records")
                try:
                    redis_client.setex(cache_key, 9000, json.dumps(cached_data, default=str))
                    # redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
                except Exception as e:
                    logging.warning(f"[Redis Set Error] {e}")

                try:
                    audit_data = {
                        "function_name": function,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        df_all = pd.DataFrame(cached_data)
        if df_all.empty:
            return response

        # Ensure tz-aware created_datetime and date-only created_date for downstream logic
        if "created_datetime" in df_all.columns:
            try:
                df_all["created_datetime"] = pd.to_datetime(df_all["created_datetime"], utc=True)
            except Exception:
                df_all["created_datetime"] = pd.to_datetime(df_all["created_datetime"], errors="coerce", utc=True)
        else:
            df_all["created_datetime"] = pd.to_datetime(df_all.get("created_date", None), errors="coerce", utc=True)

        df_all["created_date"] = df_all["created_datetime"].dt.date

        logging.info("Requested range: %s to %s", start_date, end_date)
        logging.info("Available range: %s to %s", df_all["created_date"].min(), df_all["created_date"].max())

        # Filters
        if organization_id and organization_id != "All":
            df_all = df_all[df_all["organization_id"] == str(organization_id)]

        if start_date and end_date:
            df_all = df_all[
                (df_all["created_date"] >= start_date) &
                (df_all["created_date"] <= end_date)
            ]
            if df_all.empty:
                response["message"] = "No data available for the selected date range."
                response["flag"] = True   # mark as success
                return response

        min_date = df_all["created_date"].min() if not (start_date and end_date) else None
        time_buckets, default_label = execute_all_time_buckets(tenant_time_zone,start_date, end_date, min_date, column="created_date")
        response["meta"]["default_time_range"] = default_label

        severity_map = {
            'low': 'Low',
            'normal': 'Medium',
            'high': 'High',
            'urgent': 'High'
        }

        collected_org_ids = set()
        org_id_to_name = {}

        # ---------- INLINE 1_day handling using explicit pd.date_range 4-hour edges ----------
        if any(b["label"] == "1_day" for b in time_buckets):
            bucket = next(b for b in time_buckets if b["label"] == "1_day")
            b_start = bucket["start"]
            b_end = bucket["end"]

            # Build timezone-aware timestamps in UTC (to match created_datetime)
            bucket_start_dt = datetime.combine(b_start, datetime.min.time())
            bucket_end_dt = datetime.combine(b_end, datetime.max.time())

            bucket_start_ts = pd.Timestamp(bucket_start_dt).tz_localize("UTC")
            bucket_end_ts = pd.Timestamp(bucket_end_dt).tz_localize("UTC")

            floored_start = bucket_start_ts.floor("4H")
            ceiled_end = bucket_end_ts.ceil("4H")

            edges = pd.date_range(start=floored_start, end=ceiled_end, freq="4h", tz="UTC")

            for i in range(len(edges) - 1):
                interval_start_ts = edges[i]
                interval_end_ts = edges[i + 1] - pd.Timedelta(seconds=1)

                # Filter rows for this 4-hour window using tz-aware created_datetime
                df_filtered = df_all[
                    (df_all["created_datetime"] >= interval_start_ts) &
                    (df_all["created_datetime"] <= interval_end_ts)
                ].copy()

                if df_filtered.empty:
                    continue

                # Map priority -> severity and aggregate counts
                df_filtered["priority"] = df_filtered["priority"].fillna("").astype(str).str.lower()
                df_filtered["severity"] = df_filtered["priority"].map(severity_map).fillna("Medium")
                date_label = interval_end_ts.strftime("%Y-%m-%d %H:%M:%S")

                org_records = defaultdict(lambda: defaultdict(lambda: {"Low": 0, "Medium": 0, "High": 0}))
                for _, row in df_filtered.iterrows():
                    org_id = row.get("organization_id")
                    org_name = row.get("organization_name", "Unknown Organization")
                    severity = row.get("severity", "Medium")

                    if not org_id:
                        continue

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name
                    org_records[org_id][date_label][severity] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [
                        {"date": date_key, "severity_counts": counts}
                        for date_key, counts in date_dict.items()
                    ]
                    response["data"]["data"]["1_day"].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })

            # Remove 1_day bucket from further processing
            time_buckets = [b for b in time_buckets if b["label"] != "1_day"]
        # ---------- END INLINE 1_day handling ----------

        # Main loop for remaining buckets
        for bucket in time_buckets:
            start, end, label = bucket["start"], bucket["end"], bucket["label"]
            intervals = generate_intervals_for_label(label, start, end)

            for interval_start in intervals:
                # Determine interval_end
                if label == "5_day":
                    interval_end = interval_start + timedelta(days=1) - timedelta(seconds=1)
                elif label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [1, 8, 15, 22,29, days_in_month + 1]
                    start_day = interval_start.day
                    if start_day in cutoffs:
                        idx = cutoffs.index(start_day)
                        end_day = cutoffs[idx + 1] - 1
                        interval_end = date(y, m, end_day)
                    else:
                        interval_end = interval_start + timedelta(days=6)
                elif label == "5_years":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)
                # elif label == "max":
                #     start_year = df_all["created_date"].min().year
                #     end_year = df_all["created_date"].max().year

                #     for year in range(start_year, end_year + 1):
                #         year_start = date(year, 1, 1)
                #         year_end = date(year, 12, 31)

                #         if start_date and year_start < start_date:
                #             year_start = start_date
                #         if end_date and year_end > end_date:
                #             year_end = end_date

                #         df_filtered = df_all[
                #             (df_all["created_date"] >= year_start) &
                #             (df_all["created_date"] <= year_end)
                #         ].copy()

                #         if df_filtered.empty:
                #             continue

                #         if label in ["5_years", "max"]:
                #             df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                #         elif label == "1_day":
                #             df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                #         else:
                #             df_filtered["date"] = interval_end.strftime("%Y-%m-%d")
                #         df_filtered["priority"] = df_filtered["priority"].fillna("").astype(str).str.lower()
                #         df_filtered["severity"] = df_filtered["priority"].map(severity_map).fillna("Medium")

                #         org_records = defaultdict(lambda: defaultdict(lambda: {"Low": 0, "Medium": 0, "High": 0}))
                #         for _, row in df_filtered.iterrows():
                #             org_id = row["organization_id"]
                #             org_name = row.get("organization_name", "Unknown Organization")
                #             date_val = row["date"]
                #             severity = row["severity"]

                #             collected_org_ids.add(org_id)
                #             org_id_to_name[org_id] = org_name
                #             org_records[org_id][date_val][severity] += 1

                #         for org_id, date_dict in org_records.items():
                #             formatted_records = [
                #                 {"date": date_key, "severity_counts": counts}
                #                 for date_key, counts in date_dict.items()
                #             ]
                #             response["data"]["data"][label].append({
                #                 "organization_id": org_id,
                #                 "records": serialize_data(formatted_records)
                #             })
                elif label == "max":
                    interval_end = date(interval_start.year + 2, 1, 1) - timedelta(seconds=1)
                else:
                    interval_end = end

                start_dt = interval_start.date() if isinstance(interval_start, datetime) else interval_start
                end_dt = interval_end.date() if isinstance(interval_end, datetime) else interval_end

                df_filtered = df_all[
                    (df_all["created_date"] >= start_dt) &
                    (df_all["created_date"] <= end_dt)
                ].copy()

                if df_filtered.empty:
                    continue

                df_filtered["priority"] = df_filtered["priority"].fillna("").astype(str).str.lower()
                df_filtered["severity"] = df_filtered["priority"].map(severity_map).fillna("Medium")

                # ✅ For month-based labels, set the date to the week cutoff date
                if label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [7, 14, 21,28, days_in_month]
                    start_day = interval_start.day
                    end_day = next((c for c in cutoffs if start_day <= c), days_in_month)
                    df_filtered["date"] = date(y, m, end_day).strftime("%Y-%m-%d")
                elif label in ["5_years", "max"]:
                    df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                elif label == "1_day":
                    # this branch won't run because we handled 1_day above
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d")

                org_records = defaultdict(lambda: defaultdict(lambda: {"Low": 0, "Medium": 0, "High": 0}))
                for _, row in df_filtered.iterrows():
                    org_id = row["organization_id"]
                    org_name = row.get("organization_name", "Unknown Organization")
                    date_val = row["date"]
                    severity = row["severity"]

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name
                    org_records[org_id][date_val][severity] += 1

                for org_id, date_dict in org_records.items():
                    formatted_records = [
                        {"date": date_key, "severity_counts": counts}
                        for date_key, counts in date_dict.items()
                    ]
                    response["data"]["data"][label].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })

        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        logging.exception("[get_ticket_severity_overview]")
        response["message"] = f"Error fetching ticket severity overview: {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_severity_overview",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            pass

    return response






def get_ticket_category_distribution(data):
    """
    Returns ticket category distribution for an organization across multiple time buckets
    using mapped Zendesk tags, with Redis caching.
    Args:
        data (dict): Input parameters including:
            - 'db_name' (str): Tenant database name.
            - 'tenant_name' (str, optional): Display name of the tenant.
            - 'tenant_id' (str/int, optional): Tenant ID filter.
            - 'start_date', 'end_date' (str, optional): Date range for filtering.      
            - 'refresh' (bool/str, optional): Force cache refresh.
            - 'username', 'sessionID', 'request_received_at' (str, optional): Audit logging info.
    Returns:
        dict: JSON-serializable response containing:
            - 'flag' (bool): True if successful, False on error.
            - 'meta' (dict): Tenant and provider metadata, default time range.
            - 'data' (dict): return ticket count based on category .
            - 'message' (str): Error message if applicable.
    """
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "false")).lower() == "true"

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": ""
        },
        "data": {
            "title": "Ticket Category Distribution",
            "chart_type": "Heatmap",
            "xField": "",
            "yField": "",
            "smooth": False,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [], "5_day": [], "1_month": [], "3_month": [], "6_month": [],
                "1_year": [], "5_years": [], "max": [],
                "custom_range": []
            }
        },
        "message": ""
    }

    CATEGORY_MAPPING = {
        # Top: ordered to match the module hierarchy you provided
        "Dashboard": ["dashboard", "dashboards", "__dashboard", "__dashboards"],

        "Sim Management": ["simmanagement", "simmanagements", "__simmanagement", "__simmanagements"],
        "Inventory": ["inventory"],                       # child of Sim Management / Device Management
        "Bulk Change": ["bulkchange"],
        "Customer Rate Plans": ["customerrateplan", "customerrateplans"],
        "Customer Rate Pool": ["customerratepool", "customerratepools", "__customerratepool", "_customerratepools"],
        "Carrier Rate Plan": ["__carrierrateplan", "__carrierrateplans", "carrierrateplan", "carrierrateplans"],
        "Communication Plans": ["communicationplan", "communicationplans", "__communicationplan", "__communicationplans"],
        "Optimization Groups": ["optimizationgroup", "optimizationgroups", "__optimizationgroup", "__optimizationgroups"],
        "Revenue Assurance": ["revenueassurance"],

        "Device Management": ["devicemanagement", "devicemanagements", "__devicemanagement", "__devicemanagements"],
        "Optimization": ["optimization", "optimization"],
        "Service Qualification": ["servicequalification", "servicequalifications", "__servicequalification", "__servicequalifications"],

        "Reports": ["report", "reports", "__report", "__reports"],
        "Automation": ["automation", "__automation", "__automations"],
        "NetSapiens": ["netsapiens", "__netsapiens"],
        "LNP": ["lnp", "__lnp"],
        "People": ["people", "__people"],

        # Bottom: keys from the original mapping that were NOT found in the hierarchy JSON
        "Billing Platform": ["billingplatform"],
        "Customer Groups": ["customergroup", "customergroups", "__customergroup", "__customergroups"],
        "Miscellaneous": ["miscellaneous", "__miscellaneous"],
        "Notifications": ["notification", "notifications", "__notification", "__notifications"],
        "Push Charges": ["pushcharge", "pushcharges", "__pushcharge", "__pushcharges"],
        "Settings": ["setting", "settings", "__setting", "__settings"],
        "Super Admin": ["superadmin", "superadmins", "__superadmin", "__superadmins"],
        "Ui Feature": ["uifeature", "uifeatures", "__uifeature", "__uifeatures"],
        "Users": ["user", "users", "__user", "__users"],
    }


    NORMALIZED_TAG_TO_CATEGORY = {
        normalize(tag): cat
        for cat, tag_list in CATEGORY_MAPPING.items()
        for tag in tag_list
    }

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        # NEW: Fetch tenant timezone for 1_day bucket
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        function = "get_ticket_category_distribution"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    logging.info(f"[Cache Hit] {cache_key}")
            except Exception as e:
                logging.warning(f"[Redis Get Error] {e}")

        if refresh or cached_data is None:
            
            raw_query = """
                SELECT 
                organization_id,
                organization_name,
                updated_date as created_date,
                '{' ||
                array_to_string(
                    ARRAY(
                        SELECT '"' || jsonb_array_elements_text(interaction_history) || '"'
                    ), 
                    ', '
                ) || '}' AS tag
            FROM zendesk_tickets_tracking
            WHERE created_date IS NOT NULL;

            """
            df = database.execute_query(raw_query, flag=True)
            df = df if isinstance(df, pd.DataFrame) else pd.DataFrame()

            if not df.empty:
                cached_data = df.to_dict(orient="records")
                try:
                    redis_client.setex(cache_key, 9000, json.dumps(cached_data, default=str))
                    # redis_client.set(f"{cache_key}:timestamp", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
                except Exception as e:
                    logging.warning(f"[Redis Set Error] {e}")

                new_sync_time = datetime.now()
                try:
                    audit_data = {
                        "function_name": function,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        df_all = pd.DataFrame(cached_data)
        if df_all.empty:
            return response

        # Keep both timestamp and date so 1_day can use full timestamp
        df_all["created_datetime"] = pd.to_datetime(df_all["created_date"], utc=True)
        df_all["created_date"] = df_all["created_datetime"].dt.date

        logging.info("Requested range: %s to %s", start_date, end_date)
        logging.info("Available range: %s to %s", df_all["created_date"].min(), df_all["created_date"].max())

        if organization_id and organization_id != "All":
            df_all = df_all[df_all["organization_id"] == str(organization_id)]

        if start_date and end_date:
            df_all = df_all[
                (df_all["created_date"] >= start_date) &
                (df_all["created_date"] <= end_date)
            ]
            if df_all.empty:
                response["message"] = "No data available for the selected date range."
                response["flag"] = True   # mark as success
                return response

        min_date = df_all["created_date"].min() if not (start_date and end_date) else None
        time_buckets, default_label = execute_all_time_buckets(tenant_time_zone,start_date, end_date, min_date, column="created_date")
        response["meta"]["default_time_range"] = default_label

        collected_org_ids = set()
        org_id_to_name = {}

        for bucket in time_buckets:
            start, end, label = bucket["start"], bucket["end"], bucket["label"]
            # generate_intervals_for_label is still used for non-1_day labels
            if label == "1_day":
                # ---------------------------
                # Option 2 logic: explicit 4-hour bucket edges using pd.date_range
                # ---------------------------
                # Build timezone-aware interval range for this bucket.
                # Start at start date 00:00:00 and end at end date 23:59:59 to cover full day(s)
                bucket_start_dt = datetime.combine(start, datetime.min.time())
                bucket_end_dt = datetime.combine(end, datetime.max.time())

                # Make tz-aware to match created_datetime (which we set with utc=True)
                # created_datetime is tz-aware (UTC)
                bucket_start_ts = pd.Timestamp(bucket_start_dt).tz_localize("UTC")
                bucket_end_ts = pd.Timestamp(bucket_end_dt).tz_localize("UTC")

                # Floor the start to nearest 4H boundary and ceil the end to nearest 4H boundary
                # We compute a starting edge aligned with 4-hour boundaries
                floored_start = pd.Timestamp(bucket_start_ts).floor("4H")
                ceiled_end = pd.Timestamp(bucket_end_ts).ceil("4H")

                # Generate edges every 4 hours
                edges = pd.date_range(start=floored_start, end=ceiled_end, freq="4h", tz="UTC")

                # Iterate over consecutive pairs of edges to form intervals
                # edges: e0, e1, e2,...; intervals are [e0, e1-1s], [e1, e2-1s], ...
                for i in range(len(edges) - 1):
                    interval_start_ts = edges[i]
                    interval_end_ts = edges[i + 1] - pd.Timedelta(seconds=1)

                    # Filter rows for this 4-hour window using created_datetime (tz-aware)
                    df_filtered = df_all[
                        (df_all["created_datetime"] >= interval_start_ts) &
                        (df_all["created_datetime"] <= interval_end_ts)
                    ].copy()

                    if df_filtered.empty:
                        continue

                    # Build counts per org for this interval
                    org_records = defaultdict(lambda: defaultdict(lambda: {
                    # Order matching your module hierarchy
                    "Dashboard": 0,

                    "Sim Management": 0,
                    "Inventory": 0,
                    "Bulk Change": 0,
                    "Customer Rate Plans": 0,
                    "Customer Rate Pool": 0,
                    "Carrier Rate Plan": 0,
                    "Communication Plans": 0,
                    "Optimization Groups": 0,
                    "Revenue Assurance": 0,

                    "Device Management": 0,
                    "Optimization": 0,
                    "Service Qualification": 0,

                    "Reports": 0,
                    "Automation": 0,
                    "NetSapiens": 0,
                    "LNP": 0,
                    "People": 0,

                    # Not present in hierarchy → moved to bottom
                    "Billing Platform": 0,
                    "Customer Groups": 0,
                    "Miscellaneous": 0,
                    "Notifications": 0,
                    "Push Charges": 0,
                    "Settings": 0,
                    "Super Admin": 0,
                    "Ui Feature": 0,
                    "Users": 0,

                    # Always last
                    "Uncategorized": 0
                }))

                    for _, row in df_filtered.iterrows():
                        org_id = row["organization_id"]
                        org_name = row.get("organization_name", "Unknown Organization")
                        tag_string = row.get("tag", "")

                        if not org_id:
                            continue

                        collected_org_ids.add(org_id)
                        org_id_to_name[org_id] = org_name

                        tags = [t.strip() for t in (tag_string or "").split(',') if t]
                        normalized_tags = [normalize(t) for t in tags]

                        matched = False
                        matched_category = next(
                            (cat_name for cat_tag, cat_name in NORMALIZED_TAG_TO_CATEGORY.items()
                            if any(norm_tag.endswith(cat_tag) for norm_tag in normalized_tags)),
                            None
                        )

                        if matched_category:
                            org_records[org_id][str(interval_end_ts)][matched_category] += 1
                        else:
                            org_records[org_id][str(interval_end_ts)]["Uncategorized"] += 1

                            
                        

                    # Append results for each org for this interval
                    for org_id, date_dict in org_records.items():
                        formatted_records = [
                            {"date": date_key, "category_counts": counts}
                            for date_key, counts in date_dict.items()
                        ]
                        response["data"]["data"][label].append({
                            "organization_id": org_id,
                            "records": serialize_data(formatted_records)
                        })

                # Done with 1_day; continue to next bucket
                continue

            # For non-1_day labels use original interval generation
            intervals = generate_intervals_for_label(label, start, end)

            for interval_start in intervals:
                # Determine interval_end
                if label == "5_day":
                    interval_end = interval_start + timedelta(days=1) - timedelta(seconds=1)
                elif label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [1, 8, 15, 22,29, days_in_month + 1]
                    start_day = interval_start.day
                    if start_day in cutoffs:
                        idx = cutoffs.index(start_day)
                        end_day = cutoffs[idx + 1] - 1
                        interval_end = date(y, m, end_day)
                    else:
                        interval_end = interval_start + timedelta(days=6)
                elif label == "5_years":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)
                # elif label == "max":
                #     # Year-wise intervals from min to max date
                #     start_year = df_all["created_date"].min().year
                #     end_year = df_all["created_date"].max().year

                #     for year in range(start_year, end_year + 1):
                #         year_start = date(year, 1, 1)
                #         year_end = date(year, 12, 31)

                #         # Clip by actual start/end dates if outside selected range
                #         if start_date and year_start < start_date:
                #             year_start = start_date
                #         if end_date and year_end > end_date:
                #             year_end = end_date

                #         df_filtered = df_all[
                #             (df_all["created_date"] >= year_start) &
                #             (df_all["created_date"] <= year_end)
                #         ].copy()

                #         if df_filtered.empty:
                #             continue

                #         # Assign interval end as date for all rows
                #         if label in ["5_years", "max"]:
                #             df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                #         elif label == "1_day":
                #             df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                #         else:
                #             df_filtered["date"] = interval_end.strftime("%Y-%m-%d")

                #         org_records = defaultdict(lambda: defaultdict(lambda: {
                #                 "Inventory": 0,
                #                 "Bulk Change": 0,
                #                 "Customer Rate Plans": 0,
                #                 "Optimization": 0,
                #                 "Reports": 0,
                #                 "Revenue Assurance": 0,
                #                 "Billing Platform": 0,
                #                 "Automation": 0,
                #                 "Carrier Rate Plan": 0,
                #                 "Communication Plans": 0,
                #                 "Customer Groups": 0,
                #                 "Customer Rate Pool": 0,
                #                 "Dashboard": 0,
                #                 "Device Management": 0,
                #                 "LNP": 0,
                #                 "Miscellaneous": 0,
                #                 "NetSapiens": 0,
                #                 "Notifications": 0,
                #                 "Optimization Groups": 0,
                #                 "People": 0,
                #                 "Push Charges": 0,
                #                 "Service Qualification": 0,
                #                 "Settings": 0,
                #                 "Sim Management": 0,
                #                 "Super Admin": 0,
                #                 "Ui Feature": 0,
                #                 "Users": 0,
                #                 "Uncategorized": 0
                #                 }
                #                 ))

                #         for _, row in df_filtered.iterrows():
                #             org_id = row["organization_id"]
                #             org_name = row.get("organization_name", "Unknown Organization")
                #             tag_string = row.get("tag", "")
                #             date_val = row["date"]

                #             if not org_id:
                #                 continue

                #             collected_org_ids.add(org_id)
                #             org_id_to_name[org_id] = org_name

                #             tags = [t.strip() for t in tag_string.split(',') if t]
                #             normalized_tags = [normalize(t) for t in tags]

                #             matched = False
                #             matched_category = next(
                #                 (cat_name for cat_tag, cat_name in NORMALIZED_TAG_TO_CATEGORY.items()
                #                 if any(norm_tag.endswith(cat_tag) for norm_tag in normalized_tags)),
                #                 None
                #             )

                #             if matched_category:
                #                 org_records[org_id][date_val][matched_category] += 1
                #             else:
                #                 org_records[org_id][date_val]["Uncategorized"] += 1


                #         for org_id, date_dict in org_records.items():
                #             formatted_records = [
                #                 {"date": date_key, "category_counts": counts}
                #                 for date_key, counts in date_dict.items()
                #             ]
                #             response["data"]["data"][label].append({
                #                 "organization_id": org_id,
                #                 "records": serialize_data(formatted_records)
                #             })

                #     # Skip general interval processing for "max"
                #     continue  # ensures "max" is processed only in this block
                elif label == "max":
                    interval_end = date(interval_start.year + 2, 1, 1) - timedelta(seconds=1)
                else:
                    interval_end = end

                start_dt = interval_start.date() if isinstance(interval_start, datetime) else interval_start
                end_dt = interval_end.date() if isinstance(interval_end, datetime) else interval_end

                df_filtered = df_all[
                    (df_all["created_date"] >= start_dt) &
                    (df_all["created_date"] <= end_dt)
                ].copy()

                if df_filtered.empty:
                    continue

                if label in ["5_years", "max"]:
                    df_filtered["date"] = df_filtered["created_date"].apply(lambda x: str(x.year))
                elif label == "1_day":
                    # this branch won't run because we handled 1_day above
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    df_filtered["date"] = interval_end.strftime("%Y-%m-%d")

                org_records = defaultdict(lambda: defaultdict(lambda: {
                    # Order matching your module hierarchy
                    "Dashboard": 0,

                    "Sim Management": 0,
                    "Inventory": 0,
                    "Bulk Change": 0,
                    "Customer Rate Plans": 0,
                    "Customer Rate Pool": 0,
                    "Carrier Rate Plan": 0,
                    "Communication Plans": 0,
                    "Optimization Groups": 0,
                    "Revenue Assurance": 0,

                    "Device Management": 0,
                    "Optimization": 0,
                    "Service Qualification": 0,

                    "Reports": 0,
                    "Automation": 0,
                    "NetSapiens": 0,
                    "LNP": 0,
                    "People": 0,

                    # Not present in hierarchy → moved to bottom
                    "Billing Platform": 0,
                    "Customer Groups": 0,
                    "Miscellaneous": 0,
                    "Notifications": 0,
                    "Push Charges": 0,
                    "Settings": 0,
                    "Super Admin": 0,
                    "Ui Feature": 0,
                    "Users": 0,

                    # Always last
                    "Uncategorized": 0
                }))

                for _, row in df_filtered.iterrows():
                    org_id = row["organization_id"]
                    org_name = row.get("organization_name", "Unknown Organization")
                    tag_string = row.get("tag", "")
                    date_val = row.get("date", "")

                    if not org_id:
                        continue

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name

                    tags = [t.strip() for t in tag_string.split(',') if t]
                    normalized_tags = [normalize(t) for t in tags]

                    matched = False
                    matched_category = next(
                        (cat_name for cat_tag, cat_name in NORMALIZED_TAG_TO_CATEGORY.items()
                        if any(norm_tag.endswith(cat_tag) for norm_tag in normalized_tags)),
                        None
                    )

                    if matched_category:
                        org_records[org_id][date_val][matched_category] += 1
                    else:
                        org_records[org_id][date_val]["Uncategorized"] += 1


                for org_id, date_dict in org_records.items():
                    formatted_records = [
                        {"date": date_key, "category_counts": counts}
                        for date_key, counts in date_dict.items()
                    ]
                    response["data"]["data"][label].append({
                        "organization_id": org_id,
                        "records": serialize_data(formatted_records)
                    })

        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        logging.exception(f"[get_ticket_category_distribution] : {exception}")
        response["message"] = f"Error fetching ticket category distribution: {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_category_distribution",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            pass

    return response



def get_ticket_compilance_by_module(data):
    """
    Ticket Compliance by Module

    - Category comes from mapped Zendesk tags (only tags in CATEGORY_MAPPING).
    - If no tag matches CATEGORY_MAPPING, bucket into **Uncategorized** and still count status & ETA.
    - For every Category -> Subcategory -> updated_date, count ticket_status in (open, close, progress).
      "progress" aggregates synonymous statuses like "inprogress".
    - ETA buckets for active statuses only (open, inprogress, new) comparing calculated SLA deadline vs current date:
        * before_eta : deadline < today (overdue)
        * eta        : deadline = today (due today)
        * after_eta  : deadline > today (not due yet)
    - SLA deadline is calculated from the latest SLA entry's time + target duration
    - If business_hours is true: 1 day = 8 hours, only weekdays count
    - Remaining logic mirrors the example function (cache, buckets, org meta, error logging).
    """

    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    start_date_str = data.get("start_date", "")
    end_date_str = data.get("end_date", "")
    organization_id = data.get("tenant_id", "")
    refresh = str(data.get("refresh", "false")).lower() == "true"

    response = {
        "flag": False,
        "meta": {
            "organization_names": {},
            "default_time_range": "",
            "last_sync_time": ""
        },
        "data": {
            "title": "Ticket Compliance by Module",
            "chart_type": "",
            "xField": "",
            "yField": [],
            "smooth": True,
            "height": 300,
            "width": 500,
            "data": {
                "1_day": [], "5_day": [], "1_month": [], "3_month": [], "6_month": [],
                "1_year": [], "5_years": [], "max": [], "custom_range": []
            }
        },
        "message": ""
    }

    CATEGORY_MAPPING = {
        # Top: ordered to match the module hierarchy you provided
        "Dashboard": ["dashboard", "dashboards", "__dashboard", "__dashboards"],

        "Sim Management": ["simmanagement", "simmanagements", "__simmanagement", "__simmanagements"],
        "Inventory": ["inventory"],                       # child of Sim Management / Device Management
        "Bulk Change": ["bulkchange"],
        "Customer Rate Plans": ["customerrateplan", "customerrateplans"],
        "Customer Rate Pool": ["customerratepool", "customerratepools", "__customerratepool", "_customerratepools"],
        "Carrier Rate Plan": ["__carrierrateplan", "__carrierrateplans", "carrierrateplan", "carrierrateplans"],
        "Communication Plans": ["communicationplan", "communicationplans", "__communicationplan", "__communicationplans"],
        "Optimization Groups": ["optimizationgroup", "optimizationgroups", "__optimizationgroup", "__optimizationgroups"],
        "Revenue Assurance": ["revenueassurance"],

        "Device Management": ["devicemanagement", "devicemanagements", "__devicemanagement", "__devicemanagements"],
        "Optimization": ["optimization", "optimization"],
        "Service Qualification": ["servicequalification", "servicequalifications", "__servicequalification", "__servicequalifications"],

        "Reports": ["report", "reports", "__report", "__reports"],
        "Automation": ["automation", "__automation", "__automations"],
        "NetSapiens": ["netsapiens", "__netsapiens"],
        "LNP": ["lnp", "__lnp"],
        "People": ["people", "__people"],

        # Bottom: keys from the original mapping that were NOT found in the hierarchy JSON
        "Billing Platform": ["billingplatform"],
        "Customer Groups": ["customergroup", "customergroups", "__customergroup", "__customergroups"],
        "Miscellaneous": ["miscellaneous", "__miscellaneous"],
        "Notifications": ["notification", "notifications", "__notification", "__notifications"],
        "Push Charges": ["pushcharge", "pushcharges", "__pushcharge", "__pushcharges"],
        "Settings": ["setting", "settings", "__setting", "__settings"],
        "Super Admin": ["superadmin", "superadmins", "__superadmin", "__superadmins"],
        "Ui Feature": ["uifeature", "uifeatures", "__uifeature", "__uifeatures"],
        "Users": ["user", "users", "__user", "__users"],
    }
    SUB_CATEGORY_MAPPING = {
        "Bug": ["bug"],
        "Clarification": ["clarification"],
        "Fast Feature": ["fast_feature"],
        "Spam": ["spam"],
        "Support": ["support"],
    }
    NORMALIZED_TAG_TO_CATEGORY = {
        normalize(tag): cat
        for cat, tag_list in CATEGORY_MAPPING.items()
        for tag in tag_list
    }
    NORMALIZED_TAG_TO_SUB_CATEGORY={
        normalize(tag): cat
        for cat, tag_list in SUB_CATEGORY_MAPPING.items()
        for tag in tag_list
    }

    def make_counts():
        return {"open": 0, "close": 0, "progress": 0,
                "before_eta": 0, "eta": 0, "after_eta": 0}

    def calculate_sla_deadline(sla_data):
        """
        Calculate the SLA deadline from the sla JSON column.
        Returns a date object or None if SLA data is invalid/empty.
        
        Args:
            sla_data: JSON array of SLA entries or None/empty
            
        Returns:
            date object representing the deadline, or None
        """
        if not sla_data:
            return None
            
        try:
            # Parse JSON if it's a string
            if isinstance(sla_data, str):
                sla_list = json.loads(sla_data)
            else:
                sla_list = sla_data
                
            if not sla_list or not isinstance(sla_list, list):
                return None
                
            # Get the latest SLA entry based on 'time' field
            latest_sla = max(sla_list, key=lambda x: x.get('time', ''))
            
            if not latest_sla or 'time' not in latest_sla or 'sla' not in latest_sla:
                return None
                
            sla_time_str = latest_sla['time']
            sla_config = latest_sla['sla']
            
            # Parse the start time
            sla_start = datetime.strptime(sla_time_str, "%Y-%m-%dT%H:%M:%SZ")
            
            # Get target duration in minutes
            target_minutes = sla_config.get('target')
            if target_minutes is None:
                # Fallback to target_in_seconds
                target_seconds = sla_config.get('target_in_seconds')
                if target_seconds is None:
                    return None
                target_minutes = target_seconds / 60
                
            business_hours = sla_config.get('business_hours', False)
            
            # Calculate deadline
            if business_hours:
                # Business hours: 8 hours per day, only weekdays
                remaining_minutes = target_minutes
                current_time = sla_start
                
                while remaining_minutes > 0:
                    # Skip to next business day if weekend
                    while current_time.weekday() >= 5:  # 5=Saturday, 6=Sunday
                        current_time += timedelta(days=1)
                        current_time = current_time.replace(hour=9, minute=0, second=0)
                    
                    # Check if we're in business hours (9 AM - 5 PM)
                    if current_time.hour < 9:
                        current_time = current_time.replace(hour=9, minute=0, second=0)
                    elif current_time.hour >= 17:
                        # Move to next business day
                        current_time += timedelta(days=1)
                        current_time = current_time.replace(hour=9, minute=0, second=0)
                        continue
                    
                    # Calculate minutes available in current business day
                    end_of_business = current_time.replace(hour=17, minute=0, second=0)
                    minutes_until_eob = (end_of_business - current_time).total_seconds() / 60
                    
                    if remaining_minutes <= minutes_until_eob:
                        # Can finish within today's business hours
                        current_time += timedelta(minutes=remaining_minutes)
                        remaining_minutes = 0
                    else:
                        # Need to continue to next business day
                        remaining_minutes -= minutes_until_eob
                        current_time += timedelta(days=1)
                        current_time = current_time.replace(hour=9, minute=0, second=0)
                
                return current_time.date()
            else:
                # Non-business hours: 24/7
                deadline = sla_start + timedelta(minutes=target_minutes)
                return deadline.date()
                
        except Exception as e:
            logging.warning(f"Error calculating SLA deadline: {e}")
            return None

    try:
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        # NEW: Fetch tenant timezone for 1_day bucket
        tenant_time_zone = None
        try:
            tenant_time_zone = fetch_tenant_timezone(database, data)
            logging.info(f"### Tenant timezone: {tenant_time_zone}")
        except Exception as tz_exc:
            logging.warning(f"Failed to fetch tenant timezone: {tz_exc}. Using UTC for 1_day bucket.")
            tenant_time_zone = "UTC"
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date() if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date() if end_date_str else None

        function = "get_ticket_compilance_by_module"
        cache_key = get_cache_key("zendesk_tickets_tracking", function)
        cached_data = None

        # Read from cache
        if not refresh:
            try:
                cached = redis_client.get(cache_key)
                if cached:
                    cached_data = json.loads(cached)
                    ts = redis_client.get(f"{cache_key}:timestamp")
                    if ts:
                        response["meta"]["last_sync_time"] = ts.decode() if hasattr(ts, "decode") else str(ts)
                    logging.info(f"[Cache Hit] {cache_key}")
            except Exception as e:
                logging.warning(f"[Redis Get Error] {e}")

        # Fetch from DB if no cache or refresh requested
        if refresh or cached_data is None:
            raw_query = """
            SELECT 
                organization_id,
                organization_name,
                updated_date,
                ticket_status,
                sla,
                '{' ||
                array_to_string(
                    ARRAY(
                        SELECT '"' || jsonb_array_elements_text(interaction_history) || '"'
                    ), 
                    ', '
                ) || '}' AS tag
            FROM zendesk_tickets_tracking
            WHERE updated_date IS NOT NULL;
            """
            df = database.execute_query(raw_query, flag=True)
            df = df if isinstance(df, pd.DataFrame) else pd.DataFrame()

            if not df.empty:
                # ✅ Keep full datetime (tz-aware) & also store date-only for other buckets
                df["updated_datetime"] = pd.to_datetime(df["updated_date"], errors="coerce", utc=True)
                df["updated_date"] = df["updated_datetime"].dt.date

                cached_data = df.to_dict(orient="records")
                try:
                    redis_client.setex(cache_key, 9000, json.dumps(cached_data, default=str))
                    ts_now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
                    # redis_client.set(f"{cache_key}:timestamp", ts_now)
                    response["meta"]["last_sync_time"] = ts_now
                except Exception as e:
                    logging.warning(f"[Redis Set Error] {e}")

                # Audit cache refresh
                try:
                    audit_data = {
                        "function_name": function,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Audit logging failed: {audit_exc}")
            else:
                cached_data = []

        # Build DF from cache/DB
        df_all = pd.DataFrame(cached_data)
        if df_all.empty:
            return response

        # Ensure we have a tz-aware datetime column and a date-only column
        if "updated_datetime" in df_all.columns:
            # If stored as strings, convert to tz-aware Timestamps
            try:
                df_all["updated_datetime"] = pd.to_datetime(df_all["updated_datetime"], utc=True)
            except Exception:
                df_all["updated_datetime"] = pd.to_datetime(df_all["updated_datetime"], errors="coerce", utc=True)
        else:
            df_all["updated_datetime"] = pd.to_datetime(df_all.get("updated_date", None), errors="coerce", utc=True)

        # Date-only column for other buckets (safe even if updated_datetime missing time)
        df_all["updated_date"] = df_all["updated_datetime"].dt.date

        logging.info("Requested range:", start_date, "to", end_date)
        logging.info("Available range:", df_all["updated_date"].min(), "to", df_all["updated_date"].max())

        # Organization filter
        if organization_id and organization_id != "All":
            df_all = df_all[df_all["organization_id"] == str(organization_id)]

        # Date filter (date-only)
        if start_date and end_date:
            df_all = df_all[
                (df_all["updated_date"] >= start_date) &
                (df_all["updated_date"] <= end_date)
            ]
            if df_all.empty:
                response["message"] = "No data available for the selected date range."
                response["flag"] = True
                return response

        # Compute buckets
        min_date = df_all["updated_date"].min() if not (start_date and end_date) else None
        time_buckets, default_label = execute_all_time_buckets(tenant_time_zone,start_date, end_date, min_date, column="updated_date")
        response["meta"]["default_time_range"] = default_label

        collected_org_ids = set()
        org_id_to_name = {}
        today = datetime.utcnow().date()

        # Helper: normalize status labels to our buckets
        def normalize_status(s: str) -> str:
            s = (s or "").strip().lower()
            if s in {"closed", "close", "solved", "resolved"}:
                return "close"
            if s in {"inprogress", "in_progress", "in progress", "pending"}:
                return "progress"  # aggregate progress-like states
            if s in {"open", "new"}:
                return "open"
            return s

        # ---------- INLINE 1_day handling using explicit pd.date_range 4-hour edges ----------
        if any(b["label"] == "1_day" for b in time_buckets):
            bucket = next(b for b in time_buckets if b["label"] == "1_day")
            b_start = bucket["start"]
            b_end = bucket["end"]

            # Build timezone-aware timestamps in UTC (to match updated_datetime)
            bucket_start_dt = datetime.combine(b_start, datetime.min.time())
            bucket_end_dt = datetime.combine(b_end, datetime.max.time())

            bucket_start_ts = pd.Timestamp(bucket_start_dt).tz_localize("UTC")
            bucket_end_ts = pd.Timestamp(bucket_end_dt).tz_localize("UTC")

            floored_start = bucket_start_ts.floor("4h")
            ceiled_end = bucket_end_ts.ceil("4h")

            edges = pd.date_range(start=floored_start, end=ceiled_end, freq="4h", tz="UTC")

            for i in range(len(edges) - 1):
                interval_start_ts = edges[i]
                interval_end_ts = edges[i + 1] - pd.Timedelta(seconds=1)

                # Filter rows for this 4-hour window using tz-aware updated_datetime
                df_filtered = df_all[
                    (df_all["updated_datetime"] >= interval_start_ts) &
                    (df_all["updated_datetime"] <= interval_end_ts)
                ].copy()

                if df_filtered.empty:
                    continue

                org_records = defaultdict(
                    lambda: defaultdict(
                        lambda: defaultdict(
                            lambda: defaultdict(make_counts)
                        )
                    )
                )

                for _, row in df_filtered.iterrows():
                    org_id = row.get("organization_id")
                    if not org_id:
                        continue

                    org_name = row.get("organization_name", "Unknown Organization")
                    tag_string = row.get("tag", "")
                    # Extract individual tags
                    tags = [t.strip().replace('"','') for t in str(row.get("tag", "")).strip('{}').split(',') if t]

                    # Map first matching tag to subcategory
                    subcategory = "Uncategorized Subcategory"
                    for t in tags:
                        nt = normalize(t)
                        if nt in NORMALIZED_TAG_TO_SUB_CATEGORY:
                            subcategory = NORMALIZED_TAG_TO_SUB_CATEGORY[nt]
                            break

                    
                    status_raw = str(row.get("ticket_status", ""))
                    sla_data = row.get("sla", None)
                    # Use the interval_end as date_key (string), consistent with your other 1_day presentation
                    date_key = str(interval_end_ts)

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name

                    # Category mapping
                    
                    tags = [t.strip() for t in str(tag_string).split(',') if t]
                    cat = None
                    for t in tags:
                        nt = normalize(t)
                        # Check if any category key exists in the tag (prefix ignored)
                        for key, value in NORMALIZED_TAG_TO_CATEGORY.items():
                            if nt.endswith(key):   # <-- suffix match for your case
                                cat = value
                                break
                        if cat:
                            break

                    if not cat:
                        cat = "Uncategorized"


                    status = normalize_status(status_raw)
                    counts = org_records[org_id][cat][subcategory][date_key]

                    if status in {"open", "close", "progress"}:
                        counts[status] += 1

                    # ETA logic for active statuses using SLA
                    if status_raw.strip().lower() in {"open", "inprogress", "in_progress", "in progress", "new"}:
                        sla_deadline = calculate_sla_deadline(sla_data)
                        if sla_deadline:
                           
                            try:
                                if sla_deadline < today:
                                    counts["before_eta"] += 1
                                elif sla_deadline == today:
                                    counts["eta"] += 1
                                else:
                                    counts["after_eta"] += 1
                            except Exception:
                                pass

                # Append per-org records for this interval
                for org_id, rec in org_records.items():
                    response["data"]["data"]["1_day"].append({
                        "organization_id": org_id,
                        "records": rec
                    })

            # Remove 1_day bucket from further processing
            time_buckets = [b for b in time_buckets if b["label"] != "1_day"]
        # ---------- END INLINE 1_day handling ----------

        # Core processing per bucket (remaining labels)
        for bucket in time_buckets:
            start, end, label = bucket["start"], bucket["end"], bucket["label"]

            # Special processing for MAX -> per-year rollups
            if label in ["max", "5_years"]:
                start_year = df_all["updated_date"].min().year
                end_year = df_all["updated_date"].max().year

                for year in range(start_year, end_year + 1):
                    year_start = date(year, 1, 1)
                    year_end = date(year, 12, 31)

                    if start_date and year_start < start_date:
                        year_start = start_date
                    if end_date and year_end > end_date:
                        year_end = end_date

                    df_filtered = df_all[
                        (df_all["updated_date"] >= year_start) &
                        (df_all["updated_date"] <= year_end)
                    ].copy()

                    if df_filtered.empty:
                        continue

                    df_filtered["date"] = str(year_end.year)

                    org_records = defaultdict(
                        lambda: defaultdict(
                            lambda: defaultdict(
                                lambda: defaultdict(make_counts)
                            )
                        )
                    )

                    for _, row in df_filtered.iterrows():
                        org_id = row.get("organization_id")
                        if not org_id:
                            continue

                        org_name = row.get("organization_name", "Unknown Organization")
                        tag_string = row.get("tag", "")
                        # Extract individual tags
                        tags = [t.strip().replace('"','') for t in str(row.get("tag", "")).strip('{}').split(',') if t]

                        # Map first matching tag to subcategory
                        subcategory = "Uncategorized Subcategory"
                        for t in tags:
                            nt = normalize(t)
                            if nt in NORMALIZED_TAG_TO_SUB_CATEGORY:
                                subcategory = NORMALIZED_TAG_TO_SUB_CATEGORY[nt]
                                break

                        status_raw = str(row.get("ticket_status", ""))
                        sla_data = row.get("sla", None)
                        date_key = row.get("date", "")

                        collected_org_ids.add(org_id)
                        org_id_to_name[org_id] = org_name

                        # Category mapping
                        tags = [t.strip() for t in str(tag_string).split(',') if t]
                        cat = None
                        for t in tags:
                            nt = normalize(t)
                            # Check if any category key exists in the tag (prefix ignored)
                            for key, value in NORMALIZED_TAG_TO_CATEGORY.items():
                                if nt.endswith(key):   # <-- suffix match for your case
                                    cat = value
                                    break
                            if cat:
                                break

                        if not cat:
                            cat = "Uncategorized"

                        status = normalize_status(status_raw)
                        counts = org_records[org_id][cat][subcategory][date_key]

                        if status in {"open", "close", "progress"}:
                            counts[status] += 1

                        if status_raw.strip().lower() in {"open", "inprogress", "in_progress", "in progress", "new"}:
                            sla_deadline = calculate_sla_deadline(sla_data)
                            if sla_deadline:
                                try:
                                    if sla_deadline < today:
                                        counts["before_eta"] += 1
                                    elif sla_deadline == today:
                                        counts["eta"] += 1
                                    else:
                                        counts["after_eta"] += 1
                                except Exception:
                                    pass

                    for org_id, rec in org_records.items():
                        response["data"]["data"][label].append({
                            "organization_id": org_id,
                            "records": rec
                        })
                continue

            # Build intervals for non-MAX
            intervals = generate_intervals_for_label(label, start, end)

            for interval_start in intervals:
                if label == "5_day":
                    interval_end = interval_start + timedelta(days=1) - timedelta(seconds=1)
                elif label in ["1_month", "3_month", "6_month", "1_year"]:
                    y, m = interval_start.year, interval_start.month
                    days_in_month = monthrange(y, m)[1]
                    cutoffs = [1, 8, 15, 22, days_in_month + 1]
                    start_day = interval_start.day
                    if start_day in cutoffs:
                        idx = cutoffs.index(start_day)
                        end_day = cutoffs[idx + 1] - 1
                        interval_end = date(y, m, end_day)
                    else:
                        interval_end = interval_start + timedelta(days=6)
                elif label == "5_years":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)
                elif label == "max":
                    interval_end = date(interval_start.year + 1, 1, 1) - timedelta(seconds=1)
                else:
                    interval_end = end

                start_dt = interval_start.date() if isinstance(interval_start, datetime) else interval_start
                end_dt = interval_end.date() if isinstance(interval_end, datetime) else interval_end

                df_filtered = df_all[
                    (df_all["updated_date"] >= start_dt) &
                    (df_all["updated_date"] <= end_dt)
                ].copy()

                if df_filtered.empty:
                    continue

                if label == "5_years":
                    df_filtered["date"] = str(end_dt.year)
                else:
                    df_filtered["date"] = df_filtered["updated_date"].astype(str)

                org_records = defaultdict(
                    lambda: defaultdict(
                        lambda: defaultdict(
                            lambda: defaultdict(make_counts)
                        )
                    )
                )

                for _, row in df_filtered.iterrows():
                    org_id = row.get("organization_id")
                    if not org_id:
                        continue

                    org_name = row.get("organization_name", "Unknown Organization")
                    tag_string = row.get("tag", "")
                    # Extract individual tags
                    tags = [t.strip().replace('"','') for t in str(row.get("tag", "")).strip('{}').split(',') if t]

                    # Map first matching tag to subcategory
                    subcategory = "Uncategorized Subcategory"
                    for t in tags:
                        nt = normalize(t)
                        if nt in NORMALIZED_TAG_TO_SUB_CATEGORY:
                            subcategory = NORMALIZED_TAG_TO_SUB_CATEGORY[nt]
                            break

                    status_raw = str(row.get("ticket_status", ""))
                    sla_data = row.get("sla", None)
                    date_key = row.get("date", "")

                    collected_org_ids.add(org_id)
                    org_id_to_name[org_id] = org_name

                    tags = [t.strip() for t in str(tag_string).split(',') if t]
                    cat = None
                    for t in tags:
                        nt = normalize(t)
                        # Check if any category key exists in the tag (prefix ignored)
                        for key, value in NORMALIZED_TAG_TO_CATEGORY.items():
                            if nt.endswith(key):   # <-- suffix match for your case
                                cat = value
                                break
                        if cat:
                            break

                    if not cat:
                        cat = "Uncategorized"

                    status = normalize_status(status_raw)
                    counts = org_records[org_id][cat][subcategory][date_key]

                    if status in {"open", "close", "progress"}:
                        counts[status] += 1

                    if status_raw.strip().lower() in {"open", "inprogress", "in_progress", "in progress", "new"}:
                        sla_deadline = calculate_sla_deadline(sla_data)
                        if sla_deadline:
                            try:
                                if sla_deadline < today:
                                    counts["before_eta"] += 1
                                elif sla_deadline == today:
                                    counts["eta"] += 1
                                else:
                                    counts["after_eta"] += 1
                            except Exception:
                                pass

                for org_id, rec in org_records.items():
                    response["data"]["data"][label].append({
                        "organization_id": org_id,
                        "records": rec
                    })

        if collected_org_ids:
            response["meta"]["organization_names"] = {
                str(org_id): org_id_to_name.get(org_id, "Unknown Organization") for org_id in collected_org_ids
            }
            response["flag"] = True

    except Exception as exception:
        logging.exception("[get_ticket_compilance_by_module]")
        response["message"] = f"Error fetching ticket compliance by module: {exception}"
        response["flag"] = False
        try:
            error_data = {
                "service_name": "get_ticket_compilance_by_module",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": str(exception),
                "module_name": "Dashboard",
                "request_received_at": request_received_at,
                "session_id": sessionID,
            }
            if 'database' in locals():
                database.log_error_to_db(error_data, "error_log_table")
        except Exception:
            pass

    return response


def sync_sla_from_zendesk(data):
    """
    Fire-and-forget: hit the EC2/ECS container endpoint for SLA sync and return immediately.
    No response is read or waited for.

    Returns:
        (success: bool, response: dict)
    """
    response = {"flag": False, "message": "", "details": None}

    try:
        username = data.get("username", "")
        tenant_name = data.get("tenant_name", "")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        start_time = time.time()

        # Build target URL
        container_name = "Dashboard"
        ec2_host = os.environ.get("EC2_HOST", "34.204.218.6")
        port = os.environ.get("eEC2_PORT", "5001")
        url = f"http://{ec2_host}:{port}/{container_name}_Handler"

        # Add the path for SLA batch sync
        data["path"] = "/fetch_and_store_sla_batch"

        logging.info(f"[sync_sla_from_zendesk] Fire-and-forget request to: {url}")
        logging.info(f"[sync_sla_from_zendesk] Payload keys: {list(data.keys())}")

        # --- Fire-and-forget request ---
        try:
            requests.post(url, json=data, timeout=0.1)  # 100ms timeout, don't wait for response
        except requests.exceptions.ReadTimeout:
            # This is expected for fire-and-forget, so just log and ignore
            logging.info("[sync_sla_from_zendesk] Request sent (timeout reached - ignoring response).")
        except Exception as e:
            logging.warning(f"[sync_sla_from_zendesk] Fire-and-forget POST may have failed: {e}")

        # --- Audit success ---
        try:
            time_consumed = int(float(f"{time.time() - start_time:.4f}"))
            audit_data = {
                "service_name": "sla_sync",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Forwarded - Fire and forget (no response expected)",
                "tenant_name": tenant_name,
                "module_name": "SLA Sync",
                "comments": f"SLA sync request sent to container: {container_name}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"[sync_sla_from_zendesk] Audit insert failed: {e}")

        # Return immediately
        response["flag"] = True
        response["message"] = "SLA sync request forwarded (fire-and-forget)"
        response["details"] = {"endpoint": url}
        return response

    except Exception as e:
        logging.exception(f"[sync_sla_from_zendesk] Failed to forward request: {e}")
        response["flag"] = False
        response["message"] = "Failed to forward SLA sync request"
        response["details"] = str(e)
        try:
            common_utils_database.log_error_to_db({
                "service_name": "sla_sync",
                "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": data.get("username"),
                "tenant_name": data.get("tenant_name"),
                "comments": "Error while sending fire-and-forget SLA sync request",
                "module_name": "SLA Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }, "error_log_table")
        except Exception as ee:
            logging.exception(f"[sync_sla_from_zendesk] Failed to log error to DB: {ee}")
        return response



########################## zendesk Tab ####################

############ Cache Ui Refresh #############
 
def refresh_dashboard_all_caches(data):
    """
    Triggers cache refresh for different sets of functions based on tab_name:
    - sim_overiew
    - revenue_metrics
    - zendesk
    """

    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id", "All")
    username = data.get("username", "")
    sessionID = data.get("sessionID", "")
    tab_name = data.get("tab_name", "").lower().strip()
    request_received_at = data.get("request_received_at", "")
    response = {
        "flag": True,
        "message": f"Cache refresh initiated for {tab_name or 'all'} functions",
        "results": {},
        "meta": {
            "tenant_name": tenant_name,
            "tenant_id": tenant_id,
            "tab_name": tab_name,
            "request_received_at": str(request_received_at)
        }
    }

    # Mapping of tab_name to its respective functions
    tab_functions_map = {
        "sim_overiew": [
            ("get_service_provider_vs_status", get_service_provider_vs_status),
            ("get_sim_activations_by_service_provider", get_sim_activations_by_service_provider),
            ("get_sim_count_by_service_provider", get_sim_count_by_service_provider),
            ("count_of_sim_overview", count_of_sim_overview)
        ],
        "revenue_metrics": [
            ("get_revenue_metrics_cards", get_revenue_metrics_cards),
            ("get_revenue_by_carrier", get_revenue_by_carrier),
            ("get_revenue_by_rate_plan", get_revenue_by_rate_plan),
            ("get_profit_margin_trend", get_profit_margin_trend),
            ("get_revenue_by_usage_trend", get_revenue_by_usage_trend)
        ],
        "zendesk": [
            ("get_status_count_of_tickets", get_status_count_of_tickets),
            ("get_ticket_status_distribution", get_ticket_status_distribution),
            ("get_ticket_category_distribution", get_ticket_category_distribution),
            ("get_ticket_severity_overview", get_ticket_severity_overview),
            ("get_ticket_compilance_by_module", get_ticket_compilance_by_module)
        ]
    }

    if tab_name not in tab_functions_map:
        response["flag"] = False
        response["message"] = f"Invalid tab_name: {tab_name}"
        return response

    functions_to_refresh = tab_functions_map[tab_name]

    try:
        common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
    except Exception as db_exc:
        logging.exception(f"Failed to connect to common_utils_database in refresh_all_caches : {db_exc}")
        response["flag"] = False
        response["message"] = f"Database connection error: {db_exc}"
        return response

    for function_name, function in functions_to_refresh:
        try:
            data_with_refresh = data.copy()
            data_with_refresh["refresh"] = "True"

            result = function(data_with_refresh)

            # always use refresh_{tab_name}_caches for dashboard_cache_audit
            cache_func_name = f"refresh_{tab_name}_caches"

            if result.get("flag", False):
                last_sync_time = datetime.utcnow()
                response["results"][function_name] = {
                    "status": "Success",
                    "last_sync_date": last_sync_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "message": f"Cache refreshed successfully for {function_name}"
                }

                
                try:
                    audit_data = {
                        "function_name": cache_func_name,
                        "created_by": username,
                        "last_synced_by": username,
                    }
                    common_utils_database.update_audit(audit_data, "dashboard_cache_audit")
                except Exception as audit_exc:
                    logging.warning(f"Dashboard cache audit insert failed for {function_name}: {audit_exc}")

            else:
                response["results"][function_name] = {
                    "status": "Failed",
                    "last_sync_date": None,
                    "message": result.get("message", f"Failed to refresh cache for {function_name}")
                }
                response["flag"] = False
                response["message"] = "One or more cache refreshes failed"

                
                    

            # Audit logging — user actions (separate table)
            try:
                audit_data = {
                    "service_name": f"refresh_{tab_name}_caches",
                    "function_name": function_name,
                    "created_by": username,
                    "status": response["results"][function_name]["status"],
                    "tenant_name": tenant_name,
                    "comments": f"Cache refresh attempt for {function_name} in tab {tab_name} with {data_with_refresh}",
                    "module_name": tab_name.capitalize(),
                    "request_received_at": str(request_received_at),
                    "session_id": sessionID,
                }
                common_utils_database.update_audit(audit_data, "audit_user_actions")
            except Exception as audit_exc:
                logging.warning(f"Audit logging failed for {function_name}: {audit_exc}")

        except Exception as func_exc:
            logging.exception(f"Error refreshing cache for {function_name}: {func_exc}")
            response["results"][function_name] = {
                "status": "Failed",
                "last_sync_date": None,
                "message": f"Error refreshing cache for {function_name}: {func_exc}"
            }
            response["flag"] = False
            response["message"] = "One or more cache refreshes failed"


            # Log error into error_log_table
            try:
                error_data = {
                    "service_name": f"refresh_{tab_name}_caches",
                    "error_message": str(func_exc),
                    "error_type": type(func_exc).__name__,
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": f"Error during cache refresh for {function_name} in tab {tab_name}",
                    "module_name": tab_name.capitalize(),
                    "request_received_at": str(request_received_at),
                    "session_id": sessionID,
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
            except Exception as log_exc:
                logging.warning(f"Error logging failed for {function_name}: {log_exc}")

    return response

import pytz  # make sure this is imported

def get_dashboard_last_sync_time(data):

    max_diff_seconds = 60
    """
    Retrieves the latest last_sync_date for the functions in a given tab_name 
    from dashboard_cache_audit, converts it to tenant's local timezone, 
    and returns:
        {
            "last_sync_date": <most recent timestamp in tenant time>,
            "recent_sync_date": <same value if within 1 min, else None>
        }
    """

    tab_name = data.get("tab_name", "").lower().strip()
    tab_name = f"refresh_{tab_name}_caches"

    try:
        common_utils_database = DB("common_utils", **common_utils_database_config)

        #  Fetch tenant timezone
        tenant_timezone = fetch_tenant_timezone(common_utils_database, data)

        #  Query for the latest sync date
        query = """
            SELECT function_name, last_sync_date
            FROM dashboard_cache_audit
            WHERE function_name = %s and last_sync_date is not null
            ORDER BY last_sync_date DESC 
            LIMIT 1
        """
        df = common_utils_database.execute_query(query, params=[tab_name])

        if not isinstance(df, pd.DataFrame) or df.empty:
            return {"last_sync_date": None, "recent_sync_date": None}

        #  Convert timestamps from UTC to tenant's timezone
        converted_records = convert_timestamp_data(
            df.to_dict(orient="records"), tenant_timezone, timestamp_columns=["last_sync_date"]
        )

        last_sync_date_str = converted_records[0]["last_sync_date"]

        # check if within allowed threshold
        try:
            tz = pytz.timezone(tenant_timezone)  # FIX: use pytz instead of datetime.timezone
            now_local = datetime.now(tz)

            record_dt = datetime.strptime(last_sync_date_str, "%m-%d-%Y %I:%M:%S %p")
            record_dt = tz.localize(record_dt)  # localize record datetime

            time_diff = abs((now_local - record_dt).total_seconds())
            recent_sync_date = last_sync_date_str if time_diff <= max_diff_seconds else None
        except Exception as e:
            logging.warning(f"Error parsing last_sync_date {last_sync_date_str}: {e}")
            recent_sync_date = None

        return {
            "flag": True,
            "message": "Success",
            "last_sync_date": last_sync_date_str,
            "recent_sync_date": recent_sync_date
        }

    except Exception as e:
        logging.exception(f"Error while fetching last sync time for tab '{tab_name}': {e}")
        
        return {
            "flag": False,
            "message": "Error fetching last sync time",
            "last_sync_date": None,
            "recent_sync_date": None
        }


############ Cache Ui Refresh #############

############ User Role ###########

def escape_sql(value):
    """Escape single quotes for safe f-string SQL usage"""
    if value is None:
        return ""
    return str(value).replace("'", "''")

def get_update_module_features(data):
    """
    Get or update module features for a user based on username, role, or default module features.
    """

    username = escape_sql(data.get("username", ""))
    sessionID = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    role_name = escape_sql(data.get("role_name", ""))
    action = data.get("action")
    selected_features = data.get("selected_features", [])

    response = {
        "flag": True,
        "message": "Success",
        "module_features": [],
        "selected_features": []
    }

    try:
        common_utils_database = DB("common_utils", **common_utils_database_config)
    except Exception as db_exc:
        logging.info(f"Failed to connect to common_utils_database in get_update_module_features : {db_exc}")
        response["flag"] = False
        response["message"] = f"Database connection error: {db_exc}"
        return response

    try:
        # Step 1: Get current tenant's ID and parent_tenant_id
        query = f"""SELECT id, parent_tenant_id FROM tenant WHERE tenant_name = '{tenant_name}' and is_active = true"""
        tenant_data = common_utils_database.execute_query(query, True)

        if tenant_data.empty:
            return {}

        tenant_id = tenant_data["id"].iloc[0]

        # Override ID for Altaworx Test
        if tenant_name == "Altaworx Test":
            tenant_id = 1  # Override with specific ID

        # If action is update and selected_features is provided, update the user's dashboard_dynamic_cols
        if action == "update" and selected_features:
            try:
                selected_features_json = json.dumps(selected_features) if isinstance(
                    selected_features, (list, dict)) else str(selected_features)
                selected_features_json = escape_sql(selected_features_json)

                # Prepare the data
                update_query = {
                    "dashboard_dynamic_cols": json.dumps(selected_features)
                }

                # Update by username
                common_utils_database.update_dict(
                    "users",
                    update_query,
                    {"username": username}
                )
                response["message"] = "Selected features updated successfully"

            except Exception as update_exc:
                logging.info(f"Error updating selected features for user {username}: {update_exc}")
                response["flag"] = False
                response["message"] = f"Error updating selected features: {update_exc}"
                return response

        # ----------------------------
        # Get module_features
        # ----------------------------
        module_features_data = None

        # Step 1: Only if role is NOT super admin, check user_module_tenant_mapping
        if role_name.lower() != "super admin":
            user_module_query = f"""
                SELECT module_features 
                FROM user_module_tenant_mapping 
                WHERE user_name = '{username}'
                AND tenant_id = '{tenant_id}'
            """
            user_module_result_df = common_utils_database.execute_query(user_module_query, True)
            user_module_result = user_module_result_df["module_features"].to_list() if not user_module_result_df.empty else []

            if user_module_result:
                module_features_data = user_module_result[0]

        # Step 2: If still empty, check role_module
        if not module_features_data:
            role_module_query = f"""
                SELECT module_features 
                FROM role_module 
                WHERE role = '{role_name}'
            """
            role_module_result_df = common_utils_database.execute_query(role_module_query, True)
            role_module_result = role_module_result_df["module_features"].to_list() if not role_module_result_df.empty else []

            if role_module_result:
                module_features_data = role_module_result[0]
            else:
                # Step 3: If still empty, fallback to module_features table
                default_features_query = """
                    SELECT features 
                    FROM module_features 
                    WHERE module = 'Dashboard' AND parent_module_name = 'Dashboard'
                """
                default_features_result_df = common_utils_database.execute_query(default_features_query, True)
                default_features_result = default_features_result_df["features"].to_list() if not default_features_result_df.empty else []

                if default_features_result:
                    default_features = default_features_result[0]
                    module_features_data = {"Dashboard": {"Dashboard": default_features}}

        # Parse module_features_data and extract Dashboard features
        if module_features_data:
            if isinstance(module_features_data, str):
                try:
                    module_features_data = json.loads(module_features_data)
                except Exception:
                    pass  # not JSON, leave as-is

            dashboard_features = []
            if (
                isinstance(module_features_data, dict)
                and "Dashboard" in module_features_data
                and "Dashboard" in module_features_data["Dashboard"]
            ):
                dashboard_features = module_features_data["Dashboard"]["Dashboard"]

            processed_features = []
            for feature in dashboard_features:
                if "-" in feature:
                    feature_name, tab_name = feature.rsplit("-", 1)
                    processed_features.append({"name": feature_name, "tab": tab_name})

            response["module_features"] = processed_features

        # ----------------------------
        # Get selected_features from users table
        # ----------------------------
        selected_features_query = f"""
            SELECT dashboard_dynamic_cols 
            FROM users 
            WHERE username = '{username}'
        """
        selected_result_df = common_utils_database.execute_query(selected_features_query, True)
        selected_result = selected_result_df["dashboard_dynamic_cols"].to_list() if not selected_result_df.empty else []

        if selected_result:
            selected_data = selected_result[0]
            if isinstance(selected_data, str):
                try:
                    selected_data = json.loads(selected_data)
                except Exception:
                    pass  # leave as-is if not JSON

            processed_selected = []
            if isinstance(selected_data, list):
                for feature in selected_data:
                    if isinstance(feature, str) and "-" in feature:
                        feature_name, tab_name = feature.rsplit("-", 1)
                        processed_selected.append({"name": feature_name, "tab": tab_name})
                    elif isinstance(feature, dict):
                        processed_selected.append(feature)

            response["selected_features"] = processed_selected

        # ----------------------------
        # Audit logging
        # ----------------------------
        try:
            audit_data = {
                "service_name": "get_update_module_features",
                "created_by": username,
                "status": "True",
                "tenant_name": tenant_name,
                "comments": f"Action: {action}",
                "module_name": "Dashboard",
                "request_received_at": str(request_received_at),
                "session_id": sessionID,
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

    except Exception as func_exc:
        logging.info(f"Error in get_update_module_features: {func_exc}")
        response["flag"] = False
        response["message"] = f"Error processing request: {func_exc}"

        try:
            error_data = {
                "service_name": "get_update_module_features",
                "error_message": str(func_exc),
                "error_type": type(func_exc).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error in get_update_module_features function",
                "module_name": "Dashboard",
                "request_received_at": str(request_received_at),
                "session_id": sessionID,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging failed: {log_exc}")

    finally:
        try:
            common_utils_database.close()
        except:
            pass

    return response


############ User Role ###########



################# billing sync ######################
from calendar import monthrange
import os
from dotenv import load_dotenv
import psycopg2


def run_populate_revenue_metrics(data):
    """
    Executes populate_revenue_metrics() and audits the count into audit_user_actions.
    Explicitly reads the 'populate_revenue_metrics' column if present and uses that value as count.
    Returns a response dict.
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    
    try:
        logging.info(f"Running run_populate_revenue_metrics {data} ")
        tenant_database = data.get("db_name", "")
        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")
        load_dotenv()
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))
        logging.info(f"db details {hostname}, {port},{user},{password},{port} types are {type(hostname)} {type(port)},{type(user)},{type(password)}")

        mode = os.environ.get('ENV','')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        # killbill_database = DB('altaworx_central_billing_platform_beta', **common_utils_database_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        try:

            b_conn = psycopg2.connect(
                dbname=os.environ["BILLING_PLATFORM"],
                user=user,
                password=password,
                host=hostname,
                port=port
            )
            # b_conn = create_connection(db_type, hostname, killbill_database, user, password, port)
        except Exception as e:
            logging.info(f"ERROR b_conn {e}")
        logging.info(f"create connection b_conn {b_conn}")

        # Query (adjust qualification if you prefer public.<fn>() or tenant-qualified)
        query = "SELECT * FROM populate_revenue_metrics()"
        cursor = b_conn.cursor()
        cursor.execute(query)
        result = cursor.fetchone()[0]
        logging.info(f"Rows inserted b_conn: {result}")
        b_conn.commit()
        # if b_conn.notices:
        # logging.info("Postgres notices:")
        # for notice in b_conn.notices:
        #     logging.info(notice.strip())

        cursor.close()
        b_conn.close()
        # result = killbill_database.execute_query(query, True)
        # logging.info(f"raw result repr query {repr(result)}")

        # --- Extract the numeric count reliably ---
        count = 0
        try:
            

            if pd is not None and isinstance(result, pd.DataFrame):
                # If DataFrame has the expected column, use it
                col_name = "populate_revenue_metrics"
                if col_name in result.columns and not result.empty:
                    try:
                        # take first row value from that column
                        count = int(result[col_name].iat[0])
                    except Exception as e_col:
                        logging.info(f"[populate_revenue_metrics] failed to parse column '{col_name}': {e_col}")
                        # fallback to first cell
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e_fallback:
                            logging.info("[populate_revenue_metrics] fallback parse failed:", e_fallback)
                            count = 0
                else:
                    # column not present — fallback to first column or first cell if available
                    if not result.empty:
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics] unable to parse DataFrame first cell:", e)
                            count = 0
                    else:
                        count = 0

            elif isinstance(result, (list, tuple)):
                # e.g. result might be [(67,)] or [[67]] or [67]
                if len(result) == 0:
                    count = 0
                else:
                    first = result[0]
                    if isinstance(first, (list, tuple)) and len(first) > 0:
                        try:
                            count = int(first[0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics] parse list-of-rows failed:", e)
                            count = 0
                    else:
                        try:
                            count = int(first)
                        except Exception as e:
                            logging.info("[populate_revenue_metrics] parse scalar in list failed:", e)
                            count = 0

            elif result is None:
                count = 0

            else:
                # Scalar-like fallback
                try:
                    count = int(result)
                except Exception:
                    logging.info("[populate_revenue_metrics] unknown result shape, can't parse to int. repr:", repr(result))
                    count = 0

        except Exception as parse_exc:
            logging.info("[populate_revenue_metrics] parse error:", parse_exc)
            count = 0

        
        # Step 2: Audit log
        try:
            audit_data = {
                "service_name": "populate_revenue_metrics",
                "created_by": username,
                "status": "Success" if count > 0 else "No Rows",
                "comments": f"populate_revenue_metrics inserted/updated {count} rows.",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            # keep running even if audit fails
            logging.info(f"[populate_revenue_metrics] Audit logging failed: {audit_exc}")

        # Build response
        response["flag"] = True
        response["inserted_count"] = count
        response["message"] = f"populate_revenue_metrics executed successfully, rows={count}"

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error executing populate_revenue_metrics: {exception}"

        # Step 3: Error log
        try:
            error_data = {
                "service_name": "populate_revenue_metrics",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "comments": str(exception),
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if "common_utils_database" in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"[populate_revenue_metrics] Error logging to DB: {log_exc}")

    return response


def run_populate_revenue_metrics_diff(data):
    """
    Executes populate_revenue_metrics_diff() and audits the count into audit_user_actions.
    Robustly extracts the numeric count from various shapes returned by execute_query.
    Returns a response dict.
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    try:
        

        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")
        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())

        load_dotenv()
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))
       
        logging.info(f"db details {hostname}, {port},{user},{password},{port} types are {type(hostname)} {type(port)},{type(user)},{type(password)}")
        mode = os.environ.get('ENV','')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        # killbill_database = DB('altaworx_central_billing_platform_beta', **common_utils_database_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        try:

            b_conn = psycopg2.connect(
                dbname=os.environ["BILLING_PLATFORM"],
                user=user,
                password=password,
                host=hostname,
                port=port
            )
            # b_conn = create_connection(db_type, hostname, killbill_database, user, password, port)
        except Exception as e:
            logging.info(f"ERROR b_conn {e}")
        logging.info(f"create connection b_conn {b_conn}")

        # Query (adjust qualification if you prefer public.<fn>() or tenant-qualified)
        query = "SELECT * from  populate_revenue_metrics_diff()"
        cursor = b_conn.cursor()
        cursor.execute(query)
        result = cursor.fetchone()[0]
        logging.info(f"Rows inserted b_conn: {result}")
        b_conn.commit()
        # if b_conn.notices:
        # logging.info("Postgres notices:")
        # for notice in b_conn.notices:
        #     logging.info(notice.strip())

        cursor.close()
        b_conn.close()

       

          

        # debug logging.info (remove or replace with logger if desired)
        logging.info("populate_revenue_metrics_diff raw result repr:", repr(result))

        # --- Extract the numeric count reliably ---
        count = 0
        try:
            

            # Prefer named column matching the function name
            expected_col = "populate_revenue_metrics_diff"
            alt_col = "populate_revenue_metrics"

            if pd is not None and isinstance(result, pd.DataFrame):
                if not result.empty:
                    # try expected column first
                    if expected_col in result.columns:
                        try:
                            count = int(result[expected_col].iat[0])
                        except Exception as e:
                            logging.info(f"[populate_revenue_metrics_diff] failed parse '{expected_col}': {e}")
                            # fallback to first cell
                            try:
                                count = int(result.iat[0, 0])
                            except Exception as e2:
                                logging.info("[populate_revenue_metrics_diff] fallback parse failed:", e2)
                                count = 0
                    elif alt_col in result.columns:
                        try:
                            count = int(result[alt_col].iat[0])
                        except Exception as e:
                            logging.info(f"[populate_revenue_metrics_diff] failed parse '{alt_col}': {e}")
                            try:
                                count = int(result.iat[0, 0])
                            except Exception:
                                count = 0
                    else:
                        # neither expected column present — use first cell
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_diff] unable to parse DataFrame first cell:", e)
                            count = 0
                else:
                    count = 0

            elif isinstance(result, (list, tuple)):
                # e.g. [(67,)], [[67]] or [67]
                if len(result) == 0:
                    count = 0
                else:
                    first = result[0]
                    if isinstance(first, (list, tuple)) and len(first) > 0:
                        try:
                            count = int(first[0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_diff] parse list-of-rows failed:", e)
                            count = 0
                    else:
                        try:
                            count = int(first)
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_diff] parse scalar in list failed:", e)
                            count = 0

            elif result is None:
                count = 0

            else:
                # attempt to coerce scalar-like results to int
                try:
                    count = int(result)
                except Exception:
                    logging.info("[populate_revenue_metrics_diff] unknown result shape, can't parse to int. repr:", repr(result))
                    count = 0

        except Exception as parse_exc:
            logging.info("[populate_revenue_metrics_diff] parse error:", parse_exc)
            count = 0

        # Step 2: Audit log
        try:
            audit_data = {
                "service_name": "populate_revenue_metrics_diff",
                "created_by": username,
                "status": "Success" if count > 0 else "No Rows",
                "comments": f"populate_revenue_metrics_diff inserted/updated {count} rows.",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            # keep running even if audit fails
            logging.warning(f"[populate_revenue_metrics_diff] Audit logging failed: {audit_exc}")

        # Build response
        response["flag"] = True
        response["inserted_count"] = count
        response["message"] = f"populate_revenue_metrics_diff executed successfully, rows={count}"

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error executing populate_revenue_metrics_diff: {exception}"

        # Step 3: Error log
        try:
            error_data = {
                "service_name": "populate_revenue_metrics_diff",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "comments": str(exception),
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if "common_utils_database" in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.warning(f"[populate_revenue_metrics_diff] Error logging to DB: {log_exc}")

    return response


def run_populate_revenue_metrics_by_plan(data):
    """
    Executes populate_revenue_metrics() and audits the count into audit_user_actions.
    Explicitly reads the 'populate_revenue_metrics' column if present and uses that value as count.
    Returns a response dict.
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    
    try:
        
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")
        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
        load_dotenv()
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))
        
       
       
        mode = os.environ.get('ENV','')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        # killbill_database = DB('altaworx_central_billing_platform_beta', **common_utils_database_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        try:

            b_conn = psycopg2.connect(
                dbname=os.environ["BILLING_PLATFORM"],
                user=user,
                password=password,
                host=hostname,
                port=port
            )
            # b_conn = create_connection(db_type, hostname, killbill_database, user, password, port)
        except Exception as e:
            logging.info(f"ERROR b_conn {e}")
        logging.info(f"create connection b_conn {b_conn}")
        

        # Query (adjust qualification if you prefer public.<fn>() or tenant-qualified)
        query = "SELECT * FROM populate_revenue_metrics_by_plan()"
        cursor = b_conn.cursor()
        cursor.execute(query)
        result = cursor.fetchone()[0]
        logging.info(f"Rows inserted b_conn: {result}")
        b_conn.commit()
        # if b_conn.notices:
        # logging.info("Postgres notices:")
        # for notice in b_conn.notices:
        #     logging.info(notice.strip())

        cursor.close()
        b_conn.close()
        # result = killbill_database.execute_query(query, True)
        # logging.info("raw result repr:", repr(result))

        # --- Extract the numeric count reliably ---
        count = 0
        try:
            

            if pd is not None and isinstance(result, pd.DataFrame):
                # If DataFrame has the expected column, use it
                col_name = "populate_revenue_metrics_by_plan"
                if col_name in result.columns and not result.empty:
                    try:
                        # take first row value from that column
                        count = int(result[col_name].iat[0])
                    except Exception as e_col:
                        logging.info(f"[populate_revenue_metrics_by_plan] failed to parse column '{col_name}': {e_col}")
                        # fallback to first cell
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e_fallback:
                            logging.info("[populate_revenue_metrics_by_plan] fallback parse failed:", e_fallback)
                            count = 0
                else:
                    # column not present — fallback to first column or first cell if available
                    if not result.empty:
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_by_plan] unable to parse DataFrame first cell:", e)
                            count = 0
                    else:
                        count = 0

            elif isinstance(result, (list, tuple)):
                # e.g. result might be [(67,)] or [[67]] or [67]
                if len(result) == 0:
                    count = 0
                else:
                    first = result[0]
                    if isinstance(first, (list, tuple)) and len(first) > 0:
                        try:
                            count = int(first[0])
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_by_plan] parse list-of-rows failed:", e)
                            count = 0
                    else:
                        try:
                            count = int(first)
                        except Exception as e:
                            logging.info("[populate_revenue_metrics_by_plan] parse scalar in list failed:", e)
                            count = 0

            elif result is None:
                count = 0

            else:
                # Scalar-like fallback
                try:
                    count = int(result)
                except Exception:
                    logging.info("[populate_revenue_metrics_by_plan] unknown result shape, can't parse to int. repr:", repr(result))
                    count = 0

        except Exception as parse_exc:
            logging.info("[populate_revenue_metrics_by_plan] parse error:", parse_exc)
            count = 0

        
        # Step 2: Audit log
        try:
            audit_data = {
                "service_name": "populate_revenue_metrics_by_plan",
                "created_by": username,
                "status": "Success" if count > 0 else "No Rows",
                "comments": f"populate_revenue_metrics_by_plan inserted/updated {count} rows.",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            # keep running even if audit fails
            logging.info(f"[populate_revenue_metrics_by_plan] Audit logging failed: {audit_exc}")

        # Build response
        response["flag"] = True
        response["inserted_count"] = count
        response["message"] = f"populate_revenue_metrics_by_plan executed successfully, rows={count}"

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error executing populate_revenue_metrics_by_plan: {exception}"

        # Step 3: Error log
        try:
            error_data = {
                "service_name": "populate_revenue_metrics_by_plan",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "comments": str(exception),
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if "common_utils_database" in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"[populate_revenue_metrics_by_plan] Error logging to DB: {log_exc}")

    return response



def run_fn_get_sim_inventory(data):
    """
    Executes populate_revenue_metrics() and audits the count into audit_user_actions.
    Explicitly reads the 'populate_revenue_metrics' column if present and uses that value as count.
    Returns a response dict.
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    
    try:
        
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")
        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
        load_dotenv()
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))
       

        mode = os.environ.get('ENV','')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        # killbill_database = DB('altaworx_central_billing_platform_beta', **common_utils_database_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        try:

            b_conn = psycopg2.connect(
                dbname=tenant_database,
                user=user,
                password=password,
                host=hostname,
                port=port
            )
            # b_conn = create_connection(db_type, hostname, killbill_database, user, password, port)
        except Exception as e:
            logging.info(f"ERROR b_conn {e}")
        logging.info(f"create connection b_conn {b_conn}")
        

        # Query (adjust qualification if you prefer public.<fn>() or tenant-qualified)
        query = "SELECT * FROM fn_get_sim_inventory_altaworx_test()"
        cursor = b_conn.cursor()
        cursor.execute(query)
        result = cursor.fetchone()[0]
        logging.info(f"Rows inserted b_conn: {result}")
        b_conn.commit()
        # if b_conn.notices:
        # logging.info("Postgres notices:")
        # for notice in b_conn.notices:
        #     logging.info(notice.strip())

        cursor.close()
        b_conn.close()
        # result = killbill_database.execute_query(query, True)
        # logging.info("raw result repr:", repr(result))

        # --- Extract the numeric count reliably ---
        count = 0
        try:
            

            if pd is not None and isinstance(result, pd.DataFrame):
                # If DataFrame has the expected column, use it
                col_name = "fn_get_sim_inventory_altaworx_test"
                if col_name in result.columns and not result.empty:
                    try:
                        # take first row value from that column
                        count = int(result[col_name].iat[0])
                    except Exception as e_col:
                        logging.info(f"[fn_get_sim_inventory_altaworx_test] failed to parse column '{col_name}': {e_col}")
                        # fallback to first cell
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e_fallback:
                            logging.info("[fn_get_sim_inventory_altaworx_test] fallback parse failed:", e_fallback)
                            count = 0
                else:
                    # column not present — fallback to first column or first cell if available
                    if not result.empty:
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e:
                            logging.info("[fn_get_sim_inventory_altaworx_test] unable to parse DataFrame first cell:", e)
                            count = 0
                    else:
                        count = 0

            elif isinstance(result, (list, tuple)):
                # e.g. result might be [(67,)] or [[67]] or [67]
                if len(result) == 0:
                    count = 0
                else:
                    first = result[0]
                    if isinstance(first, (list, tuple)) and len(first) > 0:
                        try:
                            count = int(first[0])
                        except Exception as e:
                            logging.info("[fn_get_sim_inventory_altaworx_test] parse list-of-rows failed:", e)
                            count = 0
                    else:
                        try:
                            count = int(first)
                        except Exception as e:
                            logging.info("[fn_get_sim_inventory_altaworx_test] parse scalar in list failed:", e)
                            count = 0

            elif result is None:
                count = 0

            else:
                # Scalar-like fallback
                try:
                    count = int(result)
                except Exception:
                    logging.info("[fn_get_sim_inventory_altaworx_test] unknown result shape, can't parse to int. repr:", repr(result))
                    count = 0

        except Exception as parse_exc:
            logging.info("[fn_get_sim_inventory_altaworx_test] parse error:", parse_exc)
            count = 0

        
        # Step 2: Audit log
        try:
            audit_data = {
                "service_name": "fn_get_sim_inventory_altaworx_test",
                "created_by": username,
                "status": "Success" if count > 0 else "No Rows",
                "comments": f"fn_get_sim_inventory_altaworx_test inserted/updated {count} rows.",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            # keep running even if audit fails
            logging.info(f"[fn_get_sim_inventory_altaworx_test] Audit logging failed: {audit_exc}")

        # Build response
        response["flag"] = True
        response["inserted_count"] = count
        response["message"] = f"fn_get_sim_inventory_altaworx_test executed successfully, rows={count}"

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error executing fn_get_sim_inventory_altaworx_test: {exception}"

        # Step 3: Error log
        try:
            error_data = {
                "service_name": "fn_get_sim_inventory_altaworx_test",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "comments": str(exception),
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if "common_utils_database" in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"[fn_get_sim_inventory_altaworx_test] Error logging to DB: {log_exc}")

    return response


def run_inventory_status_history_insert(data):
    """
    Executes inventory_status_history_insert() and audits the count into audit_user_actions.
    Explicitly reads the 'populate_revenue_metrics' column if present and uses that value as count.
    Returns a response dict.
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    
    try:
        
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")
        db_config_details = data.get("db_config_details", {})
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
        
        load_dotenv()
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))

        mode = os.environ.get('ENV','')
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
        # killbill_database = DB('altaworx_central_billing_platform_beta', **common_utils_database_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        try:

            b_conn = psycopg2.connect(
                dbname=tenant_database,
                user=user,
                password=password,
                host=hostname,
                port=port
            )
            # b_conn = create_connection(db_type, hostname, killbill_database, user, password, port)
        except Exception as e:
            logging.info(f"ERROR b_conn {e}")
        logging.info(f"create connection b_conn {b_conn}")
        

        # Query (adjust qualification if you prefer public.<fn>() or tenant-qualified)
        query = "SELECT * FROM inventory_status_history_insert()"
        cursor = b_conn.cursor()
        cursor.execute(query)
        result = cursor.fetchone()[0]
        logging.info(f"Rows inserted b_conn: {result}")
        b_conn.commit()
        # if b_conn.notices:
        # logging.info("Postgres notices:")
        # for notice in b_conn.notices:
        #     logging.info(notice.strip())

        cursor.close()
        b_conn.close()
        # result = killbill_database.execute_query(query, True)
        # logging.info("raw result repr:", repr(result))

        # --- Extract the numeric count reliably ---
        count = 0
        try:
            

            if pd is not None and isinstance(result, pd.DataFrame):
                # If DataFrame has the expected column, use it
                col_name = "fn_get_sim_inventory_altaworx_test"
                if col_name in result.columns and not result.empty:
                    try:
                        # take first row value from that column
                        count = int(result[col_name].iat[0])
                    except Exception as e_col:
                        logging.info(f"[inventory_status_history_insert] failed to parse column '{col_name}': {e_col}")
                        # fallback to first cell
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e_fallback:
                            logging.info("[inventory_status_history_insert] fallback parse failed:", e_fallback)
                            count = 0
                else:
                    # column not present — fallback to first column or first cell if available
                    if not result.empty:
                        try:
                            count = int(result.iat[0, 0])
                        except Exception as e:
                            logging.info("[inventory_status_history_insert] unable to parse DataFrame first cell:", e)
                            count = 0
                    else:
                        count = 0

            elif isinstance(result, (list, tuple)):
                # e.g. result might be [(67,)] or [[67]] or [67]
                if len(result) == 0:
                    count = 0
                else:
                    first = result[0]
                    if isinstance(first, (list, tuple)) and len(first) > 0:
                        try:
                            count = int(first[0])
                        except Exception as e:
                            logging.info("[inventory_status_history_insert] parse list-of-rows failed:", e)
                            count = 0
                    else:
                        try:
                            count = int(first)
                        except Exception as e:
                            logging.info("[inventory_status_history_insert] parse scalar in list failed:", e)
                            count = 0

            elif result is None:
                count = 0

            else:
                # Scalar-like fallback
                try:
                    count = int(result)
                except Exception:
                    logging.info("[fn_get_sim_inventory_altaworx_test] unknown result shape, can't parse to int. repr:", repr(result))
                    count = 0

        except Exception as parse_exc:
            logging.info("[fn_get_sim_inventory_altaworx_test] parse error:", parse_exc)
            count = 0

        
        # Step 2: Audit log
        try:
            audit_data = {
                "service_name": "fn_get_sim_inventory_altaworx_test",
                "created_by": username,
                "status": "Success" if count > 0 else "No Rows",
                "comments": f"fn_get_sim_inventory_altaworx_test inserted/updated {count} rows.",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            # keep running even if audit fails
            logging.info(f"[fn_get_sim_inventory_altaworx_test] Audit logging failed: {audit_exc}")

        # Build response
        response["flag"] = True
        response["inserted_count"] = count
        response["message"] = f"fn_get_sim_inventory_altaworx_test executed successfully, rows={count}"

    except Exception as exception:
        response["flag"] = False
        response["message"] = f"Error executing fn_get_sim_inventory_altaworx_test: {exception}"

        # Step 3: Error log
        try:
            error_data = {
                "service_name": "fn_get_sim_inventory_altaworx_test",
                "error_message": str(exception),
                "error_type": type(exception).__name__,
                "users": username,
                "comments": str(exception),
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if "common_utils_database" in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"[fn_get_sim_inventory_altaworx_test] Error logging to DB: {log_exc}")

    return response


################# billing sync ######################

################# usage tables sync ######################

def run_fn_get_rate_plan_name_by_customer(data):
    """
    Executes SELECT * FROM fn_get_rate_plan_name_by_customer() and inserts returned rows into
    the `customerrateplan` table using `database.insert_data(insert_records, "customerrateplan")`.

    Expected `data` keys:
      - db_name: tenant database name (required)
      - username: user performing the action (for audit)
      - sessionID: session id (for audit)
      - tenant_name: tenant friendly name (for audit)

    Returns a dict: { 'flag': bool, 'inserted_count': int, 'message': str }
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    load_dotenv()

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")
        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
     
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))
     

        # Create a DB helper for the tenant (used for inserts)
        # `db_config` is expected to be available in the surrounding module
        database = None
        try:
            database = DB(tenant_database, **db_config)
        except Exception as e:
            logging.info(f"Could not create DB helper for tenant {tenant_database}: {e}")
            # We will still try to use psycopg2 connection below for reading

        # Create common utils DB for audit/error logging if available
        common_utils_database = None
        try:
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
        except Exception:
            common_utils_database = None

        # Open a direct psycopg2 connection to execute the function
        conn = None
        try:
            conn = psycopg2.connect(dbname=tenant_database, user=user, password=password, host=hostname, port=port)
        except Exception as e:
            logging.info(f"ERROR connecting to tenant DB {tenant_database}: {e}")
            raise

        cursor = conn.cursor()
        query = "SELECT * FROM mv_usage_summary_by_plan_by_customer_3months"
        cursor.execute(query)

        # Fetch all rows
        rows = cursor.fetchall()
        conn.commit()
        colnames = []
        if cursor.description:
            colnames = [desc[0] for desc in cursor.description]

        insert_records = []

        # If the function returned zero rows, rows will be []
        if not rows:
            logging.info("fn_get_rate_plan_name_by_customer() returned no rows")
        else:
            # Build list of dicts mapping column names to values (fall back to positional keys if no colnames)
            for r in rows:
                # If row is a single composite / record (e.g., a single column that itself is a row),
                # try to unpack it. If `r` is a tuple of length 1 and that element is a tuple/list, use that inner sequence.
                if isinstance(r, (list, tuple)) and len(r) == 1 and isinstance(r[0], (list, tuple)):
                    effective_row = r[0]
                else:
                    effective_row = r

                if colnames and len(colnames) == len(effective_row):
                    record = dict(zip(colnames, effective_row))
                else:
                    # Generate positional keys like col_0, col_1
                    record = {f"col_{i}": v for i, v in enumerate(effective_row)}

                insert_records.append(record)

        # Close cursor/connection
        cursor.close()
        conn.close()

        # Insert into customerrateplan using provided `database.insert_data` helper if available
        inserted_count = 0
        if insert_records:
            if database is None:
                # Try to create DB helper (maybe db_config wasn't present earlier)
                try:
                    database = DB(tenant_database, **db_config)
                except Exception as e:
                    logging.info(f"Failed to create DB helper for insert: {e}")
                    database = None

            if database:
                try:
                    # The user asked to use: database.insert_data(insert_records, "customerrateplan")
                    database.insert_data(insert_records, "fn_get_rate_plan_name_by_customer")
                    inserted_count = len(insert_records)
                except Exception as ins_exc:
                    logging.info(f"Failed to insert records into fn_get_rate_plan_name_by_customer: {ins_exc}")
                    # Optionally try to insert using SQL fallback (not implemented here)
            else:
                logging.info("No database helper available to perform insert; skipping insertion")
        else:
            logging.info("No records to insert into fn_get_rate_plan_name_by_customer")

        # Audit the action
        try:
            audit_data = {
                "service_name": "fn_get_rate_plan_name_by_customer",
                "created_by": username,
                "status": "Success" if inserted_count > 0 else "No Rows",
                "comments": f"fn_get_rate_plan_name_by_customer inserted {inserted_count} rows into customerrateplan",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["message"] = f"fn_get_rate_plan_name_by_customer executed; inserted_count={inserted_count}"

    except Exception as exc:
        logging.exception("Error in run_fn_get_rate_plan_name_by_customer")
        response["flag"] = False
        response["message"] = f"Error executing fn_get_rate_plan_name_by_customer: {exc}"

        # Log to error table if common utils DB is available
        try:
            error_data = {
                "service_name": "fn_get_rate_plan_name_by_customer",
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": data.get("username"),
                "comments": str(exc),
                "module_name": "Revenue",
                "tenant_name": data.get("tenant_name"),
                "session_id": data.get("sessionID"),
            }
            if 'common_utils_database' in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging to DB: {log_exc}")

    return response

def run_fn_get_usage_summary_by_plan_by_customer(data):
    """
    Executes SELECT * FROM fn_get_usage_summary_by_plan_by_customer() and inserts returned rows into
    the `customerrateplan` table using `database.insert_data(insert_records, "customerrateplan")`.

    Expected `data` keys:
      - db_name: tenant database name (required)
      - username: user performing the action (for audit)
      - sessionID: session id (for audit)
      - tenant_name: tenant friendly name (for audit)

    Returns a dict: { 'flag': bool, 'inserted_count': int, 'message': str }
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    load_dotenv()

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")

        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       

        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))

        # Create a DB helper for the tenant (used for inserts)
        # `db_config` is expected to be available in the surrounding module
        database = None
        try:
            database = DB(tenant_database, **db_config)
        except Exception as e:
            logging.info(f"Could not create DB helper for tenant {tenant_database}: {e}")
            # We will still try to use psycopg2 connection below for reading

        # Create common utils DB for audit/error logging if available
        common_utils_database = None
        try:
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
        except Exception:
            common_utils_database = None

        # Open a direct psycopg2 connection to execute the function
        conn = None
        try:
            conn = psycopg2.connect(dbname=tenant_database, user=user, password=password, host=hostname, port=port)
        except Exception as e:
            logging.info(f"ERROR connecting to tenant DB {tenant_database}: {e}")
            raise

        cursor = conn.cursor()
        query = "SELECT * FROM fn_get_usage_summary_by_plan_by_customer()"
        cursor.execute(query)

        # Fetch all rows
        rows = cursor.fetchall()
        conn.commit()
        colnames = []
        if cursor.description:
            colnames = [desc[0] for desc in cursor.description]

        insert_records = []

        # If the function returned zero rows, rows will be []
        if not rows:
            logging.info("fn_get_usage_summary_by_plan_by_customer() returned no rows")
        else:
            # Build list of dicts mapping column names to values (fall back to positional keys if no colnames)
            for r in rows:
                # If row is a single composite / record (e.g., a single column that itself is a row),
                # try to unpack it. If `r` is a tuple of length 1 and that element is a tuple/list, use that inner sequence.
                if isinstance(r, (list, tuple)) and len(r) == 1 and isinstance(r[0], (list, tuple)):
                    effective_row = r[0]
                else:
                    effective_row = r

                if colnames and len(colnames) == len(effective_row):
                    record = dict(zip(colnames, effective_row))
                else:
                    # Generate positional keys like col_0, col_1
                    record = {f"col_{i}": v for i, v in enumerate(effective_row)}

                insert_records.append(record)

        # Close cursor/connection
        cursor.close()
        conn.close()

        # Insert into customerrateplan using provided `database.insert_data` helper if available
        inserted_count = 0
        if insert_records:
            if database is None:
                # Try to create DB helper (maybe db_config wasn't present earlier)
                try:
                    database = DB(tenant_database, **db_config)
                except Exception as e:
                    logging.info(f"Failed to create DB helper for insert: {e}")
                    database = None

            if database:
                try:
                    # The user asked to use: database.insert_data(insert_records, "customerrateplan")
                    database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_customer")
                    inserted_count = len(insert_records)
                except Exception as ins_exc:
                    logging.info(f"Failed to insert records into fn_get_usage_summary_by_plan_by_customer: {ins_exc}")
                    # Optionally try to insert using SQL fallback (not implemented here)
            else:
                logging.info("No database helper available to perform insert; skipping insertion")
        else:
            logging.info("No records to insert into fn_get_usage_summary_by_plan_by_customer")

        # Audit the action
        try:
            audit_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_customer",
                "created_by": username,
                "status": "Success" if inserted_count > 0 else "No Rows",
                "comments": f"fn_get_usage_summary_by_plan_by_customer inserted {inserted_count} rows into fn_get_usage_summary_by_plan_by_customer",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["message"] = f"fn_get_usage_summary_by_plan_by_customer executed; inserted_count={inserted_count}"

    except Exception as exc:
        logging.exception("Error in fn_get_usage_summary_by_plan_by_customer")
        response["flag"] = False
        response["message"] = f"Error executing fn_get_usage_summary_by_plan_by_customer: {exc}"

        # Log to error table if common utils DB is available
        try:
            error_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_customer",
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": data.get("username"),
                "comments": str(exc),
                "module_name": "Revenue",
                "tenant_name": data.get("tenant_name"),
                "session_id": data.get("sessionID"),
            }
            if 'common_utils_database' in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging to DB: {log_exc}")

    return response

def run_fn_get_rate_plan_name_by_provider(data):
    """
    Executes SELECT * FROM fn_get_rate_plan_name_by_provider() and inserts returned rows into
    the `customerrateplan` table using `database.insert_data(insert_records, "customerrateplan")`.

    Expected `data` keys:
      - db_name: tenant database name (required)
      - username: user performing the action (for audit)
      - sessionID: session id (for audit)
      - tenant_name: tenant friendly name (for audit)

    Returns a dict: { 'flag': bool, 'inserted_count': int, 'message': str }
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    load_dotenv()

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")

        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))

        # Create a DB helper for the tenant (used for inserts)
        # `db_config` is expected to be available in the surrounding module
        database = None
        try:
            database = DB(tenant_database, **db_config)
        except Exception as e:
            logging.info(f"Could not create DB helper for tenant {tenant_database}: {e}")
            # We will still try to use psycopg2 connection below for reading

        # Create common utils DB for audit/error logging if available
        common_utils_database = None
        try:
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
        except Exception:
            common_utils_database = None

        # Open a direct psycopg2 connection to execute the function
        conn = None
        try:
            conn = psycopg2.connect(dbname=tenant_database, user=user, password=password, host=hostname, port=port)
        except Exception as e:
            logging.info(f"ERROR connecting to tenant DB {tenant_database}: {e}")
            raise

        cursor = conn.cursor()
        query = "SELECT * FROM fn_get_rate_plan_name_by_provider()"
        cursor.execute(query)

        # Fetch all rows
        rows = cursor.fetchall()
        conn.commit()
        colnames = []
        if cursor.description:
            colnames = [desc[0] for desc in cursor.description]

        insert_records = []

        # If the function returned zero rows, rows will be []
        if not rows:
            logging.info("fn_get_rate_plan_name_by_provider() returned no rows")
        else:
            # Build list of dicts mapping column names to values (fall back to positional keys if no colnames)
            for r in rows:
                # If row is a single composite / record (e.g., a single column that itself is a row),
                # try to unpack it. If `r` is a tuple of length 1 and that element is a tuple/list, use that inner sequence.
                if isinstance(r, (list, tuple)) and len(r) == 1 and isinstance(r[0], (list, tuple)):
                    effective_row = r[0]
                else:
                    effective_row = r

                if colnames and len(colnames) == len(effective_row):
                    record = dict(zip(colnames, effective_row))
                else:
                    # Generate positional keys like col_0, col_1
                    record = {f"col_{i}": v for i, v in enumerate(effective_row)}

                insert_records.append(record)

        # Close cursor/connection
        cursor.close()
        conn.close()

        # Insert into customerrateplan using provided `database.insert_data` helper if available
        inserted_count = 0
        if insert_records:
            if database is None:
                # Try to create DB helper (maybe db_config wasn't present earlier)
                try:
                    database = DB(tenant_database, **db_config)
                except Exception as e:
                    logging.info(f"Failed to create DB helper for insert: {e}")
                    database = None

            if database:
                try:
                    # The user asked to use: database.insert_data(insert_records, "fn_get_rate_plan_name_by_provider")
                    database.insert_data(insert_records, "fn_get_rate_plan_name_by_provider")
                    inserted_count = len(insert_records)
                except Exception as ins_exc:
                    logging.info(f"Failed to insert records into fn_get_rate_plan_name_by_provider: {ins_exc}")
                    # Optionally try to insert using SQL fallback (not implemented here)
            else:
                logging.info("No database helper available to perform insert; skipping insertion")
        else:
            logging.info("No records to insert into fn_get_rate_plan_name_by_provider")

        # Audit the action
        try:
            audit_data = {
                "service_name": "fn_get_rate_plan_name_by_provider",
                "created_by": username,
                "status": "Success" if inserted_count > 0 else "No Rows",
                "comments": f"fn_get_rate_plan_name_by_provider inserted {inserted_count} rows into fn_get_rate_plan_name_by_provider",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["message"] = f"fn_get_rate_plan_name_by_provider executed; inserted_count={inserted_count}"

    except Exception as exc:
        logging.exception("Error in fn_get_rate_plan_name_by_provider")
        response["flag"] = False
        response["message"] = f"Error executing fn_get_rate_plan_name_by_provider: {exc}"

        # Log to error table if common utils DB is available
        try:
            error_data = {
                "service_name": "fn_get_rate_plan_name_by_provider",
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": data.get("username"),
                "comments": str(exc),
                "module_name": "Revenue",
                "tenant_name": data.get("tenant_name"),
                "session_id": data.get("sessionID"),
            }
            if 'common_utils_database' in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging to DB: {log_exc}")

    return response

def run_fn_get_usage_summary_by_plan_by_provider(data):
    """
    Executes SELECT * FROM fn_get_usage_summary_by_plan_by_provider() and inserts returned rows into
    the `fn_get_usage_summary_by_plan_by_provider` table using `database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_provider")`.

    Expected `data` keys:
      - db_name: tenant database name (required)
      - username: user performing the action (for audit)
      - sessionID: session id (for audit)
      - tenant_name: tenant friendly name (for audit)

    Returns a dict: { 'flag': bool, 'inserted_count': int, 'message': str }
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    load_dotenv()

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")

        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))

        # Create a DB helper for the tenant (used for inserts)
        # `db_config` is expected to be available in the surrounding module
        database = None
        try:
            database = DB(tenant_database, **db_config)
        except Exception as e:
            logging.info(f"Could not create DB helper for tenant {tenant_database}: {e}")
            # We will still try to use psycopg2 connection below for reading

        # Create common utils DB for audit/error logging if available
        common_utils_database = None
        try:
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
        except Exception:
            common_utils_database = None

        # Open a direct psycopg2 connection to execute the function
        conn = None
        try:
            conn = psycopg2.connect(dbname=tenant_database, user=user, password=password, host=hostname, port=port)
        except Exception as e:
            logging.info(f"ERROR connecting to tenant DB {tenant_database}: {e}")
            raise

        cursor = conn.cursor()
        query = "SELECT * FROM fn_get_usage_summary_by_plan_by_provider()"
        cursor.execute(query)

        # Fetch all rows
        rows = cursor.fetchall()
        conn.commit()
        colnames = []
        if cursor.description:
            colnames = [desc[0] for desc in cursor.description]

        insert_records = []

        # If the function returned zero rows, rows will be []
        if not rows:
            logging.info("fn_get_usage_summary_by_plan_by_provider() returned no rows")
        else:
            # Build list of dicts mapping column names to values (fall back to positional keys if no colnames)
            for r in rows:
                # If row is a single composite / record (e.g., a single column that itself is a row),
                # try to unpack it. If `r` is a tuple of length 1 and that element is a tuple/list, use that inner sequence.
                if isinstance(r, (list, tuple)) and len(r) == 1 and isinstance(r[0], (list, tuple)):
                    effective_row = r[0]
                else:
                    effective_row = r

                if colnames and len(colnames) == len(effective_row):
                    record = dict(zip(colnames, effective_row))
                else:
                    # Generate positional keys like col_0, col_1
                    record = {f"col_{i}": v for i, v in enumerate(effective_row)}

                insert_records.append(record)

        # Close cursor/connection
        cursor.close()
        conn.close()

        # Insert into customerrateplan using provided `database.insert_data` helper if available
        inserted_count = 0
        if insert_records:
            if database is None:
                # Try to create DB helper (maybe db_config wasn't present earlier)
                try:
                    database = DB(tenant_database, **db_config)
                except Exception as e:
                    logging.info(f"Failed to create DB helper for insert: {e}")
                    database = None

            if database:
                try:
                    # The user asked to use: database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_provider")
                    database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_provider")
                    inserted_count = len(insert_records)
                except Exception as ins_exc:
                    logging.info(f"Failed to insert records into fn_get_usage_summary_by_plan_by_provider: {ins_exc}")
                    # Optionally try to insert using SQL fallback (not implemented here)
            else:
                logging.info("No database helper available to perform insert; skipping insertion")
        else:
            logging.info("No records to insert into fn_get_usage_summary_by_plan_by_provider")

        # Audit the action
        try:
            audit_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_provider",
                "created_by": username,
                "status": "Success" if inserted_count > 0 else "No Rows",
                "comments": f"fn_get_usage_summary_by_plan_by_provider inserted {inserted_count} rows into fn_get_usage_summary_by_plan_by_provider",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["message"] = f"fn_get_usage_summary_by_plan_by_provider executed; inserted_count={inserted_count}"

    except Exception as exc:
        logging.exception("Error in fn_get_usage_summary_by_plan_by_provider")
        response["flag"] = False
        response["message"] = f"Error executing fn_get_usage_summary_by_plan_by_provider: {exc}"

        # Log to error table if common utils DB is available
        try:
            error_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_provider",
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": data.get("username"),
                "comments": str(exc),
                "module_name": "Revenue",
                "tenant_name": data.get("tenant_name"),
                "session_id": data.get("sessionID"),
            }
            if 'common_utils_database' in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging to DB: {log_exc}")

    return response

def run_fn_get_usage_summary_by_plan_by_provider_rate_plan(data):
    """
    Executes SELECT * FROM fn_get_usage_summary_by_plan_by_provider_rate_plan() and inserts returned rows into
    the `customerrateplan` table using `database.insert_data(insert_records, "customerrateplan")`.

    Expected `data` keys:
      - db_name: tenant database name (required)
      - username: user performing the action (for audit)
      - sessionID: session id (for audit)
      - tenant_name: tenant friendly name (for audit)

    Returns a dict: { 'flag': bool, 'inserted_count': int, 'message': str }
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    load_dotenv()

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")

        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        # db_name = 'altaworx_central_billing_platform_beta'
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))

        # Create a DB helper for the tenant (used for inserts)
        # `db_config` is expected to be available in the surrounding module
        database = None
        try:
            database = DB(tenant_database, **db_config)
        except Exception as e:
            logging.info(f"Could not create DB helper for tenant {tenant_database}: {e}")
            # We will still try to use psycopg2 connection below for reading

        # Create common utils DB for audit/error logging if available
        common_utils_database = None
        try:
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
        except Exception:
            common_utils_database = None

        # Open a direct psycopg2 connection to execute the function
        conn = None
        try:
            conn = psycopg2.connect(dbname=tenant_database, user=user, password=password, host=hostname, port=port)
        except Exception as e:
            logging.info(f"ERROR connecting to tenant DB {tenant_database}: {e}")
            raise

        cursor = conn.cursor()
        query = "SELECT * FROM fn_get_usage_summary_by_plan_by_provider_rate_plan()"
        cursor.execute(query)

        # Fetch all rows
        rows = cursor.fetchall()
        conn.commit()
        colnames = []
        if cursor.description:
            colnames = [desc[0] for desc in cursor.description]

        insert_records = []

        # If the function returned zero rows, rows will be []
        if not rows:
            logging.info("fn_get_usage_summary_by_plan_by_provider_rate_plan() returned no rows")
        else:
            # Build list of dicts mapping column names to values (fall back to positional keys if no colnames)
            for r in rows:
                # If row is a single composite / record (e.g., a single column that itself is a row),
                # try to unpack it. If `r` is a tuple of length 1 and that element is a tuple/list, use that inner sequence.
                if isinstance(r, (list, tuple)) and len(r) == 1 and isinstance(r[0], (list, tuple)):
                    effective_row = r[0]
                else:
                    effective_row = r

                if colnames and len(colnames) == len(effective_row):
                    record = dict(zip(colnames, effective_row))
                else:
                    # Generate positional keys like col_0, col_1
                    record = {f"col_{i}": v for i, v in enumerate(effective_row)}

                insert_records.append(record)

        # Close cursor/connection
        cursor.close()
        conn.close()

        # Insert into customerrateplan using provided `database.insert_data` helper if available
        inserted_count = 0
        if insert_records:
            if database is None:
                # Try to create DB helper (maybe db_config wasn't present earlier)
                try:
                    database = DB(tenant_database, **db_config)
                except Exception as e:
                    logging.info(f"Failed to create DB helper for insert: {e}")
                    database = None

            if database:
                try:
                    # The user asked to use: database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_provider_rate_plan")
                    database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_provider_rate_plan")
                    inserted_count = len(insert_records)
                except Exception as ins_exc:
                    logging.info(f"Failed to insert records into fn_get_usage_summary_by_plan_by_provider_rate_plan: {ins_exc}")
                    # Optionally try to insert using SQL fallback (not implemented here)
            else:
                logging.info("No database helper available to perform insert; skipping insertion")
        else:
            logging.info("No records to insert into fn_get_usage_summary_by_plan_by_provider_rate_plan")

        # Audit the action
        try:
            audit_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_provider_rate_plan",
                "created_by": username,
                "status": "Success" if inserted_count > 0 else "No Rows",
                "comments": f"fn_get_usage_summary_by_plan_by_provider_rate_plan inserted {inserted_count} rows into fn_get_usage_summary_by_plan_by_provider_rate_plan",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["message"] = f"fn_get_usage_summary_by_plan_by_provider_rate_plan executed; inserted_count={inserted_count}"

    except Exception as exc:
        logging.exception("Error in fn_get_usage_summary_by_plan_by_provider_rate_plan")
        response["flag"] = False
        response["message"] = f"Error executing fn_get_usage_summary_by_plan_by_provider_rate_plan: {exc}"

        # Log to error table if common utils DB is available
        try:
            error_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_provider_rate_plan",
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": data.get("username"),
                "comments": str(exc),
                "module_name": "Revenue",
                "tenant_name": data.get("tenant_name"),
                "session_id": data.get("sessionID"),
            }
            if 'common_utils_database' in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging to DB: {log_exc}")

    return response


################## usage tables sync end ######################


################## usage tables weekly sync start ######################

def run_fn_get_usage_summary_by_plan_by_customer_3months(data):
    """
    Executes SELECT * FROM fn_get_usage_summary_by_plan_by_customer() and inserts returned rows into
    the `customerrateplan` table using `database.insert_data(insert_records, "customerrateplan")`.

    Expected `data` keys:
      - db_name: tenant database name (required)
      - username: user performing the action (for audit)
      - sessionID: session id (for audit)
      - tenant_name: tenant friendly name (for audit)

    Returns a dict: { 'flag': bool, 'inserted_count': int, 'message': str }
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    load_dotenv()

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")
        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))

        # Create a DB helper for the tenant (used for inserts)
        database = None
        try:
            database = DB(tenant_database, **db_config)
        except Exception as e:
            logging.info(f"Could not create DB helper for tenant {tenant_database}: {e}")

        # Create common utils DB for audit/error logging if available
        common_utils_database = None
        try:
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
        except Exception:
            common_utils_database = None

        # Open a direct psycopg2 connection to execute the function
        conn = None
        try:
            conn = psycopg2.connect(dbname=tenant_database, user=user, password=password, host=hostname, port=port)
        except Exception as e:
            logging.info(f"ERROR connecting to tenant DB {tenant_database}: {e}")
            raise

        cursor = conn.cursor()
        
        # Calculate current month and last 2 months dynamically
        # First, get distinct months from the view to understand the date format
        cursor.execute("SELECT DISTINCT usage_day FROM mv_usage_summary_by_plan_by_customer_3months LIMIT 1")
        sample_date = cursor.fetchone()
        
        if not sample_date:
            logging.info("No data found in mv_usage_summary_by_plan_by_customer_3months")
            conn.close()
            response["flag"] = True
            response["message"] = "No data found in source table"
            return response
        
        # Determine date format and calculate date range
        # We'll use PostgreSQL date functions to filter data
        current_date = datetime.now().date()
        three_months_ago = (current_date - relativedelta(months=2)).replace(day=1)
        
        # Build query with date filter for current and last 2 months
        query = """
            SELECT * 
            FROM mv_usage_summary_by_plan_by_customer_3months 
            WHERE DATE_TRUNC('month', usage_day) >= DATE_TRUNC('month', %s::date)
            AND DATE_TRUNC('month', usage_day) <= DATE_TRUNC('month', %s::date)
        """
        
        # Calculate start date (first day of month 2 months ago) and end date (last day of current month)
        start_date = three_months_ago
        end_date = current_date
        
        cursor.execute(query, (start_date, end_date))
        
        # Fetch all rows
        rows = cursor.fetchall()
        
        # Get column names
        colnames = []
        if cursor.description:
            colnames = [desc[0] for desc in cursor.description]
        
        insert_records = []
        
        if not rows:
            logging.info("mv_usage_summary_by_plan_by_customer_3months returned no rows for the specified date range")
        else:
            # Build list of dicts mapping column names to values
            for r in rows:
                if isinstance(r, (list, tuple)) and len(r) == 1 and isinstance(r[0], (list, tuple)):
                    effective_row = r[0]
                else:
                    effective_row = r

                if colnames and len(colnames) == len(effective_row):
                    record = dict(zip(colnames, effective_row))
                else:
                    record = {f"col_{i}": v for i, v in enumerate(effective_row)}

                insert_records.append(record)
        
        # Extract unique months from the filtered data for deletion
        months_to_delete = set()
        for record in insert_records:
            if 'usage_day' in record and record['usage_day']:
                try:
                    # Convert usage_day to month format (YYYY-MM-01)
                    if isinstance(record['usage_day'], str):
                        date_obj = datetime.strptime(record['usage_day'], '%Y-%m-%d').date()
                    else:
                        date_obj = record['usage_day']
                    month_start = date_obj.replace(day=1)
                    months_to_delete.add(month_start)
                except Exception as e:
                    logging.info(f"Error parsing usage_day {record['usage_day']}: {e}")
        
        # First, delete existing records for the same months from fn_get_usage_summary_by_plan_by_customer table
        if months_to_delete:
            try:
                # Prepare delete query
                delete_query = """
                    DELETE FROM fn_get_usage_summary_by_plan_by_customer 
                    WHERE DATE_TRUNC('month', usage_day) IN (
                """
                
                # Create placeholders for all months
                placeholders = ', '.join(['%s'] * len(months_to_delete))
                delete_query += placeholders + ")"
                
                logging.info(f"deleted query{delete_query}")
                
                # Execute delete
                cursor.execute(delete_query, list(months_to_delete))
                deleted_count = cursor.rowcount
                logging.info(f"Deleted {deleted_count} existing records for months: {months_to_delete}")
                conn.commit()
                
            except Exception as delete_error:
                logging.info(f"Error deleting existing records: {delete_error}")
                # Continue with insert anyway
                conn.rollback()
        
        # Insert into fn_get_usage_summary_by_plan_by_customer table
        inserted_count = 0
        if insert_records:
            if database is None:
                # Try to create DB helper
                try:
                    database = DB(tenant_database, **db_config)
                except Exception as e:
                    logging.info(f"Failed to create DB helper for insert: {e}")
                    database = None

            if database:
                try:
                    # Insert using database helper
                    database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_customer")
                    inserted_count = len(insert_records)
                    logging.info(f"Inserted {inserted_count} records into fn_get_usage_summary_by_plan_by_customer")
                except Exception as ins_exc:
                    logging.info(f"Failed to insert records into fn_get_usage_summary_by_plan_by_customer: {ins_exc}")
                    
                    # Alternative: Use direct SQL insertion
                    try:
                        if colnames and insert_records:
                            # Build INSERT query
                            columns = ', '.join(colnames)
                            placeholders = ', '.join(['%s'] * len(colnames))
                            insert_query = f"INSERT INTO fn_get_usage_summary_by_plan_by_customer ({columns}) VALUES ({placeholders})"
                            
                            # Prepare values for batch insert
                            values = []
                            for record in insert_records:
                                row_values = []
                                for col in colnames:
                                    row_values.append(record.get(col))
                                values.append(tuple(row_values))
                            
                            # Execute batch insert
                            cursor.executemany(insert_query, values)
                            conn.commit()
                            inserted_count = len(insert_records)
                            logging.info(f"Direct SQL insert completed: {inserted_count} records")
                    except Exception as direct_insert_error:
                        logging.info(f"Direct SQL insert also failed: {direct_insert_error}")
                        conn.rollback()
            else:
                # Try direct SQL insertion if database helper is not available
                try:
                    if colnames and insert_records:
                        columns = ', '.join(colnames)
                        placeholders = ', '.join(['%s'] * len(colnames))
                        insert_query = f"INSERT INTO fn_get_usage_summary_by_plan_by_customer ({columns}) VALUES ({placeholders})"
                        
                        values = []
                        for record in insert_records:
                            row_values = []
                            for col in colnames:
                                row_values.append(record.get(col))
                            values.append(tuple(row_values))
                        
                        cursor.executemany(insert_query, values)
                        conn.commit()
                        inserted_count = len(insert_records)
                        logging.info(f"Direct SQL insert completed: {inserted_count} records")
                except Exception as direct_insert_error:
                    logging.info(f"Direct SQL insert failed: {direct_insert_error}")
                    conn.rollback()
        else:
            logging.info("No records to insert into fn_get_usage_summary_by_plan_by_customer")
        
        # Close cursor/connection
        cursor.close()
        conn.close()

        # Audit the action
        try:
            audit_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_customer",
                "created_by": username,
                "status": "Success" if inserted_count > 0 else "No Rows",
                "comments": f"Filtered and inserted {inserted_count} rows (current and last 2 months) into fn_get_rate_plan_name_by_customer",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["message"] = f"Processed current and last 2 months data; inserted_count={inserted_count}"

    except Exception as exc:
        logging.exception("Error in fn_get_usage_summary_by_plan_by_customer")
        response["flag"] = False
        response["message"] = f"Error executing fn_get_usage_summary_by_plan_by_customer: {exc}"

        # Log to error table if common utils DB is available
        try:
            error_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_customer",
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": data.get("username"),
                "comments": str(exc),
                "module_name": "Revenue",
                "tenant_name": data.get("tenant_name"),
                "session_id": data.get("sessionID"),
            }
            if 'common_utils_database' in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging to DB: {log_exc}")

    return response



def run_fn_get_usage_summary_by_plan_by_provider_rate_plan_3months(data):
    """
    Executes SELECT * FROM fn_get_usage_summary_by_plan_by_provider_rate_plan() and inserts returned rows into
    the `customerrateplan` table using `database.insert_data(insert_records, "customerrateplan")`.

    Expected `data` keys:
      - db_name: tenant database name (required)
      - username: user performing the action (for audit)
      - sessionID: session id (for audit)
      - tenant_name: tenant friendly name (for audit)

    Returns a dict: { 'flag': bool, 'inserted_count': int, 'message': str }
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    load_dotenv()

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")

        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))

        # Create a DB helper for the tenant (used for inserts)
        database = None
        try:
            database = DB(tenant_database, **db_config)
        except Exception as e:
            logging.info(f"Could not create DB helper for tenant {tenant_database}: {e}")

        # Create common utils DB for audit/error logging if available
        common_utils_database = None
        try:
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
        except Exception:
            common_utils_database = None

        # Open a direct psycopg2 connection to execute the function
        conn = None
        try:
            conn = psycopg2.connect(dbname=tenant_database, user=user, password=password, host=hostname, port=port)
        except Exception as e:
            logging.info(f"ERROR connecting to tenant DB {tenant_database}: {e}")
            raise

        cursor = conn.cursor()
        
        # Calculate current month and last 2 months dynamically
        current_date = datetime.now().date()
        three_months_ago = (current_date - relativedelta(months=2)).replace(day=1)
        
        # Build query with date filter for current and last 2 months
        query = """
            SELECT * 
            FROM mv_usage_summary_by_plan_by_provider_rate_plan_3months 
            WHERE DATE_TRUNC('month', usage_day) >= DATE_TRUNC('month', %s::date)
            AND DATE_TRUNC('month', usage_day) <= DATE_TRUNC('month', %s::date)
        """
        
        # Calculate start date (first day of month 2 months ago) and end date (last day of current month)
        start_date = three_months_ago
        end_date = current_date
        
        cursor.execute(query, (start_date, end_date))
        
        # Fetch all rows
        rows = cursor.fetchall()
        
        # Get column names
        colnames = []
        if cursor.description:
            colnames = [desc[0] for desc in cursor.description]
        
        insert_records = []
        
        if not rows:
            logging.info("mv_usage_summary_by_plan_by_provider_rate_plan_3months returned no rows for the specified date range")
        else:
            # Build list of dicts mapping column names to values
            for r in rows:
                if isinstance(r, (list, tuple)) and len(r) == 1 and isinstance(r[0], (list, tuple)):
                    effective_row = r[0]
                else:
                    effective_row = r

                if colnames and len(colnames) == len(effective_row):
                    record = dict(zip(colnames, effective_row))
                else:
                    record = {f"col_{i}": v for i, v in enumerate(effective_row)}

                insert_records.append(record)
        
        # Extract unique months from the filtered data for deletion
        months_to_delete = set()
        for record in insert_records:
            if 'usage_day' in record and record['usage_day']:
                try:
                    # Convert usage_day to month format (YYYY-MM-01)
                    if isinstance(record['usage_day'], str):
                        date_obj = datetime.strptime(record['usage_day'], '%Y-%m-%d').date()
                    else:
                        date_obj = record['usage_day']
                    month_start = date_obj.replace(day=1)
                    months_to_delete.add(month_start)
                except Exception as e:
                    logging.info(f"Error parsing usage_day {record['usage_day']}: {e}")
        
        # First, delete existing records for the same months from fn_get_usage_summary_by_plan_by_provider_rate_plan table
        if months_to_delete:
            try:
                # Prepare delete query
                delete_query = """
                    DELETE FROM fn_get_usage_summary_by_plan_by_provider_rate_plan 
                    WHERE DATE_TRUNC('month', usage_day) IN (
                """
                
                # Create placeholders for all months
                placeholders = ', '.join(['%s'] * len(months_to_delete))
                delete_query += placeholders + ")"
                
                # Execute delete
                cursor.execute(delete_query, list(months_to_delete))
                deleted_count = cursor.rowcount
                logging.info(f"Deleted {deleted_count} existing records for months: {months_to_delete}")
                conn.commit()
                
            except Exception as delete_error:
                logging.info(f"Error deleting existing records: {delete_error}")
                # Continue with insert anyway
                conn.rollback()
        
        # Insert into fn_get_usage_summary_by_plan_by_provider_rate_plan table
        inserted_count = 0
        if insert_records:
            if database is None:
                # Try to create DB helper
                try:
                    database = DB(tenant_database, **db_config)
                except Exception as e:
                    logging.info(f"Failed to create DB helper for insert: {e}")
                    database = None

            if database:
                try:
                    # Insert using database helper
                    database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_provider_rate_plan")
                    inserted_count = len(insert_records)
                    logging.info(f"Inserted {inserted_count} records into fn_get_usage_summary_by_plan_by_provider_rate_plan")
                except Exception as ins_exc:
                    logging.info(f"Failed to insert records into fn_get_usage_summary_by_plan_by_provider_rate_plan: {ins_exc}")
                    
                    # Alternative: Use direct SQL insertion
                    try:
                        if colnames and insert_records:
                            # Build INSERT query
                            columns = ', '.join(colnames)
                            placeholders = ', '.join(['%s'] * len(colnames))
                            insert_query = f"INSERT INTO fn_get_usage_summary_by_plan_by_provider_rate_plan ({columns}) VALUES ({placeholders})"
                            
                            # Prepare values for batch insert
                            values = []
                            for record in insert_records:
                                row_values = []
                                for col in colnames:
                                    row_values.append(record.get(col))
                                values.append(tuple(row_values))
                            
                            # Execute batch insert
                            cursor.executemany(insert_query, values)
                            conn.commit()
                            inserted_count = len(insert_records)
                            logging.info(f"Direct SQL insert completed: {inserted_count} records")
                    except Exception as direct_insert_error:
                        logging.info(f"Direct SQL insert also failed: {direct_insert_error}")
                        conn.rollback()
            else:
                # Try direct SQL insertion if database helper is not available
                try:
                    if colnames and insert_records:
                        columns = ', '.join(colnames)
                        placeholders = ', '.join(['%s'] * len(colnames))
                        insert_query = f"INSERT INTO fn_get_usage_summary_by_plan_by_provider_rate_plan ({columns}) VALUES ({placeholders})"
                        
                        values = []
                        for record in insert_records:
                            row_values = []
                            for col in colnames:
                                row_values.append(record.get(col))
                            values.append(tuple(row_values))
                        
                        cursor.executemany(insert_query, values)
                        conn.commit()
                        inserted_count = len(insert_records)
                        logging.info(f"Direct SQL insert completed: {inserted_count} records")
                except Exception as direct_insert_error:
                    logging.info(f"Direct SQL insert failed: {direct_insert_error}")
                    conn.rollback()
        else:
            logging.info("No records to insert into fn_get_usage_summary_by_plan_by_provider_rate_plan")
        
        # Close cursor/connection
        cursor.close()
        conn.close()

        # Audit the action
        try:
            audit_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_provider_rate_plan",
                "created_by": username,
                "status": "Success" if inserted_count > 0 else "No Rows",
                "comments": f"Filtered and inserted {inserted_count} rows (current and last 2 months) into fn_get_usage_summary_by_plan_by_provider_rate_plan",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["message"] = f"Processed current and last 2 months data; inserted_count={inserted_count}"

    except Exception as exc:
        logging.exception("Error in fn_get_usage_summary_by_plan_by_provider_rate_plan")
        response["flag"] = False
        response["message"] = f"Error executing fn_get_usage_summary_by_plan_by_provider_rate_plan: {exc}"

        # Log to error table if common utils DB is available
        try:
            error_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_provider_rate_plan",
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": data.get("username"),
                "comments": str(exc),
                "module_name": "Revenue",
                "tenant_name": data.get("tenant_name"),
                "session_id": data.get("sessionID"),
            }
            if 'common_utils_database' in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging to DB: {log_exc}")

    return response

def run_fn_get_usage_summary_by_plan_by_provider_3months(data):
    """
    Executes SELECT * FROM fn_get_usage_summary_by_plan_by_provider() and inserts returned rows into
    the `fn_get_usage_summary_by_plan_by_provider` table using `database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_provider")`.

    Expected `data` keys:
      - db_name: tenant database name (required)
      - username: user performing the action (for audit)
      - sessionID: session id (for audit)
      - tenant_name: tenant friendly name (for audit)

    Returns a dict: { 'flag': bool, 'inserted_count': int, 'message': str }
    """
    response = {"flag": False, "inserted_count": 0, "message": ""}

    load_dotenv()

    try:
        tenant_database = data.get("db_name", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        tenant_name = data.get("tenant_name", "")

        db_config_details = data.get("db_config_details", "")
        db_config_details = json.loads(base64.b64decode(db_config_details.encode()).decode())
       
        hostname = db_config_details.get("hostname", os.getenv("PSQL_DB_HOST"))
        port = db_config_details.get("port", os.getenv("PSQL_DB_PORT"))
        user = db_config_details.get("user", os.getenv("PSQL_DB_USER"))
        password = db_config_details.get("password", os.getenv("PSQL_DB_PASSWORD"))
        db_type = db_config_details.get("db_config_details", os.getenv("PSQL_DB_TYPE"))

        # Create a DB helper for the tenant (used for inserts)
        database = None
        try:
            database = DB(tenant_database, **db_config)
        except Exception as e:
            logging.info(f"Could not create DB helper for tenant {tenant_database}: {e}")

        # Create common utils DB for audit/error logging if available
        common_utils_database = None
        try:
            common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE"), **common_utils_database_config)
        except Exception:
            common_utils_database = None

        # Open a direct psycopg2 connection to execute the function
        conn = None
        try:
            conn = psycopg2.connect(dbname=tenant_database, user=user, password=password, host=hostname, port=port)
        except Exception as e:
            logging.info(f"ERROR connecting to tenant DB {tenant_database}: {e}")
            raise

        cursor = conn.cursor()
        
        # Calculate current month and last 2 months dynamically
        current_date = datetime.now().date()
        three_months_ago = (current_date - relativedelta(months=2)).replace(day=1)
        
        # Build query with date filter for current and last 2 months
        query = """
            SELECT * 
            FROM mv_usage_summary_by_plan_by_provider_3months 
            WHERE DATE_TRUNC('month', usage_day) >= DATE_TRUNC('month', %s::date)
            AND DATE_TRUNC('month', usage_day) <= DATE_TRUNC('month', %s::date)
        """
        
        # Calculate start date (first day of month 2 months ago) and end date (last day of current month)
        start_date = three_months_ago
        end_date = current_date
        
        cursor.execute(query, (start_date, end_date))
        
        # Fetch all rows
        rows = cursor.fetchall()
        
        # Get column names
        colnames = []
        if cursor.description:
            colnames = [desc[0] for desc in cursor.description]
        
        insert_records = []
        
        if not rows:
            logging.info("mv_usage_summary_by_plan_by_provider_3months returned no rows for the specified date range")
        else:
            # Build list of dicts mapping column names to values
            for r in rows:
                if isinstance(r, (list, tuple)) and len(r) == 1 and isinstance(r[0], (list, tuple)):
                    effective_row = r[0]
                else:
                    effective_row = r

                if colnames and len(colnames) == len(effective_row):
                    record = dict(zip(colnames, effective_row))
                else:
                    record = {f"col_{i}": v for i, v in enumerate(effective_row)}

                insert_records.append(record)
        
        # Extract unique months from the filtered data for deletion
        months_to_delete = set()
        for record in insert_records:
            if 'usage_day' in record and record['usage_day']:
                try:
                    # Convert usage_usage_daydate to month format (YYYY-MM-01)
                    if isinstance(record['usage_day'], str):
                        date_obj = datetime.strptime(record['usage_day'], '%Y-%m-%d').date()
                    else:
                        date_obj = record['usage_day']
                    month_start = date_obj.replace(day=1)
                    months_to_delete.add(month_start)
                except Exception as e:
                    logging.info(f"Error parsing usage_day {record['usage_day']}: {e}")
        
        # First, delete existing records for the same months from fn_get_usage_summary_by_plan_by_provider table
        if months_to_delete:
            try:
                # Prepare delete query
                delete_query = """
                    DELETE FROM fn_get_usage_summary_by_plan_by_provider 
                    WHERE DATE_TRUNC('month', usage_day) IN (
                """
                
                # Create placeholders for all months
                placeholders = ', '.join(['%s'] * len(months_to_delete))
                delete_query += placeholders + ")"
                
                # Execute delete
                cursor.execute(delete_query, list(months_to_delete))
                deleted_count = cursor.rowcount
                logging.info(f"Deleted {deleted_count} existing records for months: {months_to_delete}")
                conn.commit()
                
            except Exception as delete_error:
                logging.info(f"Error deleting existing records: {delete_error}")
                # Continue with insert anyway
                conn.rollback()
        
        # Insert into fn_get_usage_summary_by_plan_by_provider table
        inserted_count = 0
        if insert_records:
            if database is None:
                # Try to create DB helper
                try:
                    database = DB(tenant_database, **db_config)
                except Exception as e:
                    logging.info(f"Failed to create DB helper for insert: {e}")
                    database = None

            if database:
                try:
                    # Insert using database helper
                    database.insert_data(insert_records, "fn_get_usage_summary_by_plan_by_provider")
                    inserted_count = len(insert_records)
                    logging.info(f"Inserted {inserted_count} records into fn_get_usage_summary_by_plan_by_provider")
                except Exception as ins_exc:
                    logging.info(f"Failed to insert records into fn_get_usage_summary_by_plan_by_provider: {ins_exc}")
                    
                    # Alternative: Use direct SQL insertion
                    try:
                        if colnames and insert_records:
                            # Build INSERT query
                            columns = ', '.join(colnames)
                            placeholders = ', '.join(['%s'] * len(colnames))
                            insert_query = f"INSERT INTO fn_get_usage_summary_by_plan_by_provider ({columns}) VALUES ({placeholders})"
                            
                            # Prepare values for batch insert
                            values = []
                            for record in insert_records:
                                row_values = []
                                for col in colnames:
                                    row_values.append(record.get(col))
                                values.append(tuple(row_values))
                            
                            # Execute batch insert
                            cursor.executemany(insert_query, values)
                            conn.commit()
                            inserted_count = len(insert_records)
                            logging.info(f"Direct SQL insert completed: {inserted_count} records")
                    except Exception as direct_insert_error:
                        logging.info(f"Direct SQL insert also failed: {direct_insert_error}")
                        conn.rollback()
            else:
                # Try direct SQL insertion if database helper is not available
                try:
                    if colnames and insert_records:
                        columns = ', '.join(colnames)
                        placeholders = ', '.join(['%s'] * len(colnames))
                        insert_query = f"INSERT INTO fn_get_usage_summary_by_plan_by_provider ({columns}) VALUES ({placeholders})"
                        
                        values = []
                        for record in insert_records:
                            row_values = []
                            for col in colnames:
                                row_values.append(record.get(col))
                            values.append(tuple(row_values))
                        
                        cursor.executemany(insert_query, values)
                        conn.commit()
                        inserted_count = len(insert_records)
                        logging.info(f"Direct SQL insert completed: {inserted_count} records")
                except Exception as direct_insert_error:
                    logging.info(f"Direct SQL insert failed: {direct_insert_error}")
                    conn.rollback()
        else:
            logging.info("No records to insert into fn_get_usage_summary_by_plan_by_provider")
        
        # Close cursor/connection
        cursor.close()
        conn.close()

        # Audit the action
        try:
            audit_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_provider",
                "created_by": username,
                "status": "Success" if inserted_count > 0 else "No Rows",
                "comments": f"Filtered and inserted {inserted_count} rows (current and last 2 months) into fn_get_usage_summary_by_plan_by_provider",
                "module_name": "Revenue",
                "tenant_name": tenant_name,
                "session_id": sessionID,
            }
            if common_utils_database:
                common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_exc:
            logging.info(f"Audit logging failed: {audit_exc}")

        response["flag"] = True
        response["inserted_count"] = inserted_count
        response["message"] = f"Processed current and last 2 months data; inserted_count={inserted_count}"

    except Exception as exc:
        logging.exception("Error in fn_get_usage_summary_by_plan_by_provider")
        response["flag"] = False
        response["message"] = f"Error executing fn_get_usage_summary_by_plan_by_provider: {exc}"

        # Log to error table if common utils DB is available
        try:
            error_data = {
                "service_name": "fn_get_usage_summary_by_plan_by_provider",
                "error_message": str(exc),
                "error_type": type(exc).__name__,
                "users": data.get("username"),
                "comments": str(exc),
                "module_name": "Revenue",
                "tenant_name": data.get("tenant_name"),
                "session_id": data.get("sessionID"),
            }
            if 'common_utils_database' in locals() and common_utils_database:
                common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_exc:
            logging.info(f"Error logging to DB: {log_exc}")

    return response


################## usage tables weekly sync end ######################
