'''
Author : Bhavani Ganta
Status : In Progress
Objective : This script will have all the functions required for Daily sync of data for partner becoming provider
'''

# 1. Standard Library Imports
import os
import json
import re
import time
import math
import threading
from datetime import datetime, timedelta,timezone
import copy
import uuid
#import boto3
import traceback

# 2. Third-Party Imports
import pandas as pd
from pandas import Timestamp
from sqlalchemy import create_engine, exc, text
import pytds
import psycopg2
from psycopg2.extras import execute_values
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv
from psycopg2 import sql
from common_utils.logging_utils import Logging
logging = Logging(name="main")


class MigrationScheduler:
    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(self, db_type='', host='', db_name='', username='', password='', port='', driver='', max_retry=3):
        """Create a PostgreSQL or MSSQL connection."""
        connection = None
        logging.info(f"db_type: {db_type}, host: {host}, db_name: {db_name}, username: {username}, port: {port}")
        try:
            if db_type == 'postgresql':
                logging.info("Creating PostgreSQL connection...")
                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )
                logging.info("Connection to PostgreSQL DB successful.")
            elif db_type == 'mssql':
                logging.info("Creating MSSQL connection...")
                connection = pytds.connect(
                    server=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )
                logging.info("Connection to MSSQL DB successful.")
        except Exception as e:
            logging.info(f"Failed to connect to {db_type} DB: {e}")
        return connection

    def execute_query(self, connection, query, params):
        """Execute a SQL query and return result as a DataFrame."""
        try:
            if params:
                result_df = pd.read_sql_query(query, connection, params=params)
            else:
                result_df = pd.read_sql_query(query, connection)
            return result_df
        except Exception as e:
            logging.info(f"Error executing query: {e}")
            return pd.DataFrame()

    def update_table(self, conn, table_name, data_dict, condition_dict):
        """Update a table dynamically using a dictionary."""
        try:
            data_dict = {k: (None if isinstance(v, float) and math.isnan(v) else v) for k, v in data_dict.items()}
            condition_dict = {k: (None if isinstance(v, float) and math.isnan(v) else v) for k, v in condition_dict.items()}

            set_clause = ", ".join([f"{col} = %s" for col in data_dict.keys()])
            where_clause = []
            values = list(data_dict.values())

            for col, val in condition_dict.items():
                if isinstance(val, list):
                    placeholders = ", ".join(["%s"] * len(val))
                    where_clause.append(f"{col} IN ({placeholders})")
                    values.extend(val)
                else:
                    where_clause.append(f"{col} = %s")
                    values.append(val)

            if where_clause:
                where_clause = " AND ".join(where_clause)
                sql_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
            else:
                sql_query = f"UPDATE {table_name} SET {set_clause}"

            logging.info(f"SQL Query: {sql_query}")
            logging.info(f"Values: {values}")

            with conn.cursor() as cursor:
                cursor.execute(sql_query, values)
                conn.commit()
            logging.info("Update successful.")
        except Exception as e:
            conn.rollback()
            logging.info(f"Error while updating table {table_name}: {e}")

    def insert_table(self, conn, table_name, data):
        """
        Insert data into a PostgreSQL table dynamically using all columns in the DataFrame.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table
        :param data: List of dicts or pandas DataFrame
        :return: True if insert is successful, False otherwise
        """
        try:
            if isinstance(data, list):
                df = pd.DataFrame(data)
            elif isinstance(data, pd.DataFrame):
                df = data.copy()
            else:
                logging.info("Invalid data format. Must be list of dicts or DataFrame")
                return False

            if df.empty:
                logging.info("No data to insert")
                return False

            # Replace NaN with None
            df = df.where(pd.notnull(df), None)

            # Convert dict/list columns to JSON strings
            for col in df.columns:
                if df[col].apply(lambda x: isinstance(x, (dict, list))).any():
                    df[col] = df[col].apply(lambda x: json.dumps(x) if x is not None else None)

            # Add modified_date column if not exists
            if "modified_date" not in df.columns:
                df["modified_date"] = datetime.now(timezone.utc)

            # Prepare insert
            columns_str = ", ".join(df.columns)
            rows = [tuple(x) for x in df.to_numpy()]

            with conn.cursor() as cur:
                execute_values(
                    cur,
                    f"INSERT INTO {table_name} ({columns_str}) VALUES %s",
                    rows
                )
                conn.commit()

            logging.info(f"Inserted {len(rows)} records into {table_name}")
            return True

        except Exception as e:
            if conn:
                conn.rollback()
            logging.info(f"Error inserting into {table_name}: {e}")
            return False

    def creating_daily_sync_jobs_forpbp(self, data):
        """
            Creates daily synchronization job entries for processing source-to-target data sync.

            This function is responsible only for creating job records in the 
            `partner_provider_daily_sync_jobs` table. It does not execute or monitor the sync itself. 
            Each job defines a task for syncing data between the source and target databases 
            based on the active mappings available.

            Steps typically include:
            1. Fetching the required mapping information.
            2. Creating corresponding job entries.
            3. Setting default metadata (e.g., job status, created_date in UTC).
            4. Inserting the jobs into the database for later execution by the scheduler.

            Parameters:
                data (dict): Contains details such as source_db, target_db, main_tenant_db, 
                            and tenant IDs required to create daily sync jobs.

            Returns:
                bool: True if jobs are successfully created, False otherwise.
            """

        try:
            logging.info(f"=== Initial Sync Process Started === {data}")

            source_db = data.get("source_db")
            target_db = data.get("target_db")
            main_tenant_db = data.get("main_tenant_db")
            target_name=data.get("target_name")

            logging.info(f"[DEBUG] Step 0 - source_db: {source_db}")
            logging.info(f"[DEBUG] Step 0 - target_db: {target_db}")
            logging.info(f"[DEBUG] Step 0 - main_tenant_db: {main_tenant_db}")
            logging.info(f"[DEBUG] Step 0 - target_name: {target_name}")

            load_dotenv()
            common_utils_db = os.getenv("COMMON_UTILS_DB")
            host = os.getenv("PSQL_DB_HOST")
            db_type = os.getenv("PSQL_DB_TYPE")
            username = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            port = os.getenv("PSQL_DB_PORT")

            common_utils_conn = self.create_connection(db_type, host, common_utils_db, username, password, port)
            if common_utils_conn is None:
                logging.info("Failed to connect to Common Utils DB")
                return False

            details_query = """
                SELECT
                    table_name, fk_columns, fk_col_target_mapping, where_cond,
                     partner_name, partner_db_tenant_id :: integer, target_db,
                    target_db_tenant_id ::integer,select_query,is_active
                    main_tenant_db, migration_order :: integer,
                    tenant_id_flag, fk_flag, service_provider_mapping_flag,
                    main_tenant_db_tenant_id :: integer, fetch_based_ids, inv_flag, partner_db_host,target_db_host,
                    target_name,tenant_based_foreignkeyswapping
                FROM partner_provider_initial_sync_mappings
                WHERE (target_name=%s and  target_db = %s )
                AND partner_name = %s
                AND service_provider_mapping_flag IS NULL
                AND is_active = TRUE
                ORDER BY migration_order ASC;
            """
            df = self.execute_query(common_utils_conn, details_query, (target_name, target_db, source_db))
            df = df.astype(object).mask(df.isna(), None)
            logging.info(f"[Step 3] Retrieved {len(df)} mapping rows {df.head(10)}")
            logging.info(f"DEBUG STATEMENTS 2 {df[['partner_db_tenant_id', 'target_db_tenant_id', 'migration_order', 'main_tenant_db_tenant_id']]}")

            if df.empty:
                logging.info("No matching records found. Skipping insert.")
                common_utils_conn.close()
                return False

            logging.info("Inserting into daily sync table...")
            self.insert_table(common_utils_conn, "partner_provider_daily_sync_mappings", df)
            common_utils_conn.close()
            return True

        except Exception as e:
            logging.info(f"Error during copy_initial_to_daily_sync: {e}")
            return False
    def insert_audit_record(self,conn, audit_insert_query, audit_params):
        """
        Inserts an audit record and returns the generated audit id.

        Args:
            conn: psycopg2 connection object
            audit_insert_query (str): SQL insert query with RETURNING id
            audit_params (tuple): Parameters for the insert query

        Returns:
            int: The generated audit id
        """
        try:
            with conn.cursor() as cur:
                cur.execute(audit_insert_query, audit_params)
                audit_id = cur.fetchone()[0]  # fetch the returned id
                conn.commit()
                return audit_id
        except Exception as e:
            conn.rollback()
            raise Exception(f"Error inserting audit record: {e}")
    def fetch_mapped_keys(self,conn, mapping_list: list, partner_cond_dict: dict):
        """
        Fetch mapped_ids from DB and return only keys.

        Args:
            conn: psycopg2 connection object
            mapping_list (list): Mapping config
            partner_cond_dict (dict): Conditions to apply in WHERE clause

        Returns:
            dict: {col_name: [list_of_keys]}
        """
        result_dict = {}

        cursor = conn.cursor()

        for mapping in mapping_list:
            for col_name, details in mapping.items():
                where_col = details.get("where_col")
                where_table = details.get("where_table")
                extra_conditions = details.get("<where_condition>", {})

                # Build WHERE conditions from both partner_cond_dict and extra_conditions
                conditions = []
                values = []

                for k, v in {**partner_cond_dict, **extra_conditions}.items():
                    conditions.append(f"{k} = %s")
                    values.append(v)

                where_clause = " AND ".join(conditions)

                query = f"SELECT {where_col} FROM {where_table} WHERE {where_clause};"
                logging.info(f"select query formed {query} {values}")
                cursor.execute(query, tuple(values))
                rows = cursor.fetchall()

                keys_list = []
                for row in rows:
                    mapped_ids_raw = row[0]
                    if mapped_ids_raw:
                        if isinstance(mapped_ids_raw, str):
                            mapped_ids = json.loads(mapped_ids_raw)
                        else:
                            mapped_ids = mapped_ids_raw
                        if isinstance(mapped_ids, dict):
                            keys_list.extend(mapped_ids.keys())

                result_dict[col_name] = list(set(keys_list))  # unique keys

        cursor.close()
        return result_dict
    def extract_values_from_conditions(self, conditions: dict) -> dict:
        """
        Takes a dict of {col_name: df_series or list} and extracts only values 
        from inner dict/json strings. Returns {col_name: [only values]}.
        """
        clean_conditions = {}

        logging.info("Starting extraction process...")
        for col, series in conditions.items():
            logging.info(f"Processing column: {col}")
            logging.info(f"Raw series: {series}, Type: {type(series)}")

            values = []

            # Normalize into a list
            if isinstance(series, pd.DataFrame):
                series_values = series.iloc[:, 0].tolist()
                logging.info(f"Converted DataFrame to list: {series_values}")
            elif isinstance(series, pd.Series):
                series_values = series.tolist()
                logging.info(f"Converted Series to list: {series_values}")
            else:
                series_values = [series]
                logging.info(f"Wrapped single value into list: {series_values}")

            # Extract only inner dict values
            for val in series_values:
                logging.info(f"Handling value: {val}, Type: {type(val)}")
                if isinstance(val, str):
                    try:
                        parsed = json.loads(val)
                        if isinstance(parsed, dict):
                            dict_values = list(parsed.values())
                            logging.info(f"Parsed JSON dict to values: {dict_values}")
                            values.extend(dict_values)
                        else:
                            logging.info(f"Parsed JSON non-dict: {parsed}")
                            values.append(parsed)
                    except Exception:
                        logging.info(f"Not JSON, keeping as-is: {val}")
                        values.append(val)
                elif isinstance(val, dict):
                    dict_values = list(val.values())
                    logging.info(f"Direct dict to values: {dict_values}")
                    values.extend(dict_values)
                else:
                    logging.info(f"Keeping raw value: {val}")
                    values.append(val)

            clean_conditions[col] = values
            logging.info(f"Extracted values for {col}: {values}")

        logging.info("Final clean_conditions:", clean_conditions)
        return clean_conditions
    def build_dynamic_query(self,base_query: str, conditions: dict) -> str:
        """
        Takes a base query with placeholder <where_cond>
        and a dict of {column: [values]}.
        Builds a proper WHERE clause dynamically and returns the final query.
        """
        where_clauses = []

        for col, values in conditions.items():
            if not values:
                continue  # skip empty lists
            formatted_values = ", ".join(f"'{v}'" for v in values)
            where_clauses.append(f"{col} IN ({formatted_values})")

        # If no conditions, just remove the placeholder
        if where_clauses:
            where_sql = " AND ".join(where_clauses)
            final_query = base_query.replace("<where_cond>", where_sql)
        else:
            final_query = base_query.replace("WHERE <where_cond>", "")

        return final_query
    def fetch_details_from_partner_provider_initial_sync_mappings(self, where_cond_list: list, connection, params: dict):
        """
        Fetch details from the partner_provider_initial_sync_mappings (or related) tables 
        by dynamically forming WHERE conditions for multiple query configs.

        Args:
            where_cond_list (list[dict]): Each dict contains a single key (like "customer_name", "tenant_id")
                                        with config dict containing:
                                        - where_col (str): Column(s) to select
                                        - where_table (str): Table to query from
                                        - <where_condition> (list[str]): Columns to filter on
            connection: Active database connection object
            params (dict): Dictionary mapping condition columns to their values.

        Returns:
            dict: A dictionary with each top-level key ("customer_name", "tenant_id") mapped to its query result DataFrame.
        """

        results = {}

        try:
            for cond in where_cond_list:
                # Extract the alias key (e.g., "customer_name")
                alias_key = list(cond.keys())[0]
                config = cond[alias_key]

                where_col = config["where_col"]
                where_table = config["where_table"]
                where_conditions = config["<where_condition>"]

                # Build WHERE clause dynamically
                where_clause = " AND ".join([f"{col} = %s" for col in where_conditions])
                values = [params[col] for col in where_conditions]  # preserve order

                query = f"SELECT {where_col} FROM {where_table} WHERE {where_clause}"
                
                # Execute query safely
                df = pd.read_sql_query(query, connection, params=values)
                
                results[alias_key] = df

            return results

        except Exception as e:
            raise RuntimeError(f"Error fetching details from partner_provider_initial_sync_mappings: {e}")
    def fetching_foreignkey_values(self, mapping_dict: dict, conn, condition_dict: dict):
        """
        Fetch values from DB based on mapping_dict and condition_dict.

        Args:
            mapping_dict (dict): Mapping like {"rev_customer_id": {"where_row": ..., "where_table": ..., "col_to_check": ...}}
            conn: Active DB connection
            condition_dict (dict): Condition values to filter query

        Returns:
            dict: Key -> List of fetched values
        """
        results = {}
        try:
            cursor = conn.cursor()
            for key, details in mapping_dict.items():
                where_row = details["where_row"]
                where_table = details["where_table"]
                col_to_check = details["col_to_check"]
                # Build WHERE clause dynamically
                where_clauses = []
                values = []
                for cond_key, cond_value in condition_dict.items():
                    where_clauses.append(f"{cond_key} = %s")
                    values.append(cond_value)

                where_sql = " AND ".join(where_clauses)
                query = f"""
                    SELECT {col_to_check}
                    FROM {where_table}
                    WHERE table_name = %s
                    AND {where_sql}
                """
                params = [where_row] + values
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                results[key] = [row[0] for row in rows] if rows else []
            cursor.close()
            
            return results
        except Exception as e:
            logging.info(f"Error in fetching_foreignkey_values: {str(e)}")
            return {}
    def extract_values_from_conditions(self, conditions: dict) -> dict:
        """
        Takes a dict of {col_name: df_series or list} and extracts only values 
        from inner dict/json strings. Returns {col_name: [only values]}.
        """
        clean_conditions = {}

        logging.info("Starting extraction process...")
        for col, series in conditions.items():
            logging.info(f"Processing column: {col}")
            logging.info(f"Raw series: {series}, Type: {type(series)}")

            values = []

            # Normalize into a list
            if isinstance(series, pd.DataFrame):
                series_values = series.iloc[:, 0].tolist()
                logging.info(f"Converted DataFrame to list: {series_values}")
            elif isinstance(series, pd.Series):
                series_values = series.tolist()
                logging.info(f"Converted Series to list: {series_values}")
            else:
                series_values = [series]
                logging.info(f"Wrapped single value into list: {series_values}")

            # Extract only inner dict values
            for val in series_values:
                logging.info(f"Handling value: {val}, Type: {type(val)}")
                if isinstance(val, str):
                    try:
                        parsed = json.loads(val)
                        if isinstance(parsed, dict):
                            dict_values = list(parsed.values())
                            logging.info(f"Parsed JSON dict to values: {dict_values}")
                            values.extend(dict_values)
                        else:
                            logging.info(f"Parsed JSON non-dict: {parsed}")
                            values.append(parsed)
                    except Exception:
                        logging.info(f"Not JSON, keeping as-is: {val}")
                        values.append(val)
                elif isinstance(val, dict):
                    dict_values = list(val.values())
                    logging.info(f"Direct dict to values: {dict_values}")
                    values.extend(dict_values)
                else:
                    logging.info(f"Keeping raw value: {val}")
                    values.append(val)

            clean_conditions[col] = values
            logging.info(f"Extracted values for {col}: {values}")

        logging.info("Final clean_conditions:", clean_conditions)
        return clean_conditions
    def apply_foreign_key_mappings(self,df: pd.DataFrame, foreign_key_mappings: dict) -> pd.DataFrame:
        """
        Replace values in DataFrame based on foreign_key_mappings.

        Args:
            df (pd.DataFrame): Input dataframe
            foreign_key_mappings (dict): Example:
                {
                    'device_status_id': [{'22': '7', '44': '12'}],
                    'service_provider_id': [{'1': 5, '6': 1}]
                }

        Returns:
            pd.DataFrame: Updated dataframe with FK values replaced
        """
        df = df.copy()

        for col, mappings in foreign_key_mappings.items():
            if col not in df.columns:
                logging.info(f"[apply_foreign_key_mappings] Column '{col}' not in DataFrame, skipping...")
                continue

            # Merge list of dicts into single mapping
            replace_dict = {}
            if isinstance(mappings, list):
                for m in mappings:
                    if isinstance(m, dict):
                        replace_dict.update(m)
            elif isinstance(mappings, dict):
                replace_dict.update(mappings)

            if not replace_dict:
                continue

            # Determine column type
            col_dtype = df[col].dtype

            # Normalize mapping keys and values to match column type
            if pd.api.types.is_numeric_dtype(col_dtype):
                replace_dict = {int(k): int(v) for k, v in replace_dict.items()}
                df[col] = pd.to_numeric(df[col], errors='coerce')
            else:
                replace_dict = {str(k): str(v) for k, v in replace_dict.items()}
                df[col] = df[col].astype(str)

            # Apply mapping
            df[col] = df[col].replace(replace_dict)

            logging.info(f"[apply_foreign_key_mappings] Column '{col}' replaced using mapping: {replace_dict}")
            logging.info(f"[apply_foreign_key_mappings] Sample values: {df[col].head(5).tolist()}")

        return df
    def update_partner_data_to_target_db(
        self,
        postgres_conn,
        table_name,
        data_input,
        conflict_col,
        return_mapped_ids=False,
        tenant_id_flag=False
    ):
        """
        Inserts or updates data in a PostgreSQL table based on conflict and 
        optionally returns mapping of source_id to target primary key id.

        Supports both UUID and integer IDs.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            data_input (DataFrame or list[dict]): Records to insert or update
            conflict_col (str or list): Column(s) to check for conflicts
            return_mapped_ids (bool): If True, return mapping of inserted IDs
            tenant_id_flag (bool): If True, returns mapping grouped by tenant_id

        Returns:
            dict: 
                - if tenant_id_flag=True → {tenant_id: {source_id: id}}
                - else → {source_id: id}
        """
        try:
            # --- Handle DataFrame or list[dict] ---
            if isinstance(data_input, pd.DataFrame):
                if data_input.empty:
                    logging.info(f"[{table_name}] No data provided (empty DataFrame).")
                    return {} if return_mapped_ids else None
                data_list = data_input.to_dict(orient="records")

            elif isinstance(data_input, list):
                if not data_input:
                    logging.info(f"[{table_name}] No data provided (empty list).")
                    return {} if return_mapped_ids else None
                data_list = data_input

            else:
                raise TypeError("data_input must be a pandas DataFrame or list of dicts")

            # Columns to return after insert
            if return_mapped_ids:
                return_ids = ["id", "source_id"]
                if tenant_id_flag:
                    return_ids.append("tenant_id")
            else:
                return_ids = []

            with postgres_conn.cursor() as cursor:
                # Extract column names
                columns = list(data_list[0].keys())

                # Prepare SQL parts
                columns_str = ", ".join(columns)
                conflict_cols_str = (
                    ", ".join(conflict_col)
                    if isinstance(conflict_col, (list, tuple))
                    else conflict_col
                )

                update_set = ", ".join(
                    [f"{col} = EXCLUDED.{col}" for col in columns if col not in conflict_col]
                )

                # UPSERT query
                query = f"""
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({conflict_cols_str})
                DO UPDATE SET {update_set}
                {"RETURNING " + ", ".join(return_ids) if return_ids else ""};
                """

                values = [tuple(record[col] for col in columns) for record in data_list]
                logging.info(f"[{table_name}] Preparing to execute query.")
                logging.info(f"[{table_name}] Number of records to process: {len(values)}")

                # Execute query
                #execute_values(cursor, query, values)
                execute_values(
                    cursor, 
                    query, 
                    values,
                    page_size=len(values)  # Process all records in one batch
                )


                mapping = None
                if return_mapped_ids:
                    returned_rows = cursor.fetchall()
                    logging.info(f"[{table_name}] Number of returned rows: {len(returned_rows)} ")

                    #logging.info(f"returned_rows are  {returned_rows}")

                    def normalize(val):
                        """Convert UUIDs to str, keep ints as-is."""
                        if isinstance(val, uuid.UUID):
                            return str(val)
                        return val

                    if tenant_id_flag:
                        # returned_rows = [(id, source_id, tenant_id), ...]
                        mapping = {}
                        for row in returned_rows:
                            tgt_id, src_id, tid = map(normalize, row)
                            if tid not in mapping:
                                mapping[tid] = {}
                            mapping[tid][src_id] = tgt_id
                    else:
                        # returned_rows = [(id, source_id), ...]
                        mapping = {
                            normalize(src_id): normalize(tgt_id)
                            for tgt_id, src_id in returned_rows
                        }

                    # --- Debug logs ---
                    num_input = len(data_list)
                    num_mapped = (
                        sum(len(m) for m in mapping.values())
                        if tenant_id_flag
                        else len(mapping)
                    )

                    logging.info(f"[{table_name}] Records attempted: {num_input}")
                    logging.info(f"[{table_name}] Mapped IDs returned: {num_mapped}")

                    if num_input != num_mapped:
                        logging.info( f"[{table_name}] Warning: record count mismatch input={num_input}, mapped={num_mapped})")
                    else:
                        logging.info(f"[{table_name}] Record counts match.")

                postgres_conn.commit()
                logging.info(f"[{table_name}] Records inserted or updated successfully.")

                return mapping if return_mapped_ids else None

        except Exception as e:
            postgres_conn.rollback()
            logging.info(f"[{table_name}] Error in update_partner_data_to_target_db: {e}")
            return {} if return_mapped_ids else None
    def build_target_details_df(self, mapping, target_db_name, tenant_id_flag=False, target_details_df=None):
        """
        Build DataFrame with id and target_details.
        Handles int, uuid, or string id types safely.

        Args:
            mapping (dict): 
                if tenant_id_flag = False → {"22": 7, "47": 12}
                if tenant_id_flag = True  → {"123": {"1": 3, "2": 5}, "1": {"1": 4}}
            target_db_name (str): target DB name
            tenant_id_flag (bool): handle multi-tenant mappings
            target_details_df (pd.DataFrame, optional): existing df with id,target_details

        Returns:
            pd.DataFrame: updated DataFrame with 'id' and 'target_details'
        """
        records = []

        if not tenant_id_flag:
            # Single tenant mapping
            for src_id, tgt_id in mapping.items():
                records.append({
                    "id": str(src_id),  # normalize to string
                    "target_details": {target_db_name: tgt_id}
                })
        else:
            # Multi-tenant mapping → collect multiple targets per src_id
            grouped = {}
            for src_id, tenant_map in mapping.items():
                grouped.setdefault(str(src_id), [])
                for _, tgt_id in tenant_map.items():
                    grouped[str(src_id)].append({target_db_name: tgt_id})

            for src_id, tgt_list in grouped.items():
                records.append({
                    "id": str(src_id),
                    "target_details": tgt_list
                })

        new_df = pd.DataFrame(records)

        if target_details_df is not None and not target_details_df.empty:
            # Normalize to string for safe merge (int, uuid, str all work)
            target_details_df = target_details_df.copy()
            target_details_df["id"] = target_details_df["id"].astype(str)

            merged_df = target_details_df.merge(new_df, on="id", how="left", suffixes=("", "_new"))

            # Safely combine details
            def combine_details(row):
                existing = row["target_details"]
                new = row["target_details_new"]

                # Handle None or NaN in existing
                if existing is None or (isinstance(existing, float) and pd.isna(existing)):
                    existing = []
                elif not isinstance(existing, list):
                    existing = [existing]

                # Handle None or NaN in new
                if new is None or (isinstance(new, float) and pd.isna(new)):
                    new = []
                elif not isinstance(new, list):
                    new = [new]

                return existing + new

            merged_df["target_details"] = merged_df.apply(combine_details, axis=1)
            merged_df = merged_df.drop(columns=["target_details_new"])
            return merged_df

        return new_df
    def update_data_history_table_bulk(self, postgres_conn, table_name, df, conflict_col):
        """
        Inserts or updates data in a PostgreSQL table based on conflict.
        Accepts a pandas DataFrame as input and serializes dict/list to JSON for jsonb columns.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            df (pd.DataFrame): Data to insert or update
            conflict_col (str or list): Column name(s) to check for conflicts
        """
        if df is None or df.empty:
            logging.info("[INFO] No data provided for insertion.")
            return

        try:
            with postgres_conn.cursor() as cursor:
                # Ensure conflict_col is a list
                conflict_cols = conflict_col if isinstance(conflict_col, list) else [conflict_col]

                # Extract columns from DataFrame
                columns = df.columns.tolist()

                # Serialize dict/list columns to JSON
                df_serialized = df.copy()
                for col in columns:
                    # Only serialize dict or list types
                    df_serialized[col] = df_serialized[col].apply(
                        lambda x: json.dumps(x) if isinstance(x, (dict, list)) else x
                    )

                # Prepare column strings
                columns_str = ", ".join(columns)
                conflict_cols_str = ", ".join(conflict_cols)

                # Prepare update set excluding conflict columns
                update_set = ", ".join(
                    [f"{col} = EXCLUDED.{col}" for col in columns if col not in conflict_cols]
                )

                # Construct the UPSERT query
                query = f"""
                    INSERT INTO {table_name} ({columns_str})
                    VALUES %s
                    ON CONFLICT ({conflict_cols_str})
                    DO UPDATE SET {update_set};
                """

                # Convert DataFrame to list of tuples
                values = [tuple(row) for row in df_serialized[columns].values]

                logging.info(f"Executing UPSERT on table {table_name}")
                execute_values(cursor, query, values)
                postgres_conn.commit()
                logging.info(f"[SUCCESS] {len(df)} records inserted/updated in {table_name}")

        except Exception as e:
            postgres_conn.rollback()
            logging.info(f"[ERROR] Failed to upsert data into {table_name}: {e}", exc_info=True)
    def build_where_clause_for_inv(self, table_name: str, condition_df_dict: dict) -> str:
        """
        Build SQL WHERE clause string from condition_df_dict directly.

        Args:
            table_name (str): Table name being processed.
            condition_df_dict (dict): Dict with {col_name: DataFrame or dict}.

        Returns:
            str: SQL WHERE clause.
        """
        final_where_part = {}
        tenant_clause = ""
        customer_names = []
        fans = []
        bans = []

        try:
            # Step 1: Normalize input into final_where_part
            for key, df in condition_df_dict.items():
                if isinstance(df, pd.DataFrame) and not df.empty:
                    final_where_part[key] = df
                else:
                    final_where_part[key] = pd.DataFrame()

            logging.info(f"[DEBUG] Final where part for {table_name}: {list(final_where_part.keys())}")

            # Step 2: Build tenant_id clause
            if "tenant_id" in final_where_part:
                df = final_where_part["tenant_id"]
                if isinstance(df, pd.DataFrame) and "partner_db_tenant_id" in df.columns:
                    tenant_vals = df["partner_db_tenant_id"].dropna().tolist()
                    if tenant_vals:
                        if len(tenant_vals) == 1:
                            tenant_clause = f"tenant_id = {tenant_vals[0]}"
                        else:
                            formatted = ", ".join([str(t) for t in tenant_vals])
                            tenant_clause = f"tenant_id IN ({formatted})"

            # Step 3: Collect customer_names
            if "customer_name" in final_where_part:
                df = final_where_part["customer_name"]
                if isinstance(df, pd.DataFrame) and "customer_names" in df.columns:
                    for val in df["customer_names"].dropna().tolist():
                        if isinstance(val, str) and val.strip().startswith("{"):
                            try:
                                parsed = json.loads(val)
                                customer_names.extend(list(parsed.values()))
                            except Exception:
                                customer_names.extend(re.findall(r'"([^"]+)"', val))
                        else:
                            customer_names.append(str(val).strip('"'))

            # Step 4: Collect FANs
            if "foundation_account_number" in final_where_part:
                df = final_where_part["foundation_account_number"]
                if isinstance(df, pd.DataFrame) and "tagged_fan" in df.columns:
                    fans = df["tagged_fan"].dropna().tolist()
                    if fans and isinstance(fans[0], str) and fans[0].startswith("["):
                        fans = json.loads(fans[0])

            # Step 5: Collect BANs
            if "billing_account_number" in final_where_part:
                df = final_where_part["billing_account_number"]
                if isinstance(df, pd.DataFrame) and "tagged_ban" in df.columns:
                    bans = df["tagged_ban"].dropna().tolist()
                    if bans and isinstance(bans[0], str) and bans[0].startswith("["):
                        bans = json.loads(bans[0])

            # Step 6: Build the OR clause
            or_clauses = []
            if customer_names:
                formatted = ", ".join([f"'{n}'" for n in customer_names])
                or_clauses.append(f"customer_name IN ({formatted})")

            if fans or bans:
                if fans and bans:
                    formatted_fans = ", ".join([f"'{f}'" for f in fans])
                    formatted_bans = ", ".join([f"'{b}'" for b in bans])
                    or_clauses.append(
                        f"(foundation_account_number IN ({formatted_fans}) "
                        f"AND billing_account_number IN ({formatted_bans}))"
                    )
                elif fans:
                    formatted_fans = ", ".join([f"'{f}'" for f in fans])
                    or_clauses.append(
                        f"(foundation_account_number IN ({formatted_fans}))"
                    )
                elif bans:
                    formatted_bans = ", ".join([f"'{b}'" for b in bans])
                    or_clauses.append(
                        f"(billing_account_number IN ({formatted_bans}))"
                    )

            # Step 7: Combine into WHERE clause
            if tenant_clause and or_clauses:
                return f"WHERE {tenant_clause} AND ({' OR '.join(or_clauses)})"
            elif tenant_clause:
                return f"WHERE {tenant_clause}"
            elif or_clauses:
                return f"WHERE {' OR '.join(or_clauses)}"
            else:
                return ""

        except Exception as e:
            logging.info(f"[ERROR] While building WHERE clause for {table_name}: {e}")
            return ""
        finally:
            logging.info(f"[INFO] Finished processing WHERE clause for {table_name}")
    def swap_fk_columns_based_on_tenant(self,df: pd.DataFrame, fk_col_col_target_mappings: dict) -> pd.DataFrame:
        """
        Swap foreign key column values in the DataFrame based on tenant-specific mappings.

        Args:
            df (pd.DataFrame): Input DataFrame containing tenant_id and foreign key columns.
            fk_col_col_target_mappings (dict): Mapping dictionary like:
                {
                    "customer_id": [None], 
                    "customer_rate_plan_id": [
                        {
                            "123": {"1": "3"},
                            "1": {"1": "4"}
                        }
                    ]
                }

        Returns:
            pd.DataFrame: Updated DataFrame with swapped values.
        """
        df = df.copy()

        for col, mappings_list in fk_col_col_target_mappings.items():
            if not isinstance(mappings_list, list) or not mappings_list:
                continue

            mapping_dict = mappings_list[0]  # actual tenant-wise mapping dict

            if not isinstance(mapping_dict, dict):
                continue

            if col not in df.columns:
                logging.info(f"[WARN] Column {col} not found in DataFrame, skipping...")
                continue

            # Process tenant-wise mappings
            for tenant_id, tenant_mapping in mapping_dict.items():
                if not isinstance(tenant_mapping, dict):
                    continue

                tenant_mask = df["tenant_id"].astype(str) == str(tenant_id)
                if not tenant_mask.any():
                    continue

                # Replace values for this tenant_id
                df.loc[tenant_mask, col] = (
                    df.loc[tenant_mask, col].astype(str).map(tenant_mapping).fillna(df.loc[tenant_mask, col])
                )

                logging.info(f"[INFO] Applied mapping for column '{col}' under tenant_id={tenant_id}")

        return df
    def sim_management_inventory_sync(
        self, table_name, where_cond, partner_db_conn, target_db_conn,
        common_utils_conn, partner_cond_dict, select_query, partner_db_name,
        fk_col_col_target_mappings,target_db_tenant_id, main_tenant_db_tenant_id,tenant_based_foreignkeyswapping,target_db_name,audit_id
    ):
        """
        Sync data for sim_management_inventory tables.

        Args:
            table_name (str): Table name to sync.
            where_cond (dict): Conditions for filtering.
            partner_db_conn: Connection object for partner DB.
            target_db_conn: Connection object for target DB.
            common_utils_conn: Connection for utility operations.
            partner_cond_dict (dict): Extra conditions for partner DB.
            select_query (str): Base query with placeholder for WHERE condition.
            partner_db_name (str): Source DB name for tracking.
            fk_col_col_target_mappings (dict): Mapping of foreign key columns.
        """
        try:
            logging.info(f"[START] Sync process initiated for table: `{table_name}`")

            # Step 1: Build WHERE conditions
            logging.info(f"[Step 1] Fetching initial sync mappings using condition: {where_cond}")
            where_condition_values_dict = self.fetch_details_from_partner_provider_initial_sync_mappings(
                where_cond, common_utils_conn, partner_cond_dict
            )
            logging.info(f"[Step 1.1] WHERE condition values retrieved: {where_condition_values_dict} "
                f"(Type: {type(where_condition_values_dict)})")

            final_where_part = self.build_where_clause_for_inv(table_name, where_condition_values_dict)
            logging.info(f"[Step 1.2] Final WHERE clause built: {final_where_part}")
            

            # Step 2: Replace WHERE condition in query
            replaced_query = select_query.replace("<where_cond>", final_where_part)
            replaced_query = f"{replaced_query} order by id"
            logging.info(f"[Step 2] Final SQL query prepared:{replaced_query}")
            #return True

            # Step 3: Start timer
            start_time = time.perf_counter()
            logging.info("[Step 3] Timer started for partner DB fetch...")

            # Step 4: Fetch FK mappings
            logging.info(f"[Step 4] Fetching foreign key mappings for columns: {fk_col_col_target_mappings}")
            foreign_key_mappings = self.fetching_foreignkey_values(
                fk_col_col_target_mappings, common_utils_conn, partner_cond_dict
            )
            logging.info(f"[Step 4.1] Foreign key mappings retrieved: {foreign_key_mappings}")

            logging.info(f"tenant_based_foreignkeyswapping {tenant_based_foreignkeyswapping}")
            
            tenant_based_foreing_key_mappings=self.fetching_foreignkey_values(
                tenant_based_foreignkeyswapping,common_utils_conn,partner_cond_dict
            )
            #return True
            logging.info(f"Forein key mappings based on tenant values gotten is { tenant_based_foreing_key_mappings}")
            # Step 5: Execute query on partner DB
            logging.info("[Step 5] Executing query on partner DB...")
            #inv_df=None
            
            
            inv_df = self.execute_query(partner_db_conn, replaced_query, params=None)
            logging.info(f"[Step 5.1] Rows fetched from partner DB: {len(inv_df)}")

            # Step 6: Add source DB column
            inv_df["source_db"] = partner_db_name
            logging.info(f"[Step 6] Added `source_db` column with value: {partner_db_name}")

            # Step 7: Timer end
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            logging.info(f"[Step 7] Partner data fetch completed in {elapsed_time:.2f} seconds")

            # Step 8: Clean dataframe (replace NaN with None)
            inv_df = inv_df.astype(object).mask(inv_df.isna(), None)
            logging.info("[Step 8] Null values replaced with None")
            logging.info(f"[Step 8.1] Sample rows after cleaning: {inv_df.head(2).to_dict(orient='records')}")

            # Step 9: Apply FK mappings
            logging.info("[Step 9] Applying foreign key mappings to dataframe...")
            inv_df_swapped = self.apply_foreign_key_mappings(inv_df,foreign_key_mappings)
            logging.info(f"[Step 9.1] Dataframe updated with FK mappings, sample rows: {inv_df_swapped.head(2).to_dict(orient='records')}")
            tenant_ids_list = [x for x in [target_db_tenant_id, main_tenant_db_tenant_id] if x is not None]

            logging.info(f"Tenant_id_list gotten is {tenant_ids_list}")
            inv_df_swapped.assign(tenant_id=[tenant_ids_list] * len(inv_df_swapped)).explode("tenant_id").reset_index(drop=True)
            self.swap_fk_columns_based_on_tenant(inv_df_swapped, fk_col_col_target_mappings)
            conflict_cols=["mobility_device_id","mdt_id"]
            batch_size = 5000
            
            inv_df_mobility = inv_df_swapped[inv_df_swapped['mobility_device_id'].notnull()]
            num_rows = len(inv_df_mobility)
            for start in range(0, num_rows, batch_size):
                end = min(start + batch_size, num_rows)
                batch_df = inv_df_mobility.iloc[start:end].copy()
                
                logging.info(f"Processing batch {start} to {end}...")
                
                batch_start_time = time.time()
                
                # Call your update function for this batch
                mapped_ids = self.update_partner_data_to_target_db(
                    target_db_conn,
                    table_name,
                    batch_df,
                    conflict_cols,
                    False
                )
                batch_end_time = time.time()
                elapsed = batch_end_time - batch_start_time
                logging.info(f"Batch {start}-{end} processed in {elapsed:.2f} seconds")


        except Exception as e:
            logging.info(f"[ERROR] Sync failed for table `{table_name}`: {e}", flush=True)
    def daily_sync_migration_func(self,data):
        """
            Creates daily synchronization job entries for processing source-to-target data sync.

            This function is responsible only for creating job records in the 
            `partner_provider_daily_sync_jobs` table. It does not execute or monitor the sync itself. 
            Each job defines a task for syncing data between the source and target databases 
            based on the active mappings available.

            Steps typically include:
            1. Fetching the required mapping information.
            2. Creating corresponding job entries.
            3. Setting default metadata (e.g., job status, created_date in UTC).
            4. Inserting the jobs into the database for later execution by the scheduler.

            Parameters:
                data (dict): Contains details such as source_db, target_db, main_tenant_db, 
                            and tenant IDs required to create daily sync jobs.

            Returns:
                bool: True if jobs are successfully created, False otherwise.
            """

        try:
            logging.info(f"=== Initial Sync Process Started === {data}")

            source_db = data.get("source_db")
            target_db = data.get("target_db")
            main_tenant_db = data.get("main_tenant_db")
            target_name=data.get("target_name")

            logging.info(f"[DEBUG] Step 0 - source_db: {source_db}")
            logging.info(f"[DEBUG] Step 0 - target_db: {target_db}")
            logging.info(f"[DEBUG] Step 0 - main_tenant_db: {main_tenant_db}")
            logging.info(f"[DEBUG] Step 0 - target_name: {target_name}")

            load_dotenv()
            common_utils_db = os.getenv("COMMON_UTILS_DB")
            host = os.getenv("PSQL_DB_HOST")
            db_type = os.getenv("PSQL_DB_TYPE")
            username = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            port = os.getenv("PSQL_DB_PORT")

            common_utils_conn = self.create_connection(db_type, host, common_utils_db, username, password, port)
            if common_utils_conn is None:
                logging.info("Failed to connect to Common Utils DB")
                return False

            details_query = """
                SELECT
                    table_name, fk_columns, fk_col_target_mapping, where_cond,
                    select_query, partner_name, partner_db_tenant_id :: integer, target_db,
                    target_db_tenant_id ::integer,  
                    main_tenant_db, migration_order :: integer,
                    tenant_id_flag, fk_flag, service_provider_mapping_flag,
                    main_tenant_db_tenant_id :: integer, fetch_based_ids, inv_flag, partner_db_host,target_db_host,modified_date,tenant_based_foreign_keyswapping
                FROM partner_provider_daily_sync_mappings
                WHERE (target_name=%s or  target_db = %s )
                AND partner_name = %s and table_name='sim_management_inventory'
                ORDER BY migration_order ASC;
            """
            df = self.execute_query(common_utils_conn, details_query, (target_name, target_db, source_db))
            df = df.astype(object).mask(df.isna(), None)
            logging.info(f"[Step 1] Retrieved {len(df)} mapping rows {df.head(10)}")
            
            if df.empty:
                logging.info("No matching records found. Skipping insert.")
                common_utils_conn.close()
                return False
            for index, row in df.iterrows():
                logging.info(f"--- Processing mapping row {index + 1} of {len(df)} ---")
                table_name = row["table_name"]
                fk_columns = row["fk_columns"]
                fk_col_target_mapping = row["fk_col_target_mapping"]
                where_cond = row["where_cond"]
                select_query = row["select_query"]
                partner_db_tenant_id = row.get("partner_db_tenant_id")
                target_db_tenant_id = row.get("target_db_tenant_id")
                mapped_ids = row.get("mapped_ids")
                return_mapped_ids = row.get("return_mapped_ids")
                main_tenant_db = row.get("main_tenant_db")
                migration_order = row.get("migration_order")
                partner_db_name = row.get("partner_name")
                target_db_name = row.get("target_db")
                tenant_id_flag = row.get("tenant_id_flag")
                fk_flag = row.get("fk_flag")
                main_tenant_db_tenant_id = row.get("main_tenant_db_tenant_id")
                tenant_based_mappings_flag = row.get("tenant_based_mappings_flag")
                tenant_based_mappings = row.get("tenant_based_mappings")
                fetch_based_ids = row.get("fetch_based_ids")
                inv_flag=row.get("inv_flag")
                modified_date=row.get("modified_date")
                tenant_based_foreignkeyswapping=row.get("tenant_based_foreign_keyswapping")

                logging.info(f"[Step 2] Table='{table_name}' | PartnerDB='{partner_db_name}' | TargetDB='{target_db_name}' | MigrationOrder={migration_order}")

                # --- Step 5: Create DB connections ---
                partner_db_conn = self.create_connection(db_type, host, partner_db_name, username, password, port)
                target_db_conn = self.create_connection(db_type, host,  target_db_name, username, password, port)
                logging.info(f"[Step 3] Connections => PartnerDB={'OK' if partner_db_conn else 'FAILED'} | TargetDB={'OK' if target_db_conn else 'FAILED'}")
                audit_insert_query = """
                    INSERT INTO public.pbp_auditing
                    (partner_name, partner_db_tenant_id, target_db, target_db_tenant_id, target_name,
                    main_tenant_db, main_tenant_db_tenant_id, table_name, status, details, started_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,  TIMEZONE('UTC', NOW()))
                    RETURNING id;
                """
                audit_params = (
                partner_db_name,                # partner_name
                partner_db_tenant_id,     # partner_db_tenant_id
                target_db,                # target_db
                target_db_tenant_id,      # target_db_tenant_id
                target_db_name,           # target_name
                main_tenant_db,           # main_tenant_db
                main_tenant_db_tenant_id, # main_tenant_db_tenant_id
                table_name,               # table_name
                "DAILY SYNC IN_PROGRESS",            # status
                None                      # details (can be JSON later)
                )


                audit_id = self.insert_audit_record(common_utils_conn, audit_insert_query, audit_params)
                logging.info(f"[Step 4] Inserted Audit ID:  {audit_id}")
                
                if main_tenant_db_tenant_id:
                    partner_cond_dict = {
                        "partner_db_tenant_id": partner_db_tenant_id,
                        "target_db_tenant_id": target_db_tenant_id,
                        "main_tenant_db_tenant_id": main_tenant_db_tenant_id
                    }
                    logging.info(f"[Step 5] Using main_tenant_db_tenant_id={main_tenant_db_tenant_id}")
                else:
                    partner_cond_dict = {
                        "partner_db_tenant_id": partner_db_tenant_id,
                        "target_db_tenant_id": target_db_tenant_id
                    }
                    logging.info("[Step 5] No main_tenant_db_tenant_id, using only partner_db_tenant_id & target_db_tenant_id")
                logging.info(f"[Step 6] Partner condition dict: {partner_cond_dict}")

                # --- Step 7: Handle WHERE conditions ---
                logging.info(f"[Step 7] Raw WHERE condition={where_cond} | fetch_based_ids_flag={fetch_based_ids} | INV flag {inv_flag}")
                
                if inv_flag:
                    logging.info(f"This function Is used to sync the inventory tables only {inv_flag} {table_name} {partner_cond_dict}")
                    self.sim_management_inventory_sync(table_name,where_cond,partner_db_conn,target_db_conn,common_utils_conn,partner_cond_dict,select_query,partner_db_name,fk_col_target_mapping,target_db_tenant_id, main_tenant_db_tenant_id,tenant_based_foreignkeyswapping,target_db_name,audit_id)
                    return True
                if fetch_based_ids:
                    logging.info(f"[Step 7.1] fetch_based_ids flag is TRUE → resolving with fetch_mapped_keys()")
                    cleared_conditions = self.fetch_mapped_keys(common_utils_conn, where_cond, partner_cond_dict)
                else:
                    final_where_part = self.fetch_details_from_partner_provider_initial_sync_mappings(where_cond, common_utils_conn, partner_cond_dict)
                    logging.info(f"[Step 7.1] WHERE condition values resolved: {final_where_part}")
                    cleared_conditions = self.extract_values_from_conditions(final_where_part)
                logging.info(f"[Step 7.2] Cleared WHERE condition values:{select_query} {cleared_conditions}")
                
                
                # --- Step 8: Build final query ---
                final_query = self.build_dynamic_query(select_query, cleared_conditions)
                logging.info(f"[Step 8] Final SELECT query built:{final_query}")
                modified_date_filter = f"modified_date > '{modified_date}'"
                final_query=final_query.replace(";","")
                final_query += f" AND {modified_date_filter}"
                logging.info(f"Final query after updating modified_date {final_query}")
                #return True
                partner_df = self.execute_query(partner_db_conn, final_query, params=None)
                if partner_df.empty:
                    logging.info(f"[Step 10] No data present in partner DB for table '{table_name}', skipping to next table")
                    continue  # move to next row in the loop
                partner_df["source_db"] = partner_db_name
                logging.info(f"[Step 9] Partner data fetched: {len(partner_df)} rows")

                if not partner_df.empty:
                    logging.info(f"[Step 9] Sample rows: {partner_df.head(2).to_dict(orient='records')}")

                # --- Step 10: Handle foreign keys ---
                if fk_flag and not tenant_based_mappings_flag:
                    logging.info(f"[Step 10] Resolving foreign keys for {table_name} | fk_flag={fk_flag}")
                    foreign_key_mappings = self.fetching_foreignkey_values(fk_col_target_mapping, common_utils_conn, partner_cond_dict)
                    logging.info(f"[Step 10] Foreign key mappings retrieved: {foreign_key_mappings}")
                    partner_df = self.apply_foreign_key_mappings(partner_df, foreign_key_mappings)
                    logging.info(f"[Step 10] Partner dataframe updated with FK mappings, sample: {partner_df.head(2).to_dict(orient='records')}")
                tenant_ids_list = [x for x in [target_db_tenant_id, main_tenant_db_tenant_id] if x is not None] if tenant_id_flag else []
                conflict_cols = ["source_db", "source_id", "tenant_id"] if tenant_id_flag else ["source_db", "source_id"]
                logging.info(f"[Step 11] Tenant handling | tenant_id_flag={tenant_id_flag} | tenant_ids_list={tenant_ids_list}")
                partner_df = partner_df.astype(object).mask(partner_df.isna(), None)
                logging.info(f"[Step 12] Partner df {partner_df.head(5)}")
                if not tenant_id_flag:
                    query_to_get_ids = """
                        SELECT mapped_ids
                        FROM partner_provider_initial_sync_mappings
                        WHERE (target_name = %s OR target_db = %s)
                        AND partner_name = %s AND table_name=%s;
                    """
                    mapped_ids_df = self.execute_query(common_utils_conn, query_to_get_ids, (target_name, target_db, source_db,table_name))
                    logging.info(f"Mapped ids gotten are {mapped_ids_df.head(10)} {type(mapped_ids_df)}")
                    # Convert mapped_ids JSON to a Python dict
                    if not mapped_ids_df.empty and "mapped_ids" in mapped_ids_df.columns:
                        mapped_ids_raw = mapped_ids_df.iloc[0]["mapped_ids"]

                        try:
                            # Ensure mapped_ids is a valid dictionary
                            if isinstance(mapped_ids_raw, str):
                                mapped_ids = json.loads(mapped_ids_raw)
                            elif isinstance(mapped_ids_raw, dict):
                                mapped_ids = mapped_ids_raw
                            else:
                                mapped_ids = {}
                        except Exception as e:
                            logging.info(f"[ERROR] Failed to parse mapped_ids JSON: {e}")
                            mapped_ids = {}

                        logging.info(f"[DEBUG] Parsed mapped_ids keys count: {len(mapped_ids)}")
                    else:
                        mapped_ids = {}
                        logging.info("[INFO] No mapped_ids found, treating as empty dictionary.")

                    # Extract the mapped keys (as strings to match DataFrame dtype)
                    mapped_keys = set(str(k) for k in mapped_ids.keys())

                    # Ensure source_id is string for comparison consistency
                    partner_df["source_id"] = partner_df["source_id"].astype(str)

                    # Split DataFrame into two parts based on presence in mapped_ids
                    partner_df_in_mapped = partner_df[partner_df["source_id"].isin(mapped_keys)].copy()
                    partner_df_not_in_mapped = partner_df[~partner_df["source_id"].isin(mapped_keys)].copy()

                    # Debug summaries
                    logging.info(f"[Step 13] partner_df_in_mapped: {len(partner_df_in_mapped)} rows found in mapped_ids.")
                    logging.info(f"[Step 14] partner_df_not_in_mapped: {len(partner_df_not_in_mapped)} rows not found in mapped_ids.")
                    logging.info(f"[DEBUG] Sample from in_mapped: {partner_df_in_mapped.head(3).to_dict(orient='records')}")
                    logging.info(f"[DEBUG] Sample from not_in_mapped: {partner_df_not_in_mapped.head(3).to_dict(orient='records')}")
                    if len(partner_df_in_mapped) > 0:
                        self.update_partner_data_to_target_db(target_db_conn, table_name, partner_df_in_mapped, conflict_cols, return_mapped_ids=False)
                    if len(partner_df_not_in_mapped)>0:
                        new_mapped_ids = self.update_partner_data_to_target_db(target_db_conn, table_name, partner_df_not_in_mapped, conflict_cols, return_mapped_ids=True)
                        logging.info(f"New records are inserted {new_mapped_ids} {type(new_mapped_ids)}")
                        logging.info(f"old mapped ids are mapped_ids {mapped_ids} {type(mapped_ids)}")
                        combined_ids = {**mapped_ids, **new_mapped_ids}
                        logging.info(f"Combined mapped IDs: {combined_ids}")

                        try:
                            new_ids = list(new_mapped_ids.keys())
                            if new_ids:
                                placeholders = ', '.join(['%s'] * len(new_ids))
                                target_details_query = f"""
                                    SELECT id, target_details 
                                    FROM {table_name} 
                                    WHERE id IN ({placeholders})
                                """
                                logging.info(f"[Step 13] Fetching target details for new IDs: {new_ids} {target_db_conn}")
                                target_details_df = self.execute_query(partner_db_conn, target_details_query, tuple(new_ids))
                                logging.info(f"{tenant_id_flag}[DEBUG] Target Details DF (first 5 records): {target_details_df.head(5)}")
                                target_details_updated_df=self.build_target_details_df(new_mapped_ids,target_db_name,tenant_id_flag,target_details_df)
                                logging.info(f"[DEBUG] Updated Target Details DF (first 5 records): {target_details_updated_df.head(5)}")
                                #self.update_data_history_table_bulk(partner_db_conn,table_name,target_details_updated_df,conflict_col=["id"])
                                update_dict={"mapped_ids":json.dumps(combined_ids)}
                                condition_dict = {**partner_cond_dict, "table_name": table_name}
                                self.update_table(common_utils_conn,"partner_provider_initial_sync_mappings",update_dict,condition_dict)
                            else:
                                logging.info("[Step 13] No new IDs found. Skipping target details fetch. {e}")
                                cond_dict = {"id": audit_id}
                                update_dict = {"status": "FAILED", "error_msg": str(e), "completed_at":  datetime.now(timezone.utc)}
                                self.update_table(common_utils_conn,"pbp_auditing",update_dict,cond_dict)
                                return False

                        except Exception as e:
                            logging.info(f"[ERROR] Error while updating target details: {table_name} {e}")
                            cond_dict = {"id": audit_id}
                            update_dict = {"status": "FAILED", "error_msg": str(e), "completed_at":  datetime.now(timezone.utc)}
                            self.update_table(common_utils_conn,"pbp_auditing",update_dict,cond_dict)
                else:
                    if tenant_ids_list:
                        expanded_df = partner_df.assign(tenant_id=[tenant_ids_list] * len(partner_df)).explode("tenant_id").reset_index(drop=True)
                        logging.info(f"[DEBUG] Expanded DF rows={len(expanded_df)} | Sample={expanded_df.head(2).to_dict(orient='records')}")
                        mapped_ids = self.update_partner_data_to_target_db(target_db_conn, table_name, expanded_df, conflict_cols, return_mapped_ids, tenant_id_flag)
                cond_dict = {"id": audit_id}
                update_dict = {"status": "DAILY SYNC SUCCESS", "completed_at":  datetime.now(timezone.utc)}
                self.update_table(common_utils_conn,"pbp_auditing",update_dict,cond_dict)
                logging.info(f"[Step 14] Audit table updated for audit_id={audit_id}")
                sync_cond_dict={**partner_cond_dict,"table_name":table_name}
                data_dict={"modified_date": datetime.now(timezone.utc)}
                self.update_table(common_utils_conn,"partner_provider_daily_sync_mappings",update_dict,cond_dict)
                return True


        except Exception as e:
            logging.info(f"Error during copy_initial_to_daily_sync: {e}")
            cond_dict = {"id": audit_id}
            update_dict = {"status": "FAILED", "error_msg": str(e), "completed_at":  datetime.now(timezone.utc)}
            self.update_table(common_utils_conn,"pbp_auditing",update_dict,cond_dict)
            return False
        


if __name__ == "__main__":
    scheduler = MigrationScheduler()
    load_dotenv()

    payload = {
        "path": "/intial_sync_mappings",
        "access_token": None,
        "source_db": "altaworx_go_tech",
        "partner_db_tenant_id": 181,
        "target_db": "partner_test_db",
        "target_name": "Provider Testing",
        "target_db_tenant_id": 1210,
        "main_tenant_db": "partner_test_db",
        "main_tenant_db_tenant_id": 212
    }

    logging.info("Running copy_initial_to_daily_sync process...")
    #scheduler.creating_daily_sync_jobs_forpbp(payload)
    #scheduler.daily_sync_migration_func(payload)
