from opensearchpy import OpenSearch, helpers
import psycopg2
from datetime import datetime, timedelta
import uuid
import math
import ast
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import pandas as pd
import boto3
import psycopg2
import io
import concurrent.futures
import logging
import time
from io import BytesIO
from datetime import datetime
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
import threading  # For asynchronous execution
import time
from io import StringIO
import json
from ast import literal_eval
from decimal import Decimal, InvalidOperation
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import re
import pytz
from pytz import timezone
import datetime
from tempfile import TemporaryDirectory  # Add this import
import zipfile
from functools import reduce
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from dateutil.relativedelta import relativedelta
from dateutil import parser
from requests import get
from decimal import Decimal, ROUND_HALF_UP, ROUND_DOWN
import csv
import xlsxwriter
import numpy as np

logging = Logging(name="opensearch")

db_config = {  
    'port': os.getenv('PORT'),      
    'user': os.getenv('USER'),     
    'password': os.getenv('PASSWORD'),
    "multi_schema":False,
}


es = None
current_db_name = None
is_excluded_flag = None
# Connect to OpenSearch
# es = OpenSearch(
#     [os.getenv('Opensearch_URL')],
#     http_auth=(os.getenv('Opensearch_USERNAME'), os.getenv('Opensearch_PASSWORD')),
#     use_ssl=True,
#     verify_certs=True,
#     timeout=120
# )



def initialize_opensearch(db_name,index_name):
    """
    Initializes the OpenSearch client using db_name for host lookup.
    """
    
    global es, current_db_name, is_excluded_flag

    excluded_indexes = [
        'tenant_based_banners_logs', 'tenant_based_banners',
        'partner_users', 'carrier_apis', 'amop_apis',
        'email_audit', 'email_templates', 'Central_bulk_change', 'Central_optimization'
    ]

    current_flag = index_name in excluded_indexes
    logging.info(f"Initializing OpenSearch for {db_name}, excluded_flag={current_flag}")
    # logging.info(f"Initializing OpenSearch client for {es}")
    if es is not None and current_db_name == db_name and is_excluded_flag == current_flag:
        logging.info(f"Reusing existing OpenSearch client for {db_name} (excluded_flag={current_flag})")
        return es

    try:
        config = get_opensearch_config(db_name,index_name)
        es = OpenSearch(**config)
        current_db_name = db_name  # Store current db for validation
        is_excluded_flag = current_flag
        
        # Health check
        health = es.cluster.health(wait_for_status='yellow', timeout=10)
        logging.info(f"OpenSearch client initialized for {db_name}: status {health['status']}")
        return es
    except Exception as e:
        logging.error(f"Failed to connect to OpenSearch: {e}")
        es = None
        current_db_name = None
        is_excluded_flag = None

    return es


def get_opensearch_config(db_name, index_name, ssm_param_name='OS_URL'):
    """
    Retrieves OpenSearch host URL for a given db_name from SSM JSON parameter.
    Constructs and returns the OpenSearch client configuration.
    Falls back to environment variables if not found.
    """
    start_time = time.time()
    logging.info(f"Fetching OpenSearch config for {db_name} index name {index_name}")
    if index_name in ["Central_bulk_change", "Central_optimization"]:
        db_name = "central_db"
    host_url = get_ssm_parameter(ssm_param_name, db_name)
    elapsed_time = time.time() - start_time
    logging.info(f"OpenSearch config fetch time: {elapsed_time:.4f} seconds")
    if host_url and index_name not in ['tenant_based_banners_logs','tenant_based_banners','partner_users','carrier_apis','amop_apis','email_audit','email_templates']:
        # Assume host_url is like "https://opensearch-db.example.com"
        # Use existing env vars for auth and other settings
        opensearch_config = {
            'hosts': [host_url],  # Or directly use host_url if single string
            'http_auth': (os.getenv('Opensearch_USERNAME'), os.getenv('Opensearch_PASSWORD')),
            'use_ssl': True,
            'verify_certs': True,
            'timeout': 60,
        }
        logging.info(f"Retrieved OpenSearch host '{host_url}' for {db_name} from SSM")
        return opensearch_config
    else:
        logging.info(f"OpenSearch host not found for {db_name}, using default from env")
        # Fallback to original env-based config
        return {
            'hosts': [os.getenv('Opensearch_URL')],
            'http_auth': (os.getenv('Opensearch_USERNAME'), os.getenv('Opensearch_PASSWORD')),
            'use_ssl': True,
            'verify_certs': True,
            'timeout': 60,
        }


def get_ssm_parameter(param_name, tenant_name, decrypt=True):
    """
    Fetches the parameter value from AWS SSM Parameter Store.
    Returns the value corresponding to tenant_name key in the JSON parameter.
    """
    
    try:
        ssm = boto3.client("ssm")
        # Full path to the parameter
        param_name = f"/AMOP/BETA/{param_name}"
        response = ssm.get_parameter(Name=param_name, WithDecryption=decrypt)
        param_value = response["Parameter"]["Value"]

        try:
            param_json = json.loads(param_value)
        except json.JSONDecodeError:
            logging.info(f"Warning: Parameter {param_name} is not valid JSON, returning raw value.")
            return None

        # Return value for the requested tenant_name
        value = param_json.get(tenant_name)
        if value is None:
            logging.info(f"Tenant '{tenant_name}' not found in parameter {param_name}")
        return value

    except Exception as e:
        logging.info(f"Error fetching SSM parameter {param_name}: {str(e)}")
        return None


def get_db_config(db_name):
    """
    Dynamically updates db_config['host'] based on db_name and returns the config.
    """
    start_time = time.time()
    host = get_ssm_parameter('RDS_HOST', db_name)  # Replace 'database_hosts' with your actual SSM param_name
    elapsed_time = time.time() - start_time
    logging.info(f"Function execution time: {elapsed_time:.4f} seconds")
        
    if host:
        db_config['host'] = host
    else:
        logging.warning(f"Host not found for db_name '{db_name}', using default from env")
    return db_config


def get_tenant_id(tenant_name):
    try:
        # Establish connection
        database = DB("common_utils", **get_db_config("common_utils"))  # Assuming DB is a predefined class for database connection
        query = f"""
            SELECT id 
            FROM tenant 
            WHERE tenant_name = '{tenant_name}';
        """

        df = database.execute_query(query, True)  # Execute query and return result
        if not df.empty:
            id = df.iloc[0]["id"]  # Extract the "id" value from the first row
            logging.info(f"### get_tenant_id {id}")
            return id  # Return the ID
        logging.info(f"### No tenant found with name: {tenant_name}")
        return None  # Return None if no record is found

    except Exception as e:
        logging.info(f"### Error occured: {e}")
        return None
    finally:
        if database:
            database.close()

def create_filter_clause(index_list, custom_filter,index_name):
    filter_clauses = []

    # Check if a custom_filter dictionary is provided
    if custom_filter:
        for field, value in custom_filter.items():
            # Only include fields that exist in the index
            if is_field_present(index_list, field):
                filter_clauses.append({"term": {field: value}})
    
    if index_name == 'Billing and Payments Billing':
        filter_clauses.append({"range": {"amount_due": { "gt": 0 }}})

    # if index_name == 'Unposted':
    #     filter_clauses.append({"range": {"charge_amount": { "gt": 0 }}})


    # If no filters were added, return None
    if not filter_clauses:
        return None

    # Return the filter clauses
    return filter_clauses

def is_date(date_str, input_format="%m-%d-%Y"):
    """
    Checks if a given string is a valid date in the specified format. Returns True if valid, False otherwise.
    """
    try:
        date_str=datetime.datetime.strptime(date_str, input_format)
        # print("date_str ---",date_str)
        return date_str
    except ValueError:
        return False

def convert_to_opensearch_date_format(date_str, input_format="%m-%d-%Y"):
    """
    Converts a date string from the specified input format to OpenSearch format (YYYY-MM-DDTHH:mm:ss).
    """
    parsed_date = datetime.datetime.strptime(date_str, input_format)
    return parsed_date.strftime("%Y-%m-%d")

def normalize_numeric_commas(text):
    """
    Removes commas only from numeric values inside the text.
    Examples:
    '1,234' -> '1234'
    'Tax 12,345.67' -> 'Tax 12345.67'
    'INV-1,234' -> 'INV-1234'
    """
    return re.sub(
        r'(?<!\d)(-?\d{1,3}(?:,\d{3})+(?:\.\d+)?)',
        lambda m: m.group(1).replace(',', ''),
        text
    )

def search_data(query, search_all_columns, index_list,start,end,columns,db_name, custom_filter,page_flag,index_name,col_sort,tenant_name,role):
    index = index_list
    logging.info(f"custom_filter -- {custom_filter}")
    if index_name == "Inventory":
        columns.append("account_number")
    logging.info("page_flag -- %s",page_flag)
    if '$' in query and 'Tax' not in query:
        query = query.replace('$', '')  # Remove dollar sign
    
    if query.endswith('.'):
        query = query[:-1]
    # if re.fullmatch(r'[\d,]+', query):
    #     query = query.replace(',', '')
    query = normalize_numeric_commas(query)
    # print("query --- ", query)
    if is_date(query):
        # print("query --- ",query)
        query = convert_to_opensearch_date_format(query)
    if index_name in ["Inventory", "inventory_export", "daily_usage_report_export","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
        try:
            database = DB("common_utils", **get_db_config("common_utils"))

            # Query to check if it's a subtenant
            parent_tenant_query = f'''SELECT parent_tenant_id FROM tenant WHERE tenant_name='{tenant_name}' '''
            parent_tenant_id_df = database.execute_query(parent_tenant_query, True)

            if not parent_tenant_id_df.empty:
                parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                if parent_tenant_id is not None:
                    # Update columns if needed
                    updated_columns = []
                    for col in columns:
                        if col == 'carrier_rate_plan_name' or col == "carrier_rate_plan":
                            updated_columns.append('sub_tenant_carrier_rate_plan_name')
                        elif col == 'customer_rate_plan_name':
                            updated_columns.append('sub_tenant_customer_rate_plan_name')
                        else:
                            updated_columns.append(col)
                    columns = list(set(updated_columns))  # remove duplicates if any
        except Exception as e:
            logging.info(f"An error occurred while searching: {e}")
        finally:
            if database:
                database.close()

    columns = [col for col in columns if col and col != "is_active"]
    columns=list(set(columns))
    search_body = {
        "query": {
            "bool": {
                "must": [],
                "should": [
                    
                    {
                        "multi_match": {
                            "query": str(query),
                            "fields": columns,
                            "type": "bool_prefix",
                            "operator": "and",
                            "lenient": True
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        },
        "from": start,
        "size": end - start,
        "track_total_hits": True
    }
    # if db_name == "altaworx_central":
    #     index=index_name
    # else:
    #     index=f"{index_name}_{db_name}"
    


    # print("************",columns)
    sort_clause = None
    if index_name == "automation_rule_log":
        if is_field_present(index_list, 'id'):
            sort_clause = [
                {
                    "id.keyword": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name in ["customer_optimization_list_view", "carrier_optimization_list_view"]:
        if is_field_present(index_list, 'run_start_time'):
            sort_clause = [
                {
                    "run_start_time": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name == "action_history_report":
        # Apply last one year filter
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_month_date = (datetime.datetime.utcnow() - relativedelta(months=1)).strftime("%Y-%m-%d")

        date_filter = {
            "range": {
                "date_of_change": {
                    "gte": last_month_date,  # From one year ago
                    "lte": current_date     # Up to the present date
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_filter)
    elif index_name == "Usage Details":
        usage_filter = {
            "bool": {
                "should": [
                    {
                        "range": {
                            "usage_mb": {
                                "gt": 0
                            }
                        }
                    },
                    {
                        "range": {
                            "sms_cost": {
                                "gt": 0
                            }
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        }
        search_body["query"]["bool"]["must"].append(usage_filter)
    elif index_name == "partner_users":
        logging.info(f"### partner_users role: {role}, tenant_name: {tenant_name}")
        role_order = [
            "Partner Admin",
            "Agent Partner Admin",
            "Agent",
            "User",
            "Notification Only User",
            "Qualification Only User"
        ]
        if role and role != "Super Admin":
            if role in role_order:
                supported_role = role_order[role_order.index(role):]
                usernames = get_usernames(tenant_name, supported_role)
                should_queries = []
                for r in supported_role:
                    should_queries.append({"wildcard": {"role.keyword": f"*{r}*"}})

                role_filters = {
                    "bool": {
                        "should": should_queries,
                        "minimum_should_match": 1
                    }
                }
                username_filters = {
                    "terms": {
                        "username.keyword": usernames
                    }
                }
                search_body["query"]["bool"]["must"].append(role_filters)
                search_body["query"]["bool"]["must"].append(username_filters)
                logging.info(f"### Supported roles: {supported_role}")
            else:
                logging.warning(f"### Role {role} not found in role_order")
        else:
            logging.info("### Super admin: No role-based filtering applied")
    else:
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    if index_name == "Charge Details":
        search_body["query"]["bool"].setdefault("must_not", []).append({
            "terms": {
                "category.keyword": ["MRC", "Credit"]
            }
        })
    if col_sort:
        try:
            # Extract field and order from the key
            field_to_sort, sort_order = next(iter(col_sort.items()))  
            sort_order = sort_order.lower()  # Normalize to lowercase

            # Get the field type (Assuming `get_field_type` is a defined function)
            field_type = get_field_type(index_list, field_to_sort)

            # Modify field_to_sort if it is of type "text"
            if field_type == "text":
                field_to_sort = f'{field_to_sort}.keyword'

            # Check if the field and sort order are valid
            if field_to_sort and sort_order in ["asc", "desc"]:
                sort_clause = [{field_to_sort: {"order": sort_order}}]  # Override default sort with key sorting
            else:
                logging.info("Invalid sorting key: Ensure the format is {<field_name>: 'asc'/'desc'}.")
        except StopIteration:
            logging.info("Error: The provided 'key' dictionary is empty or invalid.")
        except Exception as e:
            logging.info(f"An error occurred: {e}")
    
    if sort_clause:
        search_body["sort"] = sort_clause
    
    # if page_flag == "Pagination":
    #     search_body["from"] = start  # Calculate the offset
    #     search_body["size"] = end - start  # Number of results per page
    # else:
    #     # If no pagination, use a scroll API or other mechanism to fetch all results
    #     search_body["scroll"] = "1m"   # OpenSearch max size per query (adjust as needed)
    #     print("Fetching all results without pagination.")
    # print("Search_Body",search_body)
    filter_clause=create_filter_clause(index_list,custom_filter,index_name)
    if filter_clause:
        search_body["query"]["bool"]["filter"] = filter_clause
    search_body = add_customer_exists_filters(search_body, index_name, tenant_name, db_config)
    
    if index_name == "Active_lines_report":
        search_body["query"]["bool"]["must"].append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A","ACTIVATED"]
            }
        })
        logging.info(f"whole Search query {search_body}")
    elif index_name == "Customers":
        logging.info("adding rev_customer_id is null filter")
        if "must_not" not in search_body["query"]["bool"]:
            search_body["query"]["bool"]["must_not"] = []
        search_body["query"]["bool"]["must_not"].append({
            "exists": {"field": "rev_customer_id"}
        })
    elif index_name in ['Billing Report w/_City_County_Country','AR Aging Report','Export Variance Billing','Billing report by day with OCC Report','Total MRC for Sales Person: Catapult']:
        logging.info("adding bill_reversed_date is null filter")
        date_trunc_filter = {
            "script": {
                "script": {
                    "lang": "painless",
                    "source": """
                        if (doc['bill_reversed_date'].size() == 0) {
                            return true;
                        }

                        ZonedDateTime created = doc['created_date'].value;
                        ZonedDateTime reversed = doc['bill_reversed_date'].value;

                        return created.getYear() != reversed.getYear()
                            || created.getMonthValue() != reversed.getMonthValue();
                    """
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_trunc_filter)
    elif index_name in ["zero_usage_report", "usp_report_customer_usage_by_line", "usage_by_line_report", "newly_activated_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### adding customer_name, customer_id is not null filter")
            if "must" not in search_body["query"]["bool"]:
                search_body["query"]["bool"]["must"] = []
            search_body["query"]["bool"]["must"].extend([
                {"exists": {"field": "customer_id"}},
                {"term": {"customer_is_active": True}}
            ])
        else:
            logging.info("### Skipping customer_name, customer_id is not null filter. Due to main tenant")
    elif index_name in ["status_history_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### adding customer_id is not null filter")
            if "must" not in search_body["query"]["bool"]:
                search_body["query"]["bool"]["must"] = []
            search_body["query"]["bool"]["must"].extend([
                {"exists": {"field": "customer_id"}}
            ])
        else:
            logging.info("### Skipping customer_id is not null filter. Due to main tenant")

    logging.info(f"### whole search {search_body}")
    try:
        # if index_name == "sim_management_bulk_change" and page_flag == 'Pagination':
        #     # Scroll API for "bulk change" index
        #     scroll_time = "1m"
        #     scroll_size = 1000
        #     all_hits = []

        #     response = es.search(index=index, body=search_body, scroll=scroll_time, size=scroll_size)
        #     all_hits.extend(response.get("hits", {}).get("hits", []))
        #     scroll_id = response.get("_scroll_id")

        #     # Scroll through the results
        #     while len(response.get("hits", {}).get("hits", [])) > 0:
        #         response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
        #         all_hits.extend(response.get("hits", {}).get("hits", []))

        #     # Clear the scroll context
        #     es.clear_scroll(scroll_id=scroll_id)

        #     # Group records by `bulk_change_id`
        #     grouped_sources = {}
        #     for hit in all_hits:
        #         source = hit.get("_source", {})
        #         bulk_id = source.get("bulk_change_id")
        #         if bulk_id and bulk_id not in grouped_sources:
        #             grouped_sources[bulk_id] = hit

        #     # Prepare paginated results
        #     grouped_hits = list(grouped_sources.values())
        #     total_records = len(grouped_hits)
        #     paginated_hits = grouped_hits[start:end]

        #     results = {
        #         "hits": {
        #             "hits": paginated_hits,
        #             "total": {"value": total_records}
        #         }
        #     }
        #     # print(f"Grouped results count: {total_records}, returning {len(paginated_hits)} records.")
        #     # return replace_none_with_empty(results, index),total_records
        #     return results,total_records

        if index_name == "sim_management_bulk_change" and page_flag == 'Pagination':
            # Use aggregations for efficient grouping by bulk_change_id
            agg_body = {
                "query": search_body.get("query", {}),
                "size": 0,  # We don't need the actual documents here
                "aggs": {
                    "unique_bulk_ids": {
                        "terms": {
                            "field": "bulk_change_id",
                            "size": 10000,  # Adjust based on expected unique IDs
                            "order": {"latest_date": "desc"}
                        },
                        "aggs": {
                            "latest_date": {
                                "max": {
                                    "field": "modified_date"
                                }
                            },
                            "top_hit": {
                                "top_hits": {
                                    "size": 1,
                                    "sort": [{"modified_date": {"order": "desc"}}]
                                }
                            }
                        }
                    }
                }
            }


            
            response = es.search(index=index, body=agg_body)
            buckets = response.get("aggregations", {}).get("unique_bulk_ids", {}).get("buckets", [])
            
            # Extract the top hit from each bucket
            grouped_hits = []
            for bucket in buckets:
                top_hits = bucket.get("top_hit", {}).get("hits", {}).get("hits", [])
                if top_hits:
                    grouped_hits.append(top_hits[0])
            
            # Apply pagination
            total_records = len(grouped_hits)
            paginated_hits = grouped_hits[start:end]
            
            results = {
                "hits": {
                    "hits": paginated_hits,
                    "total": {"value": total_records}
                }
            }
            
            return results, total_records,search_body
        elif start<10000 and page_flag == 'Pagination':
            # Regular search for non-bulk-change indices
            response = es.search(index=index, body=search_body)
            total_records = response['hits']['total']['value']
            if index_name in ["Inventory", "inventory_export", "daily_usage_report_export","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
                
                logging.info(f"### Checking tenant information for tenant_name: {tenant_name}")
                database = DB("common_utils", **get_db_config("common_utils"))
                
                tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
                
                if not tenant_data.empty:
                    tenant_id = tenant_data["id"].to_list()[0]
                    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
                    
                    logging.info(f"### Tenant ID: {tenant_id} | Parent Tenant ID: {parent_tenant_id}")
                    
                    # Handle sub-tenant column swap if parent_tenant_id exists
                    if parent_tenant_id is not None:
                        logging.info("Sub-tenant detected, swapping column names")
                        
                        for hit in response.get('hits', {}).get('hits', []):
                            source = hit.get('_source', {})
                            
                            # Remove original columns if they exist
                            # source.pop('customer_rate_plan_name', None)
                            
                            # Swap sub_tenant_carrier_rate_plan_name to carrier_rate_plan_name
                            if 'sub_tenant_carrier_rate_plan_name' in source:
                                if index_name in ["Inventory", "inventory_export"]:
                                    source['carrier_rate_plan_name'] = source.pop('sub_tenant_carrier_rate_plan_name')
                                elif index_name in ["daily_usage_report", "daily_usage_report_export", "usage_by_line_report2","zero_usage_report"]:
                                    source['carrier_rate_plan'] = source.pop('sub_tenant_carrier_rate_plan_name')
                    
                    logging.warning(f"No tenant found for tenant_name: {tenant_name}")
            #print("total_records",total_records)
            cleaned_response = replace_none_with_empty(response, index)
            # print("check point")
            # return cleaned_response,total_records
            return response,total_records,search_body
    except Exception as e:
        logging.info(f"An error occurred while searching: {e}")
        return None
    try:
        scroll_time = "1m"
        scroll_size = 10000
        search_body.pop("from", None)
        search_body["size"] = scroll_size
        response = es.search(index=index_list, body=search_body, scroll=scroll_time)
        response = replace_none_with_empty(response,index_list)
        
        scroll_id = response.get('_scroll_id')
        if not scroll_id:
            logging.info("Error: No scroll ID returned.")
            return None

        # Retrieve the hits
        all_hits = response['hits']['hits']
        # print(f"Fetched {len(all_hits)} initial records.")
        total_records = response['hits']['total']['value']



    
        if page_flag == "Pagination":  # Check if flag is set for paginated results (scrolling)
            fetched_records = all_hits
            while scroll_id and len(fetched_records) < end:
                scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                hits = scroll_response.get('hits', {}).get('hits', [])

                if not hits:
                    logging.info("No more records found.")
                    break

                fetched_records.extend(hits)
                #print(f"Fetched {len(hits)} more records, total: {len(fetched_records)}.")

                # Update scroll_id for the next batch
                scroll_id = scroll_response.get('_scroll_id')
                if not scroll_id:
                    logging.info("Error: No scroll ID found in subsequent response.")
                    break

            # Return the records for the pagination range requested (start to end)
            
            paginated_results = fetched_records[start:end]
            es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
            cleaned_response = replace_none_with_empty(paginated_results,index_list)
            # return cleaned_response,total_records
            return paginated_results,total_records,search_body
        elif page_flag == "Nopagination":  # Handle fetching all records without pagination
            # logging.info("check point - 2")
            fetched_records = all_hits
            while True:
                if len(fetched_records) >= total_records:
                    # print("All records have been fetched.")
                    fetched_records = fetched_records[:total_records]
                    logging.info("check --------")
                    break

                scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                hits = scroll_response.get('hits', {}).get('hits', [])

                if not hits:
                    logging.info("No more records found.")
                    break

                fetched_records.extend(hits)
                logging.info(f"Fetched {len(hits)} more records, total: {len(fetched_records)}.")

                # Update scroll_id for the next batch
                scroll_id = scroll_response.get('_scroll_id')
                if not scroll_id:
                    logging.info("Error: No scroll ID found in subsequent response.")
                    break
            if index_name in ["Inventory", "inventory_export", "daily_usage_report_export","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
                logging.info(f"### Checking tenant information for tenant_name: {tenant_name}")
                database = DB("common_utils", **get_db_config("common_utils"))
                
                tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
                
                if not tenant_data.empty:
                    tenant_id = tenant_data["id"].to_list()[0]
                    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
                    
                    logging.info(f"### Tenant ID: {tenant_id} | Parent Tenant ID: {parent_tenant_id}")
                    
                    # Handle sub-tenant column swap if parent_tenant_id exists
                    if parent_tenant_id is not None:
                        logging.info("Sub-tenant detected, swapping column names for all fetched records")
                        
                        for hit in fetched_records:
                            source = hit.get('_source', {})
                            
                            # Swap sub_tenant_carrier_rate_plan_name to carrier_rate_plan_name
                            if 'sub_tenant_carrier_rate_plan_name' in source:
                                if index_name in ["Inventory", "inventory_export"]:
                                    source['carrier_rate_plan_name'] = source.pop('sub_tenant_carrier_rate_plan_name')
                                elif index_name in ["daily_usage_report", "daily_usage_report_export", "usage_by_line_report2","zero_usage_report"]:
                                    source['carrier_rate_plan'] = source.pop('sub_tenant_carrier_rate_plan_name')
                else:
                    logging.info(f"No tenant found for tenant_name: {tenant_name}")
            if index_name == 'sim_management_bulk_change':
                grouped_sources = {}
                for hit in fetched_records:
                    source = hit.get("_source", {})
                    bulk_id = source.get("bulk_change_id")
                    if bulk_id and bulk_id not in grouped_sources:
                        grouped_sources[bulk_id] = hit

            # Prepare paginated results
            if index_name == 'sim_management_bulk_change':
                fetched_records = list(grouped_sources.values())
            total_records = len(fetched_records)
            es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
            cleaned_response = replace_none_with_empty(fetched_records,index_list)
            # return cleaned_response,len(fetched_records)
            return fetched_records,len(fetched_records),search_body
        else:
            # If flag is not set, just return the first batch of results
            return all_hits,total_records,search_body

    except Exception as e:
        logging.info(f"An error occurred while searching in Whole search data: {e}")
        return None
    # try:
    #     response = es.search(index=index, body=search_body)
    #     cleaned_response = replace_none_with_empty(response,index)
    #     return cleaned_response
        
    # except Exception as e:
    #     print(f"An error occurred while searching: {e}")
    #     return None




def create_filter_clause(index_list, custom_filter,index_name):
    filter_clauses = []
    logging.info(f"custom_filter ---- {custom_filter}")
    if custom_filter:
        for field, value in custom_filter.items():
            # Skip fields not in index
            if not is_field_present(index_list, field):
                continue
            field_type = get_field_type(index_list, field)
            if field_type == "text":
                field = f"{field}.keyword"
            if isinstance(value, list):
                if len(value) == 1:
                    filter_clauses.append({"term": {field: value[0]}})
                elif len(value) > 1:
                    filter_clauses.append({"terms": {field: value}})
            else:
                filter_clauses.append({"term": {field: value}})
    logging.info(f"filter_clauses ---- {index_name}")
    if index_name == 'Billing and Payments Billing':
        filter_clauses.append({"range": {"amount_due": { "gt": 0 }}})

    # if index_name == 'Unposted':
    #     filter_clauses.append({"range": {"charge_amount": { "gt": 0 }}})
    return filter_clauses if filter_clauses else None


def get_field_type(index_name, field_name):
    """Fetch the type of a field from the OpenSearch index mapping."""
    try:
        index_name=index_name[0]
        mapping = es.indices.get_mapping(index=index_name)

        # Navigate to the properties of the index
        properties = mapping[index_name]['mappings']['properties']

        # Check if the field exists
        if field_name in properties:
            return properties[field_name].get('type', 'unknown')  # Return the field type
        else:
            return None  # Field does not exist
    except Exception as e:
        logging.info(f"Error fetching field type: {e}")
        return None

def is_valid_date(date_str):
    # List of possible date formats
    date_formats = ["%d-%m-%Y %H:%M:%S", "%m-%d-%Y %H:%M:%S"]
    
    for date_format in date_formats:
        try:
            # Try parsing the date with each format
            datetime.datetime.strptime(date_str, date_format)
            return date_format
        except ValueError:
            continue  # If this format fails, try the next one
    
    return False  # If none of the formats match, return False

def is_field_present(index_name, field_name):
    try:
        # Get the mapping for the index
        mapping = es.indices.get_mapping(index=index_name)
        # Check if the field exists in the mapping
        fields = mapping[index_name]['mappings']['properties']
        return field_name in fields
    except Exception as e:
        logging.info(f"An error occurred while checking field presence: {e}")
        return False

def get_field_type(index_name, field_name):
    """
    Fetch the field type from the OpenSearch index mappings.
    """
    try:
        mapping = es.indices.get_mapping(index=index_name)
        field_mapping = mapping.get(index_name, {}).get("mappings", {}).get("properties", {})
        return field_mapping.get(field_name, {}).get("type", None)
    except Exception as e:
        logging.info(f"Error fetching mapping for index {index_name}: {e}")
        return None

def convert_date_format(dates, column_name="billing_cycle_end_date", current_format="%m/%d/%Y %H:%M:%S", target_format="%m/%d/%Y %H:%M:%S"):
    if isinstance(dates, list):
        formatted_dates = []
        for date_str in dates:
            try:
                date_obj = datetime.datetime.strptime(date_str, current_format)
                if column_name == "billing_cycle_end_date":
                    if date_obj.time() == pd.Timestamp("23:59:59").time():
                        date_obj = (date_obj + pd.Timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                formatted_date = date_obj.strftime(target_format)
                formatted_dates.append(formatted_date)
            except ValueError as e:
                raise ValueError(f"Error parsing date '{date_str}': {e}")
        return formatted_dates
    else:
        try:
            date_obj = datetime.datetime.strptime(dates, current_format)
            if column_name == "billing_cycle_end_date":
                if date_obj.time() == pd.Timestamp("23:59:59").time():
                    date_obj = (date_obj + pd.Timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
            return date_obj.strftime(target_format)
        except ValueError as e:
            raise ValueError(f"Error parsing date '{dates}': {e}")


def convert_to_timezone(k, v, tenant_time_zone, index_name):
    """
    Converts a date string from 'yyyy-mm-dd' to 'mm-dd-yyyy' format.
    
    Parameters:
    - k: The key associated with the value (e.g., field name; unused in this implementation).
    - v: The date string in 'yyyy-mm-dd' format.
    - tenant_time_zone: The timezone string (e.g., 'Asia/Kolkata'; unused in this implementation).
    - index_name: The index name (e.g., for logging; unused in this implementation).
    
    Returns:
    - The reformatted date string in 'mm-dd-yyyy' format.
    
    Raises:
    - ValueError: If the input date string is invalid.
    """
    try:
        # Parse the input date string (assumes 'yyyy-mm-dd' format)
        date_obj = datetime.datetime.strptime(v, '%Y-%m-%d')
        
        # Reformat to 'mm-dd-yyyy'
        formatted_date = date_obj.strftime('%m-%d-%Y')
        
        return formatted_date
    except ValueError:
        # Handle invalid date formats (you could log using k, tenant_time_zone, index_name here if needed)
        raise ValueError(f"Invalid date format for key '{k}' in index '{index_name}': '{v}' must be in 'yyyy-mm-dd' format.")


def convert_to_tenant_timezone(k, date_str, tenant_time_zone, index_name,fetch=None):
    """Converts date from Asia/Kolkata time zone to tenant's time zone (e.g., America/Chicago)."""
    date_only_indexes = [
            'Export Cycle Date Report',
            'AR Aging Report',
            'Export FCC',
            'Billing Report w/_City_County_Country',
            'Transaction Analysis Report',
            'Payment Details Report',
            'Export Variance Billing',
            'Billing report by day with OCC Report',
            'Total MRC for Sales Person: Catapult'
        ]
    try:
        # Handle input format with milliseconds
        if '.' in date_str:
            date_str = date_str.split('.')[0]  # Remove milliseconds

        # Parse the date string in the format "YYYY-MM-DDTHH:MM:SS"
        date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S")
        
        # Localize to UTC if no timezone info
        if date_obj.tzinfo is None:
            date_obj = pytz.utc.localize(date_obj)
        skip = (
            (index_name in ['Inventory', 'inventory_export','Customer Services'] and k in ['date_activated', 'last_activated_date', 'effective_date']) or
            (index_name in ['status_history_report'] and k in ['date_of_change']) or
            (index_name in ['usage_by_line_report', 'usp_report_customer_usage_by_line', 'usage_by_line_report2'] and
            k in ['customer_cycle_end_date', 'billing_cycle_end_date']) or
            (index_name in ['Unposted Upload Data'] and k in ['start_date','end_date']) or
            (index_name in date_only_indexes) or
            (index_name in ['Customer Profile'] and k in ['bill_cycle_start_date']) or
            (k in ['billing_cycle_end_date', 'billing_period_end_date'])
        )
        # Convert to tenant's timezone
        if not skip:
            tenant_timezone = pytz.timezone(tenant_time_zone)
            date_obj = date_obj.astimezone(tenant_timezone)
            
        if index_name in date_only_indexes:
            return date_obj.strftime("%m-%d-%Y")  # Return date only
        if fetch:
            return date_obj.strftime("%m/%d/%Y %I:%M:%S %p")  # 12-hour format with AM/PM
        # Return formatted date in 12-hour format (with AM/PM)
        return date_obj.strftime("%m-%d-%Y %I:%M:%S %p")  # 12-hour format with AM/PM
    except ValueError:
        # If the date format is invalid, return the original string
        return date_str

def convert_to_scientific_notation(value):
    try:
        # Convert the number to scientific notation with 2 decimal points (you can adjust the precision)
        return "{:.2e}".format(float(value))
    except ValueError:
        # Handle the case where the value cannot be converted to a number
        logging.info(f"Invalid number: {value}")
        return None

def advance_search_data(filters,index_list,start, end,db_name,index_name,col_sort,tenant_name,role,is_redirected):
    sort_clause = []
    t5=time.time()
    logging.info(f"index_name --------- {index_name}")
    search_body = {
        "query": {
            "bool": {
                "must": [],
                "should": [],
            }
        },
        "from": start ,  # Start from the specified offset
        "size": end-start,
        "track_total_hits": True # Number of results to return
    }
    if index_name == "automation_rule_log":
        if is_field_present(index_list, 'created_date'):
            sort_clause = [
                {
                    "created_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name in ["customer_optimization_list_view", "carrier_optimization_list_view"]:
        if is_field_present(index_list, 'run_start_time'):
            sort_clause = [
                {
                    "run_start_time": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name == "action_history_report":
        # Apply last one year filter
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_month_date = (datetime.datetime.utcnow() - relativedelta(months=1)).strftime("%Y-%m-%d")

        date_filter = {
            "range": {
                "date_of_change": {
                    "gte": last_month_date,  # From one year ago
                    "lte": current_date     # Up to the present date
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_filter)
    elif index_name == "Usage Details":
        usage_filter = {
            "bool": {
                "should": [
                    {
                        "range": {
                            "usage_mb": {
                                "gt": 0
                            }
                        }
                    },
                    {
                        "range": {
                            "sms_cost": {
                                "gt": 0
                            }
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        }
        search_body["query"]["bool"]["must"].append(usage_filter)
    elif index_name == 'Billing and Payments Billing':
        due_filter = {
            "range": {
                "amount_due": { "gt": 0 }
            }
        }
        search_body["query"]["bool"]["must"].append(due_filter)
    # elif index_name == 'Unposted':
        # due_filter = {
        #     "range": {
        #         "charge_amount": { "gt": 0 }
        #     }
        # }
        # search_body["query"]["bool"]["must"].append(due_filter)
    elif index_name == "partner_users":
        logging.info(f"### partner_users role: {role}, tenant_name: {tenant_name}")
        role_order = [
            "Partner Admin",
            "Agent Partner Admin",
            "Agent",
            "User",
            "Notification Only User",
            "Qualification Only User"
        ]
        if role and role != "Super Admin":
            if role in role_order:
                supported_role = role_order[role_order.index(role):]
                usernames = get_usernames(tenant_name, supported_role)
                should_queries = []
                for r in supported_role:
                    should_queries.append({"wildcard": {"role.keyword": f"*{r}*"}})

                role_filters = {
                    "bool": {
                        "should": should_queries,
                        "minimum_should_match": 1
                    }
                }
                username_filters = {
                    "terms": {
                        "username.keyword": usernames
                    }
                }
                search_body["query"]["bool"]["must"].append(role_filters)
                search_body["query"]["bool"]["must"].append(username_filters)
                logging.info(f"### Supported roles: {supported_role}")
            else:
                logging.warning(f"### Role {role} not found in role_order")
        else:
            logging.info("### Super admin: No role-based filtering applied")
    else:
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    if index_name == "Charge Details":
        search_body["query"]["bool"].setdefault("must_not", []).append({
            "terms": {
                "category.keyword": ["MRC", "Credit"]
            }
        })
    if col_sort:
        try:
            # Extract field and order from the key
            field_to_sort, sort_order = next(iter(col_sort.items()))  
            # print("field_to_sort", field_to_sort)
            sort_order = sort_order.lower()  # Normalize to lowercase

            # Get the field type (Assuming `get_field_type` is a defined function)
            field_type = get_field_type(index_list, field_to_sort)

            # Modify field_to_sort if it is of type "text"
            if field_type == "text":
                field_to_sort = f'{field_to_sort}.keyword'

            # Check if the field and sort order are valid
            if field_to_sort and sort_order in ["asc", "desc"]:
                sort_clause = [{field_to_sort: {"order": sort_order}}]  # Override default sort with key sorting
            else:
                logging.info("Invalid sorting key: Ensure the format is {<field_name>: 'asc'/'desc'}.")
        except StopIteration:
            logging.info("Error: The provided 'key' dictionary is empty or invalid.")
        except Exception as e:
            logging.info(f"An error occurred: {e}")
    # print("sort_clause --------", sort_clause)
    
    if sort_clause:
        search_body["sort"] = sort_clause
    if filters:
        for field, values in filters.items():
            logging.info(f"{field}-->{values}")
            if values:  # Check if values is not empty
                field_type = get_field_type(index_list, field)
                # print(f"Field: {field}, Field Type: {field_type}")
                if isinstance(values, list) and len(values) > 1:
                    if field_type in ["date", "long", "float"]:  # Adjust based on actual types returned by get_field_type
                        values = [v for v in values if v != '']  # Remove empty string
                        
                        # Update filters with cleaned values
                        filters[field] = values
                if isinstance(values, list):  # Handle lists
                    if len(values) == 1:
                        # Single value, handle boolean or other types
                        value = values[0]
                        if field_type in ["long", "float"]:
                            try:
                                if isinstance(value, (int, float)):
                                    pass  # already numeric
                                else:
                                    value = float(value) if value.replace('.', '').isdigit() else int(value)
                            except (ValueError, TypeError):
                                pass  # Keep original value if conversion fails
                        if field in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost"] and index_name in ["carrier_optimization_list_view","customer_optimization_list_view","Customer_Rate_Plan"]:
                            if isinstance(value, str) and ":" in value:
                                logging.info(f"value--{value}")
                                try:
                                    start_range, end_range = map(int, value.split(':'))
                                    # start_range = round(float(start_range))
                                    # end_range = round(float(end_range))
                                    search_body["query"]["bool"].setdefault("must", []).append({
                                        "range": {
                                            f"{field}": {
                                                "gte": start_range,  # Greater than or equal to start of range
                                                "lte": end_range     # Less than or equal to end of range
                                            }
                                        }
                                    })
                                    search_body["sort"] = [
                                            {f"{field}": {"order": "asc"}}
                                        ]
                                except ValueError:
                                    logging.info(f"Invalid range format for {field}")
                            else:
                                try:
                                    start_range = int(value)
                                    end_range = int(value)+1
                                    search_body["query"]["bool"].setdefault("must", []).append({
                                        "range": {
                                            f"{field}": {
                                                "gte": start_range,  # Greater than or equal to start of range
                                                "lt": end_range     # Less than or equal to end of range
                                            }
                                        }
                                    })
                                    search_body["sort"] = [
                                            {f"{field}": {"order": "asc"}}
                                        ]
                                except ValueError:
                                    logging.info(f"Invalid range format for {field}")
                        elif isinstance(value, str) and ":" in value:
                            try:
                                start_range, end_range = value.split(':')
                                search_body["query"]["bool"].setdefault("must", []).append({
                                    "range": {
                                        f"{field}": {
                                            "gte": start_range,  # Greater than or equal to start of range
                                            "lte": end_range     # Less than or equal to end of range
                                        }
                                    }
                                })
                                search_body["sort"] = [
                                        {f"{field}": {"order": "asc"}}
                                    ]
                            except ValueError:
                                logging.info(f"Invalid range format for {field}")
                        elif field in ["created_date", "date_activated"] and is_redirected and index_name in ["Inventory", "inventory_export"]:
                            # Parse as date range
                            start_range, end_range = value.split(':')
                            # Optional: validate format
                            datetime.datetime.strptime(start_range, "%Y-%m-%d")
                            datetime.datetime.strptime(end_range, "%Y-%m-%d")
                            if field == "created_date":
                                earliest_date_query = {
                                    "size": 0,
                                    "aggs": {
                                        "min_date": {"min": {"field": field}}
                                    }
                                }
                                response = es.search(index=index_list, body=earliest_date_query)
                                start_range = response["aggregations"]["min_date"]["value_as_string"] if response["aggregations"]["min_date"]["value_as_string"] else end_range
                            logging.info(f"## start_range: {start_range}, end_range: {end_range}")
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "range": {
                                    f"{field}": {
                                        "gte": start_range,
                                        "lte": end_range
                                    }
                                }
                            })
                        elif isinstance(value, str) and value.strip() == "":
                            # Handle case where the single value is an empty string
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},  # Empty string
                                        {"bool": {"must_not": {"exists": {"field": field}}}}  # Missing field
                                    ]
                                }
                            })
                        elif field in ['category'] and value.lower() in ['ach','credit']:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value.lower()}  # Converts to lowercase
                            })
                        elif field in ['volte_capable', 'assigned'] and isinstance(value, str) and value.lower() in ['yes', 'no']:
                            # Convert 'yes'/'no' to boolean
                            if field == 'assigned' and index_name == 'Rate_Plan_Socs':
                                boolean_value = "Yes" if value.lower() == 'yes' else "No"
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": boolean_value}  # Use the converted boolean value
                                })
                            else:
                                boolean_value = True if value.lower() == 'yes' else False
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}": boolean_value}  # Use the converted boolean value
                                })
                        elif field in ['nsdev',"auto_change_rate_plan", "att_certified","is_billing_advance_eligible","allows_sim_pooling"] and isinstance(value, str) and value.lower() in ['true', 'false']:
                        # Handle boolean as string
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}  # Converts to a boolean
                            })
                        elif field_type == "long" and field=="bulk_change_id":  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif field in ["vw_users_tenant_roles", "customerrateplan","is_active"] and isinstance(value, str) and value.lower() in ["active", "inactive"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "active" else "false"}
                            })
                        elif field in ["optimization_type"] and index_name == "Customer_Rate_Plan":
                            # Normalize the "Cross Customer Pooling" values
                            normalized_value = "Cross Customer Pooling" if value.lower() in ["cross customer pooling", "cross customer pooling", "cross customer pooling"] else value
                            
                            if normalized_value == "Cross Customer Pooling":
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}.keyword": ["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling", "Cross customer Pooling"]}
                                })
                            else:
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": normalized_value}
                                })
                        elif field in ["amop_apis", "carrier_apis", "email_templates"] and isinstance(value, str) and value.lower() in ["enable", "disable"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "enable" else "disable"}
                            })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.info(f"Invalid date format for item: {item}")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(value, (list, str)) and field_type != "float":
                            if value is None or (isinstance(value, str) and value == "(Spaces)"):
                                if isinstance(value, str):
                                    stripped_value = ""
                                    if stripped_value == "":
                                        search_body["query"]["bool"]["must"].append({
                                            "terms": {f"{field}.keyword": ["", " ", "  "]}  # Match exact empty string, single space, and double space
                                        })
                            elif field == 'prorate':
                                if isinstance(value, str):
                                    search_body["query"]["bool"]["must"].append({
                                        "term": {f"{field}": value }
                                    })
                            elif value.strip() not in [""," "] and value != "(Spaces)":
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": value }
                                })
                        # elif isinstance(value, (list, str)) and field_type == "text" and value.strip() not in [""," "]:
                        #     search_body["query"]["bool"]["must"].append({
                        #         "term": {f"{field}.keyword": value }
                        #     })
                        # for handling empty values
                        
                        
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, (list, str)) and field == "billing_cycle_end_date":
                            try:
                                if isinstance(value, str):
                                    value = [value]
                                formatted_values = convert_date_format(value)
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                            except ValueError:
                                continue            
                        elif isinstance(value, (list, str)):
                            try:
                                if isinstance(value, str):
                                    value = [value]  # Convert single string to a list if it's not already a list
                                for item in value:
                                    if isinstance(item, str):  # Ensure it's a string before adding to the query
                                        # Create a match query for each item in the list
                                        search_body["query"]["bool"]["must"].append({
                                            "match": {
                                                f"{field}": item  # Using match for full-text search
                                            }
                                        })
                            except ValueError:
                                continue
                        elif isinstance(value, (list, str)):  # Single int or float value
                            converted_value = convert_to_scientific_notation(value)
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })

                        elif isinstance(value, (int, float)):  # Single int or float value
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, str) and field == 'status'  and index_list=='sim_management_bulk_change_request':  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                        elif isinstance(value, str):  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        else:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                    else:
                        if field in ['category'] and index_name in ['Chargeback Exceptions','Payment History']:
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['ach', 'credit']]
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": values.lower()}  # Converts to lowercase
                            })

                        elif field in ['nsdev', "auto_change_rate_plan", "att_certified", "is_billing_advance_eligible", "allows_sim_pooling"] and isinstance(values, list):
                            # Ensure all values in the list are lowercase and valid boolean strings
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['true', 'false']]
                            
                            if lower_values:  # Proceed only if the list has valid boolean strings
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": lower_values}  # Add terms filter with lowercase values
                                })
                        elif any(isinstance(v, str) and v.strip() == "" for v in values):  
                            # Handle empty string or missing field cases
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},
                                        {"bool": {"must_not": {"exists": {"field": field}}}},
                                        {"terms": {f"{field}.keyword": [v for v in values if isinstance(v, str) and v.strip() != ""]}}
                                    ]
                                }
                            })
                        elif field_type == "text":
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}.keyword": values }
                            })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        print(f"Invalid date format for item: {item}")
                                        continue
                            # if formatted_values:
                            #     search_body["query"]["bool"]["must"].append({
                            #         "terms": {f"{field}": formatted_values}
                            #     })
                            if formatted_values:
                                if len(formatted_values) > 1024:
                                    # If too many dates, use a range query
                                    min_date = min(formatted_values)
                                    max_date = max(formatted_values)
                                    search_body["query"]["bool"]["filter"] = {
                                        "range": {f"{field}": {"gte": min_date, "lte": max_date}}
                                    }
                                else:
                                    # Use terms query if within limit
                                    search_body["query"]["bool"]["must"].append({
                                        "terms": {f"{field}": formatted_values}
                                    })
                        elif field in ['is_active'] and isinstance(values, (list, str)):
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str) and item.lower() == 'active':
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append('true')
                                    except ValueError:
                                        continue
                                elif isinstance(values, (list, str)) and item.lower() == 'inactive':
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append('false')
                                    except ValueError:
                                        continue
                            if formatted_values:
                                if len(formatted_values) > 1024:
                                    # If too many dates, use a range query
                                    min_date = min(formatted_values)
                                    max_date = max(formatted_values)
                                    search_body["query"]["bool"]["filter"] = {
                                        "range": {f"{field}": {"gte": min_date, "lte": max_date}}
                                    }
                                else:
                                    # Use terms query if within limit
                                    search_body["query"]["bool"]["must"].append({
                                        "terms": {f"{field}": formatted_values}
                                    })
                        elif isinstance(values, (list, str)) and field == "billing_cycle_end_date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        formatted_value = convert_date_format(item)
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        # print(f"An Error Occurred in formatting billing_cycle_end_date")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.info(f"Invalid date format for item: {item}")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(values, (list, str)):
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):  # Ensure it's a string before adding to the query
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append(item)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {
                                        f"{field}": formatted_values  # List of values for multiple exact matches
                                    }
                                })
                        if isinstance(values, list) :
                            if all(isinstance(v, (int, float)) for v in values) :
                                # print(f"Adding terms filter for {field} with values: {values}") 
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {field: values}  
                                })
                        else:
                            # Multiple values in the list
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}": values}
                            })
                elif isinstance(values, dict) and field_type == 'date':
                    logging.info(f"Date range query: {field} -> {values}")

                    range_value = values.get("range")
                    include_empty = values.get("include_empty", False)

                    if range_value and ":" in range_value:
                        try:
                            start_range, end_range = range_value.split(":")

                            range_query = {
                                "range": {
                                    field: {
                                        "gte": start_range,
                                        "lte": end_range,
                                        "format": "yyyy-MM-dd"
                                    }
                                }
                            }

                            #  If empty values should also be included
                            if include_empty:
                                search_body["query"]["bool"].setdefault("should", []).append({
                                    "bool": {
                                        "should": [
                                            range_query,
                                            {
                                                "bool": {
                                                    "must_not": {
                                                        "exists": {
                                                            "field": field
                                                        }
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                })

                                # VERY IMPORTANT
                                search_body["query"]["bool"]["minimum_should_match"] = 1

                            else:
                                search_body["query"]["bool"].setdefault("must", []).append(range_query)

                            # Sorting
                            search_body["sort"] = [
                                {field: {"order": "asc"}}
                            ]

                        except ValueError:
                            logging.info(f"Invalid date range format for {field}")

                elif isinstance(values, bool):  # Single boolean condition
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, int):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, str):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}.keyword": values}
                    })
                else:
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
            elif values is False:
                search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })

    search_body = add_customer_exists_filters(search_body, index_name, tenant_name, db_config)
    logging.info(f"Search body: {search_body}")
    if index_name == "Active_lines_report":
        search_body["query"]["bool"]["must"].append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A","ACTIVATED"]
            }
        })
        logging.info(f"Advance Search query {search_body}")

    if index_name == "rev_assurance":
        logging.info("adding is_active_status or rev_is_active_status filters")
        search_body["query"]["bool"]["should"].extend([
            {"term": {"is_active_status": False}},
            {"term": {"rev_is_active_status": False}}
        ])
        search_body["query"]["bool"]["minimum_should_match"] = 1
    elif index_name == "IMEI_Master_Table":
        if "must_not" not in search_body["query"]["bool"]:
            search_body["query"]["bool"]["must_not"] = []

        search_body["query"]["bool"]["must_not"].append({
            "exists": {"field": "deleted_date"}
        })
    elif index_name == "Customers":
        logging.info("adding rev_customer_id is null filter")
        if "must_not" not in search_body["query"]["bool"]:
            search_body["query"]["bool"]["must_not"] = []
        search_body["query"]["bool"]["must_not"].append({
            "exists": {"field": "rev_customer_id"}
        })
    elif index_name in ['Billing Report w/_City_County_Country','AR Aging Report','Export Variance Billing','Billing report by day with OCC Report','Total MRC for Sales Person: Catapult']:
        logging.info("adding bill_reversed_date is null filter")
        date_trunc_filter = {
            "script": {
                "script": {
                    "lang": "painless",
                    "source": """
                        if (doc['bill_reversed_date'].size() == 0) {
                            return true;
                        }

                        ZonedDateTime created = doc['created_date'].value;
                        ZonedDateTime reversed = doc['bill_reversed_date'].value;

                        return created.getYear() != reversed.getYear()
                            || created.getMonthValue() != reversed.getMonthValue();
                    """
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_trunc_filter)
    elif index_name in ["zero_usage_report", "usp_report_customer_usage_by_line", "usage_by_line_report", "newly_activated_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### adding customer_name, customer_id is not null filter")
            if "must" not in search_body["query"]["bool"]:
                search_body["query"]["bool"]["must"] = []
            search_body["query"]["bool"]["must"].extend([
                {"exists": {"field": "customer_id"}},
                {"term": {"customer_is_active": True}}
            ])
        else:
            logging.info("### Skipping customer_name, customer_id is not null filter. Due to main tenant")
    elif index_name in ["status_history_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### adding customer_id is not null filter")
            if "must" not in search_body["query"]["bool"]:
                search_body["query"]["bool"]["must"] = []
            search_body["query"]["bool"]["must"].extend([
                {"exists": {"field": "customer_id"}}
            ])
        else:
            logging.info("### Skipping customer_id is not null filter. Due to main tenant")
    logging.info(f"### Search body advance: {index_name} -- {search_body}")
    try:
        # if index_name == "sim_management_bulk_change":
        #     # Scroll parameters
        #     scroll_time = "1m"
        #     scroll_size = 10000
        #     grouped_sources = {}  # Dictionary to store unique `bulk_change_id` records

        #     search_body.pop('from',None)
        #     search_body.pop('size', None)

        #     # Initial search request
        #     response = es.search(index=index_list, body=search_body, scroll=scroll_time, size=scroll_size)
        #     hits = response.get("hits", {}).get("hits", [])
        #     scroll_id = response.get("_scroll_id")

        #     if not hits or not scroll_id:
        #         print("No hits found or scroll_id is missing.")
        #         return None

        #     # Variables to track progress
        #     total_processed = 0  # Number of records processed
        #     required_records = end - start  # Number of records needed for the current page

        #     # Scroll through and process records
        #     while hits:
        #         for hit in hits:
        #             total_processed += 1

        #             # Skip records before the `start` index
        #             if total_processed <= start:
        #                 continue

        #             # Add records after the `start` index to the grouped_sources
        #             source = hit.get("_source", {})
        #             bulk_id = source.get("bulk_change_id")
        #             if bulk_id and bulk_id not in grouped_sources:
        #                 grouped_sources[bulk_id] = hit  # Add unique bulk_change_id entry

        #             # Stop early if enough records are collected
        #             if len(grouped_sources) >= required_records:
        #                 break

        #         # Stop scrolling if enough records are collected
        #         if len(grouped_sources) >= required_records:
        #             break

        #         # Fetch the next batch of records
        #         response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
        #         hits = response.get("hits", {}).get("hits", [])

        #     # Clear the scroll context
        #     if scroll_id:
        #         es.clear_scroll(scroll_id=scroll_id)

        #     # Prepare paginated results
        #     grouped_hits = list(grouped_sources.values())
        #     total_records = total_processed  # Total records processed across all batches
        #     paginated_hits = grouped_hits[:required_records]  # Limit to the required page size

        #     results = {
        #         "hits": {
        #             "hits": paginated_hits,
        #             "total": {"value": total_records}
        #         }
        #     }
        #     return results,agg_body

        if index_name == "sim_management_bulk_change":
            # Step 1: Get unique bulk_change_ids using aggregations
            agg_body = {
                "query": search_body.get("query", {}),
                "size": 0,  # We don't need the actual documents here
                "aggs": {
                    "unique_bulk_ids": {
                        "terms": {
                            "field": "bulk_change_id",  # No .keyword needed for long type
                            "size": 10000,  # Adjust based on expected unique IDs
                            "order": {"latest_date": "desc"}
                        },
                        "aggs": {
                            "latest_date": {
                                "max": {
                                    "field": "modified_date"
                                }
                            },
                            "top_hit": {
                                "top_hits": {
                                    "size": 1,
                                    "sort": [{"modified_date": {"order": "desc"}}]
                                }
                            }
                        }
                    }
                }
            }
            
            response = es.search(index=index_list, body=agg_body)
            buckets = response.get("aggregations", {}).get("unique_bulk_ids", {}).get("buckets", [])
            
            # Extract the top hit from each bucket
            all_unique_hits = [
                bucket["top_hit"]["hits"]["hits"][0]
                for bucket in buckets
            ]
            
            # Apply pagination
            total_records = len(all_unique_hits)
            paginated_hits = all_unique_hits[start:end]
            
            results = {
                "hits": {
                    "hits": paginated_hits,
                    "total": {"value": total_records}
                }
            }
            return results,agg_body
        
        else:
            # Perform regular search for non-bulk-change indices
            response = es.search(index=index_list, body=search_body)
            total_records = response['hits']['total']['value']
            if index_name in ["Inventory", "inventory_export", "daily_usage_report_export","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
                
                logging.info(f"### Checking tenant information for tenant_name: {tenant_name}")
                database = DB("common_utils", **get_db_config("common_utils"))
                
                tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
                
                if not tenant_data.empty:
                    tenant_id = tenant_data["id"].to_list()[0]
                    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
                    
                    logging.info(f"### Tenant ID: {tenant_id} | Parent Tenant ID: {parent_tenant_id}")
                    
                    # Handle sub-tenant column swap if parent_tenant_id exists
                    if parent_tenant_id is not None:
                        logging.info("Sub-tenant detected, swapping column names")
                        
                        for hit in response.get('hits', {}).get('hits', []):
                            source = hit.get('_source', {})
                            
                            # Remove original columns if they exist
                            # source.pop('customer_rate_plan_name', None)
                            
                            # Swap sub_tenant_carrier_rate_plan_name to carrier_rate_plan_name
                            if 'sub_tenant_carrier_rate_plan_name' in source:
                                if index_name in ["Inventory", "inventory_export"]:
                                    source['carrier_rate_plan_name'] = source.pop('sub_tenant_carrier_rate_plan_name')
                                elif index_name in ["daily_usage_report", "zero_usage_report", "usage_by_line_report2"]:
                                    source['carrier_rate_plan'] = source.pop('sub_tenant_carrier_rate_plan_name')
                else:
                    logging.warning(f"No tenant found for tenant_name: {tenant_name}")
            cleaned_response = replace_none_with_empty(response,index_list)
            # return cleaned_response
            return response,search_body
    except Exception as e:
        logging.info(f"An error occurred advanced searching: {e}")
        return None
    # try:
    #     response = es.search(index=index_list, body=search_body)
    #     cleaned_response = replace_none_with_empty(response,index_list)
    #     return cleaned_response
    # except Exception as e:
    #     print(f"An error occurred while searching: {e}")
    #     return None

def get_service_id(account_number,current_cycle,db_name):
    customer_profile_id = int(get_customer_id(account_number,db_name))
    created_start_date = current_cycle[0].split("T")[0]  # Extract the date part
    created_end_date = current_cycle[1].split("T")[0]  # Extract the date part
    try:
        # Establish connection
        database = DB(os.getenv('BILLING_PLATFORM'), **get_db_config(os.getenv('BILLING_PLATFORM')))  # Assuming DB is a predefined class for database connection
        query = f"""
            SELECT applied_services
            FROM customer_bills
            WHERE customer_profile_id = '{customer_profile_id}'
                AND created_date >= '{created_start_date}'
                AND created_date <= '{created_end_date}';
        """

        bill_details = database.execute_query(query, True)  # Assuming `fetch_one` fetches a single row
        if not bill_details.empty:
            service_ids_set = set()
            for _, row in bill_details.iterrows():
                applied_services = row["applied_services"]
                if applied_services is None:
                    continue

                if isinstance(applied_services, str):
                    try:
                        applied_services_list = literal_eval(applied_services)
                    except Exception:
                        try:
                            applied_services_list = json.loads(applied_services)
                        except Exception:
                            logging.info(f"Could not parse applied_services: {applied_services}")
                            continue
                else:
                    applied_services_list = applied_services  # Already list-like

                for service_id in applied_services_list:
                    if service_id is not None:
                        service_ids_set.add(service_id)
        distinct_service_ids = sorted(service_ids_set)
        logging.info(f"### Distinct Service IDs: {distinct_service_ids}")
        return distinct_service_ids
    except Exception as e:
        logging.info(f"## An Error Occured while getting service ids as {e}")
        return None
    finally:
        if database:
            database.close()

def get_customer_id(account_number,db_name):
    try:
        # Establish connection
        database = DB(db_name, **get_db_config(db_name))  # Assuming DB is a predefined class for database connection
        query = f"""
            SELECT id 
            FROM customer_profiles 
            WHERE account_number = '{account_number}';
        """

        df = database.execute_query(query,True)  # Assuming `fetch_one` fetches a single row
        if not df.empty:
            id = df.iloc[0]["id"]  # Extract
            return id  # Return the ID
        logging.info(f"## Return Customer Profile id as {id}")
        return None  # Return None if no record is found

    except Exception as e:
        logging.info(f"## An Error Occured as {e}")
        return None
    finally:
        if database:
            database.close()

def replace_none_with_empty(data,index):
    """
    Recursively replace 'None' values with empty strings in the given dictionary or list.
    """
    
    if isinstance(data, dict):
        return {key: replace_none_with_empty(value, index) for key, value in data.items()}
    elif isinstance(data, list):
        return [replace_none_with_empty(item, index) for item in data]
    elif data is None and any(keyword in index for keyword in ["sim_management_bulk_change_view"]):
        return data  # Replace None with an empty string
    elif data is None:
        return ""
    else:
        return data


def advanced_search_data(filters, index_list, start, end,flag,db_name,index_name,col_sort,tenant_name,role,dollar_fields,tenant_time_zone,is_redirected,scroll_time='1m'):
    # Initialize the search body
    # print("index_name ---------", index_name)
    # print(flag, "1234567890")
    # if db_name=="altaworx_central":
    #         index_list=index_list
    # else:
    #     index_list=index_list
    # print("index_name------",index_list)
    sort_clause = []
    logging.info(f"### filters3333333333: {filters}")
    search_body = {
        "query": {
            "bool": {
                "must": [],
                "should": []
            }
        },
        "size": 10000,  # Fetch up to 10,000 records per scroll batch
        "track_total_hits": True  # Ensure we track the total number of hits
    }
    if index_name == "automation_rule_log":
        if is_field_present(index_list, 'id'):
            sort_clause = [
                {
                    "id.keyword": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name in ["customer_optimization_list_view", "carrier_optimization_list_view"]:
        if is_field_present(index_list, 'run_start_time'):
            sort_clause = [
                {
                    "run_start_time": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name == "action_history_report":
        # Apply last one year filter
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_month_date = (datetime.datetime.utcnow() - relativedelta(months=1)).strftime("%Y-%m-%d")

        date_filter = {
            "range": {
                "date_of_change": {
                    "gte": last_month_date,  # From one year ago
                    "lte": current_date     # Up to the present date
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_filter)
    elif index_name == "Usage Details":
        usage_filter = {
            "bool": {
                "should": [
                    {
                        "range": {
                            "usage_mb": {
                                "gt": 0
                            }
                        }
                    },
                    {
                        "range": {
                            "sms_cost": {
                                "gt": 0
                            }
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        }
        search_body["query"]["bool"]["must"].append(usage_filter)
    elif index_name == 'Billing and Payments Billing':
        due_filter = {
            "range": {
                "amount_due": { "gt": 0 }
            }
        }
        search_body["query"]["bool"]["must"].append(due_filter)
    # elif index_name == 'Unposted':
    #     due_filter = {
    #         "range": {
    #             "charge_amount": { "gt": 0 }
    #         }
    #     }
    #     search_body["query"]["bool"]["must"].append(due_filter)
    elif index_name == "partner_users":
        logging.info(f"### partner_users role: {role}, tenant_name: {tenant_name}")
        role_order = [
            "Partner Admin",
            "Agent Partner Admin",
            "Agent",
            "User",
            "Notification Only User",
            "Qualification Only User"
        ]
        if role and role != "Super Admin":
            if role in role_order:
                supported_role = role_order[role_order.index(role):]
                usernames = get_usernames(tenant_name, supported_role)
                should_queries = []
                for r in supported_role:
                    should_queries.append({"wildcard": {"role.keyword": f"*{r}*"}})

                role_filters = {
                    "bool": {
                        "should": should_queries,
                        "minimum_should_match": 1
                    }
                }
                user_name = {
                    "terms": {
                        "username.keyword": usernames
                    }
                }
                search_body["query"]["bool"]["must"].append(role_filters)
                search_body["query"]["bool"]["must"].append(user_name)
                logging.info(f"### Supported roles: {supported_role}")
            else:
                logging.warning(f"### Role {role} not found in role_order")
        else:
            logging.info("### Super admin: No role-based filtering applied")
    else:
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    if index_name == "Charge Details":
        search_body["query"]["bool"].setdefault("must_not", []).append({
            "terms": {
                "category.keyword": ["MRC", "Credit"]
            }
        })
    if col_sort:
        try:
            # Extract field and order from the key
            field_to_sort, sort_order = next(iter(col_sort.items()))  
            # print("field_to_sort", field_to_sort)
            sort_order = sort_order.lower()  # Normalize to lowercase

            # Get the field type (Assuming `get_field_type` is a defined function)
            field_type = get_field_type(index_list, field_to_sort)


            # Modify field_to_sort if it is of type "text"
            if field_type == "text":
                field_to_sort = f'{field_to_sort}.keyword'

            # Check if the field and sort order are valid
            if field_to_sort and sort_order in ["asc", "desc"]:
                search_body["sort"] = [{field_to_sort: {"order": sort_order}}]  # Override default sort with key sorting
            else:
                logging.info("Invalid sorting key: Ensure the format is {<field_name>: 'asc'/'desc'}.")
        except StopIteration:
            logging.info("Error: The provided 'key' dictionary is empty or invalid.")
        except Exception as e:
            logging.info(f"An error occurred: {e}")
    # print("sort_clause -------", sort_clause)
    # if flag != "Pagination":
    #     search_body["scroll"] = scroll_time  # Define the scroll duration, e.g., "1m"
    #     search_body["size"] = 10000
    if sort_clause:
        search_body["sort"] = sort_clause

    if filters:
        for field, values in filters.items():
            if values:  # Check if values is not empty
                field_type = get_field_type(index_list, field)
                # print(f"Field: {field}, Field Type: {field_type}")
                if isinstance(values, list) and len(values) > 1:
                    if field_type in ["date", "long", "float"]:  # Adjust based on actual types returned by get_field_type
                        values = [v for v in values if v != '']  # Remove empty string
                        
                        # Update filters with cleaned values
                        filters[field] = values
                if isinstance(values, list):  # Handle lists
                    if len(values) == 1:
                        # Single value, handle boolean or other types
                        value = values[0]
                        if field in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost", "billing_cycle_end_date", "usage_date"] and index_name in ["carrier_optimization_list_view","customer_optimization_list_view", "daily_usage_report_export"]:
                            for value in values:
                                if isinstance(value, str) and ":" in value:
                                    try:
                                        logging.info("export check ----")
                                        if index_name == "daily_usage_report_export" and field in ["billing_cycle_end_date", "usage_date"]:
                                            logging.info("export check ---- 2")
                                            start_range, end_range = value.split(':')
                                            logging.info(f"export filters ---- start_range {start_range} and end_range {end_range} ")
                                            # Optional: validate format
                                            # datetime.datetime.strptime(start_range, "%Y-%m-%d")
                                            # datetime.datetime.strptime(end_range, "%Y-%m-%d")
                                            start_date = datetime.datetime.strptime(start_range, "%d-%m-%Y").strftime("%Y-%m-%d")
                                            end_date = datetime.datetime.strptime(end_range, "%d-%m-%Y").strftime("%Y-%m-%d")
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    field: {
                                                        "gte": start_date,  # Keep date as string
                                                        "lte": end_date
                                                    }
                                                }
                                            })
                                            logging.info(f"start range -- {start_date} and end range -- {end_date}")
                                        else:
                                            start_range, end_range = map(int, value.split(':'))
                                            # start_range = round(float(start_range))
                                            # end_range = round(float(end_range))
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    f"{field}": {
                                                        "gte": start_range,  # Greater than or equal to start of range
                                                        "lte": end_range     # Less than or equal to end of range
                                                    }
                                                }
                                            })
                                            search_body["sort"] = [
                                                    {f"{field}": {"order": "asc"}}
                                                ]
                                    except ValueError:
                                        logging.info(f"Invalid range format for {field}")
                                else:
                                    try:
                                        if index_name == "daily_usage_report_export" and field == "usage_date":
                                            logging.info(f"## value - {value}")
                                            date_value = datetime.datetime.strptime(value.strip(), "%m/%d/%Y").strftime("%Y-%m-%d")
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "term": {
                                                    field: date_value
                                                }
                                            })
                                            logging.info(f"Applied single date filter for {field}: {date_value}")
                                        else:
                                            start_range = int(value)
                                            end_range = int(value)+1
                                            search_body["query"]["bool"].setdefault("must", []).append({
                                                "range": {
                                                    f"{field}": {
                                                        "gte": start_range,  # Greater than or equal to start of range
                                                        "lt": end_range     # Less than or equal to end of range
                                                    }
                                                }
                                            })
                                            search_body["sort"] = [
                                                    {f"{field}": {"order": "asc"}}
                                                ]
                                    except ValueError:
                                        logging.info(f"Invalid range format for {field}")
                        elif isinstance(value, str) and ":" in value:
                            try:
                                start_range, end_range = value.split(':')
                                search_body["query"]["bool"].setdefault("must", []).append({
                                    "range": {
                                        f"{field}": {
                                            "gte": start_range,  # Greater than or equal to start of range
                                            "lte": end_range     # Less than or equal to end of range
                                        }
                                    }
                                })
                                search_body["sort"] = [
                                        {f"{field}": {"order": "asc"}}
                                    ]
                            except ValueError:
                                logging.info(f"Invalid range format for {field}")
                        elif field in ["created_date", "date_activated"] and is_redirected and index_name in ["Inventory", "inventory_export"]:
                            # Parse as date range
                            start_range, end_range = value.split(':')
                            # Optional: validate format
                            datetime.datetime.strptime(start_range, "%Y-%m-%d")
                            datetime.datetime.strptime(end_range, "%Y-%m-%d")
                            if field == "created_date":
                                earliest_date_query = {
                                    "size": 0,
                                    "aggs": {
                                        "min_date": {"min": {"field": field}}
                                    }
                                }
                                response = es.search(index=index_list, body=earliest_date_query)
                                start_range = response["aggregations"]["min_date"]["value_as_string"] if response["aggregations"]["min_date"]["value_as_string"] else end_range
                            logging.info(f"## start_range: {start_range}, end_range: {end_range}")
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "range": {
                                    f"{field}": {
                                        "gte": start_range,
                                        "lte": end_range
                                    }
                                }
                            })
                        elif isinstance(value, str) and value.strip() == "":
                            # Handle case where the single value is an empty string
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},  # Empty string
                                        {"bool": {"must_not": {"exists": {"field": field}}}}  # Missing field
                                    ]
                                }
                            })
                        elif field in ['category'] and value.lower() in ['ach','credit']:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value.lower()}  # Converts to lowercase
                            })
                        elif field in ['volte_capable', 'assigned'] and isinstance(value, str) and value.lower() in ['yes', 'no']:
                            # Convert 'yes'/'no' to boolean
                            if field == 'assigned' and index_name == 'Rate_Plan_Socs':
                                boolean_value = "Yes" if value.lower() == 'yes' else "No"
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": boolean_value}  # Use the converted boolean value
                                })
                            else:
                                boolean_value = True if value.lower() == 'yes' else False
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}": boolean_value}  # Use the converted boolean value
                                })
                        elif field in ['nsdev',"auto_change_rate_plan", "att_certified","is_billing_advance_eligible","allows_sim_pooling"] and isinstance(value, str) and value.lower() in ['true', 'false']:
                        # Handle boolean as string
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}  # Converts to a boolean
                            })
                        elif field_type == "long" and field=="bulk_change_id":  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif field in ["vw_users_tenant_roles", "is_active","vw_customer_rate_plans"] and isinstance(value, str) and value.lower() in ["active", "inactive"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "active" else "false"}
                            })
                        elif field in ["optimization_type"] and index_name == "Customer_Rate_Plan":
                            # Normalize the "Cross Customer Pooling" values
                            normalized_value = "Cross Customer Pooling" if value.lower() in ["cross customer pooling", "cross customer pooling", "cross customer pooling"] else value
                            
                            if normalized_value == "Cross Customer Pooling":
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}.keyword": ["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling", "Cross customer Pooling"]}
                                })
                            else:
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": normalized_value}
                                })
                        elif field in ["amop_apis", "carrier_apis", "email_templates"] and isinstance(value, str) and value.lower() in ["enable", "disable"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "enable" else "disable"}
                            })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.info(f"Invalid date format for item: {item}")
                                        # print(f"An Error Occurred in formatting billing_cycle_end_date")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.info(f"Invalid date format for item: {item}")

                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(value, (list, str)) and field_type != "float":
                            if value is None or (isinstance(value, str) and value == "(Spaces)"):
                                if isinstance(value, str):
                                    stripped_value = ""
                                    if stripped_value == "":
                                        search_body["query"]["bool"]["must"].append({
                                            "terms": {f"{field}.keyword": ["", " ", "  "]}  # Match exact empty string, single space, and double space
                                        })
                            elif field == 'prorate':
                                if isinstance(value, str):
                                    search_body["query"]["bool"]["must"].append({
                                        "term": {f"{field}": value }
                                    })
                            elif value.strip() not in [""," "] and value != "(Spaces)":
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": value }
                                })
                        # elif isinstance(value, (list, str)) and field_type == "text" and value.strip() not in [""," "]:
                        #     search_body["query"]["bool"]["must"].append({
                        #         "term": {f"{field}.keyword": value }
                        #     })
                        # for handling empty values
                        
                        
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, (list, str)) and field == "billing_cycle_end_date":
                            try:
                                if isinstance(value, str):
                                    value = [value]
                                formatted_values = convert_date_format(value)
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                            except ValueError:
                                continue            
                        elif isinstance(value, (list, str)):
                            try:
                                if isinstance(value, str):
                                    value = [value]  # Convert single string to a list if it's not already a list
                                for item in value:
                                    if isinstance(item, str):  # Ensure it's a string before adding to the query
                                        # Create a match query for each item in the list
                                        search_body["query"]["bool"]["must"].append({
                                            "match": {
                                                f"{field}": item  # Using match for full-text search
                                            }
                                        })
                            except ValueError:
                                continue
                        elif isinstance(value, (list, str)):  # Single int or float value
                            converted_value = convert_to_scientific_notation(value)
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, (int, float)):  # Single int or float value
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, str) and field == 'status'  and index_list=='sim_management_bulk_change_request':  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                        elif isinstance(value, str):  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        else:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                    else:
                        if field in ['category'] and index_name in ['Chargeback Exceptions','Payment History']:
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['ach', 'credit']]
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": values.lower()}  # Converts to lowercase
                            })

                        elif field in ['nsdev', "auto_change_rate_plan", "att_certified", "is_billing_advance_eligible", "allows_sim_pooling"] and isinstance(values, list):
                            # Ensure all values in the list are lowercase and valid boolean strings
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['true', 'false']]
                            
                            if lower_values:  # Proceed only if the list has valid boolean strings
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": lower_values}  # Add terms filter with lowercase values
                                })
                        elif any(isinstance(v, str) and v.strip() == "" for v in values):  
                            # Handle empty string or missing field cases
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},
                                        {"bool": {"must_not": {"exists": {"field": field}}}},
                                        {"terms": {f"{field}.keyword": [v for v in values if isinstance(v, str) and v.strip() != ""]}}
                                    ]
                                }
                            })
                        elif field_type == "text":
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}.keyword": values }
                            })
                        elif isinstance(values, (list, str)) and field_type == "date" and index_name == "daily_usage_report_export" and field in ["billing_cycle_end_date", "usage_date"]:
                            logging.info(f"export filters ---- {field} and {values}")
                            should_ranges = []
                            if isinstance(values, str):
                                values = [values]
                            for value in values:
                                if isinstance(value, str) and ":" in value:
                                    try:
                                        start_range, end_range = value.split(':')
                                        logging.info(f"export filters ---- start_range {start_range} and end_range {end_range}")

                                        start_date = datetime.datetime.strptime(start_range, "%d-%m-%Y").strftime("%Y-%m-%d")
                                        end_date = datetime.datetime.strptime(end_range, "%d-%m-%Y").strftime("%Y-%m-%d")

                                        should_ranges.append({
                                            "range": {
                                                field: {
                                                    "gte": start_date,
                                                    "lte": end_date
                                                }
                                            }
                                        })
                                        logging.info(f"start range -- {start_date} and end range -- {end_date}")

                                    except Exception as e:
                                        logging.info(f"Invalid date format for {field} → {value} ({e})")
                            if should_ranges:
                                search_body["query"]["bool"].setdefault("should", []).extend(should_ranges)
                                search_body["query"]["bool"]["minimum_should_match"] = 1
                            logging.info(f"export filters ---- {should_ranges}")
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        logging.info(f"Invalid date format for item: {item}")
                                        continue
                            # if formatted_values:
                            #     search_body["query"]["bool"]["must"].append({
                            #         "terms": {f"{field}": formatted_values}
                            #     })
                            if formatted_values:
                                if len(formatted_values) > 1024:
                                    # If too many dates, use a range query
                                    min_date = min(formatted_values)
                                    max_date = max(formatted_values)
                                    search_body["query"]["bool"]["filter"] = {
                                        "range": {f"{field}": {"gte": min_date, "lte": max_date}}
                                    }
                                else:
                                    # Use terms query if within limit
                                    search_body["query"]["bool"]["must"].append({
                                        "terms": {f"{field}": formatted_values}
                                    })
                        elif isinstance(values, (list, str)) and field == "billing_cycle_end_date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        formatted_value = convert_date_format(item)
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        
                        elif isinstance(values, (list, str)):
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):  # Ensure it's a string before adding to the query
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append(item)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {
                                        f"{field}": formatted_values  # List of values for multiple exact matches
                                    }
                                })
                        if isinstance(values, list) :
                            if all(isinstance(v, (int, float)) for v in values) :
                                # print(f"Adding terms filter for {field} with values: {values}") 
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {field: values}  
                                })
                        else:
                            # Multiple values in the list
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}": values}
                            })
                elif isinstance(values, dict) and field_type == 'date':
                    logging.info(f"Date range query: {field} -> {values}")

                    range_value = values.get("range")
                    include_empty = values.get("include_empty", False)

                    if range_value and ":" in range_value:
                        try:
                            start_range, end_range = range_value.split(":")

                            range_query = {
                                "range": {
                                    field: {
                                        "gte": start_range,
                                        "lte": end_range,
                                        "format": "yyyy-MM-dd"
                                    }
                                }
                            }

                            #  If empty values should also be included
                            if include_empty:
                                search_body["query"]["bool"].setdefault("should", []).append({
                                    "bool": {
                                        "should": [
                                            range_query,
                                            {
                                                "bool": {
                                                    "must_not": {
                                                        "exists": {
                                                            "field": field
                                                        }
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                })

                                # VERY IMPORTANT
                                search_body["query"]["bool"]["minimum_should_match"] = 1

                            else:
                                search_body["query"]["bool"].setdefault("must", []).append(range_query)

                            # Sorting
                            search_body["sort"] = [
                                {field: {"order": "asc"}}
                            ]

                        except ValueError:
                            logging.info(f"Invalid date range format for {field}")


                elif isinstance(values, bool):  # Single boolean condition
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, int):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, str):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}.keyword": values}
                    })
                else:
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
            elif values is False:
                search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
    search_body = add_customer_exists_filters(search_body, index_name, tenant_name, db_config)
    logging.info(f"### Search body: {search_body}")
    if index_name == "Active_lines_report":
        search_body["query"]["bool"]["must"].append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A","ACTIVATED"]
            }
        })
        logging.info(f"Advanced Search query {search_body}")

    if index_name == "rev_assurance":
        logging.info("adding is_active_status or rev_is_active_status filters")
        search_body["query"]["bool"]["should"].extend([
            {"term": {"is_active_status": False}},
            {"term": {"rev_is_active_status": False}}
        ])
        search_body["query"]["bool"]["minimum_should_match"] = 1
    elif index_name == "IMEI_Master_Table":
        if "must_not" not in search_body["query"]["bool"]:
            search_body["query"]["bool"]["must_not"] = []

        search_body["query"]["bool"]["must_not"].append({
            "exists": {"field": "deleted_date"}
        })
    elif index_name == "Customers":
        logging.info("adding rev_customer_id is null filter")
        if "must_not" not in search_body["query"]["bool"]:
            search_body["query"]["bool"]["must_not"] = []
        search_body["query"]["bool"]["must_not"].append({
            "exists": {"field": "rev_customer_id"}
        })
    elif index_name in ['Billing Report w/_City_County_Country','AR Aging Report','Export Variance Billing','Billing report by day with OCC Report','Total MRC for Sales Person: Catapult']:
        logging.info("adding bill_reversed_date is null filter")
        date_trunc_filter = {
            "script": {
                "script": {
                    "lang": "painless",
                    "source": """
                        if (doc['bill_reversed_date'].size() == 0) {
                            return true;
                        }

                        ZonedDateTime created = doc['created_date'].value;
                        ZonedDateTime reversed = doc['bill_reversed_date'].value;

                        return created.getYear() != reversed.getYear()
                            || created.getMonthValue() != reversed.getMonthValue();
                    """
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_trunc_filter)
    elif index_name in ["zero_usage_report", "usp_report_customer_usage_by_line", "usage_by_line_report", "newly_activated_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### adding customer_name, customer_id is not null filter")
            if "must" not in search_body["query"]["bool"]:
                search_body["query"]["bool"]["must"] = []
            search_body["query"]["bool"]["must"].extend([
                {"exists": {"field": "customer_id"}},
                {"term": {"customer_is_active": True}}
            ])
        else:
            logging.info("### Skipping customer_name, customer_id is not null filter. Due to main tenant")
    elif index_name in ["status_history_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### adding customer_id is not null filter")
            if "must" not in search_body["query"]["bool"]:
                search_body["query"]["bool"]["must"] = []
            search_body["query"]["bool"]["must"].extend([
                {"exists": {"field": "customer_id"}}
            ])
        else:
            logging.info("### Skipping customer_id is not null filter. Due to main tenant")
    logging.info(f"### Search body advanced: {index_name} -- {search_body}")

    try:
        response = es.search(index=index_list, body=search_body, scroll=scroll_time)
        response = replace_none_with_empty(response,index_list)

        scroll_id = response.get('_scroll_id')
        if not scroll_id:
            logging.info("Error: No scroll ID returned.")
            return None

        # Retrieve the hits
        all_hits = response['hits']['hits']
        # print("all_hits", all_hits)
        # print(f"Fetched {len(all_hits)} initial records.")
        total_records = response['hits']['total']['value']

    
        if flag == "Pagination":  # Check if flag is set for paginated results (scrolling)
                fetched_records = all_hits
                while True:
                    scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                    hits = scroll_response.get('hits', {}).get('hits', [])
                    
                    if not hits:
                        logging.info("No more records found.")
                        break

                    fetched_records.extend(hits)
                    # print(f"Fetched {len(hits)} more records, total: {len(fetched_records)}.")

                    # Update scroll_id for the next batch
                    scroll_id = scroll_response.get('_scroll_id')
                    if not scroll_id:
                        logging.info("Error: No scroll ID found in subsequent response.")
                        break

                # Return the records for the pagination range requested (start to end)
                
                paginated_results = fetched_records[start:end]
                es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
                cleaned_response = replace_none_with_empty(paginated_results,index_list)
                # return cleaned_response,total_records
                return paginated_results,total_records,search_body
        elif flag == "Nopagination":  # Handle fetching all records without pagination
            fetched_records = all_hits
            while True:
                if len(fetched_records) >= total_records:
                    # print("All records have been fetched.")
                    fetched_records = fetched_records[:total_records]
                    break

                scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                hits = scroll_response.get('hits', {}).get('hits', [])

                if not hits:
                    logging.info("No more records found.")
                    break

                fetched_records.extend(hits)
                # print(f"Fetched {len(hits)} more records, total: {len(fetched_records)}.")

                # Update scroll_id for the next batch
                scroll_id = scroll_response.get('_scroll_id')
                if not scroll_id:
                    logging.info("Error: No scroll ID found in subsequent response.")
                    break
            logging.info(f"### index_name ---- {index_name}")
            if index_name in ["Inventory", "inventory_export", "daily_usage_report_export","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
                logging.info(f"### Checking tenant information for tenant_name: {tenant_name}")
                database = DB("common_utils", **get_db_config("common_utils"))
                
                tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
                
                if not tenant_data.empty:
                    tenant_id = tenant_data["id"].to_list()[0]
                    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
                    
                    logging.info(f"### Tenant ID: {tenant_id} | Parent Tenant ID: {parent_tenant_id}")
                    
                    # Handle sub-tenant column swap if parent_tenant_id exists
                    if parent_tenant_id is not None:
                        logging.info("Sub-tenant detected, swapping column names for all fetched records")
                        
                        for hit in fetched_records:
                            source = hit.get('_source', {})
                            
                            # Swap sub_tenant_carrier_rate_plan_name to carrier_rate_plan_name
                            if 'sub_tenant_carrier_rate_plan_name' in source:
                                if index_name in ["Inventory", "inventory_export"]:
                                    source['carrier_rate_plan_name'] = source.pop('sub_tenant_carrier_rate_plan_name')
                                elif index_name in ["daily_usage_report_export","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
                                    source['carrier_rate_plan'] = source.pop('sub_tenant_carrier_rate_plan_name')
                            
                else:
                    logging.info(f"No tenant found for tenant_name: {tenant_name}")
            if index_name == 'sim_management_bulk_change':
                logging.info("check--index_name")
                grouped_sources = {}
                for hit in fetched_records:
                    source = hit.get("_source", {})
                    bulk_id = source.get("bulk_change_id",None)
                    if bulk_id and bulk_id not in grouped_sources:
                        grouped_sources[bulk_id] = hit

            # Prepare paginated results
            if index_name == 'sim_management_bulk_change':
                fetched_records = list(grouped_sources.values())
            total_records = len(fetched_records)
            es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
            cleaned_response = replace_none_with_empty(fetched_records,index_list)
            logging.info(f"length of cleaned_response {len(cleaned_response)}")
            # return cleaned_response, total_records
            return fetched_records, total_records,search_body
        else:
            # If flag is not set, just return the first batch of results
            return all_hits,total_records,search_body

    except Exception as e:
        logging.info(f"An error occurred while searching in Advance search data: {e}")
        return None

# AWS S3 client
s3_client = boto3.client('s3')


def export_inventory(data):
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]

    db = None
    database = None

    try:
        module_name = data.get("module_name", "")
        db = DB("common_utils", **get_db_config("common_utils"))
        partner = data.get("partner", "")
        user_name = data.get("username", "")
        tenant_details = db.get_data(
            "tenant",
            {"tenant_name": partner},
            ["id"],
        )
        tenant_id = tenant_details["id"].to_list()[0]
        updated = db.update_dict(
            "export_status",
            {"status_flag": "Waiting", "url": ""},
            {"module_name": module_name, "tenant_id": tenant_id, "user_name": user_name},
        )
        if not updated:
            db.insert_data(
                {
                    "module_name": module_name,
                    "url": "",
                    "status_flag": "Waiting",
                    "tenant_id": tenant_id,
                    "user_name": user_name,
                },
                "export_status",
            )

        # print("data--------", data)
        search = data.get("search")
        cols = data.get("cols")
        start = 0
        end = 10000
        try:
            pages = data.get("pages")
            start = int(pages.get("start", None))
            end = int("10000")
            # print("^^^^^^^^^^", start, end)
        except Exception as e:
            print(f"Pagination parameters missing or invalid: {e}")

        

        tenant_name = data.get("partner", "")
        if not tenant_name:
            raise ValueError("Tenant name is missing.")

        tenant_name = "Altaworx Test"
        tenant_time_zone = get_tenant_timezone(tenant_name)

        data['page_flag']="Nopagination"

        # data['index_name'] = "Inventory"


        results = perform_search(data)
        
        sources = results.get('data', {}).get('table', [])
        # print("^^^^^^^^^^^^^^^^^^^^^^",sources)
        total_rows = results.get('pages', {}).get('total', 0)
    
        if sources:
            # Create a DataFrame for the filtered data
            df = pd.DataFrame(sources)
            required_columns = [
                "service_provider_display_name", "msisdn", "iccid", "eid", "imei", "account_number",
                "customer_name", "username", "sim_status", "sms_count", "minutes_used",
                "ip_address", "telegence_feature", "communication_plan", "carrier_rate_plan_name",
                "carrier_rate_plan_mb", "carrier_rate_plan_display_rate",
                "customer_rate_pool_name", "customer_rate_plan_name", "customer_data_allocation_mb",
                "date_activated", "cost_center", "billing_account_number",
                "foundation_account_number", "device_make", "device_model", "service_zip_code",
                "next_bill_cycle_date", "date_added", "modified_by", "modified_date"
            ]

            # Get optimization setting
            db_name = data.get("db_name", "altaworx_test")
            database = DB(db_name, **get_db_config(db_name))
            p = database.execute_query(f"select optino_cross_providercustomer_optimization from optimization_setting", True).iloc[0, 0]
            
            # Add usage columns based on p value
            if p:
                required_columns.extend(["carrier_cycle_usage_mb", "customer_cycle_usage_mb"])
            else:
                required_columns.append("carrier_cycle_usage_mb")

            available_columns = [col for col in required_columns if col in df.columns]
            # Filter the DataFrame to include only the required columns
            df = df[available_columns]

            # Define column renaming mapping
            rename_columns = {
                "service_provider_display_name": "service_provider_name",
                "carrier_rate_plan_name": "rate_plan",
                "carrier_rate_plan_display_rate": "carrier_rate_plan_cost",
                "sim_status": "status",
                "plan_limit_mb": "carrier_data_allocation_mb",
                "telegence_feature": "feature_codes",
                "carrier_rate_plan_mb": "carrier_data_allocation_mb",
                "sms_count": "sms_total"
            }

            # Add usage column renaming based on p value
            if p:
                rename_columns.update({
                    "carrier_cycle_usage_mb": "carrier_cycle_usage",
                    "customer_cycle_usage_mb": "customer_cycle_usage"
                })
            else:
                rename_columns["carrier_cycle_usage_mb"] = "data_usage_mb"

            # Rename columns
            df.rename(columns=rename_columns, inplace=True)

            # Create a list of all columns
            all_columns = list(df.columns)
            
            if "status" in all_columns:
                # Find the position of status_display_name
                status_index = all_columns.index("status")

                # Remove usage columns from their current position and insert after status_display_name
                if p:
                    # Remove usage columns if they exist
                    if "carrier_cycle_usage" in all_columns:
                        all_columns.remove("carrier_cycle_usage")
                    if "customer_cycle_usage" in all_columns:
                        all_columns.remove("customer_cycle_usage")

                    # Insert after status_display_name
                    all_columns.insert(status_index + 1, "carrier_cycle_usage")
                    all_columns.insert(status_index + 2, "customer_cycle_usage")
                else:
                    # Remove data_usage_mb if it exists
                    if "data_usage_mb" in all_columns:
                        all_columns.remove("data_usage_mb")

                    # Insert after status_display_name
                    all_columns.insert(status_index + 1, "data_usage_mb")

            # Reorder the DataFrame columns
            df = df[all_columns]

            # print(df, "22222222222222")

            # Convert all large integers to strings to avoid scientific notation
            # Ensure all numeric columns are converted to plain strings
            for col in df.columns:
                if df[col].dtype in ['int64', 'float64']:
                    df[col] = df[col].apply(lambda x: str(int(x)) if pd.notnull(x) else '')
            # Filter the DataFrame to include only the required columns
            #df = df[required_columns]
            # df.columns = [col.replace('_', ' ').capitalize() for col in df.columns]
            # df.columns = [" ".join(word.capitalize() for word in col.split("_")) for col in df.columns]
            acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "MSISDN", "IP"}

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {
                "Att": "AT&T",
                "And": "and"
            }
            # Format column names
            df.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in df.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            df.columns = [
                " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
            ]




            # df['S.No'] = range(1, len(df) + 1)
            # columns = ['S.No'] + [col for col in df.columns if col != 'S.No']
            # df = df[columns]
            # # Convert to CSV (you can convert to Excel if you prefer)
            # csv_buffer = StringIO()
            # df.to_csv(csv_buffer, index=False)

            # # Upload the CSV file to S3
            # file_name = f"exports/search/Inventory_export.csv"
            # csv_buffer.seek(0)  # Move to the start of the StringIO buffer

            # # Upload to S3 (public or private based on your needs)
            # s3_client.put_object(
            #     Bucket=S3_BUCKET_NAME,
            #     Key=file_name,
            #     Body=csv_buffer.getvalue(),
            #     ContentType='text/csv'
            # )
            # Convert DataFrame to Excel using openpyxl
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                df.to_excel(writer, index=False, sheet_name="Inventory")
                workbook = writer.book
                sheet = writer.sheets["Inventory"]

                # Write headers with formatting
                for c_idx, column in enumerate(df.columns, start=1):
                    cell = sheet.cell(row=1, column=c_idx, value=column)
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")

                # Write data rows
                for r_idx, row in enumerate(df.itertuples(index=False), start=2):
                    for c_idx, value in enumerate(row, start=1):
                        sheet.cell(row=r_idx, column=c_idx, value=value)

                # Adjust column widths
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

            excel_buffer.seek(0)

            # Define the file name for the Excel file
            file_name = f"exports/search/export/Inventory Export_{tenant_id}_{user_name}.xlsx"

            # Upload the Excel file to S3
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )

            # Generate URL (public URL or pre-signed URL)
            download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
            search_result = {
                'flag': True,
                'download_url': download_url  # Return the URL where the file is stored in S3
            }
            db.update_dict(
                "export_status",
                {"status_flag": "Success", "url": download_url},
                {"module_name": module_name, "tenant_id": tenant_id, "user_name": user_name},
            )
            return search_result            
    except Exception as e:
        print(f"Exception is {e}")

        if db:
            db.update_dict(
                "export_status",
                {"status_flag": "Failed"},
                {"module_name": module_name, "tenant_id": tenant_id, "user_name": user_name},
            )

        return {
            "flag": False,
            "message": "No Records found",
        }

    finally:
        if database is not None:
            database.close()
        if db is not None:
            db.close()

def get_tenant_timezone(tenant_name):
    try:
        db_name = "common_utils"
        database = DB(db_name, **get_db_config(db_name))
        tenant_timezone_query = f"SELECT time_zone FROM tenant WHERE tenant_name = '{tenant_name}'"
        table_data = database.execute_query(tenant_timezone_query, True)

        tenant_time_zone = "UTC" 
        
        if not table_data.empty and 'time_zone' in table_data.columns:
            tenant_time_zone = table_data['time_zone'].iloc[0]
        if tenant_time_zone is None:
            print(f"No valid timezone found for tenant '{tenant_name}'. Using UTC as fallback.")
            tenant_time_zone = "UTC"
        
        match = re.search(r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone)
        if match:
            tenant_time_zone = "Asia/Kolkata"

        return tenant_time_zone
    except Exception as e:
        logging.info(f"## An Error Occured as {e}")
        return None
    finally:
        if database:
            database.close()


def fetch_and_pivot_daily_device_usage(df, device_table, device_id_field, billing_cycle_start, cycle_end_date, billing_cycle_dates, database):
    if df.empty:
        return pd.DataFrame()
    
    try:
        unique_iccid = df["MSISDN"].unique()
        if not unique_iccid.any():
            return pd.DataFrame()
        if len(unique_iccid) == 1:
            iccid_str = f"('{unique_iccid[0]}')"  # no trailing comma
        else:
            iccid_str = str(tuple(unique_iccid))  # normal tuple syntax

        iccid_query = f"""
            SELECT id, msisdn FROM {device_table}
            WHERE msisdn IN {iccid_str} AND is_active = 'true'
        """
        iccid_df = database.execute_query(iccid_query, True).drop_duplicates(subset=["msisdn"])
        iccid_list = iccid_df.set_index("id")["msisdn"].replace('', None).to_dict()
        device_ids = list(iccid_list.keys())
        
        # Avoid empty IN clause
        if not device_ids:
            return pd.DataFrame()
        # Build SQL-safe IN clause
        if len(device_ids) == 1:
            id_str = f"({device_ids[0]})"  # no trailing comma
        else:
            id_str = str(tuple(device_ids))
            
        
        device_usage_query = f"""
            SELECT {device_id_field} AS mobility_device_id, usage_date, data_usage
            FROM device_usage
            WHERE {device_id_field} IN {id_str} 
            AND usage_date BETWEEN '{billing_cycle_start}' AND '{cycle_end_date}'
        """
        logging.info(f"device_usage_query - {device_usage_query}")
        
        device_usage_df = database.execute_query(device_usage_query, True)
        if device_usage_df.empty:
            return pd.DataFrame()
        
        device_usage_df["usage_date"] = pd.to_datetime(device_usage_df["usage_date"]).dt.strftime("%Y-%m-%d")
        grouped_device_usage_df = device_usage_df.groupby(["mobility_device_id", "usage_date"], as_index=False).sum()
        
        merged_usage_df = pd.merge(
            grouped_device_usage_df, iccid_df,
            left_on="mobility_device_id", right_on="id", how="left"
        ).drop(columns=["id", "mobility_device_id"], errors='ignore').rename(columns={"msisdn": "MSISDN"})
        
        logging.info(f"merged_usage_df_aft - {merged_usage_df.head()}")
        usage_pivot = merged_usage_df.pivot_table(index="MSISDN", columns="usage_date", values="data_usage", aggfunc="sum")
        return usage_pivot
    except Exception as e:
        logging.exception(f"### fetch_and_pivot_daily_device_usage Error : {e}")
        return pd.DataFrame()
    




def search_export(data):
    logging.info("### search_export called")
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]
    module_name = data.get("module_name", "")
    module_name = "Daily usage report Export" if module_name == "Daily usage report" else module_name
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    db_name = data.get('db_name')
    if module_name == "Daily usage report Export":
        data["index_name"] = "daily_usage_report_export"
    index_name = data.get('index_name', "")
    role_name=data.get('role_name', "Super Admin")
    tenant_name = data.get("partner", "")
    user_name = data.get("username","")
    s3_client = boto3.client("s3")

    db = DB("common_utils", **get_db_config("common_utils"))
    tenant_details = db.get_data(
        "tenant",
        {"tenant_name": tenant_name},
        ["id"],
    )
    tenant_id = tenant_details["id"].to_list()[0]
    module_name_snake_case = f"{module_name_snake_case}_{tenant_id}_{user_name}"
    updated = db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name,"tenant_id":tenant_id,"user_name":user_name},
    )
    if not updated:
        db.insert_data(
            {
                "module_name": module_name,
                "url": "",
                "status_flag": "Waiting",
                "tenant_id":tenant_id,
                "user_name":user_name,
            },
            "export_status"
        )
    
    filter_data = data.get("filter", {})
    try:
        search = data.get("search")
        cols = data.get("cols")
        start = 0
        end = 10000
        try:
            pages = data.get("pages")
            start = int(pages.get("start", None))
            end = int(pages.get("end", 10000))
        except Exception as e:
            logging.exception(f"## Pagination parameters missing or invalid: {e}")

        tenant_name = data.get("partner", "")
        if not tenant_name:
            raise ValueError("Tenant name is missing.")

        tenant_name = "Altaworx"
        tenant_time_zone = get_tenant_timezone(tenant_name)


        data['page_flag']="Nopagination"

        results = perform_search(data)
        if module_name == "Charge Overview":
            var=export_charge_overview_excel(data,results)
            return var
            

        # logging.info("### results : %s", results)
        sources = results.get('data', {}).get('table', [])
        total_rows = results.get('pages', {}).get('total', 0)

            #return {"flag":True,"results":sources}
            # Filter the columns if 'cols' are provided

        if sources:

            # Create a DataFrame for the filtered data
            df = pd.DataFrame(sources)
            # required_columns = [
            #     "service_provider_display_name", "imei", "rate_plan", "data_usage_mb", "sms_count",
            #     "cost_center", "account_number", "customer_name", "date_added", "iccid",
            #     "msisdn", "eid", "username", "data_usage_bytes",
            #     "customer_rate_pool_name", "customer_rate_plan_name", "status_display_name",
            #     "date_activated", "ip_address", "billing_account_number", "foundation_account_number",
            #     "modified_by", "modified_date"
            # ]
            # Specify the required columns from the original data
            # Specify the required columns from the original data (duplicates removed)
            logging.info(f"######## df: {df}")
            ##databse connenction
            database = DB("common_utils", **get_db_config("common_utils"))
            # Fetch the query from the database based on the module name
            module_query_df = database.get_data(
                "export_columns", {"module_name": module_name}
            )

            # checking the dataframe is empty or not
            if module_query_df.empty:
                return {
                    "flag": False,
                    "message": f"No query found for module name: {module_name}",
                }

            # Extract the required columns from the query result
            required_columns = module_query_df.iloc[0].get("required_columns")
            if not required_columns:
                logging.exception(f"## Unknown module name: {module_name}")
                return {"flag": False, "message": f"Unknown module name: {module_name}"}

            # Parse the required columns as a list (assuming they are stored as a comma-separated string)
            required_columns = [col.strip().strip('"') for col in required_columns.split(",")]

            # Special handling for "Usage By Line Report"
            # if module_name == "Usage By Line Report" and "customer_cycle_end_date" in df.columns:
            #     if "billing_cycle_end_date" in required_columns:
            #         idx = required_columns.index("billing_cycle_end_date")
            #         required_columns.pop(idx)
            #         required_columns.insert(idx, "customer_cycle_end_date")

            # 🔹 Special handling for "Daily usage report Export"
            if module_name == "Daily usage report Export" and index_name != 'daily_usage_report':
                rename_map = {
                    "service_provider_display_name": "service_provider",
                    "customer_rate_pool_name": "customer_pool",
                    "rate_plan_name": "customer_rate_plan",
                    "datausagemb": "data_usage_mb",
                    "status_display_name": "sim_status",
                    "billing_cycle_end_date":"usage_date",
                }
                # 1. Rename df columns
                df.rename(columns=rename_map, inplace=True)
                # 2. Rename required_columns too
                required_columns = [rename_map.get(col, col) for col in required_columns]

            # Ensure all required columns exist in the DataFrame
            df_columns = [col.strip().strip('"') for col in df.columns]  # Normalize column names in DataFrame
            if module_name == 'Customer Rate Pool Usage Report':
                if "data_allocation_mb" in df.columns and "data_allocation_mb" not in required_columns:
                    required_columns.append("data_allocation_mb")
                if "data_usage_mb" in df.columns and "data_usage_mb" not in required_columns:
                    required_columns.append("data_usage_mb")
            missing_columns = [col for col in required_columns if col not in df_columns]

            if missing_columns:
                return {
                    "flag": False,
                    "message": f"Missing required columns in data: {', '.join(missing_columns)}",
                }

            # Filter the DataFrame to include only the required columns
            df = df[required_columns]

            tenant_name = data.get("partner", "")
            if tenant_name in ('Altaworx', 'Altaworx Test') and module_name in ("Active Customer Rate Plan","Customer Rate Plan"):
                tenant_name = "Altaworx"
            # tenant_data = db.get_data("tenant", {"tenant_name": tenant_name}, ["id","billing_platform_flag"])
            # tenant_id = tenant_data["id"].to_list()[0]
            
            # billing_platform_flag = tenant_data["billing_platform_flag"].to_list()[0]
            # if module_name in ("Active Customer Rate Plan","Customer Rate Plan") and billing_platform_flag:
            #     module_name = module_name + " Billing Platform"
            
            # logging.info(f"### search export billing_platform_flag: {billing_platform_flag}")
            # logging.info(f"### search export tenant_id: {tenant_id}")
            # logging.info(f"### search export module_name: {module_name}")

            
            if module_name in ["Usage By Line Report","New Usage By Line Report"]:
                print("DEBUG: Usage By Line Report - df.columns:", df.columns.tolist())
                
                # Ensure 'data_usage_mb' is numeric
                df['data_usage_mb'] = pd.to_numeric(df['data_usage_mb'], errors='coerce').fillna(0)
                
                # Filter out rows with missing billing_cycle_end_date
                df_with_dates = df.dropna(subset=['billing_cycle_end_date']).copy()
                
                if df_with_dates.empty:
                    logging.info("## No valid billing cycle dates found after filtering.")
                else:
                    # Convert billing_cycle_end_date to datetime for proper handling
                    df_with_dates['billing_cycle_end_date'] = pd.to_datetime(df_with_dates['billing_cycle_end_date'], errors='coerce')
                    
                    # Remove any rows where date conversion failed
                    df_with_dates = df_with_dates.dropna(subset=['billing_cycle_end_date'])
                    
                    if df_with_dates.empty:
                        logging.info("## No valid dates after datetime conversion.")
                    else:
                        # Get unique billing periods
                        billing_cycle_period = df_with_dates['billing_cycle_end_date'].dt.strftime('%Y-%m-%d').unique().tolist()
                        primary_billing_period = billing_cycle_period[0] if billing_cycle_period else None
                        
                        if primary_billing_period:
                            # Create df_secondary with necessary columns - handle missing ICCID
                            df_secondary = df_with_dates[['iccid','msisdn','billing_cycle_end_date', 'data_usage_mb']].copy()
                            
                            # Remove rows with missing ICCID
                            df_secondary = df_secondary.dropna(subset=['iccid','msisdn'])
                            
                            if df_secondary.empty:
                                logging.info("## No valid ICCID data for pivot operation.")
                            else:
                                # Convert date to string format for pivot
                                df_secondary['billing_cycle_end_date_str'] = df_secondary['billing_cycle_end_date'].dt.strftime('%Y-%m-%d')
                                
                                # Group by 'iccid' and 'billing_cycle_end_date_str', summing 'data_usage_mb' to handle duplicates
                                df_secondary_grouped = df_secondary.groupby(['iccid','msisdn', 'billing_cycle_end_date_str'], as_index=False)['data_usage_mb'].sum()
                                

                                if not df_secondary_grouped.empty:
                                    try:
                                        # Get base info (non-pivoted columns) - remove duplicates by ICCID
                                        base_columns = [
                                            'service_provider_display_name', 'iccid', 'msisdn', 'foundation_account_number',
                                            'billing_account_number', 'customer_rate_pool_name', 'customer_name', 'carrier_rate_plan', 
                                            'rate_plan_name', 'username',  'cost_center', 'ip_address', 'sms_usage', 'status_display_name', 'date_activated'
                                        ]
                                        
                                        # Filter base_columns to only include columns that exist in df
                                        existing_base_columns = [col for col in base_columns if col in df.columns]
                                        
                                        # Get base data - remove duplicates by ICCID, keeping first occurrence
                                        df_base = df_with_dates.drop_duplicates(subset=['iccid','msisdn'])[existing_base_columns].copy()
                                        
                                        # --- Pivot for MB Usage: don't use fill_value so missing ICCIDs stay NaN (which we convert to blank) ---
                                        df_pivot_usage = df_secondary_grouped.pivot_table(
                                            index=['iccid','msisdn'],
                                            columns='billing_cycle_end_date_str',
                                            values='data_usage_mb',
                                            aggfunc='sum'   # sum duplicates if any
                                        ).reset_index()
                                        
                                        # Rename MB Usage columns to include "MB Usage" suffix (same as your original)
                                        usage_columns = {}
                                        for date_str in df_pivot_usage.columns:
                                            if date_str not in ['iccid','msisdn']:
                                                try:
                                                    date_obj = pd.to_datetime(date_str)
                                                    #Manual formatting to avoid platform issues
                                                    month = date_obj.month
                                                    day = date_obj.day
                                                    year = date_obj.year % 100  # Get 2-digit year
                                                    formatted_date = f"{month}/{day}/{year:02d}"
                                                    # formatted_date = date_obj.strftime("%m/%d/%Y")
                                                    usage_columns[date_str] = f"{formatted_date} MB Usage"
                                                except:
                                                    usage_columns[date_str] = f"{date_str} MB Usage"
                                        
                                        df_pivot_usage = df_pivot_usage.rename(columns=usage_columns)
                                        
                                        # Merge base data with pivoted usage data
                                        data_frame = df_base.merge(df_pivot_usage, on=['iccid','msisdn'], how='left')
                                        
                                        # Reorder columns: base columns + MB Usage columns
                                        mb_usage_cols = [col for col in data_frame.columns if 'MB Usage' in col]
                                        
                                        # Create final column order
                                        other_cols = [col for col in existing_base_columns if col not in ['sms_usage', 'status_display_name', 'date_activated']]
                                        final_columns = (
                                            other_cols + 
                                            mb_usage_cols + 
                                            (['sms_usage'] if 'sms_usage' in existing_base_columns else []) +
                                            (['status_display_name'] if 'status_display_name' in existing_base_columns else []) +
                                            (['date_activated'] if 'date_activated' in existing_base_columns else [])
                                        )
                                        
                                        # Only keep columns that exist in data_frame
                                        final_columns = [col for col in final_columns if col in data_frame.columns]
                                        data_frame = data_frame[final_columns]
                                        
                                        # Convert NaN -> '' for MB Usage columns only (this leaves real 0 values intact)
                                        for col in mb_usage_cols:
                                            if col in data_frame.columns:
                                                # keep numeric zeros as 0, but replace NaN (missing ICCID for that period) with empty string
                                                data_frame[col] = data_frame[col].where(~data_frame[col].isna(), '')
                                        
                                        # Update df with the pivoted data
                                        df = data_frame
                                        
                                        logging.info(f"## Successfully pivoted data. Final shape: {df.shape}")
                                        
                                    except Exception as pivot_error:
                                        logging.exception(f"## Pivot operation failed: {pivot_error}")
                                        # Fallback to original df if pivot fails
                                        logging.info("## Using original data without pivot.")
                                else:
                                    logging.info("## No data after grouping operation.")
                        else:
                            logging.info("## No primary billing period found.")
                    # NEW LOGIC ENDS HERE

                    # ORIGINAL PIVOT LOGIC (COMMENTED OUT - keeping for reference)
                    # # Pivot the secondary data to make 'billing_cycle_end_date' values as columns
                    # df_pivot = df_secondary.pivot(index='iccid', columns='billing_cycle_end_date', values='data_usage_mb').reset_index()

                    # # Merge the pivoted data with the main data
                    # df_final = df.merge(df_pivot, on='iccid', how='outer')

                    # # Rename columns using billing cycle values
                    # rename_dict = {date: str(date) for date in billing_cycle_period if date in df_final.columns}
                    # df_final.rename(columns=rename_dict, inplace=True)

                    # # Rename 'data_usage_mb' to the primary billing period
                    # if 'data_usage_mb' in df_final.columns:
                    #     df_final.rename(columns={'data_usage_mb': str(primary_billing_period)}, inplace=True)

                    # df = df_final

            
            
            
            # Rename the columns to match the SQL aliases
            if module_name == "SimManagement Inventory":
                def truncate_to_2_decimal(x):
                    return math.floor(x * 100) / 100
                if 'carrier_cycle_usage_mb' in df.columns:
                    df['carrier_cycle_usage_mb'] = df['carrier_cycle_usage_mb'].apply(truncate_to_2_decimal)
                df.rename(
                    columns={
                        "service_provider_display_name": "service_provider_name",
                        "data_usage_bytes": "carrier_cycle_usage",
                        "status_display_name": "sim_status",
                        "carrier_rate_plan_display_rate": "carrier_rate_plan_cost",
                        "plan_limit_mb": "carrier_data_allocation_mb",
                        "telegence_feature": "feature_codes",
                    },
                    inplace=True,
                )
            if module_name == "Customer Groups":
                df.rename(
                    columns={
                        "sub_tenant_name": "sub_partner",
                    },
                    inplace=True,
                )

            if module_name == "Active Private Networks":
                df.rename(
                    columns={
                        "service_provider": "carrier",
                        "ip_start_range":"start_range",
                        "ip_end_range":"end_range",
                        "modified_date":"last_modified_date_&_time",
                        "modified_by":"last_modified_by"
                    },
                    inplace=True,
                )

            if module_name == "Automation rule verification report":
                df.rename(
                    columns={
                        "service_provider_name": "service_provider",
                        "remove_trigger_1": "remove"
                    },
                    inplace=True,
                )
                
            if module_name=='Rate Plan Socs':
                df.rename(
                    columns={
                        "service_provider": "provider","rate_plan_short_name":"soc_code",
                        "base_rate": "base_price",
                        "data_per_overage_charge": "$_mb",
                        "overage_rate_cost": "Overage_$_MB",
                        "plan_mb": "mb_included",
                        "modified_by": "last_modified_by",
                        "modified_date": "last_modified_date"
                    },
                    inplace=True,
                )
            if module_name == 'Users':
                df.rename(
                    columns={
                        "is_active": "user_status","tenant_names":"partner","email":"email_id","modified_by":"last_modified_by","modified_date":"last_modified_date_and_time"
                    },
                    inplace=True,
                )
            if module_name in ["Usage By Line Report","New Usage By Line Report"]:
                df.rename(
                    columns={
                        "status_display_name": "sim_status"
                    },
                    inplace=True,
                )
            if module_name=='Customer Charges':
                df.rename(
                    columns={
                        "rev_customer_id": "account_number"
                    },
                    inplace=True,
                )
            if module_name=='Billing Services':
                df.rename(
                    columns={
                        "description": "service_type", "id":"service_id","service_provider_name":"service_provider"

                    },
                    inplace=True,
                )
            if module_name == 'Product Level Tax Mapping':
                df.rename(
                    columns={
                        "account_number":"account_id","inv_bill_id":"bill_id","product_rate":"mrc","products_tax":"taxes","total_amount":"total"

                    },
                    inplace=True,
                )
            if module_name == 'Billing Products':
                df.rename(
                    columns={
                        "id":"product_id","service_provider":"provider","product_type":"type","ps_code":"tax_code","g_l_code":"gl_code","is_active":"status"

                    },
                    inplace=True,
                )
            if module_name == 'Billing Packages':
                df.rename(
                    columns={
                        "id":"package_id","category":"package_name"

                    },
                    inplace=True,
                )
            if module_name == 'Unposted Upload Data':
                df.rename(
                    columns = {"service_provider_name":"provider"},
                    inplace=True,
                )
            if module_name == 'Unposted Upload Status':
                df.rename(
                    columns = {"created_by":"uploaded_by"},
                    inplace=True,
                )
            if module_name=='Unposted Items':
                df.rename(
                    #columns={"customer_id":"Customer ID","description":"Description","amount":"Amount","mrc":"MRC","calculated_cost":"Usage","sms_cost":"SMS","tax_name":"Tax","start_date":"Start Date","end_date":"End Date","created_date":"Created Date","tn":"Tn","line_id":"Line ID","product_id":"Product ID"},
                    columns={"customer_id":"customer_id","description":"Description","amount":"Amount","mrc":"MRC","calculated_cost":"Usage","sms_cost":"SMS","tax_name":"Tax","start_date":"start_date","end_date":"end_date","created_date":"created_date","tn":"Tn","line_id":"line_id","product_id":"product_id"},
                    inplace=True,
                )
            if module_name in ['Billing and Collections Reversals','Billing and Collections Unposted']:
                df.rename(
                    columns={
                        "telephone_number":"tn","charge_description":"description","charge_amount":"amount","unbilled_usage_charge":"usage","unbilled_sms_charge":"sms","tax_name":"tax","created_date":"created"
                    },
                    inplace=True,
                )
            if module_name == 'Payment History Report':
                df.rename(
                    columns={
                        "date":"payment_date","created_date":"bill_date"
                    },
                    inplace=True,
                )

            if module_name == 'AR Aging Report':
                df.rename(
                    columns={
                        "template_description":"collection_template","step_description":"collection_step",
                    },
                    inplace=True,
                )
            if module_name == "Usage Details":
                df.rename(
                    columns={
                        "usage_mb":"usage","sms_cost":"sms","usage_tax_amount":"usage_tax","sms_tax_amount":"sms_tax"
                    },
                    inplace=True,
                )
            if module_name == "Charge By Service":
                df.rename(
                    columns={
                        "account_number":"account","billed_usage_charge":"usage","billed_sms_charge":"sms","tax_amount":"tax"
                    },
                    inplace=True,
                )
                if 'packages' not in df.columns:
                    df['package'] = '' 
                
                primary_idx = df.columns.get_loc('primary_identifier')
                other_cols = [col for col in df.columns if col not in ['package', 'primary_identifier']]
                
                
                cols_before_primary = df.columns[:primary_idx].tolist()
                new_column_order = cols_before_primary + ['primary_identifier', 'package'] + other_cols
                
                df = df[new_column_order]
            
            if module_name == 'Billing and Payments Billing':
                df.rename(
                    columns={
                        "id":"bill","due_date_of_this_bill":"due_date","email_status":"flags",
                    },
                    inplace=True,
                )
            if module_name == 'Billing and Payments-Payment History':
                df.rename(
                    columns={
                        "id":"payment_id","ref":"transaction_id","category":"method"
                    },
                    inplace=True,
                )
            if module_name in ['Charge Overview Recurring Charges','Charge Overview Account Credits','Charge Overview Account Charges']:
                df.rename(
                    columns={
                        "charge_description":"description","charge_amount":"amount"
                    },
                    inplace=True,
                )
            if module_name == 'Transaction Report':
                df.rename(
                    #columns={"account_number":"Account Number","customer_name":"Customer Name","iccid":"ICCID","description":"Description","gl_code":"G/L Code","product_id":"Product ID","bill_range":"Bill Range","category":"Category","amount":"Amount","mrc":"MRC","calculated_cost":"Usage","sms_cost":"SMS","tax_name":"Tax","modified_date":"Modified Date"},
                    columns={"account_number":"account_number","customer_name":"customer_name","description":"description","gl_code":"gl_code","product_id":"product_id","bill_range":"bill_range","category":"type","amount":"Amount","nrc": "NRC","mrc":"MRC","calculated_cost":"usage","sms_cost":"SMS","tax_name":"Tax","modified_date":"modified_date"},
                    inplace=True,
                )
            if module_name == 'Export Cycle Date':
                df.rename(
                    columns={
                        "sales_person": "agent_name","bill_cycle_start_date": "current_cycle_date"
                    },
                    inplace=True,
                )
            if module_name == 'Export Variance Billing':
                df.rename(
                    columns={
                        "account_number": "customer_id","prev_mrc":"prevmrc","mrc":"currmrc","diff_mrc":"netmrc","prev_nrc_usage":"prevnrcusage","nrc_usage":"currnrcusage","diff_nrc_usage":"netnrcusage","prev_nrc":"prevnrc","nrc":"currnrc","diff_nrc":"netnrc"
                    },
                    inplace=True,
                )
            if module_name == 'Billing Customer Profiles':
                df.rename(
                    columns={
                        "account_number":"account_id","customer_name":"name","customer_address_text":"address","bill_cycle_start_date":"bill_cycle"
                    },
                    inplace=True,
                )

            if module_name== 'Billing Report w/_City_County_Country':
                df.rename(
                    #columns={"account_number":"Account Number","account_type":"Account Type","customer_name":"Customer Name","bill_id":"Bill ID","sales_person":"Sales Person","secondary_sales_person":"Secondary Sales Person","bill_cycle_start_date":"Statement Date","amount_due":"Balance Forward","mrc":"MRC","nrc":"NRC","network_access_fee":"Network Access Fee","cost_recovery_fee":"Admin Recovery Tax","taxes":"Other Taxes","total":"Total","payments":"Payments","bill_due_date":"Bill Due Date","account_balance":"Account Balance","state":"State","timezone":"Timezone"},
                    columns={"bill_cycle_start_date":"statement_date","amount_due":"balance_forward","mrc":"mrc","nrc":"nrc","network_access_fee":"network_access_fee","cost_recovery_fee":"admin_recovery_tax","taxes":"other_taxes","total":"total","payments":"payments","bill_due_date":"payment_date","sales_person":"agent","secondary_sales_person":"secondary_agent","account_balance":"balance","state":"county","timezone":"timezone"},
                    inplace=True,
                )
            if module_name == 'Total MRC for Sales Person: Catapult':
                df.rename(
                    columns={"account_number":"customer_id","customer_name":"customer_name","contract_start_date":"contract_sign_date","customer_creation_date":"customer_created_date","bill_id":"statement_id","bill_generation_date":"statement_created_date","due_date_of_this_bill":"due_date"},
                    inplace=True,
                )
            if module_name == 'Chargeback Exceptions':
                df.rename(
                    columns={"bill_list":"bill_id","ref_guid":"transaction_id","date":"activity_date","last_four":"payment_type","account_number":"customer_id"},
                    inplace=True,
                )
            if module_name == 'Billing Customers':
                df.rename(
                    columns={"tenant_name":"partner","customer_name":"name","bp_account_number":"account_number","bp_account_type":"account_type","bp_billing_cycle_start_date":"billing_cycle_start_date"},
                    inplace=True,
                )
            if module_name == 'Rev assurance':
                df.rename(
                    columns={
                        "rev_account_number": "customer_id",
                        "service_number":"service_id",
                        "service_provider":"carrier",
                        "customer_rate_plan_name":"customer_rate_plan",
                        "device_status":"carrier_status",
                        "carrier_last_status_date":"carrier_status_date",
                        "description":"product",
                        "rev_io_status":"billing_platform_status",
                        "activated_date":"billing_platform_status_date"
                    },
                    inplace=True,
                )  
                    
            if module_name == 'Customer Services':
                df.rename(
                    columns={"custom_primary_field_value":"custom_primary_identifier"},
                    inplace=True,
                )
            if module_name == 'Collections Summary':
                df.rename(
                    columns={"due_date_of_this_bill":"bill_due_date","template_description":"collection_name","day":"current_step","step_description":"step_details","days_left":"days_late"},
                    inplace=True,
                )

            if module_name in ('Active Customer Rate Plan', 'Customer Rate Plan', 'Active Customer Rate Plan Billing Platform'):
                df.rename(
                    columns={
                        "is_billing_advance_eligible": "uses_bill_in_advance","service_provider_name":"provider","rate_plan_name":"plan_name",
                        "automation_rule_flag":"automation","display_rate":"total_charge", "soc_code":"carrier_rate_plan", "carrier_rate_plan":"carrier_rate_plan_name"


                    },
                    inplace=True,
                )
                if role_name not in ('Super Admin', 'Partner Admin', 'Agent Partner Admin'):
                    if 'soc_code' in df.columns:
                        df.drop(columns=['soc_code'], inplace=True)
                    if "carrier_rate_plan" in df.columns:
                        df.drop(columns=["carrier_rate_plan"], inplace=True)
                    if "carrier_rate_plan_name" in df.columns:
                        df.drop(columns=["carrier_rate_plan_name"], inplace=True)
                logging.info(f"columns -- {df.columns}")
                logging.info(f"data -- {df.head()}")
                if "optimization_type" in df.columns:
                    df["optimization_type"] = df["optimization_type"].replace(
                        {"Cross customer pooling": "Cross Customer Pooling"}
                    )
                if "status" in df.columns:
                    df["status"] = df["status"].map({True: "Active", False: "Inactive", "True": "Active", "False": "Inactive"})

                if "overage_rate_cost" in df.columns:
                        df["overage_rate_cost"] = (
                            df["overage_rate_cost"]
                            .astype(str)
                            .apply(lambda x: f"0{x}" if x.startswith('.') else x)
                        )
                # Function to clean and convert input to float
                def fix_leading_dot_float(x):
                    try:
                        if isinstance(x, str):
                            x = x.strip().replace('$', '').replace(',', '')  # Remove dollar sign and whitespace
                            if not x:  # Handle empty strings
                                return 0.0  # or return None, or return x depending on your needs
                            if x.startswith('.'):
                                x = f"0{x}"
                        return float(x)
                    except Exception as e:
                        logging.exception(f"### search_export fix_leading_dot_float exception {e}: {x}")
                        return x  # Return original value if not convertible

                # Function to format float as string for display
                def format_float_display(x):
                    try:
                        if pd.isnull(x):
                            return ""
                        x = float(x)
                        return f"{int(x)}" if x.is_integer() else f"{x:.2f}"
                    except Exception as e:
                        logging.exception(f"### search_export format_float_display exception {e}: {x}")
                        return ""

                # Column groups
                float_columns = [
                    "base_rate", "rate_charge",
                    "total_charge", "sms_rate", "mb_included"
                ]

                int_columns = ["min_plan_mb", "max_plan_mb", "data_per_overage_charge"]

                try:
                    # 1. Clean all relevant columns (convert strings like ".49", "$0.68" to float)
                    for col in float_columns + int_columns:
                        if col in df.columns:
                            df[col] = df[col].apply(fix_leading_dot_float)

                    # 2. Format integer columns as nullable Int64 (drop decimals)
                    for col in int_columns:
                        if col in df.columns:
                            df[col] = (
                                df[col]
                                .apply(lambda x: int(x) if pd.notnull(x) and float(x).is_integer() else pd.NA)
                                .astype("Int64")
                            )

                    # 3. Format float columns as strings for export/display
                    for col in float_columns:
                        if col in df.columns and col != "overage_rate_cost":
                            df[col] = df[col].apply(format_float_display)

                except Exception as e:
                    logging.info(f"### search_export column format change exception: {e}")
                logging.info(f"base_rate --- {df['base_rate']}")
                # print product column from df
                # if 'product_cost' in df.columns:
                #     df['product_cost'] = df['product_cost'].apply(
                #         lambda x: json.dumps(x) if isinstance(x, (list, dict)) else x
                #     )
                # if 'product' in df.columns:
                #     if df['product'].apply(lambda x: isinstance(x, list)).any():
                #         df = df.explode('product')
                #     else:
                #         df['product'] = df['product'].apply(lambda x: x.split(',') if isinstance(x, str) else x)
                #         df = df.explode('product')
                # if billing_platform_flag:
                #     logging.info(f"### search_export billing settings : {billing_platform_flag}")
                #     def safe_json_load(x):
                #         if isinstance(x, str) and x.strip():
                #             try:
                #                 return json.loads(x)
                #             except json.JSONDecodeError:
                #                 logging.warning(f"Invalid JSON in product_cost: {x}")
                #                 return []  # or return x, or None depending on how you want to handle bad data
                #         return x if isinstance(x, list) else []
                #     if 'product' in df.columns and 'product_cost' in df.columns:
                #         # Ensure product_cost is a list of dicts
                #         df['product_cost'] = df['product_cost'].apply(safe_json_load)
                #         # Ensure product is a list
                #         df['product'] = df['product'].apply(
                #             lambda x: x if isinstance(x, list) else (x.split(',') if isinstance(x, str) else [])
                #         )

                #         new_rows = []
                #         for _, row in df.iterrows():
                #             products = row['product']
                #             costs = row['product_cost'] if isinstance(row['product_cost'], list) else []
                #             for idx, prod in enumerate(products):
                #                 # Pair by index: first product with first cost dict, etc.
                #                 cost_dict = costs[idx] if idx < len(costs) else {}
                #                 new_row = row.to_dict()
                #                 new_row['Product'] = prod
                #                 new_row['Product Id'] = cost_dict.get('product_id', '')
                #                 new_row['Product Description'] = cost_dict.get('description', '')
                #                 new_row['Product Rate'] = cost_dict.get('rate', '')
                #                 # Show 0 if cost is None/null, else show value, else empty
                #                 cost_val = cost_dict.get('cost', '')
                #                 if cost_val in [None, '', 0, '0']:
                #                     new_row['Product Cost'] = ''
                #                 else:
                #                     new_row['Product Cost'] = cost_val
                #                 new_rows.append(new_row)
                #         df = pd.DataFrame(new_rows)
                #         df = df.drop(columns=['product', 'product_cost'], errors='ignore')
                #         if "optimization_type" in df.columns:
                #             df["optimization_type"] = df["optimization_type"].replace(
                #                 {"Cross customer pooling": "Cross Customer Pooling"}
                #             )
                #         if "status" in df.columns:
                #             df["status"] = df["status"].map({True: "Active", False: "Inactive", "True": "Active", "False": "Inactive"})
                #         # Function to clean and convert input to float
                #         def fix_leading_dot_float(x):
                #             try:
                #                 if isinstance(x, str):
                #                     x = x.strip().replace('$', '')  # Remove dollar sign and whitespace
                #                     if x.startswith('.'):
                #                         x = f"0{x}"
                #                 return float(x)
                #             except Exception:
                #                 return x  # Return original value if not convertible

                #         # Function to format float as string for display
                #         def format_float_display(x):
                #             try:
                #                 if pd.isnull(x):
                #                     return ""
                #                 x = float(x)
                #                 return f"{int(x)}" if x.is_integer() else f"{x:.2f}"
                #             except Exception:
                #                 return ""

                #         # Column groups
                #         float_columns = [
                #             "base_rate", "rate_charge", "overage_rate_cost",
                #             "total_charge", "sms_rate", "mb_included"
                #         ]

                #         int_columns = ["min_plan_mb", "max_plan_mb", "data_per_overage_charge"]

                #         try:
                #             # 1. Clean all relevant columns (convert strings like ".49", "$0.68" to float)
                #             for col in float_columns + int_columns:
                #                 if col in df.columns:
                #                     df[col] = df[col].apply(fix_leading_dot_float)

                #             # 2. Format integer columns as nullable Int64 (drop decimals)
                #             for col in int_columns:
                #                 if col in df.columns:
                #                     df[col] = (
                #                         df[col]
                #                         .apply(lambda x: int(x) if pd.notnull(x) and float(x).is_integer() else pd.NA)
                #                         .astype("Int64")
                #                     )

                #             # 3. Format float columns as strings for export/display
                #             for col in float_columns:
                #                 if col in df.columns:
                #                     df[col] = df[col].apply(format_float_display)

                #         except Exception as e:
                #             logging.info(f"### search_export column format change exception: {e}")
                #         # Reorder columns after "Service Type"
                #         after_service_type = [
                #             "Product", "Product Id", "Product Description", "Product Rate", "Product Cost",
                #             "package", "automation_rule", "automation", "uses_bill_in_advance", "status",
                #             "last_modified_by", "last_modified_datetime"
                #         ]
                #         # Find columns before "Service Type"
                #         cols = list(df.columns)
                #         logging.info(f"columnsss --- {cols}")
                #         if "service_type" in cols:
                #             idx = cols.index("service_type")
                #             before_service_type = cols[:idx+1]  # includes "service_type"
                #             # Only keep columns that exist in df
                #             reordered = before_service_type + [c for c in after_service_type if c in df.columns]
                #             df = df[reordered]
                #         df.rename(columns={"Product Id":"product_id","Product Description":"product_description",
                #                            "Product Rate":"product _rate","Product Cost":"product_cost"
                #                            })
                # else:
                #     logging.info(f"### billing settings : {billing_platform_flag}")
                #     if 'product' in df.columns:
                #         df.drop(columns=['product'], inplace=True)
                #     if 'product_cost' in df.columns:
                #         df.drop(columns=['product_cost'], inplace=True)
                #     if 'package' in df.columns:
                #         df.drop(columns=['package'], inplace=True)

                logging.info(f"### columns -- {df.columns}")
                logging.info(f"### data -- {df.head()}")

            if module_name == 'Customer Rate Pool Usage Report':
                tenant_name = data.get("partner", "")
                tenant_data = db.get_data("tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"])
                tenant_id = tenant_data["id"].to_list()[0]
                parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
                if parent_tenant_id is not None:
                    optimization_setting_table='optimization_setting_tenant_override'
                else:
                    optimization_setting_table='optimization_setting'

                try:
                    tenant_database = DB(db_name, **get_db_config(db_name))
                    p = tenant_database.get_data(
                            optimization_setting_table,
                            {"tenant_id": tenant_id},
                            ["optino_cross_providercustomer_optimization"],
                        ).iloc[0, 0]
                except Exception as e:
                    logging.exception(f"## Exception fetching optimization setting: {e}")
                    p = False

                if p:
                    logging.info(f"## Cross Provider Customer Pooling is enabled - df columns = {df.columns}")
                    df.rename(
                        columns={
                            "subscriber_number": "msisdn",
                            "service_provider_name": "service_provider",
                            "data_allocation_mb":"customer_data_allocation_mb",
                        },
                        inplace=True,
                    )
                    df.drop(columns=["portal_type_id","customer_rate_pool_device_count",
                                    "billing_period_start_date","customer_rate_pool_data_remaining",
                                    "total_used","parent_customer_id"
                                    ], inplace=True, errors='ignore')

                    preferred_order = [
                        "customer_rate_pool_name",
                        "data_usage_mb",
                        "customer_data_allocation_mb",
                        "customer_rate_pool_data_usage_percentage",
                        "msisdn",
                        "iccid",
                        "username",
                        "account_number",
                        "customer_name",
                        "service_provider",
                        "customer_rate_plan_name",
                        "billing_period_end_date"
                    ]

                    # Reorder dynamically (keeping only columns that exist)
                    df = df[[col for col in preferred_order if col in df.columns]]

            # Update the Communication plans section in search_export:
            
            logging.info(f"### columns -- {df.columns}")
            logging.info(f"### data -- {df.head(5)}")

            acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "MSISDN", "IP","MRC","NRC", "ID"}

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {
                "Tn": "TN",
                "Att": "AT&T",
                "And": "and",
                "Gl": "G/L",
                # "Parent": "IsParent",  Ar Aging Report got an issue
                "Child": "IsChild",
                "Prevmrc": "PrevMRC", 
                "Currmrc": "CurrMRC", 
                "Netmrc": "NetMRC", 
                "Prevnrc": "PrevNRC", 
                "Currnrc": "CurrNRC", 
                "Netnrc": "NetNRC",
                "Prevnrcusage": "PrevNRC-Usage",
                "Currnrcusage": "CurrNRC-Usage",
                "Netnrcusage": "NetNRC-Usage"
            }
            # Format column names
            df.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in df.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            df.columns = [
                " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
            ]
            if module_name == "Communication plans":
                logging.info("### Exploding Carrier Rate Plans with proper Excel alignment")

                exploded_rows = []

                for _, row in df.iterrows():
                    rate_plans = row.get("Carrier Rate Plans", None)

                    # Handle null/empty values
                    if pd.isna(rate_plans) or str(rate_plans).strip() == "":
                        plans_list = [None]
                    else:
                        rate_plans = str(rate_plans).strip()
                        try:
                            plans_list = ast.literal_eval(rate_plans)
                            if not isinstance(plans_list, list):
                                plans_list = [str(plans_list)]
                        except Exception:
                            rate_plans = rate_plans.strip('[]"')
                            plans_list = [x.strip() for x in rate_plans.split(",") if x.strip()]

                    # Clean prefixes rate plans 
                    cleaned_plans = [
                        re.sub(r"^\s*-+|-+\s*$", "", str(p)).strip() if p is not None else None
                        for p in plans_list
                    ]


                    #cleaned_plans = [str(p).split("-")[-1].strip() if p is not None else None for p in plans_list]

                    # Row explosion with blanks for merge effect
                    for i, plan in enumerate(cleaned_plans):
                        new_row = row.copy()
                        new_row["Carrier Rate Plans"] = plan
                        if i > 0:  # blank for merged effect
                            for col in ["Service Provider Name", "Communication Plan Name", "Alias Name", "Modified By", "Modified Date"]:
                                new_row[col] = ""
                        exploded_rows.append(new_row)

                # Create final dataframe with correct column order
                df = pd.DataFrame(exploded_rows)[
                    ["Service Provider Name", "Communication Plan Name", "Alias Name",
                    "Carrier Rate Plans", "Modified By", "Modified Date"]
                ]

                

            # --- Fix date MB Usage capitalization (e.g. "9/16/25 mb usage" -> "9/16/25 Mb Usage") ---
            def normalize_date_mb_usage_columns(df):
                pattern = re.compile(r'^\s*(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4})\s+mb\s+usage\s*$', flags=re.IGNORECASE)
                new_cols = []
                for col in df.columns:
                    col_str = str(col)
                    m = pattern.match(col_str)
                    if m:
                        new_cols.append(f"{m.group(1)} MB Usage")
                    else:
                        new_cols.append(col)
                df.columns = new_cols
                return df
            # --- end fix ---


            if module_name == "Daily usage report Export" and index_name == 'daily_usage_report':
                # get unique Billing Cycle End Date from df
                billing_periods = []
                billing_cycle_dates = df["Billing Cycle End Date"].unique().tolist()
                billing_cycle_dates = [date for date in billing_cycle_dates if date is not None]
                billing_periods = []
                for date_str in billing_cycle_dates:
                    date = pd.to_datetime(date_str)  # Convert string to Timestamp
                    cycle_start = (date - pd.DateOffset(months=1) + datetime.timedelta(days=1)).date()
                    cycle_end = date.date()
                    billing_periods.append((cycle_start, cycle_end))
                all_results = []  # To accumulate all results across billing cycles
                tenant_db = DB(db_name, **get_db_config(db_name))
                df_telegence = df[df["Service Provider"].str.contains("Telegence", case=False, na=False)]
                df_non_telegence = df[~df["Service Provider"].str.contains("Telegence", case=False, na=False)]
                for billing_cycle_start, cycle_end_date in billing_periods:
                    # Telegence
                    if not df_telegence.empty:
                        usage_pivot_df_telegence = fetch_and_pivot_daily_device_usage(
                            df_telegence,
                            "mobility_device",
                            "mobility_device_id",
                            billing_cycle_start,
                            cycle_end_date,
                            billing_cycle_dates,
                            tenant_db
                        )
                        if not usage_pivot_df_telegence.empty:
                            telegence_data_frame = pd.merge(df_telegence, usage_pivot_df_telegence, on="MSISDN", how="left")
                        else:
                            telegence_data_frame = df_telegence
                    else:
                        telegence_data_frame = pd.DataFrame()

                    # Non-Telegence
                    if not df_non_telegence.empty:
                        usage_pivot_df_non_telegence = fetch_and_pivot_daily_device_usage(
                            df_non_telegence,
                            "device",
                            "m2m_device_id",
                            billing_cycle_start,
                            cycle_end_date,
                            billing_cycle_dates,
                            tenant_db
                        )
                        if not usage_pivot_df_non_telegence.empty:
                            nont_telegence_data_frame = pd.merge(df_non_telegence, usage_pivot_df_non_telegence, on="MSISDN", how="left")
                        else:
                            nont_telegence_data_frame = df_non_telegence
                    else:
                        nont_telegence_data_frame = pd.DataFrame()

                    # Combine for this cycle
                    cycle_df = pd.concat([telegence_data_frame, nont_telegence_data_frame], ignore_index=True)

                    all_results.append(cycle_df)
                
                # Use outer join to preserve all date columns from each billing cycle
                df = reduce(
                    lambda left, right: pd.merge(
                        left, right.drop(columns=[col for col in right.columns if col in left.columns and col not in ["MSISDN"]]),
                        on="MSISDN",
                        how="outer"
                    ),
                    all_results
                )
                df = df.drop_duplicates()
                # Identify columns that match the YYYY-MM-DD format
                date_columns = [col for col in df.columns if re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(col))]
                # Fill NaN only in those date columns
                df[date_columns] = df[date_columns].fillna('-')

            
            print("index_nameindex_name", index_name, df.columns.tolist())
            if module_name == "Daily usage report Export" and index_name == 'daily_usage_report_export' and "Usage Date" in df.columns:
                logging.info("inside daily usage report")
                df["MSISDN"] = df["MSISDN"].fillna("NA")
                
                try:
                    logging.info(f"Original DataFrame shape: {df.shape}")

                    # Convert Usage Date to datetime and normalize (remove time part)
                    df["Usage Date"] = pd.to_datetime(df["Usage Date"], errors="coerce").dt.normalize()
                    
                    # Check for duplicates in key columns before pivot
                    key_cols = ["Service Provider", "ICCID", "MSISDN", "Usage Date"]
                    duplicates = df.duplicated(subset=key_cols).sum()
                    logging.info(f"Duplicate key combinations: {duplicates}")
                    
                    # Remove duplicates in key columns first (keeping first occurrence)
                    df_clean = df.drop_duplicates(subset=key_cols, keep='first')
                    logging.info(f"After removing key duplicates: {df_clean.shape}")
                    
                    # Create pivot table
                    df_pivot = df_clean.pivot_table(
                        index=["Service Provider", "ICCID", "MSISDN"],
                        columns="Usage Date",
                        values="Data Usage MB",
                        aggfunc="first"
                    ).reset_index()
                    
                    # Flatten column names
                    df_pivot.columns.name = None
                    logging.info("pivot columns --- ")
                    logging.info(df_pivot.columns)
                    
                    # Get other columns (non-pivoted) - take first value for each group
                    other_cols = [col for col in df_clean.columns 
                                if col not in ["Data Usage MB", "Usage Date", "Created Date", "Modified Date",
                                            "Service Provider", "ICCID", "MSISDN"]]
                    
                    if other_cols:
                        base_df = df_clean.groupby(["Service Provider", "ICCID", "MSISDN"])[other_cols].first().reset_index()
                        df = base_df.merge(df_pivot, on=["Service Provider", "ICCID", "MSISDN"], how="inner")
                    else:
                        df = df_pivot
                    
                    # Final duplicate check
                    final_duplicates = df.duplicated(subset=["Service Provider", "ICCID", "MSISDN"]).sum()
                    
                    if final_duplicates > 0:
                        logging.info("Warning: Still have duplicates! Removing them...")
                        df = df.drop_duplicates(subset=["Service Provider", "ICCID", "MSISDN"], keep='first')
                        logging.info(f"After final dedup: {df.shape}")
                        
                except Exception as e:
                    logging.error(f"### Error while pivoting Daily usage report Export: {e}")
                    import traceback
                    logging.error(traceback.format_exc())

            df = df.rename(columns={"Soc Code": "SOC", "Product Id": "Product ID"})
            file_name = f"exports/search/{module_name_snake_case}.xlsx"

            if module_name in ["Charge History", "Charge history"]:
                #rename df columns
                df = df.rename(columns={"Rev Account Number": "Customer Account Number"})
                with TemporaryDirectory() as temp_dir:
                    excel_file_path = os.path.join(temp_dir, f"{module_name_snake_case}.xlsx")
                    logging.info(f"excel_file_path: {excel_file_path} == df olumns = {df.columns}")
                    with pd.ExcelWriter(excel_file_path, engine="xlsxwriter") as writer:
                        df.to_excel(writer, sheet_name="Sheet 1", index=False)
                        worksheet = writer.sheets["Sheet 1"]
                        for i, col in enumerate(df.columns):
                            col_width = max(df[col].astype(str).map(len).max(), len(col)) + 2
                            worksheet.set_column(i, i, min(col_width, 50))

                    zip_file_path = os.path.join(temp_dir, f"{module_name_snake_case}.zip")
                    with zipfile.ZipFile(zip_file_path, "w") as zipf:
                        zipf.write(excel_file_path, os.path.basename(excel_file_path))

                    with open(zip_file_path, "rb") as zipf:
                        s3_client.put_object(
                            Bucket=S3_BUCKET_NAME,
                            Key=f"exports/search/{module_name_snake_case}.zip",
                            Body=zipf,
                            ContentType="application/zip",
                        )

                    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/exports/search/{module_name_snake_case}.zip"
            # In the Excel writing section, after all processing:
            elif module_name == "Communication plans":
                logging.info("inside communication plans")
                excel_buffer  = BytesIO() 
                with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                    df.to_excel(writer, index=False, sheet_name="Sheet1")
                    sheet = writer.book["Sheet1"]

                    # Header formatting
                    header_font = Font(bold=True)
                    header_fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    for cell in sheet[1]:
                        cell.font = header_font
                        cell.fill = header_fill
                        cell.alignment = Alignment(horizontal="left", vertical="center")


                    merge_columns = [
                        "Service Provider Name",
                        "Communication Plan Name",
                        "Alias Name",
                        "Modified By",
                        "Modified Date"
                    ]

                    for col_name in merge_columns:
                        col_idx = df.columns.get_loc(col_name) + 1
                        row = 2  # start from first data row

                        while row <= sheet.max_row:

                            # Detect block start based on Service Provider column
                            provider_value = sheet.cell(row=row, column=1).value
                            end_row = row

                            # Walk until next provider appears
                            while (
                                end_row + 1 <= sheet.max_row and
                                sheet.cell(row=end_row + 1, column=1).value in ("", None)
                            ):
                                end_row += 1

                            # Merge the entire block for this column
                            sheet.merge_cells(
                                start_row=row, start_column=col_idx,
                                end_row=end_row, end_column=col_idx
                            )
                            sheet.cell(row=row, column=col_idx).alignment = Alignment(
                                horizontal="left", vertical="center"
                            )

                            # Jump to next block
                            row = end_row + 1

                    
                    # # Auto-adjust column widths
                    for col_idx, col_cells in enumerate(sheet.columns, 1):
                        max_length = max(len(str(cell.value or "")) for cell in col_cells)
                        sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

                excel_buffer.seek(0)
                s3_client = boto3.client("s3")
                # Upload to S3
                s3_client.put_object(
                    Bucket=S3_BUCKET_NAME,
                    Key=file_name,
                    Body=excel_buffer.getvalue(),
                    ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
                
                download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
            else:
                # Ensure final column names are normalized before writing
                df = normalize_date_mb_usage_columns(df)

                excel_buffer = BytesIO()
                df.columns = df.columns.map(str) 
                with pd.ExcelWriter(excel_buffer, engine="xlsxwriter") as writer:
                    df.to_excel(writer, sheet_name="Sheet 1", index=False)
                    worksheet = writer.sheets["Sheet 1"]
                    for i, col in enumerate(df.columns):
                        try:
                            max_col_len = df[col].astype(str).map(len).max()
                            # Handle case where max() returns NaN or Series
                            if pd.isna(max_col_len):
                                max_col_len = 0
                            elif hasattr(max_col_len, 'iloc'):  # It's a Series
                                max_col_len = max_col_len.iloc[0] if not max_col_len.empty else 0
                            col_width = max(int(max_col_len), len(col)) + 2
                        except (ValueError, TypeError):
                            # Fallback to just column name length if calculation fails
                            col_width = len(col) + 2
                        worksheet.set_column(i, i, min(col_width, 50))
                excel_buffer.seek(0)
                s3_client = boto3.client("s3")
                s3_client.put_object(
                    Bucket=S3_BUCKET_NAME,
                    Key=file_name,
                    Body=excel_buffer.getvalue(),
                    ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
                download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

            search_result = {
                "flag": True,
                "download_url": download_url,
            }

            db = DB("common_utils", **get_db_config("common_utils"))
            db.update_dict(
                "export_status",
                {"status_flag": "Success", "url": download_url},
                {"module_name": module_name, "tenant_id":tenant_id,"user_name":user_name},
            )
            return search_result
        else:
            updated_record = db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name, "tenant_id":tenant_id,"user_name":user_name},
            )
            logging.info(f"##empty data Updated record: {updated_record}")
            search_result = {"flag": False, "message": "No data found for export."}

        return search_result
    except Exception as e:
        logging.exception(f"## Exception is {e}")
        message=f"No Records found"
        search_result = {"flag": False, "message": message}
        return search_result






def get_module_name(search_module,db_name):
    try:
        database = DB(db_name, **get_db_config(db_name))
        query = f"""
            SELECT module_name
            FROM open_search_index
            WHERE search_module = '{search_module}'
        """
        # Execute the query

        df = database.execute_query(query, True)

        if not df.empty:
            module_name = df.iloc[0]["module_name"]  # Extract the first value of the "module_name" column
            return module_name
        else:
            print("No results found.")
            return None
    except Exception as e:
        logging.info(f"## An Error Occured as {e}")
        return None
    finally:
        if database:
            database.close()


def get_columns_from_db( module_name,db_name):
    database = DB("common_utils", **get_db_config("common_utils"))
    if "billing_platform" in db_name:
        database = DB("billing_platform_common_utils", **get_db_config("billing_platform_common_utils"))
    
    query = f"""
        SELECT db_column_name
        FROM field_column_mapping
        WHERE module_name = '{module_name}' AND table_col = 'yes'
    """
    # Execute the query

    df = database.execute_query(query, True)
    # Convert the column to a list
    return df['db_column_name'].tolist()

def combined_search_data(filters,query,columns,index_list, start, end, page_flag, db_name, col_sort,index_name,tenant_name,role,is_redirected):
    # if db_name == "altaworx_central":
    #     index_list = index_list
    # else:
    #     index_list = index_list
    # print("index_name------", index_list)
    print("page_flag",page_flag)
    if '$' in query and 'Tax' not in query:
        query = query.replace('$', '')  # Remove dollar sign
    if query.endswith('.'):
        query = query[:-1]
    # if re.fullmatch(r'[\d,]+', query):
    #     query = query.replace(',', '')
    query = normalize_numeric_commas(query)
    # if '$' in query:
    #     query = query.replace('$', '')  # Remove dollar sign
    # if ',' in query:
    #     query = query.replace(',', '')
    columns = [col for col in columns if col and col != "is_active"]
    columns=list(set(columns))
    search_body = {
        "query": {
            "bool": {
                # "must": [],   # Exact matches / required conditions
                "must": [
                    # Wildcard search for partial matches in text fields
                    {
                        "multi_match": {
                            "query": str(query),
                            "fields": columns,
                            "type": "bool_prefix",
                            "operator": "and",
                            "lenient": True
                        }
                    }
                ]
                # "minimum_should_match": 1  # At least one condition must match
            }
        },
        "from": start,
        "size": end - start,
        "track_total_hits": True
    }
    if is_date(query):
        # print("query --- ",query)
        query = convert_to_opensearch_date_format(query)

    # print("************",columns)
    sort_clause = []
    if index_name == "automation_rule_log":
        if is_field_present(index_list, 'id'):
            sort_clause = [
                {
                    "id": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name in ["customer_optimization_list_view", "carrier_optimization_list_view"]:
        if is_field_present(index_list, 'run_start_time'):
            sort_clause = [
                {
                    "run_start_time": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    elif index_name == "action_history_report":
        # Apply last one year filter
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_month_date = (datetime.datetime.utcnow() - datetime.timedelta(days=30)).strftime("%Y-%m-%d")

        date_filter = {
            "range": {
                "date_of_change": {
                    "gte": last_month_date,  # From one year ago
                    "lte": current_date     # Up to the present date
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_filter)
    elif index_name == "Usage Details":
        usage_filter = {
            "bool": {
                "should": [
                    {
                        "range": {
                            "usage_mb": {
                                "gt": 0
                            }
                        }
                    },
                    {
                        "range": {
                            "sms_cost": {
                                "gt": 0
                            }
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        }
        search_body["query"]["bool"]["must"].append(usage_filter)
    elif index_name == 'Billing and Payments Billing':
        due_filter = {
            "range": {
                "amount_due": { "gt": 0 }
            }
        }
        search_body["query"]["bool"]["must"].append(due_filter)
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    # elif index_name == 'Unposted':
    #     due_filter = {
    #         "range": {
    #             "charge_amount": { "gt": 0 }
    #         }
    #     }
    #     search_body["query"]["bool"]["must"].append(due_filter)
    #     if is_field_present(index_list, 'modified_date'):
    #         sort_clause = [
    #             {
    #                 "modified_date": {
    #                     "order": "desc"  # Sort by modified_date in descending order
    #                 }
    #             }
    #         ]
    elif index_name == "partner_users":
        logging.info(f"### partner_users role: {role}, tenant_name: {tenant_name}")
        role_order = [
            "Partner Admin",
            "Agent Partner Admin",
            "Agent",
            "User",
            "Notification Only User",
            "Qualification Only User"
        ]
        if role and role != "Super Admin":
            if role in role_order:
                supported_role = role_order[role_order.index(role):]
                usernames = get_usernames(tenant_name, supported_role)
                should_queries = []
                for r in supported_role:
                    should_queries.append({"wildcard": {"role.keyword": f"*{r}*"}})

                role_filters = {
                    "bool": {
                        "should": should_queries,
                        "minimum_should_match": 1
                    }
                }
                username_filters = {
                    "terms": {
                        "username.keyword": usernames
                    }
                }
                search_body["query"]["bool"]["must"].append(role_filters)
                logging.info(f"### Supported roles: {supported_role}")
                search_body["query"]["bool"]["must"].append(username_filters)
            else:
                logging.warning(f"### Role {role} not found in role_order")
        else:
            logging.info("### Super admin: No role-based filtering applied")
    else:
        if is_field_present(index_list, 'modified_date'):
            sort_clause = [
                {
                    "modified_date": {
                        "order": "desc"  # Sort by modified_date in descending order
                    }
                }
            ]
    if index_name == "Charge Details":
        search_body["query"]["bool"].setdefault("must_not", []).append({
            "terms": {
                "category.keyword": ["MRC", "Credit"]
            }
        })
    if col_sort:
        try:
            # Extract field and order from the key
            field_to_sort, sort_order = next(iter(col_sort.items()))  
            sort_order = sort_order.lower()  # Normalize to lowercase

            # Get the field type (Assuming `get_field_type` is a defined function)
            field_type = get_field_type(index_list, field_to_sort)

            # Modify field_to_sort if it is of type "text"
            if field_type == "text":
                field_to_sort = f'{field_to_sort}.keyword'

            # Check if the field and sort order are valid
            if field_to_sort and sort_order in ["asc", "desc"]:
                sort_clause = [{field_to_sort: {"order": sort_order}}]  # Override default sort with key sorting
            else:
                print("Invalid sorting key: Ensure the format is {<field_name>: 'asc'/'desc'}.")
        except StopIteration:
            print("Error: The provided 'key' dictionary is empty or invalid.")
        except Exception as e:
            print(f"An error occurred: {e}")
    
    if sort_clause:
        search_body["sort"] = sort_clause
    # Apply Filters if Present
    if filters:
        for field, values in filters.items():
            if values:  # Check if values is not empty
                field_type = get_field_type(index_list, field)
                # print(f"Field: {field}, Field Type: {field_type}")
                if isinstance(values, list) and len(values) > 1:
                    if field_type in ["date", "integer", "float"]:  # Adjust based on actual types returned by get_field_type
                        values = [v for v in values if v != '']  # Remove empty string
                        
                        # Update filters with cleaned values
                        filters[field] = values
                if isinstance(values, list):  # Handle lists
                    if len(values) == 1:
                        # Single value, handle boolean or other types
                        value = values[0]
                        if field in ["device_count", "total_charges", "total_charge_amount", "base_rate", "rate_charge_amt", "overage_rate_cost"]:
                            for value in values:
                                if isinstance(value, str) and ":" in value:
                                    try:
                                        start_range, end_range = map(int, value.split(':'))
                                        # start_range = round(float(start_range))
                                        # end_range = round(float(end_range))
                                        search_body["query"]["bool"].setdefault("must", []).append({
                                            "range": {
                                                f"{field}": {
                                                    "gte": start_range,  # Greater than or equal to start of range
                                                    "lte": end_range     # Less than or equal to end of range
                                                }
                                            }
                                        })
                                        search_body["sort"] = [
                                                {f"{field}": {"order": "asc"}}
                                            ]
                                    except ValueError:
                                        print(f"Invalid range format for {field}")
                                else:
                                    try:
                                        start_range = int(value)
                                        end_range = int(value)+1
                                        search_body["query"]["bool"].setdefault("must", []).append({
                                            "range": {
                                                f"{field}": {
                                                    "gte": start_range,  # Greater than or equal to start of range
                                                    "lt": end_range     # Less than or equal to end of range
                                                }
                                            }
                                        })
                                        search_body["sort"] = [
                                                {f"{field}": {"order": "asc"}}
                                            ]
                                    except ValueError:
                                        print(f"Invalid range format for {field}")
                        elif isinstance(value, str) and ":" in value:
                            try:
                                start_range, end_range = value.split(':')
                                search_body["query"]["bool"].setdefault("must", []).append({
                                    "range": {
                                        f"{field}": {
                                            "gte": start_range,  # Greater than or equal to start of range
                                            "lte": end_range     # Less than or equal to end of range
                                        }
                                    }
                                })
                                search_body["sort"] = [
                                        {f"{field}": {"order": "asc"}}
                                    ]
                            except ValueError:
                                logging.info(f"Invalid range format for {field}")
                        elif field in ["created_date", "date_activated"] and is_redirected and index_name in ["Inventory", "inventory_export"]:
                            # Parse as date range
                            start_range, end_range = value.split(':')
                            # Optional: validate format
                            datetime.datetime.strptime(start_range, "%Y-%m-%d")
                            datetime.datetime.strptime(end_range, "%Y-%m-%d")
                            if field == "created_date":
                                earliest_date_query = {
                                    "size": 0,
                                    "aggs": {
                                        "min_date": {"min": {"field": field}}
                                    }
                                }
                                response = es.search(index=index_list, body=earliest_date_query)
                                start_range = response["aggregations"]["min_date"]["value_as_string"] if response["aggregations"]["min_date"]["value_as_string"] else end_range
                            logging.info(f"## start_range: {start_range}, end_range: {end_range}")
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "range": {
                                    f"{field}": {
                                        "gte": start_range,
                                        "lte": end_range
                                    }
                                }
                            })
                        elif isinstance(value, str) and value.strip() == "":
                            # Handle case where the single value is an empty string
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},  # Empty string
                                        {"bool": {"must_not": {"exists": {"field": field}}}}  # Missing field
                                    ]
                                }
                            })
                        elif field in ['nsdev', "auto_change_rate_plan", "att_certified","is_billing_advance_eligible","allows_sim_pooling"] and isinstance(value, str) and value.lower() in ['true', 'false']:
                        # Handle boolean as string
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}  # Converts to a boolean
                            })
                        elif field in ['category'] and value.lower() in ['ach','credit']:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value.lower()}  # Converts to lowercase
                            })
                        elif field in ['volte_capable', 'assigned'] and isinstance(value, str) and value.lower() in ['yes', 'no']:
                            if field == 'assigned' and index_name == 'Rate_Plan_Socs':
                                boolean_value = "Yes" if value.lower() == 'yes' else "No"
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": boolean_value}  # Use the converted boolean value
                                })
                            else:
                                boolean_value = True if value.lower() == 'yes' else False
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}": boolean_value}  # Use the converted boolean value
                                })
                        elif field_type == "long" and field=="bulk_change_id":  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif field in ["vw_users_tenant_roles", "customerrateplan","is_active"] and isinstance(value, str) and value.lower() in ["active", "inactive"]:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": "true" if value.lower() == "active" else "false"}
                            })
                        elif field in ["optimization_type"] and index_name == "Customer_Rate_Plan":
                            # Normalize the "Cross Customer Pooling" values
                            normalized_value = "Cross Customer Pooling" if value.lower() in ["cross customer pooling", "cross customer pooling", "cross customer pooling"] else value
                            
                            if normalized_value == "Cross Customer Pooling":
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}.keyword": ["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling", "Cross customer Pooling"]}
                                })
                            else:
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": normalized_value}
                                })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        print(f"Invalid date format for item: {item}")
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        elif isinstance(value, (list, str)):
                            if value is None or (isinstance(value, str) and value == "(Spaces)"):
                                if isinstance(value, str):
                                    stripped_value = ""
                                    if stripped_value == "":
                                        search_body["query"]["bool"]["must"].append({
                                            "terms": {f"{field}.keyword": ["", " ", "  "]}  # Match exact empty string, single space, and double space
                                        })
                            elif field == 'prorate':
                                if isinstance(value, str):
                                    search_body["query"]["bool"]["must"].append({
                                        "term": {f"{field}": value }
                                    })
                            elif value.strip() not in [""," "] and value != "(Spaces)":
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}.keyword": value }
                                })
                            else:
                                search_body["query"]["bool"]["must"].append({
                                    "term": {f"{field}": value }
                                })
                        # elif isinstance(value, (list, str)) and field_type == "text" and value.strip() not in [""," "]:
                        #     search_body["query"]["bool"]["must"].append({
                        #         "term": {f"{field}.keyword": value }
                        #     })
                        # for handling empty values
                        
                        
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, (list, str)) and field == "billing_cycle_end_date":
                            try:
                                if isinstance(value, str):
                                    value = [value]
                                formatted_values = convert_date_format(value)
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                            except ValueError:
                                continue            
                        elif isinstance(value, (list, str)):
                            try:
                                if isinstance(value, str):
                                    value = [value]  # Convert single string to a list if it's not already a list
                                for item in value:
                                    if isinstance(item, str):  # Ensure it's a string before adding to the query
                                        # Create a match query for each item in the list
                                        search_body["query"]["bool"]["must"].append({
                                            "match": {
                                                f"{field}": item  # Using match for full-text search
                                            }
                                        })
                            except ValueError:
                                continue
                        elif isinstance(value, (int, float)):  # Single int or float value
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        elif isinstance(value, bool):  # Handle boolean condition
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value.lower()}
                            })
                        elif isinstance(value, str) and field == 'status'  and index_list=='sim_management_bulk_change_request':  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                        elif isinstance(value, str):  # Handle integer values
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}": value}
                            })
                        else:
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": value}
                            })
                    else:
                        if field in ['category'] and index_name in ['Chargeback Exceptions','Payment History']:
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['ach', 'credit']]
                            search_body["query"]["bool"]["must"].append({
                                "term": {f"{field}.keyword": values.lower()}  # Converts to lowercase
                            })

                        elif field in ['nsdev', "auto_change_rate_plan", "att_certified", "is_billing_advance_eligible", "allows_sim_pooling"] and isinstance(values, list):
                            # Ensure all values in the list are lowercase and valid boolean strings
                            lower_values = [v.lower() for v in values if isinstance(v, str) and v.lower() in ['true', 'false']]
                            
                            if lower_values:  # Proceed only if the list has valid boolean strings
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": lower_values}  # Add terms filter with lowercase values
                                })
                        elif any(isinstance(v, str) and v.strip() == "" for v in values):  
                            # Handle empty string or missing field cases
                            search_body["query"]["bool"].setdefault("must", []).append({
                                "bool": {
                                    "should": [
                                        {"term": {f"{field}.keyword": ""}},
                                        {"bool": {"must_not": {"exists": {"field": field}}}},
                                        {"terms": {f"{field}.keyword": [v for v in values if isinstance(v, str) and v.strip() != ""]}}
                                    ]
                                }
                            })
                        elif field_type == "text":
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}.keyword": values }
                            })
                        elif isinstance(values, (list, str))  and field_type == "date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        parsed_date = datetime.datetime.strptime(item, "%m/%d/%Y")
                                        formatted_value = parsed_date.strftime("%Y-%m-%d")
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        print(f"Invalid date format for item: {item}")
                                        continue
                            # if formatted_values:
                            #     search_body["query"]["bool"]["must"].append({
                            #         "terms": {f"{field}": formatted_values}
                            #     })
                            if formatted_values:
                                if len(formatted_values) > 1024:
                                    # If too many dates, use a range query
                                    min_date = min(formatted_values)
                                    max_date = max(formatted_values)
                                    search_body["query"]["bool"]["filter"] = {
                                        "range": {f"{field}": {"gte": min_date, "lte": max_date}}
                                    }
                                else:
                                    # Use terms query if within limit
                                    search_body["query"]["bool"]["must"].append({
                                        "terms": {f"{field}": formatted_values}
                                    })
                        elif isinstance(values, (list, str)) and field == "billing_cycle_end_date":
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):
                                    try:
                                        formatted_value = convert_date_format(item)
                                        formatted_values.append(formatted_value)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {f"{field}": formatted_values}
                                })
                        
                        elif isinstance(values, (list, str)):
                            if isinstance(values, str):
                                values = [values]
                            formatted_values = []
                            for item in values:
                                if isinstance(item, str):  # Ensure it's a string before adding to the query
                                    try:
                                        # Create a match query for each item in the list
                                        formatted_values.append(item)
                                    except ValueError:
                                        continue
                            if formatted_values:
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {
                                        f"{field}": formatted_values  # List of values for multiple exact matches
                                    }
                                })
                        if isinstance(values, list) :
                            if all(isinstance(v, (int, float)) for v in values) :
                                # print(f"Adding terms filter for {field} with values: {values}") 
                                search_body["query"]["bool"]["must"].append({
                                    "terms": {field: values}  
                                })
                        else:
                            # Multiple values in the list
                            search_body["query"]["bool"]["must"].append({
                                "terms": {f"{field}": values}
                            })
                elif isinstance(values, dict) and field_type == 'date':
                    logging.info(f"Date range query: {field} -> {values}")

                    range_value = values.get("range")
                    include_empty = values.get("include_empty", False)

                    if range_value and ":" in range_value:
                        try:
                            start_range, end_range = range_value.split(":")

                            range_query = {
                                "range": {
                                    field: {
                                        "gte": start_range,
                                        "lte": end_range,
                                        "format": "yyyy-MM-dd"
                                    }
                                }
                            }

                            #  If empty values should also be included
                            if include_empty:
                                search_body["query"]["bool"].setdefault("should", []).append({
                                    "bool": {
                                        "should": [
                                            range_query,
                                            {
                                                "bool": {
                                                    "must_not": {
                                                        "exists": {
                                                            "field": field
                                                        }
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                })

                                # VERY IMPORTANT
                                search_body["query"]["bool"]["minimum_should_match"] = 1

                            else:
                                search_body["query"]["bool"].setdefault("must", []).append(range_query)

                            # Sorting
                            search_body["sort"] = [
                                {field: {"order": "asc"}}
                            ]

                        except ValueError:
                            logging.info(f"Invalid date range format for {field}")
                elif isinstance(values, bool):  # Single boolean condition
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, int):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
                elif isinstance(values, str):
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}.keyword": values}
                    })
                else:
                    search_body["query"]["bool"]["must"].append({
                        "term": {f"{field}": values}
                    })
            elif values is False:
                search_body["query"]["bool"]["must"].append({
                    "term": {f"{field}": values}
                })
    search_body = add_customer_exists_filters(search_body, index_name, tenant_name, db_config)
    print("Final Search Body:",search_body)
    if index_name == "Active_lines_report":
        search_body["query"]["bool"]["must"].append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A","ACTIVATED"]
            }
        })
        print(f"Combined Search query {search_body}")
        
    if index_name == "rev_assurance":
        print("adding is_active_status or rev_is_active_status filters")

        status_or_clause = {
            "bool": {
                "should": [
                    {"term": {"is_active_status": False}},
                    {"term": {"rev_is_active_status": False}}
                ],
                "minimum_should_match": 1
            }
        }
        search_body["query"]["bool"]["must"].append(status_or_clause)
    elif index_name == "Customers":
        logging.info("adding rev_customer_id is null filter")
        if "must_not" not in search_body["query"]["bool"]:
            search_body["query"]["bool"]["must_not"] = []
        search_body["query"]["bool"]["must_not"].append({
            "exists": {"field": "rev_customer_id"}
        })
    elif index_name in ['Billing Report w/_City_County_Country','AR Aging Report','Export Variance Billing','Billing report by day with OCC Report','Total MRC for Sales Person: Catapult']:
        logging.info("adding bill_reversed_date is null filter")
        date_trunc_filter = {
            "script": {
                "script": {
                    "lang": "painless",
                    "source": """
                        if (doc['bill_reversed_date'].size() == 0) {
                            return true;
                        }

                        ZonedDateTime created = doc['created_date'].value;
                        ZonedDateTime reversed = doc['bill_reversed_date'].value;

                        return created.getYear() != reversed.getYear()
                            || created.getMonthValue() != reversed.getMonthValue();
                    """
                }
            }
        }
        search_body["query"]["bool"]["must"].append(date_trunc_filter)
    elif index_name in ["zero_usage_report", "usp_report_customer_usage_by_line", "usage_by_line_report", "newly_activated_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### adding customer_name, customer_id is not null filter")
            if "must" not in search_body["query"]["bool"]:
                search_body["query"]["bool"]["must"] = []
            search_body["query"]["bool"]["must"].extend([
                {"exists": {"field": "customer_id"}},
                {"term": {"customer_is_active": True}}
            ])
        else:
            logging.info("### Skipping customer_name, customer_id is not null filter. Due to main tenant")
    elif index_name in ["status_history_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### adding customer_id is not null filter")
            if "must" not in search_body["query"]["bool"]:
                search_body["query"]["bool"]["must"] = []
            search_body["query"]["bool"]["must"].extend([
                {"exists": {"field": "customer_id"}}
            ])
        else:
            logging.info("### Skipping customer_id is not null filter. Due to main tenant")
    print("Search body Combined:", index_name," --", search_body)
    try:
        if index_name == "sim_management_bulk_change" and page_flag == 'Pagination':
            # Scroll API for "bulk change" index
            scroll_time = "1m"
            scroll_size = 10000
            all_hits = []

            response = es.search(index=index_list, body=search_body, scroll=scroll_time, size=scroll_size)
            all_hits.extend(response.get("hits", {}).get("hits", []))
            scroll_id = response.get("_scroll_id")

            # Scroll through the results
            while len(response.get("hits", {}).get("hits", [])) > 0:
                response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                all_hits.extend(response.get("hits", {}).get("hits", []))

            # Clear the scroll context
            es.clear_scroll(scroll_id=scroll_id)

            # Group records by `bulk_change_id`
            grouped_sources = {}
            for hit in all_hits:
                source = hit.get("_source", {})
                bulk_id = source.get("bulk_change_id")
                if bulk_id and bulk_id not in grouped_sources:
                    grouped_sources[bulk_id] = hit

            # Prepare paginated results
            grouped_hits = list(grouped_sources.values())
            total_records = len(grouped_hits)
            paginated_hits = grouped_hits[start:end]

            results = {
                "hits": {
                    "hits": paginated_hits,
                    "total": {"value": total_records}
                }
            }
            # print(f"Grouped results count: {total_records}, returning {len(paginated_hits)} records.")
            # return replace_none_with_empty(results, index_list),total_records
            return results,total_records,search_body
        elif start<10000 and page_flag == 'Pagination':
            # Regular search for non-bulk-change indices
            response = es.search(index=index_list, body=search_body)
            total_records = response['hits']['total']['value']
            #print("total_records",total_records)
            cleaned_response = replace_none_with_empty(response, index_list)
            # print("check point")
            # return cleaned_response,total_records
            return response,total_records,search_body
    except Exception as e:
        logging.info(f"An error occurred while searching: {e}")
        return None
    try:
        scroll_time = "1m"
        scroll_size = 10000
        search_body.pop("from", None)
        search_body["size"] = scroll_size
        response = es.search(index=index_list, body=search_body, scroll=scroll_time)
        response = replace_none_with_empty(response,index_list)
        
        scroll_id = response.get('_scroll_id')
        if not scroll_id:
            print("Error: No scroll ID returned.")
            return None

        # Retrieve the hits
        all_hits = response['hits']['hits']
        # print(f"Fetched {len(all_hits)} initial records.")
        total_records = response['hits']['total']['value']



    
        if page_flag == "Pagination":  # Check if flag is set for paginated results (scrolling)
            fetched_records = all_hits
            while scroll_id and len(fetched_records) < end:
                scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                hits = scroll_response.get('hits', {}).get('hits', [])

                if not hits:
                    print("No more records found.")
                    break

                fetched_records.extend(hits)
                #print(f"Fetched {len(hits)} more records, total: {len(fetched_records)}.")

                # Update scroll_id for the next batch
                scroll_id = scroll_response.get('_scroll_id')
                if not scroll_id:
                    print("Error: No scroll ID found in subsequent response.")
                    break

            # Return the records for the pagination range requested (start to end)
            
            paginated_results = fetched_records[start:end]
            es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
            cleaned_response = replace_none_with_empty(paginated_results,index_list)
            # return cleaned_response,total_records
            return paginated_results,total_records,search_body
        elif page_flag == "Nopagination":  # Handle fetching all records without pagination
            # print("check point - 2")
            fetched_records = all_hits
            while True:
                if len(fetched_records) >= total_records:
                    # print("All records have been fetched.")
                    fetched_records = fetched_records[:total_records]
                    # print("check --------")
                    break

                scroll_response = es.scroll(scroll_id=scroll_id, scroll=scroll_time)
                hits = scroll_response.get('hits', {}).get('hits', [])

                if not hits:
                    print("No more records found.")
                    break

                fetched_records.extend(hits)
                print(f"Fetched {len(hits)} more records, total: {len(fetched_records)}.")

                # Update scroll_id for the next batch
                scroll_id = scroll_response.get('_scroll_id')
                if not scroll_id:
                    print("Error: No scroll ID found in subsequent response.")
                    break
            if index_name == 'sim_management_bulk_change':
                grouped_sources = {}
                for hit in fetched_records:
                    source = hit.get("_source", {})
                    bulk_id = source.get("bulk_change_id")
                    if bulk_id and bulk_id not in grouped_sources:
                        grouped_sources[bulk_id] = hit

            # Prepare paginated results
            if index_name == 'sim_management_bulk_change':
                fetched_records = list(grouped_sources.values())
            total_records = len(fetched_records)
            es.clear_scroll(scroll_id=scroll_id)  # Clear the scroll context
            cleaned_response = replace_none_with_empty(fetched_records,index_list)
            # return cleaned_response,len(fetched_records)
            return fetched_records,len(fetched_records),search_body
        else:
            # If flag is not set, just return the first batch of results
            return all_hits,total_records,search_body

    except Exception as e:
        print(f"An error occurred while searching in Whole search data: {e}")
        return None

def format_billing_platform_decimals(source, tenant_db_name):
    if 'billing_platform' not in tenant_db_name:
        return source

    EXCLUDE_KEYS = {
        "charge_description","email","account_number","account","iccid",
        "primary_identifier","telephone_number","id","customer_name",
        "customer","bill_id","ref","ref_guid","template_description",
        "customer_id","quantity","package_type","subscription_count",
        "company_name","company_zip","company_address","product_id",
        "name_on_card","line_id","tn",
        "customer_service_id","imei","msisdn","eid",
        "custom_primary_field_value","customer_cycle_usage_mb","ctd_voice_usage",
        "minutes_used","customer_rate_plan_mb","mb_included","data_per_overage_charge",
        "service_line_description","contact","cost_center"
    }

    def format_number(num_str):
        num_str = num_str.replace(',', '')
        dec = Decimal(num_str)
        return (
            f"{dec:,}" if dec % 1 == 0
            else f"{dec:,.2f}"
        )

    def format_dollar_amount(match):
        amount = match.group(1).replace(',', '')
        return f"${Decimal(amount):,.2f}"

    for k, v in source.items():
        if not isinstance(v, str):
            continue

        v = v.strip()

        if k in EXCLUDE_KEYS:
            continue

        # Skip dates
        # if re.search(r'\d{2}-\d{2}-\d{4}', v):
        #     continue

        # Skip JSON-like strings
        if v.startswith('[') or v.startswith('{'):
            continue

        try:
            if k == 'description':
                if not (re.search(r'\bTax\b', v, re.I) or '$' in v):
                    continue

                # format dollar amounts
                new_val = re.sub(
                    r'\$(-?\d+(?:,\d{3})*(?:\.\d+)?)',
                    format_dollar_amount,
                    v
                )
                source[k] = new_val
                continue
            # ---- FORMAT $ AMOUNTS ANYWHERE IN TEXT (supports negative) ----
            new_val = re.sub(
                r'\$(-?\d+(?:\.\d+)?)',
                format_dollar_amount,
                v
            )

            # ---- FORMAT FULL NUMERIC STRING (no $) ----
            if new_val == v:
                clean_val = v.replace(',', '')
                m = re.fullmatch(r'\((\d+(\.\d+)?)\)', clean_val)
                if m:
                    formatted = format_number(m.group(1))
                    new_val = f"({formatted})"
                elif re.fullmatch(r'-?\d+(\.\d+)?', clean_val):
                    new_val = format_number(clean_val)

            source[k] = new_val

        except Exception:
            pass

    return source

def process_hits(hits, dollar_fields, tenant_time_zone, index_name,tenant_db_name,export_flag = False):
    try:
        sources = []
        preserve_decimal_fields = [
            "plan_mb", "data_per_overage_charge", "min_plan_data_mb", "max_plan_data_mb"
        ]
        ISO_TZ_DATETIME_PATTERN = re.compile(
            r"^\d{4}-\d{2}-\d{2}T"
            r"\d{2}:\d{2}:\d{2}"
            r"(\.\d+)?"
            r"(Z|[+-]\d{2}:\d{2})$"
        )
        datetime_pattern = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?$")
        zero_after_decimal_pattern = re.compile(r"^\d+\.0*$")
        integer_pattern = re.compile(r"^\d+$")
        DATE_ONLY_PATTERN = re.compile(r'^\d{4}-\d{2}-\d{2}$')
        database = None
        for hit in hits:
            source = hit.get('_source', {})
            if export_flag and index_name in ['usage_by_line_report2']:
                # print("check point - 1")
                column_name = 'data_usage_mb'
                try:
                    value = source.get(column_name, None)
                    if value is None:
                        continue
                    else:
                        source[column_name] = Decimal(str(value))  # Convert to Decimal using string representation
                        source[column_name] = f"{source[column_name]:.3f}"
                except Exception as e:
                        # logging.exception(f"### Error processing {field}: {e}")
                        continue
            else:
                for k, v in source.items():
                    if isinstance(v, (float, Decimal)):  # Check if the value is float or int (you can add more types if needed)
                        if k not in dollar_fields:
                            source[k] = Decimal(str(v))  # Convert to Decimal using string representation
                            source[k] = f"{source[k]:.2f}"
                for field in dollar_fields:
                    try:
                        value = source.get(field, None)
                        if value is None:
                            continue 
                        if field in preserve_decimal_fields:
                            # logging.info(f"Skipping conversion for {field} with value {value}")
                            source[field] = f"{value:f}"
                        elif (field in ["sms_quantity","usage_cost","usage_quantity","usage_mb","sms_cost","carrier_cycle_usage_mb", "plan_mb", "overage_rate_cost", "data_per_overage_charge","account_balance"]) or ((field in ["base_rate", "display_rate", "overage_rate_cost"]) and (index_name == "Rate_Plan_Socs")):
                            if field == "overage_rate_cost":
                                dec_val = Decimal(str(value))
                                source[field] = format(dec_val, 'f')  # full precision
                                continue
                            source[field] = Decimal(str(value))
                            if source[field] < Decimal("0.001") and field in ['account_balance']:
                                source[field] = f"{source[field]:f}"  # Show full value for small numbers
                            else:
                                source[field] = f"{source[field]:,.2f}"
                        elif field == 'device_count':
                            source[field] = int(source[field])
                        elif index_name in ["Inventory", "inventory_export"] and field == "customer_data_allocation_mb":
                            try:
                                logging.info(f"### field inventory : {field}")
                                val = Decimal(str(value))
                                # If it's an integer value (no fractional part after quantize)
                                if val == val.to_integral_value():
                                    source[field] = str(int(val))  # "12"
                                else:
                                    source[field] = str(val.quantize(Decimal("0.01")))  # "12.32"
                            except Exception as e:
                                logging.exception(f"### Error formatting {field}: {e}")
                                continue
                        else:
                            # source[field] = float(source[field])
                            # source[field] = f"${source[field]:,.2f}"
                            source[field] = Decimal(str(value))
                            if source[field] < Decimal("0.001"):
                                source[field] = f"${source[field]:f}"  # Show full value for small numbers
                            else:
                                source[field] = f"${source[field]:,.2f}"
                    except Exception as e:
                        # logging.exception(f"### Error processing {field}: {e}")
                        continue
            if index_name in ['Chargeback Exceptions','Payment History']:
                if 'category' in source and isinstance(source['category'], str):
                    if source['category'] == 'ach':
                        source['category'] = 'ACH'
                    elif source['category'] == 'credit':
                        source['category'] = 'Credit'

            if index_name in ['Customer_Rate_Plan','Export FCC', 'Customer_Rate_Plan_Report']:
                for k, v in source.items():
                    if isinstance(v, str):
                        # Check if it starts with '$' and remember for later
                        has_dollar = v.startswith('$')
                        # Clean potential dollar signs and commas before regex check
                        cleaned_v = v.replace('$', '').replace(',', '').strip()
                        if integer_pattern.match(cleaned_v) or zero_after_decimal_pattern.match(cleaned_v):
                            # Safely convert cleaned string to Decimal first, then to int
                            try:
                                dec = Decimal(cleaned_v)
                                simplified = str(int(dec))
                                # If original had '$', prefix it back
                                if has_dollar:
                                    source[k] = f"${simplified}"
                                else:
                                    source[k] = simplified
                            except (ValueError, InvalidOperation):
                                source[k] = v  # Revert to original if conversion fails
                        else:
                            source[k] = v  # Keep original if no match
                    else:
                        source[k] = v

            if index_name == 'Inventory' and 'customer_data_allocation_mb' in source:
                val = source.get('customer_data_allocation_mb')

                # Convert None or invalid strings to 0 or skip
                if val is None or (isinstance(val, str) and not val.replace('.', '', 1).isdigit()):
                    # logging.info(f"Skipping invalid customer_data_allocation_mb: {val}")
                    source['customer_data_allocation_mb'] = None  # or 0 if preferred
                else:
                    try:
                        # Remove commas if present
                        val_clean = str(val).replace(',', '')
                        dec_val = Decimal(val_clean)

                        # Format
                        if dec_val == dec_val.to_integral_value():
                            source['customer_data_allocation_mb'] = f"{int(dec_val)}"
                        else:
                            source['customer_data_allocation_mb'] = f"{dec_val:.2f}"

                    except (InvalidOperation, TypeError, ValueError) as e:
                        logging.info(f"Error processing customer_data_allocation_mb: {val} | {e}")
                        source['customer_data_allocation_mb'] = None
            if index_name == 'Customer Services':
                if 'built_in_fields' in source and isinstance(source['built_in_fields'],str):
                    if value:  # not empty
                        try:
                            # Try JSON first — safer and more predictable
                            source['built_in_fields'] = json.loads(value)
                        except json.JSONDecodeError:
                            try:
                                # Fallback to literal_eval for Python literal strings
                                source['built_in_fields'] = ast.literal_eval(value)
                            except Exception as e:
                                logging.warning(f"### Failed to parse built_in_fields: {value} | Error: {e}")
                                source['built_in_fields'] = value  # fallback to raw string
                    else:
                        source['built_in_fields'] = []  # empty string becomes empty list
            if index_name == 'Billing Service':
                if 'service_provider_name' in source and isinstance(source['service_provider_name'], str):
                    value = source['service_provider_name'].strip()
                    if value:  # not empty
                        try:
                            # Try JSON first — safer and more predictable
                            source['service_provider_name'] = json.loads(value)
                        except json.JSONDecodeError:
                            try:
                                # Fallback to literal_eval for Python literal strings
                                source['service_provider_name'] = ast.literal_eval(value)
                            except Exception as e:
                                logging.warning(f"### Failed to parse service_provider_name: {value} | Error: {e}")
                                source['service_provider_name'] = value  # fallback to raw string
                    else:
                        source['service_provider_name'] = []  # empty string becomes empty list
                if 'built_in_fields' in source and isinstance(source['built_in_fields'],str):
                    value = source['built_in_fields'].strip()
                    if value:  # not empty
                        try:
                            # Try JSON first — safer and more predictable
                            source['built_in_fields'] = json.loads(value)
                        except json.JSONDecodeError:
                            try:
                                # Fallback to literal_eval for Python literal strings
                                source['built_in_fields'] = ast.literal_eval(value)
                            except Exception as e:
                                logging.warning(f"### Failed to parse built_in_fields: {value} | Error: {e}")
                                source['built_in_fields'] = value  # fallback to raw string
                    else:
                        source['built_in_fields'] = []  # empty string becomes empty list
                if 'custom_fields' in source and isinstance(source['custom_fields'],str):
                    value = source['custom_fields'].strip()
                    if value:  # not empty
                        try:
                            # Try JSON first — safer and more predictable
                            source['custom_fields'] = json.loads(value)
                        except json.JSONDecodeError:
                            try:
                                # Fallback to literal_eval for Python literal strings
                                source['custom_fields'] = ast.literal_eval(value)
                            except Exception as e:
                                logging.warning(f"### Failed to parse built_in_fields: {value} | Error: {e}")
                                source['custom_fields'] = value  # fallback to raw string
                    else:
                        source['custom_fields'] = []  # empty string becomes empty list
            
            if index_name == 'Billing Product':
                if 'multi_service_id' in source and isinstance(source['multi_service_id'],str):
                    value = source['multi_service_id'].strip()
                    if value:  # not empty
                        try:
                            # Try JSON first — safer and more predictable
                            source['multi_service_id'] = json.loads(value)
                        except json.JSONDecodeError:
                            try:
                                # Fallback to literal_eval for Python literal strings
                                source['multi_service_id'] = ast.literal_eval(value)
                            except Exception as e:
                                logging.warning(f"### Failed to parse built_in_fields: {value} | Error: {e}")
                                source['multi_service_id'] = value  # fallback to raw string
                    else:
                        source['multi_service_id'] = []  # empty string becomes empty list
                
            for k, v in source.items():
                if isinstance(v, str) and ISO_TZ_DATETIME_PATTERN.match(v):
                    v = normalize_datetime_for_pattern(v)
                    source[k] = v
                if isinstance(v, str) and datetime_pattern.match(v):  # If the value looks like a date
                    # source[k] = convert_to_tenant_timezone(k, v, tenant_time_zone, index_name)
                    if index_name == 'daily_usage_report_export' and k == 'usage_date':
                        # Skip timezone conversion but format like before
                        try:
                            dt = datetime.datetime.strptime(v, "%Y-%m-%dT%H:%M:%S")
                            source[k] = dt.strftime("%m-%d-%Y %I:%M:%S %p")
                        except ValueError:
                            source[k] = v  # fallback if parsing fails
                    else:
                        try:
                            source[k] = convert_to_tenant_timezone(k, v, tenant_time_zone, index_name)
                        except (OverflowError, ValueError) as e:
                            logging.warning(
                                f"### Skipping invalid datetime for key={k}, value={v}, index={index_name} | {e}"
                            )
                            source[k] = v  # keep original value
                elif isinstance(v, str) and DATE_ONLY_PATTERN.match(v):
                    source[k] = convert_to_timezone(k, v, tenant_time_zone, index_name)

                    
            if index_name in ['Unposted Items Report','Billed Through Date Report','Customer Profile']:
                if 'created_date' in source and index_name == 'Unposted Items Report':
                    created_date_val = source['created_date']
                    if isinstance(created_date_val, str):
                        if 'T' in created_date_val:
                            source['created_date'] = created_date_val.split('T')[0]
                        elif ' ' in created_date_val:
                            source['created_date'] = created_date_val.split(' ')[0]
                    elif isinstance(created_date_val, datetime):
                        source['created_date'] = created_date_val.strftime('%m-%d-%Y')
                elif index_name == 'Customer Profile' and 'bill_cycle_start_date' in source:
                    created_date_val = source['bill_cycle_start_date']
                    if isinstance(created_date_val, str):
                        if 'T' in created_date_val:
                            source['bill_cycle_start_date'] = created_date_val.split('T')[0]
                        elif ' ' in created_date_val:
                            source['bill_cycle_start_date'] = created_date_val.split(' ')[0]
                    elif isinstance(created_date_val, datetime):
                        source['bill_cycle_start_date'] = created_date_val.strftime('%m-%d-%Y')

                elif index_name == 'Billed Through Date Report':
                    if 'activation_date' in source:
                        created_date_val = source['activation_date']
                        if isinstance(created_date_val, str):
                            if 'T' in created_date_val:
                                source['activation_date'] = created_date_val.split('T')[0]
                            elif ' ' in created_date_val:
                                source['activation_date'] = created_date_val.split(' ')[0]
                        elif isinstance(created_date_val, datetime):
                            source['activation_date'] = created_date_val.strftime('%Y-%m-%d')

                    if 'billed_through_date' in source:
                        billed_date_val = source['billed_through_date']
                        if isinstance(billed_date_val, str):
                            if 'T' in billed_date_val:
                                source['billed_through_date'] = billed_date_val.split('T')[0]
                            elif ' ' in billed_date_val:
                                source['billed_through_date'] = billed_date_val.split(' ')[0]
                        elif isinstance(billed_date_val, datetime):
                            source['billed_through_date'] = billed_date_val.strftime('%Y-%m-%d')
            # source = {k: str(v) for k, v in source.items()}
            if index_name == "partner_users":
                # logging.info(f"### tenant_role_mapping: {source.get('tenant_role_mapping')}")
                if 'tenant_role_mapping' in source and not isinstance(source["tenant_role_mapping"], str):
                    source["tenant_role_mapping"] = str(source["tenant_role_mapping"])
                if 'tenant_name' in source and source['tenant_name'] is None:
                    source['tenant_name'] = "[]"
                if 'subtenant_name' in source and source['subtenant_name'] is None:
                    source['subtenant_name'] = "[]"
            if index_name not in ["Billing Product", "Billing Package","Billing Service"]:
                source  = format_billing_platform_decimals(source, tenant_db_name)
            sources.append(source)
        return sources
    except Exception as e:
        logging.exception(f"### Error processing hits: {e}")
        return []

def normalize_datetime_for_pattern(value: str) -> str:
    """
    Converts ISO datetime with timezone into:
    YYYY-MM-DDTHH:MM:SS.xx (no timezone)
    """
    try:
        # Parse ISO with timezone
        dt = datetime.datetime.fromisoformat(value)

        # Trim microseconds to 2 decimal places (ROUND_DOWN)
        micro = Decimal(dt.microsecond) / Decimal(1_000_000)
        micro = micro.quantize(Decimal("0.01"), rounding=ROUND_DOWN)

        # Rebuild datetime string
        return (
            dt.strftime("%Y-%m-%dT%H:%M:%S")
            + f".{str(micro)[2:]}"
        )
    except Exception:
        return value

def get_id_list(primary_identifier,db_name):
    try:
        database = DB(db_name, **get_db_config(db_name))
        id_list = database.get_data("unposted_upload_data", {"primary_identifier": primary_identifier}, ["upload_id"])
            
        if not id_list.empty:
            result = id_list["upload_id"].to_list()
            return result
        else:
            return ["No Records"]
        
    except Exception as e:
        logging.error(f"Error while fetching IDs for {primary_identifier}: {e}")
        return ["No Records"]

def perform_search(data):
    start_time = time.time() 
    logging.info("### data-------- %s",data)
    search_all_columns = data.get("search_all_columns", "true")
    index_name=data.get('index_name')
    cols=data.get("cols")
    search=data.get("search")
    db_name=data.get("db_name")
    upload_id = data.get("upload_id", None)
    global es
    excluded_indexes = [
        'tenant_based_banners_logs', 'tenant_based_banners',
        'partner_users', 'carrier_apis', 'amop_apis',
        'email_audit', 'email_templates', 'Central_bulk_change', 'Central_optimization', 'partner_creation'
    ]
    table_is_excluded = index_name in excluded_indexes
    if (es is None or current_db_name != db_name or is_excluded_flag is None or (table_is_excluded and not is_excluded_flag) or (not table_is_excluded and is_excluded_flag)):
        logging.info("Initializing OpenSearch for DB: %s", db_name)
        es = initialize_opensearch(db_name,index_name)
        if es is None:
            raise ValueError(f"Failed to initialize OpenSearch for {db_name}")
    else:
        logging.info(f"Using existing OpenSearch client for {db_name} (excluded_flag={is_excluded_flag})")
    bulk_change_id=data.get("bulk_change_id",None)
    flag=data.get("flag",None)
    page_flag=data.get("page_flag","Pagination")
    session_id=data.get("session_id",None)
    toggle=data.get("toggle",None)
    username=data.get("username",None)
    col_sort = data.get('col_sort',None)
    tenant_name = data.get("partner", "")
    account_number = data.get("account_number",None)
    user_first_last_name = data.get("firstLastName",None)
    col_sort = None
    if index_name != 'Customer Services':
        col_sort = data.get('col_sort',None)
    tenant_name = data.get("partner", "")
    tenant_id = data.get("tenant_id", None)
    current_cycle = data.get("current_cycle", None)
    is_redirected = data.get("is_redirected", False)
    sub_tenant_name = data.get("sub_tenant_name", None)
    partner_name = data.get("Selected_Partner", None)
    customer_group_name = data.get("customer_group_name", None)
    tenant_db_name = data.get("tenant_database", "altaworx_test")
    dollar_fields = ['sms_quantity','usage_cost','usage_quantity','usage_mb', 'sms_cost', 'overage_rate_cost', 'rate_charge_amt', 'base_rate', 'sms_rate', 'total_charge_amount', 'total_charges', 'carrier_cycle_usage_mb','plan_mb' ,'device_count','display_rate','min_plan_data_mb','max_plan_data_mb', 'data_per_overage_charge','account_balance']
    try:
        pages=data.get("pages")
        start=int(pages.get("start",None))
        end=int(pages.get("end",None))
    
    except:
        pass
    results=None
    sources=[]
    database = DB(db_name, **get_db_config(db_name))
    if index_name in ["usage_by_line_report", "customer_rate_pool_usage_report"]:
        # index_name = resolve_usage_table(tenant_name, db_name)
        index_name = fetching_usage_by_line_table(tenant_name, db_name, username, index_name)
        logging.info("index_name-------- %s", index_name)


    pquery=f"select search_tables,search_cols from open_search_index where search_module='{index_name}'"
    table_data=database.execute_query(pquery, True)
    index_list = table_data['search_tables'].iloc[0]
    search_type=table_data['search_cols'].iloc[0]
    index = index_list
    # search_type="whole"

    # Assuming 'partner' is the correct key for tenant name
    if not tenant_name:
        raise ValueError("Tenant name is missing.")
    tenant_time_zone = get_tenant_timezone(tenant_name)

    if index in ["vw_users_tenant_roles","carrier_apis","amop_apis","email_audit","email_templates", "deployment_tenant_based_banners", "deployment_tenant_based_audit_logs", "tenant","vw_tenant_partner_addition"]:
        index_list=f"{index_list}"
    elif index_name in ["Central_bulk_change", "Central_optimization"]:
        index_list=f"{index_list}_central_db".lower()
    else:
        index_list=f"{index_list}_{db_name}".lower()

    whole_results, advanced_results, combine_results = None, None, None
    whole_total_rows, advanced_total_rows, combine_total_rows = 0, 0, 0
    t1 = time.time()
    search_word = data.get('search_word',None)
    if (
        search in ["combined", "whole"]
        and index_name in ['Unposted Upload Status']
        and search_word
        and search_word.isdigit()
        and len(search_word) >= 10
    ):
        search = "advanced"


    if search == "advanced":
        filters = data.get('filters')
        logging.info("filters-------- %s", filters)
        # if index_name == "daily_usage_report_export":
        #     billing_cycle_dates = filters.get("billing_cycle_end_date", [])
        #     start_dates = []
        #     end_dates = []

        #     for date_str in billing_cycle_dates:
        #         try:
        #             # If already in range format, just split it
        #             if isinstance(date_str, str) and ":" in date_str:
        #                 start_str, end_str = date_str.split(":")
        #                 start_dates.append(datetime.datetime.strptime(start_str, "%m-%d-%Y"))
        #                 end_dates.append(datetime.datetime.strptime(end_str, "%m-%d-%Y"))
        #                 continue

        #             # Otherwise parse input like "10/04/2025"
        #             dt = datetime.datetime.strptime(date_str, "%m/%d/%Y")

        #             # Start = same day previous month
        #             start_dt = dt - relativedelta(months=1)
        #             end_dt = dt

        #             start_dates.append(start_dt)
        #             end_dates.append(end_dt)

        #         except Exception as e:
        #             logging.error(f"Invalid billing_cycle_end_date format {date_str}: {e}")

        #     if start_dates and end_dates:
        #         # Take min start and max end → merge to single range
        #         min_start = min(start_dates)
        #         max_end = max(end_dates)
        #         filters["usage_date"] = [
        #             f"{min_start.strftime('%d-%m-%Y')}:{max_end.strftime('%d-%m-%Y')}"
        #         ]
        #         filters.pop("billing_cycle_end_date", None)

        #     logging.info("### filters-------- %s", filters)
        search_word = data.get('search_word',None)
        if index_name in ['Unposted Upload Status'] and search_word is not None:
            if filters is None:
                filters = {}
                filters['id'] = list(set(get_id_list(search_word, db_name)))
            elif filters.get('id',None) is not None:
                filters['id'] = list(set(get_id_list(search_word, db_name)) & set(filters['id']))

        logging.info("filters-------- %s", filters)
        if index_name in ["Inventory", "inventory_export", "daily_usage_report_export","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
            logging.info(f"### Checking tenant information for tenant_name: {tenant_name}")
            database = DB("common_utils", **get_db_config("common_utils"))
            
            tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
            
            if not tenant_data.empty:
                tenant_id = tenant_data["id"].to_list()[0]
                parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
                
                logging.info(f"### Tenant ID: {tenant_id} | Parent Tenant ID: {parent_tenant_id}")
                
                # Handle sub-tenant column swap if parent_tenant_id exists
                if parent_tenant_id is not None:
                    if "carrier_rate_plan_name" in filters:
                        filters["sub_tenant_carrier_rate_plan_name"] = filters.pop("carrier_rate_plan_name")
                        logging.info("### Filters updated for sub-tenant: %s", filters)
                    elif "carrier_rate_plan" in filters:
                        filters["sub_tenant_carrier_rate_plan_name"] = filters.pop("carrier_rate_plan")
                        logging.info("### Filters updated for sub-tenant: %s", filters)
                

        if index_name == "daily_usage_report_export":
            billing_cycle_dates = filters.get("billing_cycle_end_date", [])
            # start_dates = []
            # end_dates = []
            usage_date_ranges = []
            if not billing_cycle_dates or all(d.strip() == "" for d in billing_cycle_dates):
                today_date = datetime.datetime.now().strftime("%m/%d/%Y")
                filters["usage_date"] = [today_date]
                logging.info(f"No billing_cycle_end_date found. Defaulting usage_date to today: {today_date}")
                filters.pop("billing_cycle_end_date", None)
            else:
                for date_str in billing_cycle_dates:
                    try:
                        # If already in range format, just split it
                        if isinstance(date_str, str) and ":" in date_str:
                            start_str, end_str = date_str.split(":")
                            # start_dt.append(datetime.datetime.strptime(start_str, "%m-%d-%Y"))
                            # end_dt.append(datetime.datetime.strptime(end_str, "%m-%d-%Y"))
                            start_dt = datetime.datetime.strptime(start_str.strip(), "%m-%d-%Y")
                            end_dt = datetime.datetime.strptime(end_str.strip(), "%m-%d-%Y")
                        else:
                            # Otherwise parse input like "10/04/2025"
                            dt = datetime.datetime.strptime(date_str, "%m/%d/%Y")

                            # Start = same day previous month
                            start_dt = dt - relativedelta(months=1)
                            end_dt = dt

                            # start_dates.append(start_dt)
                            # end_dates.append(end_dt)

                        usage_date_ranges.append(
                            f"{start_dt.strftime('%d-%m-%Y')}:{end_dt.strftime('%d-%m-%Y')}"
                        )
                    

                    except Exception as e:
                        logging.error(f"Invalid billing_cycle_end_date format {date_str}: {e}")

                if usage_date_ranges:
                    # Assign multiple ranges instead of merging into one
                    filters["usage_date"] = usage_date_ranges
                    filters.pop("billing_cycle_end_date", None)

            logging.info("### filters-------- %s", filters)
        username=data.get('username',None)
        # Iterate through filters and replace "<Empty spaces>" with an empty string
        customer_columns = ['customer_name','name']
        service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
        customer_rate_plan_names=["customer_rate_plan_name","rate_plan_name","customer_rate_plan"]
        # user_data={'customer': ['US Vision, Inc.- Mcallen (300006738)'], 'service_provider': ['AT&T - Cisco Jasper']}
        query = f"SELECT customers, service_provider, customer_group, role, first_name, last_name, tenant_role_mapping FROM users WHERE username ='{username}'"
        # Create the database connection
        database = DB("common_utils", **get_db_config("common_utils"))
        user_df = database.execute_query(query, True)
        user_data = {}
        user_data["role"] = user_df['role'].to_list()[0]
        user_data["first_name"] = user_df['first_name'].to_list()[0]
        user_data["last_name"] = user_df['last_name'].to_list()[0]
        tenant_role_mapping = user_df["tenant_role_mapping"].iloc[0]
        user_role = None 
        if tenant_role_mapping and index_name == "partner_users":
            try:
                # If it's a string → parse it
                if isinstance(tenant_role_mapping, str):
                    role_mappings = json.loads(tenant_role_mapping)
                else:
                    # Already list/dict
                    role_mappings = tenant_role_mapping

                for item in role_mappings:
                    if item.get("tenant") == tenant_name:
                        user_role = item.get("role")
                        break
            except Exception as e:
                # JSON parsing issue — fallback already set
                logging.exception("Error parsing tenant_role_mapping, using default user_role")
                pass

        user_data["role"] = user_role

        for key, value in filters.items():
            if value is not None and isinstance(value, list): 
                for i in range(len(value)):
                    if index_name in ["rev_assurance_variance", "rev_assurance"] and key == "customer_name" and value[i] == "Unassigned":
                        value[i] = ""
                        break
                    elif value[i] == "(Blanks)":
                        value[i] = ""  # Replace with empty string
                        break
        if is_field_present(index_list, 'is_active') and index not in ["products_list_view","vw_combined_rev_service_products", "vw_combined_rev_service_products_altaworx_test","vw_combined_rev_service_products_with_out_variance","vw_combined_rev_service_products_with_out_variance_altaworx_test", "vw_zero_usage_report", "vw_usage_by_line_report", "vw_newly_activated_report",'vw_status_history_report', 'vw_daily_usage_report_export',"customer_services","gl_code","serviceprovider","billing_report_view","ar_aging_view","vw_export_variance_billing_report"]:
            filters['is_active'] = True
            if index_name in ["action_history_report"]:
                filters.pop("is_active", None)
            elif toggle == False:
                filters["is_active"] = ["true", "false"]
    
        # if is_field_present(index_list, 'is_active') and is_field_present(index_list, 'is_deleted') and index == 'transaction_analysis_view':
        #     filters['is_active'] = False
        #     filters['is_deleted'] = False
        if account_number:
            if index_name in ['Customer Payment History','Unposted Upload Status']:
                filters['account_number'] = account_number
            elif index == 'ledger':
                filters['account'] = account_number
            elif index_name == 'RepostedMRC':
                service_id = get_service_id(account_number,current_cycle,db_name) 
                if 'id' not in filters:
                    filters['id'] = service_id
            else:
                id = get_customer_id(account_number,db_name)
                filters['customer_profile_id'] = int(id)

        if upload_id and index_name in ['Unposted Upload Data']:
            filters['upload_id'] = int(upload_id)

        if customer_group_name and index_name == "Filtered_Customer_Rate_Plan":
            if "rate_plan_name" not in filters:
                rate_plans = get_rate_plans_by_customer_group(customer_group_name, db_name)
                if rate_plans:
                    filters["rate_plan_name"] = rate_plans
                else:
                    filters["rate_plan_name"] = ""
        logging.info(f"## filters: {filters}")
        if index_name in ['Collection Templates'] and is_field_present(index_list, 'is_deleted'):
            filters['is_deleted'] = False
        if index in ['gl_code','serviceprovider']:
            if index == 'serviceprovider':
                sub_tenant_name = data.get('sub_partner',None)
            if sub_tenant_name:
                tenant_name = sub_tenant_name
            elif partner_name:
                tenant_name =  partner_name
            id = get_tenant_id(tenant_name)
            if index == 'gl_code':
                filters["sub_tenant_id"] = int(id)
                filters.pop("tenant_id")
            else:
                filters["tenant_id"] = int(id)
                    
        # if index_name in ["Billed Through Date Report"]:
        #     filters['billed_flag'] =  False

        if index_name in ["Unposted","Reversals"]:
            if index_name == "Unposted":
                filters['reversal_flag'] =  False
            else:
                filters['reversal_flag'] =  True

        if 'bulk_change_id' in filters:
            bulk_change_id=filters['bulk_change_id']
            if any(keyword in index for keyword in ["sim_management_bulk_change_request","sim_management_bulk_change_request", "sim_management_bulk_change_view"]):
                filters['bulk_change_id'] = bulk_change_id
            else:
                removed_value = filters.pop('bulk_change_id', None)
        if index_name in ['rev_assurance_variance','rev_assurance']:
            filters['bp_customer'] = False

        if index_name == "Inventory":
            for key, value in filters.items():
                # Check if the value is a list or an iterable before using len()
                if isinstance(value, list):
                    if len(value) > 60000:
                        filters[key] = value[:60000]  # Slice the list to the first 60000 items
                    print(f"Count of values for '{key}' : {len(filters[key])}")
                else:
                    print(f"Value for '{key}' is not a list, so it cannot be sliced.")
        print("Advance search filters are --", filters)
        # print("filters",filters)
        if index_name in ['Inventory', 'inventory_export', 'usage_by_line_report2']:
            print("adding service_provider_is_active filter")
            filters['service_provider_is_active'] = True
            # filters['tenant_is_active'] = True
            print("Advance search filters are --",filters)
        if user_data['role'] not in ('Super Admin', 'Partner Admin') and index_name == "Billing report by day with OCC Report":
            index_list = f"altaworx_billing_report_by_day_search_{db_name}"

        index_mapping = get_index_mappings_with_types(index_list)
        agent_flag = False
        print("index_name ******", index_name)
        if index not in ["email_audit","email_templates","vw_users_tenant_roles"] and db_name != os.getenv('BILLING_PLATFORM'):
            agent_rel_data=db_config_maker(username, db_config,db_name,tenant_name,user_data['role'], index_name,user_first_last_name)
            agent_rel_data = {
                k: list(v) if isinstance(v, tuple) else v
                for k, v in agent_rel_data.items()
            }

            print("agent_data ---", agent_rel_data)
            previous_filters = filters.copy()
            filters.update(agent_rel_data)
            agent_flag = True
        if index in ["email_audit", "email_templates"]:
            database = DB("common_utils", **get_db_config("common_utils"))

            tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
            if tenant_data.empty:
                raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

            tenant_id = tenant_data["id"].to_list()[0]
            parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

            if parent_tenant_id is not None:
                filters["tenant_id"] = tenant_id  # Add to filter
            else:
                filters["tenant_id"] = None
        print("advanced__tej",filters)
        query_filters = {}
        # print("index_mapping", index_mapping)
        for key, value in filters.items():
            if key in ["customer","name"]:
                customer_field = next((col for col in customer_columns if col in index_mapping), None)
                if index_name == 'action_history_report':
                    customer_field = 'customer_account_name'
                if customer_field:
                    field_name = customer_field
                    query_filters[field_name] = value
                continue

            if key == "service_provider":
                if agent_flag:
                    prev_value = previous_filters.get(key)
                    if prev_value is not None:
                        value = prev_value
                service_provider_field = next((col for col in service_provider_column if col in index_mapping), None)
                if service_provider_field:
                    field_name = service_provider_field
                    query_filters[field_name] = value
                continue

            if key == "customer_rate_plan_name":
                customer_rate_plan_field = next((col for col in customer_rate_plan_names if col in index_mapping), None)
                if customer_rate_plan_field:
                    field_name = customer_rate_plan_field
                    query_filters[field_name] = value
                continue

            if key in index_mapping:
                field_type = index_mapping[key]
                field_name = key
                query_filters[field_name] = value
        
        if user_data['role'] != 'Super Admin' and index_name in ["rev_assurance_variance", "rev_assurance","sim_management_bulk_change"]:
            by_fields = ["created_by", "modified_by", "deleted_by"]
            selected_by_field = next((field for field in by_fields if field in index_mapping), None)
            username = user_data["first_name"]+" "+user_data["last_name"]
            if selected_by_field:
                query_filters[selected_by_field] = username
        print("query_filters", query_filters)
        if agent_flag:
            if user_data['role'] == 'Agent Partner Admin':
                for key, value in query_filters.items():
                    prev_value = previous_filters.get(key)
                    if prev_value is not None:
                        if isinstance(prev_value, list):
                            clean_values = [v for v in prev_value if v != '']
                            print(f"## clean_values {clean_values}")
                            # If list is empty after cleaning and key is customer_name, set to ['__NO_MATCH__']
                            if not clean_values and key == 'customer_name':
                                query_filters[key] = ['__NO_MATCH__']
                            elif clean_values:
                                query_filters[key] = clean_values
                        else:
                            if prev_value != '':
                                query_filters[key] = prev_value
            else:
                print("agent_flag",user_data['role'])
                for key, value in query_filters.items():
                    prev_value = previous_filters.get(key)
                    if prev_value is not None:
                        query_filters[key] = prev_value
                        
        if index_name in ["Central_bulk_change", "Central_optimization","sim_management_bulk_change_request", "Comm_Plans","GL Code Settings", "IMEI_Master_Table","e911customers","partner_creation"]:
            query_filters.pop('tenant_id', None)
        logging.info("query_filters- %s ", query_filters)
        if index_name == "daily_usage_report_export":
            # service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
            # check if service_provider exists and is empty
            logging.info(f"service_provider_column - {service_provider_column}")
            for col in service_provider_column:
                if col in query_filters and (
                    not query_filters[col] or query_filters[col] == [""]
                ):
                    query_filters.pop(col)
            # Clean billing_cycle_end_date
            if "billing_cycle_end_date" in query_filters and (
                not query_filters["billing_cycle_end_date"]
                or query_filters["billing_cycle_end_date"] == [""]
            ):
                query_filters.pop("billing_cycle_end_date")
        elif index_name == "sim_order_form":
            # Add company filter for sim_order_form
            query_filters["company"] = tenant_name
        elif index_name in ["email_audit", "email_templates"]:
            query_filters["partner_name"] = tenant_name
        logging.info(f"query_filters after cleanup - {query_filters}")
        if index_name in ['Charge By Service','Usage Details','Charge Overview','Charge Details','Recurring Charge Details','Credit Details']:
            if data.get("bill_id", None):
                query_filters['applied_to_bill'] = int(data.get("bill_id", None))
            if index_name in ['Charge By Service','Recurring Charge Details']:
                query_filters['category'] = 'MRC'
            elif index_name in ['Credit Details']:
                query_filters['category'] = 'Credit'
            query_filters.pop("is_active")

        DATE_FORMAT = "%m/%d/%Y"
        updated_filters = {}
        for key,value in query_filters.items():
            field_type = index_mapping[key]
            logging.info(f"key - {key} and field_type - {field_type}")
            if isinstance(value, list) and len(value) > 500 and field_type == 'date':
                empty_present = False

                if isinstance(value, list):
                    empty_present = any(v == '' for v in value)
                elif isinstance(value, str):
                    empty_present = value.strip() == ''

                if empty_present:
                    logging.info(f"Empty value detected for field: {key}")

                parsed_dates = [
                    datetime.datetime.strptime(v, DATE_FORMAT)
                    for v in value
                    if isinstance(v, str) and v.strip() != ''
                ]
                min_date = min(parsed_dates).strftime("%Y-%m-%d")
                max_date = max(parsed_dates).strftime("%Y-%m-%d")
                logging.info(f"date range more than 1024 so taking range from {min_date} to {max_date}")
                if not empty_present:
                    updated_filters[key] = [f"{min_date}:{max_date}"]
                else:
                    updated_filters[key] = {
                        "range": f"{min_date}:{max_date}",
                        "include_empty": empty_present
                    }
            else:
                updated_filters[key] = value
        
        query_filters = updated_filters
        logging.info("final filters for elasticsearch %s", query_filters)
            
        flag="pagination"
        if start > 9999 or page_flag == "Nopagination":
            search="advanced_pro"
            advanced_results,advanced_total_rows,search_body =advanced_search_data(query_filters, index_list, start, end,page_flag,db_name,index_name,col_sort,tenant_name,user_data['role'],dollar_fields,tenant_time_zone,is_redirected,scroll_time='1m')
            # print("advanced_results", advanced_results)
        else:
            advanced_results,search_body=advance_search_data(query_filters,index_list,start, end,db_name,index_name,col_sort,tenant_name,user_data['role'],is_redirected)
            if advanced_results:
                advanced_total_rows = advanced_results.get('hits', {}).get('total', {}).get('value', 0)
                
    elif search == "whole":
        query=data.get("search_word")
        username = data.get("username", None)
        module_name=get_module_name(index_name,db_name)
        columns=get_columns_from_db(module_name,db_name)
        customer_columns = ['customer_name','name']
        service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
        customer_rate_plan_names=["customer_rate_plan_name","rate_plan_name","customer_rate_plan"]
        custom_filter = {}
        if any(keyword in index_list for keyword in ["sim_management_inventory_action_history"]) or index_name in ['RepostedMRC','GL Code Settings','Billing Service Providers']:
            custom_filter={}
        elif index_name == "sim_management_bulk_change":
            custom_filter={"is_active": True}
            # columns.append("iccid")
            columns.extend(["iccid", "subscriber_number"])
        elif is_field_present(index_list, 'is_active') and index_name not in [
            "rev_assurance","rev_assurance_variance",
            "zero_usage_report","usage_by_line_report", "newly_activated_report", "status_history_report", "GL Code Settings", "vw_customer_services_usage_altaworx","Billing Report w/_City_County_Country","AR Aging Report"
        ]:
            
            if index_name in ["action_history_report", "usage_by_line_report", "usp_report_customer_usage_by_line"]:
                custom_filter = {}
            # elif index_name == 'Transaction Analysis Report':
            #     custom_filter={"is_active": False, "is_deleted": False}
            elif toggle == False:
                custom_filter = {"is_active": ["true", "false"]}
            else:
                custom_filter = {"is_active": True}
        elif any(keyword in index_list for keyword in ["sim_management_inventory", "vw_combined_device_inventory_export", "sim_management_inventory"]):
            custom_filter={"is_active": True, "tenant_id": 1 }
        elif flag == "bulk_history" or any(keyword in index_list for keyword in ["sim_management_bulk_change_request","sim_management_bulk_change_request"]):
            # custom_filter={"bulk_change_id": bulk_change_id[0] }
            if isinstance(bulk_change_id, list):
                custom_filter = {"bulk_change_id": bulk_change_id[0]}
            else:
                custom_filter = {"bulk_change_id": bulk_change_id}
            columns.append("bulk_change_id")
        
        elif index in ["customerrateplan","services","product_types","packages_list_view","products_list_view"] and toggle == False:
            custom_filter={}
        # elif index == 'transaction_analysis_view':
        #     custom_filter={"is_active": False, "is_deleted": False}
        elif index not in ["vw_users_tenant_roles","products_list_view","vw_combined_rev_service_products", "vw_combined_rev_service_products_altaworx_test","vw_combined_rev_service_products_with_out_variance","vw_combined_rev_service_products_with_out_variance_altaworx_test", "vw_zero_usage_report", "vw_usage_by_line_report", "vw_newly_activated_report",'vw_status_history_report',"billing_report_view","ar_aging_view","vw_export_variance_billing_report"]:
            logging.info(f"checking - is_active index_list -- {index}")
            custom_filter={"is_active": True}
            logging.info("### custom_filter- %s ", custom_filter)
        if username:
            try:
                query_user = f"SELECT customers, service_provider, customer_group, role, first_name, last_name, tenant_role_mapping FROM users WHERE username ='{username}'"
                database = DB("common_utils", **get_db_config("common_utils"))
                user_df = database.execute_query(query_user, True)
                user_data = {}
                user_data["role"] = user_df['role'].to_list()[0]
                user_data["first_name"] = user_df['first_name'].to_list()[0]
                user_data["last_name"] = user_df['last_name'].to_list()[0]
                tenant_role_mapping = user_df["tenant_role_mapping"].iloc[0]
                if tenant_role_mapping:
                    try:
                        # If it's a string → parse it
                        if isinstance(tenant_role_mapping, str):
                            role_mappings = json.loads(tenant_role_mapping)
                        else:
                            # Already list/dict
                            role_mappings = tenant_role_mapping

                        for item in role_mappings:
                            if item.get("tenant") == tenant_name:
                                user_role = item.get("role")
                                break
                    except Exception as e:
                        # JSON parsing issue — fallback already set
                        logging.exception("Error parsing tenant_role_mapping, using default user_role")
                        pass
            
                user_data["role"] = user_role
                try:
                    if user_data['role'] not in ('Super Admin', 'Partner Admin') and index_name == "Billing report by day with OCC Report":
                        index_list = f"altaworx_billing_report_by_day_search_{db_name}"
                    index_mapping = get_index_mappings_with_types(index_list)
                    agent_flag = False
                    filters = {}

                    if index not in ["email_audit","email_templates","vw_users_tenant_roles"] and db_name != os.getenv('BILLING_PLATFORM'):
                        agent_rel_data = db_config_maker(username, db_config, db_name, tenant_name, user_data['role'], index_name, user_first_last_name)
                        agent_rel_data = {
                            k: list(v) if isinstance(v, tuple) else v
                            for k, v in agent_rel_data.items()
                        }
                        print("agent_data", agent_rel_data)
                        filters.update(agent_rel_data)
                        agent_flag = True
                    if index in ["email_audit", "email_templates", "customer_groups_view"]:
                        database = DB("common_utils", **get_db_config("common_utils"))

                        tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
                        if tenant_data.empty:
                            raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

                        tenant_id = tenant_data["id"].to_list()[0]
                        parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

                        if parent_tenant_id is not None:
                            filters["tenant_id"] = tenant_id  # Add to filter
                        else:
                            filters["tenant_id"] = None
                    print("advanced__tej", filters)
                    query_filters = {}
                    for key, value in filters.items():
                        if key in ["customer","name"]:
                            customer_field = next((col for col in customer_columns if col in index_mapping), None)
                            if index_name == 'action_history_report':
                                customer_field = 'customer_account_name'
                            if customer_field:
                                query_filters[customer_field] = value
                            continue

                        if key == "service_provider":
                            service_provider_field = next((col for col in service_provider_column if col in index_mapping), None)
                            if service_provider_field:
                                query_filters[service_provider_field] = value
                            continue

                        if key == "customer_rate_plan_name":
                            customer_rate_plan_field = next((col for col in customer_rate_plan_names if col in index_mapping), None)
                            if customer_rate_plan_field:
                                query_filters[customer_rate_plan_field] = value
                            continue

                        if key in index_mapping:
                            field_type = index_mapping[key]
                            query_filters[key] = value

                    if user_data['role'] != 'Super Admin' and index_name in ["rev_assurance_variance", "rev_assurance", "sim_management_bulk_change"]:
                        by_fields = ["created_by", "modified_by", "deleted_by"]
                        selected_by_field = next((field for field in by_fields if field in index_mapping), None)
                        user_name = user_data['first_name']+" "+user_data['last_name']
                        if selected_by_field:
                            query_filters[selected_by_field] = user_name

                    custom_filter.update(query_filters)
                except Exception as e:
                    print(f"Error applying user filters: {e}")
            except Exception as e:
                    print(f"Error in select query: {e}")
        
        # if is_field_present(index_list, 'tenant_id'):
        #     # if any(keyword in index_list for keyword in ["sim_management_inventory", "sim_management_inventory","vw_combined_rev_service_products", "vw_combined_rev_service_products","vw_combined_rev_service_products_with_out_variance","vw_combined_rev_service_products_with_out_variance", "vw_combined_device_inventory_export", "vw_zero_usage_report", "vw_usage_by_line_report", "vw_newly_activated_report"]):
        #         # tenant_id=1
        #     if db_name == "spectrotel":
        #         tenant_id=162
        #     elif db_name == "altaworx_go_tech":
        #         tenant_id=181
        #     else:
        #         tenant_id=1
        #     # filters['tenant_id'] = tenant_id
        #     custom_filter.update({"tenant_id": tenant_id})

        if index_name in ['optimization_instance_summary']:
            custom_filter['session_id'] = session_id
        
        if account_number:
            if index_name in ['Customer Payment History','Unposted Upload Status']:
                custom_filter['account_number'] = account_number
            elif index == 'ledger':
                custom_filter['account'] = account_number
            elif index_name == 'RepostedMRC':
                service_id = get_service_id(account_number,current_cycle,db_name)
                custom_filter['id'] = service_id
            else:
                id = get_customer_id(account_number,db_name)
                custom_filter['customer_profile_id'] = int(id)

        if upload_id and index_name in ['Unposted Upload Data']:
            custom_filter['upload_id'] = int(upload_id)

        if index_name in ['Collection Templates']:
            custom_filter['is_deleted'] = False
        
        if index_name in ['Billing Service Providers', 'GL Code Settings']:
            if index_name == 'Billing Service Providers':
                sub_tenant_name = data.get('sub_partner', None)
            if sub_tenant_name:
                tenant_name = sub_tenant_name
            elif partner_name:
                tenant_name = partner_name
            tenant_id = get_tenant_id(tenant_name)
            if index_name == 'Billing Service Providers':
                custom_filter['tenant_id'] = int(tenant_id)
            else:
                custom_filter['sub_tenant_id'] = int(tenant_id)
        # if index_name in ['Billed Through Date Report']:
        #     custom_filter['billed_flag'] = False
        
        if index_name in ['Unposted','Reversals']:
            if index_name == 'Unposted':
                custom_filter['reversal_flag'] = False
            else:
                custom_filter['reversal_flag'] = True
            
        if index_name in ['Collections Summary','Billing Package']:
            tenant_id = data.get('tenant_id')
            if tenant_id:
                custom_filter['tenant_id'] = int(tenant_id)
            else:
                tenant_id = get_tenant_id(tenant_name)
                custom_filter['tenant_id'] = int(tenant_id)
        
        if index_name in ['Charge By Service','Usage Details','Charge Overview','Charge Details','Recurring Charge Details','Credit Details']:
            if data.get("bill_id", None):
                custom_filter['applied_to_bill'] = int(data.get("bill_id", None))
            if index_name in ['Charge By Service','Recurring Charge Details']:
                custom_filter['category'] = 'MRC'
            elif index_name in ['Credit Details']:
                custom_filter['category'] = 'Credit'
            custom_filter.pop("is_active")
        if index_name in ['rev_assurance_variance','rev_assurance']:
            custom_filter['bp_customer'] = False
        if customer_group_name and index_name == "Filtered_Customer_Rate_Plan":
            
            rate_plans = get_rate_plans_by_customer_group(customer_group_name, db_name)
            if rate_plans:
                custom_filter["rate_plan_name"] = rate_plans
            else:
                custom_filter["rate_plan_name"] = ""
        logging.info("custom_filter --- %s", custom_filter)
        date_format = is_valid_date(query)
        if date_format:
            # Parse the input date string into a datetime object
                input_date = datetime.datetime.strptime(query, date_format)

            # Convert the datetime object into the desired ISO format (2023-04-27T19:06:00)
                query = input_date.strftime("%Y-%m-%dT%H:%M:%S")
        custom_filter = {k: v for k, v in custom_filter.items() if v is not None}
        if index_name in ["Central_bulk_change", "Central_optimization","sim_management_bulk_change_request", "Comm_Plans", "IMEI_Master_Table","e911customers","partner_creation"]:
            custom_filter.pop('tenant_id', None)
        print("Whole search custom_filter",custom_filter)
        if index_name in ['Inventory', 'inventory_export', 'usage_by_line_report2']:
            print("adding service_provider_is_active filter")
            custom_filter['service_provider_is_active'] = True
            # custom_filter['tenant_is_active'] = True
        elif index_name == "sim_order_form":
            # Add company filter for sim_order_form
            custom_filter["company"] = tenant_name
        elif index_name in ["email_audit", "email_templates"]:
            custom_filter["partner_name"] = tenant_name
        logging.info(f"Whole search custom_filter - {custom_filter}")
        whole_results,whole_total_rows,search_body = search_data(query, search_all_columns, index_list, start, end, columns, db_name, custom_filter, page_flag, index_name,col_sort,tenant_name,user_data['role'])
        # print("whole_total_rows",whole_total_rows)
    elif search == "combined":
        filters = data.get('filters')
        username=data.get('username',None)
        # Iterate through filters and replace "<Empty spaces>" with an empty string
        customer_columns = ['customer_name','name']
        service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
        customer_rate_plan_names=["customer_rate_plan_name","rate_plan_name","customer_rate_plan","customer_rate_plans"]
        # user_data={'customer': ['US Vision, Inc.- Mcallen (300006738)'], 'service_provider': ['AT&T - Cisco Jasper']}
        query = f"SELECT customers, service_provider, customer_group, role, first_name, last_name, tenant_role_mapping FROM users WHERE username ='{username}'"
        # Create the database connection
        database = DB("common_utils", **get_db_config("common_utils"))
        user_df = database.execute_query(query, True)
        user_data = {}
        user_data["role"] = user_df['role'].to_list()[0]
        user_data["first_name"] = user_df['first_name'].to_list()[0]
        user_data["last_name"] = user_df['last_name'].to_list()[0]
        tenant_role_mapping = user_df["tenant_role_mapping"].iloc[0]
        if tenant_role_mapping:
            try:
                # If it's a string → parse it
                if isinstance(tenant_role_mapping, str):
                    role_mappings = json.loads(tenant_role_mapping)
                else:
                    # Already list/dict
                    role_mappings = tenant_role_mapping

                for item in role_mappings:
                    if item.get("tenant") == tenant_name:
                        user_role = item.get("role")
                        break
            except Exception as e:
                # JSON parsing issue — fallback already set
                logging.exception("Error parsing tenant_role_mapping, using default user_role")
                pass
        user_data["role"] = user_role
        if db_name != 'billing_platform':
            try:
                user_data["customer"]=list(json.loads(user_df['customers'].to_list()[0]))  
            except:
                user_data["customer"] = [] 
            try:
                user_data["service_provider"]=list(json.loads(user_df['service_provider'].to_list()[0]))
            except:
                user_data["service_provider"]=[]
                
            
            for col in customer_columns:
                if is_field_present(index_list, col):
                    previous_customer_filter = filters.get(col, None)
                    # Add the column to filter conditions
                    if user_data['customer']:
                        filters[col]= user_data['customer']
                    else:
                        filters[col] = previous_customer_filter
                    break  # Use the first valid column found
            # Check for service provider columns in the index mapping
        
            for col in service_provider_column:
                if is_field_present(index_list, col):
                    previous_service_provider_filter = filters.get(col, None)
                    # Add the column to filter conditions
                    if user_data['service_provider']:
                        filters[col] = user_data['service_provider']
                    else:
                        filters[col] = previous_service_provider_filter
                    break
        for key, value in filters.items():
            if value is not None and isinstance(value, list): 
                for i in range(len(value)):
                    if index_name in ["rev_assurance_variance", "rev_assurance"] and key == "customer_name" and value[i] == "Unassigned":
                        value[i] = ""
                        break
                    elif value[i] == "(Blanks)":
                        value[i] = ""  # Replace with empty string
                        break
        if is_field_present(index_list, 'is_active') and index not in ["vw_combined_rev_service_products", "vw_combined_rev_service_products_altaworx_test","vw_combined_rev_service_products_with_out_variance","vw_combined_rev_service_products_with_out_variance_altaworx_test", "vw_zero_usage_report", "vw_usage_by_line_report", "vw_newly_activated_report","customer_services","gl_code","serviceprovider","billing_report_view","ar_aging_view","vw_export_variance_billing_report"]:
            filters['is_active'] = True
            if index_name in ["action_history_report"]:
                filters.pop("is_active", None)
            elif toggle == False:
                filters["is_active"] = ["true", "false"]
        # if is_field_present(index_list, 'is_active') and is_field_present(index_list, 'is_deleted') and index == 'transaction_analysis_view':
        #     filters['is_active'] = False
        #     filters['is_deleted'] = False
        if account_number:
            if index_name in ['Customer Payment History','Unposted Upload Status']:
                filters['account_number'] = account_number
            elif index == 'ledger':
                filters['account'] = account_number
            elif index_name == 'RepostedMRC':
                service_id = get_service_id(account_number, current_cycle, db_name)
                if 'id' not in filters:
                    filters['id'] = service_id
            else:
                id = get_customer_id(account_number,db_name)
                filters['customer_profile_id'] = int(id)

        if upload_id and index_name in ['Unposted Upload Data']:
            filters['upload_id'] = int(upload_id)
        
        if index_name in ['Collection Templates'] and is_field_present(index_list, 'is_deleted'):
            filters['is_deleted'] = False

        if index_name in ['Billing Service Providers','GL Code Settings']:
            if index_name == 'Billing Service Providers':
                sub_tenant_name = data.get('sub_partner', None)
            if sub_tenant_name:
                tenant_name = sub_tenant_name
            elif partner_name:
                tenant_name = partner_name
            tenant_id = get_tenant_id(tenant_name)
            if index_name == 'Billing Service Providers':
                filters['tenant_id'] = int(tenant_id)
                if tenant_id == 212:   #only in UAT
                    filters['tenant_id'] = 1
            else:
                if tenant_id == 212:   #only in UAT
                    tenant_id = 1
                filters['sub_tenant_id'] = int(tenant_id)
                
        if index_name in ['Unposted','Reversals']:
            if index_name == 'Unposted':
                filters['reversal_flag'] = False
            else:
                filters['reversal_flag'] = True
                
        if customer_group_name and index_name == "Filtered_Customer_Rate_Plan":
            if "rate_plan_name" not in filters:
                rate_plans = get_rate_plans_by_customer_group(customer_group_name, db_name)
                if rate_plans:
                    filters["rate_plan_name"] = rate_plans
                else:
                    filters["rate_plan_name"] = ""
        logging.info("filters --- %s", filters)
        if index_name in ['Charge By Service','Usage Details','Charge Overview','Charge Details','Recurring Charge Details','Credit Details']:
            if data.get("bill_id", None):
                filters['applied_to_bill'] = int(data.get("bill_id", None))
            if index_name in ['Charge By Service','Recurring Charge Details']:
                filters['category'] = 'MRC' 
            elif index_name == 'Credit Details':
                filters['category'] = 'Credit'
            filters.pop("is_active")
        # if index_name in ['Billed Through Date Report']:
        #     filters['billed_flag'] = False
        # if is_field_present(index_list, 'tenant_id'):
        # # if any(keyword in index for keyword in ["sim_management_inventory", "sim_management_inventory_altaworx_test","vw_combined_rev_service_products", "vw_combined_rev_service_products_altaworx_test","vw_combined_rev_service_products_with_out_variance","vw_combined_rev_service_products_with_out_variance_altaworx_test", "vw_combined_device_inventory_export", "vw_zero_usage_report", "vw_usage_by_line_report", "vw_newly_activated_report", "vw_carrier_search_view", "vw_customer_search_view"]):
        #         # tenant_id=1
        #     if db_name == "spectrotel":
        #         tenant_id=162
        #     elif db_name == "altaworx_go_tech":
        #         tenant_id=181
        #     else:
        #         tenant_id=1
        #     filters['tenant_id'] = tenant_id
            # else:
            #     filters.pop('tenant_id', None)
        if 'bulk_change_id' in filters:
            bulk_change_id=filters['bulk_change_id']
            if any(keyword in index for keyword in ["sim_management_bulk_change_request","sim_management_bulk_change_request_altaworx_test", "sim_management_bulk_change_view"]):
                filters['bulk_change_id'] = bulk_change_id
            else:
                removed_value = filters.pop('bulk_change_id', None)
        if index_name in ['rev_assurance_variance','rev_assurance']:
            filters['bp_customer'] = False
        if index_name == "Inventory":
            for key, value in filters.items():
                # Check if the value is a list or an iterable before using len()
                if isinstance(value, list):
                    if len(value) > 60000:
                        filters[key] = value[:60000]  # Slice the list to the first 60000 items
                    print(f"Count of values for '{key}' : {len(filters[key])}")
                else:
                    print(f"Value for '{key}' is not a list, so it cannot be sliced.")
        query=data.get("search_word")
        module_name=get_module_name(index_name,db_name)
        columns=get_columns_from_db(module_name,db_name)

        if user_data['role'] not in ('Super Admin', 'Partner Admin') and index_name == "Billing report by day with OCC Report":
            index_list = f"altaworx_billing_report_by_day_search_{db_name}"

        index_mapping = get_index_mappings_with_types(index_list)
        agent_flag = False
        if index not in  ["email_audit","email_templates","vw_users_tenant_roles"] and db_name != os.getenv('BILLING_PLATFORM'):
            agent_rel_data=db_config_maker(username, db_config, db_name, tenant_name, user_data['role'], index_name, user_first_last_name)
            agent_rel_data = {
                k: list(v) if isinstance(v, tuple) else v
                for k, v in agent_rel_data.items()
            }
            print("agent_data", agent_rel_data)
            previous_filters = filters.copy()
            filters.update(agent_rel_data)
            agent_flag = True
            filters = {k: v for k, v in filters.items() if v is not None}
        if index in ["email_audit", "email_templates"]:
            database = DB("common_utils", **get_db_config("common_utils"))

            tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
            if tenant_data.empty:
                raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

            tenant_id = tenant_data["id"].to_list()[0]
            parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

            if parent_tenant_id is not None:
                filters["tenant_id"] = tenant_id  # Add to filter
            else:
                filters["tenant_id"] = None
        filter = {}
        for key, value in filters.items():
            if key in ["customer","name"]:
                customer_field = next((col for col in customer_columns if col in index_mapping), None)
                if index_name == 'action_history_report':
                    customer_field = 'customer_account_name'
                if customer_field:
                    field_name = customer_field
                    filter[field_name] = value
                continue

            if key == "service_provider":
                service_provider_field = next((col for col in service_provider_column if col in index_mapping), None)
                if service_provider_field:
                    field_name = service_provider_field
                    filter[field_name] = value
                continue

            if key == "customer_rate_plan_name":
                customer_rate_plan_field = next((col for col in customer_rate_plan_names if col in index_mapping), None)
                if customer_rate_plan_field:
                    field_name = customer_rate_plan_field
                    filter[field_name] = value
                continue

            if key in index_mapping:
                field_type = index_mapping[key]
                field_name = key
                filter[field_name] = value
            
        # if agent_flag:
        #     contains_customer_or_plan = any(
        #         field in filters
        #         for field in (customer_columns + customer_rate_plan_names)
        #     )
        #     if not contains_customer_or_plan:/
        if user_data['role'] != 'Super Admin' and index_name in ["rev_assurance_variance", "rev_assurance", "sim_management_bulk_change"]:
            by_fields = ["created_by", "modified_by", "deleted_by"]
            selected_by_field = next((field for field in by_fields if field in index_mapping), None)
            username = user_data["first_name"]+" "+user_data["last_name"]
            if selected_by_field:
                filter[selected_by_field] = username
        
        if agent_flag:
            if user_data['role'] == 'Agent Partner Admin':
                for key, value in filters.items():
                    prev_value = previous_filters.get(key)
                    if prev_value is not None:
                        if isinstance(prev_value, list):
                            clean_values = [v for v in prev_value if v != '']
                            print(f"## clean_values {clean_values}")
                            # If list is empty after cleaning and key is customer_name, set to ['__NO_MATCH__']
                            if not clean_values and key == 'customer_name':
                                filters[key] = ['__NO_MATCH__']
                            elif clean_values:
                                filters[key] = clean_values
                        else:
                            if prev_value != '':
                                filters[key] = prev_value
            else:
                print("agent_flag",user_data['role'])
                for key, value in filters.items():
                    prev_value = previous_filters.get(key)
                    if prev_value is not None:
                        filters[key] = prev_value
        

        date_format = is_valid_date(query)
        if date_format:
            # Parse the input date string into a datetime object
                input_date = datetime.datetime.strptime(query, date_format)

            # Convert the datetime object into the desired ISO format (2023-04-27T19:06:00)
                query = input_date.strftime("%Y-%m-%dT%H:%M:%S")
        if index_name in ["Central_bulk_change", "Central_optimization","sim_management_bulk_change_request", "Comm_Plans", "IMEI_Master_Table","e911customers","partner_creation"]:
            filter.pop('tenant_id', None)
        print("Combined filters", filter)
        if index_name in ['Inventory', 'inventory_export', 'usage_by_line_report2']:
            print("adding service_provider_is_active filter")
            filter['service_provider_is_active'] = True
            # filter['tenant_is_active'] = True
        elif index_name == "sim_order_form":
            # Add company filter for sim_order_form
            filter["company"] = tenant_name
        elif index_name in ["email_audit", "email_templates"]:
            filter["partner_name"] = tenant_name
        logging.info(f"Combined filters search filters are -- {filter}")

        
        DATE_FORMAT = "%m/%d/%Y"
        updated_filters = {}
        for key,value in filter.items():
            field_type = index_mapping[key]
            logging.info(f"key - {key} and field_type - {field_type}")
            if isinstance(value, list) and len(value) > 500 and field_type == 'date':
                empty_present = False

                if isinstance(value, list):
                    empty_present = any(v == '' for v in value)
                elif isinstance(value, str):
                    empty_present = value.strip() == ''

                if empty_present:
                    logging.info(f"Empty value detected for field: {key}")

                parsed_dates = [
                    datetime.datetime.strptime(v, DATE_FORMAT)
                    for v in value
                    if isinstance(v, str) and v.strip() != ''
                ]
                min_date = min(parsed_dates).strftime("%Y-%m-%d")
                max_date = max(parsed_dates).strftime("%Y-%m-%d")
                logging.info(f"date range more than 1024 so taking range from {min_date} to {max_date}")
                if not empty_present:
                    updated_filters[key] = [f"{min_date}:{max_date}"]
                else:
                    updated_filters[key] = {
                        "range": f"{min_date}:{max_date}",
                        "include_empty": empty_present
                    }
            else:
                updated_filters[key] = value
        
        filter = updated_filters
        logging.info("final filters for elasticsearch %s", filter)
            
        combine_results,combine_total_rows,search_body = combined_search_data(filter, query,columns,index_list, start,end, page_flag, db_name, col_sort,index_name,tenant_name,user_data['role'],is_redirected)
    whole_sources = []
    combine_sources = []
    advanced_sources = []
    raw_advanced_sources = []
    raw_whole_sources = []
    raw_combine_sources = []
    total = advanced_total_rows + whole_total_rows + combine_total_rows
    
    if page_flag == "Nopagination":
        # Extract `_source` directly from the list of results
        # raw_advanced_sources = []
        # print("search --", search)
        if search in ["advanced_pro","advanced"]:
            for item in advanced_results:
                # print("item", item)
                # Ensure we handle cases where _source or _id may not exist
                source = item.get('_source', {})
                # print("source", source)
                source_id = item.get('id', item.get('_id'))  # Fallback to `_id` if `id` is not in `_source`
                # print("source_id", source_id)
                if source_id:
                    source['id'] = source_id  # Add `id` into the source dictionary
                    raw_advanced_sources.append(source)
                else:
                    print(f"Skipping source without 'id': {item}")
            advanced_sources = process_hits(
                advanced_results,
                dollar_fields,
                tenant_time_zone,
                index_name,
                db_name,
                True
            ) if raw_advanced_sources else []
        
        elif search == "whole":
            # print("total ---", total)
            # print("whole --", type(whole_results))
            if isinstance(whole_results, dict) and 'hits' in whole_results and 'hits' in whole_results['hits']:
                whole_hits = whole_results['hits']['hits']
            elif isinstance(whole_results, list):
                # If it's a list, assign it directly
                whole_hits = whole_results
            else:
                print("Invalid response format for whole_results:", whole_results)
                whole_hits = []

            for item in whole_hits:  # Iterate over the actual hits
                # print("item", item)
                # Ensure we handle cases where _source or _id may not exist
                source = item.get('_source', {})
                # print("source", source)
                source_id = item.get('id', item.get('_id'))  # Fallback to `_id` if `id` is not in `_source`
                # print("source_id", source_id)
                if source_id:
                    source['id'] = source_id  # Add `id` into the source dictionary
                    raw_whole_sources.append(source)
                else:
                    print(f"Skipping source without 'id': {item}")
            whole_sources = process_hits(
                whole_hits,
                dollar_fields,
                tenant_time_zone,
                index_name,
                db_name,
                True
            ) if raw_whole_sources else []
            # print("whole_sources ---", whole_sources)
            # print("raw_whole_sources ---", raw_whole_sources)
        elif search == "combined":
            # print("total ---", total)
            # print("whole --", whole_results)
            if isinstance(combine_results, dict) and 'hits' in combine_results and 'hits' in combine_results['hits']:
                combine_hits = combine_results['hits']['hits']
            elif isinstance(combine_results, list):
                # If it's a list, assign it directly
                combine_hits = combine_results
            else:
                print("Invalid response format for combine_results:", combine_results)
                combine_hits = []
            for item in combine_hits:
                # print("item", item)
                # Ensure we handle cases where _source or _id may not exist
                source = item.get('_source', {})
                # print("source", source)
                source_id = item.get('id', item.get('_id'))  # Fallback to `_id` if `id` is not in `_source`
                # print("source_id", source_id)
                if source_id:
                    source['id'] = source_id  # Add `id` into the source dictionary
                    raw_combine_sources.append(source)
                else:
                    print(f"Skipping source without 'id': {item}")
            combine_sources = process_hits(
                combine_hits,
                dollar_fields,
                tenant_time_zone,
                index_name,
                db_name,
                True
            ) if raw_combine_sources else []
    else:
        # In case it's not "Nopagination", advanced_results should be in a `hits`-like format
        if search in ["advanced","advanced_pro"]:
            if isinstance(advanced_results, dict):  # Ensure advanced_results is a dictionary
                advanced_sources = process_hits(
                    advanced_results.get('hits', {}).get('hits', []),
                    dollar_fields,
                    tenant_time_zone,
                    index_name,
                    db_name
                )
            elif isinstance(advanced_results, list):  # Handle case where advanced_results is a list
                advanced_sources = process_hits(
                    advanced_results,
                    dollar_fields,
                    tenant_time_zone,
                    index_name,
                    db_name
                )
        elif search == "whole":
        # Handle both list and dictionary formats for `whole_results`
            if isinstance(whole_results, dict):
                hits = whole_results.get('hits', {}).get('hits', [])
            elif isinstance(whole_results, list):
                hits = whole_results
            else:
                print("Invalid response format for whole_results:", whole_results)
                hits = []

            whole_sources = process_hits(
                hits,
                dollar_fields,
                tenant_time_zone,
                index_name,
                db_name
            ) if hits else []
        elif search == 'combined':
            if isinstance(combine_results, dict):
                hits = combine_results.get('hits', {}).get('hits', [])
            elif isinstance(combine_results, list):
                hits = combine_results
            else:
                print("Invalid response format for combined_results:", whole_results)
                hits = []

            combine_sources = process_hits(
                hits,
                dollar_fields,
                tenant_time_zone,
                index_name,
                db_name
            ) if hits else []
    combined_sources = whole_sources + advanced_sources + combine_sources
    # print("combined_sources --------", combined_sources)
    # print("combined_sources ----", len(combined_sources))
    # combined_sources = whole_sources + advanced_sources
    t2 = time.time()
    unique_sources = {}
    for source in combined_sources:
        # print("source", source)
        if 'id' in source:  
            unique_sources[source['id']] = source
        else:
            print(f"Skipping source without -- 'id': {source}")
    final_sources = list(unique_sources.values())

    summary = {}
    id = []
    if index_name in ["Product Level Tax Mapping","AR Aging Report","Export FCC","Billing Report w/_City_County_Country","Transaction Analysis Report","Payment Details Report","Export Variance Billing","Billing report by day with OCC Report"]:
        summary = add_summary(search_body,final_sources,index_name,index_list,False)
    elif index_name in ['Reversals','Billing and Collections Bill','Unposted']:
        id = add_summary(search_body, final_sources, index_name, index_list, True)
    if index_name == "Charge Overview":
        final_sources = split_by_category(final_sources)

    if final_sources:    
        search_result = {
            "flag": True,
            "data": {
                "table": final_sources
            },
            "pages": {
                "start": start,  
                "end": end,  
                "total": total 
            },
            "summary": summary.get("summary", {}),
            "search_ids": id
        }
    else:
        total_rows=0
        search_result = {
            "flag": True,
            "data": {
                "table": final_sources
            },
            "pages": {
                "start": start,
                "end": end,
                "total": total
            },
            "summary": summary.get("summary", {}),
            "search_ids": id
        }
    # print("search_result", search_result)
    end_time = time.time()  # End timer
    before_search_time = t1 - start_time
    search_time = t2 - t1
    elapsed_time = end_time - start_time  
    print(f"before_search_time: {before_search_time:.2f} seconds")
    print(f"search_time: {search_time:.2f} seconds")
    print(f"Total Execution Time: {elapsed_time:.2f} seconds")
    print(f"Length of records got in search {len(final_sources)}")
    import sys
    print("Response size:", sys.getsizeof(json.dumps(search_result)))
    # print("search_result", search_result)
    return search_result

def split_by_category(final_sources):
    result = {
        "charge_overview_account_charges": [],
        "charge_overview_account_credits": [],
        "charge_overview_recurring_charges": []
    }

    for item in final_sources:
        category = item.get("category")

        if category == "Credit":
            result["charge_overview_account_credits"].append(item)
        elif category == "MRC":
            result["charge_overview_recurring_charges"].append(item)
        else:
            result["charge_overview_account_charges"].append(item)

    return result


def add_summary(search_body,data,index_name,index_list,fetch_dropdown_flag):
    # if not search_body or 'query' not in search_body:
    #     return {"summary": {}}
    summary_totals = {}
    if index_name == "AR Aging Report":
        columns_to_sum = ["current", "0-30", "31-60", "61-90", "91-120", "120+", "total"]
    elif index_name == 'Export FCC':
        columns_to_sum = ["subscription_count"]
    elif index_name == 'Billing Report w/_City_County_Country':
        columns_to_sum = ["amount_due","mrc","nrc","network_access_fee","cost_recovery_fee","taxes","total","payments","account_balance"]
    elif index_name == 'Transaction Analysis Report':
        columns_to_sum = ["amount"]
    elif index_name == 'Payment Details Report':
        columns_to_sum = ["amount"]
    elif index_name == 'Export Variance Billing':
        columns_to_sum = ["prev_mrc","mrc","diff_mrc","prev_nrc_usage","nrc_usage","diff_nrc_usage","prev_nrc","nrc","diff_nrc"]
    elif index_name == 'Billing report by day with OCC Report':
        columns_to_sum = ["total_mrc_billed","total_nrc_billed","total_network_access_tax_billed","total_admin_recovery_tax_billed","total_other_tax_billed","total_payments","total_billed_amount"]
    elif index_name == 'Total MRC for Sales Person: Catapult':
        columns_to_sum = ["mrc","usage"]
    elif index_name == 'Product Level Tax Mapping':
        columns_to_sum = ["product_rate","products_tax","total_amount"]
    
    elif fetch_dropdown_flag:
        if isinstance(index_name, list):
            columns_to_sum = index_name
        elif index_name in ['Reversals','Billing and Collections Bill','Unposted']:
            index_name = 'id'
            columns_to_sum = [index_name]
        else:
            columns_to_sum = [index_name]

    start_time = time.time()
    all_values = {col: [] for col in columns_to_sum}

    scroll_query = {
        "query": search_body["query"],  # Copy filters/must/terms for exact scope match
        "size": 1000,  # Batch size for scroll; adjust based on doc size
        "_source": columns_to_sum  # Fetch only needed fields to reduce payload
    }

    try:
        # Initial search with scroll
        response = es.search(index=index_list, body=scroll_query, scroll='2m')  # 2m scroll timeout
        scroll_id = response.get('_scroll_id')
        total_hits = response['hits']['total']['value']
        logging.info(f"Fetching {total_hits} docs for exact sum in {index_name}")
        
        # Scroll through all hits
        while True:
            hits = response['hits']['hits']
            if not hits:
                break
            
            for hit in hits:
                source = hit.get('_source', {})
                for col in columns_to_sum:
                    val = source.get(col)
                    if val is not None:  # Handle nulls
                        # Use str() to capture exact stored value (avoids float conversion)
                        if col != 'id':
                            all_values[col].append(Decimal(str(val)))
                        else:
                            all_values[col].append(int(val))
            
            # Next scroll
            response = es.scroll(scroll_id=scroll_id, scroll='2m')
        
        # Clear scroll
        es.clear_scroll(scroll_id=scroll_id)

        if fetch_dropdown_flag:
            return all_values.get(index_name, [])
        
        # Compute exact sums
        summary_totals = {}
        for col in columns_to_sum:
            if all_values[col]:
                col_sum = sum(all_values[col])
                exact_total = col_sum.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                summary_totals[col] = float(exact_total)
                logging.info(f"Exact sum for {col}: {exact_total}")
            else:
                summary_totals[col] = 0.0
        
        elapsed = time.time() - start_time
        logging.info(f"Exact sum complete for {index_name}: {elapsed:.2f}s ({total_hits} docs)")
        return {"summary": summary_totals}
        
    except Exception as e:
        # Log error (adapt to your logging setup)
        print(f"Error in add_summary for {index_name}: {e}")
        return {"summary": {}}


def fetch_dropdown_old(data):
    try:
        column_name=data.get("drop_down",None)
        table=data.get("table",None)
        flag=data.get("flag",None)
        db_name=data.get("db_name",None)
        database = DB(db_name, **get_db_config(db_name))

        table_query = f"SELECT search_tables, index_search_type FROM open_search_index WHERE search_module='{table}'"
        table_data=database.execute_query(table_query, True)
        index_name = table_data["search_tables"].tolist()[0]
        # print("column name",column_name)
        table_name=table_data[0][0]

        if  flag == "status_history":
            iccid=data.get("iccid",None)
            iccid=iccid[0]
            query = f"SELECT DISTINCT {column_name} FROM {table_name} where iccid='{iccid}' and  {column_name} IS NOT NULL"
        elif flag == "bulk_history":
            bulk_change_id=data.get("bulk_change_id",None)
            bulk_change_id=bulk_change_id
            query = f"SELECT DISTINCT {column_name} FROM {table_name} where bulk_change_id='{bulk_change_id}' and {column_name} IS NOT NULL"

        else:
            query = f"SELECT DISTINCT {column_name} FROM {table_name} WHERE {column_name} IS NOT NULL"

        # Execute the query
        cursor.execute(query)
        # Fetch all unique values and return them as a list
        unique_values = cursor.fetchall()
        col_data = []
        for value in unique_values:
            val = value[0]
            if isinstance(val, Decimal):
                col_data.append(float(val))  # Convert Decimal to float
            elif isinstance(val, bool):
                col_data.append(str(val).lower())  # Convert boolean to "true"/"false"
            elif isinstance(val, datetime):
                if column_name == "billing_cycle_end_date":
                    formatted_date = (val - pd.Timedelta(days=1)).replace(hour=23, minute=59, second=59) \
                        if val.time() == pd.Timestamp("00:00:00").time() else val
                    col_data.append(formatted_date.strftime("%m/%d/%Y %H:%M:%S"))
                else:
                    col_data.append(val.strftime("%m/%d/%Y %H:%M:%S"))
            else:
                col_data.append(val)

        return {"flag": "true" , column_name:col_data}

    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        # Close the cursor and connection
        cursor.close()
        conn.close()

def convert_to_opensearch_date(date_value):
    """
    Converts a date value to OpenSearch's expected date format (YYYY-MM-DDTHH:mm:ss).
    This handles both string and datetime inputs.
    """
    if isinstance(date_value, str):
        try:
            # Try to parse it to a datetime object first
            datetime_obj = datetime.datetime.strptime(date_value, '%m/%d/%Y')
            return datetime_obj.strftime('%Y-%m-%d')
        except ValueError:
            # If it cannot be parsed, return as is or handle it accordingly
            return date_value
    elif isinstance(date_value, datetime):
        # If it's already a datetime object, format it directly
        return date_value.strftime('%Y-%m-%d')
    return date_value

def convert_timestamp_to_date(value):
    try:
        if isinstance(value, (int, float)) and len(str(int(value))) == 13: 
            human_readable_date = datetime.datetime.fromtimestamp(value / 1000, tz=datetime.timezone.utc).strftime('%m/%d/%Y')
            return human_readable_date
        elif isinstance(value, str):
            # If the value is already a date string (ISO format), keep it as is
            return value
        else:
            # If it's not a timestamp, return it as is
            return value
    except Exception as e:
        print(f"Error converting timestamp {value}: {e}")
        return value

def normalize_tenant_database(tenant_database: str) -> str:
    """
    Normalizes tenant database names by removing '_billing_platform'
    while preserving environment suffixes like _beta, _uat, _prod.
    """
    if not tenant_database:
        return tenant_database

    return tenant_database.replace("_billing_platform", "")

def db_config_maker(user, db_config_making, tenant_database, tenant_name, role_name, index_name, user_first_last_name):
    common_utils_database = DB('common_utils', **get_db_config("common_utils"))
    database = DB(tenant_database, **get_db_config(tenant_database))
    if 'billing_platform' in tenant_database:
        tenant_database = normalize_tenant_database(tenant_database)
    agent_data = {}
    logging.info(f"role_name={role_name}, user={user}")
    logging.info(f"tenant_database={tenant_database}, tenant_name={tenant_name}")

    # Connect to common_utils to fetch tenant info
    
    tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
    tenant_id = int(tenant_data["id"].to_list()[0])
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    logging.info(f"tenant_id={tenant_id}, parent_tenant_id={parent_tenant_id}")
    
    try:
        query = f"""
            SELECT tenant_role,tenant_id
            FROM user_module_tenant_mapping
            WHERE user_name='{user}' AND tenant_id={tenant_id}
        """
        tenant_df = common_utils_database.execute_query(query, True)
        logging.info(f"tenant_role_name={tenant_df}")
        if not tenant_df.empty:
            tenant_role_name = tenant_df["tenant_role"].iloc[0]
            tenant_identifier = tenant_df["tenant_id"].iloc[0]
            role_name = tenant_role_name
            if role_name != 'Super Admin' and tenant_identifier:
                tenant_id = int(tenant_identifier)
        else:
            logging.info(f"No roles found for user {user} in tenant {tenant_id}")
    except Exception as e:
        logging.info(f"Role name not found in user_module_tenant_mapping {e}")
    logging.info(f"role_tenant_name={role_name}")
    # Bypass filtering for Super Admin or Partner Admin
    if role_name in ('Super Admin', 'Partner Admin'):
        logging.info("Bypassing filtering for Super Admin or Partner Admin")
        if tenant_name in ["Altaworx Test", "Altaworx"]:
            tenant_id = 1
        agent_data["tenant_id"] = tenant_id
        if index_name in ['partner_users','customer_groups','e911customers','partner_creation']:
            agent_data.pop('tenant_id', None)
        return agent_data
    elif role_name != 'Super Admin' and index_name == 'customer_groups':
        if not parent_tenant_id:
            if tenant_name in ["Altaworx Test", "Altaworx"]:
                tenant_id = 1
            agent_data["tenant_id"] = tenant_id
            return agent_data

        query = f"""
            SELECT customers, service_provider, customer_group
            FROM user_module_tenant_mapping
            WHERE user_name='{user}' AND tenant_id={tenant_id}
        """
        filters = common_utils_database.execute_query(query, True)
        try:
            customer_group = filters["customer_group"].to_list()[0]
        except Exception:
            customer_group = None


        created_customer_groups_query = f"""
            SELECT name AS customer_group
            FROM customergroups
            WHERE created_by = '{user_first_last_name}'
        """
        try:
            created_customer_groups = database.execute_query(created_customer_groups_query, True)['customer_group'].to_list()
        except Exception:
            created_customer_groups = None
        
        if not created_customer_groups:
            created_customer_groups = None
        

        if customer_group is not None:
            valid_names = []

            # Add single customer_group
            if customer_group:
                valid_names.append(customer_group)

            # Extend list of created groups (if exists)
            if created_customer_groups:
                valid_names.extend(created_customer_groups)

            agent_data.update({
                "name": valid_names
            })
        else:
            agent_data.update({
                "name": customer_group
            })

        if index_name in ['partner_users','customer_groups','e911customers','partner_creation']:
            agent_data.pop('tenant_id', None)
        return agent_data

    

    # For Only User role (partner admin level)
    if parent_tenant_id and role_name == 'Only User':
        try:
            query = f"""
                SELECT customers, service_provider, customer_names, rate_plan_name, feature_codes, billing_account_number
                FROM tenant_based_partner_admin_filters
                WHERE tenant_id={tenant_id}
            """
            df = common_utils_database.execute_query(query, True)

            def extract_json(col): return set(json.loads(col)) if col else set()

            merged_customers = set()
            merged_service_provider = set()
            merged_rate_plan_name = set()
            merged_feature_codes = set()
            merged_billing_account_number = set()

            for _, row in df.iterrows():
                merged_customers |= extract_json(row.get('customers', '[]'))
                merged_customers |= extract_json(row.get('customer_names', '[]'))
                merged_service_provider |= extract_json(row.get('service_provider', '[]'))
                merged_rate_plan_name |= extract_json(row.get('rate_plan_name', '[]'))
                merged_feature_codes |= extract_json(row.get('feature_codes', '[]'))
                if row.get('billing_account_number'):
                    merged_billing_account_number.add(str(row['billing_account_number']))

            agent_data.update({
                "customer": list(merged_customers) or None,
                "service_provider": list(merged_service_provider) or None,
                "customer_rate_plan_name": list(merged_rate_plan_name) if index_name not in ["Inventory", "inventory_export"] else None,
                "feature_codes": list(merged_feature_codes) or None,
                "billing_account_number": list(merged_billing_account_number) if merged_billing_account_number else None
            })
        except Exception as e:
            logging.exception("Error in partner admin filter logic", e)

    else:
        # Agent level filters from user_module_tenant_mapping
        query = f"""
            SELECT customers, service_provider, customer_group
            FROM user_module_tenant_mapping
            WHERE user_name='{user}' AND tenant_id={tenant_id}
        """
        filters = common_utils_database.execute_query(query, True)

        try:
            customer_group = filters["customer_group"].to_list()[0]
        except Exception:
            customer_group = None

        customer_names = None
        customer_rate_plan_name = None
        billing_account_number = None
        feature_codes = None

        # If customer group exists, fetch from customergroups
        if customer_group:
            cg_data = database.get_data(
                "customergroups",
                {"name": customer_group},
                ["customer_names", "rate_plan_name", "billing_account_number", "feature_codes"]
            )

            if not cg_data.empty:
                try:
                    customer_rate_plan_name = tuple(json.loads(cg_data["rate_plan_name"].to_list()[0]))
                except Exception as e:
                    logging.exception("Error extracting rate_plan_name", e)

                try:
                    customer_names = tuple(json.loads(cg_data["customer_names"].to_list()[0]))
                except Exception as e:
                    logging.exception("Error extracting customer_names", e)

                try:
                    billing_data = cg_data["billing_account_number"].to_list()[0]
                    billing_account_number = (billing_data,) if billing_data else None
                except Exception as e:
                    logging.exception("Error extracting billing_account_number", e)

                try:
                    feature_data = cg_data["feature_codes"].to_list()[0]
                    if isinstance(feature_data, str):
                        feature_codes = tuple(json.loads(feature_data))
                    elif isinstance(feature_data, list):
                        feature_codes = tuple(feature_data)
                    else:
                        feature_codes = (feature_data,) if feature_data else None
                except Exception as e:
                    logging.exception("Error extracting feature_codes", e)

        # Customers from mapping or customer group
        if customer_names is None:
            try:
                customer = tuple(json.loads(filters["customers"].to_list()[0]))
            except Exception:
                customer = None
        else:
            customer = customer_names

        # Merge customers created by this user
        try:
            customers_query = f"""
                SELECT customer_name 
                FROM customers 
                WHERE tenant_id={tenant_id} AND is_active=TRUE AND created_by='{user}'
            """
            customers_df = database.execute_query(customers_query, True)
            if not customers_df.empty:
                existing_customers = customers_df['customer_name'].to_list()
                customer_set = set(customer or [])
                customer_set.update(existing_customers)
                customer = tuple(customer_set)
        except Exception as e:
            logging.exception(f"Error fetching user-created customers for {user}", e)

        # Service provider & IDs
        try:
            service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
            if len(service_provider) == 1:
                query = f"SELECT id FROM serviceprovider WHERE service_provider_name='{service_provider[0]}'"
            else:
                formatted_values = "', '".join(service_provider)
                query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
            service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
        except Exception:
            service_provider, service_provider_id = None, None

        # Merge rate plans created by user
        try:
            customer_rate_plan_query = f"""
                SELECT rate_plan_name 
                FROM customerrateplan 
                WHERE tenant_id={tenant_id} AND is_active=TRUE AND created_by='{user}'
            """
            customer_rate_plan_df = database.execute_query(customer_rate_plan_query, True)
            if not customer_rate_plan_df.empty:
                existing_rate_plans = customer_rate_plan_df['rate_plan_name'].to_list()
                rate_plan_set = set(customer_rate_plan_name or [])
                rate_plan_set.update(existing_rate_plans)
                customer_rate_plan_name = tuple(rate_plan_set)
        except Exception as e:
            logging.exception(f"Error fetching user-created rate plans for {user}", e)

        
        
        if role_name == 'Agent Partner Admin' and parent_tenant_id:
            agent_data.update({
                "customer": None,
                "service_provider": list(service_provider) if service_provider else None,
                "service_provider_id": list(service_provider_id) if service_provider_id else None,
                "customer_rate_plan_name": None,
                "feature_codes": None
                # "billing_account_number": list(billing_account_number) if billing_account_number else None
            })

        else:
            agent_data.update({
                "customer": list(customer) if customer else None,
                "service_provider": list(service_provider) if service_provider else None,
                "service_provider_id": list(service_provider_id) if service_provider_id else None,
                "customer_rate_plan_name": (
                    list(customer_rate_plan_name) if customer_rate_plan_name and index_name in ["Customer_Rate_Plan", "Customer_Rate_Plan_Report"] 
                    else None
                ),
                "feature_codes": list(feature_codes) if feature_codes else None,
                # "billing_account_number": list(billing_account_number) if billing_account_number else None
            })

    # Override tenant_id for Altaworx Test
    if tenant_name == "Altaworx Test":
        tenant_id = 1

    agent_data["tenant_id"] = tenant_id
    print("### agent_data :", agent_data)
    return agent_data


def add_customer_exists_filters(search_body, index_name, tenant_name, db_config):
    if index_name in ["inventory_export", "Inventory"]:
        common_utils_database = DB('common_utils', **get_db_config("common_utils"))
        tenant_data = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
        tenant_id = tenant_data["id"].to_list()[0]
        parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
        print("parent_tenant_id $$$$$---$$$$$$", parent_tenant_id)

        if parent_tenant_id:
            must_filters = [
                {"exists": {"field": "customer_id"}}
            ]

            if "filter" in search_body["query"]["bool"]:
                search_body["query"]["bool"]["filter"].extend(must_filters)
            else:
                search_body["query"]["bool"]["filter"] = must_filters
    elif index_name == "IMEI_Master_Table":
        # Add condition: deleted_date is null
        print("Adding filter: deleted_date is null for IMEI_Master_Table")
        if "must_not" not in search_body["query"]["bool"]:
            search_body["query"]["bool"]["must_not"] = []
        search_body["query"]["bool"]["must_not"].append({
            "exists": {"field": "deleted_date"}
        })

    return search_body

def fetching_usage_by_line_table(tenant_name, db_name, username, index_name):
    """ Fetching usage_by_line iews based on the different role and manin tenant and sub tenant"""
    # table = "usage_by_line_report" 
    if index_name in ["usage_by_line_report", "customer_rate_pool_usage_report"]:
        table = index_name
    logging.info(f"### table name -- {table}")
    database = DB("common_utils", **get_db_config("common_utils"))

    # Fetch tenant_id and parent_tenant_id
    tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
    if tenant_data.empty:
        print(f"No tenant found for tenant_name: {tenant_name}")
        return index_name

    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

    print("Tenant ID:", tenant_id, "| Parent Tenant ID:", parent_tenant_id)

    # Fetch user role
    user_info = database.get_data("users", {"username": username}, ["role"])
    if user_info.empty:
        print(f"No user found for username: {username}")
        role = None
    else:
        role = user_info["role"].to_list()[0]
        print("User Role:", role)

    if parent_tenant_id is not None:
        # It's a subtenant — check the override table
        query = f"SELECT optino_cross_providercustomer_optimization FROM public.optimization_setting_tenant_override WHERE tenant_id = '{tenant_id}' LIMIT 1"

    else:
        # It's a main tenant — check the main table
        # if tenant_id == 212:
        #     tenant_id = 1
        query = f"SELECT optino_cross_providercustomer_optimization FROM public.optimization_setting WHERE tenant_id = '{tenant_id}' LIMIT 1"

    try:
        # params = {"tenant_id": tenant_id}
        database = DB(db_name, **get_db_config(db_name))
        optimization_data = database.execute_query(query, True)
        logging.info("### optimization_data ************* %s",optimization_data["optino_cross_providercustomer_optimization"].tolist()[0])
        if optimization_data["optino_cross_providercustomer_optimization"].tolist()[0]:
            if table == "usage_by_line_report":
                return "usp_report_customer_usage_by_line"
            else:
                return "get_crossprovider_customerpool_aggregated_usage"
        else:
            return index_name
    except Exception as e:
        print(f"An error occurred while fetching optimization data: {e}")


def get_index_mappings(index_name):
    """
    Fetch the mapping for the specified OpenSearch index.
    :param index_name: Name of the OpenSearch index
    :return: List of column names in the index
    """
    try:
        mappings = es.indices.get_mapping(index=index_name)
        properties = mappings[index_name]['mappings']['properties']
        return list(properties.keys())
    except Exception as e:
        print(f"Failed to fetch mappings for index {index_name}: {e}")
        return []


def get_index_mappings_with_types(index_name):
    """
    Fetch the mapping for the specified OpenSearch index and return field types.
    :param index_name: Name of the OpenSearch index
    :return: Dictionary with column names as keys and their types as values
    """
    try:
        mappings = es.indices.get_mapping(index=index_name)
        properties = mappings[index_name]['mappings']['properties']
        field_types = {field: details['type'] for field, details in properties.items() if 'type' in details}
        return field_types
    except Exception as e:
        print(f"Failed to fetch mappings for index {index_name}: {e}")
        return {}

def extract_start_date(date_range):
    try:
        # Split the string and take the first date
        start_date = date_range.split(' - ')[0]
        # Convert the string to a datetime object
        return datetime.datetime.strptime(start_date, '%m/%d/%Y')
    except (ValueError, IndexError):
        # Return None for invalid entries
        return None

def round_to_2_decimal_places(value):
    # Convert to Decimal to preserve precision and avoid float rounding issues
    dec = Decimal(str(value)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    return f"{dec:.2f}" 

def sort_mixed(values):
    def convert(val):
        try:
            # Try integer conversion first
            return int(val)
        except ValueError:
            try:
                # Try float conversion
                return float(val)
            except ValueError:
                # Keep as string
                return val

    return sorted(values, key=convert)

def fetch_distinct_values_with_composite(index_name, column_name, query_filters,table, tenant_name, batch_size=10000):
    """
    Fetch distinct values for a specified column using composite aggregation with pagination.
    :param index_name: Name of the OpenSearch index
    :param column_name: Name of the column to fetch distinct values for
    :param query_filters: List of filters to apply to the query
    :param tenant_time_zone: Tenant time zone for date conversion
    :param batch_size: Number of buckets to fetch per composite aggregation query
    :return: Dictionary with column name as key and processed list of distinct values as value
    """
    distinct_values = []
    after_key = None  # Initialize the after_key variable for pagination

    try:
        while True:
            # Build the composite aggregation query
            agg_query = build_composite_aggregation_query(index_name, column_name, query_filters,table, tenant_name, after_key, batch_size)
            logging.info(f"### agg_query -- {agg_query}")
            # Execute the query
            response = es.search(index=index_name, body=agg_query)
            # print("response --", response)
            # Extract buckets from the response
            buckets = response["aggregations"]["composite_values"]["buckets"]
            distinct_values.extend([bucket["key"][column_name] for bucket in buckets])

            # Check if there is more data to paginate through
            after_key = response["aggregations"]["composite_values"].get("after_key")
            if not after_key:
                break  # Exit the loop if there are no more results

        # Fetch index mapping to get the field type for the specified column
        index_mapping = get_index_mappings_with_types(index_name)
        field_type = index_mapping.get(column_name, None)

        # Convert values based on their type
        formatted_values = []
        float_pattern = re.compile(r"^-?\d*\.\d+$")
        for value in distinct_values:
            if field_type == 'date':
                formatted_values.append(convert_timestamp_to_date(value))
                # print(f"fetch_dropname date {value}")
            elif isinstance(value, (float, Decimal)) or (isinstance(value,str) and column_name != "account_number" and float_pattern.match(value.strip())):
                # Convert any numeric value to float, ensuring no scientific notation
                decimal_value = Decimal(value)
                formatted_values.append(f"{decimal_value:.2f}")
                # print(f"fetch_dropname decimal {value}")
            else:
                # print(f"fetch_dropname isn't decimal {value}")
                formatted_values.append(value)

        distinct_values = formatted_values

        return {"flag": "true", column_name: distinct_values}

    except Exception as e:
        print(f"An error occurred while fetching distinct values for {column_name}: {e}")
        return {"flag": "true", column_name: []}

def is_sub_tenant(tenant_name):
    """
    Checks if the given tenant is a sub-tenant based on parent_tenant_id.
    Returns True if it's a sub-tenant, False otherwise.
    """
    try:
        logging.info(f"### Checking sub-tenant status for tenant: {tenant_name}")
        # Connect to common_utils DB
        database = DB("common_utils", **get_db_config("common_utils"))
        # Fetch tenant_id and parent_tenant_id
        tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
        if tenant_data.empty:
            logging.info(f"### No tenant found for tenant_name: {tenant_name}")
            return False
        tenant_id = tenant_data["id"].to_list()[0]
        parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
        logging.info("Tenant ID: %s | Parent Tenant ID: %s", tenant_id, parent_tenant_id)
        # A tenant is a sub-tenant if parent_tenant_id is not None
        return parent_tenant_id is not None
    except Exception as e:
        logging.info(f"Error while checking sub-tenant for {tenant_name}: {e}")
        return False


def build_composite_aggregation_query(index_name, column_name, query_filters,table,tenant_name, after_key=None, batch_size=10000):
    """
    Build a composite aggregation query with pagination support using after_key.
    """
    # Get the field type from the index mapping
    index_mapping = get_index_mappings_with_types(index_name)
    logging.info(f"index_name -- {index_name}")

    if column_name not in index_mapping:
        raise ValueError(f"Column {column_name} not found in index mappings")

    field_type = index_mapping[column_name]

    # Dynamically build the aggregation field based on type
    if field_type == "text":

        field_name = f"{column_name}.keyword"

    elif field_type in ["integer", "float", "double", "long"]:

        field_name = column_name  # Use field directly for numeric types

    elif field_type == "boolean":

        field_name = column_name  # Use boolean field directly

    elif field_type == "date":

        field_name = column_name  # Use date field directly

    else:

        field_name = column_name  # Use the field directly for other types

    # print("query_filters -----", query_filters)
    updated_query_filters = []
    for filter_item in query_filters:
        if 'terms' in filter_item:
            for field_, value in filter_item['terms'].items():
                # print("%%% field -- ", field_, value)

                # Check for the field type and handle accordingly
                field_type_ = index_mapping.get(field_)
                # if not isinstance(value, list):
                #     print("check ---", value)
                #     filter_item['terms'][field_] = (
                #         value if isinstance(value, bool) else (value.lower() == "true")
                #     )
                if not field_type_:
                    # If field does not exist in index_mapping, check for .keyword for text fields
                    if field_.endswith('.keyword'):
                        field_type_ = 'text'
                    else:
                        field_type_ = index_mapping.get(f"{field_}.keyword", None)

                if field_type_ == "date":
                    # print("%%% field, field_type -- ", field_, field_type_)
                    # Convert the date values to OpenSearch date format
                    if isinstance(value, list):
                        value = [convert_to_opensearch_date(v) for v in value]
                    else:
                        value = convert_to_opensearch_date(value)
                    filter_item['terms'][field_] = value
        elif 'term' in filter_item:
            # If it's a "term" filter (single value)
            for field_, value in filter_item['term'].items():
                # print("%%% field -- ", field_)
                field_type_ = index_mapping.get(field_)
                # if not isinstance(value, list):
                #     print("check ---", value)
                #     filter_item['term'][field_] = (
                #         value if isinstance(value, bool) else (value.lower() == "true")
                #     )
                if not field_type_:
                    # If field does not exist in index_mapping, check for .keyword for text fields
                    if field_.endswith('.keyword'):
                        field_type_ = 'text'
                    else:
                        field_type_ = index_mapping.get(f"{field_}.keyword", None)

                if field_type_ == "date":
                    # print("%%% field, field_type -- ", field_, field_type_)
                    # Convert the date value to OpenSearch date format
                    filter_item['term'][field_] = convert_to_opensearch_date(value)

                if field_ in ["optimization_type", "optimization_type.keyword"]:
                    if isinstance(value, list):
                        normalized_values = []
                        for v in value:
                            if isinstance(v, str) and v.lower() in ["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling"]:
                                normalized_values.extend(["Cross Customer Pooling", "cross customer pooling", "Cross customer pooling"])
                            else:
                                normalized_values.append(v)
                        filter_item['terms'][field_] = normalized_values
        
        updated_query_filters.append(filter_item)
    if table == "action_history_report":
        current_date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        last_month_date = (datetime.datetime.utcnow() - relativedelta(months=1)).strftime("%Y-%m-%d")

        query_filters.append({
            "range": {
                "date_of_change": {
                    "gte": last_month_date,  # From April 1, 2024
                    "lte": current_date      # Up to the present date
                }
            }
        })
    if table == "Usage Details":
        query_filters.append({
            "bool": {
                "should": [
                    {
                        "range": {
                            "usage_mb": {
                                "gt": 0
                            }
                        }
                    },
                    {
                        "range": {
                            "sms_cost": {
                                "gt": 0
                            }
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        })                                    

    if table == "Active_lines_report":
        query_filters.append({
            "terms": {
                "sim_status.keyword": ["Activated", "Active", "A","ACTIVATED"]
            }
        })
        logging.info(f"## build composite aggregation query_filters--- {query_filters}")

    logging.info(f"### query filters --- {query_filters}")
    if table == "rev_assurance":
        logging.info("adding is_active_status or rev_is_active_status filters")
        # Build the base bool part of the query with must, should, minimum_should_match
        bool_query = {
            "must": query_filters,
            "should": [
                {"term": {"is_active_status": False}},
                {"term": {"rev_is_active_status": False}}
            ],
            "minimum_should_match": 1
        }
    elif table == "Customers":
        logging.info("adding rev_customer_id is null filter")
        bool_query = {
            "must": query_filters,
            "must_not": [
                {"exists": {"field": "rev_customer_id"}}
            ]
        }
    elif table == "Charge Details":
        bool_query = {
            "must": query_filters,
            "must_not": [
                {"terms": {"category.keyword": ["MRC", "Credit"]}}
            ]
        }
    elif table in ["zero_usage_report", "usp_report_customer_usage_by_line", "usage_by_line_report", "newly_activated_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("adding customer_name and customer_id is not null filters")
            bool_query = {
                "must": query_filters + [
                    {"exists": {"field": "customer_id"}},
                    {"term": {"customer_is_active": True}}
                ]
            }
        else:
            logging.info("### Skipping customer_name, customer_id is not null filter. Due to main tenant")
            bool_query = {
                "must": query_filters
            }
    elif table in ["status_history_report"]:
        if is_sub_tenant(tenant_name):
            logging.info("### customer_id is not null filters")
            bool_query = {
                "must": query_filters + [
                    {"exists": {"field": "customer_id"}}
                ]
            }
        else:
            logging.info("### Skipping customer_id is not null filter. Due to main tenant")
            bool_query = {
                "must": query_filters
            }
    else:
        # For other tables, bool only has must filters
        bool_query = {
            "must": query_filters
        }
    logging.info(f"### Build query filters --- {query_filters}")

    if table in ['Billing Report w/_City_County_Country','AR Aging Report','Export Variance Billing','Billing report by day with OCC Report','Total MRC for Sales Person: Catapult']:
        bill_reverse_month_filter = {
            "script": {
                "script": {
                    "lang": "painless",
                    "source": """
                        if (doc['bill_reversed_date'].size() == 0) {
                            return true;
                        }

                        ZonedDateTime created = doc['created_date'].value;
                        ZonedDateTime reversed = doc['bill_reversed_date'].value;

                        return created.getYear() != reversed.getYear()
                            || created.getMonthValue() != reversed.getMonthValue();
                    """
                }
            }
        }
        logging.info("adding bill_reversed_date month mismatch filter")
        query_filters.append(bill_reverse_month_filter)

    # Build the composite aggregation query
    query = {
        "size": 0,  # We only need aggregation results
        "query": {
            "bool": bool_query
        },
        "aggs": {
            "composite_values": {
                "composite": {
                    "sources": [
                        {
                            column_name: {
                                "terms": {
                                    "field": field_name
                                }
                            }
                        }
                    ],
                    "size": batch_size  # Number of buckets to retrieve per request
                }
            }
        }
    }

    # Add after_key for pagination
    if after_key:
        query["aggs"]["composite_values"]["composite"]["after"] = after_key
    query = add_customer_exists_filters(query, table, tenant_name, db_config)
    return query

def isfloat(value):
    try:
        float(value)
        return True
    except (ValueError, TypeError):
        return False

def get_rate_plans_by_customer_group(customer_group_name, db_name):
    """
    Fetch rate_plan_name(s) for a given customer_group_name.
    Always returns a list (can be empty).
    """
    logging.info("### get_rate_plans_by_customer_group called for: %s", customer_group_name)

    if not customer_group_name:
        logging.info("### No customer_group_name provided")
        return []

    try:
        group_db = DB(db_name, **get_db_config(db_name))

        query = """
            SELECT rate_plan_name
            FROM customergroups
            WHERE name = %s
        """

        # result = group_db.execute_query(query, True, (customer_group_name,))
        result = group_db.execute_query(query, True, params=[customer_group_name])

        if result is not None and not result.empty:
            raw_value = result["rate_plan_name"].iloc[0]

            if not raw_value:
                return []

            # If stored as JSON string
            if isinstance(raw_value, str):
                try:
                    parsed = json.loads(raw_value)
                    if isinstance(parsed, list):
                        rate_plans = parsed
                    else:
                        rate_plans = [parsed]
                except Exception:
                    rate_plans = [raw_value]
            elif isinstance(raw_value, list):
                rate_plans = raw_value
            else:
                rate_plans = [raw_value]

            logging.info("### Parsed rate plans: %s", rate_plans)
            return rate_plans

        logging.info("### No rate plans found for group: %s", customer_group_name)
        return []

    except Exception as e:
        logging.error("### Error fetching rate plans: %s", str(e))
        return []

def get_usernames(tenant_name, role):
    database = DB("common_utils", **get_db_config("common_utils"))
    tenant_id = int(get_tenant_id(tenant_name))
    logging.info("Fetching usernames for tenant: %s, role: %s", tenant_name, role)
    query = "select user_name from user_module_tenant_mapping where tenant_id = %s and tenant_role IN %s AND is_active = true"
    # print(query)
    try:
        user_data=database.execute_query(query, True, params=[tenant_id, tuple(role)])
        # print(user_data)
        if user_data is None or user_data.empty:
            logging.info("### No usernames found for tenant: %s", tenant_name)
            return []
        usernames = user_data["user_name"].tolist()
        return usernames
    except Exception as e:
        logging.error("Error fetching usernames: %s", str(e))
        return []
    

def fetch_dropdown(data):
    column_name = data.get("drop_down", None)
    table = data.get("table", None)
    flag = data.get("flag", None)
    db_name=data.get("db_name","altaworx_central")
    upload_id = data.get("upload_id", None)
    customer_group_name = data.get("customer_group_name", None)
    global es
    logging.info(f"### Fetching es {es}")
    excluded_indexes = [
        'tenant_based_banners_logs', 'tenant_based_banners',
        'partner_users', 'carrier_apis', 'amop_apis',
        'email_audit', 'email_templates', 'Central_bulk_change', 'Central_optimization', 'partner_creation'
    ]
    table_is_excluded = table in excluded_indexes
    if (es is None or current_db_name != db_name or is_excluded_flag is None or (table_is_excluded and not is_excluded_flag) or (not table_is_excluded and is_excluded_flag)):
        logging.info("Initializing OpenSearch for DB: %s", db_name)
        es = initialize_opensearch(db_name,table)
        if es is None:
            raise ValueError(f"Failed to initialize OpenSearch for {db_name}")
    else:
        logging.info(f"Using existing OpenSearch client for {db_name} (excluded_flag={is_excluded_flag})")
    cascade = data.get("cascade", {})
    toggle = data.get("toggle", None)
    tenant_name = data.get("partner", "")  
    account_number = data.get("account_number",None)
    tenant_id = data.get("tenant_id", None)
    partner_name = data.get("Selected_Partner", None)
    sub_tenant_name = data.get("sub_partner") or partner_name
    username=data.get("username",None)
    current_cycle = data.get("current_cycle", None)
    user_first_last_name = data.get("firstLastName",None)
    if not tenant_name:
        raise ValueError("Tenant name is missing.")
    tenant_time_zone = get_tenant_timezone(tenant_name)
    # print("Fetch drop down db name",db_name)
    database = DB(db_name, **get_db_config(db_name))
    if table in ["usage_by_line_report", "customer_rate_pool_usage_report"]:
        # table = resolve_usage_table(tenant_name, db_name)
        table = fetching_usage_by_line_table(tenant_name, db_name, username, table)
        # if table == "usage_by_line_report":
        #     temp_filters = cascade
        #     logging.info("### temp_filters-------- %s", temp_filters)
        #     # billing_cycle_dates = temp_filters.get("billing_cycle_end_date", [])
        #     if "billing_cycle_end_date" not in temp_filters:
        #         table = "usage_by_line_from_devices"
        #     else:
        #         logging.info("Skipping index update. since billing_cycle_end_date is present in filters.")
        logging.info("index_name-------- %s", table)
    filter_conditions=cascade
    
    if table in ["Inventory","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
        logging.info(f"### Checking tenant information for tenant_name: {tenant_name}")
        commonutils_database = DB("common_utils", **get_db_config("common_utils"))
        
        tenant_data = commonutils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
        
        if not tenant_data.empty:
            tenant_id = tenant_data["id"].to_list()[0]
            parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
            
            logging.info(f"### Tenant ID: {tenant_id} | Parent Tenant ID: {parent_tenant_id}")
            
            # Handle sub-tenant column swap if parent_tenant_id exists
            if parent_tenant_id is not None and column_name in ("carrier_rate_plan_name","carrier_rate_plan"):
                column_name = "sub_tenant_carrier_rate_plan_name"
            
            logging.info(f"### Using cascade: {cascade}")
            if "carrier_rate_plan_name" in cascade:
                cascade["sub_tenant_carrier_rate_plan_name"] = cascade.pop("carrier_rate_plan_name")
                logging.info(f"### Updated cascade for sub-tenant: {cascade}")
            elif "carrier_rate_plan" in cascade:
                cascade["sub_tenant_carrier_rate_plan_name"] = cascade.pop("carrier_rate_plan")
                logging.info(f"### Updated cascade for sub-tenant: {cascade}")

    if (
        table in ["usage_by_line_report", "usage_by_line_report2"]
        and column_name == "billing_cycle_end_date"
        and filter_conditions.keys() == {"service_provider_display_name"}
        and (service_provider_name_list := filter_conditions.get("service_provider_display_name", []))
    ):
        table = "usage_by_line_billing_period"
        filter_conditions["service_provider"] = service_provider_name_list

    table_query = f"SELECT search_tables, index_search_type FROM open_search_index WHERE search_module='{table}'"
    table_data=database.execute_query(table_query, True)
    index_name = table_data["search_tables"].tolist()[0]
    index = index_name

    
    if index in ["vw_users_tenant_roles","carrier_apis","amop_apis","email_audit","email_templates", "deployment_tenant_based_banners", "deployment_tenant_based_audit_logs", "tenant","vw_tenant_partner_addition"]:
        index_name=f"{index_name}"
    elif table in ["Central_bulk_change", "Central_optimization"]:
        index_name=f"{index_name}_central_db".lower()
    else:
        index_name=f"{index_name}_{db_name}".lower()
    print("index_name --", index_name)
    available_columns = get_index_mappings(index_name)
    customer_columns = ['customer_name']
    service_provider_column = ['service_provider', 'service_provider_name', 'service_provider_display_name', 'service_providers']
    customer_rate_plan_names=["customer_rate_plan_name","rate_plan_name","customer_rate_plan","customer_rate_plans"]
        
    query=f"select customers , service_provider, customer_group, role, first_name, last_name, tenant_role_mapping from users where username ='{username}'"
    database = DB("common_utils", **get_db_config("common_utils"))
    # filter_conditions={}
    user_data=database.execute_query(query, True)
    user = {}
    # user["role"]=user_data["role"].to_list()[0]
    user["first_name"]=user_data["first_name"].to_list()[0]
    user["last_name"]=user_data["last_name"].to_list()[0]
    user_role = user_data["role"].to_list()[0]
    logging.info(f"### user role-- {user_role}")
    tenant_role_mapping = user_data["tenant_role_mapping"].iloc[0]

    if tenant_role_mapping:
        try:
            # If it's a string → parse it
            if isinstance(tenant_role_mapping, str):
                role_mappings = json.loads(tenant_role_mapping)
            else:
                # Already list/dict
                role_mappings = tenant_role_mapping

            for item in role_mappings:
                if item.get("tenant") == tenant_name:
                    user_role = item.get("role")
                    break
        except Exception as e:
            # JSON parsing issue — fallback already set
            pass
    user["role"] = user_role
    flag1=False
    
    category_map = {"ACH": "ach", "Credit": "credit"}
    filter_conditions = {
    key: (
        [category_map.get(v, v) for v in value] if key == "category" else
        'true' if value[0] in ["True", "Yes"]
        else 'false' if value[0] in ["False", "No"]
        else " " if value[0] == "(Spaces)"
        else value
    )
    for key, value in filter_conditions.items()
    if value
    and not (
        len(value) == 1 and (
            value[0] == "(Blanks)" or (
                value[0] == "Unassigned"
                and table in ["rev_assurance_variance", "rev_assurance"]
                and key == "customer_name"
            )
        )
    )
    and (key != column_name)  # Skip this column if it's the one triggering cascade
    and key not in [
        "device_count", "total_charges", "total_charge_amount",
        "base_rate", "rate_charge_amt", "overage_rate_cost"
    ]
    }

    index_mapping = get_index_mappings_with_types(index_name)
    for key, value in filter_conditions.items():  # No need to use list() if we're not modifying the dictionary during iteration
        # Get the field type from index_mapping
        field_type = index_mapping.get(key, None)
        
        # Check if the field is of type int or float and if the filter condition is a list
        if field_type in ['long', 'float', 'date'] and isinstance(value, list):
            # Remove the "(Blanks)" value from the list if it exists
            filter_conditions[key] = [v for v in value if v != "(Blanks)"]

    logging.info(f"### user-- {user}, available_columns {available_columns}")
    if  "is_active" in available_columns and index not in ["carrier_apis", "amop_apis","vw_status_history_report", "vw_zero_usage_report", "vw_usage_by_line_report","customer_services","gl_code","serviceprovider","billing_report_view","ar_aging_view","vw_export_variance_billing_report"]:
        filter_conditions["is_active"] = True
        logging.info(f"######################## {toggle}")
        if table in ["action_history_report"]:
            filter_conditions.pop("is_active", None)
        elif toggle == False:
            filter_conditions["is_active"] = ["true", "false"]
    # if "is_active" in available_columns and "is_deleted" in available_columns and index == 'transaction_analysis_view':
    #     filter_conditions["is_active"] = False
    #     filter_conditions["is_deleted"] = False
    if account_number:
        if table in ['Customer Payment History','Unposted Upload Status']:
            filter_conditions['account_number'] = account_number
        elif index == 'ledger':
            filter_conditions['account'] = account_number
        elif table == 'RepostedMRC':
            service_ids = get_service_id(account_number,current_cycle, db_name)
            filter_conditions['id'] = service_ids
        else:
            id = get_customer_id(account_number,db_name)
            filter_conditions['customer_profile_id'] = int(id)
    if upload_id and table in ['Unposted Upload Data']:
        filter_conditions["upload_id"] = int(upload_id)
    if customer_group_name and table == "Filtered_Customer_Rate_Plan":
        # logging.info("### Fetching rate plans for customer group: %s", customer_group_name)
        if "rate_plan_name" not in filter_conditions:
            rate_plans = get_rate_plans_by_customer_group(customer_group_name, db_name)
            if rate_plans:
                filter_conditions["rate_plan_name"] = rate_plans
            else:
                filter_conditions["rate_plan_name"] = ""
    print("filter_conditions 1**************", filter_conditions)
    # if  "tenant_id" in available_columns and index not in ["vw_users_tenant_roles"]:
    #     filter_conditions["tenant_id"] = [tenant_id]
    if "tenant_id" in available_columns and index not in ["vw_users_tenant_roles","vw_customer_services_usage_altaworx","customer_services","gl_code","customer_groups_view", "billing_period","e911customers","vw_tenant_partner_addition"]:  
        filter_conditions["tenant_id"] = tenant_id

    if table in ['Collection Templates'] and "is_deleted" in available_columns:
        filter_conditions['is_deleted'] = False
    
    if table in ["GL Code Settings","Billing Service Providers"]:
        if table == "Billing Service Providers":
            sub_tenant_name = data.get("sub_partner", None)
        if sub_tenant_name:
            tenant_name = sub_tenant_name
        elif partner_name:
            tenant_name =  partner_name
        id = get_tenant_id(tenant_name)
        print(f"## tenant_id_from_tenant {id}")
        if table == "GL Code Settings":
            # if id == 212:  #only in UAT
            #     id = 1
            filter_conditions["sub_tenant_id"] = int(id)
        else:
            filter_conditions["tenant_id"] = int(id)
            # if id == 212:  #only in UAT
            #     filter_conditions["tenant_id"] = 1
        if 'is_active' in filter_conditions:
            var = filter_conditions['is_active']
            if isinstance(var, list):
                if var[0] == 'Inactive':
                    filter_conditions['is_active'] = False
                else:
                    filter_conditions['is_active'] = True
            else:
                if var == 'Inactive':
                    filter_conditions['is_active'] = False
                else:
                    filter_conditions['is_active'] = True
    # if table in ['Billed Through Date Report']:
    #     filter_conditions['is_active'] = True
        # filter_conditions['billed_flag'] = False

    if table in ['Unposted','Reversals']:
        if table in ['Reversals']:
            filter_conditions['reversal_flag'] = True
        else:
            filter_conditions['reversal_flag'] = False
    
    if table in ['Charge By Service','Usage Details','Charge Overview','Charge Details','Recurring Charge Details','Credit Details']:
        if data.get("bill_id", None):
            filter_conditions['applied_to_bill'] = int(data.get("bill_id", None))
        if table in ["Charge By Service","Recurring Charge Details"]:
            filter_conditions['category'] = 'MRC'
        elif table == "Credit Details":
            filter_conditions['category'] = 'Credit'
        filter_conditions.pop("is_active")
            

    logging.info(f"## filter_conditions ************** {filter_conditions}")

    if flag == "status_history" and "iccid" in available_columns:  # Custom filter for status_history flag
        iccid = data.get("iccid", None)
        if iccid:
            filter_conditions["iccid"] = [iccid[0]]

    if flag == "bulk_history" and "bulk_change_id" in available_columns:  # Custom filter for bulk_history flag
        bulk_change_id = data.get("bulk_change_id", None)
        print("bulk_change_id",bulk_change_id)
        if bulk_change_id:
            filter_conditions["bulk_change_id"] = [bulk_change_id]
    
    if table in ['rev_assurance','rev_assurance_variance']:
        filter_conditions['bp_customer'] = False

    
    for key, value in filter_conditions.items():
            # Check if the value is a list or an iterable before using len()
            if isinstance(value, list):
                if len(value) > 60000:
                    filter_conditions[key] = value[:60000]  # Slice the list to the first 60000 items
                print(f"Count of values for '{key}' : {len(filter_conditions[key])}")
            else:
                print(f"Value for '{key}' is not a list, so it cannot be sliced.")
    if user['role'] not in ('Super Admin', 'Partner Admin') and table == "Billing report by day with OCC Report":
        index_name = f"altaworx_billing_report_by_day_search_{db_name}"


    index_mapping = get_index_mappings_with_types(index_name)
    query_filters = []
    agent_flag = False
    if index not in ["email_audit","email_templates", "billing_period","vw_users_tenant_roles"]:
        print("user", user)
        agent_rel_data=db_config_maker(username, db_config,db_name, tenant_name, user['role'], table, user_first_last_name)
        print("agent_data", agent_rel_data)
        previous_filters = filter_conditions.copy()
        filter_conditions.update(agent_rel_data)
        agent_flag = True
    if index in ["email_audit", "email_templates"]:
        database = DB("common_utils", **get_db_config("common_utils"))

        tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
        if tenant_data.empty:
            raise ValueError(f"No tenant found for tenant_name: {tenant_name}")

        tenant_id = tenant_data["id"].to_list()[0]
        parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]

        if parent_tenant_id is not None:
            filter_conditions["tenant_id"] = tenant_id  # Add to filter
        else:
            filter_conditions["tenant_id"] = None
    print("filter_conditions_tej",filter_conditions)
    if table in ['Inventory', 'inventory_export', 'usage_by_line_report2']:
        print("adding service_provider_is_active filter")
        filter_conditions['service_provider_is_active'] = True
        # filter_conditions['tenant_is_active'] = True
        print("filter_conditions_tej --",filter_conditions)
    filter_conditions = {k: v for k, v in filter_conditions.items() if v not in [[], None]}
    for key, value in filter_conditions.items():
        # print("Filter conditions:", key, filter_conditions)
        # Handle customer-specific logic
        if key in ["customer","name"]:
            # Check if any column from customer_columns exists in index_mapping
            customer_field = next((col for col in customer_columns if col in index_mapping), None)
            if table == 'action_history_report':
                customer_field = 'customer_account_name'
            if customer_field:
                # print("Using customer field:", customer_field)
                field_name = f"{customer_field}.keyword" if index_mapping[customer_field] == "text" else customer_field
                if isinstance(value, (list,tuple)):  # Check for multiple values
                    query_filters.append({"terms": {field_name: value}})
                else:
                    query_filters.append({"term": {field_name: value}})
            continue  # Skip further processing for this key
        # Handle service_provider-specific logic
        if key == "service_provider":
            if agent_flag:
                prev_value = previous_filters.get(key)
                if prev_value is not None:
                    value = prev_value
            # Check if any column from service_provider_column exists in index_mapping
            service_provider_field = next((col for col in service_provider_column if col in index_mapping), None)
            if service_provider_field:
                # print("Using service provider field:", service_provider_field)
                field_name = f"{service_provider_field}.keyword" if index_mapping[service_provider_field] == "text" else service_provider_field
                if isinstance(value, list):  # Check for multiple values
                    query_filters.append({"terms": {field_name: value}})
                else:
                    query_filters.append({"term": {field_name: value}})
            continue  # Skip further processing for this key
        if key == "customer_rate_plan_name":
            # Check if any column from service_provider_column exists in index_mapping
            customer_rate_plan_field = next((col for col in customer_rate_plan_names if col in index_mapping), None)
            if customer_rate_plan_field:
                # print("Using service provider field:", service_provider_field)
                field_name = f"{customer_rate_plan_field}.keyword" if index_mapping[customer_rate_plan_field] == "text" else customer_rate_plan_field
                if isinstance(value, list):  # Check for multiple values
                    query_filters.append({"terms": {field_name: value}})
                else:
                    query_filters.append({"term": {field_name: value}})
            continue 
        # General logic for other keys
        if key in index_mapping:
            field_type = index_mapping[key]
            # print("Field type for", key, ":", field_type)
            # Use '.keyword' suffix for text fields in Elasticsearch
            field_name = f"{key}.keyword" if field_type == "text" else key
            if isinstance(value, list):  # Check for multiple values
                query_filters.append({"terms": {field_name: value}})
            else:
                query_filters.append({"term": {field_name: value}})
    # if agent_flag:
    #     all_customer_plan_fields = customer_columns + customer_rate_plan_names
    #     contains_customer_or_plan = any(
    #         any(
    #             any(field == k or f"{field}.keyword" == k for field in all_customer_plan_fields)
    #             for k in list(q.get("term", {}).keys()) + list(q.get("terms", {}).keys())
    #         )
    #         for q in query_filters
    #     )
    #     if not contains_customer_or_plan:
    if user['role'] != 'Super Admin' and table in ["rev_assurance_variance", "rev_assurance","sim_management_bulk_change"]:
        by_fields = ["created_by", "modified_by", "deleted_by", "processed_by"]
        selected_by_field = next((field for field in by_fields if field in index_mapping), None)
        username = user["first_name"]+" "+user["last_name"]
        print("username----", username)
        if selected_by_field:
            field_type = index_mapping[selected_by_field]
            field_name = f"{selected_by_field}.keyword" if field_type == "text" else selected_by_field
            query_filters.append({"term": {field_name: username}})
    if table in ["Central_bulk_change", "Central_optimization","sim_management_bulk_change_request", "Comm_Plans", "IMEI_Master_Table"]:
        query_filters = [f for f in query_filters if 'tenant_id' not in f.get('term', {})]
    if table in ['Billing and Payments Billing']:
        if table == 'Unposted':
            query_filters.append({"range": {"charge_amount": { "gt": 0 }}})
        else:    
            query_filters.append({"range": {"amount_due": { "gt": 0 }}})
    elif table == "sim_order_form":
        # Add company filter for sim_order_form
        query_filters.append({"term": {"company.keyword": tenant_name}})
    elif table in ["email_audit", "email_templates"]:
        query_filters.append({"term": {"partner_name.keyword": tenant_name}})
    elif table == "partner_users":
        logging.info(f"### partner_users role: {user['role']}, tenant_name: {tenant_name}")
        role = user.get("role")
        
        role_order = [
            "Partner Admin",
            "Agent Partner Admin",
            "Agent",
            "User",
            "Notification Only User",
            "Qualification Only User"
        ]
        if role and role != "Super Admin":
            if role in role_order:
                supported_role = role_order[role_order.index(role):]
                usernames = get_usernames(tenant_name, supported_role)
                should_queries = []
                for r in supported_role:
                    should_queries.append({"wildcard": {"role.keyword": f"*{r}*"}})
                

                query_filters.append({
                    "bool": {
                        "should": should_queries,
                        "minimum_should_match": 1
                    }
                })
                query_filters.append({
                    "terms": {
                        "username.keyword": usernames
                    }
                })
                logging.info(f"### Supported roles: {supported_role}")
            else:
                logging.warning(f"### Role {role} not found in role_order")   
    logging.info(f"### fetch drop down filters are -- {query_filters}")
    unique_values = fetch_distinct_values_with_composite(index_name, column_name, query_filters,table,tenant_name)
    values = unique_values.get(column_name, [])
    # print("values -- ", values)
    col_data = []
    billing_category_map = {
        "ach": "ACH",
        "credit": "Credit"
    }

    int_columns = ['subscription_count']
    yes_no_columns = {"volte_capable", "assigned"}
    active_inactive_columns = {"is_active"}
    enable_disable_columns = {"api_state", "email_status"}
    true_false_columns = {"nsdev", "auto_change_rate_plan"}
    index_active_columns = {"vw_users_tenant_roles", "vw_customer_rate_plans", "amop_apis", "carrier_apis", "email_templates","products_list_view",'gl_code', 'vw_service_provider_apn_pdp_ip'}
    capitalization_columns = {"optimization_type"}

    # Iterate over the values once, reducing redundancy
    for val in values:
        # Check for blanks
        if val is None or str(val).strip() == "":
            if "" not in col_data:
                col_data.append("(Spaces)")
        else:
            if column_name == "category" and table in ["Chargeback Exceptions","Payment History"]:
                normalized_val = billing_category_map.get(str(val).lower(), val)  # default to original if not in dict
                col_data.append(normalized_val)
            elif column_name in int_columns:
                if isfloat(val):
                    col_data.append(int(float(val)))
                else:
                    col_data.append(int(val))
            elif column_name in yes_no_columns:
                col_data.append("Yes" if val == 1 or val == "Yes" else "No")
            elif column_name in active_inactive_columns and index in index_active_columns:
                col_data.append("Active" if val == 1 else "Inactive")
            elif column_name in enable_disable_columns and index in index_active_columns:
                col_data.append("Enable" if val == 1 else "Disable")
            elif column_name in true_false_columns and (index == "vw_customer_rate_plans" or index == "imei_master"):
                col_data.append("True" if val == 1 else "False")
            elif column_name in capitalization_columns and (index == "vw_customer_rate_plans"):
                normalized_val = "Cross customer pooling" if val in ["Cross Customer Pooling", "Cross customer pooling", "cross customer pooling", "Cross Customer pooling"] else val
                if normalized_val not in col_data:  # Avoid appending duplicates
                    col_data.append(normalized_val)
            elif isinstance(val, Decimal):
                col_data.append(float(val))  # Convert Decimal to float
            elif isinstance(val, bool):
                col_data.append(str(val).lower())
            else:
                col_data.append(val)
        
    if column_name in index_mapping and index_mapping[column_name] == "date":
        # col_data = [convert_to_tenant_timezone(i, tenant_time_zone) for i in col_data] 
        try:
            col_data = list(set(col_data))
            valid_dates = []
            for i in col_data:
                if i:  # skip None or empty
                    try:
                        valid_dates.append(str(i))
                    except Exception:
                        continue
            valid_dates.sort(
                key=lambda x: datetime.datetime.strptime(str(x), "%m/%d/%Y"),
                reverse=True
            )
            col_data = valid_dates

        except ValueError as e:
            print(f"Fetch drop down - Error while parsing dates: {e}")
    
    cols_except=["service_provider","service_provider_display_name","service_provider_name","id","modified_date","order_of_execution"]
    
    # if column_name not in cols_except:
    #     if index == "vw_combined_rev_service_products" and column_name == "customer_name":
    #         col_data = ["unassigned"] + ["assigned"] + col_data
    #     else:
    #         col_data = ["(Blanks)"] + col_data

    normalized_col = column_name.strip().lower()
    if normalized_col not in [c.lower() for c in cols_except]:
        print("adding blanks")
        if table in ["rev_assurance_variance", "rev_assurance"] and column_name == "customer_name":
            # For specific tables and column, add 'unassigned' and 'assigned' at the start
            col_data = ["Unassigned", "Assigned"] + col_data
        else:
            print("adding blanks2")
            col_data = ["(Blanks)"] + col_data

    if column_name in ["billing_period_duration", "billing_period_duration_dates"] :
        
        filtered_date_ranges = [d for d in col_data if d.strip() and extract_start_date(d) is not None]

        # Sort the list based on the extracted start date, in descending order
        sorted_date_ranges = sorted(filtered_date_ranges, key=extract_start_date, reverse=True)
        
        # Convert the sorted list to the required format: month/day/year
        col_data = [ f"{datetime.datetime.strptime(d.split(' - ')[0], '%m/%d/%Y').strftime('%m/%d/%Y')} - {d.split(' - ')[1]}" 
            for d in sorted_date_ranges]
    # unique_values[column_name] = col_data
    if table in ["Inventory","daily_usage_report","zero_usage_report","usage_by_line_report2"]:
        logging.info(f"### Checking tenant information for tenant_name: {tenant_name}")
        database = DB("common_utils", **get_db_config("common_utils"))
        
        tenant_data = database.get_data("tenant", {"tenant_name": tenant_name}, ["id", "parent_tenant_id"])
        
        if not tenant_data.empty:
            tenant_id = tenant_data["id"].to_list()[0]
            parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
            
            logging.info(f"### Tenant ID: {tenant_id} | Parent Tenant ID: {parent_tenant_id}")
            
            # Handle sub-tenant column swap if parent_tenant_id exists
            if parent_tenant_id is not None:
                if column_name == "sub_tenant_carrier_rate_plan_name":
                    if table == "Inventory":
                        unique_values["carrier_rate_plan_name"] = col_data
                    elif table in ["daily_usage_report","zero_usage_report","usage_by_line_report2"]:
                        unique_values["carrier_rate_plan"] = col_data
                    unique_values.pop("sub_tenant_carrier_rate_plan_name", None)
                else:
                    unique_values[column_name] = col_data
            else:
                unique_values[column_name] = col_data
    else:
        unique_values[column_name] = col_data
    return unique_values

def normalize_records(records):
    """
    Convert list of jumbled dicts into
    clean list with only required columns
    """
    normalized = []
    for r in records:
        normalized.append({
            "charge_description": r.get("charge_description"),
            "charge_amount": float(r.get("charge_amount", 0) or 0)
        })
    return normalized

def export_charge_overview_excel(request_data, charges_data):
    """
    Generates Charge Overview Excel from pre-fetched JSON data
    and uploads to S3. Does NOT hit any DB.
    """

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    import boto3, os
    from io import BytesIO
    from copy import deepcopy

    module_name = request_data.get("module_name", "Charge Overview")
    module_name_snake = "_".join(module_name.lower().split())
    user_name = request_data.get("username", "")
    tenant_id = request_data.get("tenant_id", "")
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]
    module_name_snake_case = "_".join(module_name.strip().lower().split())

    file_name = f"exports/search/{module_name_snake_case}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

    table_data = charges_data.get("data", {}).get("table", {})
    # Extract tables from input data
    account_charges = normalize_records(deepcopy(table_data.get("charge_overview_account_charges", [])))
    credits = normalize_records(deepcopy(table_data.get("charge_overview_account_credits", [])))
    recurring = normalize_records(deepcopy(table_data.get("charge_overview_recurring_charges", [])))

    # Setup Excel
    wb = Workbook()
    ws = wb.active
    ws.title = "Charge Overview"

    header_font = Font(bold=True)
    section_font = Font(bold=True, size=12)
    header_fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")

    current_row = 1

    def write_section(title, records):
        nonlocal current_row

        ws.cell(row=current_row, column=1, value=title).font = section_font
        current_row += 1

        headers = ["Charge Description", "Charge Amount"]
        for idx, header in enumerate(headers, 1):
            cell = ws.cell(row=current_row, column=idx, value=header)
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center")
            cell.fill = header_fill
        current_row += 1

        if records:
            for row in records:
                ws.cell(row=current_row, column=1, value=row.get("charge_description"))
                amt = float(row.get("charge_amount", 0) or 0)
                cell = ws.cell(row=current_row, column=2, value=amt)
                cell.number_format = '"$"#,##0.00'
                current_row += 1
        else:
            ws.cell(row=current_row, column=1, value="No Data Found")
            current_row += 1

        current_row += 2

    # Write 3 sections
    write_section("Account Charges", account_charges)
    write_section("Credits", credits)
    write_section("Recurring Charges", recurring)

    # Auto column width
    for col_idx, column_cells in enumerate(ws.columns, 1):
        max_len = max(len(str(cell.value or "")) for cell in column_cells)
        ws.column_dimensions[get_column_letter(col_idx)].width = max_len + 2

    # Save to memory
    excel_buffer = BytesIO()
    wb.save(excel_buffer)
    excel_buffer.seek(0)

    # Upload to S3
    s3_client = boto3.client("s3")
    s3_client.put_object(
        Bucket=S3_BUCKET_NAME,
        Key=file_name,
        Body=excel_buffer.getvalue(),
        ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

    return {
        "flag": True,
        "message": "Charge Overview export completed successfully",
        "download_url": download_url
    }