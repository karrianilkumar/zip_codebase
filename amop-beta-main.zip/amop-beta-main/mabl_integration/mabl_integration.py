"""
@Author1 : SaiMohit
@Author2 : Phaneendra Y
Created Date: 2026-02-02
"""
# Importing the necessary Libraries
import logging
import os
import json
import time
from datetime import datetime
import pandas as pd
import numpy as np


from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
from pandas import Timestamp
from datetime import datetime
from dateutil.relativedelta import relativedelta
from sqlalchemy import create_engine, text
from pytz import timezone
from openpyxl.utils import get_column_letter
from concurrent.futures import ThreadPoolExecutor, as_completed
import time, random

logging = Logging(name="mabl_integration")
# Database configuration
db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }


def funtion_caller(data, path):
    """
    Main function caller
    
    Args:
        data (dict): Request data containing webhook information
        path (str): API endpoint path being called
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/mabl_test_results":
        result = mabl_test_results_processor(data)
    
    else:
        result = {"flag": False, "error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    
    return result


def mabl_test_results_processor(data):
    """
    This function processes the Mabl webhook response
    """
    logging.info(f"request recieved for mabl_test_results_processor with data {data}")
    start_time = time.time()
    
    try:
        # Connect to all environments
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    
    try:
        # Extract data
        # Get plan execution ID (similar to Verizon's requestId)
        plan_execution = data.get("plan_execution", {})
        plan_execution_id = plan_execution.get("id", "")
        request_id = plan_execution_id  
        
        # Get plan info
        plan = data.get("plan", {})
        
        # Get status
        status = data.get("status", "")
        success = data.get("success", False)
        
        # Convert Mabl status to test_status
        if status == "succeeded":
            test_status = "Success"
        elif status == "failed":
            test_status = "Failed"
        elif status == "stopped":
            test_status = "Stopped"
        else:
            test_status = "Unknown"
        
        # Extract journeys and journey_executions
        journeys = data.get("journeys", [])
        journey_executions = data.get("journey_executions", [])
        
        # Extract test_cases from each journey_execution
        test_cases_list = []
        for journey_exec in journey_executions:
            if "test_cases" in journey_exec:
                test_cases_list.extend(journey_exec.get("test_cases", []))
        
        # Create callback data with all required fields
        callback_data = {
            "request_id": request_id,
            "status": status,
            "test_status": test_status,
            "success": success,
            "plan_execution": json.dumps(plan_execution),
            "journey_executions": json.dumps(journey_executions),
            "test_cases": json.dumps(test_cases_list) if test_cases_list else json.dumps([]),
            "start_time": data.get("start_time"),
            "stop_time": data.get("stop_time"),
            "results": json.dumps(data.get("results", [])),
            "plan": json.dumps(plan), 
        }
        
        logging.info(f"Mabl callback response data is {callback_data}")
        
        # Insert into DB
        try:
            request_data = common_utils_database.insert_data(callback_data, "mabl_test_callback")
            logging.info(f"Mabl callback response inserted successfully for request id {request_id}")
        except Exception as e:
            logging.error(f"Failed to insert in prod DB: {e}")
        

        # Process to update partner_setup_json based on plan_execution_id and setup_action
        if plan_execution_id and status in ["succeeded", "failed", "stopped"]:
            try:
                # Step 1: Query tenant table to find matching plan_run_ids
                # Removing tenant_id since it doesn't exist
                query = """
                    SELECT tenant_name, mabl_results_json, partner_setup_json 
                    FROM tenant 
                    WHERE mabl_results_json IS NOT NULL 
                    AND mabl_results_json != '[]'
                    AND mabl_results_json != '{}'
                """
                
                logging.info(f"Querying tenant table for plan_execution_id: {plan_execution_id}")
                
                # Execute query - based on your trigger_test_run pattern
                tenants_result = common_utils_database.execute_query(query, True)
                
                # Check if we got a valid result
                if tenants_result is False:
                    logging.info("No tenants found with mabl_results_json data (execute_query returned False)")
                elif isinstance(tenants_result, pd.DataFrame):
                    if tenants_result.empty:
                        logging.info("No tenants found with mabl_results_json data (DataFrame is empty)")
                    else:
                        logging.info(f"Found {len(tenants_result)} tenants with mabl_results_json data")
                        
                        for index, row in tenants_result.iterrows():
                            tenant_name = row["tenant_name"]
                            mabl_results_json_str = row["mabl_results_json"]
                            partner_setup_json_str = row["partner_setup_json"]
                            
                            try:
                                # Skip if JSON strings are None or empty
                                if not mabl_results_json_str or not partner_setup_json_str:
                                    logging.info(f"Skipping tenant {tenant_name}: empty JSON data")
                                    continue
                                    
                                # Parse JSON strings
                                mabl_results = json.loads(mabl_results_json_str) if isinstance(mabl_results_json_str, str) else mabl_results_json_str
                                partner_setup_data = json.loads(partner_setup_json_str) if isinstance(partner_setup_json_str, str) else partner_setup_json_str
                                
                                # Check if mabl_results is a list
                                if isinstance(mabl_results, list):
                                    # Find matching entry in mabl_results_json
                                    for mabl_entry in mabl_results:
                                        plan_run_ids = mabl_entry.get("plan_run_ids", [])
                                        
                                        # Check if our plan_execution_id exists in plan_run_ids
                                        if plan_execution_id in plan_run_ids:
                                            setup_action = mabl_entry.get("setup_action", "")
                                            logging.info(f"Found matching plan_run_id {plan_execution_id} for setup_action: {setup_action} in tenant {tenant_name}")
                                            
                                            # Now update partner_setup_json
                                            if isinstance(partner_setup_data, list):
                                                updated = False
                                                for setup_item in partner_setup_data:
                                                    # Find matching setup_action
                                                    if setup_item.get("setup_action") == setup_action:
                                                        # Update test_status based on Mabl result
                                                        setup_item["test_status"] = test_status
                                                        setup_item["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                                        updated = True
                                                        logging.info(f"Updating partner_setup_json for tenant {tenant_name}, setup_action: {setup_action}, new test_status: {test_status}")
                                                        break
                                                
                                                if updated:
                                                    # Update the tenant table with modified partner_setup_json
                                                    update_data = {
                                                        "partner_setup_json": json.dumps(partner_setup_data)
                                                    }
                                                    
                                                    # Update using update_dict method - same pattern as trigger_test_run
                                                    try:
                                                        update_result = common_utils_database.update_dict(
                                                            "tenant",
                                                            update_data,
                                                            and_conditions={"tenant_name": tenant_name},
                                                        )
                                                        
                                                        if update_result:
                                                            logging.info(f"Successfully updated partner_setup_json for tenant {tenant_name}")
                                                            
                                                            # Also update the specific mabl_results_json entry's test_status
                                                            if mabl_entry.get("test_status") != test_status:
                                                                mabl_entry["test_status"] = test_status
                                                                # Update mabl_results_json in the database
                                                                mabl_update_data = {
                                                                    "mabl_results_json": json.dumps(mabl_results)
                                                                }
                                                                
                                                                mabl_update_result = common_utils_database.update_dict(
                                                                    "tenant",
                                                                    mabl_update_data,
                                                                    and_conditions={"tenant_name": tenant_name},
                                                                )
                                                                
                                                                if mabl_update_result:
                                                                    logging.info(f"Also updated test_status in mabl_results_json for tenant {tenant_name}")
                                                                else:
                                                                    logging.warning(f"Failed to update mabl_results_json for tenant {tenant_name}")
                                                        else:
                                                            logging.error(f"Failed to update partner_setup_json for tenant {tenant_name}")
                                                    except Exception as update_error:
                                                        logging.error(f"Error updating tenant {tenant_name}: {update_error}")
                                                    
                                                else:
                                                    logging.warning(f"No matching setup_action '{setup_action}' found in partner_setup_json for tenant {tenant_name}")
                                            
                                            break  # Found matching plan_run_id, no need to check other mabl entries
                                
                            except json.JSONDecodeError as e:
                                logging.error(f"JSON decode error for tenant {tenant_name}: {e}")
                                continue
                            except Exception as e:
                                logging.error(f"Error processing tenant {tenant_name}: {e}")
                                continue
                else:
                    logging.info(f"execute_query returned: {type(tenants_result)} - {tenants_result}")
            
            except Exception as e:
                logging.error(f"Error updating partner_setup_json: {e}")
                logging.exception("Full traceback:")
        else:
            logging.info(f"No plan_execution_id found or status not in ['succeeded', 'failed', 'stopped']: plan_execution_id={plan_execution_id}, status={status}")
       
        
        # Audit logging for user actions
        if request_data:
            response = {"flag": True, "message": "Received Mabl test results"}
            try:
                # End time calculation
                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                time_consumed = int(float(time_consumed))
                audit_data_user_actions = {
                    "service_name": "mabl_test_results_processor",
                    "created_by": "System",
                    "time_consumed_secs": time_consumed,
                    "status": "Response Inserted",
                    "tenant_name": "",
                    "module_name": "Mabl Callback",
                    "comments": f"Audited request id {request_id} and response: {test_status}",
                    "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### Audit logging failed: {e}")
        else:
            response = {"flag": True, "message": "Mabl test results failed to insert"}

        return response
        
    except Exception as e:
        logging.exception(f"inserting into table failed: {e}")
        response = {"flag": False, "error": "Mabl test results failed to insert"}
        
        error_message = f"Error during Mabl test processing"
        error_type = str(type(e).__name__)
        
        try:
            # Log failure to error log table 
            error_data = { 
                "service_name": "mabl_test_results_processor",
                "created_by": "System",
                "error_message": error_message,
                "error_type": error_type,
                "users": "",
                "tenant_name": "",
                "comments": f"Error while inserting response details into table",
                "module_name": "Mabl Callback",
                "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
        
        return response