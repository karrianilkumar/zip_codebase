CREATE OR REPLACE FUNCTION update_modified_date()
RETURNS TRIGGER AS $$
BEGIN
  NEW.modified_date := CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_last_modified_date_()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_modified_date := CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_last_modified_date_time()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_modified_date_time := CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;



CREATE OR REPLACE FUNCTION public.update_sequence_after_insert()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  -- Debugging message to check the trigger execution
  RAISE NOTICE 'Trigger executed for table: %, id value: %', TG_TABLE_NAME, NEW.id;

  -- Update the sequence to the maximum value of the id column
  EXECUTE 'SELECT setval(pg_get_serial_sequence(''' || TG_TABLE_NAME || ''', ''id''), 
                          (SELECT MAX(id) FROM ' || TG_TABLE_NAME || '))';

  -- Debugging message after setting the sequence
  RAISE NOTICE 'Sequence for table: % has been updated', TG_TABLE_NAME;

  RETURN NEW;
END;
$function$
;


CREATE TRIGGER update_last_modified
BEFORE UPDATE ON integration
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON serviceprovider
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON bandwidthaccount
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON bandwidth_customers
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON billing_period_status
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON billing_period
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON carrier_rate_plan
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON customer_rate_pool
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON customerrateplan
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON netsapiens_reseller
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON e911customers
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON integration_authentication
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON revcustomer
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON customers
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON customergroups
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON mobility_feature
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON customer_mobility_feature
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

create trigger update_last_modified before
update
    on
    public.device for each row
    when ((old.modified_date is null)) execute function update_modified_date();

create trigger update_last_modified before
update
    on
    public.mobility_device for each row execute function update_modified_date();


create trigger update_last_modified before
update
    on
    public.mobility_device_tenant for each row execute function update_modified_date();    


create trigger update_last_modified before
update
    on
    public.smi_cross_provider_device_history for each row execute function update_modified_date();


create trigger update_last_modified before
update
    on
    public.smi_device_history for each row execute function update_modified_date();


create trigger update_last_modified before
update
    on
    public.smi_device_detail_history for each row execute function update_modified_date();


CREATE TRIGGER update_last_modified
BEFORE UPDATE ON device_status
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON sim_management_communication_plan
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON revagent
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON revbillprofile
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON rev_provider
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON rev_service_type
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON rev_usage_plan_group
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON rev_service
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON sim_management_inventory
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON service_provider_tenant_configuration
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON sim_management_bulk_change_type
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON sim_management_bulk_change
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON sim_management_bulk_change_request
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON sim_management_bulk_change_log
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON sim_management_carrier_feature_codes_uat
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON rev_product_type
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON rev_product
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON rev_package
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_type
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_status
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON mobility_device_usage_aggregate
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON imei_master
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON sim_management_inventory_history
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON device_status_reason_code
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON netsapiens_device
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_session
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_instance
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_comm_group
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_group
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_group_carrier_rate_plan
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_instance_result_file
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();


CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_queue
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_rate_plan_type
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_smi_result_customer_charge_queue
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON optimization_smi_result_rate_plan_queue
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON rev_service_product
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();


CREATE TRIGGER update_last_modified
BEFORE UPDATE ON qualification
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON app_file
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_get_usage_by_rate_plan
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_action
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_condition
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_customer_rate_plan
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_followup_effective_date_type
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_followup
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_detail
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_followup_detail
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_log
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON automation_rule_type
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON device_status_uploaded_file_detail
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON device_status_uploaded_file
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON e_bonding_device
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON e_bonding_device_sync_audit
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON jasper_device_sync_audit
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON telegence_device
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON telegence_device_mobility_feature
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON telegence_device_sync_audit
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON thing_space_device_sync_audit
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON customer_billing_period
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON imei_type
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

CREATE TRIGGER update_last_modified
BEFORE UPDATE ON integration_connection
FOR EACH ROW
EXECUTE FUNCTION update_modified_date();

create trigger update_last_modified before
update
    on
    public.device_tenant for each row execute function update_modified_date();



-- DROP FUNCTION public.get_current_customer_billing_period(int4, int4);

CREATE OR REPLACE FUNCTION public.get_current_customer_billing_period(customer_bill_period_end_day integer, customer_bill_period_end_hour integer)
 RETURNS TABLE(start_date timestamp without time zone, end_date timestamp without time zone)
 LANGUAGE plpgsql
AS $function$

BEGIN
    IF customer_bill_period_end_day >= EXTRACT(DAY FROM CURRENT_TIMESTAMP AT TIME ZONE 'UTC') THEN
        end_date := make_timestamp(
            EXTRACT(YEAR FROM CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::INT,
            EXTRACT(MONTH FROM CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::INT,
            customer_bill_period_end_day,
            customer_bill_period_end_hour, 0, 0
        );
        start_date := end_date - INTERVAL '1 month';
    ELSE
        end_date := make_timestamp(
            EXTRACT(YEAR FROM CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::INT,
            EXTRACT(MONTH FROM CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::INT,
            customer_bill_period_end_day,
            customer_bill_period_end_hour, 0, 0
        ) + INTERVAL '1 month';
        start_date := end_date - INTERVAL '1 month';
    END IF;

    RETURN NEXT;
END;
$function$
;

-- DROP FUNCTION public.get_current_cycle_usage_bytes(int4, int4);

CREATE OR REPLACE FUNCTION public.get_current_cycle_usage_bytes(p_mobility_device_id integer, p_tenant_id integer)
 RETURNS numeric
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    usage_bytes NUMERIC := 0;
BEGIN
    SELECT
        COALESCE(SUM(du.data_usage), 0)
    INTO usage_bytes
    FROM device_usage du
    JOIN mobility_device_tenant mdt
        ON du.mobility_device_id = mdt.mobility_device_id
    JOIN customers c
        ON mdt.customer_id = c.id
    CROSS JOIN LATERAL get_current_customer_billing_period(
        c.customer_bill_period_end_day,
        c.customer_bill_period_end_hour
    ) billing_period(start_date, end_date)
    WHERE du.mobility_device_id = p_mobility_device_id
      AND mdt.tenant_id = p_tenant_id
      AND du.usage_date >= billing_period.start_date
      AND du.usage_date < billing_period.end_date
      AND (c.customer_bill_period_end_day IS NOT NULL OR c.customer_bill_period_end_hour IS NOT NULL);
 
    RETURN usage_bytes;
END;
$function$
;
 
-- DROP FUNCTION public.get_current_cycle_usage_bytes_m2m(int4, int4);

CREATE OR REPLACE FUNCTION public.get_current_cycle_usage_bytes_m2m(p_m2m_device_id integer, p_tenant_id integer)
 RETURNS numeric
 LANGUAGE plpgsql
 STABLE
AS $function$

DECLARE
    usage_bytes NUMERIC := 0;
BEGIN
    SELECT
        COALESCE(SUM(du.data_usage), 0)
    INTO usage_bytes
    FROM device_usage du
    JOIN device_tenant mdt
        ON du.m2m_device_id = mdt.device_id
    JOIN customers c
        ON mdt.customer_id = c.id
    CROSS JOIN LATERAL get_current_customer_billing_period(
        c.customer_bill_period_end_day,
        c.customer_bill_period_end_hour
    ) billing_period(start_date, end_date)
    WHERE du.m2m_device_id = p_m2m_device_id
      AND mdt.tenant_id = p_tenant_id
      AND du.usage_date >= billing_period.start_date
      AND du.usage_date < billing_period.end_date
      AND (c.customer_bill_period_end_day IS NOT NULL OR c.customer_bill_period_end_hour IS NOT NULL);
 
    RETURN usage_bytes;
END;
$function$
;
 


-- DROP FUNCTION public.update_service_provider_names();

CREATE OR REPLACE FUNCTION public.update_service_provider_names()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$

DECLARE
    displaynames TEXT;
BEGIN
    RAISE NOTICE 'Trigger fired for customerrateplan ID: %', NEW.id;
    RAISE NOTICE 'Original serviceproviderids: %', NEW.serviceproviderids;

    IF NEW.serviceproviderids IS NOT NULL THEN
        SELECT STRING_AGG(sp.display_name, ', ' ORDER BY sp.display_name)
        INTO displaynames
        FROM UNNEST(STRING_TO_ARRAY(NEW.serviceproviderids, ',')) AS spid(id)
        JOIN serviceprovider sp ON sp.id = spid.id::int;

        RAISE NOTICE 'Resolved from serviceproviderids: %', displaynames;

    ELSIF NEW.service_provider_id IS NOT NULL THEN
        SELECT sp.display_name
        INTO displaynames
        FROM serviceprovider sp
        WHERE sp.id = NEW.service_provider_id;

        RAISE NOTICE 'Resolved from service_provider_id: %', displaynames;
    ELSE
        displaynames := NULL;
        RAISE NOTICE 'No service provider ID(s) provided.';
    END IF;

    NEW.service_provider_name := displaynames;

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_smi_from_device();
CREATE OR REPLACE FUNCTION public.update_smi_from_device()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$

DECLARE 
update_flag text;
BEGIN 
      
	-- Get the session variable safely (returns NULL if not set)
update_flag := current_setting('myvars.update_in_progress', true);
IF update_flag IS NOT NULL AND update_flag = 'true' THEN
        RETURN NEW;
    END IF;

	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.update_in_progress', 'true', true);
	
	-- Perform the update on sim_management_inventory
    UPDATE public.sim_management_inventory
    SET
        last_usage_date = new.last_usage_date,
        dt_id = dt.id,
        device_id = new.id,
        service_provider_id = new.service_provider_id,
        service_provider_display_name = sp.display_name,
        integration_id = sp.integration_id,
        iccid = new.iccid,
        msisdn = new.msisdn,
        imei = new.imei,
        eid = new.eid,
        carrier_cycle_usage_bytes = new.carrier_cycle_usage,
        carrier_rate_plan_name = COALESCE(carrier_rate_plan.friendly_name, new.carrier_rate_plan),
        carrier_cycle_usage_mb = CASE
            WHEN i.id = 12 THEN round(COALESCE(new.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(new.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END,
        created_by = new.created_by,
        created_date = new.created_date,
        modified_by = new.modified_by,
        modified_date = new.modified_date,
        deleted_by = new.deleted_by,
        deleted_date = new.deleted_date,
        is_active = new.is_active,
        is_deleted = new.is_deleted,
        account_number = dt.account_number,
        cost_center = new.cost_center,
        username = new.username,
        carrier_rate_plan_id = new.carrier_rate_plan_id,
        device_status_id = new.device_status_id,
        sim_status = ds.display_name,
        is_active_status = ds.is_active_status,
        tenant_id = dt.tenant_id,
        rev_customer_id = revcust.rev_customer_id,
        rev_customer_name = revcust.customer_name,
        rev_parent_customer_id = revcust.rev_parent_customer_id,
        customer_id = cust.id,
        parent_customer_id = cust.parent_customer_id,
        customer_name = cust.customer_name,
        customer_rate_plan_id = dt.customer_rate_plan_id,
        customer_rate_plan_code = customerrateplan.rate_plan_code,
        customer_rate_plan_name = customerrateplan.rate_plan_name,
        sms_count = new.ctd_sms_usage,
        communication_plan = new.communication_plan,
        ip_address = new.ip_address,
        customer_rate_pool_id = dt.customer_rate_pool_id,
        customer_rate_pool_name = customer_rate_pool.name,
        
        carrier_rate_plan_mb = carrier_rate_plan.plan_mb,
        soc = new.soc,
		billing_cycle_start_date=bp.billing_cycle_start_date,
        billing_cycle_end_date=bp.billing_cycle_end_date,
    billing_period_id=NEW.billing_period_id,
	ctd_sms_usage=NEW.ctd_sms_usage,
	ctd_session_count=NEW.ctd_session_count,
	package=NEW.package,
	overage_limit_reached=NEW.overage_limit_reached,
	overage_limit_override=NEW.overage_limit_override,
	device_description=NEW.device_description,
    ctd_voice_usage=NEW.ctd_voice_usage,
	rev_service_id=dt.rev_service_id,
	account_number_integration_authentication_id=dt.account_number_integration_authentication_id,
	customer_data_allocation_mb=dt.customer_data_allocation_mb,
    customer_rate_plan_mb=customerrateplan.plan_mb,
    customer_rate_plan_allows_sim_pooling=customerrateplan.allows_sim_pooling,
	-- date_added = COALESCE(date_added.date_of_change, new.date_added),
date_added = CASE
    WHEN sp.integration_id IN (1, 4, 9, 11, 15)
        THEN smi.date_added
    ELSE
        COALESCE(date_added.date_of_change, smi.date_added)
END,

date_activated = CASE
    WHEN sp.integration_id IN (1, 4, 9, 11, 15)
        THEN smi.date_activated
    ELSE
        COALESCE(date_activated.date_of_change, smi.date_activated)
END,
	tenant_is_active=dt.is_active,
	tenant_is_deleted=dt.is_deleted,
	customer_cycle_usage_mb=CASE
            WHEN cust.customer_bill_period_end_day IS NOT NULL AND cust.customer_bill_period_end_hour IS NOT NULL THEN 
                ROUND(get_current_cycle_usage_bytes_m2m(smi.id, dt.tenant_id) / 1024.0 / 1024.0, 3)
            ELSE 
                ROUND(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END ,
        service_provider_is_active = CASE 
			    WHEN sp.is_active = true THEN true
			    ELSE false
			END
    FROM device smi
    JOIN device_tenant dt ON smi.id = dt.device_id
    JOIN serviceprovider sp ON smi.service_provider_id = sp.id
    LEFT JOIN device_status ds ON ds.id = smi.device_status_id
	 LEFT JOIN billing_period bp ON bp.id = smi.billing_period_id
    LEFT JOIN carrier_rate_plan carrier_rate_plan ON smi.carrier_rate_plan_id = carrier_rate_plan.id
    LEFT JOIN customers cust ON cust.id = dt.customer_id AND cust.is_active = true AND cust.is_deleted = false
    LEFT JOIN revcustomer revcust ON cust.rev_customer_id = revcust.id AND cust.is_active = true
    LEFT JOIN integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false AND i.portal_type_id = 0
    LEFT JOIN customerrateplan customerrateplan ON dt.customer_rate_plan_id = customerrateplan.id
    LEFT JOIN customer_rate_pool customer_rate_pool ON dt.customer_rate_pool_id = customer_rate_pool.id
	LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id AND ds.is_active_status = true))
          ORDER BY device_status_history.date_of_change
         LIMIT 1) date_added ON true
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id))
          ORDER BY device_status_history.date_of_change DESC
         LIMIT 1) date_activated ON true
    WHERE dt.device_id=new.id and sim_management_inventory.device_id=old.id
	and dt.id=sim_management_inventory.dt_id;
    PERFORM set_config('myvars.update_in_progress', 'false', true);
	 
    RETURN NEW;
END;
$BODY$;

-- DROP FUNCTION public.insert_into_optimization_smi();

CREATE OR REPLACE FUNCTION public.insert_into_optimization_smi()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO public.optimization_smi (
        instance_id,
        device_id,
        cycle_data_usage_mb,
        projected_data_usage_mb,
        communication_plan,
        msisdn,
        iccid,
        usage_date,
        created_by,
        created_date,
        amop_device_id,
        service_provider_id,
        date_activated,
        was_activated_in_this_billing_period,
        days_activated_in_billing_period,
        sms_usage,
        optimization_comm_group_id,
        auto_change_rate_plan,
        did
    )
    VALUES (
        NEW.instance_id,
        NEW.device_id,
        NEW.cycle_data_usage_mb,
        NEW.projected_data_usage_mb,
        NEW.communication_plan,
        NEW.msisdn,
        NEW.iccid,
        NEW.usage_date,
        NEW.created_by,
        NEW.created_date,
        NEW.amop_device_id,
        NEW.service_provider_id,
        NEW.date_activated,
        NEW.was_activated_in_this_billing_period,
        NEW.days_activated_in_billing_period,
        NEW.sms_usage,
		NEW.optimization_comm_group_id,
        NEW.auto_change_rate_plan,
        NEW.id  -- Use NEW.id to populate the did column in optimization_smi
    );
    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.insert_into_optimization_smi_from_mobility();

CREATE OR REPLACE FUNCTION public.insert_into_optimization_smi_from_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO public.optimization_smi (
        instance_id,
        device_id,
        cycle_data_usage_mb,
        projected_data_usage_mb,
        communication_plan,
        msisdn,
        iccid,
        usage_date,
        created_by,
        created_date,
        amop_device_id,
        service_provider_id,
        date_activated,
        was_activated_in_this_billing_period,
        days_activated_in_billing_period,
        sms_usage,
		optimization_rate_plan_type_id,
        optimization_group_id,
        auto_change_rate_plan,
		optimization_comm_group_id,
        mid
    )
    VALUES (
        NEW.instance_id,
        NEW.device_id,
        NEW.cycle_data_usage_mb,
        NEW.projected_data_usage_mb,
        NEW.communication_plan,
        NEW.msisdn,
        NEW.iccid,
        NEW.usage_date,
        NEW.created_by,
        NEW.created_date,
        NEW.amop_device_id,
        NEW.service_provider_id,
        NEW.date_activated,
        NEW.was_activated_in_this_billing_period,
        NEW.days_activated_in_billing_period,
        NEW.sms_usage,
        NEW.optimization_rate_plan_type_id,
        NEW.optimization_group_id,
        NEW.auto_change_rate_plan,
		NEW.optimization_comm_group_id,
        NEW.id  -- Use NEW.id to populate the Mid column in optimization_smi
    );
    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.insert_into_optimization_smi_result_from_device_result();

CREATE OR REPLACE FUNCTION public.insert_into_optimization_smi_result_from_device_result()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    RAISE LOG 'Trigger start: op=%, device_result_id=%', TG_OP, NEW.id;

    INSERT INTO public.optimization_smi_result (
        queue_id,
        device_id,
        usage_mb,
        assigned_carrier_rate_plan_id,
        assigned_customer_rate_plan_id,
        customer_rate_pool_id,
        created_by,
        created_date,
        amop_device_id,
        charge_amt,
        billing_period_id,
        sms_usage,
        sms_charge_amount,
        base_rate_amt,
        rate_charge_amt,
        overage_charge_amt,
        did
    )
    VALUES (
        NEW.queue_id,
        NEW.device_id,
        NEW.usage_mb,
        NEW.assigned_carrier_rate_plan_id,
        NEW.assigned_customer_rate_plan_id,
        NEW.customer_rate_pool_id,
        NEW.created_by,
        NEW.created_date,
        NEW.amop_device_id,
        NEW.charge_amt,
        NEW.billing_period_id,
        NEW.sms_usage,
        NEW.sms_charge_amount,
        NEW.base_rate_amt,
        NEW.rate_charge_amt,
        NEW.overage_charge_amt,
        NEW.id
    );

    RAISE LOG 'Trigger insert done for device_result_id=%', NEW.id;

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.insert_into_optimization_smi_result_from_mobility_device_result();

CREATE OR REPLACE FUNCTION public.insert_into_optimization_smi_result_from_mobility_device_result()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO public.optimization_smi_result (
        queue_id,
        device_id,
        usage_mb,
        assigned_carrier_rate_plan_id,
        assigned_customer_rate_plan_id,
        customer_rate_pool_id,
        created_by,
        created_date,
        amop_device_id,
        charge_amt,
        billing_period_id,
        sms_usage,
        sms_charge_amount,
        base_rate_amt,
        rate_charge_amt,
        overage_charge_amt,
        mid  -- This column will hold the id from optimization_mobility_device_result
    )
    VALUES (
        NEW.queue_id,
        NEW.device_id,
        NEW.usage_mb,
        NEW.assigned_carrier_rate_plan_id,
        NEW.assigned_customer_rate_plan_id,
        NEW.customer_rate_pool_id,
        NEW.created_by,
        NEW.created_date,
        NEW.amop_device_id,
        NEW.charge_amt,
        NEW.billing_period_id,
        NEW.sms_usage,
        NEW.sms_charge_amount,
        NEW.base_rate_amt,
        NEW.rate_charge_amt,
        NEW.overage_charge_amt,
        NEW.id  -- Use NEW.id to populate the did column in optimization_smi_result
    );
    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.insert_into_optimization_smi_result_rate_plan_queue_from_device();

CREATE OR REPLACE FUNCTION public.insert_into_optimization_smi_result_rate_plan_queue_from_device()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN

    INSERT INTO public.optimization_smi_result_rate_plan_queue (
        optimization_device_result_id,
        is_processed,
        created_by,
        created_date,
        modified_by,
        modified_date,
        group_number,
        has_errors,
        error_message,
        did
    )
    VALUES (
        NEW.optimization_device_result_id,
        NEW.is_processed,
        NEW.created_by,
        NEW.created_date,
        NEW.modified_by,
        NEW.modified_date,
        NEW.group_number,
        NEW.has_errors,
        NEW.error_message,
        NEW.id
    );

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.insertto_optimization_smi_result_rate_plan_queue_from_mobility();

CREATE OR REPLACE FUNCTION public.insertto_optimization_smi_result_rate_plan_queue_from_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN

    INSERT INTO public.optimization_smi_result_rate_plan_queue (
        optimization_mobility_device_result_id,
        is_processed,
        created_by,
        created_date,
        modified_by,
        modified_date,
        group_number,
        has_errors,
        error_message,
        mid
    )
    VALUES (
        NEW.optimization_mobility_device_result_id,
        NEW.is_processed,
        NEW.created_by,
        NEW.created_date,
        NEW.modified_by,
        NEW.modified_date,
        NEW.group_number,
        NEW.has_errors,
        NEW.error_message,
        NEW.id  -- Insert the `id` from `optimization_mobility_device_result_rate_plan_queue` as `did`
    );

    RETURN NEW;
END;
$function$
;


-- DROP FUNCTION public.insert_to_optimization_smi_result_customer_chargeq_frm_device();

CREATE OR REPLACE FUNCTION public.insert_to_optimization_smi_result_customer_chargeq_frm_device()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO public.optimization_smi_result_customer_charge_queue (
        optimization_device_result_id,
        is_processed,
        created_by,
        created_date,
        modified_by,
        modified_date,
        charge_amount,
        charge_id,
        base_charge_amount,
        total_charge_amount,
        has_errors,
        error_message,
        rev_service_number,
        rev_product_type_id,
        uploaded_file_id,
        billing_start_date,
        billing_end_date,
        description,
        integration_authentication_id,
        billing_period_id,
        sms_rev_product_type_id,
        sms_charge_amount,
        sms_charge_id,
        rate_charge_amt,
        overage_charge_amt,
        base_rate_amt,
        overage_rev_product_type_id,
        rev_product_id,
        sms_rev_product_id,
        overage_rev_product_id,
		did
    )
    VALUES (
        NEW.optimization_device_result_id,
        NEW.is_processed,
        NEW.created_by,
        NEW.created_date,
        NEW.modified_by,
        NEW.modified_date,
        NEW.charge_amount,
        NEW.charge_id,
        NEW.base_charge_amount,
        NEW.total_charge_amount,
        NEW.has_errors,
        NEW.error_message,
        NEW.rev_service_number,
        NEW.rev_product_type_id,
        NEW.uploaded_file_id,
        NEW.billing_start_date,
        NEW.billing_end_date,
        NEW.description,
        NEW.integration_authentication_id,
        NEW.billing_period_id,
        NEW.sms_rev_product_type_id,
        NEW.sms_charge_amount,
        NEW.sms_charge_id,
        NEW.rate_charge_amt,
        NEW.overage_charge_amt,
        NEW.base_rate_amt,
        NEW.overage_rev_product_type_id,
        NEW.rev_product_id,
        NEW.sms_rev_product_id,
        NEW.overage_rev_product_id,
		NEW.id
    );

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.insert_to_optimization_smi_result_cust_chargeq_frm_mobility();

CREATE OR REPLACE FUNCTION public.insert_to_optimization_smi_result_cust_chargeq_frm_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO public.optimization_smi_result_customer_charge_queue (
        optimization_mobility_device_result_id,
        is_processed,
        created_by,
        created_date,
        modified_by,
        modified_date,
        charge_amount,
        charge_id,
        base_charge_amount,
        total_charge_amount,
        has_errors,
        error_message,
        rev_service_number,
        rev_product_type_id,
        uploaded_file_id,
        billing_start_date,
        billing_end_date,
        description,
        integration_authentication_id,
        billing_period_id,
        sms_rev_product_type_id,
        sms_charge_amount,
        sms_charge_id,
        rate_charge_amt,
        overage_charge_amt,
        base_rate_amt,
        overage_rev_product_type_id,
        rev_product_id,
        sms_rev_product_id,
        overage_rev_product_id,
		mid
    )
    VALUES (
        NEW.optimization_mobility_device_result_id,
        NEW.is_processed,
        NEW.created_by,
        NEW.created_date,
        NEW.modified_by,
        NEW.modified_date,
        NEW.charge_amount,
        NEW.charge_id,
        NEW.base_charge_amount,
        NEW.total_charge_amount,
        NEW.has_errors,
        NEW.error_message,
        NEW.rev_service_number,
        NEW.rev_product_type_id,
        NEW.uploaded_file_id,
        NEW.billing_start_date,
        NEW.billing_end_date,
        NEW.description,
        NEW.integration_authentication_id,
        NEW.billing_period_id,
        NEW.sms_rev_product_type_id,
        NEW.sms_charge_amount,
        NEW.sms_charge_id,
        NEW.rate_charge_amt,
        NEW.overage_charge_amt,
        NEW.base_rate_amt,
        NEW.overage_rev_product_type_id,
        NEW.rev_product_id,
        NEW.sms_rev_product_id,
        NEW.overage_rev_product_id,
		NEW.id
    );

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_optimization_smi();

CREATE OR REPLACE FUNCTION public.update_optimization_smi()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    UPDATE public.optimization_smi
    SET
        instance_id = NEW.instance_id,
        device_id = NEW.device_id,
        cycle_data_usage_mb = NEW.cycle_data_usage_mb,
        projected_data_usage_mb = NEW.projected_data_usage_mb,
        communication_plan = NEW.communication_plan,
        msisdn = NEW.msisdn,
        iccid = NEW.iccid,
        usage_date = NEW.usage_date,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        amop_device_id = NEW.amop_device_id,
        service_provider_id = NEW.service_provider_id,
        date_activated = NEW.date_activated,
        was_activated_in_this_billing_period = NEW.was_activated_in_this_billing_period,
        days_activated_in_billing_period = NEW.days_activated_in_billing_period,
        sms_usage = NEW.sms_usage,
        auto_change_rate_plan = NEW.auto_change_rate_plan,
		optimization_comm_group_id=NEW.optimization_comm_group_id
    WHERE did = OLD.id;  -- Update the row in optimization_smi where did matches the old id
    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_optimization_smi_from_mobility();

CREATE OR REPLACE FUNCTION public.update_optimization_smi_from_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    UPDATE public.optimization_smi
    SET
        instance_id = NEW.instance_id,
        device_id = NEW.device_id,
        cycle_data_usage_mb = NEW.cycle_data_usage_mb,
        projected_data_usage_mb = NEW.projected_data_usage_mb,
        communication_plan = NEW.communication_plan,
        msisdn = NEW.msisdn,
        iccid = NEW.iccid,
        usage_date = NEW.usage_date,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        amop_device_id = NEW.amop_device_id,
        service_provider_id = NEW.service_provider_id,
        date_activated = NEW.date_activated,
        was_activated_in_this_billing_period = NEW.was_activated_in_this_billing_period,
        days_activated_in_billing_period = NEW.days_activated_in_billing_period,
        sms_usage = NEW.sms_usage,
        optimization_rate_plan_type_id = NEW.optimization_rate_plan_type_id,
        optimization_group_id = NEW.optimization_group_id,
        auto_change_rate_plan = NEW.auto_change_rate_plan,
		optimization_comm_group_id=NEW.optimization_comm_group_id
    WHERE mid = OLD.id;  -- Match on the 'did' column in optimization_smi

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_optimization_smi_result_cust_chargeq_frm_mobility();

CREATE OR REPLACE FUNCTION public.update_optimization_smi_result_cust_chargeq_frm_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    UPDATE public.optimization_smi_result_customer_charge_queue
    SET
        optimization_mobility_device_result_id = NEW.optimization_mobility_device_result_id,
        is_processed = NEW.is_processed,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        modified_by = NEW.modified_by,
        modified_date = NEW.modified_date,
        charge_amount = NEW.charge_amount,
        charge_id = NEW.charge_id,
        base_charge_amount = NEW.base_charge_amount,
        total_charge_amount = NEW.total_charge_amount,
        has_errors = NEW.has_errors,
        error_message = NEW.error_message,
        rev_service_number = NEW.rev_service_number,
        rev_product_type_id = NEW.rev_product_type_id,
        uploaded_file_id = NEW.uploaded_file_id,
        billing_start_date = NEW.billing_start_date,
        billing_end_date = NEW.billing_end_date,
        description = NEW.description,
        integration_authentication_id = NEW.integration_authentication_id,
        billing_period_id = NEW.billing_period_id,
        sms_rev_product_type_id = NEW.sms_rev_product_type_id,
        sms_charge_amount = NEW.sms_charge_amount,
        sms_charge_id = NEW.sms_charge_id,
        rate_charge_amt = NEW.rate_charge_amt,
        overage_charge_amt = NEW.overage_charge_amt,
        base_rate_amt = NEW.base_rate_amt,
        overage_rev_product_type_id = NEW.overage_rev_product_type_id,
        rev_product_id = NEW.rev_product_id,
        sms_rev_product_id = NEW.sms_rev_product_id,
        overage_rev_product_id = NEW.overage_rev_product_id
    WHERE mid = OLD.id;  -- Match based on the corresponding ID

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_optimization_smi_result_customer_chargeq_frm_device();

CREATE OR REPLACE FUNCTION public.update_optimization_smi_result_customer_chargeq_frm_device()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$

BEGIN
    UPDATE public.optimization_smi_result_customer_charge_queue
    SET
        optimization_device_result_id = NEW.optimization_device_result_id,
        is_processed = NEW.is_processed,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        modified_by = NEW.modified_by,
        modified_date = NEW.modified_date,
        charge_amount = NEW.charge_amount,
        charge_id = NEW.charge_id,
        base_charge_amount = NEW.base_charge_amount,
        total_charge_amount = NEW.total_charge_amount,
        has_errors = NEW.has_errors,
        error_message = NEW.error_message,
        rev_service_number = NEW.rev_service_number,
        rev_product_type_id = NEW.rev_product_type_id,
        uploaded_file_id = NEW.uploaded_file_id,
        billing_start_date = NEW.billing_start_date,
        billing_end_date = NEW.billing_end_date,
        description = NEW.description,
        integration_authentication_id = NEW.integration_authentication_id,
        billing_period_id = NEW.billing_period_id,
        sms_rev_product_type_id = NEW.sms_rev_product_type_id,
        sms_charge_amount = NEW.sms_charge_amount,
        sms_charge_id = NEW.sms_charge_id,
        rate_charge_amt = NEW.rate_charge_amt,
        overage_charge_amt = NEW.overage_charge_amt,
        base_rate_amt = NEW.base_rate_amt,
        overage_rev_product_type_id = NEW.overage_rev_product_type_id,
        rev_product_id = NEW.rev_product_id,
        sms_rev_product_id = NEW.sms_rev_product_id,
        overage_rev_product_id = NEW.overage_rev_product_id
    WHERE did = OLD.id;  -- Match the row in optimization_smi_result_customer_charge_queue based on the did

    RETURN NEW;
END;
$function$
;



-- DROP FUNCTION public.update_optimization_smi_result_from_device_result();

CREATE OR REPLACE FUNCTION public.update_optimization_smi_result_from_device_result()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    RAISE LOG
        'SMI UPDATE trigger start | op=% | old_id=% | new_id=% | pid=% | txid=%',
        TG_OP,
        OLD.id,
        NEW.id,
        pg_backend_pid(),
        txid_current();

    RAISE LOG
        'SMI UPDATE before update | did=% | time=%',
        OLD.id,
        clock_timestamp();

    UPDATE public.optimization_smi_result
    SET
        queue_id = NEW.queue_id,
        device_id = NEW.device_id,
        usage_mb = NEW.usage_mb,
        assigned_carrier_rate_plan_id = NEW.assigned_carrier_rate_plan_id,
        assigned_customer_rate_plan_id = NEW.assigned_customer_rate_plan_id,
        customer_rate_pool_id = NEW.customer_rate_pool_id,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        amop_device_id = NEW.amop_device_id,
        charge_amt = NEW.charge_amt,
        billing_period_id = NEW.billing_period_id,
        sms_usage = NEW.sms_usage,
        sms_charge_amount = NEW.sms_charge_amount,
        base_rate_amt = NEW.base_rate_amt,
        rate_charge_amt = NEW.rate_charge_amt,
        overage_charge_amt = NEW.overage_charge_amt
    WHERE did = OLD.id;

    RAISE LOG
        'SMI UPDATE after update | did=% | rows_affected=% | time=%',
        OLD.id,
        FOUND,
        clock_timestamp();

    RETURN NEW;
END;
$function$
;


-- DROP FUNCTION public.update_optimization_smi_result_from_mobility_device_result();

CREATE OR REPLACE FUNCTION public.update_optimization_smi_result_from_mobility_device_result()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    UPDATE public.optimization_smi_result
    SET
        queue_id = NEW.queue_id,
        device_id = NEW.device_id,
        usage_mb = NEW.usage_mb,
        assigned_carrier_rate_plan_id = NEW.assigned_carrier_rate_plan_id,
        assigned_customer_rate_plan_id = NEW.assigned_customer_rate_plan_id,
        customer_rate_pool_id = NEW.customer_rate_pool_id,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        amop_device_id = NEW.amop_device_id,
        charge_amt = NEW.charge_amt,
        billing_period_id = NEW.billing_period_id,
        sms_usage = NEW.sms_usage,
        sms_charge_amount = NEW.sms_charge_amount,
        base_rate_amt = NEW.base_rate_amt,
        rate_charge_amt = NEW.rate_charge_amt,
        overage_charge_amt = NEW.overage_charge_amt
    WHERE mid = OLD.id;  -- Match on the 'did' column in optimization_smi_result

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_optimization_smi_result_rate_plan_queue_frm_mobility();

CREATE OR REPLACE FUNCTION public.update_optimization_smi_result_rate_plan_queue_frm_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- Log the incoming values for debugging
    --RAISE NOTICE 'Trigger fired for update: ID = %, Mobility ID = %', NEW.id, NEW.optimization_mobility_device_result_id;

    UPDATE public.optimization_smi_result_rate_plan_queue
    SET
        optimization_device_result_id = NEW.optimization_mobility_device_result_id,
        is_processed = NEW.is_processed,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        modified_by = NEW.modified_by,
        modified_date = NEW.modified_date,
        group_number = NEW.group_number,
        has_errors = NEW.has_errors,
        error_message = NEW.error_message
    WHERE mid = OLD.id;  -- Match the row in optimization_smi_result_rate_plan_queue based on the id (did)

    -- Log successful update
    --RAISE NOTICE 'Successfully updated optimization_smi_result_rate_plan_queue for Mobility ID: %', NEW.id;

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_optimization_smi_result_rate_plan_queue_from_device();

CREATE OR REPLACE FUNCTION public.update_optimization_smi_result_rate_plan_queue_from_device()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    UPDATE public.optimization_smi_result_rate_plan_queue
    SET
        optimization_device_result_id = NEW.optimization_device_result_id,
        is_processed = NEW.is_processed,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        modified_by = NEW.modified_by,
        modified_date = NEW.modified_date,
        group_number = NEW.group_number,
        has_errors = NEW.has_errors,
        error_message = NEW.error_message
    WHERE did = OLD.id;  -- Use OLD.id to reference the row before the update

    RETURN NEW;
END;
$function$
;


-- DROP FUNCTION public.insert_intosim_managementbulkchangerequestfrommobilitychange();

CREATE OR REPLACE FUNCTION public.insert_intosim_managementbulkchangerequestfrommobilitychange()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
INSERT INTO public.sim_management_bulk_change_request (
    bulk_change_id,
    subscriber_number,
    change_request,
    device_id,
    is_processed,
    has_errors,
    status,
    status_details,
    processed_date,
    processed_by,
    created_by,
    modified_by,
    modified_date,
    deleted_by,
    deleted_date,
    is_active,
    iccid,
    additional_step_status,
    additional_step_details,
    ip_address,
    device_change_request_id,
	mobility_id	
)
VALUES(
  new.bulk_change_id,
    new.subscriber_number,
    new.change_request,
    new.device_id,
    new.is_processed,
    new.has_errors,
    new.status,
    new.status_details,
    new.processed_date,
    new.processed_by,
    new.created_by,
    new.modified_by,
    new.modified_date,
    new.deleted_by,
    new.deleted_date,
    new.is_active,
    new.iccid,
    new.additional_step_status,
    new.additional_step_details,
    new.ip_address,
    new.device_change_request_id,
	new.id
);
    RETURN NEW; 
END;
$function$
;


CREATE OR REPLACE FUNCTION public.insert_intosimmanagementbulkchangerequestfromm2m()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
BEGIN
    INSERT INTO public.sim_management_bulk_change_request (
        bulk_change_id,
        iccid,
        msisdn,
        ip_address,
        change_request,
        device_id,
        is_processed,
        has_errors,
        status,
        status_details,
        processed_date,
        processed_by,
        created_by,
        created_date,
        modified_by,
        modified_date,
        deleted_by,
        deleted_date,
        is_active,
        device_change_request_id,
        m2m_id
    )
    VALUES (
        NEW.bulk_change_id,
        NEW.iccid,
        NEW.msisdn,
        NEW.ip_address,
        NEW.change_request,
        NEW.device_id,
        NEW.is_processed,
        NEW.has_errors,
        NEW.status,
        NEW.status_details,
        NEW.processed_date,
        NEW.processed_by,
        NEW.created_by,
        NEW.created_date,
        NEW.modified_by,
        NEW.modified_date,
        NEW.deleted_by,
        NEW.deleted_date,
        NEW.is_active,
        NEW.device_change_request_id,
        NEW.id
    );

    RETURN NEW;
END;
$BODY$;



-- DROP FUNCTION public.update_sim_management_bulk_change_request_from_mobility();

CREATE OR REPLACE FUNCTION public.update_sim_management_bulk_change_request_from_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO public.sim_management_bulk_change_request (
        bulk_change_id,
        subscriber_number,
        change_request,
        device_id,
        is_processed,
        has_errors,
        status,
        status_details,
        processed_date,
        processed_by,
        created_by,
        modified_by,
        modified_date,
        deleted_by,
        deleted_date,
        is_active,
        iccid,
        additional_step_status,
        additional_step_details,
        ip_address,
        device_change_request_id,
        mobility_id
    )
    VALUES (
        NEW.bulk_change_id,
        NEW.subscriber_number,
        NEW.change_request,
        NEW.device_id,
        NEW.is_processed,
        NEW.has_errors,
        NEW.status,
        NEW.status_details,
        NEW.processed_date,
        NEW.processed_by,
        NEW.created_by,
        NEW.modified_by,
        NEW.modified_date,
        NEW.deleted_by,
        NEW.deleted_date,
        NEW.is_active,
        NEW.iccid,
        NEW.additional_step_status,
        NEW.additional_step_details,
        NEW.ip_address,
        NEW.device_change_request_id,
        NEW.id
    );

    RETURN NEW; 
END;
$function$
;


-- DROP FUNCTION public.insert_inventory_history_from_mobility();

CREATE OR REPLACE FUNCTION public.insert_inventory_history_from_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- Insert into sim_management_inventory_history from mobility_device_history
    INSERT INTO public.sim_management_inventory_history (
        changed_date,
        id,
        service_provider_id,
        foundation_account_number,
        billing_account_number,
        iccid,
        imsi,
        msisdn,
        imei,
        device_status_id,
        status,
        carrier_rate_plan_id,
        rate_plan,
        last_usage_date,
        carrier_cycle_usage,
        ctd_sms_usage,
        ctd_voice_usage,
        ctd_session_count,
        created_by,
        created_date,
        modified_by,
        modified_date,
        last_activated_date,
        deleted_by,
        deleted_date,
        is_active,
        account_number,
        provider_date_added,
        provider_date_activated,
        old_device_status_id,
        old_ctd_data_usage,
        account_number_integration_authentication_id,
        billing_period_id,
        customer_id,
        single_user_code,
        single_user_code_description,
        service_zip_code,
        data_group_id,
        pool_id,
        device_make,
        device_model,
        contract_status,
        ban_status,
        imei_type_id,
        plan_limit_mb,
        customer_rate_plan_id,
        customer_data_allocation_mb,
        username,
        customer_rate_pool_id,
        mobility_device_tenant_id,
        tenant_id,
        ip_address,
        is_pushed,
        m_device_history_id  -- Add device_history_id from mobility_device_history
    )
    VALUES (
        NEW.changed_date,
        NEW.id,
        NEW.service_provider_id,
        NEW.foundation_account_number,
        NEW.billing_account_number,
        NEW.iccid,
        NEW.imsi,
        NEW.msisdn,
        NEW.imei,
        NEW.device_status_id,
        NEW.status,
        NEW.carrier_rate_plan_id,
        NEW.rate_plan,
        NEW.last_usage_date,
        NEW.carrier_cycle_usage,
        NEW.ctd_sms_usage,
        NEW.ctd_voice_usage,
        NEW.ctd_session_count,
        NEW.created_by,
        NEW.created_date,
        NEW.modified_by,
        NEW.modified_date,
        NEW.last_activated_date,
        NEW.deleted_by,
        NEW.deleted_date,
        NEW.is_active,
        NEW.account_number,
        NEW.provider_date_added,
        NEW.provider_date_activated,
        NEW.old_device_status_id,
        NEW.old_ctd_data_usage,
        NEW.account_number_integration_authentication_id,
        NEW.billing_period_id,
        NEW.customer_id,
        NEW.single_user_code,
        NEW.single_user_code_description,
        NEW.service_zip_code,
        NEW.data_group_id,
        NEW.pool_id,
        NEW.device_make,
        NEW.device_model,
        NEW.contract_status,
        NEW.ban_status,
        NEW.imei_type_id,
        NEW.plan_limit_mb,
        NEW.customer_rate_plan_id,
        NEW.customer_data_allocation_mb,
        NEW.username,
        NEW.customer_rate_pool_id,
        NEW.mobility_device_tenant_id,
        NEW.tenant_id,
        NEW.ip_address,
        NEW.is_pushed,
        NEW.device_history_id  -- Insert the device_history_id from mobility_device_history into m_device_history_id
    );

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.insert_into_inventory_history();

CREATE OR REPLACE FUNCTION public.insert_into_inventory_history()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- Insert the new device history record into sim_management_inventory_history
    INSERT INTO public.sim_management_inventory_history (
        changed_date,
        id,
        d_device_history_id, -- Assign the device_history_id to this field
        service_provider_id,
        iccid,
        imsi,
        msisdn,
        imei,
        device_status_id,
        status,
        carrier_rate_plan_id,
        rate_plan,
        last_usage_date,
        apn,
        carrier_cycle_usage,
        ctd_sms_usage,
        ctd_voice_usage,
        ctd_session_count,
        created_by,
        created_date,
        modified_by,
        modified_date,
        last_activated_date,
        deleted_by,
        deleted_date,
        is_active,
        is_deleted,
        account_number,
        provider_date_added,
        provider_date_activated,
        old_device_status_id,
        old_ctd_data_usage,
        account_number_integration_authentication_id,
        billing_period_id,
        customer_rate_plan_id,
        customer_rate_pool_id,
        device_tenant_id,
        tenant_id,
        "package",
        billing_cycle_end_date,
        bill_year,
        bill_month,
        overage_limit_reached,
        overage_limit_override,
        cost_center,
        username,
        is_pushed
    )
    VALUES (
        NEW.changed_date,
        NEW.id,
        NEW.device_history_id,  -- Assign the device_history_id from the new record
        NEW.service_provider_id,
        NEW.iccid,
        NEW.imsi,
        NEW.msisdn,
        NEW.imei,
        NEW.device_status_id,
        NEW.status,
        NEW.carrier_rate_plan_id,
        NEW.rate_plan,
        NEW.last_usage_date,
        NEW.apn,
        NEW.carrier_cycle_usage,
        NEW.ctd_sms_usage,
        NEW.ctd_voice_usage,
        NEW.ctd_session_count,
        NEW.created_by,
        NEW.created_date,
        NEW.modified_by,
        NEW.modified_date,
        NEW.last_activated_date,
        NEW.deleted_by,
        NEW.deleted_date,
        NEW.is_active,
        NEW.is_deleted,
        NEW.account_number,
        NEW.provider_date_added,
        NEW.provider_date_activated,
        NEW.old_device_status_id,
        NEW.old_ctd_data_usage,
        NEW.account_number_integration_authentication_id,
        NEW.billing_period_id,
        NEW.customer_rate_plan_id,
        NEW.customer_rate_pool_id,
        NEW.device_tenant_id,
        NEW.tenant_id,
        NEW."package",
        NEW.billing_cycle_end_date,
        NEW.bill_year,
        NEW.bill_month,
        NEW.overage_limit_reached,
        NEW.overage_limit_override,
        NEW.cost_center,
        NEW.username,
        NEW.is_pushed
    );

    -- Return the new record
    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_inventory_history();

CREATE OR REPLACE FUNCTION public.update_inventory_history()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- Update the corresponding record in sim_management_inventory_history
    UPDATE public.sim_management_inventory_history
    SET
        changed_date = NEW.changed_date,
        id = NEW.id,
        service_provider_id = NEW.service_provider_id,
        iccid = NEW.iccid,
        imsi = NEW.imsi,
        msisdn = NEW.msisdn,
        imei = NEW.imei,
        device_status_id = NEW.device_status_id,
        status = NEW.status,
        carrier_rate_plan_id = NEW.carrier_rate_plan_id,
        rate_plan = NEW.rate_plan,
        last_usage_date = NEW.last_usage_date,
        apn = NEW.apn,
        carrier_cycle_usage = NEW.carrier_cycle_usage,
        ctd_sms_usage = NEW.ctd_sms_usage,
        ctd_voice_usage = NEW.ctd_voice_usage,
        ctd_session_count = NEW.ctd_session_count,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        modified_by = NEW.modified_by,
        modified_date = NEW.modified_date,
        last_activated_date = NEW.last_activated_date,
        deleted_by = NEW.deleted_by,
        deleted_date = NEW.deleted_date,
        is_active = NEW.is_active,
        is_deleted = NEW.is_deleted,
        account_number = NEW.account_number,
        provider_date_added = NEW.provider_date_added,
        provider_date_activated = NEW.provider_date_activated,
        old_device_status_id = NEW.old_device_status_id,
        old_ctd_data_usage = NEW.old_ctd_data_usage,
        account_number_integration_authentication_id = NEW.account_number_integration_authentication_id,
        billing_period_id = NEW.billing_period_id,
        customer_rate_plan_id = NEW.customer_rate_plan_id,
        customer_rate_pool_id = NEW.customer_rate_pool_id,
        device_tenant_id = NEW.device_tenant_id,
        tenant_id = NEW.tenant_id,
        "package" = NEW."package",
        billing_cycle_end_date = NEW.billing_cycle_end_date,
        bill_year = NEW.bill_year,
        bill_month = NEW.bill_month,
        overage_limit_reached = NEW.overage_limit_reached,
        overage_limit_override = NEW.overage_limit_override,
        cost_center = NEW.cost_center,
        username = NEW.username,
        is_pushed = NEW.is_pushed
    WHERE d_device_history_id = OLD.device_history_id;  -- Use the OLD.device_history_id to match the correct row

    -- Return the updated row
    RETURN NEW;
END;
$function$
;


-- DROP FUNCTION public.update_inventory_history_from_mobility();

CREATE OR REPLACE FUNCTION public.update_inventory_history_from_mobility()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- Update the corresponding record in sim_management_inventory_history
    UPDATE public.sim_management_inventory_history
    SET
        changed_date = NEW.changed_date,
        id = NEW.id,
        service_provider_id = NEW.service_provider_id,
        foundation_account_number = NEW.foundation_account_number,
        billing_account_number = NEW.billing_account_number,
        iccid = NEW.iccid,
        imsi = NEW.imsi,
        msisdn = NEW.msisdn,
        imei = NEW.imei,
        device_status_id = NEW.device_status_id,
        status = NEW.status,
        carrier_rate_plan_id = NEW.carrier_rate_plan_id,
        rate_plan = NEW.rate_plan,
        last_usage_date = NEW.last_usage_date,
        carrier_cycle_usage = NEW.carrier_cycle_usage,
        ctd_sms_usage = NEW.ctd_sms_usage,
        ctd_voice_usage = NEW.ctd_voice_usage,
        ctd_session_count = NEW.ctd_session_count,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        modified_by = NEW.modified_by,
        modified_date = NEW.modified_date,
        last_activated_date = NEW.last_activated_date,
        deleted_by = NEW.deleted_by,
        deleted_date = NEW.deleted_date,
        is_active = NEW.is_active,
		is_deleted=New.is_deleted,
        account_number = NEW.account_number,
        provider_date_added = NEW.provider_date_added,
        provider_date_activated = NEW.provider_date_activated,
        old_device_status_id = NEW.old_device_status_id,
        old_ctd_data_usage = NEW.old_ctd_data_usage,
        account_number_integration_authentication_id = NEW.account_number_integration_authentication_id,
        billing_period_id = NEW.billing_period_id,
        customer_id = NEW.customer_id,
        single_user_code = NEW.single_user_code,
        single_user_code_description = NEW.single_user_code_description,
        service_zip_code = NEW.service_zip_code,
        data_group_id = NEW.data_group_id,
        pool_id = NEW.pool_id,
        device_make = NEW.device_make,
        device_model = NEW.device_model,
        contract_status = NEW.contract_status,
        ban_status = NEW.ban_status,
        imei_type_id = NEW.imei_type_id,
        plan_limit_mb = NEW.plan_limit_mb,
        customer_rate_plan_id = NEW.customer_rate_plan_id,
        customer_data_allocation_mb = NEW.customer_data_allocation_mb,
        username = NEW.username,
        customer_rate_pool_id = NEW.customer_rate_pool_id,
        mobility_device_tenant_id = NEW.mobility_device_tenant_id,
        tenant_id = NEW.tenant_id,
        ip_address = NEW.ip_address,
        is_pushed = NEW.is_pushed
    WHERE m_device_history_id = OLD.device_history_id;  -- Match using OLD.device_history_id

    RETURN NEW;
END;
$function$
;




CREATE OR REPLACE FUNCTION public.insert_into_sim_management_inventory_test_from_mobility()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$

DECLARE
update_flag_insert text;
BEGIN
update_flag_insert := current_setting('myvars.insert_in_progress', true);
IF update_flag_insert IS NOT NULL AND update_flag_insert = 'true' THEN
        RETURN NEW;
    END IF;
	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.insert_in_progress', 'true', true);
    RAISE NOTICE '1-Starting insert_into_sim_management_inventory_test function for mobility_device_id: %', NEW.id;
    INSERT INTO sim_management_inventory (
        mobility_device_id, 
        mdt_id,
        tenant_id,
        service_provider_id,
        service_provider_display_name,
        integration_id,
        billing_account_number,
        foundation_account_number,
        iccid,
        imsi,
       msisdn,
        imei,
        customer_id,
       customer_name,
        parent_customer_id,
        rev_customer_id,
        rev_customer_name,
        rev_parent_customer_id,
        device_status_id,
        sim_status,
        carrier_cycle_usage_bytes,
        carrier_cycle_usage_mb,
        date_added,
        date_activated,
        account_number,
        carrier_rate_plan_id,
        carrier_rate_plan_name,
       customer_cycle_usage_mb,
        customer_rate_pool_id,
        customer_rate_pool_name,
        customer_rate_plan_id,
       customer_rate_plan_name,
       customer_rate_plan_code,
        sms_count,
        minutes_used,
        username,
        is_active_status,
        ip_address,
        service_zip_code,
        rate_plan_soc,
        rate_plan_soc_description,
        data_group_id,
        pool_id,
        next_bill_cycle_date,
        device_make,
        device_model,
        contract_status,
        ban_status,
        imei_type_id,
        plan_limit_mb,
        customer_data_allocation_mb,
        billing_cycle_start_date,
       billing_cycle_end_date,
        customer_rate_plan_mb,
        customer_rate_plan_allows_sim_pooling,
        carrier_rate_plan_mb,
        telegence_features,
        ebonding_features,
        last_usage_date,
        created_by,
        created_date,
        modified_by,
        modified_date,
        last_activated_date,
        deleted_by,
        deleted_date,
        is_active,
        is_deleted,
        cost_center,
        soc,
		billing_period_id,
		ctd_sms_usage,
		ctd_session_count,
		ctd_voice_usage,
		rev_service_id,
		account_number_integration_authentication_id,
	delta_ctd_data_usage,
	technology_type,
		optimization_group_id,
		tenant_is_active,
		 tenant_is_deleted,
		 service_provider_is_active
   )
SELECT
        md.id as mobility_device_id, 
        mdt.id as mdt_id,
        mdt.tenant_id,
        md.service_provider_id,
        sp.display_name as service_provider_display_name,
        sp.integration_id,
        md.billing_account_number,
        md.foundation_account_number,
        md.iccid,
        md.imsi,
       md.msisdn,
       md.imei,
        mdt.customer_id,
        COALESCE(rc.customer_name, c.customer_name) AS customername,
        c.parent_customer_id,
        rc.rev_customer_id,
        rc.customer_name,
        rc.rev_parent_customer_id,
        md.device_status_id,
        ds.display_name as sim_status,
        md.carrier_cycle_usage as carrier_cycle_usage_bytes,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
           ELSE round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS carrier_cycle_usage_mb,
        md.date_added,
        md.date_activated,
        mdt.account_number,
        md.carrier_rate_plan_id,
        COALESCE(crp.friendly_name, md.carrier_rate_plan) AS carrier_rate_plan_name,
      CASE
            WHEN c.customer_bill_period_end_day IS NOT NULL AND c.customer_bill_period_end_hour IS NOT NULL THEN 
                ROUND(get_current_cycle_usage_bytes(md.id, mdt.tenant_id) / 1024.0 / 1024.0, 3)
            ELSE 
                ROUND(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS customer_cycle_usage_mb,
        mdt.customer_rate_pool_id,
        cpool.name as customer_rate_pool_name,
        mdt.customer_rate_plan_id,
        custrp.rate_plan_name as customer_rate_plan_name,
        custrp.rate_plan_code as customer_rate_plan_code,
        md.sms_count,
        md.minutes_used,
        md.username,
        ds.is_active_status,
        md.ip_address,
        md.service_zip_code,
        md.Single_User_Code AS rate_plan_soc,
        md.single_user_code_description as rate_plan_soc_description,
       md.data_group_id,
       md.pool_id,
       md.next_bill_cycle_date,
        md.device_make,
        md.device_model,
        md.contract_status,
        md.ban_status,
        md.imei_type_id,
        md.plan_limit_mb,
       mdt.customer_data_allocation_mb,
        bp.billing_cycle_start_date,
        bp.billing_cycle_end_date,
       custrp.plan_mb as customer_rate_plan_mb,
        custrp.allows_sim_pooling as customer_rate_plan_allows_sim_pooling,
        crp.plan_mb as carrier_rate_plan_mb,
        (SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
            FROM telegence_device_mobility_feature tdmf
            JOIN mobility_feature mf ON mf.id = tdmf.mobility_feature_id
            WHERE td.id IS NOT NULL AND tdmf.is_deleted = false AND tdmf.is_active = true AND tdmf.telegence_device_id = td.id AND mf.is_deleted = false AND mf.is_active = true AND mf.is_retired = false
        ) AS telegence_feature,
        (SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
            FROM e_bonding_device_mobility_feature ebdmf
            JOIN mobility_feature mf ON mf.id = ebdmf.mobility_feature_id
            WHERE e_bonding_device.id IS NOT NULL AND ebdmf.is_deleted = false AND ebdmf.is_active = true AND ebdmf.e_bonding_device_id = e_bonding_device.id AND mf.is_deleted = false AND mf.is_active = true AND mf.is_retired = false
       ) AS e_bonding_feature,
        md.last_usage_date,
       md.created_by,
        md.created_date,
        md.modified_by,
        md.modified_date,
        md.last_activated_date,
      md.deleted_by,
        md.deleted_date,
        md.is_active,
        md.is_deleted,
        md.cost_center_1 as cost_center1,
        md.soc,
		md.billing_period_id,
		md.ctd_sms_usage,
		md.ctd_session_count,
		md.ctd_voice_usage,
		mdt.rev_service_id,
		mdt.account_number_integration_authentication_id,
		md.delta_ctd_data_usage,
		md.technology_type,
	md.optimization_group_id,
	mdt.is_active as tenant_is_active,
		mdt.is_deleted as tenant_is_deleted,
		CASE 
    WHEN sp.is_active = true THEN true 
    ELSE false 
END AS service_provider_is_active
    FROM mobility_device md
    JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id 
    JOIN  serviceprovider sp ON md.service_provider_id = sp.id
    LEFT JOIN  device_status ds ON ds.id = md.device_status_id
    LEFT JOIN customers c ON c.id = mdt.customer_id AND c.is_active = true AND c.is_deleted = false
    LEFT JOIN 
	    revcustomer rc ON c.rev_customer_id = rc.id AND rc.is_active = true AND rc.is_deleted = false
	LEFT JOIN 
	    integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false 
	LEFT JOIN 
	    carrier_rate_plan crp ON crp.id = md.carrier_rate_plan_id
	LEFT JOIN customerrateplan custrp ON custrp.id=mdt.customer_rate_plan_id 
	LEFT JOIN customer_rate_pool cpool ON cpool.id = mdt.customer_rate_pool_id 
	LEFT JOIN billing_period bp ON bp.id = md.billing_period_id 
	LEFT JOIN telegence_device td ON td.subscriber_number = md.msisdn AND td.service_provider_id = md.service_provider_id and td.is_active=true
	LEFT JOIN e_bonding_device ON e_bonding_device.subscriber_number = md.msisdn AND e_bonding_device.service_provider_id = md.service_provider_id
	--LEFT JOIN vw_mobility_customer_current_cycle_device_usage ON vw_mobility_customer_current_cycle_device_usage.mobility_device_id = md.id AND vw_mobility_customer_current_cycle_device_usage.tenant_id = mdt.tenant_id
	left join public.sim_management_inventory sm on sm.mdt_id=mdt.id
	where mdt.mobility_device_id=new.id --and md.is_active=True and md.is_deleted=false and i.portal_type_id=2 
	and NOT EXISTS (
        SELECT 1 FROM sim_management_inventory s WHERE s.mdt_id = mdt.id
    )  and  mdt.is_active=true and mdt.is_deleted=false
	;
	RAISE NOTICE 'Insert into sim_management_inventory succeeded for id: %', NEW.id;
	 PERFORM set_config('myvars.insert_in_progress', 'false', true);
    RETURN NEW;
   EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Trigger failed for mobility_device_id %: %', NEW.id, SQLERRM;
END;
$BODY$;


CREATE OR REPLACE FUNCTION public.update_into_sim_management_inventory_test_from_mobility()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$

DECLARE 
update_flag text;
    error_id BIGINT;
    error_iccid TEXT;

BEGIN
    RAISE NOTICE 'Starting update_into_sim_management_inventory_test function for mobility_device_id: %', NEW.id;

    RAISE NOTICE 'Updating Record: id: %, service_provider_id: %, iccid: %, msisdn: %, device_status_id: %', 
                 NEW.id, NEW.service_provider_id, NEW.iccid, NEW.msisdn, NEW.device_status_id;
 -- Get the session variable safely (returns NULL if not set)
update_flag := current_setting('myvars.update_in_progress', true);
IF update_flag IS NOT NULL AND update_flag = 'true' THEN
        RETURN NEW;
    END IF;

	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.update_in_progress', 'true', true);
	
    -- Set a custom session variable to track the source
	--PERFORM set_config('custom.smi_update_source', 'mobility_device_trigger', true);
  -- Capture id and iccid
        error_id := NEW.id;
        error_iccid := NEW.iccid;
    UPDATE sim_management_inventory
    SET
        mobility_device_id = NEW.id,
        mdt_id = mdt.id,
        tenant_id = mdt.tenant_id,
        service_provider_id = NEW.service_provider_id,
        service_provider_display_name = sp.display_name,
        integration_id = sp.integration_id,
        billing_account_number = NEW.billing_account_number,
        foundation_account_number = NEW.foundation_account_number,
        iccid = NEW.iccid,
        imsi = NEW.imsi,
        msisdn = NEW.msisdn,
        imei = NEW.imei,
        customer_id = mdt.customer_id,
        customer_name = COALESCE(rc.customer_name, c.customer_name),
        parent_customer_id = c.parent_customer_id,
        rev_customer_id = rc.rev_customer_id,
        rev_customer_name = rc.customer_name,
        rev_parent_customer_id = rc.rev_parent_customer_id,
        device_status_id = NEW.device_status_id,
        sim_status = ds.display_name,
        carrier_cycle_usage_bytes = NEW.carrier_cycle_usage,
        carrier_cycle_usage_mb = CASE
            WHEN i.id = 12 THEN round(COALESCE(NEW.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(NEW.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END,
        date_added = NEW.date_added,
        date_activated = NEW.date_activated,
        account_number = mdt.account_number,
        carrier_rate_plan_id = NEW.carrier_rate_plan_id,
        carrier_rate_plan_name = COALESCE(crp.friendly_name, NEW.carrier_rate_plan),
       
        customer_rate_pool_name = cpool.name,
        customer_rate_plan_name = custrp.rate_plan_name,
        customer_rate_plan_code = custrp.rate_plan_code,
        sms_count = NEW.sms_count,
        minutes_used = NEW.minutes_used,
        username = COALESCE(NEW.amop_username, NEW.username),
        is_Active_status = ds.is_active_status,
        ip_address = NEW.ip_address,
        service_zip_code = NEW.service_zip_code,
        rate_plan_soc = NEW.Single_User_Code,
        rate_plan_soc_description = NEW.single_user_code_description,
        data_group_id = NEW.data_group_id,
        pool_id = NEW.pool_id,
        next_bill_cycle_date = NEW.next_bill_cycle_date,
        device_make = NEW.device_make,
        device_model = NEW.device_model,
        contract_status = NEW.contract_status,
        ban_status = NEW.ban_status,
        imei_type_id = NEW.imei_type_id,
        plan_limit_mb = NEW.plan_limit_mb,
        customer_data_allocation_mb = mdt.customer_data_allocation_mb,
        billing_cycle_start_date = bp.billing_cycle_start_date,
        billing_cycle_end_date = bp.billing_cycle_end_date,
        customer_rate_plan_mb = custrp.plan_mb,
        customer_rate_plan_allows_sim_pooling = custrp.allows_sim_pooling,
        carrier_rate_plan_mb = crp.plan_mb,
        telegence_features = (SELECT string_agg(mf.soc_code::text, ','::text) FROM telegence_device_mobility_feature tdmf
            JOIN mobility_feature mf ON mf.id = tdmf.mobility_feature_id
            WHERE tdmf.is_deleted = false AND tdmf.is_active = true AND tdmf.telegence_device_id = td.id AND mf.is_deleted = false AND mf.is_active = true AND mf.is_retired = false),
        ebonding_features = (SELECT string_agg(mf.soc_code::text, ','::text) FROM e_bonding_device_mobility_feature ebdmf
            JOIN mobility_feature mf ON mf.id = ebdmf.mobility_feature_id
            WHERE ebdmf.is_deleted = false AND ebdmf.is_active = true AND ebdmf.e_bonding_device_id = e_bonding_device.id AND mf.is_deleted = false AND mf.is_active = true AND mf.is_retired = false),
        last_usage_date = NEW.last_usage_date,
        created_by = NEW.created_by,
        created_date = NEW.created_date,
        modified_by = NEW.modified_by,
        modified_date = NEW.modified_date,
        last_activated_date = NEW.last_activated_date,
        deleted_by = NEW.deleted_by,
        deleted_date = NEW.deleted_date,
        is_active = NEW.is_active,
        is_deleted = NEW.is_deleted,
        cost_center = NEW.cost_center_1,
		soc=new.soc,
		billing_period_id=NEW.billing_period_id,
		ctd_sms_usage=NEW.ctd_sms_usage,
		ctd_session_count=NEW.ctd_session_count,
		ctd_voice_usage=NEW.ctd_voice_usage,
		rev_service_id=mdt.rev_service_id,
		account_number_integration_authentication_id=mdt.account_number_integration_authentication_id,
		technology_type=NEW.technology_type,
		delta_ctd_data_usage=New.delta_ctd_data_usage,
		optimization_group_id=NEW.optimization_group_id,
		customer_cycle_usage_mb=CASE
            WHEN c.customer_bill_period_end_day IS NOT NULL AND c.customer_bill_period_end_hour IS NOT NULL THEN 
                ROUND(get_current_cycle_usage_bytes(md.id, mdt.tenant_id) / 1024.0 / 1024.0, 3)
            ELSE 
                ROUND(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        end,
        service_provider_is_active = CASE 
		    WHEN sp.is_active = true THEN true
		    ELSE false
		END,
		sub_tenant_carrier_rate_plan_name_id=mdt.sub_tenant_carrier_rate_plan_name_id,
		sub_tenant_carrier_rate_plan_name=mdt.sub_tenant_carrier_rate_plan_name
    FROM 
        mobility_device md
    JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id
    JOIN serviceprovider sp ON md.service_provider_id = sp.id
    LEFT JOIN device_status ds ON ds.id = md.device_status_id
    LEFT JOIN customers c ON c.id = mdt.customer_id AND c.is_active = true AND c.is_deleted = false
    LEFT JOIN revcustomer rc ON c.rev_customer_id = rc.id AND rc.is_active = true AND rc.is_deleted = false
    LEFT JOIN integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false AND i.portal_type_id = 2
    LEFT JOIN carrier_rate_plan crp ON crp.id = md.carrier_rate_plan_id
    LEFT JOIN customerrateplan custrp ON custrp.id = mdt.customer_rate_plan_id
    LEFT JOIN customer_rate_pool cpool ON cpool.id = mdt.customer_rate_pool_id
    LEFT JOIN billing_period bp ON bp.id = md.billing_period_id
    LEFT JOIN telegence_device td ON td.subscriber_number = md.msisdn AND td.service_provider_id = md.service_provider_id and td.is_active=true
    LEFT JOIN e_bonding_device ON e_bonding_device.subscriber_number = NEW.msisdn AND e_bonding_device.service_provider_id = md.service_provider_id
    where mdt.mobility_device_id=new.id 
	and sim_management_inventory.mobility_device_id=old.id
	and mdt.id=sim_management_inventory.mdt_id;
    PERFORM set_config('myvars.update_in_progress', 'false', true);
	 RETURN NEW;
	EXCEPTION 
        WHEN OTHERS THEN
            -- Capture error message and store it in error_log_table
            INSERT INTO trigger_error_logs (trigger_name, error_msg, error_id, error_iccid,trigger_table)
            VALUES ('update_into_sim_management_inventory_test_from_mobility', SQLERRM, error_id, error_iccid,'mobility_device');

            RAISE NOTICE 'Error inserting data: %, ID: %, ICCID: %', SQLERRM, error_id, error_iccid;
    RETURN NEW;

END;
$BODY$;

-- DROP FUNCTION public.insert_into_smi_test_from_device();

CREATE OR REPLACE FUNCTION public.insert_into_smi_test_from_device()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$

DECLARE

update_flag_insert text;

BEGIN

update_flag_insert := current_setting('myvars.insert_in_progress', true);
IF update_flag_insert IS NOT NULL AND update_flag_insert = 'true' THEN
        RETURN NEW;
    END IF; 
	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.insert_in_progress', 'true', true);
insert into public.sim_management_inventory(
   last_usage_date,
   dt_id,
   device_id,
   service_provider_id,
   service_provider_display_name,
   integration_id,
   iccid,
   msisdn,
   imei,
   eid,
   carrier_cycle_usage_bytes,
   carrier_rate_plan_name,
   carrier_cycle_usage_mb,
   date_added,
   date_activated,
   created_by,
   created_date,
   modified_by,
   modified_date,
   deleted_by,
   deleted_date,
   is_active,
   is_deleted,
   account_number,
   cost_center,
   username,
   carrier_rate_plan_id,
   device_status_id,
   sim_status,
   is_active_status,
   tenant_id,
   rev_customer_id,
   rev_customer_name,
   rev_parent_customer_id,
   customer_id,
   parent_customer_id,
   customer_name,
   customer_rate_plan_id,
   customer_rate_plan_code,
   customer_rate_plan_name,
   sms_count,
   communication_plan,
   ip_address,
   customer_rate_pool_id,
   customer_rate_pool_name,
   carrier_rate_plan_mb,
   soc,
   billing_cycle_start_date,
   billing_cycle_end_date,
   billing_period_id,
	ctd_sms_usage,
	ctd_session_count,
	package,
	overage_limit_reached,
	overage_limit_override,
	device_description,
    ctd_voice_usage,
	rev_service_id,
	account_number_integration_authentication_id,
	customer_data_allocation_mb,
    customer_rate_plan_mb,
    customer_rate_plan_allows_sim_pooling,
	tenant_is_active,
	tenant_is_deleted,
	customer_cycle_usage_mb,
	service_provider_is_active
)  
select smi.last_usage_date,
       dt.id as dt_id,
	   smi.id as device_id,
	   smi.service_provider_id,
	   sp.display_name as service_provider_display_name,
	   sp.integration_id,
	   smi.iccid,
	   smi.msisdn,
	   smi.imei,
	   smi.eid,
	   smi.carrier_cycle_usage as carrier_cycle_usage_bytes,
	   COALESCE(carrier_rate_plan.friendly_name, smi.carrier_rate_plan) AS carrier_rate_plan_name,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS carrier_cycle_usage_mb,

        CASE
            WHEN sp.integration_id IN (1, 4, 9, 11, 15)
                THEN smi.date_added
            ELSE
                COALESCE(date_added.date_of_change, smi.date_added)
        END AS date_added,

        CASE
            WHEN sp.integration_id IN (1, 4, 9, 11, 15)
                THEN smi.date_activated
            ELSE
                COALESCE(date_activated.date_of_change, smi.date_activated)
        END AS date_activated,
	   --COALESCE(date_added.date_of_change, smi.date_added) AS date_added,
       --COALESCE(date_activated.date_of_change, smi.date_activated) AS date_activated,
	   smi.created_by,
       smi.created_date,
       smi.modified_by,
       smi.modified_date,
       smi.deleted_by,
       smi.deleted_date,
      smi.is_active,
       smi.is_deleted,
	   dt.account_number,
	   smi.cost_center,
       smi.username,
	   smi.carrier_rate_plan_id,
	   smi.device_status_id,
	   ds.display_name as sim_status,
       ds.is_active_status,
       dt.tenant_id,
       revcust.rev_customer_id,
       revcust.customer_name as rev_customer_name,
       revcust.rev_parent_customer_id,
       cust.id as customer_id,
      cust.parent_customer_id,
       cust.customer_name, 
       dt.customer_rate_plan_id,
       customerrateplan.rate_plan_code AS customer_rate_plan_code,
       customerrateplan.rate_plan_name customer_rate_plan_name,
       smi.ctd_sms_usage as sms_count,
       smi.communication_plan,
       smi.ip_address,
       dt.customer_rate_pool_id, 
       customer_rate_pool.name AS customer_rate_pool_name,
        carrier_rate_plan.plan_mb as carrier_rate_plan_mb,
		smi.soc,
		bp.billing_cycle_start_date,
        bp.billing_cycle_end_date,
		smi.billing_period_id,
		smi.ctd_sms_usage,
		smi.ctd_session_count,
		smi.package,
		smi.overage_limit_reached,
		smi.overage_limit_override,
		smi.device_description,
		smi.ctd_voice_usage,
		dt.rev_service_id,
		dt.account_number_integration_authentication_id,
		dt.customer_data_allocation_mb,
       customerrateplan.plan_mb as customer_rate_plan_mb,
        customerrateplan.allows_sim_pooling as customer_rate_plan_allows_sim_pooling,
		dt.is_active as tenant_is_active,
		dt.is_deleted as tenant_is_deleted,
		CASE
            WHEN cust.customer_bill_period_end_day IS NOT NULL AND cust.customer_bill_period_end_hour IS NOT NULL THEN 
                ROUND(get_current_cycle_usage_bytes_m2m(smi.id, dt.tenant_id) / 1024.0 / 1024.0, 3)
            ELSE 
                ROUND(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END as customer_cycle_usage_mb,
        CASE 
		    WHEN sp.is_active = true THEN true
		    ELSE false
		END AS service_provider_is_active
		FROM device smi
		JOIN device_tenant dt ON smi.id = dt.device_id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id 
     LEFT JOIN device_status ds ON ds.id = smi.device_status_id
	 LEFT JOIN billing_period bp ON bp.id = smi.billing_period_id
     LEFT JOIN carrier_rate_plan carrier_rate_plan ON smi.carrier_rate_plan_id = carrier_rate_plan.id
     LEFT JOIN customers cust ON cust.id = dt.customer_id AND cust.is_active = true AND cust.is_deleted = false
     LEFT JOIN revcustomer revcust ON cust.rev_customer_id = revcust.id AND cust.is_active = true
     LEFT JOIN integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false AND i.portal_type_id = 0
     LEFT JOIN customerrateplan customerrateplan ON dt.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customer_rate_pool customer_rate_pool ON dt.customer_rate_pool_id = customer_rate_pool.id
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id AND ds.is_active_status = true))
          ORDER BY device_status_history.date_of_change
         LIMIT 1) date_added ON true
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id))
          ORDER BY device_status_history.date_of_change DESC
         LIMIT 1) date_activated ON true
		left join public.sim_management_inventory sm on sm.dt_id=dt.id
	where dt.device_id=new.id --and smi.is_active=True and smi.is_deleted=false and i.portal_type_id=0  
	AND NOT EXISTS (
        SELECT 1 FROM sim_management_inventory s WHERE s.dt_id = dt.id
    );
	 PERFORM set_config('myvars.insert_in_progress', 'false', true); 
RETURN NEW;
END;
$BODY$;

CREATE OR REPLACE FUNCTION public.update_smi_test_from_device()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$

BEGIN
     RAISE NOTICE 'Old value: %, New value: %,New value: %', OLD.iccid, NEW.iccid,NEW.id;
    UPDATE public.sim_management_inventory
    SET
        last_usage_date = new.last_usage_date,
        dt_id = dt.id,
        device_id = new.id,
        service_provider_id = new.service_provider_id,
        service_provider_display_name = sp.display_name,
        integration_id = sp.integration_id,
        iccid = new.iccid,
        msisdn = new.msisdn,
        imei = new.imei,
        eid = new.eid,
        carrier_cycle_usage_bytes = new.carrier_cycle_usage,
        carrier_rate_plan_name = COALESCE(carrier_rate_plan.friendly_name, new.carrier_rate_plan),
        carrier_cycle_usage_mb = CASE
            WHEN i.id = 12 THEN round(COALESCE(new.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(new.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END,
        date_added = COALESCE(date_added.date_of_change, new.date_added),
        date_activated = COALESCE(date_activated.date_of_change, new.date_activated),
        created_by = new.created_by,
        created_date = new.created_date,
        modified_by = new.modified_by,
        modified_date = new.modified_date,
        deleted_by = new.deleted_by,
        deleted_date = new.deleted_date,
        is_active = new.is_active,
        account_number = dt.account_number,
        cost_center = new.cost_center,
        username = new.username,
        carrier_rate_plan_id = new.carrier_rate_plan_id,
        device_status_id = new.device_status_id,
        sim_status = ds.display_name,
        is_active_status = ds.is_active_status,
        tenant_id = dt.tenant_id,
        rev_customer_id = revcust.rev_customer_id,
        rev_customer_name = revcust.customer_name,
        rev_parent_customer_id = revcust.rev_parent_customer_id,
        customer_id = cust.id,
        parent_customer_id = cust.parent_customer_id,
        customer_name = cust.customer_name,
        customer_rate_plan_id = dt.customer_rate_plan_id,
        customer_rate_plan_code = customerrateplan.rate_plan_code,
        customer_rate_plan_name = customerrateplan.rate_plan_name,
        sms_count = new.ctd_sms_usage,
        communication_plan = new.communication_plan,
        ip_address = new.ip_address,
        customer_rate_pool_id = dt.customer_rate_pool_id,
        customer_rate_pool_name = customer_rate_pool.name,
        customer_cycle_usage_mb = CASE
            WHEN cust.customer_bill_period_end_day IS NOT NULL AND cust.customer_bill_period_end_hour IS NOT NULL THEN
                convertbytestombbyintegrationid(COALESCE(vw_m2m_customer_current_cycle_device_usage.customer_cycle_usage_byte, 0.0)::bigint, sp.integration_id)
            ELSE
                convertbytestombbyintegrationid(COALESCE(new.carrier_cycle_usage::numeric, 0.0)::bigint, sp.integration_id)
        END,
        carrier_rate_plan_mb = carrier_rate_plan.plan_mb,
        soc = new.soc,
		billing_cycle_start_date=bp.billing_cycle_start_date,
        billing_cycle_end_date=bp.billing_cycle_end_date,
   billing_period_id=NEW.billing_period_id,
	ctd_sms_usage=NEW.ctd_sms_usage,
	ctd_session_count=NEW.ctd_session_count,
	package=NEW.package,
	overage_limit_reached=NEW.overage_limit_reached,
	overage_limit_override=NEW.overage_limit_override,
	device_description=NEW.device_description,
    ctd_voice_usage=NEW.ctd_voice_usage,
	rev_service_id=dt.rev_service_id,
	account_number_integration_authentication_id=dt.account_number_integration_authentication_id,
	customer_data_allocation_mb=dt.customer_data_allocation_mb,
      customer_rate_plan_mb=customerrateplan.plan_mb,
customer_rate_plan_allows_sim_pooling=customerrateplan.allows_sim_pooling
    FROM device smi
    JOIN device_tenant dt ON smi.id = dt.device_id
    JOIN serviceprovider sp ON smi.service_provider_id = sp.id
    LEFT JOIN device_status ds ON ds.id = smi.device_status_id
	 LEFT JOIN billing_period bp ON bp.id = smi.billing_period_id
    LEFT JOIN carrier_rate_plan carrier_rate_plan ON smi.carrier_rate_plan_id = carrier_rate_plan.id
    LEFT JOIN customers cust ON cust.id = dt.customer_id AND cust.is_active = true
    LEFT JOIN revcustomer revcust ON cust.rev_customer_id = revcust.id AND cust.is_active = true
    LEFT JOIN integration i ON i.id = sp.integration_id AND i.is_active = true  AND i.portal_type_id = 0
    LEFT JOIN customerrateplan customerrateplan ON dt.customer_rate_plan_id = customerrateplan.id
    LEFT JOIN customer_rate_pool customer_rate_pool ON dt.customer_rate_pool_id = customer_rate_pool.id
    LEFT JOIN vw_m2m_customer_current_cycle_device_usage ON vw_m2m_customer_current_cycle_device_usage.m2m_device_id = smi.id AND vw_m2m_customer_current_cycle_device_usage.tenant_id = dt.tenant_id
    LEFT JOIN LATERAL (
        SELECT device_status_history.date_of_change
        FROM device_status_history
        WHERE device_status_history.iccid::text = smi.iccid::text
        AND (device_status_history.current_status::text IN (
            SELECT device_status.status
            FROM device_status
            WHERE sp.integration_id = ds.integration_id AND ds.is_active_status = true
        ))
        ORDER BY device_status_history.date_of_change
        LIMIT 1
    ) date_added ON true
    LEFT JOIN LATERAL (
        SELECT device_status_history.date_of_change
        FROM device_status_history
        WHERE device_status_history.iccid::text = smi.iccid::text
        AND (device_status_history.current_status::text IN (
            SELECT device_status.status
            FROM device_status
            WHERE sp.integration_id = ds.integration_id
        ))
        ORDER BY device_status_history.date_of_change DESC
        LIMIT 1
    ) date_activated ON true
    WHERE dt.device_id=new.id and sim_management_inventory.device_id=old.id
	and dt.id=sim_management_inventory.dt_id;

    RETURN NEW;
END;
$BODY$;


CREATE OR REPLACE FUNCTION public.update_smi_frm_device_tenant()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$

BEGIN

RAISE NOTICE 'Before update for device_tenant with dt_id: %, device_id: %', OLD.id, OLD.device_id;

Update public.sim_management_inventory
set tenant_id=new.tenant_id,
     rev_service_id=new.rev_service_id,
	 customer_rate_plan_id=new.customer_rate_plan_id,
	 customer_data_allocation_mb=new.customer_data_allocation_mb,
	 customer_rate_pool_id=new.customer_rate_pool_id,
	 account_number=new.account_number,
	 account_number_integration_authentication_id=new.account_number_integration_authentication_id,
	 customer_id=new.customer_id ,
     parent_customer_id=cust.parent_customer_id,
     customer_name=new.customer_name,
	 customer_rate_plan_code=customerrateplan.rate_plan_code,
     customer_rate_plan_name=customerrateplan.rate_plan_name,
	 customer_rate_pool_name=customer_rate_pool.name,
	 customer_cycle_usage_mb=CASE
            WHEN cust.customer_bill_period_end_day IS NOT NULL AND cust.customer_bill_period_end_hour IS NOT NULL THEN convertbytestombbyintegrationid(COALESCE(vw_m2m_customer_current_cycle_device_usage.customer_cycle_usage_byte, 0.0)::bigint, sp.integration_id)
            ELSE convertbytestombbyintegrationid(COALESCE(smi.carrier_cycle_usage::numeric, 0.0)::bigint, sp.integration_id)
        END,
    customer_rate_plan_mb =customerrateplan.plan_mb,
    customer_rate_plan_allows_sim_pooling=customerrateplan.allows_sim_pooling
	 from device_tenant dt
	 JOIN device smi on NEW.device_id=smi.id
	 JOIN serviceprovider sp ON smi.service_provider_id = sp.id
	 JOIN customers cust ON cust.id = NEW.customer_id AND cust.is_active = true
	 LEFT JOIN customerrateplan customerrateplan ON NEW.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customer_rate_pool customer_rate_pool ON NEW.customer_rate_pool_id = customer_rate_pool.id
	 LEFT JOIN vw_m2m_customer_current_cycle_device_usage ON vw_m2m_customer_current_cycle_device_usage.m2m_device_id = smi.id AND vw_m2m_customer_current_cycle_device_usage.tenant_id = NEW.tenant_id
 WHERE sim_management_inventory.dt_id = OLD.id
      AND sim_management_inventory.device_id = OLD.device_id;

    RETURN NEW;
END;
$BODY$;

CREATE OR REPLACE FUNCTION public.update_smi_frm_mobility_device_tenant()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$

BEGIN
Update public.sim_management_inventory
set tenant_id=new.tenant_id,
     rev_service_id=new.rev_service_id,
	 customer_rate_plan_id=new.customer_rate_plan_id,
	 customer_data_allocation_mb=new.customer_data_allocation_mb,
	 customer_rate_pool_id=new.customer_rate_pool_id,
	 account_number=new.account_number,
	 account_number_integration_authentication_id=new.account_number_integration_authentication_id,
	 customer_id=NEW.customer_id ,
     parent_customer_id=cust.parent_customer_id,
     customer_name=NEW.customer_name,
	 customer_rate_plan_code=customerrateplan.rate_plan_code,
     customer_rate_plan_name=customerrateplan.rate_plan_name,
	 customer_rate_pool_name=customer_rate_pool.name,

	 customer_cycle_usage_mb=CASE
            WHEN cust.customer_bill_period_end_day IS NOT NULL AND cust.customer_bill_period_end_hour IS NOT NULL THEN round(COALESCE(vw_mobility_customer_current_cycle_device_usage.customer_cycle_usage_byte, 0.0) / 1024.0 / 1024.0, 3)
            ELSE round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END,
	customer_rate_plan_mb=customerrateplan.plan_mb,
	customer_rate_plan_allows_sim_pooling=customerrateplan.allows_sim_pooling
	 from mobility_device_tenant mdt
	 JOIN mobility_device smi on NEW.mobility_device_id=smi.id
	 LEFT JOIN customers cust ON cust.id = NEW.customer_id AND cust.is_active = true
	 LEFT JOIN customerrateplan customerrateplan ON NEW.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customer_rate_pool customer_rate_pool ON NEW.customer_rate_pool_id = customer_rate_pool.id
	 LEFT JOIN vw_mobility_customer_current_cycle_device_usage ON vw_mobility_customer_current_cycle_device_usage.mobility_device_id = smi.id AND vw_mobility_customer_current_cycle_device_usage.tenant_id = NEW.tenant_id
 WHERE new.id=sim_management_inventory.mdt_id;
    RETURN NEW;
END;
$BODY$;


CREATE OR REPLACE TRIGGER after_insert_optimization_device
    AFTER INSERT
    ON public.optimization_device
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_optimization_smi();


CREATE OR REPLACE TRIGGER after_update_optimization_device
    AFTER UPDATE
    ON public.optimization_device
    FOR EACH ROW
    EXECUTE FUNCTION public.update_optimization_smi();

CREATE OR REPLACE TRIGGER after_insert_optimization_device_result
    AFTER INSERT
    ON public.optimization_device_result
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_optimization_smi_result_from_device_result();

CREATE OR REPLACE TRIGGER after_update_optimization_device_result
    AFTER UPDATE
    ON public.optimization_device_result
    FOR EACH ROW
    EXECUTE FUNCTION public.update_optimization_smi_result_from_device_result();

CREATE OR REPLACE TRIGGER after_insert_optimization_device_result_customer_chargeq
    AFTER INSERT
    ON public.optimization_device_result_customer_charge_queue
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_to_optimization_smi_result_customer_chargeq_frm_device();

CREATE OR REPLACE TRIGGER after_update_optimization_device_result_rate_plan_queue_device
    AFTER UPDATE
    ON public.optimization_device_result_rate_plan_queue
    FOR EACH ROW
    EXECUTE FUNCTION public.update_optimization_smi_result_rate_plan_queue_from_device();

CREATE OR REPLACE TRIGGER after_insert_optimization_mobility_device
    AFTER INSERT
    ON public.optimization_mobility_device
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_optimization_smi_from_mobility();

CREATE OR REPLACE TRIGGER after_update_optimization_mobility_device
    AFTER UPDATE
    ON public.optimization_mobility_device
    FOR EACH ROW
    EXECUTE FUNCTION public.update_optimization_smi_from_mobility();

CREATE OR REPLACE TRIGGER after_insert_optimization_mobility_device_result
    AFTER INSERT
    ON public.optimization_mobility_device_result
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_optimization_smi_result_from_mobility_device_result();

CREATE OR REPLACE TRIGGER after_update_optimization_mobility_device_result
    AFTER UPDATE
    ON public.optimization_mobility_device_result
    FOR EACH ROW
    EXECUTE FUNCTION public.update_optimization_smi_result_from_mobility_device_result();


CREATE OR REPLACE TRIGGER after_insert_optimization_mobility_device_result_cust_chargeq
    AFTER INSERT
    ON public.optimization_mobility_device_result_customer_charge_queue
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_to_optimization_smi_result_cust_chargeq_frm_mobility();

CREATE OR REPLACE TRIGGER after_update_opt_mobility_device_result_customer_chargeq
    AFTER UPDATE
    ON public.optimization_mobility_device_result_customer_charge_queue
    FOR EACH ROW
    EXECUTE FUNCTION public.update_optimization_smi_result_cust_chargeq_frm_mobility();

CREATE OR REPLACE TRIGGER after_optimization_mobility_device_result_rate_plan_queue
    AFTER INSERT
    ON public.optimization_mobility_device_result_rate_plan_queue
    FOR EACH ROW
    EXECUTE FUNCTION public.insertto_optimization_smi_result_rate_plan_queue_from_mobility();

CREATE OR REPLACE TRIGGER after_update_optimization_mobility_device_result_rate_planq
    AFTER UPDATE
    ON public.optimization_mobility_device_result_rate_plan_queue
    FOR EACH ROW
    EXECUTE FUNCTION public.update_optimization_smi_result_rate_plan_queue_frm_mobility();

CREATE OR REPLACE TRIGGER after_insert_device_history
    AFTER INSERT
    ON public.device_history
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_inventory_history();

CREATE OR REPLACE TRIGGER after_update_device_history
    AFTER UPDATE
    ON public.device_history
    FOR EACH ROW
    EXECUTE FUNCTION public.update_inventory_history();

-- DROP FUNCTION public.insert_to_smi_bulkchange_frm_m2m();

CREATE OR REPLACE FUNCTION public.insert_to_smi_bulkchange_frm_m2m()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO public.sim_management_bulk_change_request (
        bulk_change_id,
        iccid,
        msisdn,
        ip_address,
        change_request,
        device_id,
        is_processed,
        has_errors,
        status,
        status_details,
        processed_date,
        processed_by,
        created_by,
        created_date,
        modified_by,
        modified_date,
        deleted_by,
        deleted_date,
        is_deleted,
        is_active,
        device_change_request_id,
        m2m_id
    )
    VALUES (
        NEW.bulk_change_id,
        NEW.iccid,
        NEW.msisdn,
        NEW.ip_address,
        NEW.change_request,
        NEW.device_id,
        NEW.is_processed,
        NEW.has_errors,
        NEW.status,
        NEW.status_details,
        NEW.processed_date,
        NEW.processed_by,
        NEW.created_by,
        NEW.created_date,
        NEW.modified_by,
        NEW.modified_date,
        NEW.deleted_by,
        NEW.deleted_date,
        NEW.is_deleted,
        NEW.is_active,
        NEW.device_change_request_id,
        NEW.id
    );

    RETURN NEW;
END;
$function$
;


CREATE OR REPLACE TRIGGER insert_sim_management_bulk_chng_req
    AFTER INSERT
    ON public.m2m_device_change
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_to_smi_bulkchange_frm_m2m();

CREATE OR REPLACE FUNCTION public.update_to_smi_bulkchange_frm_m2m()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
BEGIN
    UPDATE public.sim_management_bulk_change_request
    SET
        bulk_change_id = NEW.bulk_change_id,
        iccid = NEW.iccid,
        msisdn = NEW.msisdn,
        ip_address = NEW.ip_address,
        change_request = NEW.change_request,
        device_id = NEW.device_id,
        is_processed = NEW.is_processed,
        has_errors = NEW.has_errors,
        status = NEW.status,
        status_details = NEW.status_details,
        processed_date = NEW.processed_date,
        processed_by = NEW.processed_by,
        modified_by = NEW.modified_by,
        modified_date = NEW.modified_date,
        deleted_by = NEW.deleted_by,
        deleted_date = NEW.deleted_date,
        is_active = NEW.is_active,
        device_change_request_id = NEW.device_change_request_id
    WHERE m2m_id = new.id;

    RETURN NEW;
END;
$BODY$;

CREATE OR REPLACE TRIGGER update_sim_management_req
    AFTER UPDATE
    ON public.m2m_device_change
    FOR EACH ROW
    EXECUTE FUNCTION public.update_to_smi_bulkchange_frm_m2m();

CREATE OR REPLACE TRIGGER sim_management_bulk_change_request_trigger
    AFTER INSERT
    ON public.mobility_device_change
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_intosim_managementbulkchangerequestfrommobilitychange();

CREATE OR REPLACE TRIGGER sim_management_bulk_change_request_update_trigger
    AFTER UPDATE
    ON public.mobility_device_change
    FOR EACH ROW
    EXECUTE FUNCTION public.update_sim_management_bulk_change_request_from_mobility();
CREATE OR REPLACE TRIGGER after_insert_mobility_device_history
    AFTER INSERT
    ON public.mobility_device_history
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_inventory_history_from_mobility();


CREATE OR REPLACE TRIGGER after_update_mobility_device_history
    AFTER UPDATE
    ON public.mobility_device_history
    FOR EACH ROW
    EXECUTE FUNCTION public.update_inventory_history_from_mobility();

CREATE OR REPLACE TRIGGER insert_into_smi_from_device
    AFTER INSERT
    ON public.device
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_smi_test_from_device();


-- CREATE OR REPLACE TRIGGER update_into_smi_from_device
--     AFTER UPDATE
--     ON public.device
--     FOR EACH ROW
--     EXECUTE FUNCTION public.update_smi_test_from_device();

CREATE OR REPLACE TRIGGER update_into_smi_from_device_no_loop
    AFTER UPDATE 
    ON public.device
    FOR EACH ROW
    WHEN (old.* IS DISTINCT FROM new.* AND NOT (old.id_10 IS DISTINCT FROM new.id_10 AND old.apn::text IS DISTINCT FROM new.apn::text AND old.source_db::text IS DISTINCT FROM new.source_db::text AND old.source_id IS DISTINCT FROM new.source_id AND old.inv_source_id IS DISTINCT FROM new.inv_source_id AND true))
    EXECUTE FUNCTION public.update_smi_from_device();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.device for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.integration for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.serviceprovider for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.bandwidthaccount for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.bandwidth_customers for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.billing_period_status for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.billing_period for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.carrier_rate_plan for each row execute function update_sequence_after_insert();
   
create trigger update_sequence_after_insert_trigger after
insert
    on
    public.netsapiens_reseller for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.e911customers for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.integration_authentication for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.customers for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.customergroups for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.mobility_feature for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.customer_mobility_feature for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.device_status for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.sim_management_communication_plan for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.rev_provider for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.rev_service_type for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.rev_service for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.sim_management_inventory for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.service_provider_tenant_configuration for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.sim_management_bulk_change_type for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.sim_management_bulk_change for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.sim_management_bulk_change_request for each row execute function update_sequence_after_insert();



-- CREATE OR REPLACE TRIGGER update_smi_frm_device_tenant_trigger
--     AFTER UPDATE
--     ON public.device_tenant
--     FOR EACH ROW
--     EXECUTE FUNCTION public.update_smi_frm_device_tenant();

CREATE OR REPLACE TRIGGER after_update_mobility_device_test
    AFTER UPDATE 
    ON public.mobility_device
    FOR EACH ROW
    WHEN (old.* IS DISTINCT FROM new.* AND NOT (old.soc::text IS DISTINCT FROM new.soc::text AND old.rev_vw_device_status::text IS DISTINCT FROM new.rev_vw_device_status::text AND old.smi_id IS DISTINCT FROM new.smi_id AND old.updated_from_smi IS DISTINCT FROM new.updated_from_smi AND old.id_10 IS DISTINCT FROM new.id_10 AND old.source_db::text IS DISTINCT FROM new.source_db::text AND old.source_id IS DISTINCT FROM new.source_id AND old.inv_source_id IS DISTINCT FROM new.inv_source_id AND true))
    EXECUTE FUNCTION public.update_into_sim_management_inventory_test_from_mobility();


CREATE OR REPLACE TRIGGER insert_into_smi_from_mobility_device
    AFTER INSERT
    ON public.mobility_device
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_sim_management_inventory_test_from_mobility();


CREATE OR REPLACE TRIGGER update_smi_frm_mobility_device_tenant_trigger
    AFTER UPDATE
    ON public.mobility_device_tenant
    FOR EACH ROW
    EXECUTE FUNCTION public.update_smi_frm_mobility_device_tenant();


CREATE OR REPLACE FUNCTION public.set_assigned_value()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
BEGIN
    -- Check if the service_provider_id already exists in the table
    IF EXISTS (SELECT 1 FROM public.carrier_rate_plan WHERE service_provider = NEW.service_provider) THEN
        -- If it exists, set assigned to false
        NEW.assigned := true;
    ELSE
        -- If it does not exist, set assigned to true
        NEW.assigned := false;
    END IF;

    -- Return the new record with the updated assigned value
    RETURN NEW;
END;
$BODY$;

CREATE OR REPLACE FUNCTION public.update_processed_date()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
BEGIN
    NEW.processed_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$BODY$;


CREATE OR REPLACE FUNCTION public.update_service_provider_names_pool()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    displaynames TEXT;
BEGIN
    RAISE NOTICE 'Trigger fired for customerrateplan ID: %', NEW.id;
    RAISE NOTICE 'Original serviceproviderids: %', NEW.service_provider_ids;

    IF NEW.service_provider_ids IS NOT NULL THEN
        SELECT STRING_AGG(sp.display_name, ', ' ORDER BY sp.display_name)
        INTO displaynames
        FROM UNNEST(STRING_TO_ARRAY(NEW.service_provider_ids, ',')) AS spid(id)
        JOIN serviceprovider sp ON sp.id = spid.id::int;

        RAISE NOTICE 'Resolved from serviceproviderids: %', displaynames;

    ELSIF NEW.service_provider_id IS NOT NULL THEN
        SELECT sp.display_name
        INTO displaynames
        FROM serviceprovider sp
        WHERE sp.id = NEW.service_provider_id;

        RAISE NOTICE 'Resolved from service_provider_id: %', displaynames;
    ELSE
        displaynames := NULL;
        RAISE NOTICE 'No service provider ID(s) provided.';
    END IF;

    NEW.service_provider_name := displaynames;

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_rev_service_false_customer_rate_pool();

CREATE OR REPLACE FUNCTION public.update_rev_service_false_customer_rate_pool()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    existing_record JSONB;
    updated_json JSONB;
BEGIN
    -- Fetch the existing JSON data (single row assumption)
    SELECT rev_service_ids INTO existing_record FROM rev_service_false where id=3 LIMIT 1;

    -- If no record exists, initialize an empty JSONB object
    IF existing_record IS NULL THEN
        existing_record := '{}'::JSONB;
    END IF;

    -- If the trigger is fired from the rev_service table
    IF TG_TABLE_NAME = 'customer_rate_pool' THEN
        updated_json := jsonb_set(
            existing_record, 
            '{pool_id}', 
            (COALESCE(existing_record->'pool_id', '[]'::JSONB) || to_jsonb(NEW.id))
        );
    END IF;

    -- Ensure only a single row exists in rev_service_false
    INSERT INTO rev_service_false (id, rev_service_ids)
    VALUES (3, updated_json)
    ON CONFLICT (id) DO UPDATE
    SET rev_service_ids = updated_json;

    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.trg_set_serviceproviderids_insert()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    IF NEW.serviceproviderids IS NULL OR TRIM(NEW.serviceproviderids) = '' THEN
        NEW.serviceproviderids := NEW.service_provider_id::text;
    END IF;
    RETURN NEW;
END;
$function$
;


CREATE OR REPLACE FUNCTION public.update_display_rate()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    NEW.display_rate := NEW.base_rate + NEW.rate_charge_amt;
    RETURN NEW;
END;
$function$
;


-- DROP FUNCTION public.update_rev_service_false_customer();

CREATE OR REPLACE FUNCTION public.update_rev_service_false_customer()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    existing_record JSONB;
    updated_json JSONB;
BEGIN
    -- Fetch the existing JSON data (single row assumption)
    SELECT rev_service_ids INTO existing_record FROM rev_service_false where id=2 LIMIT 1;

    -- If no record exists, initialize an empty JSONB object
    IF existing_record IS NULL THEN
        existing_record := '{}'::JSONB;
    END IF;

    -- If the trigger is fired from the rev_service table
    IF TG_TABLE_NAME = 'customerrateplan' THEN
        updated_json := jsonb_set(
            existing_record, 
            '{id}', 
            (COALESCE(existing_record->'id', '[]'::JSONB) || to_jsonb(NEW.id))
        );
    END IF;

    -- Ensure only a single row exists in rev_service_false
    INSERT INTO rev_service_false (id, rev_service_ids)
    VALUES (2, updated_json)
    ON CONFLICT (id) DO UPDATE
    SET rev_service_ids = updated_json;

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.log_customerrateplan_changes();

CREATE OR REPLACE FUNCTION public.log_customerrateplan_changes()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO public.customerrateplan_audit(
        action,
        old_data,
        new_data,
        session_user_name,
        current_user_name,
        client_ip,
        application_name,
        action_timestamp
    )
    VALUES (
        TG_OP,
        CASE WHEN TG_OP IN ('UPDATE', 'DELETE') THEN row_to_json(OLD) ELSE NULL END,
        CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN row_to_json(NEW) ELSE NULL END,
        SESSION_USER,
        CURRENT_USER,
        inet_client_addr(),
        current_setting('application_name', true),
        statement_timestamp()
    );

    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.update_optimization_type()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$

BEGIN
    -- Apply logic only if optimization_type is NULL or empty
    IF NEW.optimization_type IS NULL OR NEW.optimization_type = '' THEN
        IF NEW.auto_change_rate_plan = TRUE THEN
            NEW.optimization_type := 'Auto Change Rate Plan';
        ELSE
            NEW.optimization_type := 'Cross customer pooling';
        END IF;
    END IF;

    RETURN NEW;
END;
$function$
;


-- DROP FUNCTION public.update_tenant_name();

CREATE OR REPLACE FUNCTION public.update_tenant_name()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_tenant_name TEXT;
BEGIN
    RAISE NOTICE 'Beginning update for customer_id: %, tenant_id: %', NEW.id, NEW.tenant_id;

    -- Fetch tenant_name from tenant table
    SELECT tenant_name INTO v_tenant_name
    FROM tenant
    WHERE id = NEW.tenant_id;

    -- Assign the fetched name to NEW.tenant_name (modifies the row before insert/update)
    NEW.tenant_name := v_tenant_name;

    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.sync_rev_customer_tenant_id()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- Update tenant_id in rev_customer based on customers.rev_customer_id
    UPDATE revcustomer
    SET tenant_id = NEW.tenant_id
    WHERE id = NEW.rev_customer_id;

    RETURN NEW;
END;
$function$
;


--CREATE OR REPLACE FUNCTION public.set_user_type()
-- RETURNS trigger
-- LANGUAGE plpgsql
--AS $function$
--
--BEGIN
--  IF NEW.billing_platform_flag = TRUE THEN
--    NEW.user_type := 'Billing Customer';
--  ELSE
--    NEW.user_type := 'Rev IO Customer';
--  END IF;
--  RETURN NEW;
--END;
--$function$
--;


CREATE OR REPLACE FUNCTION public.update_user_type()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$

BEGIN
  IF NEW.billing_platform_flag THEN
    NEW.user_type := 'Billing Customer';
  ELSE
    NEW.user_type := 'Rev IO Customer';
  END IF;

  RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.insert_into_device_or_mobility_device_from_smi();

CREATE OR REPLACE FUNCTION public.insert_into_device_or_mobility_device_from_smi()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$

DECLARE
update_flag_insert text;
new_device_id INT;
    new_device_tenant_id INT;
    new_mobility_device_id INT;
    new_mobility_device_tenant_id INT;
BEGIN
update_flag_insert := current_setting('myvars.insert_in_progress', true);
IF update_flag_insert IS NOT NULL AND update_flag_insert = 'true' THEN
        RETURN NEW;
    END IF;

	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.insert_in_progress', 'true', true);
    -- Check if the service_provider_id is 20, 35, or 6
    IF NEW.service_provider_id IN (6)
	 AND NEW.device_id IS NULL
       AND NEW.mobility_device_id IS NULL
       AND NEW.dt_id IS NULL
       AND NEW.mdt_id IS NULL THEN
       INSERT INTO mobility_device (service_provider_id, foundation_account_number,billing_account_number,iccid,imsi,msisdn,imei,
	   device_status_id,sim_status,carrier_rate_plan_id,carrier_rate_plan,last_usage_date,carrier_cycle_usage,ctd_sms_usage,
	   ctd_voice_usage,ctd_session_count,created_by,created_date,modified_by,modified_date,last_activated_date,deleted_by,
	   deleted_date,is_active,is_deleted,date_added,date_activated,delta_ctd_data_usage,billing_period_id,single_user_code,
	   single_user_code_description,service_zip_code,next_bill_cycle_date,sms_count,minutes_used,data_group_id,pool_id,
	   device_make,device_model,contract_status,ban_status,imei_type_id,plan_limit_mb,
	   username,technology_type,ip_address,optimization_group_id,cost_center_1,smi_id)

	   VALUES (
	   NEW.service_provider_id, NEW.foundation_account_number,NEW.billing_account_number,NEW.iccid,NEW.imsi,NEW.msisdn,NEW.imei,
	   NEW.device_status_id,NEW.sim_status,NEW.carrier_rate_plan_id,NEW.carrier_rate_plan_name,New.last_usage_date,NEW.carrier_cycle_usage_bytes,NEW.ctd_sms_usage,
	   NEW.ctd_voice_usage,NEW.ctd_session_count,NEW.created_by,NEW.created_date,NEW.modified_by,NEW.modified_date,NEW.last_activated_date,NEW.deleted_by,
	   NEW.deleted_date,NEW.is_active,NEW.is_deleted,NEW.date_added,NEW.date_activated,NEW.delta_ctd_data_usage,NEW.billing_period_id,NEW.rate_plan_soc,
	   NEW.rate_plan_soc_description,NEW.service_zip_code,NEW.next_bill_cycle_date,NEW.sms_count,NEW.minutes_used,NEW.data_group_id,NEW.pool_id,
	   NEW.device_make,NEW.device_model,NEW.contract_status,NEW.ban_status,NEW.imei_type_id,NEW.plan_limit_mb,
	   NEW.username,NEW.technology_type,NEW.ip_address,NEW.optimization_group_id,NEW.cost_center,new.id)
	   RETURNING id INTO new_mobility_device_id;

	   INSERT INTO mobility_device_tenant(
	   mobility_device_id,tenant_id,rev_service_id,customer_rate_plan_id,customer_data_allocation_mb,
	   customer_rate_pool_id,account_number,customer_id,customer_name,account_number_integration_authentication_id,created_by,
	   created_date,modified_by,modified_date,deleted_by,deleted_date,is_active,is_deleted,customer_rate_plan_name,customer_rate_pool_name)
	   VALUES (
new_mobility_device_id,NEW.tenant_id,NEW.rev_service_id,NEW.customer_rate_plan_id,NEW.customer_data_allocation_mb,
	   NEW.customer_rate_pool_id,NEW.account_number,NEW.customer_id,NEW.customer_name,NEW.account_number_integration_authentication_id,NEW.created_by,
	   NEW.created_date,NEW.modified_by,NEW.modified_date,NEW.deleted_by,NEW.deleted_date,NEW.is_active,NEW.is_deleted,NEW.customer_rate_plan_name,NEW.customer_rate_pool_name)
	   RETURNING id INTO new_mobility_device_tenant_id;
	   PERFORM set_config('myvars.update_in_progress', 'true', true);
	   UPDATE sim_management_inventory
        SET mobility_device_id = new_mobility_device_id,
            mdt_id = new_mobility_device_tenant_id
        WHERE id = NEW.id;
		PERFORM set_config('myvars.update_in_progress', 'false', true);

    ELSE
	IF NEW.service_provider_id not IN (6)
	 AND NEW.device_id IS NULL
       AND NEW.mobility_device_id IS NULL
       AND NEW.dt_id IS NULL
       AND NEW.mdt_id IS NULL THEN
        -- Insert into device and device_tenant
        INSERT INTO device (service_provider_id,iccid,imsi,msisdn,imei,eid,device_status_id,sim_status,
		carrier_rate_plan_id,carrier_rate_plan,communication_plan,last_usage_date,package,billing_cycle_end_date,
		carrier_cycle_usage,ctd_sms_usage,ctd_voice_usage,ctd_session_count,overage_limit_reached,overage_limit_override,
		created_by,created_date,modified_by,modified_date,last_activated_date,deleted_by,deleted_date,is_active,is_deleted,
		delta_ctd_data_usage,cost_center,username,billing_period_id,device_description,ip_address,smi_id)
        VALUES (NEW.service_provider_id,NEW.iccid,NEW.imsi,NEW.msisdn,NEW.imei,NEW.eid,NEW.device_status_id,NEW.sim_status,
		NEW.carrier_rate_plan_id,NEW.carrier_rate_plan_name,NEW.communication_plan,NEW.last_usage_date,NEW.package,NEW.billing_cycle_end_date,
		NEW.carrier_cycle_usage_bytes,NEW.ctd_sms_usage,NEW.ctd_voice_usage,NEW.ctd_session_count,NEW.overage_limit_reached,NEW.overage_limit_override,
		NEW.created_by,NEW.created_date,NEW.modified_by,NEW.modified_date,NEW.last_activated_date,NEW.deleted_by,NEW.deleted_date,NEW.is_active,NEW.is_deleted,
		NEW.delta_ctd_data_usage,NEW.cost_center,NEW.username,NEW.billing_period_id,NEW.device_description,NEW.ip_address,NEW.id)
		RETURNING id INTO new_device_id;

        INSERT INTO device_tenant (device_id,tenant_id,rev_service_id,customer_rate_plan_id,customer_data_allocation_mb,customer_rate_pool_id,
		account_number,customer_id,account_number_integration_authentication_id,created_by,created_date,
		modified_by,modified_date,deleted_by,deleted_date,is_active,is_deleted,customer_rate_pool_name,customer_rate_plan_name,customer_name)
        VALUES (new_device_id,NEW.tenant_id,NEW.rev_service_id,NEW.customer_rate_plan_id,NEW.customer_data_allocation_mb,NEW.customer_rate_pool_id,
		NEW.account_number,NEW.customer_id,NEW.account_number_integration_authentication_id,NEW.created_by,NEW.created_date,
		NEW.modified_by,NEW.modified_date,NEW.deleted_by,NEW.deleted_date,NEW.is_active,NEW.is_deleted,NEW.customer_rate_pool_name,NEW.customer_rate_plan_name,
		NEW.customer_name)
		RETURNING id INTO new_device_tenant_id;
		PERFORM set_config('myvars.update_in_progress', 'true', true);
		 UPDATE sim_management_inventory
            SET device_id = new_device_id,
                dt_id = new_device_tenant_id
            WHERE id = NEW.id;
		PERFORM set_config('myvars.update_in_progress', 'false', true);
		PERFORM set_config('myvars.update_in_progress', 'false', true);
    END IF;
    END IF;
  PERFORM set_config('myvars.insert_in_progress', 'false', true);
    RETURN NEW;
END;
$BODY$;

-- DROP FUNCTION public.insert_into_inventory_if_not_exists_device_tenant();

CREATE OR REPLACE FUNCTION public.insert_into_inventory_if_not_exists_device_tenant()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$


DECLARE
update_flag_insert text;
BEGIN
update_flag_insert := current_setting('myvars.insert_in_progress', true);
IF update_flag_insert IS NOT NULL AND update_flag_insert = 'true' THEN
        RETURN NEW;
    END IF;

	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.insert_in_progress', 'true', true);
  insert into public.sim_management_inventory(
   last_usage_date,
   dt_id,
   device_id,
   service_provider_id,
   service_provider_display_name,
   integration_id,
   iccid,
   msisdn,
   imei,
   eid,
   carrier_cycle_usage_bytes,
   carrier_rate_plan_name,
   carrier_cycle_usage_mb,
   date_added,
   date_activated,
   created_by,
   created_date,
   modified_by,
   modified_date,
   deleted_by,
   deleted_date,
   is_active,
   is_deleted,
   account_number,
   cost_center,
   username,
   carrier_rate_plan_id,
   device_status_id,
   sim_status,
   is_active_status,
   tenant_id,
   rev_customer_id,
   rev_customer_name,
   rev_parent_customer_id,
   customer_id,
   parent_customer_id,
   customer_name,
   customer_rate_plan_id,
   customer_rate_plan_code,
   customer_rate_plan_name,
   sms_count,
   communication_plan,
   ip_address,
   customer_rate_pool_id,
   customer_rate_pool_name,
   carrier_rate_plan_mb,
   soc,
   billing_cycle_start_date,
   billing_cycle_end_date,
   billing_period_id,
	ctd_sms_usage,
	ctd_session_count,
	package,
	overage_limit_reached,
	overage_limit_override,
	device_description,
    ctd_voice_usage,
	rev_service_id,
	account_number_integration_authentication_id,
	customer_data_allocation_mb,
    customer_rate_plan_mb,
    customer_rate_plan_allows_sim_pooling,
	tenant_is_active,
	tenant_is_deleted,
--	sub_tenant_customer_rate_plan_name,
	sub_tenant_carrier_rate_plan_name,
	customer_cycle_usage_mb,
	 service_provider_is_active,
	 last_status_date,
	deactivation_date,
	source_id,
	source_db
   
)
select smi.last_usage_date,
       dt.id as dt_id,
  smi.id as device_id,
  smi.service_provider_id,
  sp.display_name as service_provider_display_name,
  sp.integration_id,
  smi.iccid,
  smi.msisdn,
  smi.imei,
  smi.eid,
  smi.carrier_cycle_usage as carrier_cycle_usage_bytes,
  COALESCE(carrier_rate_plan.friendly_name, smi.carrier_rate_plan) AS carrier_rate_plan_name,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS carrier_cycle_usage_mb,
  -- COALESCE(date_added.date_of_change, smi.date_added) AS date_added,
  --      COALESCE(date_activated.date_of_change, smi.date_activated) AS date_activated,
  CASE
    WHEN sp.integration_id IN (1, 4, 9, 11, 15)
        THEN smi.date_added
    ELSE
        COALESCE(date_added.date_of_change, smi.date_added)
END AS date_added,

CASE
    WHEN sp.integration_id IN (1, 4, 9, 11, 15)
        THEN smi.date_activated
    ELSE
        COALESCE(date_activated.date_of_change, smi.date_activated)
END AS date_activated,
  smi.created_by,
       smi.created_date,
       smi.modified_by,
       smi.modified_date,
       smi.deleted_by,
       smi.deleted_date,
       smi.is_active,
       smi.is_deleted,
  dt.account_number,
  smi.cost_center,
       smi.username,
  smi.carrier_rate_plan_id,
  smi.device_status_id,
  ds.display_name as sim_status,
       ds.is_active_status,
       dt.tenant_id,
       revcust.rev_customer_id,
       revcust.customer_name as rev_customer_name,
       revcust.rev_parent_customer_id,
       cust.id as customer_id,
       cust.parent_customer_id,
       cust.customer_name, 
       dt.customer_rate_plan_id,
       customerrateplan.rate_plan_code AS customer_rate_plan_code,
       customerrateplan.rate_plan_name customer_rate_plan_name,
       smi.ctd_sms_usage as sms_count,
       smi.communication_plan,
       smi.ip_address,
       dt.customer_rate_pool_id, 
       customer_rate_pool.name AS customer_rate_pool_name,
        carrier_rate_plan.plan_mb as carrier_rate_plan_mb,
		smi.soc,
		bp.billing_cycle_start_date,
        bp.billing_cycle_end_date,
		smi.billing_period_id,
		smi.ctd_sms_usage,
		smi.ctd_session_count,
		smi.package,
		smi.overage_limit_reached,
		smi.overage_limit_override,
		smi.device_description,
		smi.ctd_voice_usage,
		dt.rev_service_id,
		dt.account_number_integration_authentication_id,
		dt.customer_data_allocation_mb,
        customerrateplan.plan_mb as customer_rate_plan_mb,
        customerrateplan.allows_sim_pooling as customer_rate_plan_allows_sim_pooling,
		dt.is_active as tenant_is_active,
		dt.is_deleted as tenant_is_deleted,
--		COALESCE(carrier_rate_plan.friendly_name, smi.carrier_rate_plan) AS sub_tenant_customer_rate_plan_name,
		customerrateplan.rate_plan_name as sub_tenant_carrier_rate_plan_name,
		CASE
            WHEN cust.customer_bill_period_end_day IS NOT NULL AND cust.customer_bill_period_end_hour IS NOT NULL THEN 
                ROUND(get_current_cycle_usage_bytes_m2m(smi.id, dt.tenant_id) / 1024.0 / 1024.0, 3)
            ELSE 
                ROUND(COALESCE(smi.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END as customer_cycle_usage_mb,
		 CASE 
			    WHEN sp.is_active = true THEN true
			    ELSE false
			END as service_provider_is_active,
		smi.last_status_date,
		smi.deactivation_date,
		smi.inv_source_id,
		smi.source_db
		FROM device smi
		JOIN device_tenant dt ON smi.id = dt.device_id
     JOIN serviceprovider sp ON smi.service_provider_id = sp.id
     LEFT JOIN device_status ds ON ds.id = smi.device_status_id
	 LEFT JOIN billing_period bp ON bp.id = smi.billing_period_id
     LEFT JOIN carrier_rate_plan carrier_rate_plan ON smi.carrier_rate_plan_id = carrier_rate_plan.id
     LEFT JOIN customers cust ON cust.id = dt.customer_id AND cust.is_active = true AND cust.is_deleted = false
     LEFT JOIN revcustomer revcust ON cust.rev_customer_id = revcust.id AND cust.is_active = true
     LEFT JOIN integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false AND i.portal_type_id = 0
     LEFT JOIN customerrateplan customerrateplan ON dt.customer_rate_plan_id = customerrateplan.id
     LEFT JOIN customer_rate_pool customer_rate_pool ON dt.customer_rate_pool_id = customer_rate_pool.id
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id AND ds.is_active_status = true))
          ORDER BY device_status_history.date_of_change
         LIMIT 1) date_added ON true
     LEFT JOIN LATERAL ( SELECT device_status_history.date_of_change
           FROM device_status_history
          WHERE device_status_history.iccid::text = smi.iccid::text AND (device_status_history.current_status::text IN ( SELECT device_status.status
                   FROM device_status
                  WHERE sp.integration_id = ds.integration_id))
          ORDER BY device_status_history.date_of_change DESC
         LIMIT 1) date_activated ON true
	left join public.sim_management_inventory sm on sm.dt_id=dt.id
	where  NEW.device_id=smi.id --and smi.is_active=True and smi.is_deleted=false and i.portal_type_id=0 
	AND NOT EXISTS (
        SELECT 1 FROM sim_management_inventory s WHERE s.dt_id = dt.id
    ) ;
 PERFORM set_config('myvars.insert_in_progress', 'false', true);
  RETURN NEW;
END;
$BODY$;

CREATE OR REPLACE TRIGGER trg_insert_inventory_dev_tenant_id
    AFTER INSERT
    ON public.device_tenant
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_inventory_if_not_exists_device_tenant();


CREATE OR REPLACE FUNCTION public.insert_into_inventory_if_not_exists_mob_device_tenant()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
DECLARE
update_flag_insert text;
BEGIN
update_flag_insert := current_setting('myvars.insert_in_progress', true);
IF update_flag_insert IS NOT NULL AND update_flag_insert = 'true' THEN
        RETURN NEW;
    END IF;

	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.insert_in_progress', 'true', true);
INSERT INTO sim_management_inventory (
        mobility_device_id, 
        mdt_id,
        tenant_id,
        service_provider_id,
        service_provider_display_name,
        integration_id,
        billing_account_number,
        foundation_account_number,
        iccid,
        imsi,
        msisdn,
        imei,
        customer_id,
        customer_name,
        parent_customer_id,
        rev_customer_id,
        rev_customer_name,
        rev_parent_customer_id,
        device_status_id,
        sim_status,
        carrier_cycle_usage_bytes,
        carrier_cycle_usage_mb,
        date_added,
        date_activated,
        account_number,
        carrier_rate_plan_id,
        carrier_rate_plan_name,
       customer_cycle_usage_mb,
        customer_rate_pool_id,
        customer_rate_pool_name,
        customer_rate_plan_id,
        customer_rate_plan_name,
        customer_rate_plan_code,
        sms_count,
        minutes_used,
        username,
        is_active_status,
        ip_address,
        service_zip_code,
        rate_plan_soc,
        rate_plan_soc_description,
        data_group_id,
        pool_id,
        next_bill_cycle_date,
        device_make,
        device_model,
        contract_status,
        ban_status,
        imei_type_id,
        plan_limit_mb,
        customer_data_allocation_mb,
        billing_cycle_start_date,
        billing_cycle_end_date,
        customer_rate_plan_mb,
        customer_rate_plan_allows_sim_pooling,
        carrier_rate_plan_mb,
        telegence_features,
        ebonding_features,
        last_usage_date,
        created_by,
        created_date,
        modified_by,
        modified_date,
        last_activated_date,
        deleted_by,
        deleted_date,
        is_active,
        is_deleted,
        cost_center,
        soc,
		billing_period_id,
		ctd_sms_usage,
		ctd_session_count,
		ctd_voice_usage,
		rev_service_id,
		account_number_integration_authentication_id,
		delta_ctd_data_usage,
		technology_type,
		optimization_group_id,
		tenant_is_active,
		 tenant_is_deleted,
         service_provider_is_active,
--		 sub_tenant_customer_rate_plan_name,
--	sub_tenant_carrier_rate_plan_name,
	source_db,
	source_id

    )
SELECT
        md.id as mobility_device_id, 
        mdt.id as mdt_id,
        mdt.tenant_id,
        md.service_provider_id,
        sp.display_name as service_provider_display_name,
        sp.integration_id,
        md.billing_account_number,
        md.foundation_account_number,
        md.iccid,
        md.imsi,
        md.msisdn,
        md.imei,
        mdt.customer_id,
        c.customer_name,
        c.parent_customer_id,
        rc.rev_customer_id,
        rc.customer_name,
        rc.rev_parent_customer_id,
        md.device_status_id,
        ds.display_name as sim_status,
        md.carrier_cycle_usage as carrier_cycle_usage_bytes,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS carrier_cycle_usage_mb,
        md.date_added,
        md.date_activated,
        mdt.account_number,
        md.carrier_rate_plan_id,
        COALESCE(crp.friendly_name, md.carrier_rate_plan) AS carrier_rate_plan_name,
        CASE
            WHEN c.customer_bill_period_end_day IS NOT NULL AND c.customer_bill_period_end_hour IS NOT NULL THEN 
                ROUND(get_current_cycle_usage_bytes(md.id, mdt.tenant_id) / 1024.0 / 1024.0, 3)
            ELSE 
                ROUND(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS customer_cycle_usage_mb,
        mdt.customer_rate_pool_id,
        cpool.name as customer_rate_pool_name,
        mdt.customer_rate_plan_id,
        custrp.rate_plan_name as customer_rate_plan_name,
        custrp.rate_plan_code as customer_rate_plan_code,
        md.sms_count,
        md.minutes_used,
        md.username,
        ds.is_active_status,
        md.ip_address,
        md.service_zip_code,
        md.Single_User_Code AS rate_plan_soc,
        md.single_user_code_description as rate_plan_soc_description,
        md.data_group_id,
        md.pool_id,
        md.next_bill_cycle_date,
        md.device_make,
        md.device_model,
        md.contract_status,
        md.ban_status,
        md.imei_type_id,
        md.plan_limit_mb,
        mdt.customer_data_allocation_mb,
        bp.billing_cycle_start_date,
        bp.billing_cycle_end_date,
        custrp.plan_mb as customer_rate_plan_mb,
        custrp.allows_sim_pooling as customer_rate_plan_allows_sim_pooling,
        crp.plan_mb as carrier_rate_plan_mb,
        (SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
            FROM telegence_device_mobility_feature tdmf
            JOIN mobility_feature mf ON mf.id = tdmf.mobility_feature_id
            WHERE td.id IS NOT NULL AND tdmf.is_deleted = false AND tdmf.is_active = true AND tdmf.telegence_device_id = td.id AND mf.is_deleted = false AND mf.is_active = true AND mf.is_retired = false
        ) AS telegence_feature,
        (SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
            FROM e_bonding_device_mobility_feature ebdmf
            JOIN mobility_feature mf ON mf.id = ebdmf.mobility_feature_id
            WHERE e_bonding_device.id IS NOT NULL AND ebdmf.is_deleted = false AND ebdmf.is_active = true AND ebdmf.e_bonding_device_id = e_bonding_device.id AND mf.is_deleted = false AND mf.is_active = true AND mf.is_retired = false
        ) AS e_bonding_feature,
        md.last_usage_date,
        md.created_by,
        md.created_date,
        md.modified_by,
        md.modified_date,
        md.last_activated_date,
        md.deleted_by,
        md.deleted_date,
        md.is_active,
        md.is_deleted,
        md.cost_center_1 as cost_center1,
        md.soc,
		md.billing_period_id,
		md.ctd_sms_usage,
		md.ctd_session_count,
		md.ctd_voice_usage,
		mdt.rev_service_id,
		mdt.account_number_integration_authentication_id,
		md.delta_ctd_data_usage,
		md.technology_type,
		md.optimization_group_id,
		mdt.is_active as tenant_is_active,
		mdt.is_deleted as tenant_is_deleted,
        CASE 
			    WHEN sp.is_active = true THEN true
			    ELSE false
			END as service_provider_is_active,
--		COALESCE(crp.friendly_name, md.carrier_rate_plan) AS sub_tenant_customer_rate_plan_name,
--		custrp.rate_plan_name as sub_tenant_carrier_rate_plan_name,
		md.source_db,
		md.inv_source_id
    FROM mobility_device md
    JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id 
    JOIN  serviceprovider sp ON md.service_provider_id = sp.id
    LEFT JOIN  device_status ds ON ds.id = md.device_status_id
    LEFT JOIN customers c ON c.id = mdt.customer_id AND c.is_active = true AND c.is_deleted = false
    LEFT JOIN 
   revcustomer rc ON c.rev_customer_id = rc.id AND rc.is_active = true AND rc.is_deleted = false
	LEFT JOIN 
   integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false 
	LEFT JOIN 
   carrier_rate_plan crp ON crp.id = md.carrier_rate_plan_id
	LEFT JOIN customerrateplan custrp ON custrp.id=mdt.customer_rate_plan_id 
	LEFT JOIN customer_rate_pool cpool ON cpool.id = mdt.customer_rate_pool_id 
	LEFT JOIN billing_period bp ON bp.id = md.billing_period_id 
	LEFT JOIN telegence_device td ON td.subscriber_number = md.msisdn AND td.service_provider_id = md.service_provider_id
	LEFT JOIN e_bonding_device ON e_bonding_device.subscriber_number = md.msisdn AND e_bonding_device.service_provider_id = md.service_provider_id
	--LEFT JOIN vw_mobility_customer_current_cycle_device_usage ON vw_mobility_customer_current_cycle_device_usage.mobility_device_id = md.id AND vw_mobility_customer_current_cycle_device_usage.tenant_id = mdt.tenant_id
	left join public.sim_management_inventory sm on sm.mdt_id=mdt.id
	where new.mobility_device_id=md.id and md.is_active=True and md.is_deleted=false 
	AND NOT EXISTS (
        SELECT 1 FROM sim_management_inventory s WHERE s.mdt_id = mdt.id
    )
    AND mdt.id IS NOT NULL;
  
	 PERFORM set_config('myvars.insert_in_progress', 'false', true);
  RETURN NEW;
END;
$BODY$;

create trigger trg_insert_inventory_mob_dev_tenant_id after
insert
    on
    public.mobility_device_tenant for each row execute function insert_into_inventory_if_not_exists_mob_device_tenant();

-- DROP FUNCTION public.update_device_and_mobility_device_from_smi();

CREATE OR REPLACE FUNCTION public.update_device_and_mobility_device_from_smi()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$

DECLARE 
update_flag text;
BEGIN

RAISE NOTICE 'Updating device and device_tenant for device_id: %, dt_id: %', NEW.device_id, NEW.dt_id;
-- Get the session variable safely (returns NULL if not set)
update_flag := current_setting('myvars.update_in_progress', true);
IF update_flag IS NOT NULL AND update_flag = 'true' THEN
        RETURN NEW;
    END IF;

	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.update_in_progress', 'true', true);
	
   IF NEW.device_id IS NOT NULL AND NEW.dt_id IS NOT NULL THEN
			 RAISE NOTICE 'Updating device and device_tenant for device_id: %, dt_id: %', NEW.device_id, NEW.dt_id;
        UPDATE device
SET 
    service_provider_id = NEW.service_provider_id,
    iccid = NEW.iccid,
    imsi = NEW.imsi,
    msisdn = NEW.msisdn,
    imei = NEW.imei,
    eid = NEW.eid,
    device_status_id = NEW.device_status_id,
    sim_status = NEW.sim_status,
    carrier_rate_plan_id = NEW.carrier_rate_plan_id,
    carrier_rate_plan = NEW.carrier_rate_plan_name,
    communication_plan = NEW.communication_plan,
    last_usage_date = NEW.last_usage_date,
    package = NEW.package,
    billing_cycle_end_date = NEW.billing_cycle_end_date,
    --carrier_cycle_usage = NEW.carrier_cycle_usage_bytes,
    ctd_sms_usage = NEW.ctd_sms_usage,
    ctd_voice_usage = NEW.ctd_voice_usage,
    ctd_session_count = NEW.ctd_session_count,
    overage_limit_reached = NEW.overage_limit_reached,
    overage_limit_override = NEW.overage_limit_override,
    created_by = NEW.created_by,
    created_date = NEW.created_date,
    modified_by = NEW.modified_by,
    modified_date = NEW.modified_date,
    last_activated_date = NEW.last_activated_date,
    deleted_by = NEW.deleted_by,
    deleted_date = NEW.deleted_date,
    is_active = NEW.is_active,
    is_deleted = NEW.is_deleted,
    delta_ctd_data_usage = NEW.delta_ctd_data_usage,
    cost_center = NEW.cost_center,
    username = NEW.username,
    billing_period_id = NEW.billing_period_id,
    device_description = NEW.device_description,
    ip_address = NEW.ip_address,
	smi_id=NEW.id,
	updated_from_smi=True,
	date_added=NEW.date_added,
	date_activated=NEW.date_activated
WHERE id = NEW.device_id;
UPDATE device_tenant
SET 
    rev_service_id = NEW.rev_service_id,
    customer_rate_plan_id = NEW.customer_rate_plan_id,
    customer_data_allocation_mb = NEW.customer_data_allocation_mb,
    customer_rate_pool_id = NEW.customer_rate_pool_id,
    account_number = NEW.rev_customer_id,
    customer_id = NEW.customer_id,
    account_number_integration_authentication_id = NEW.account_number_integration_authentication_id,
    created_by = NEW.created_by,
    created_date = NEW.created_date,
    modified_by = NEW.modified_by,
    modified_date = NEW.modified_date,
    deleted_by = NEW.deleted_by,
    deleted_date = NEW.deleted_date,
    is_active = NEW.tenant_is_active,
    is_deleted = NEW.tenant_is_deleted,
    customer_rate_pool_name = NEW.customer_rate_pool_name,
    customer_rate_plan_name = NEW.customer_rate_plan_name,
    customer_name = NEW.customer_name,
	bulk_change_id=New.bulk_change_id,
	rev_line_status=New.rev_line_status,
	sub_tenant_carrier_rate_plan_name_id=New.sub_tenant_carrier_rate_plan_name_id,
	sub_tenant_carrier_rate_plan_name=New.sub_tenant_carrier_rate_plan_name
WHERE id=new.dt_id;

    END IF;
    -- Update mobility_device & mobility_device_tenant if mobility_device_id and mdt_id are both present
    IF NEW.mobility_device_id IS NOT NULL AND NEW.mdt_id IS NOT NULL THEN
		RAISE NOTICE 'Updating mobility_device and mobility_device_tenant for mobility_device_id: %, mdt_id: %', NEW.mobility_device_id, NEW.mdt_id;
        UPDATE mobility_device
SET 
    service_provider_id = NEW.service_provider_id,
    foundation_account_number = NEW.foundation_account_number,
    billing_account_number = NEW.billing_account_number,
    iccid = NEW.iccid,
    imsi = NEW.imsi,
    msisdn = NEW.msisdn,
    imei = NEW.imei,
    device_status_id = NEW.device_status_id,
    sim_status = NEW.sim_status,
    carrier_rate_plan_id = NEW.carrier_rate_plan_id,
    carrier_rate_plan = NEW.carrier_rate_plan_name,
    last_usage_date = NEW.last_usage_date,
   -- carrier_cycle_usage = NEW.carrier_cycle_usage_bytes,
    ctd_sms_usage = NEW.ctd_sms_usage,
    ctd_voice_usage = NEW.ctd_voice_usage,
    ctd_session_count = NEW.ctd_session_count,
    created_by = NEW.created_by,
    created_date = NEW.created_date,
    modified_by = NEW.modified_by,
    modified_date = NEW.modified_date,
    last_activated_date = NEW.last_activated_date,
    deleted_by = NEW.deleted_by,
    deleted_date = NEW.deleted_date,
    is_active = NEW.is_active,
    is_deleted = NEW.is_deleted,
    date_added = NEW.date_added,
    date_activated = NEW.date_activated,
    delta_ctd_data_usage = NEW.delta_ctd_data_usage,
    billing_period_id = NEW.billing_period_id,
    single_user_code = NEW.rate_plan_soc,  -- Assuming the rate plan SOC
    single_user_code_description = NEW.rate_plan_soc_description,  -- Assuming the rate plan SOC description
    service_zip_code = NEW.service_zip_code,
    next_bill_cycle_date = NEW.next_bill_cycle_date,
    sms_count = NEW.sms_count,
    minutes_used = NEW.minutes_used,
    data_group_id = NEW.data_group_id,
    pool_id = NEW.pool_id,
    device_make = NEW.device_make,
    device_model = NEW.device_model,
    contract_status = NEW.contract_status,
    ban_status = NEW.ban_status,
    imei_type_id = NEW.imei_type_id,
    plan_limit_mb = NEW.plan_limit_mb,
    amop_username = NEW.username,
    technology_type = NEW.technology_type,
    ip_address = NEW.ip_address,
    optimization_group_id = NEW.optimization_group_id,
    cost_center_1 = NEW.cost_center,
	updated_from_smi=True
WHERE id = NEW.mobility_device_id;  -- Assuming the `mobility_device_id` is the identifier to update

UPDATE mobility_device_tenant
SET
    tenant_id = NEW.tenant_id,
    rev_service_id = NEW.rev_service_id,
    customer_rate_plan_id = NEW.customer_rate_plan_id,
    customer_data_allocation_mb = NEW.customer_data_allocation_mb,
    customer_rate_pool_id = NEW.customer_rate_pool_id,
    account_number = NEW.rev_customer_id,
    customer_id = NEW.customer_id,
    customer_name = NEW.customer_name,
    account_number_integration_authentication_id = NEW.account_number_integration_authentication_id,
    created_by = NEW.created_by,
    created_date = NEW.created_date,
    modified_by = NEW.modified_by,
    modified_date = NEW.modified_date,
    deleted_by = NEW.deleted_by,
    deleted_date = NEW.deleted_date,
    is_active = NEW.tenant_is_active,
    is_deleted = NEW.tenant_is_deleted,
    customer_rate_plan_name = NEW.customer_rate_plan_name,
    customer_rate_pool_name = NEW.customer_rate_pool_name,
	bulk_change_id=New.bulk_change_id,
	rev_line_status=New.rev_line_status,
	sub_tenant_carrier_rate_plan_name_id=New.sub_tenant_carrier_rate_plan_name_id,
	sub_tenant_carrier_rate_plan_name=New.sub_tenant_carrier_rate_plan_name
WHERE id=new.mdt_id;  -- Assuming NEW.mobility_device_id is the identifier for the existing tenant record
    END IF;

 -- Reset the session variable after update
    PERFORM set_config('myvars.update_in_progress', 'false', true);
	
    RETURN NEW;
END;
$function$
;


-- DROP FUNCTION public.update_rev_service_false();

CREATE OR REPLACE FUNCTION public.update_rev_service_false()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    existing_record JSONB;
    updated_json JSONB;
BEGIN
    -- Fetch the existing JSON data (single row assumption)
    SELECT rev_service_ids INTO existing_record FROM rev_service_false LIMIT 1;

    -- If no record exists, initialize an empty JSONB object
    IF existing_record IS NULL THEN
        existing_record := '{}'::JSONB;
    END IF;

    -- If the trigger is fired from the rev_service table
    IF TG_TABLE_NAME = 'rev_service' THEN
        updated_json := jsonb_set(
            existing_record, 
            '{rev_service_id}', 
            (COALESCE(existing_record->'rev_service_id', '[]'::JSONB) || to_jsonb(NEW.id))
        );
    END IF;

    -- If the trigger is fired from the rev_service_product table
    IF TG_TABLE_NAME = 'rev_service_product' THEN
        updated_json := jsonb_set(
            existing_record, 
            '{rev_service_product_id}', 
            (COALESCE(existing_record->'rev_service_product_id', '[]'::JSONB) || to_jsonb(NEW.id))
        );
    END IF;

	 IF TG_TABLE_NAME = 'device_tenant' THEN
        updated_json := jsonb_set(
            existing_record, 
            '{dev_tenant_ids}', 
            (COALESCE(existing_record->'dev_tenant_ids', '[]'::JSONB) || to_jsonb(NEW.id))
        );
    END IF;

    -- If the trigger is fired from the mobility_device_tenant table
    IF TG_TABLE_NAME = 'mobility_device_tenant' THEN
        updated_json := jsonb_set(
            existing_record, 
            '{mob_tenant_ids}', 
            (COALESCE(existing_record->'mob_tenant_ids', '[]'::JSONB) || to_jsonb(NEW.id))
        );
    END IF;

	

    -- Ensure only a single row exists in rev_service_false
    INSERT INTO rev_service_false (id, rev_service_ids)
    VALUES (1, updated_json)
    ON CONFLICT (id) DO UPDATE
    SET rev_service_ids = updated_json;

    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_rev_service_on_processed();

CREATE OR REPLACE FUNCTION public.update_rev_service_on_processed()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- Check if the status is updated to 'processed'
    IF NEW.status = 'PROCESSED' or NEW.status='processed' THEN
        -- Update the corresponding rows in rev_service table
        UPDATE rev_service
        SET rev_service_line_status='PROCESSED',
        is_active = 'FALSE',
            is_deleted = 'TRUE'
        WHERE bulk_change_id = NEW.bulk_change_id
          AND number = NEW.service_number;
    ELSE
        -- Update the status in rev_service to indicate an error occurred
        UPDATE rev_service
        SET rev_service_line_status = 'an error occurred in bulk change'
        WHERE bulk_change_id = NEW.bulk_change_id
          AND number = NEW.service_number;
    
        END IF;
    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_rev_service_on_processed123();

CREATE OR REPLACE FUNCTION public.update_rev_service_on_processed123()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN

IF NEW.status = 'NEW' OR NEW.status = 'new' THEN
        RETURN NEW;
    END IF;
    
    IF NEW.status = 'PROCESSED' OR NEW.status = 'processed' THEN
        
        UPDATE rev_service
        SET rev_service_line_status = 'PROCESSED',
            is_active = 'FALSE',
            is_deleted = 'TRUE'
        WHERE bulk_change_id = NEW.bulk_change_id
          AND number = NEW.service_number;

        
        IF NOT EXISTS (
            SELECT 1
            FROM rev_service
            WHERE bulk_change_id = NEW.bulk_change_id
              AND number = NEW.service_number
        ) THEN
            UPDATE sim_management_inventory
            SET rev_line_status = 'PROCESSED',
                tenant_is_active = 'FALSE',
                tenant_is_deleted = 'TRUE'
            WHERE (iccid = NEW.service_number OR msisdn = NEW.service_number OR eid = NEW.service_number)
              AND bulk_change_id = NEW.bulk_change_id;
        END IF;
    ELSE
        -- Update the status in rev_service to indicate an error occurred
        UPDATE rev_service
        SET rev_service_line_status = 'an error occurred in bulk change'
        WHERE bulk_change_id = NEW.bulk_change_id
          AND number = NEW.service_number;

        -- If service_number is not found in rev_service, check sim_management_inventory
        IF NOT EXISTS (
            SELECT 1
            FROM rev_service
            WHERE bulk_change_id = NEW.bulk_change_id
              AND number = NEW.service_number
        ) THEN
            UPDATE sim_management_inventory
            SET rev_line_status = 'an error occurred in bulk change'
            WHERE (iccid = NEW.service_number OR msisdn = NEW.service_number OR eid = NEW.service_number)
              AND bulk_change_id = NEW.bulk_change_id;
        END IF;
    END IF;

    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.update_processed_date()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$

BEGIN
    NEW.processed_date = now() AT TIME ZONE 'UTC';
    RETURN NEW;
END;
$function$
;


CREATE OR REPLACE FUNCTION public.update_bulk_change_request_id()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$

BEGIN
  if new.bulk_change_request_id is null then 
    UPDATE sim_management_bulk_change_log
    SET bulk_change_request_id = (
        SELECT id 
        FROM sim_management_bulk_change_request 
        WHERE 
            bulk_change_id = NEW.bulk_change_id AND 
            (m2m_id = NEW.m2m_device_change_id OR mobility_id = NEW.mobility_device_change_id)
    )
    WHERE id = NEW.id;
    end if;
    RETURN NEW;
END;
$function$
;


-- DROP FUNCTION public.keep_previous_run_start_time();

CREATE OR REPLACE FUNCTION public.keep_previous_run_start_time()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    IF NEW.optimization_run_start_date IS NULL  THEN
        NEW.optimization_run_start_date := OLD.optimization_run_start_date;
    END IF;
    RETURN NEW;
END;
$function$
;

-- DROP FUNCTION public.update_smi_result_id_in_queue();

CREATE OR REPLACE FUNCTION public.update_smi_result_id_in_queue()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- Handle INSERT case
    IF TG_OP = 'INSERT' THEN
        UPDATE optimization_smi_result_customer_charge_queue
        SET optimization_smi_result_id = optimization_smi_result.id
        FROM optimization_smi_result
        WHERE 
            optimization_smi_result_customer_charge_queue.id = NEW.id
            AND (NEW.optimization_mobility_device_result_id = optimization_smi_result.mid
                 OR NEW.optimization_device_result_id = optimization_smi_result.did);

    -- Handle UPDATE case: Check if the relevant columns have changed
    ELSIF TG_OP = 'UPDATE' AND 
          (OLD.optimization_mobility_device_result_id IS DISTINCT FROM NEW.optimization_mobility_device_result_id 
           OR OLD.optimization_device_result_id IS DISTINCT FROM NEW.optimization_device_result_id) THEN

        UPDATE optimization_smi_result_customer_charge_queue
        SET optimization_smi_result_id = optimization_smi_result.id
        FROM optimization_smi_result
        WHERE 
            optimization_smi_result_customer_charge_queue.id = NEW.id
            AND (NEW.optimization_mobility_device_result_id = optimization_smi_result.mid
                 OR NEW.optimization_device_result_id = optimization_smi_result.did);
    END IF;

    RETURN NEW;
END;
$function$
;






CREATE OR REPLACE TRIGGER update_processed_date_trigger
    BEFORE UPDATE
    ON public.sim_management_bulk_change
    FOR EACH ROW
    EXECUTE FUNCTION public.update_processed_date();

CREATE OR REPLACE TRIGGER update_processed_date_triggerreq
    BEFORE UPDATE
    ON public.sim_management_bulk_change_request
    FOR EACH ROW
    EXECUTE FUNCTION public.update_processed_date();

CREATE OR REPLACE TRIGGER before_insert_carrier_rate_plan_setassign_value
    BEFORE INSERT
    ON public.carrier_rate_plan
    FOR EACH ROW
    EXECUTE FUNCTION public.set_assigned_value();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.customer_rate_pool for each row execute function update_sequence_after_insert();

create trigger trg_update_service_provider_names before
insert
    or
update
    on
    public.customer_rate_pool for each row execute function update_service_provider_names_pool();

create trigger rev_service_false_trigger after
update
    on
    public.customer_rate_pool for each row
    when ((new.is_active = false)) execute function update_rev_service_false_customer_rate_pool();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.customerrateplan for each row execute function update_sequence_after_insert();

create trigger trg_before_insert_customerrateplan before
insert
    on
    public.customerrateplan for each row execute function trg_set_serviceproviderids_insert();

create trigger trg_update_display_rate before
insert
    or
update
    on
    public.customerrateplan for each row execute function update_display_rate();

create trigger rev_service_false_trigger after
update
    on
    public.customerrateplan for each row
    when ((new.is_active = false)) execute function update_rev_service_false_customer();

create trigger set_optimization_type before
insert
    or
update
    on
    public.customerrateplan for each row execute function update_optimization_type();

create trigger trg_update_service_provider_names before
insert
    or
update
    on
    public.customerrateplan for each row execute function update_service_provider_names();




create trigger trg_update_tenant_name before
insert
    or
update
    on
    public.customers for each row execute function update_tenant_name();

create trigger trg_sync_rev_customer_tenant_id after
insert
    or
update
    on
    public.customers for each row
    when (((new.rev_customer_id is not null)
        and (new.tenant_id is not null))) execute function sync_rev_customer_tenant_id();


--create trigger trg_set_user_type before
--insert
--    or
--update
--    of billing_platform_flag on
--    public.customers for each row execute function set_user_type();
--
--create trigger set_user_type_trigger before
--insert
--    or
--update
--    of billing_platform_flag on
--    public.customers for each row execute function update_user_type();

create trigger rev_service_false_trigger after
update
    on
    public.rev_service for each row
    when (((new.is_active = false)
        and (new.bulk_change_id is not null))) execute function update_rev_service_false();
    
create trigger trg_update_rev_service after
update
    on
    public.sim_management_bulk_change_request for each row execute function update_rev_service_on_processed();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.mobility_device for each row execute function update_sequence_after_insert();



create trigger trg_update_rev_service_sim_or_rev after
update
    on
    public.sim_management_bulk_change_request for each row execute function update_rev_service_on_processed123();

create trigger trg_update_bulk_change_request_id after
insert
    on
    public.sim_management_bulk_change_log for each row execute function update_bulk_change_request_id();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.sim_management_bulk_change_log for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.rev_product_type for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.rev_product for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.rev_package for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_type for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_status for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.mobility_device_usage_aggregate for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.imei_master for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.sim_management_inventory_history for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.device_status_reason_code for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_session for each row execute function update_sequence_after_insert();

create trigger trigger_keep_run_start_time before
update
    on
    public.optimization_session for each row execute function keep_previous_run_start_time();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_instance for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_queue for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_instance_result_file for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_group_carrier_rate_plan for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_group for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_comm_group for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_rate_plan_type for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_smi_result_customer_charge_queue for each row execute function update_sequence_after_insert();
create trigger after_insert_or_update_queue after
insert
    or
update
    of optimization_device_result_id,
    optimization_mobility_device_result_id on
    public.optimization_smi_result_customer_charge_queue for each row execute function update_smi_result_id_in_queue();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.optimization_smi_result_rate_plan_queue for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.qualification for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.app_file for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_get_usage_by_rate_plan for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_action for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_condition for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_customer_rate_plan for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_followup_effective_date_type for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_followup for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_detail for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_followup_detail for each row execute function update_sequence_after_insert();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_log for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.automation_rule_type for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.device_status_uploaded_file_detail for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.device_status_uploaded_file for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.e_bonding_device for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.e_bonding_device_sync_audit for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.jasper_device_sync_audit for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.telegence_device for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.telegence_device_mobility_feature for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.telegence_device_sync_audit for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.thing_space_device_sync_audit for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.customer_billing_period for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.imei_type for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.integration_connection for each row execute function update_sequence_after_insert();

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.bulk_change_popup_screens for each row execute function update_sequence_after_insert();    


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.sim_management_bulk_change_type_service_provider for each row execute function update_sequence_after_insert();    

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.telegence_device_status_reason_code for each row execute function update_sequence_after_insert();   

create trigger update_sequence_after_insert_trigger after
insert
    on
    public.thingspace_device_status_reason_code for each row execute function update_sequence_after_insert();   

 create trigger update_sequence_after_insert_trigger after
insert
    on
    public.smi_change_type_mapping for each row execute function update_sequence_after_insert();          

CREATE OR REPLACE TRIGGER after_insert_on_smi
    AFTER INSERT
    ON public.sim_management_inventory
    FOR EACH ROW
    EXECUTE FUNCTION public.insert_into_device_or_mobility_device_from_smi();


CREATE OR REPLACE TRIGGER after_update__on_smi
    AFTER UPDATE 
    ON public.sim_management_inventory
    FOR EACH ROW
    EXECUTE FUNCTION public.update_device_and_mobility_device_from_smi();


create trigger update_last_modified before
update
    on
    public.action_history_logs for each row execute function update_modified_date();


create trigger update_sequence_after_insert_trigger after
insert
    on
    public.action_history_logs for each row execute function update_sequence_after_insert();    
                        
    

create or replace trigger update_sequence_after_insert_trigger after
insert
    on
    public.device_tenant for each row execute function update_sequence_after_insert();                          
  
    

create or replace trigger update_sequence_after_insert_trigger after
insert
    on
    public.mobility_device_tenant for each row execute function update_sequence_after_insert();    
                        
