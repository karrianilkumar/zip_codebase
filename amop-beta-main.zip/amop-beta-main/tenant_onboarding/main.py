"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
@Author3 : Vyshnavi
Created Date: 01-11-24
"""

import json
import time
import boto3
from datetime import datetime
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from tenant_db_creation_script import funtion_caller
from common_utils.email_trigger import (
    send_sns_email,
    get_memory_usage,
    memory_sns,
    insert_email_audit,
)

# Initialize the SNS client
sns = boto3.client("sns")
cloudwatch = boto3.client("cloudwatch")
logging = Logging(name="main")


def lambda_handler(event, context):

    function_name = context.function_name if context else "user_authentication"

    performance_matrix = {}
    # Record the start time of the function
    start_time = time.time()
    performance_matrix["start_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}.{int((start_time % 1) * 1000):03d}"
    )
    print(
        f"Request received at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}.{int((start_time % 1) * 1000):03d}"
    )
    # Monitor memory usage

    data = event.get("data")
    if data:
        try:
            data = data
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid JSON in body"}),
            }
    else:
        data = {}

    # Extract the HTTP method, path, and query string parameters from the event
    data = data.get("data")
    path = data.get("path")

    # Route based on the path and method
    result = funtion_caller(data, path)

    if result.get("flag") == False:
        status_code = 400  # You can change this to an appropriate error code
    else:
        status_code = 200

    # Record the end time of the function
    end_time = time.time()
    performance_matrix["end_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )
    performance_matrix["execution_time"] = f"{end_time - start_time:.4f}"
    print(
        f"Request processed at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )

    performance_matrix["execution_time"] = f"{end_time - start_time:.4f} seconds"

    print(f"Function performance_matrix: {performance_matrix} seconds")

    memory_limit = int(context.memory_limit_in_mb)
    memory_used = int(get_memory_usage()) + 100
    final_memory_used = get_memory_usage()
    logging.info(
        f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
    )
    memory_sns(memory_limit, memory_used, context)

    return {
        "statusCode": status_code,
        "body": json.dumps(result),
        "performance_matrix": json.dumps(performance_matrix),
    }
