'''
Author : Bhavani Ganta
Status : In Progress
Objective : This script will have all the functions required for initial sync of data for partner becoming provider
'''

# 1. Standard Library Imports
import os
import json
import re
import time
import math
import threading
from datetime import datetime, timedelta,timezone
import copy
import uuid
#import boto3
import traceback

# 2. Third-Party Imports
import pandas as pd
from pandas import Timestamp
from sqlalchemy import create_engine, exc, text
import pytds
import psycopg2
from psycopg2.extras import execute_values
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv
from psycopg2 import sql
from common_utils.logging_utils import Logging
logging = Logging(name="main")


class MigrationScheduler:
    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(self,db_type='',host='', db_name='',username='', password='',port='',driver='',max_retry=3):
        """
        """
        connection = None
        retry = 1
        logging.info(f"db_type:{db_type}, host--{host}-db_name-{db_name}, username-{username},password-{password},port-{port},driver-{driver}")
        db_type = db_type.strip()
        host = host.strip()
        db_name = db_name.strip()
        username = username.strip()
        password = password.strip()
        port = port.strip()
        driver = driver.strip()
        if db_type=='postgresql':
            try:
                logging.info(f"creating postgresql connection")

                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.info(f"Failed to connect to PostgreSQL DB: {e}")
        elif db_type=='mssql':
            logging.info(f"Creating MSSQL connection")
            try:
                connection = pytds.connect(
                    server=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )

                logging.info("Connection to MSSQL successful!")
            except Exception as e:
                logging.info(f"Failed to connect to MSSQL DB: {e}")
        return connection

    def execute_query(self,connection,query,params):
        """
        """
        try:
            if params:
                result_df = pd.read_sql_query(query, connection, params=params)
            else:
                result_df = pd.read_sql_query(query, connection)
            return result_df
        except Exception as e:
            logging.info(f"Error executing query: {e}")
            return pd.DataFrame()
    def update_table(self, conn, table_name, data_dict, condition_dict):
        """
        Update a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to update
        :param data_dict: Dictionary containing column-value pairs to update
        :param condition_dict: Dictionary containing column-value pairs for the WHERE condition
        """
        try:
            # Replace NaN with None in data_dict
            data_dict = {
                k: (None if isinstance(v, float) and math.isnan(v) else v)
                for k, v in data_dict.items()
            }

            # Replace NaN with None in condition_dict
            condition_dict = {
                k: (None if isinstance(v, float) and math.isnan(v) else v)
                for k, v in condition_dict.items()
            }
            # Generate the SET part of the SQL query
            set_clause = ", ".join([f"{col} = %s" for col in data_dict.keys()])

            # Handle condition dict with lists or single values
            where_clause = []
            # logging.info(f"in updat_table val dict is {data_dict}")
            values = list(data_dict.values())

            for col, val in condition_dict.items():
                if isinstance(val, list):
                    # Generate the WHERE clause for IN condition
                    placeholders = ", ".join(["%s"] * len(val))
                    where_clause.append(f"{col} IN ({placeholders})")
                    values.extend(val)  # Add the list values to the values list
                else:
                    # Handle single value condition
                    where_clause.append(f"{col} = %s")
                    values.append(val)

            # Combine WHERE conditions
            if where_clause:
                where_clause = " AND ".join(where_clause)
                sql_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
            else:
                sql_query = f"UPDATE {table_name} SET {set_clause}"

            # logging.info the SQL query and values for debugging
            logging.info(f"Conn in update is {conn}")
            logging.info(f"SQL Query: {sql_query}")
            logging.info(f"Values: {values}")

            # Execute the query
            try:
                with conn.cursor() as cursor:
                    cursor.execute(sql_query, values)
                    conn.commit()
                logging.info("Update successful")
            except Exception as e:
                conn.rollback()
                logging.info(f"Error in updating {e}")
            # finally:
            #     if conn:
            #         conn.close()

        except Exception as e:
            conn.rollback()
            logging.info(f"Error while updating table {table_name}: {e}")
    def apply_foreign_key_mappings(self,df: pd.DataFrame, foreign_key_mappings: dict) -> pd.DataFrame:
        """
        Replace values in DataFrame based on foreign_key_mappings.

        Args:
            df (pd.DataFrame): Input dataframe
            foreign_key_mappings (dict): Example:
                {
                    'device_status_id': [{'22': '7', '44': '12'}],
                    'service_provider_id': [{'1': 5, '6': 1}]
                }

        Returns:
            pd.DataFrame: Updated dataframe with FK values replaced
        """
        df = df.copy()

        for col, mappings in foreign_key_mappings.items():
            if col not in df.columns:
                logging.info(f"[apply_foreign_key_mappings] Column '{col}' not in DataFrame, skipping...")
                continue

            # Merge list of dicts into single mapping
            replace_dict = {}
            if isinstance(mappings, list):
                for m in mappings:
                    if isinstance(m, dict):
                        replace_dict.update(m)
            elif isinstance(mappings, dict):
                replace_dict.update(mappings)

            if not replace_dict:
                continue

            # Determine column type
            col_dtype = df[col].dtype

            # Normalize mapping keys and values to match column type
            if pd.api.types.is_numeric_dtype(col_dtype):
                replace_dict = {int(k): int(v) for k, v in replace_dict.items()}
                df[col] = pd.to_numeric(df[col], errors='coerce')
            else:
                replace_dict = {str(k): str(v) for k, v in replace_dict.items()}
                df[col] = df[col].astype(str)

            # Apply mapping
            df[col] = df[col].replace(replace_dict)

            logging.info(f"[apply_foreign_key_mappings] Column '{col}' replaced using mapping: {replace_dict}")
            logging.info(f"[apply_foreign_key_mappings] Sample values: {df[col].head(5).tolist()}")

        return df
    def fetching_foreignkey_values(self, mapping_dict: dict, conn, condition_dict: dict):
        """
        Fetch values from DB based on mapping_dict and condition_dict.

        Args:
            mapping_dict (dict): Mapping like {"rev_customer_id": {"where_row": ..., "where_table": ..., "col_to_check": ...}}
            conn: Active DB connection
            condition_dict (dict): Condition values to filter query

        Returns:
            dict: Key -> List of fetched values
        """
        results = {}
        try:
            cursor = conn.cursor()
            for key, details in mapping_dict.items():
                where_row = details["where_row"]
                where_table = details["where_table"]
                col_to_check = details["col_to_check"]
                # Build WHERE clause dynamically
                where_clauses = []
                values = []
                for cond_key, cond_value in condition_dict.items():
                    where_clauses.append(f"{cond_key} = %s")
                    values.append(cond_value)

                where_sql = " AND ".join(where_clauses)
                query = f"""
                    SELECT {col_to_check}
                    FROM {where_table}
                    WHERE table_name = %s
                    AND {where_sql}
                """
                params = [where_row] + values
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                results[key] = [row[0] for row in rows] if rows else []
            cursor.close()
            
            return results
        except Exception as e:
            logging.info(f"Error in fetching_foreignkey_values: {str(e)}")
            return {}
    def build_where_clause_for_inv(self, table_name: str, condition_df_dict: dict) -> str:
        """
        Build SQL WHERE clause string from condition_df_dict directly.

        Args:
            table_name (str): Table name being processed.
            condition_df_dict (dict): Dict with {col_name: DataFrame or dict}.

        Returns:
            str: SQL WHERE clause.
        """
        final_where_part = {}
        tenant_clause = ""
        customer_names = []
        fans = []
        bans = []

        try:
            # Step 1: Normalize input into final_where_part
            for key, df in condition_df_dict.items():
                if isinstance(df, pd.DataFrame) and not df.empty:
                    final_where_part[key] = df
                else:
                    final_where_part[key] = pd.DataFrame()

            logging.info(f"[DEBUG] Final where part for {table_name}: {list(final_where_part.keys())}")

            # Step 2: Build tenant_id clause
            if "tenant_id" in final_where_part:
                df = final_where_part["tenant_id"]
                if isinstance(df, pd.DataFrame) and "partner_db_tenant_id" in df.columns:
                    tenant_vals = df["partner_db_tenant_id"].dropna().tolist()
                    if tenant_vals:
                        if len(tenant_vals) == 1:
                            tenant_clause = f"tenant_id = {tenant_vals[0]}"
                        else:
                            formatted = ", ".join([str(t) for t in tenant_vals])
                            tenant_clause = f"tenant_id IN ({formatted})"

            # Step 3: Collect customer_names
            if "customer_name" in final_where_part:
                df = final_where_part["customer_name"]
                if isinstance(df, pd.DataFrame) and "customer_names" in df.columns:
                    for val in df["customer_names"].dropna().tolist():
                        if isinstance(val, str) and val.strip().startswith("{"):
                            try:
                                parsed = json.loads(val)
                                customer_names.extend(list(parsed.values()))
                            except Exception:
                                customer_names.extend(re.findall(r'"([^"]+)"', val))
                        else:
                            customer_names.append(str(val).strip('"'))

            # Step 4: Collect FANs
            if "foundation_account_number" in final_where_part:
                df = final_where_part["foundation_account_number"]
                if isinstance(df, pd.DataFrame) and "tagged_fan" in df.columns:
                    fans = df["tagged_fan"].dropna().tolist()
                    if fans and isinstance(fans[0], str) and fans[0].startswith("["):
                        fans = json.loads(fans[0])

            # Step 5: Collect BANs
            if "billing_account_number" in final_where_part:
                df = final_where_part["billing_account_number"]
                if isinstance(df, pd.DataFrame) and "tagged_ban" in df.columns:
                    bans = df["tagged_ban"].dropna().tolist()
                    if bans and isinstance(bans[0], str) and bans[0].startswith("["):
                        bans = json.loads(bans[0])

            # Step 6: Build the OR clause
            or_clauses = []
            if customer_names:
                formatted = ", ".join([f"'{n}'" for n in customer_names])
                or_clauses.append(f"customer_name IN ({formatted})")

            if fans or bans:
                if fans and bans:
                    formatted_fans = ", ".join([f"'{f}'" for f in fans])
                    formatted_bans = ", ".join([f"'{b}'" for b in bans])
                    or_clauses.append(
                        f"(foundation_account_number IN ({formatted_fans}) "
                        f"AND billing_account_number IN ({formatted_bans}))"
                    )
                elif fans:
                    formatted_fans = ", ".join([f"'{f}'" for f in fans])
                    or_clauses.append(
                        f"(foundation_account_number IN ({formatted_fans}))"
                    )
                elif bans:
                    formatted_bans = ", ".join([f"'{b}'" for b in bans])
                    or_clauses.append(
                        f"(billing_account_number IN ({formatted_bans}))"
                    )

            # Step 7: Combine into WHERE clause
            if tenant_clause and or_clauses:
                return f"WHERE {tenant_clause} AND ({' OR '.join(or_clauses)})"
            elif tenant_clause:
                return f"WHERE {tenant_clause}"
            elif or_clauses:
                return f"WHERE {' OR '.join(or_clauses)}"
            else:
                return ""

        except Exception as e:
            logging.info(f"[ERROR] While building WHERE clause for {table_name}: {e}")
            return ""
        finally:
            logging.info(f"[INFO] Finished processing WHERE clause for {table_name}")
    def fetch_details_from_partner_provider_initial_sync_mappings(self, where_cond_list: list, connection, params: dict):
        """
        Fetch details from the partner_provider_initial_sync_mappings (or related) tables 
        by dynamically forming WHERE conditions for multiple query configs.

        Args:
            where_cond_list (list[dict]): Each dict contains a single key (like "customer_name", "tenant_id")
                                        with config dict containing:
                                        - where_col (str): Column(s) to select
                                        - where_table (str): Table to query from
                                        - <where_condition> (list[str]): Columns to filter on
            connection: Active database connection object
            params (dict): Dictionary mapping condition columns to their values.

        Returns:
            dict: A dictionary with each top-level key ("customer_name", "tenant_id") mapped to its query result DataFrame.
        """

        results = {}

        try:
            for cond in where_cond_list:
                # Extract the alias key (e.g., "customer_name")
                alias_key = list(cond.keys())[0]
                config = cond[alias_key]

                where_col = config["where_col"]
                where_table = config["where_table"]
                where_conditions = config["<where_condition>"]

                # Build WHERE clause dynamically
                where_clause = " AND ".join([f"{col} = %s" for col in where_conditions])
                values = [params[col] for col in where_conditions]  # preserve order

                query = f"SELECT {where_col} FROM {where_table} WHERE {where_clause}"
                
                # Execute query safely
                df = pd.read_sql_query(query, connection, params=values)
                
                results[alias_key] = df

            return results

        except Exception as e:
            raise RuntimeError(f"Error fetching details from partner_provider_initial_sync_mappings: {e}")
    def fetch_dependent_data(self, conn, base_query: str, cond_dict: dict,order_by='id'):
        """
        Executes a query with additional conditions from cond_dict and returns a DataFrame.

        Args:
            conn: Database connection object.
            base_query (str): The base SQL query (without WHERE or with default).
            cond_dict (dict): Dictionary of conditions {col: value}.

        Returns:
            pandas.DataFrame: Query result as DataFrame.
        """
        try:
            # Step 1: Build WHERE clause from cond_dict
            where_parts = []
            params = []
            for col, val in cond_dict.items():
                where_parts.append(f"{col} = %s")
                params.append(val)

            where_clause = " AND ".join(where_parts)

            # Step 2: Handle base_query variations
            query_lower = base_query.lower().strip()

            if "where" in query_lower:
                if query_lower.endswith("where"):
                    # Case 2: query ends with WHERE (no conditions yet)
                    final_query = f"{base_query} {where_clause}"
                else:
                    # Case 1: query already has conditions
                    final_query = f"{base_query} AND {where_clause}"
            else:
                # Case 3: no WHERE in query
                final_query = f"{base_query} WHERE {where_clause}"

            logging.info(f"[fetch_with_conditions] Final query: {final_query}")
            logging.info(f"[fetch_with_conditions] Params: {params}")
            if order_by:
                final_query = f"{final_query} ORDER BY {order_by}"

            # Step 3: Execute query
            df = self.execute_query(conn, final_query, params)
            logging.info(f"[fetch_with_conditions] Rows fetched: {len(df)}")
            return df

        except Exception as e:
            logging.info(f"[ERROR] Failed to fetch with conditions: {e}")
            raise
    def build_dependent_df(self, inv_df: pd.DataFrame, columns_list: list) -> pd.DataFrame:
        """
        Select only the columns from inv_df that are listed in columns_list
        and return a new DataFrame for the dependent table.

        Args:
            inv_df (pd.DataFrame): Main inventory DataFrame.
            columns_list (list): List of column names to select.

        Returns:
            pd.DataFrame: Filtered DataFrame with only the selected columns.
        """
        # Step 1: Filter columns that actually exist in inv_df'
        logging.info(f"build_dependent_dict {inv_df} {columns_list}")
        
        valid_columns = [col for col in columns_list if col in inv_df.columns]

        if not valid_columns:
            logging.info("[WARN] None of the columns in columns_list exist in inv_df.")
            return pd.DataFrame()  # Return empty df if nothing matches

        # Step 2: Create new DataFrame with only valid columns
        dependent_df = inv_df[valid_columns].copy()

        logging.info(f"[INFO] Built dependent DataFrame with {len(dependent_df)} rows and {len(valid_columns)} columns")
        logging.info(f"[DEBUG] Sample rows: {dependent_df.head(2).to_dict(orient='records')}")
        return dependent_df
    def update_partner_data_to_target_db(
        self,
        postgres_conn,
        table_name,
        data_input,
        conflict_col,
        return_mapped_ids=False,
        tenant_id_flag=False
    ):
        """
        Inserts or updates data in a PostgreSQL table based on conflict and 
        optionally returns mapping of source_id to target primary key id.

        Supports both UUID and integer IDs.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            data_input (DataFrame or list[dict]): Records to insert or update
            conflict_col (str or list): Column(s) to check for conflicts
            return_mapped_ids (bool): If True, return mapping of inserted IDs
            tenant_id_flag (bool): If True, returns mapping grouped by tenant_id

        Returns:
            dict: 
                - if tenant_id_flag=True → {tenant_id: {source_id: id}}
                - else → {source_id: id}
        """
        try:
            # --- Handle DataFrame or list[dict] ---
            if isinstance(data_input, pd.DataFrame):
                if data_input.empty:
                    logging.info(f"[{table_name}] No data provided (empty DataFrame).")
                    return {} if return_mapped_ids else None
                data_list = data_input.to_dict(orient="records")

            elif isinstance(data_input, list):
                if not data_input:
                    logging.info(f"[{table_name}] No data provided (empty list).")
                    return {} if return_mapped_ids else None
                data_list = data_input

            else:
                raise TypeError("data_input must be a pandas DataFrame or list of dicts")

            # Columns to return after insert
            if return_mapped_ids:
                return_ids = ["id", "source_id"]
                if tenant_id_flag:
                    return_ids.append("tenant_id")
            else:
                return_ids = []

            with postgres_conn.cursor() as cursor:
                # Extract column names
                columns = list(data_list[0].keys())

                # Prepare SQL parts
                columns_str = ", ".join(columns)
                conflict_cols_str = (
                    ", ".join(conflict_col)
                    if isinstance(conflict_col, (list, tuple))
                    else conflict_col
                )

                update_set = ", ".join(
                    [f"{col} = EXCLUDED.{col}" for col in columns if col not in conflict_col]
                )

                # UPSERT query
                query = f"""
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({conflict_cols_str})
                DO UPDATE SET {update_set}
                {"RETURNING " + ", ".join(return_ids) if return_ids else ""};
                """

                values = [tuple(record[col] for col in columns) for record in data_list]
                logging.info(f"[{table_name}] Preparing to execute query.")
                logging.info(f"[{table_name}] Number of records to process: {len(values)}")

                # Execute query
                #execute_values(cursor, query, values)
                execute_values(
                    cursor, 
                    query, 
                    values,
                    page_size=len(values)  # Process all records in one batch
                )


                mapping = None
                if return_mapped_ids:
                    returned_rows = cursor.fetchall()
                    logging.info(f"[{table_name}] Number of returned rows: {len(returned_rows)} ")

                    #logging.info(f"returned_rows are  {returned_rows}")

                    def normalize(val):
                        """Convert UUIDs to str, keep ints as-is."""
                        if isinstance(val, uuid.UUID):
                            return str(val)
                        return val

                    if tenant_id_flag:
                        # returned_rows = [(id, source_id, tenant_id), ...]
                        mapping = {}
                        for row in returned_rows:
                            tgt_id, src_id, tid = map(normalize, row)
                            if tid not in mapping:
                                mapping[tid] = {}
                            mapping[tid][src_id] = tgt_id
                    else:
                        # returned_rows = [(id, source_id), ...]
                        mapping = {
                            normalize(src_id): normalize(tgt_id)
                            for tgt_id, src_id in returned_rows
                        }

                    # --- Debug logs ---
                    num_input = len(data_list)
                    num_mapped = (
                        sum(len(m) for m in mapping.values())
                        if tenant_id_flag
                        else len(mapping)
                    )

                    logging.info(f"[{table_name}] Records attempted: {num_input}")
                    logging.info(f"[{table_name}] Mapped IDs returned: {num_mapped}")

                    if num_input != num_mapped:
                        logging.info( f"[{table_name}] Warning: record count mismatch input={num_input}, mapped={num_mapped})")
                    else:
                        logging.info(f"[{table_name}] Record counts match.")

                postgres_conn.commit()
                logging.info(f"[{table_name}] Records inserted or updated successfully.")

                return mapping if return_mapped_ids else None

        except Exception as e:
            postgres_conn.rollback()
            logging.info(f"[{table_name}] Error in update_partner_data_to_target_db: {e}")
            return {} if return_mapped_ids else None
    def insert_dependent_df_batchwise(
    self,
    target_db_conn,
    table_name: str,
    partner_df: pd.DataFrame,
    conflict_cols: list,
    return_mapped_ids: bool = True,
    batch_size: int = 5000
) -> dict:
        """
        Insert partner_df into target_db table in batches, and collect mapped IDs.

        Args:
            target_db_conn: Target DB connection object.
            table_name (str): Target table name.
            partner_df (pd.DataFrame): DataFrame to insert.
            conflict_cols (list): Columns to handle conflicts (UPSERT keys).
            return_mapped_ids (bool): Whether to return mapping of old → new IDs.
            batch_size (int): Number of rows per batch.

        Returns:
            dict: Combined mapped IDs for all batches.
        """
        all_mapped_ids = {}

        if partner_df.empty:
            logging.info(f"[INFO] No data to insert for {table_name}")
            return all_mapped_ids

        logging.info(f"[INFO] Inserting {len(partner_df)} rows into {table_name} in batches of {batch_size}")

        # Step 1: Split DataFrame into batches
        num_batches = (len(partner_df) + batch_size - 1) // batch_size

        for i in range(num_batches):
            start_idx = i * batch_size
            end_idx = min((i + 1) * batch_size, len(partner_df))
            batch_df = partner_df.iloc[start_idx:end_idx]

            logging.info(f"[BATCH {i+1}/{num_batches}] Processing rows {start_idx} to {end_idx-1}")

            # Step 2: Insert batch using existing method
            mapped_ids_batch = self.update_partner_data_to_target_db(
                target_db_conn, table_name, batch_df, conflict_cols, return_mapped_ids
            )

            if mapped_ids_batch:
                all_mapped_ids.update(mapped_ids_batch)
                logging.info(f"[BATCH {i+1}] Mapped IDs: {len(mapped_ids_batch)} {len(all_mapped_ids)}")
            #return all_mapped_ids

        logging.info(f"[INFO] Finished inserting all batches for {table_name}")
        logging.info(f"[INFO] Total mapped IDs collected: {len(all_mapped_ids)} {len(partner_df)}")

        return all_mapped_ids
    def insert_dependent_df_batchwise_for_tenant(
    self,
    target_db_conn,
    table_name: str,
    partner_df: pd.DataFrame,
    conflict_cols: list,
    return_mapped_ids: bool = True,
    batch_size: int = 5000
) -> dict:
        """
        Insert partner_df into target_db table in batches, and collect mapped IDs by tenant.

        Args:
            target_db_conn: Target DB connection object.
            table_name (str): Target table name.
            partner_df (pd.DataFrame): DataFrame to insert.
            conflict_cols (list): Columns to handle conflicts (UPSERT keys).
            return_mapped_ids (bool): Whether to return mapping of old → new IDs.
            batch_size (int): Number of rows per batch.

        Returns:
            dict: Combined mapped IDs for all batches, grouped by tenant_id.
                Example: {"123": {"1": "3", "2": "5"}, "1": {"1": "4"}}
        """
        all_mapped_ids = {}

        if partner_df.empty:
            logging.info(f"[INFO] No data to insert for {table_name}")
            return all_mapped_ids

        logging.info(f"[INFO] Inserting {len(partner_df)} rows into {table_name} in batches of {batch_size}")

        # Step 1: Split DataFrame into batches
        num_batches = (len(partner_df) + batch_size - 1) // batch_size

        for i in range(num_batches):
            start_idx = i * batch_size
            end_idx = min((i + 1) * batch_size, len(partner_df))
            batch_df = partner_df.iloc[start_idx:end_idx]

            logging.info(f"[BATCH {i+1}/{num_batches}] Processing rows {start_idx} to {end_idx-1}")

            # Step 2: Insert batch using existing method
            mapped_ids_batch = self.update_partner_data_to_target_db(
                target_db_conn, table_name, batch_df, conflict_cols, return_mapped_ids,tenant_id_flag=True
            )

            # Step 3: Accumulate tenant-wise mappings
            if mapped_ids_batch:
                for tenant_id, mappings in mapped_ids_batch.items():
                    if tenant_id not in all_mapped_ids:
                        all_mapped_ids[tenant_id] = {}
                    #all_mapped_ids[tenant_id].update(mappings)
                    batch_count = len(mappings)
                    logging.info(f"[BATCH {i+1}] Tenant {tenant_id}: {batch_count} IDs returned in this batch")
                    # Cumulative update
                    all_mapped_ids[tenant_id].update(mappings)
                    logging.info(f"[BATCH {i+1}] Tenant {tenant_id}: {len(all_mapped_ids[tenant_id])} IDs cumulative")

                    logging.info(f"[BATCH {i+1}] Mapped IDs: {len(mapped_ids_batch)} {len(all_mapped_ids)} ")

        logging.info(f"[INFO] Finished inserting all batches for {table_name}")
        logging.info(f"[INFO] Final mapped IDs collected: {len(all_mapped_ids)} {len(partner_df)}")

        return all_mapped_ids
    def swap_fk_columns_based_on_tenant(self,df: pd.DataFrame, fk_col_col_target_mappings: dict) -> pd.DataFrame:
        """
        Swap foreign key column values in the DataFrame based on tenant-specific mappings.

        Args:
            df (pd.DataFrame): Input DataFrame containing tenant_id and foreign key columns.
            fk_col_col_target_mappings (dict): Mapping dictionary like:
                {
                    "customer_id": [None], 
                    "customer_rate_plan_id": [
                        {
                            "123": {"1": "3"},
                            "1": {"1": "4"}
                        }
                    ]
                }

        Returns:
            pd.DataFrame: Updated DataFrame with swapped values.
        """
        df = df.copy()

        for col, mappings_list in fk_col_col_target_mappings.items():
            if not isinstance(mappings_list, list) or not mappings_list:
                continue

            mapping_dict = mappings_list[0]  # actual tenant-wise mapping dict

            if not isinstance(mapping_dict, dict):
                continue

            if col not in df.columns:
                logging.info(f"[WARN] Column {col} not found in DataFrame, skipping...")
                continue

            # Process tenant-wise mappings
            for tenant_id, tenant_mapping in mapping_dict.items():
                if not isinstance(tenant_mapping, dict):
                    continue

                tenant_mask = df["tenant_id"].astype(str) == str(tenant_id)
                if not tenant_mask.any():
                    continue

                # Replace values for this tenant_id
                df.loc[tenant_mask, col] = (
                    df.loc[tenant_mask, col].astype(str).map(tenant_mapping).fillna(df.loc[tenant_mask, col])
                )

                logging.info(f"[INFO] Applied mapping for column '{col}' under tenant_id={tenant_id}")

        return df
    
    def inv_dependent_sync_tables(
    self,
    common_utils_conn,
    partner_cond_dict,
    fk_col_col_target_mappings,
    tenant_id_list,
    inv_df,
    target_db_conn,
    source_db_conn
):
        """
        Sync data for sim_management_inventory dependent tables.
        """
        
        logging.info("[START] Inventory dependent tables sync initiated")
        

        try:
            # Step 1: Build base query
            dependent_query = """
                SELECT
                    table_name, fk_columns, fk_col_target_mapping, where_cond,
                    select_query, partner_name, partner_db_tenant_id, target_db,
                    target_db_tenant_id, mapped_ids, return_mapped_ids,
                    main_tenant_db, migration_order,
                    tenant_id_flag, fk_flag, service_provider_mapping_flag,
                    tenant_based_mappings, tenant_based_mappings_flag,
                    main_tenant_db_tenant_id, fetch_based_ids, inv_flag, dependent_table_mappings
                FROM partner_provider_initial_sync_mappings WHERE
            """

            # Step 2: Add conditions
            dependent_cond_dict = {**partner_cond_dict, "inv_depen": "true"}

            # Step 3: Fetch dependent data
            dependent_cond_df = self.fetch_dependent_data(
                common_utils_conn, dependent_query, dependent_cond_dict
            )

            if dependent_cond_df.empty:
                logging.info("[INFO] No dependent tables found → skipping dependent sync.")
                
                return

            logging.info(
                f"[INFO] Dependent DataFrame fetched → {len(dependent_cond_df)} rows "
                f"(fk_col_col_target_mappings: {fk_col_col_target_mappings})"
            )
            logging.info(f"[DEBUG] Sample dependent rows:{dependent_cond_df.head(2).to_dict(orient='records')}")
            

            mobility_device_ids_dict = {}
            device_ids_dict = {}

            # Process each dependent table
            for idx, row in dependent_cond_df.iterrows():
                logging.info(f"[PROCESSING] Table: {row['table_name']} | Migration Order: {row['migration_order']}")


                # Extract row values
                table_name = row.get("table_name")
                #select_query = row["select_query"]
                partner_db_name = row.get("partner_name")
                dependent_table_mappings = row.get("dependent_table_mappings")

                # Handle dependent_table_mappings JSON
                if isinstance(dependent_table_mappings, str):
                    try:
                        dependent_table_mappings = json.loads(dependent_table_mappings)
                        logging.info(f"[INFO] Parsed dependent_table_mappings JSON → {dependent_table_mappings}")
                    except json.JSONDecodeError:
                        logging.info(f"[ERROR] Invalid JSON in dependent_table_mappings: {dependent_table_mappings}")
                        raise

                columns_list = dependent_table_mappings.get(table_name)
                if not columns_list:
                    logging.info(f"[WARN] No column mappings found for {table_name}, skipping.")
                    continue

                logging.info(f"[INFO] Required columns for {table_name}: {columns_list}")

                # Special case: mobility_device
                if table_name == "mobility_device":
                    logging.info("[INFO] Handling mobility_device records")
                    mobility_device_df = inv_df[inv_df["mobility_device_id"].notna()].copy()
                    if mobility_device_df.empty:
                        logging.info("[INFO] No mobility_device_id found in inv_df → skipping.")
                        continue

                    logging.info(f"[INFO] mobility_device rows: {len(mobility_device_df)}")
                    logging.info(f"[DEBUG] Sample rows: {mobility_device_df.head(2).to_dict(orient='records')}")

                    mobility_device_df = self.build_dependent_df(mobility_device_df, columns_list)
                    mobility_device_df = mobility_device_df.rename(columns={"mobility_device_id": "source_id"})
                    mobility_device_df["source_db"] = partner_db_name

                    logging.info(f"[INFO] Prepared mobility_device_df with columns: {mobility_device_df.columns.tolist()}")
                    conflict_cols = ["source_db", "source_id", "inv_source_id"]

                    mapped_ids = self.insert_dependent_df_batchwise(
                        target_db_conn, table_name, mobility_device_df, conflict_cols,
                        return_mapped_ids=True, batch_size=5000
                    )

                    logging.info(f"[RESULT] mobility_device mapped_ids: {len(mapped_ids)} {len(mobility_device_df)}")
                    self.update_table(
                        common_utils_conn, "partner_provider_initial_sync_mappings",
                        {"mapped_ids": json.dumps(mapped_ids)},
                        {**partner_cond_dict, "table_name": table_name}
                    )
                    mobility_device_ids_dict["mobility_device_id"] = [mapped_ids]

                elif table_name == "mobility_device_tenant":
                    logging.info("[INFO] Handling mobility_device_tenant records")
                    mdt_df = inv_df[inv_df["mdt_id"].notna()].copy()
                    if mdt_df.empty:
                        logging.info("[INFO] No mdt_id found in inv_df → skipping.")
                        continue

                    mdt_df = self.build_dependent_df(mdt_df, columns_list)
                    mdt_df = self.apply_foreign_key_mappings(mdt_df, mobility_device_ids_dict)
                    mdt_df = mdt_df.assign(tenant_id=[tenant_id_list] * len(mdt_df)).explode("tenant_id").reset_index(drop=True)
                    mdt_df = self.swap_fk_columns_based_on_tenant(mdt_df, fk_col_col_target_mappings)
                    mdt_df = mdt_df.rename(columns={"mdt_id": "source_id", "tenant_is_active": "is_active", "tenant_is_deleted": "is_deleted"})
                    mdt_df["source_db"] = partner_db_name
                    mdt_df = mdt_df.where(pd.notnull(mdt_df), None)

                    logging.info(f"[INFO] Final mobility_device_tenant_df sample: {mdt_df.head(5).to_dict(orient='records')}")
                    conflict_cols = ["source_db", "source_id", "tenant_id"]

                    mapped_ids = self.insert_dependent_df_batchwise_for_tenant(
                        target_db_conn, table_name, mdt_df, conflict_cols,
                        return_mapped_ids=True, batch_size=5000
                    )
                    logging.info("[RESULT] mobility_device_tenant mapped_ids count per tenant:")
                    for tenant_id, mappings in mapped_ids.items():
                        logging.info(f"  Tenant {tenant_id} → {len(mappings)} mapped IDs")

                    # Optional: also logging.info total across all tenants
                    total = sum(len(m) for m in mapped_ids.values())
                    logging.info(f"[RESULT] Total mapped IDs across all tenants: {total}")

                    #logging.info(f"[RESULT] mobility_device_tenant mapped_ids: {len(mapped_ids)} {len(mobility_device_df)}")
                    self.update_table(
                        common_utils_conn, "partner_provider_initial_sync_mappings",
                        {"tenant_based_mappings": json.dumps(mapped_ids)},
                        {**partner_cond_dict, "table_name": table_name}
                    )

                elif table_name == "device":
                    logging.info("[INFO] Handling device records")
                    device_df = inv_df[inv_df["device_id"].notna()].copy()
                    if device_df.empty:
                        logging.info("[INFO] No device_id found in inv_df → skipping.")
                        continue

                    logging.info(f"[INFO] device rows: {len(device_df)}")
                    logging.info(f"[DEBUG] Sample rows: {device_df.head(2).to_dict(orient='records')}")

                    device_df = self.build_dependent_df(device_df, columns_list)
                    device_df = device_df.rename(columns={"device_id": "source_id"})
                    device_df["source_db"] = partner_db_name

                    logging.info(f"[INFO] Prepared device_df with columns: {device_df.columns.tolist()}")
                    conflict_cols = ["source_db", "source_id", "inv_source_id"]

                    mapped_ids = self.insert_dependent_df_batchwise(
                        target_db_conn, table_name, device_df, conflict_cols,
                        return_mapped_ids=True, batch_size=5000
                    )

                    logging.info(f"[RESULT] device mapped_ids: {len(mapped_ids)} {len(device_df)}")
                    self.update_table(
                        common_utils_conn, "partner_provider_initial_sync_mappings",
                        {"mapped_ids": json.dumps(mapped_ids)},
                        {**partner_cond_dict, "table_name": table_name}
                    )
                    device_ids_dict["device_id"] = [mapped_ids]

                elif table_name == "device_tenant":
                    logging.info("[INFO] Handling device_tenant records")
                    dt_df = inv_df[inv_df["dt_id"].notna()].copy()
                    if dt_df.empty:
                        logging.info("[INFO] No dt_id found in inv_df → skipping.")
                        continue

                    dt_df = self.build_dependent_df(dt_df, columns_list)
                    dt_df = self.apply_foreign_key_mappings(dt_df, device_ids_dict)
                    dt_df = dt_df.assign(tenant_id=[tenant_id_list] * len(dt_df)).explode("tenant_id").reset_index(drop=True)
                    dt_df = self.swap_fk_columns_based_on_tenant(dt_df, fk_col_col_target_mappings)
                    dt_df = dt_df.rename(columns={"mdt_id": "source_id", "tenant_is_active": "is_active", "tenant_is_deleted": "is_deleted"})
                    dt_df["source_db"] = partner_db_name

                    logging.info(f"[INFO] Final device_tenant_df sample: {dt_df.head(5).to_dict(orient='records')}")
                    conflict_cols = ["source_db", "source_id", "tenant_id"]

                    mapped_ids = self.insert_dependent_df_batchwise_for_tenant(
                        target_db_conn, table_name, dt_df, conflict_cols,
                        return_mapped_ids=True, batch_size=5000
                    )

                    #logging.info(f"[RESULT] device_tenant mapped_ids: {mapped_ids}")
                    logging.info("[RESULT] mobility_device_tenant mapped_ids count per tenant:")
                    for tenant_id, mappings in mapped_ids.items():
                        logging.info(f"  Tenant {tenant_id} → {len(mappings)} mapped IDs")

                    # Optional: also logging.info total across all tenants
                    total = sum(len(m) for m in mapped_ids.values())
                    logging.info(f"[RESULT] Total mapped IDs across all tenants: {total}")
                    self.update_table(
                        common_utils_conn, "partner_provider_initial_sync_mappings",
                        {"tenant_based_mappings": json.dumps(mapped_ids)},
                        {**partner_cond_dict, "table_name": table_name}
                    )

            logging.info("[COMPLETE] Dependent tables sync finished.")

        except Exception as e:
            logging.info(f"[ERROR] Dependent Sync failed: {e}", flush=True)
    def update_query_with_tenant_ids(self,query: str, tenant_ids: list[int]) -> str:
        """
        Replace the tenant_id filter in a SQL query with a list of tenant_ids.
 
        Args:
            query (str): Original SQL query containing "tenant_id = <value>"
            tenant_ids (list[int]): List of tenant IDs (single or multiple)
 
        Returns:
            str: Updated query with "tenant_id IN (...)" condition
        """
        if not tenant_ids:
            raise ValueError("Tenant ID list cannot be empty")
 
        # Build the replacement string
        if len(tenant_ids) == 1:
            replacement = f"tenant_id = {tenant_ids[0]}"
        else:
            replacement = f"tenant_id IN ({', '.join(map(str, tenant_ids))})"
 
        # Find the part starting with "tenant_id ="
        lower_query = query.lower()
        key = "tenant_id ="
        if key not in lower_query:
            raise ValueError("Query does not contain a tenant_id condition")
 
        start_idx = lower_query.index(key)
        end_idx = start_idx + len(key)
 
        # Skip spaces and digits after "tenant_id ="
        while end_idx < len(query) and (query[end_idx].isspace() or query[end_idx].isdigit()):
            end_idx += 1
 
        # Replace the old condition with the new one
        updated_query = query[:start_idx] + replacement + query[end_idx:]
 
        return updated_query
    def update_query_with_tenant_ids(self,query: str, tenant_ids: list[int]) -> str:
        """
        Replace the tenant_id filter in a SQL query with a list of tenant_ids.
 
        Args:
            query (str): Original SQL query containing "tenant_id = <value>"
            tenant_ids (list[int]): List of tenant IDs (single or multiple)
 
        Returns:
            str: Updated query with "tenant_id IN (...)" condition
        """
        if not tenant_ids:
            raise ValueError("Tenant ID list cannot be empty")
 
        # Build the replacement string
        if len(tenant_ids) == 1:
            replacement = f"tenant_id = {tenant_ids[0]}"
        else:
            replacement = f"tenant_id IN ({', '.join(map(str, tenant_ids))})"
 
        # Find the part starting with "tenant_id ="
        lower_query = query.lower()
        key = "tenant_id ="
        if key not in lower_query:
            raise ValueError("Query does not contain a tenant_id condition")
 
        start_idx = lower_query.index(key)
        end_idx = start_idx + len(key)
 
        # Skip spaces and digits after "tenant_id ="
        while end_idx < len(query) and (query[end_idx].isspace() or query[end_idx].isdigit()):
            end_idx += 1
 
        # Replace the old condition with the new one
        updated_query = query[:start_idx] + replacement + query[end_idx:]
 
        return updated_query
    def sim_management_inventory_sync(
        self, table_name, where_cond, partner_db_conn, target_db_conn,
        common_utils_conn, partner_cond_dict, select_query, partner_db_name,
        fk_col_col_target_mappings,target_db_tenant_id, main_tenant_db_tenant_id,tenant_based_foreignkeyswapping,target_db_name
    ):
        """
        Sync data for sim_management_inventory tables.

        Args:
            table_name (str): Table name to sync.
            where_cond (dict): Conditions for filtering.
            partner_db_conn: Connection object for partner DB.
            target_db_conn: Connection object for target DB.
            common_utils_conn: Connection for utility operations.
            partner_cond_dict (dict): Extra conditions for partner DB.
            select_query (str): Base query with placeholder for WHERE condition.
            partner_db_name (str): Source DB name for tracking.
            fk_col_col_target_mappings (dict): Mapping of foreign key columns.
        """
        try:
            logging.info(f"[START] Sync process initiated for table: `{table_name}`")

            # Step 1: Build WHERE conditions
            logging.info(f"[Step 1] Fetching initial sync mappings using condition: {where_cond}")
            where_condition_values_dict = self.fetch_details_from_partner_provider_initial_sync_mappings(
                where_cond, common_utils_conn, partner_cond_dict
            )
            logging.info(f"[Step 1.1] WHERE condition values retrieved: {where_condition_values_dict} "
                f"(Type: {type(where_condition_values_dict)})")

            final_where_part = self.build_where_clause_for_inv(table_name, where_condition_values_dict)
            logging.info(f"[Step 1.2] Final WHERE clause built: {final_where_part}")
            

            # Step 2: Replace WHERE condition in query
            replaced_query = select_query.replace("<where_cond>", final_where_part)
            replaced_query = f"{replaced_query}"
            logging.info(f"[Step 2] Final SQL query prepared:{replaced_query}")
            #return True

            # Step 3: Start timer
            start_time = time.perf_counter()
            logging.info("[Step 3] Timer started for partner DB fetch...")

            # Step 4: Fetch FK mappings
            logging.info(f"[Step 4] Fetching foreign key mappings for columns: {fk_col_col_target_mappings}")
            foreign_key_mappings = self.fetching_foreignkey_values(
                fk_col_col_target_mappings, common_utils_conn, partner_cond_dict
            )
            logging.info(f"[Step 4.1] Foreign key mappings retrieved: {foreign_key_mappings}")

            logging.info(f"tenant_based_foreignkeyswapping {tenant_based_foreignkeyswapping}")
            
            tenant_based_foreing_key_mappings=self.fetching_foreignkey_values(
                tenant_based_foreignkeyswapping,common_utils_conn,partner_cond_dict
            )
            #return True
            logging.info(f"Forein key mappings based on tenant values gotten is { tenant_based_foreing_key_mappings}")
            # Step 5: Execute query on partner DB
            logging.info("[Step 5] Executing query on partner DB...")
            #inv_df=None
            
            
            inv_df = self.execute_query(partner_db_conn, replaced_query, params=None)
            logging.info(f"[Step 5.1] Rows fetched from partner DB: {len(inv_df)}")

            # Step 6: Add source DB column
            inv_df["source_db"] = partner_db_name
            logging.info(f"[Step 6] Added `source_db` column with value: {partner_db_name}")

            # Step 7: Timer end
            end_time = time.perf_counter()
            elapsed_time = end_time - start_time
            logging.info(f"[Step 7] Partner data fetch completed in {elapsed_time:.2f} seconds")

            # Step 8: Clean dataframe (replace NaN with None)
            inv_df = inv_df.astype(object).mask(inv_df.isna(), None)
            logging.info("[Step 8] Null values replaced with None")
            logging.info(f"[Step 8.1] Sample rows after cleaning: {inv_df.head(2).to_dict(orient='records')}")

            # Step 9: Apply FK mappings
            logging.info("[Step 9] Applying foreign key mappings to dataframe...")
            inv_df_swapped = self.apply_foreign_key_mappings(inv_df,foreign_key_mappings)
            logging.info(f"[Step 9.1] Dataframe updated with FK mappings, sample rows: {inv_df_swapped.head(2).to_dict(orient='records')}")
            tenant_ids_list = [x for x in [target_db_tenant_id, main_tenant_db_tenant_id] if x is not None]
            logging.info(f"Tenant_id_list gotten is {tenant_ids_list}")
            self.inv_dependent_sync_tables(common_utils_conn,partner_cond_dict,tenant_based_foreing_key_mappings,tenant_ids_list,inv_df_swapped,target_db_conn,partner_db_conn)
            logging.info(f"[COMPLETE] Sync process finished for table: `{table_name}`")
            try:
                # Step 1: Build queries
                partner_target_details_query = f"""SELECT id, target_details 
                                                FROM sim_management_inventory 
                                                {final_where_part}"""
                target_partner_details_query = f"""SELECT id, source_id 
                                                FROM sim_management_inventory 
                                                {final_where_part}"""

                # Update query with tenant IDs
                target_partner_details_query = self.update_query_with_tenant_ids(
                    target_partner_details_query, tenant_ids_list
                )
                logging.info(f"[INFO] Target partner details query:\n{target_partner_details_query}")

                # Step 2: Execute queries
                partner_target_details_df = self.execute_query(
                    partner_db_conn, partner_target_details_query, params=None
                )
                logging.info(f"[INFO] partner_target_details_df fetched with {len(partner_target_details_df)} rows")
                logging.info("[INFO] First five rows of partner_target_details_df:")
                logging.info(partner_target_details_df.head())

                target_partner_details_df = self.execute_query(
                    target_db_conn, target_partner_details_query, params=None
                )
                logging.info(f"[INFO] target_partner_details_df fetched with {len(target_partner_details_df)} rows")
                logging.info("[INFO] First five rows of target_partner_details_df:")
                logging.info(target_partner_details_df.head())

                # Step 3: Rename and group
                df = target_partner_details_df.rename(columns={"id": target_db_name})
                aggregated_df = (
                    df.groupby("source_id")[target_db_name]
                    .apply(lambda x: [{target_db_name: v} for v in x])
                    .reset_index(name="target_ids")
                )
                logging.info(f"[INFO] aggregated_df created with {len(aggregated_df)} rows")
                logging.info("[INFO] First five rows of aggregated_df:")
                logging.info(aggregated_df.head())

                # Step 4: Merge partner and aggregated
                merged_df = partner_target_details_df.merge(
                    aggregated_df,
                    how="left",
                    left_on="id",
                    right_on="source_id"
                )
                merged_df = merged_df.drop(columns=["source_id"])
                merged_df["target_ids"] = merged_df["target_ids"].apply(lambda x: x if isinstance(x, list) else [])

                # Step 5: Combine existing target_details with new target_ids
                def combine_details(existing, new_list):
                    if existing is None:
                        existing_list = []
                    elif isinstance(existing, list):
                        existing_list = existing
                    else:
                        existing_list = [existing]
                    return existing_list + new_list

                merged_df["target_details"] = merged_df.apply(
                    lambda row: combine_details(row["target_details"], row["target_ids"]),
                    axis=1
                )
                merged_df = merged_df.drop(columns=["target_ids"])
                logging.info(f"[INFO] merged_df prepared with {len(merged_df)} rows")
                logging.info("[INFO] First five rows of merged_df:")
                logging.info(merged_df.head())

                # Step 6: Process in batches
                batch_size = 5000
                total_rows = len(merged_df)
                logging.info(f"[INFO] Starting batch updates: total rows={total_rows}, batch_size={batch_size}")

                for start in range(0, total_rows, batch_size):
                    end = start + batch_size
                    batch_df = merged_df.iloc[start:end]
                    logging.info(f"[INFO] Processing batch rows {start} to {min(end, total_rows)}...")
                    self.update_data_history_table_bulk(partner_db_conn, table_name, batch_df, conflict_col=["id"])

                logging.info("[INFO] All batches processed successfully.")

            except Exception as e:
                logging.info(f"[ERROR] Failed while executing partner/target details queries: {e}")
                partner_target_details_df, target_partner_details_df = None, None
        except Exception as e:
            logging.info(f"[ERROR] Sync failed for table `{table_name}`: {e}", flush=True)
    def fetch_mapped_keys(self,conn, mapping_list: list, partner_cond_dict: dict):
        """
        Fetch mapped_ids from DB and return only keys.

        Args:
            conn: psycopg2 connection object
            mapping_list (list): Mapping config
            partner_cond_dict (dict): Conditions to apply in WHERE clause

        Returns:
            dict: {col_name: [list_of_keys]}
        """
        result_dict = {}

        cursor = conn.cursor()

        for mapping in mapping_list:
            for col_name, details in mapping.items():
                where_col = details.get("where_col")
                where_table = details.get("where_table")
                extra_conditions = details.get("<where_condition>", {})

                # Build WHERE conditions from both partner_cond_dict and extra_conditions
                conditions = []
                values = []

                for k, v in {**partner_cond_dict, **extra_conditions}.items():
                    conditions.append(f"{k} = %s")
                    values.append(v)

                where_clause = " AND ".join(conditions)

                query = f"SELECT {where_col} FROM {where_table} WHERE {where_clause};"
                logging.info(f"select query formed {query} {values}")
                cursor.execute(query, tuple(values))
                rows = cursor.fetchall()

                keys_list = []
                for row in rows:
                    mapped_ids_raw = row[0]
                    if mapped_ids_raw:
                        if isinstance(mapped_ids_raw, str):
                            mapped_ids = json.loads(mapped_ids_raw)
                        else:
                            mapped_ids = mapped_ids_raw
                        if isinstance(mapped_ids, dict):
                            keys_list.extend(mapped_ids.keys())

                result_dict[col_name] = list(set(keys_list))  # unique keys

        cursor.close()
        return result_dict
    def extract_values_from_conditions(self, conditions: dict) -> dict:
        """
        Takes a dict of {col_name: df_series or list} and extracts only values 
        from inner dict/json strings. Returns {col_name: [only values]}.
        """
        clean_conditions = {}

        logging.info("Starting extraction process...")
        for col, series in conditions.items():
            logging.info(f"Processing column: {col}")
            logging.info(f"Raw series: {series}, Type: {type(series)}")

            values = []

            # Normalize into a list
            if isinstance(series, pd.DataFrame):
                series_values = series.iloc[:, 0].tolist()
                logging.info(f"Converted DataFrame to list: {series_values}")
            elif isinstance(series, pd.Series):
                series_values = series.tolist()
                logging.info(f"Converted Series to list: {series_values}")
            else:
                series_values = [series]
                logging.info(f"Wrapped single value into list: {series_values}")

            # Extract only inner dict values
            for val in series_values:
                logging.info(f"Handling value: {val}, Type: {type(val)}")
                if isinstance(val, str):
                    try:
                        parsed = json.loads(val)
                        if isinstance(parsed, dict):
                            dict_values = list(parsed.values())
                            logging.info(f"Parsed JSON dict to values: {dict_values}")
                            values.extend(dict_values)
                        else:
                            logging.info(f"Parsed JSON non-dict: {parsed}")
                            values.append(parsed)
                    except Exception:
                        logging.info(f"Not JSON, keeping as-is: {val}")
                        values.append(val)
                elif isinstance(val, dict):
                    dict_values = list(val.values())
                    logging.info(f"Direct dict to values: {dict_values}")
                    values.extend(dict_values)
                else:
                    logging.info(f"Keeping raw value: {val}")
                    values.append(val)

            clean_conditions[col] = values
            logging.info(f"Extracted values for {col}: {values}")

        logging.info("Final clean_conditions:", clean_conditions)
        return clean_conditions
    def build_dynamic_query(self,base_query: str, conditions: dict) -> str:
        """
        Takes a base query with placeholder <where_cond>
        and a dict of {column: [values]}.
        Builds a proper WHERE clause dynamically and returns the final query.
        """
        where_clauses = []

        for col, values in conditions.items():
            if not values:
                continue  # skip empty lists
            formatted_values = ", ".join(f"'{v}'" for v in values)
            where_clauses.append(f"{col} IN ({formatted_values})")

        # If no conditions, just remove the placeholder
        if where_clauses:
            where_sql = " AND ".join(where_clauses)
            final_query = base_query.replace("<where_cond>", where_sql)
        else:
            final_query = base_query.replace("WHERE <where_cond>", "")

        return final_query
    def update_data_history_table_bulk(self, postgres_conn, table_name, df, conflict_col):
        """
        Inserts or updates data in a PostgreSQL table based on conflict.
        Accepts a pandas DataFrame as input and serializes dict/list to JSON for jsonb columns.

        Parameters:
            postgres_conn: Active PostgreSQL connection
            table_name (str): Name of the target table
            df (pd.DataFrame): Data to insert or update
            conflict_col (str or list): Column name(s) to check for conflicts
        """
        if df is None or df.empty:
            logging.info("[INFO] No data provided for insertion.")
            return

        try:
            with postgres_conn.cursor() as cursor:
                # Ensure conflict_col is a list
                conflict_cols = conflict_col if isinstance(conflict_col, list) else [conflict_col]

                # Extract columns from DataFrame
                columns = df.columns.tolist()

                # Serialize dict/list columns to JSON
                df_serialized = df.copy()
                for col in columns:
                    # Only serialize dict or list types
                    df_serialized[col] = df_serialized[col].apply(
                        lambda x: json.dumps(x) if isinstance(x, (dict, list)) else x
                    )

                # Prepare column strings
                columns_str = ", ".join(columns)
                conflict_cols_str = ", ".join(conflict_cols)

                # Prepare update set excluding conflict columns
                update_set = ", ".join(
                    [f"{col} = EXCLUDED.{col}" for col in columns if col not in conflict_cols]
                )

                # Construct the UPSERT query
                query = f"""
                    INSERT INTO {table_name} ({columns_str})
                    VALUES %s
                    ON CONFLICT ({conflict_cols_str})
                    DO UPDATE SET {update_set};
                """

                # Convert DataFrame to list of tuples
                values = [tuple(row) for row in df_serialized[columns].values]

                logging.info(f"Executing UPSERT on table {table_name}")
                execute_values(cursor, query, values)
                postgres_conn.commit()
                logging.info(f"[SUCCESS] {len(df)} records inserted/updated in {table_name}")

        except Exception as e:
            postgres_conn.rollback()
            logging.info(f"[ERROR] Failed to upsert data into {table_name}: {e}", exc_info=True)
    def insert_audit_record(self,conn, audit_insert_query, audit_params):
        """
        Inserts an audit record and returns the generated audit id.

        Args:
            conn: psycopg2 connection object
            audit_insert_query (str): SQL insert query with RETURNING id
            audit_params (tuple): Parameters for the insert query

        Returns:
            int: The generated audit id
        """
        try:
            with conn.cursor() as cur:
                cur.execute(audit_insert_query, audit_params)
                audit_id = cur.fetchone()[0]  # fetch the returned id
                conn.commit()
                return audit_id
        except Exception as e:
            conn.rollback()
            raise Exception(f"Error inserting audit record: {e}")
    def build_target_details_df(self, mapping, target_db_name, tenant_id_flag=False, target_details_df=None):
        """
        Build DataFrame with id and target_details.
        Handles int, uuid, or string id types safely.

        Args:
            mapping (dict): 
                if tenant_id_flag = False → {"22": 7, "47": 12}
                if tenant_id_flag = True  → {"123": {"1": 3, "2": 5}, "1": {"1": 4}}
            target_db_name (str): target DB name
            tenant_id_flag (bool): handle multi-tenant mappings
            target_details_df (pd.DataFrame, optional): existing df with id,target_details

        Returns:
            pd.DataFrame: updated DataFrame with 'id' and 'target_details'
        """
        records = []

        if not tenant_id_flag:
            # Single tenant mapping
            for src_id, tgt_id in mapping.items():
                records.append({
                    "id": str(src_id),  # normalize to string
                    "target_details": {target_db_name: tgt_id}
                })
        else:
            # Multi-tenant mapping → collect multiple targets per src_id
            grouped = {}
            for src_id, tenant_map in mapping.items():
                grouped.setdefault(str(src_id), [])
                for _, tgt_id in tenant_map.items():
                    grouped[str(src_id)].append({target_db_name: tgt_id})

            for src_id, tgt_list in grouped.items():
                records.append({
                    "id": str(src_id),
                    "target_details": tgt_list
                })

        new_df = pd.DataFrame(records)

        if target_details_df is not None and not target_details_df.empty:
            # Normalize to string for safe merge (int, uuid, str all work)
            target_details_df = target_details_df.copy()
            target_details_df["id"] = target_details_df["id"].astype(str)

            merged_df = target_details_df.merge(new_df, on="id", how="left", suffixes=("", "_new"))

            # Safely combine details
            def combine_details(row):
                existing = row["target_details"]
                new = row["target_details_new"]

                # Handle None or NaN in existing
                if existing is None or (isinstance(existing, float) and pd.isna(existing)):
                    existing = []
                elif not isinstance(existing, list):
                    existing = [existing]

                # Handle None or NaN in new
                if new is None or (isinstance(new, float) and pd.isna(new)):
                    new = []
                elif not isinstance(new, list):
                    new = [new]

                return existing + new

            merged_df["target_details"] = merged_df.apply(combine_details, axis=1)
            merged_df = merged_df.drop(columns=["target_details_new"])
            return merged_df

        return new_df
    def perform_intial_sync(self, data):
        """
        Objective: Perform initial sync of data from source_db to target_db based on selected customer group/plan.
        """
        try:
            logging.info(f"=== Initial Sync Process Started === {data}")
            source_db = data.get("source_db")
            logging.info(f"[DEBUG] Step 0 - source_db extracted: {source_db} (Type: {type(source_db)})")

            target_db = data.get("target_db")
            logging.info(f"[DEBUG] Step 0 - target_db extracted: {target_db} (Type: {type(target_db)})")

            main_tenant_db = data.get("main_tenant_db")
            logging.info(f"[DEBUG] Step 0 - main_tenant_db extracted: {main_tenant_db} (Type: {type(main_tenant_db)})")

            # --- Step 1: Setup connections ---
            logging.info("[Step 1] Reading DB config from environment variables")
            load_dotenv()
            common_utils_db = os.getenv("COMMON_UTILS_DB")
            host = os.getenv("PSQL_DB_HOST")
            db_type = os.getenv("PSQL_DB_TYPE")
            username = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            port = os.getenv("PSQL_DB_PORT")
            logging.info(f"[DEBUG] Environment variables loaded: COMMON_UTILS_DB={common_utils_db}, HOST={host}, DB_TYPE={db_type}, USER={username}, PORT={port}")

            logging.info(f"[Step 2] Creating connection to common utils DB '{common_utils_db}'")
            common_utils_conn = self.create_connection(db_type, host, common_utils_db, username, password, port)
            if common_utils_conn is None:
                logging.info("[ERROR][Step 2] Failed to connect to Common Utils DB")
                return False
            logging.info("[Step 2] Common Utils DB connection successful")

            # --- Step 3: Fetch sync mapping details ---
            logging.info("[Step 3] Fetching sync mapping details from 'partner_provider_initial_sync_mappings'")
            details_query = '''
                SELECT
                    table_name, fk_columns, fk_col_target_mapping, where_cond,
                    select_query, partner_name, partner_db_tenant_id, target_db,
                    target_db_tenant_id, mapped_ids, return_mapped_ids,
                    main_tenant_db, migration_order,
                    tenant_id_flag, fk_flag, service_provider_mapping_flag,
                    tenant_based_mappings, tenant_based_mappings_flag,
                    main_tenant_db_tenant_id, fetch_based_ids,inv_flag,tenant_based_foreign_keyswapping
                FROM partner_provider_initial_sync_mappings
                WHERE (main_tenant_db=%s OR target_db=%s)
                AND partner_name=%s
                AND service_provider_mapping_flag IS NULL AND is_active=true
                ORDER BY migration_order ASC;
            '''
            df = self.execute_query(common_utils_conn, details_query, (main_tenant_db, target_db, source_db))
            logging.info(f"[Step 3] Retrieved {len(df)} mapping rows")

            # --- Step 4: Loop through mapping rows ---
            for index, row in df.iterrows():
                logging.info(f"--- Step 4: Processing mapping row {index + 1}/{len(df)} ---")
                table_name = row["table_name"]
                logging.info(f"[DEBUG] Table to process: {table_name}")

                # Extracting other mapping details
                fk_columns = row["fk_columns"]
                fk_col_target_mapping = row["fk_col_target_mapping"]
                where_cond = row["where_cond"]
                select_query = row["select_query"]
                partner_db_tenant_id = row.get("partner_db_tenant_id")
                target_db_tenant_id = row.get("target_db_tenant_id")
                mapped_ids = row.get("mapped_ids")
                return_mapped_ids = row.get("return_mapped_ids")
                main_tenant_db = row.get("main_tenant_db")
                migration_order = row.get("migration_order")
                partner_db_name = row.get("partner_name")
                target_db_name = row.get("target_db")
                tenant_id_flag = row.get("tenant_id_flag")
                fk_flag = row.get("fk_flag")
                main_tenant_db_tenant_id = row.get("main_tenant_db_tenant_id")
                tenant_based_mappings_flag = row.get("tenant_based_mappings_flag")
                tenant_based_mappings = row.get("tenant_based_mappings")
                fetch_based_ids = row.get("fetch_based_ids")
                inv_flag=row.get("inv_flag")
                tenant_based_foreignkeyswapping=row.get("tenant_based_foreign_keyswapping")

                logging.info(f"[DEBUG] Row details: PartnerDB='{partner_db_name}', TargetDB='{target_db_name}', MigrationOrder={migration_order}")

                # --- Step 5: Create DB connections ---
                logging.info("[Step 5] Creating partner and target DB connections")
                partner_db_conn = self.create_connection(db_type, host, partner_db_name, username, password, port)
                target_db_conn = self.create_connection(db_type, host, (main_tenant_db or target_db_name), username, password, port)
                logging.info(f"[DEBUG] Connections status => PartnerDB={'OK' if partner_db_conn else 'FAILED'}, TargetDB={'OK' if target_db_conn else 'FAILED'}")

                audit_insert_query = """
                    INSERT INTO public.pbp_migration_history
                    (partner_name, partner_db_tenant_id, target_db, target_db_tenant_id, target_name,
                    main_tenant_db, main_tenant_db_tenant_id, table_name, status, details, started_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,  TIMEZONE('UTC', NOW()))
                    RETURNING id;
                """
                audit_params = (
                    partner_db_name, partner_db_tenant_id, target_db, target_db_tenant_id, target_db_name,
                    main_tenant_db, main_tenant_db_tenant_id, table_name, "IN_PROGRESS", None
                )
                audit_id = self.insert_audit_record(common_utils_conn, audit_insert_query, audit_params)
                logging.info(f"[Step 5] Audit record inserted with ID: {audit_id}")

                # --- Step 6: Prepare condition dict ---
                if main_tenant_db_tenant_id:
                    partner_cond_dict = {
                        "partner_db_tenant_id": partner_db_tenant_id,
                        "target_db_tenant_id": target_db_tenant_id,
                        "main_tenant_db_tenant_id": main_tenant_db_tenant_id
                    }
                    logging.info(f"[Step 6] Using main_tenant_db_tenant_id={main_tenant_db_tenant_id}")
                else:
                    partner_cond_dict = {
                        "partner_db_tenant_id": partner_db_tenant_id,
                        "target_db_tenant_id": target_db_tenant_id
                    }
                    logging.info("[Step 6] No main_tenant_db_tenant_id, using only partner_db_tenant_id & target_db_tenant_id")

                logging.info(f"[DEBUG] Partner condition dict: {partner_cond_dict}")

                # --- Step 7: Handle WHERE conditions ---
                logging.info(f"[Step 7] Raw WHERE condition={where_cond} | fetch_based_ids_flag={fetch_based_ids} | INV flag={inv_flag}")

                if inv_flag:
                    logging.info(f"[Step 7] Inventory sync detected. Skipping further processing for table {table_name}.")
                    self.sim_management_inventory_sync(table_name,where_cond,partner_db_conn,target_db_conn,common_utils_conn,partner_cond_dict,select_query,partner_db_name,fk_col_target_mapping,target_db_tenant_id, main_tenant_db_tenant_id,tenant_based_foreignkeyswapping,target_db_name)
                    return True

                if fetch_based_ids:
                    logging.info(f"[Step 7.1] fetch_based_ids flag is TRUE → resolving with fetch_mapped_keys()")
                    cleared_conditions = self.fetch_mapped_keys(common_utils_conn, where_cond, partner_cond_dict)
                else:
                    final_where_part = self.fetch_details_from_partner_provider_initial_sync_mappings(where_cond, common_utils_conn, partner_cond_dict)
                    logging.info(f"[Step 7.1] WHERE condition values resolved: {final_where_part}")
                    cleared_conditions = self.extract_values_from_conditions(final_where_part)

                logging.info(f"[Step 7.2] Cleared WHERE condition values: {cleared_conditions}")

                # --- Step 8: Build final query ---
                final_query = self.build_dynamic_query(select_query, cleared_conditions)
                logging.info(f"[Step 8] Final SELECT query built: {final_query}")

                # --- Step 9: Execute query on partner DB ---
                partner_df = self.execute_query(partner_db_conn, final_query, params=None)
                if partner_df.empty:
                    logging.info(f"[Step 9] No data found in Partner DB for table '{table_name}', skipping.")
                    continue
                partner_df["source_db"] = partner_db_name
                logging.info(f"[Step 9] Partner data fetched: {len(partner_df)} rows")
                logging.info(f"[DEBUG] Sample rows: {partner_df.head(2).to_dict(orient='records')}")

                # --- Step 10: Handle foreign keys ---
                if fk_flag and not tenant_based_mappings_flag:
                    logging.info(f"[Step 10] Resolving foreign keys for {table_name}")
                    foreign_key_mappings = self.fetching_foreignkey_values(fk_col_target_mapping, common_utils_conn, partner_cond_dict)
                    partner_df = self.apply_foreign_key_mappings(partner_df, foreign_key_mappings)
                    logging.info(f"[Step 10] Partner DF updated with FK mappings, sample: {partner_df.head(2).to_dict(orient='records')}")

                # --- Step 11: Tenant handling ---
                tenant_ids_list = [x for x in [target_db_tenant_id, main_tenant_db_tenant_id] if x is not None] if tenant_id_flag else []
                conflict_cols = ["source_db", "source_id", "tenant_id"] if tenant_id_flag else ["source_db", "source_id"]
                logging.info(f"[Step 11] Tenant handling | tenant_id_flag={tenant_id_flag} | tenant_ids_list={tenant_ids_list}")

                # --- Step 12: Update to Target DB ---
                partner_df = partner_df.astype(object).mask(partner_df.isna(), None)
                logging.info(f"[Step 12] Updating TargetDB='{target_db_name}' | Table='{table_name}' | ConflictCols={conflict_cols}")
                if tenant_ids_list:
                    expanded_df = partner_df.assign(tenant_id=[tenant_ids_list] * len(partner_df)).explode("tenant_id").reset_index(drop=True)
                    logging.info(f"[DEBUG] Expanded DF rows={len(expanded_df)} | Sample={expanded_df.head(2).to_dict(orient='records')}")
                    mapped_ids = self.update_partner_data_to_target_db(target_db_conn, table_name, expanded_df, conflict_cols, return_mapped_ids, tenant_id_flag)
                else:
                    mapped_ids = self.update_partner_data_to_target_db(target_db_conn, table_name, partner_df, conflict_cols, return_mapped_ids)
                logging.info(f"[Step 12] Mapped IDs returned: {len(mapped_ids)}")

                # --- Step 13: Update mapping table ---
                update_dict = {"tenant_based_mappings" if tenant_id_flag else "mapped_ids": json.dumps(mapped_ids)}
                self.update_table(common_utils_conn, "partner_provider_initial_sync_mappings", update_dict, {**partner_cond_dict, "table_name": table_name})
                logging.info(f"[Step 13] partner_provider_initial_sync_mappings updated for table={table_name}")

                try:
                    target_details_query=f"select id,target_details from {table_name} WHERE <where_cond>"
                    final_target_query = self.build_dynamic_query(target_details_query, cleared_conditions)
                    target_details_df = self.execute_query(partner_db_conn, final_target_query, params=None)
                    logging.info(f"{tenant_id_flag}[DEBUG] Target Details DF (first 5 records): {target_details_df.head(5)}")
                    target_details_updated_df=self.build_target_details_df(mapped_ids,target_db_name,tenant_id_flag,target_details_df)
                    logging.info(f"[DEBUG] Updated Target Details DF (first 5 records): {target_details_updated_df.head(5)}")
                    self.update_data_history_table_bulk(partner_db_conn,table_name,target_details_updated_df,conflict_col=["id"])
                    
                except Exception as e:
                    logging.info(f"[ERROR] Error while updating target details: {e}")
                # --- Step 14: Update audit table ---
                cond_dict = {"id": audit_id}
                update_dict = {"status": "SUCCESS", "completed_at":  datetime.now(timezone.utc)}
                self.update_table(common_utils_conn,"pbp_migration_history",update_dict,cond_dict)
                logging.info(f"[Step 14] Audit table updated for audit_id={audit_id}")

                logging.info(f"--- Completed processing for table={table_name} ---")
                

            logging.info("=== Initial Sync Process Completed Successfully ===")
            return True

        except Exception as e:
            logging.info(f"[ERROR] perform_intial_sync failed: {str(e)}", exc_info=True)
            cond_dict = {"id": audit_id}
            update_dict = {"status": "FAILED", "error_msg": str(e), "completed_at":  datetime.now(timezone.utc)}
            self.update_table(common_utils_conn,"pbp_migration_history",update_dict,cond_dict)
            return False
    def perform_intial_sync_bak_30_09_2025(self, data):
        """
        Objective: Perform initial sync of data from source_db to target_db based on selected customer group/plan.
        """
        try:

            logging.info(f"=== Initial Sync Process Started === {data}")
            source_db = data.get("source_db")
            logging.info(f"[DEBUG] source_db extracted: {source_db} (Type: {type(source_db)})")

            target_db = data.get("target_db")
            logging.info(f"[DEBUG] target_db extracted: {target_db} (Type: {type(target_db)})")

            main_tenant_db = data.get("main_tenant_db")
            logging.info(f"[DEBUG] main_tenant_db extracted: {main_tenant_db} (Type: {type(main_tenant_db)})")


            # --- Step 1: Setup connections ---
            logging.info("[Step 1] Reading DB config from environment variables")
            load_dotenv()
            logging.info("=== Initial Sync Process Started ===")

            # --- Step 1: Setup connections ---
            logging.info("[Step 1] Reading DB config from environment variables")
            common_utils_db = os.getenv("COMMON_UTILS_DB")
            host = os.getenv("PSQL_DB_HOST")
            db_type = os.getenv("PSQL_DB_TYPE")
            username = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            port = os.getenv("PSQL_DB_PORT")

            logging.info(f"[Step 2] Creating connection to common utils DB '{common_utils_db}' "
                f"at {host}:{port} (db_type={db_type}, user={username})")
            common_utils_conn = self.create_connection(db_type, host, common_utils_db, username, password, port)
            if common_utils_conn is None:
                logging.info("[ERROR][Step 2] Failed to connect to Common Utils DB")
                return False
            logging.info("[Step 2] Common Utils DB connection successful")

            # --- Step 3: Fetch sync mapping details ---
            logging.info("[Step 3] Fetching sync mapping details from 'partner_provider_initial_sync_mappings'")
            details_query = '''
                SELECT
                    table_name, fk_columns, fk_col_target_mapping, where_cond,
                    select_query, partner_name, partner_db_tenant_id, target_db,
                    target_db_tenant_id, mapped_ids, return_mapped_ids,
                    main_tenant_db, migration_order,
                    tenant_id_flag, fk_flag, service_provider_mapping_flag,
                    tenant_based_mappings, tenant_based_mappings_flag,
                    main_tenant_db_tenant_id, fetch_based_ids,inv_flag,tenant_based_foreign_keyswapping
                FROM partner_provider_initial_sync_mappings
                WHERE (main_tenant_db=%s OR target_db=%s)
                AND partner_name=%s
                AND service_provider_mapping_flag IS NULL AND is_active=true
                ORDER BY migration_order ASC;
            '''
            df = self.execute_query(common_utils_conn, details_query, (target_db, target_db, source_db))
            logging.info(f"[Step 3] Retrieved {len(df)} mapping rows")

            # --- Step 4: Loop through mapping rows ---
            for index, row in df.iterrows():
                logging.info(f"--- Processing mapping row {index + 1} of {len(df)} ---")

                # Extract mapping row values
                table_name = row["table_name"]
                fk_columns = row["fk_columns"]
                fk_col_target_mapping = row["fk_col_target_mapping"]
                where_cond = row["where_cond"]
                select_query = row["select_query"]
                partner_db_tenant_id = row.get("partner_db_tenant_id")
                target_db_tenant_id = row.get("target_db_tenant_id")
                mapped_ids = row.get("mapped_ids")
                return_mapped_ids = row.get("return_mapped_ids")
                main_tenant_db = row.get("main_tenant_db")
                migration_order = row.get("migration_order")
                partner_db_name = row.get("partner_name")
                target_db_name = row.get("target_db")
                tenant_id_flag = row.get("tenant_id_flag")
                fk_flag = row.get("fk_flag")
                main_tenant_db_tenant_id = row.get("main_tenant_db_tenant_id")
                tenant_based_mappings_flag = row.get("tenant_based_mappings_flag")
                tenant_based_mappings = row.get("tenant_based_mappings")
                fetch_based_ids = row.get("fetch_based_ids")
                inv_flag=row.get("inv_flag")
                tenant_based_foreignkeyswapping=row.get("tenant_based_foreign_keyswapping")

                logging.info(f"[Step 4] Table='{table_name}' | PartnerDB='{partner_db_name}' | TargetDB='{target_db_name}' | MigrationOrder={migration_order}")

                # --- Step 5: Create DB connections ---
                partner_db_conn = self.create_connection(db_type, host, partner_db_name, username, password, port)
                target_db_conn = self.create_connection(db_type, host, (main_tenant_db or target_db_name), username, password, port)
                logging.info(f"[Step 5] Connections => PartnerDB={'OK' if partner_db_conn else 'FAILED'} | TargetDB={'OK' if target_db_conn else 'FAILED'}")

                # --- Step 6: Prepare condition dict ---
                if main_tenant_db_tenant_id:
                    partner_cond_dict = {
                        "partner_db_tenant_id": partner_db_tenant_id,
                        "target_db_tenant_id": target_db_tenant_id,
                        "main_tenant_db_tenant_id": main_tenant_db_tenant_id
                    }
                    logging.info(f"[Step 6] Using main_tenant_db_tenant_id={main_tenant_db_tenant_id}")
                else:
                    partner_cond_dict = {
                        "partner_db_tenant_id": partner_db_tenant_id,
                        "target_db_tenant_id": target_db_tenant_id
                    }
                    logging.info("[Step 6] No main_tenant_db_tenant_id, using only partner_db_tenant_id & target_db_tenant_id")

                logging.info(f"[Step 6] Partner condition dict: {partner_cond_dict}")

                # --- Step 7: Handle WHERE conditions ---
                logging.info(f"[Step 7] Raw WHERE condition={where_cond} | fetch_based_ids_flag={fetch_based_ids} | INV flag {inv_flag}")
                
                if inv_flag:
                    logging.info(f"This function Is used to sync the inventory tables only {inv_flag} {table_name} {partner_cond_dict}")

                    self.sim_management_inventory_sync(table_name,where_cond,partner_db_conn,target_db_conn,common_utils_conn,partner_cond_dict,select_query,partner_db_name,fk_col_target_mapping,target_db_tenant_id, main_tenant_db_tenant_id,tenant_based_foreignkeyswapping)
                    return True

                if fetch_based_ids:
                    logging.info(f"[Step 7.1] fetch_based_ids flag is TRUE → resolving with fetch_mapped_keys()")
                    cleared_conditions = self.fetch_mapped_keys(common_utils_conn, where_cond, partner_cond_dict)
                else:
                    final_where_part = self.fetch_details_from_partner_provider_initial_sync_mappings(where_cond, common_utils_conn, partner_cond_dict)
                    logging.info(f"[Step 7.1] WHERE condition values resolved: {final_where_part}")
                    
                    cleared_conditions = self.extract_values_from_conditions(final_where_part)
                logging.info(f"[Step 7.2] Cleared WHERE condition values: {cleared_conditions}")

                # --- Step 8: Build final query ---
                final_query = self.build_dynamic_query(select_query, cleared_conditions)
                logging.info(f"[Step 8] Final SELECT query built:{final_query}")

                # --- Step 9: Execute query on partner DB ---
                partner_df = self.execute_query(partner_db_conn, final_query, params=None)
                if partner_df.empty:
                    logging.info(f"[Step 10] No data present in partner DB for table '{table_name}', skipping to next table")
                    continue  # move to next row in the loop
                partner_df["source_db"] = partner_db_name
                logging.info(f"[Step 9] Partner data fetched: {len(partner_df)} rows")
                if not partner_df.empty:
                    logging.info(f"[Step 9] Sample rows: {partner_df.head(2).to_dict(orient='records')}")

                # --- Step 10: Handle foreign keys ---
                if fk_flag and not tenant_based_mappings_flag:
                    logging.info(f"[Step 10] Resolving foreign keys for {table_name} | fk_flag={fk_flag}")
                    foreign_key_mappings = self.fetching_foreignkey_values(fk_col_target_mapping, common_utils_conn, partner_cond_dict)
                    logging.info(f"[Step 10] Foreign key mappings retrieved: {foreign_key_mappings}")
                    partner_df = self.apply_foreign_key_mappings(partner_df, foreign_key_mappings)
                    logging.info(f"[Step 10] Partner dataframe updated with FK mappings, sample: {partner_df.head(2).to_dict(orient='records')}")
                

                # --- Step 11: Tenant handling ---
                tenant_ids_list = [x for x in [target_db_tenant_id, main_tenant_db_tenant_id] if x is not None] if tenant_id_flag else []
                conflict_cols = ["source_db", "source_id", "tenant_id"] if tenant_id_flag else ["source_db", "source_id"]
                logging.info(f"[Step 11] Tenant handling | tenant_id_flag={tenant_id_flag} | tenant_ids_list={tenant_ids_list}")

                # --- Step 12: Update to Target DB ---
                partner_df = partner_df.astype(object).mask(partner_df.isna(), None)
                logging.info(f"[Step 12] Updating TargetDB='{target_db_name}' | Table='{table_name}' | ConflictCols={conflict_cols}")
                if tenant_ids_list:
                    expanded_df = partner_df.assign(tenant_id=[tenant_ids_list] * len(partner_df)).explode("tenant_id").reset_index(drop=True)
                    logging.info(f"[Step 12] Expanded DF rows={len(expanded_df)} | Sample={expanded_df.head(2).to_dict(orient='records')}")
                    mapped_ids = self.update_partner_data_to_target_db(target_db_conn, table_name, expanded_df, conflict_cols, return_mapped_ids, tenant_id_flag)
                else:
                    mapped_ids = self.update_partner_data_to_target_db(target_db_conn, table_name, partner_df, conflict_cols, return_mapped_ids)

                logging.info(f"[Step 12] Mapped IDs returned: {mapped_ids}")

                # --- Step 13: Update mapping table ---
                update_dict = {"tenant_based_mappings" if tenant_id_flag else "mapped_ids": json.dumps(mapped_ids)}
                self.update_table(common_utils_conn, "partner_provider_initial_sync_mappings", update_dict, {**partner_cond_dict, "table_name": table_name})
                logging.info(f"[Step 13] partner_provider_initial_sync_mappings updated for table={table_name}")

                logging.info(f"--- Completed processing for table={table_name} ---")
                

            logging.info("=== Initial Sync Process Completed Successfully ===")
            return True

        except Exception as e:
            logging.info(f"[ERROR] perform_intial_sync failed: {str(e)}", exc_info=True)
            return False
if __name__ == "__main__":
    
    scheduler = MigrationScheduler()
    load_dotenv()
    target_db = 'partner_test_db'
    source_db = 'altaworx_go_tech'
    new_target_db = 'partner_test_db_2'
    main_tenant_db='partner_test_db'

    # scheduler.add_mapping_cols_to_source_target(source_db,main_tenant_db)

    #scheduler.create_table_mappings_for_new_provider(source_db,'181',target_db,'190',main_tenant_db,'1')

    #scheduler.create_sub_tenant_history_tables(source_db,target_db,main_tenant_db)
    #scheduler.perform_intial_sync(source_db,target_db,main_tenant_db)
