import boto3
import os
import time
import re
import json
import traceback
import uuid


dms_client = boto3.client('dms')
s3_client = boto3.client('s3')
ssm = boto3.client('ssm')
sns_client = boto3.client('sns')  # SNS client

def send_sns_alert(subject, message):
    topic_arn = os.environ.get('SNS_TOPIC_ARN')
    if not topic_arn:
        print("SNS_TOPIC_ARN is not set in environment variables")
        return
    try:
        sns_client.publish(
            TopicArn=topic_arn,
            Subject=subject,
            Message=message
        )
    except Exception as e:
        print(f"Failed to send SNS alert: {e}")
        
def sanitize_identifier(name):
    sanitized = re.sub(r'[^a-zA-Z0-9-]', '-', name)
    sanitized = re.sub(r'--+', '-', sanitized)
    if not sanitized[0].isalpha():
        sanitized = f"a{sanitized}"
    sanitized = sanitized.rstrip('-')
    return sanitized

def add_s3_lambda_notification(bucket_name, lambda_arn, max_retries=5, delay=5):
    s3 = boto3.client("s3")
    lambda_client = boto3.client("lambda")

    # Generate unique StatementId
    statement_id = f"trigger-CDC-Lambda-{uuid.uuid4()}"

    # Add Lambda permission
    try:
        lambda_client.add_permission(
            FunctionName=lambda_arn,
            StatementId=statement_id,
            Action="lambda:InvokeFunction",
            Principal="s3.amazonaws.com",
            SourceArn=f"arn:aws:s3:::{bucket_name}"
        )
    except lambda_client.exceptions.ResourceConflictException:
        # Permission already exists, continue
        pass

    # Prepare S3 notification configuration
    notification_cfg = {
        "LambdaFunctionConfigurations": [
            {
                "Id": f"trigger-CDC-Lambda-{uuid.uuid4()}",
                "LambdaFunctionArn": lambda_arn,
                "Events": ["s3:ObjectCreated:*"]
            }
        ]
    }

    # Retry logic for put_bucket_notification_configuration
    for attempt in range(1, max_retries + 1):
        try:
            s3.put_bucket_notification_configuration(
                Bucket=bucket_name,
                NotificationConfiguration=notification_cfg
            )
            return f"S3 notification configured for bucket '{bucket_name}' → Lambda '{lambda_arn}'"
        except s3.exceptions.ClientError as e:
            if "InvalidArgument" in str(e):
                if attempt < max_retries:
                    time.sleep(delay)
                    continue  # retry
                else:
                    raise
            else:
                raise

def create_dms_task(source_arn, target_arn, replication_instance_arn, tenant_db_name, s3_bucket_name, billing_flag):
    task_id = sanitize_identifier(f"{tenant_db_name}-beta")
    rules = []

    # Define tables based on billing flag
    tables = [
        "e911customers","customergroups","sim_management_inventory","rule_rule_definition",
        "sim_order_form","carrier_rate_plan","customer_rate_pool","sim_management_communication_plan",
        "imei_master","sim_management_carrier_feature_codes_uat","mobility_feature",
        "sim_management_bulk_change_request","optimization_group","automation_rule",
        "sim_management_inventory_action_history","customerrateplan","optimization_rate_plan_type",
        "billing_period","action_history_logs","customers"
    ] if not billing_flag else [
        "services","product_types","customer_profiles","customer_services",
        "collection_templates","bill_templates","gl_code","serviceprovider",
        "charge_back_history","customer_bills"
    ]

    # Build table mappings
    for i, table in enumerate(tables, start=1):
        rules.append({
            "rule-type": "selection",
            "rule-id": str(i),
            "rule-name": f"{table}_{tenant_db_name}",
            "rule-action": "include",
            "object-locator": {"schema-name": "public", "table-name": table},
            "filters": []
        })
    table_mappings = {"rules": rules}

    try:
        # Try to check if task exists
        resp = dms_client.describe_replication_tasks(
            Filters=[{"Name": "replication-task-id", "Values": [task_id]}]
        )
        existing_tasks = resp.get("ReplicationTasks", [])

    except dms_client.exceptions.ResourceNotFoundFault:
        # No existing task found, safe to create
        existing_tasks = []

    # If task exists, start it if in stopped/ready/failed state
    if existing_tasks:
        task = existing_tasks[0]
        task_arn = task["ReplicationTaskArn"]
        status = task["Status"].lower()
        print(f"Existing DMS task found: {task_arn} — Status: {status}")

        if status in ["stopped", "ready", "failed", "stopped-error"]:
            dms_client.start_replication_task(
                ReplicationTaskArn=task_arn,
                StartReplicationTaskType="start-replication"
            )
            return True, f"Existing task started: {task_arn}"
        return True, f"Task exists — current state: {status}"

    # Task does not exist, create a new one
    print("No existing DMS task found. Creating new task...")
    create_resp = dms_client.create_replication_task(
        ReplicationTaskIdentifier=task_id,
        SourceEndpointArn=source_arn,
        TargetEndpointArn=target_arn,
        ReplicationInstanceArn=replication_instance_arn,
        MigrationType="cdc",
        TableMappings=json.dumps(table_mappings),
        ReplicationTaskSettings=json.dumps({
            "TargetMetadata": {"TargetSchema": "", "SupportLobs": True},
            "FullLoadSettings": {"TargetTablePrepMode": "DO_NOTHING"},
            "PreMigrationAssessment": {
                "EnableAssessment": True,
                "AssessmentReportSettings": {
                    "OutputFormat": "json",
                    "S3BucketName": s3_bucket_name,
                    "S3BucketFolder": "premigrate",
                    "EncryptionMode": "NONE"
                },
                "EnabledAssessmentRuleIds": ["source-table-without-primary-key"]
            }
        })
    )

    task_arn = create_resp["ReplicationTask"]["ReplicationTaskArn"]
    print(f"Created new DMS Task: {task_arn}")

    # Wait until READY
    max_wait_seconds = 600
    poll_interval = 5
    waited = 0
    status = None
    while waited < max_wait_seconds:
        time.sleep(poll_interval)
        waited += poll_interval
        describe = dms_client.describe_replication_tasks(
            Filters=[{"Name": "replication-task-id", "Values": [task_id]}]
        )
        status = describe["ReplicationTasks"][0]["Status"].lower()
        print(f"Current status: {status} (waited {waited}s)")
        if status == "ready":
            break
        if status in ["failed", "error"]:
            raise Exception(f"DMS Task failed during creation: {status}")
    if status != "ready":
        raise Exception(f"Timed out waiting for task to become ready (last status: {status})")

    # Start CDC replication
    dms_client.start_replication_task(
        ReplicationTaskArn=task_arn,
        StartReplicationTaskType="start-replication"
    )
    print("New task started successfully.")
    return True, f"CDC replication started: {task_arn}"


def wait_for_endpoint_available(endpoint_arn, max_attempts=20, delay=5):
    try:
        for _ in range(max_attempts):
            response = dms_client.describe_endpoints(Filters=[{'Name': 'endpoint-arn', 'Values': [endpoint_arn]}])
            status = response['Endpoints'][0]['Status']
            if status == 'active':
                return True
            elif status == 'failed':
                raise Exception(f"Endpoint {endpoint_arn} failed")
            time.sleep(delay)
        return False
    except Exception as e:
        send_sns_alert(subject="DMS Endpoint Error", message=str(e))
        raise

def wait_for_connection_status(endpoint_arn, replication_instance_arn, max_attempts=20, delay=10):
    try:
        for _ in range(max_attempts):
            response = dms_client.describe_connections(
                Filters=[
                    {"Name": "endpoint-arn", "Values": [endpoint_arn]},
                    {"Name": "replication-instance-arn", "Values": [replication_instance_arn]}
                ]
            )
            if response['Connections']:
                status = response['Connections'][0]['Status']
                if status == 'successful':
                    return True
                elif status == 'failed':
                    raise Exception(f"Connection failed for endpoint {endpoint_arn}")
                elif status in ['testing', 'modifying']:
                    print(f"Connection test in progress for {endpoint_arn}")
            else:
                try:
                    test_response = dms_client.test_connection(
                        ReplicationInstanceArn=replication_instance_arn,
                        EndpointArn=endpoint_arn
                    )
                    print(f"Started connection test: {test_response['Connection']['Status']}")
                except dms_client.exceptions.InvalidResourceStateFault:
                    print(f"Connection test already in progress for {endpoint_arn}")
            time.sleep(delay)
        raise Exception(f"Connection test timed out for endpoint {endpoint_arn}")
    except Exception as e:
        send_sns_alert(subject="DMS Connection Error", message=str(e))
        raise

def wait_for_ssm_command(command_id, instance_id, timeout=300):
    try:
        elapsed = 0
        interval = 5
        while elapsed < timeout:
            try:
                response = ssm.get_command_invocation(
                    CommandId=command_id,
                    InstanceId=instance_id
                )
                status = response["Status"]
                if status.lower() in ["success", "failed", "timedout", "cancelled"]:
                    return (
                        status,
                        response.get("StandardOutputContent", ""),
                        response.get("StandardErrorContent", "")
                    )
            except ssm.exceptions.InvocationDoesNotExist:
                pass
            time.sleep(interval)
            elapsed += interval
        raise Exception(f"SSM command {command_id} timed out after {timeout}s")
    except Exception as e:
        send_sns_alert(subject="SSM Command Error", message=str(e))
        raise

def lambda_handler(event, context):
    container_status = None
    deletion_container_status = None
    command_id = None
    deletion_command_id = None
    try:
        tenant_db_name = event.get('tenant_db_name')
        container_flag = event.get('container_flag', False)
        deletion_container_flag = event.get('deletion_container_flag', False)
        billing_flag = event.get('billing_flag', False)
        billing_container_flag = event.get('billing_container_flag', False)
        if not tenant_db_name:
            return {"statusCode": 400, "body": "tenant_db_name is required"}

        if container_flag:
            INSTANCE_ID = os.environ['INSTANCE_ID']
            response = ssm.send_command(
                InstanceIds=[INSTANCE_ID],
                DocumentName="AWS-RunShellScript",
                Parameters={
                    "commands": [
                        f"bash /opt/scripts/create_scheduler.sh {tenant_db_name}"
                    ]
                }
            )
            command_id = response["Command"]["CommandId"]
            container_status, stdout, stderr = wait_for_ssm_command(command_id, INSTANCE_ID)
            if container_status != "Success":
                raise Exception(f"SSM command execution failed: {stdout} | {stderr}")

            if deletion_container_flag:
                response = ssm.send_command(
                    InstanceIds=[INSTANCE_ID],
                    DocumentName="AWS-RunShellScript",
                    Parameters={
                        "commands": [
                            f"bash /opt/scripts/create_deletion_scheduler.sh {tenant_db_name}"
                        ]
                    }
                )
                deletion_command_id = response["Command"]["CommandId"]
                deletion_container_status, stdout, stderr = wait_for_ssm_command(deletion_command_id, INSTANCE_ID)
                if deletion_container_status != "Success":
                    raise Exception(f"Deletion SSM command execution failed: {stdout} | {stderr}")
        elif billing_container_flag:
            INSTANCE_ID = os.environ['INSTANCE_ID']
            response = ssm.send_command(
                InstanceIds=[INSTANCE_ID],
                DocumentName="AWS-RunShellScript",
                Parameters={
                    "commands": [
                        f"bash /opt/scripts/create_billing_scheduler.sh {tenant_db_name}"
                    ]
                }
            )
            command_id = response["Command"]["CommandId"]
            container_status, stdout, stderr = wait_for_ssm_command(command_id, INSTANCE_ID)
            if container_status != "Success":
                raise Exception(f"Billing SSM command execution failed: {stdout} | {stderr}")

        replication_instance_arn = os.environ['DMS_REPLICATION_INSTANCE_ARN']
        bucket_name = f"dms-{tenant_db_name.lower().replace('_','-')}"
        bucket_name = sanitize_identifier(bucket_name)
        bucket_name = f"{bucket_name}-beta"
        region = os.environ.get('AWS_REGION', 'us-east-1')

        existing_buckets = [b['Name'] for b in s3_client.list_buckets()['Buckets']]
        if bucket_name not in existing_buckets:
            s3_client.create_bucket(
                Bucket=bucket_name,
                CreateBucketConfiguration={'LocationConstraint': region} if region != 'us-east-1' else {}
            )
            print(f"Created new bucket: {bucket_name}")
        else:
            print(f"Bucket {bucket_name} already exists")

        lambda_arn = os.environ['CDC_LAMBDA_ARN']
        print(add_s3_lambda_notification(bucket_name, lambda_arn))

        source_endpoint_id = sanitize_identifier(f"{tenant_db_name}-beta")
        target_endpoint_id = sanitize_identifier(f"{tenant_db_name}-s3-beta")

        try:
            source_response = dms_client.describe_endpoints(Filters=[{'Name':'endpoint-id','Values':[source_endpoint_id]}])
            source_arn = source_response['Endpoints'][0]['EndpointArn']
            print(f"Source endpoint exists: {source_arn}")
            source_ok = wait_for_connection_status(source_arn, replication_instance_arn)
        except dms_client.exceptions.ResourceNotFoundFault:
            source_endpoint = dms_client.create_endpoint(
                EndpointIdentifier=source_endpoint_id,
                EndpointType='source',
                EngineName='postgres',
                Username=os.environ['USER'],
                Password=os.environ['PASSWORD'],
                ServerName=os.environ['HOST'],
                Port=int(os.environ['PORT']),
                DatabaseName=tenant_db_name,
                ExtraConnectionAttributes='captureDdls=true;sslMode=require;'
            )
            source_arn = source_endpoint['Endpoint']['EndpointArn']
            print(f"Created new source endpoint: {source_arn}")
            source_ok = wait_for_connection_status(source_arn, replication_instance_arn) if wait_for_endpoint_available(source_arn) else False

        extra_attrs = (
            f"bucketFolder=DMS/;"
            f"bucketName={bucket_name};"
            "cdcMaxBatchInterval=5;"
            "compressionType=NONE;"
            "csvDelimiter=,;"
            "csvRowDelimiter=\\n;"
            "datePartitionEnabled=false;"
        )
        try:
            target_response = dms_client.describe_endpoints(Filters=[{'Name':'endpoint-id','Values':[target_endpoint_id]}])
            target_arn = target_response['Endpoints'][0]['EndpointArn']
            print(f"Target endpoint exists: {target_arn}")
            target_ok = wait_for_connection_status(target_arn, replication_instance_arn)
        except dms_client.exceptions.ResourceNotFoundFault:
            target_endpoint = dms_client.create_endpoint(
                EndpointIdentifier=target_endpoint_id,
                EndpointType='target',
                EngineName='s3',
                ExtraConnectionAttributes=extra_attrs,
                S3Settings={'ServiceAccessRoleArn': os.environ['DMS_S3_ROLE_ARN']}
            )
            target_arn = target_endpoint['Endpoint']['EndpointArn']
            print(f"Created new target endpoint: {target_arn}")
            target_ok = wait_for_connection_status(target_arn, replication_instance_arn) if wait_for_endpoint_available(target_arn) else False

        if source_ok and target_ok:
            print("Both endpoints are ready")
            dms_status, message = create_dms_task(source_arn, target_arn, replication_instance_arn, tenant_db_name, bucket_name, billing_flag)
        else:
            raise Exception("One or both DMS endpoints not ready")

        status_code = 200 if source_ok and target_ok and dms_status else 500
        connection_status = "successful" if source_ok and target_ok else "failed"

        return {
            "statusCode": status_code,
            "body": {
                "bucket_name": bucket_name,
                "source_endpoint": source_arn,
                "target_endpoint": target_arn,
                "dms_task": message,
                "connection_status": connection_status,
                "container_status": container_status,
                "container_command_id": command_id,
                "deletion_container_status": deletion_container_status,
                "deletion_container_command_id": deletion_command_id
            }
        }

    except Exception as e:
        error_msg = f"Lambda execution failed: {str(e)}\nTraceback:\n{traceback.format_exc()}"
        print(error_msg)
        send_sns_alert(subject=f"DMS Lambda Error: {event.get('tenant_db_name')}", message=error_msg)
        return {
            "statusCode": 500,
            "body": {"error": str(e), "traceback": traceback.format_exc()}
        }
