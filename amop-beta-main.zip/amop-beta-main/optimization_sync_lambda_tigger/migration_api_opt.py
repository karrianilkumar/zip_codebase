"""
Author : Vyshnavi.K, Bhavani.Ganta
Created Date : 09-12-2024
main fn: main_migration_func
"""

# 1. Standard Library Imports
import os
import json
import re
import time
import math
import threading
from datetime import datetime, timedelta,timezone
import copy
import uuid
import boto3
import traceback

# 2. Third-Party Imports
import pandas as pd
from pandas import Timestamp
from sqlalchemy import create_engine, exc, text
import pytds
import psycopg2
from psycopg2.extras import execute_values
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv
import requests

# 3. Local Application Imports
from common_utils.logging_utils import Logging
# from optimization_migration import optimization_sync_comm_group

logging = Logging(name="migration_api_opt")


# logging.basicConfig(filename='db_migration.log', level=logging.ERROR,
                    # format='%(asctime)s %(levelname)s:%(message)s')

onepoint_o_database=os.getenv("ONEPOINTODATABASE","AltaworxCentral")
class MigrationScheduler:



    def create_postgres_connection(self,postgres_db_name):
        logging.info(f"In create_postgres_connection {postgres_db_name}")

        load_dotenv()
        hostname = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        try:
            connection=self.create_connection(db_type,hostname,postgres_db_name,user,password,port)
            logging.info(f"in create postgres connection {connection}")
        except Exception as e:
            logging.info(f"Error while establishing connection {e}")
        return connection

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(self,db_type='',host='', db_name='',username='', password='',port='',driver='',max_retry=3):
        """
        Establishes a database connection to PostgreSQL or MSSQL based on the provided parameters.

        Retries the connection up to a specified number of times in case of failure.

        Args:
            db_type (str): Type of the database ('postgresql' or 'mssql').
            host (str): Hostname or IP address of the database server.
            db_name (str): Name of the database.
            username (str): Username for authentication.
            password (str): Password for authentication.
            port (str): Port number for the database connection.
            driver (str): Driver details (used for MSSQL if required).
            max_retry (int): Maximum number of retry attempts (default: 3).

        Returns:
            connection: A database connection object or None if the connection fails.
        """
        connection = None

        retry = 1
        logging.info(f"db_type:{db_type}, host--{host}-db_name-{db_name}, username-{username},password-{password},port-{port},driver-{driver}")
        db_type = db_type.strip()
        host = host.strip()
        db_name = db_name.strip()
        username = username.strip()
        password = password.strip()
        port = port.strip()
        driver = driver.strip()
        if db_type=='postgresql':
            try:
                logging.info(f"creating postgresql connection")

                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.warning(f"Failed to connect to PostgreSQL DB: {e}")
        elif db_type=='mssql':
            logging.info(f"Creating MSSQL connection")
            try:
                connection = pytds.connect(
                    server=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )

                logging.info("Connection to MSSQL successful!")
            except Exception as e:
                logging.warning(f"Failed to connect to MSSQL DB: {e}")
        return connection

    def execute_query(self,connection,query):
        """
        Executes a SQL query using the given database connection and returns the result as a DataFrame.

        Args:
            connection: The database connection object to execute the query.
            query (str): The SQL query to be executed.

        Returns:
            pd.DataFrame: The result of the query as a pandas DataFrame, or None if an error occurs.
        """
        try:
            result_df=pd.read_sql_query(query,connection)
            return result_df
        except Exception as e:
            logging.error(f"Error executing query: {e}")
            return None

    def get_from_clause_index(self,query):
        """
        Identifies the starting index of the "FROM" clause in a SQL query.

        This method uses a regular expression to locate the standalone "FROM" keyword
        in the provided SQL query, ignoring case sensitivity. It raises an exception
        if the "FROM" clause is not found in the query.

        Args:
            query (str): The SQL query string.

        Returns:
            int: The starting index of the "FROM" keyword in the query.

        Raises:
            ValueError: If the query does not contain a "FROM" clause.
        """
    # This regex will match the standalone "FROM" keyword
        match = re.search(r"\bFROM\b", query, re.IGNORECASE)
        # logging.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@getting the index of from",match.start() )
        if match:
            return match.start()  # Return the starting index of "FROM"
        else:
            raise ValueError("Invalid query: Missing FROM clause.")

    def get_updated_records_query(self, columns, last_id, full_from_table, query, error_id_list):
        """
        Generate a query to fetch updated records based on dynamic conditions.

        This method constructs a SQL query dynamically to fetch records that are updated
        (based on `id`, `modifieddate`, and `deleteddate`) after the provided values.
        It supports handling table aliases and building WHERE clauses intelligently.

        Args:
            columns (list): List of column names to use in the WHERE clause.
            last_id (list): List of values corresponding to the columns for filtering.
            full_from_table (str): Fully qualified table name if provided.
            query (str): The base query string to enhance with dynamic WHERE conditions.
            error_id_list (list): List of error IDs to include in the query.

        Returns:
            str: A dynamically constructed query string.
            None: If an error occurs during query generation.

        Raises:
            ValueError: If the base query is invalid (e.g., missing a FROM clause).
        """
        try:
            # Initialize the WHERE clause
            where_conditions = []
            modified_date_condition = None
            deleted_date_condition = None

            # Parse the FROM clause to extract table aliases
            from_clause_start = self.get_from_clause_index(query)
            if from_clause_start == -1:
                raise ValueError("Invalid query: Missing FROM clause.")

            # Extract the part of the query after FROM
            from_clause = query[from_clause_start + 4:].strip()

            # Split on JOIN, comma, or WHERE to isolate the FROM section
            from_clause = from_clause.split(" WHERE")[0].split(" JOIN")[0].split(",")[0].strip()
            from_clause_split = from_clause.split()

            table_aliases = {}
            for idx, word in enumerate(from_clause_split):
                if self.recognize_format(word):
                    # Check if there is an alias available
                    if idx + 1 < len(from_clause_split):
                        alias = from_clause_split[idx + 1]
                        table_aliases[alias] = word

            # Check if ModifiedDate, DeletedDate, or ID exists in the query to determine alias
            date_column_alias = None
            for alias in table_aliases:
                alias_modifieddate = f"{alias}.modifieddate"
                alias_deleteddate = f"{alias}.deleteddate"
                alias_id = f"{alias}.id"

                # Check if any of these columns with alias exist in the query
                if (alias_modifieddate in query.lower() or
                    alias_deleteddate in query.lower() or
                    alias_id in query.lower()):
                    date_column_alias = alias
                    break

            # Constructing the WHERE clause dynamically
            for col, val in zip(columns, last_id):
                col_lower = col.lower()

                if col_lower == 'id' and date_column_alias:
                    col_with_alias = f"{date_column_alias}.{col}"
                    if isinstance(val, str):
                        where_conditions.append(f"{col_with_alias} > '{val}'")
                    else:
                        where_conditions.append(f"{col_with_alias} > {val}")

                elif col_lower == "modifieddate":
                    if date_column_alias:
                        col_with_alias = f"{date_column_alias}.{col}"
                        if isinstance(val, str):
                            modified_date_condition = f"{col_with_alias} > '{val}'"
                        else:
                            modified_date_condition = f"{col_with_alias} > {val}"
                    elif col_lower in query.lower():
                        # Handle case where no alias but column exists in query
                        if isinstance(val, str):
                            modified_date_condition = f"{col} > '{val}'"
                        else:
                            modified_date_condition = f"{col} > {val}"

                elif col_lower == "deleteddate":
                    if date_column_alias:
                        col_with_alias = f"{date_column_alias}.{col}"
                        if isinstance(val, str):
                            deleted_date_condition = f"{col_with_alias} > '{val}'"
                        else:
                            deleted_date_condition = f"{col_with_alias} > {val}"
                    elif col_lower in query.lower():
                        # Handle case where no alias but column exists in query
                        if isinstance(val, str):
                            deleted_date_condition = f"{col} > '{val}'"
                        else:
                            deleted_date_condition = f"{col} > {val}"

                else:
                    # Handle other columns
                    if isinstance(val, str):
                        where_conditions.append(f"{col} > '{val}'")
                    else:
                        where_conditions.append(f"{col} > {val}")

            # Handle error_id_list
            if error_id_list:
                if date_column_alias:
                    col_with_alias = f"{date_column_alias}.id"
                    error_id_list_str = ', '.join([str(i) for i in error_id_list])
                    error_id_condition = f"{col_with_alias} IN ({error_id_list_str})"
                    where_conditions.append(error_id_condition)
                else:
                    error_id_list_str = ', '.join([str(i) for i in error_id_list])
                    error_id_condition = f"id IN ({error_id_list_str})"
                    where_conditions.append(error_id_condition)

            # Combine the conditions
            where_clause = ""
            if where_conditions:
                where_clause = " WHERE " + " OR ".join(where_conditions)

            # Add modified date condition
            if modified_date_condition:
                if where_clause:
                    where_clause += f" OR {modified_date_condition}"
                else:
                    where_clause = f" WHERE {modified_date_condition}"

            # Add deleted date condition
            if deleted_date_condition:
                if where_clause:
                    where_clause += f" OR {deleted_date_condition}"
                else:
                    where_clause = f" WHERE {deleted_date_condition}"

            # Construct the final query
            if full_from_table:
                migrate_records = f"SELECT * FROM {full_from_table}{where_clause} ORDER BY id ASC"
            elif query:
                if "ORDER BY" in query.upper():
                    parts = query.rsplit("ORDER BY", 1)
                    # Add the WHERE clause before the last "ORDER BY"
                    query = parts[0] + where_clause + " ORDER BY" + parts[1]
                else:
                    query += where_clause
                migrate_records = query

        except Exception as e:
            logging.info(f"Error in generating query to select records: {e}")
            migrate_records = None

        return migrate_records
    """
    #Commenting below bloc because this is for user interaction not used in lambda
    def main(self):
        load_dotenv()  # Load environment variables from .env file
        migration_details_dict={}

        logging.info("Beginning migration")

        hostname = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        db_name = 'Migration_Test'
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        migration_table=os.getenv('MIGRATION_TABLE')

        postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
        query = f"SELECT migration_name FROM {migration_table}"
        rows = self.execute_query(postgres_conn, query)


        if rows.empty:
            logging.info("No existing jobs found. Creating a new job.")
            new_job = self.create_new_migration(postgres_conn, migration_table)

        else:
            user_choice = input("Do you want to create a new migration job or select an existing one? (new/existing): ").strip().lower()

            if user_choice == 'new':
                logging.info("Creating a new migration job.")
                new_job = self.create_new_migration(postgres_conn, migration_table)
            elif user_choice == 'existing':
                logging.info("Existing jobs:")
                # logging.info(rows)
                for index, row in rows.iterrows():
                    logging.info(f"{index + 1}. {row['migration_name']}")

                choice = input("Enter 'single' to execute a single job immediately or 'scheduled' to schedule jobs: ").strip().lower()

                if choice == 'single':
                    job_name = input("Enter the job name you want to execute: ").strip()
                    self.main_migration_func(job_name, postgres_conn)
                elif choice == 'scheduled':
                    job_names = input("Enter the job names you want to select (comma-separated for multiple jobs): ").strip().split(',')
                    job_names = [job.strip() for job in job_names]

                    start_times = {}
                    for job_name in job_names:
                        start_time_str = input(f"Enter the start time for the migration '{job_name}' (in HH:MM:SS format): ")
                        start_time = datetime.strptime(start_time_str, "%H:%M:%S").time()
                        start_times[job_name] = start_time

                    days_to_run = int(input("Enter the number of days to run the job (including today): "))

                    now = datetime.now()
                    for job_name, start_time in start_times.items():
                        for day in range(days_to_run):
                            start_datetime = datetime.combine(now + timedelta(days=day), start_time)
                            delay_seconds = (start_datetime - now).total_seconds()
                            start_time_12hr = start_datetime.strftime("%I:%M:%S %p")
                            logging.info(f"Scheduled to start '{job_name}' at: {start_time_12hr} on {start_datetime.date()}")
                            threading.Timer(delay_seconds, self.main_migration_func, [job_name, postgres_conn]).start()

            else:
                logging.info("Invalid choice. Please enter 'new' or 'existing'.")
                self.main()"""


    def get_migration_details(self, job_name, conn,migrations_table):
        """
        Fetch migration details for a specific job from the migrations table.

        This method queries the database to retrieve migration details for a given job name.
        It executes the query, fetches the result as a pandas DataFrame, and converts it
        to a dictionary format.

        Args:
            job_name (str): The name of the migration job to fetch details for.
            conn (object): The database connection object to execute the query.
            migrations_table (str): The name of the migrations table in the database.

        Returns:
            dict: A dictionary containing the details of the migration job.
                If no details are found or an error occurs, an empty dictionary is returned.
        """
        try:
            query = f"SELECT * FROM {migrations_table} WHERE migration_name = '{job_name}'"
            query_result = self.execute_query(conn, query)
            return query_result.to_dict(orient='records')[0]
        except Exception as e:
            logging.error(f"Error while fetching the {job_name} details - {e}")
            return {}

    def get_db_config(self, migration_details_dict):
        """
        Extract and process database configuration from migration details.

        This method retrieves the database configuration from the given migration details dictionary.
        If the configuration is a JSON string, it converts it into a Python dictionary.
        If the configuration is not present or invalid, it falls back to a default configuration.

        Args:
            migration_details_dict (dict): A dictionary containing migration details,
                                        including the database configuration under 'from_db_config'.

        Returns:
            dict: A dictionary containing database configuration details, either from the input
        """
        db_config = migration_details_dict.get('from_db_config')
        if db_config and not isinstance(db_config, dict):
            db_config = json.loads(db_config)
        return db_config or {
            'hostname': os.getenv('MSSQL_DB_HOST'),
            'port': os.getenv('MSSQL_DB_PORT'),
            'user': os.getenv('MSSQL_DB_USER'),
            'password': os.getenv('MSSQL_DB_PASSWORD'),
            'from_db_type': os.getenv('MSSQL_DB_TYPE')
        }


    def update_migration_details_dict(self,insert_records,success,failures,last_id_time,error_msg):
        try:
            migration_details_updated_dict={}
            migration_details_updated_dict['status']=insert_records
            # migration_details_updated_dict['last_id']=last_id_time
            migration_update_list=[]
            migration_update_dict={'Success_Records':success,'failed_records':failures}
            #migration_update_list=[migration_update]
            migration_details_updated_dict['last_id']=str(last_id_time)
            migration_update_list.append(migration_update_dict)
            migration_details_updated_dict['migration_update']=json.dumps(migration_update_list)
            migrated_time=datetime.now()
            # logging.info(f"Current_time is {migrated_time}")
            migration_details_updated_dict['last_migrated_time']=migrated_time
            migration_details_updated_dict['error_message']=error_msg
            logging.info(f"migration_details_updated_dict is {migration_details_updated_dict}")

        except Exception as e:
            logging.error(f"Error while updating migration details dict : {e}")
        return migration_details_updated_dict

    #removing this because its doing some unnecessary updates
    def update_migration_details_dict_(
            self,
            migration_details_dict,
            insert_records,
            success,
            failures,
            last_id_time,
            db_config):
        """
        Update the migration details dictionary with the latest migration status.

        This method updates various fields in the migration details dictionary,
        including status, last migrated ID/time, database configurations,
        and mappings, while handling success and failure records.

        Args:
            migration_details_dict (dict): The dictionary containing migration details to be updated.
            insert_records (int): The number of records inserted in the migration.
            success (int): The count of successfully migrated records.
            failures (int): The count of failed migrations.
            last_id_time (str/datetime): The last ID or timestamp of the migrated record.
            db_config (dict): The database configuration dictionary.

        Returns:
            dict: The updated migration details dictionary.
        """
        try:
            # Update the current migration status and the last migrated ID/time
            migration_details_dict['status']=insert_records
            migration_details_dict['last_id']=last_id_time

            # Update migration update list with success and failure records
            migration_update_list=migration_details_dict['migration_update'] or []
            if isinstance(migration_update_list, str):
                migration_update_list = json.loads(migration_update_list)  # If it's a string, convert it back to a list
            if not isinstance(migration_update_list, list):
                migration_update_list = []
            logging.info(f"Migration Status {migration_update_list}")
            migration_update_dict={'Success_Records':success,'failed_records':failures}
            #migration_update_list=[migration_update]

            migration_update_list.append(migration_update_dict)
            migration_details_dict['migration_update']=json.dumps(migration_update_list)

            migration_details_dict['from_db_config']=json.dumps(db_config)
            to_mapping=migration_details_dict['table_mappings']
            migration_details_dict['table_mappings']=json.dumps(to_mapping)

            reverse_sync_mapping=migration_details_dict['reverse_sync_mapping']
            migration_details_dict['reverse_sync_mapping']=json.dumps(reverse_sync_mapping)

            migrated_time=datetime.now()
            # logging.info(f"Current_time is {migrated_time}")
            migration_details_dict['last_migrated_time']=migrated_time
        except Exception as e:
            logging.error(f"Error while updating migration details dict : {e}")
        return migration_details_dict

    def select_updated_records(self,columns_list, last_id_list, full_from_table):
        """
        Construct and return a SQL query to select updated records based on dynamic column values.

        This method generates a WHERE clause dynamically using the provided list of columns
        and corresponding last IDs or values. The final SQL query is constructed to select records
        that have values greater than the provided last IDs.

        Args:
            columns_list (list): List of column names used for comparison in the WHERE clause.
            last_id_list (list): List of last ID values to compare against for each column in columns_list.
            full_from_table (str): The name of the table from which records are selected.

        Returns:
            str: The constructed SQL query as a string.
        """
        # Constructing the WHERE clause dynamically
        where_conditions = []
        for col, val in zip(columns_list, last_id_list):
            if isinstance(val, str):
                where_conditions.append(f"{col} > '{val}'")
            else:
                where_conditions.append(f"{col} > {val}")

        where_clause = " AND ".join(where_conditions)

        # Constructing the SQL query
        migrate_records = f"SELECT * FROM {full_from_table} WHERE {where_clause}"

        return migrate_records

    def main_migration_func(self,job_name,key_name=None):
        """
        The main migration function that handles the process of migrating data from one database to another.
        This includes both table-to-table migration and query-based migration, with support for reverse synchronization.

        Args:
            job_name (str): The name of the migration job to be executed.

        Returns:
            bool: Returns True if the migration job completes successfully, otherwise returns False.
        """
        try:
            logging.info("starting the job",{job_name})
            load_dotenv()
            hostname = os.getenv('PSQL_DB_HOST')
            port = os.getenv('PSQL_DB_PORT')
            user = os.getenv('PSQL_DB_USER')
            password = os.getenv('PSQL_DB_PASSWORD')
            db_type = os.getenv('PSQL_DB_TYPE')
            db_name=os.getenv('PSQL_DB_NAME')
            logging.info("postgress sql db configuration loaded successfully")
            # logging.info(hostname,port)

            # Create the PostgreSQL connection to the source database
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info("Connection to PostgreSQL DB successful")
            #Before starting the job insert a record in history table
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            hist_insert_data={'key_name':key_name,'job_name':job_name,'job_start_time':datetime.now(timezone.utc).replace(tzinfo=None),
                              'request_triggered_by':'optimization_sync_lambda'}

            trace_id=self.insert_dict(postgres_conn,history_table,hist_insert_data,True,'trace_id')
            logging.info(f"Trace Id after insertion is {trace_id}")


            logging.info(f"{trace_id} Executing job: {job_name}")
            load_dotenv()
            migration_table=os.getenv('MIGRATION_TABLE')
            # migration_table='migrations_2'
            logging.info(f"migrations table {migration_table}")
            migration_details_dict=self.get_migration_details(job_name,postgres_conn,migration_table)

            table_flag=migration_details_dict['table_flag']
            logging.info(f"{trace_id} Table Flag is {table_flag}")


            to_hostname = os.getenv('PSQL_DB_HOST')
            to_port = os.getenv('PSQL_DB_PORT')
            to_db_name =migration_details_dict['to_database']
            to_user = os.getenv('PSQL_DB_USER')
            to_password = os.getenv('PSQL_DB_PASSWORD')
            to_db_type = os.getenv('PSQL_DB_TYPE')
            to_table=migration_details_dict['to_table']
            to_connection=self.create_connection(to_db_type,to_hostname,to_db_name,to_user,to_password,to_port)


            migration_status=migration_details_dict['status']
            reverse_sync_flag = migration_details_dict["reverse_sync"]
            reverse_sync_mappings = migration_details_dict["reverse_sync_mapping"]

            # Handle reverse sync if the flag is set
            if reverse_sync_flag:
                logging.info(
                    f"####################{trace_id} Reverse sync for {job_name} starting"
                )
                reverse_sync_flag,error_msg,rev_error_id_list = self.reverse_sync_migration(
                    job_name,
                    to_connection,
                    reverse_sync_mappings,
                    migration_details_dict,
                    trace_id,
                    postgres_conn
                )
                if reverse_sync_flag is False:
                    logging.error(
                        f"#################### Reverse sync for {job_name} failed"
                    )
                    tb = traceback.format_exc()
                    error_message_tb=f'{error_msg} {tb}'
                    update_hist={'error_msg':error_message_tb,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'rev_sync_error_id':json.dumps(reverse_sync_mappings),'rev_sync_error_id':json.dumps(rev_error_id_list)}
                    self.update_table(postgres_conn,history_table,update_hist,{'trace_id':trace_id})
                    return False

            if table_flag:
                logging.info(f"{trace_id} Table to Table migration for {job_name}")
                if migration_status=='first':
                    first_table_migrate=self.first_migration(table_flag,to_connection,
                                                         postgres_conn,migration_details_dict,migration_table,job_name,trace_id)
                else:
                    logging.info(f"###############{trace_id} LAST ID migration for {job_name}")
                    last_id_migration=self.last_id_migration(table_flag,to_connection,
                                                         postgres_conn,migration_details_dict,migration_table,job_name,trace_id)

            else:
                logging.info(f"{trace_id} Executing {job_name}")

                if migration_status=='first':
                    try:
                        logging.info(f"{trace_id} FIRST MIGRATION -- {job_name}")
                        first_migration=self.first_migration(table_flag,to_connection,
                                                     postgres_conn,migration_details_dict,migration_table,job_name,trace_id)
                    except Exception as e:
                        tb = traceback.format_exc()
                        msg=f"Error in first migration {job_name} {e} {tb}"
                        update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                        self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                        logging.error(f"Error in main_migration_func:first_migration {job_name} -{e}")

                else:
                    logging.info(f"{trace_id} LAST ID MIGRATION -- {job_name}")
                    try:
                        last_id_migration=self.last_id_migration(table_flag,to_connection, postgres_conn,migration_details_dict,migration_table,job_name,trace_id)
                    except Exception as e:
                        tb = traceback.format_exc()
                        msg=f"Error in main-last migration {job_name} {e} {tb}"
                        update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                        self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                        logging.error(f"Error in main_migration_fun:last_id_migration {job_name} -{e}")

            return_flag = True
        except Exception as e:
            # If any error occurs, log the error and set return_flag to False
            return_flag = False
            tb = traceback.format_exc()
            msg=f"Error in {job_name} {e} {tb}"
            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
            logging.error(f"Error in main_migration_fun {job_name} -{e} {tb}")
        return return_flag

    def first_migration(
            self,
            table_flag,
            to_connection,
            postgres_conn,
            migration_details_dict,
            migration_table,
            job_name,
            trace_id
    ):
        """
        Perform the first migration process for moving data from
        a source (SQL Server or query) to a target database (PostgreSQL).

        Args:
            table_flag (bool): Flag to determine if the migration is based on a table or a query.
            to_connection: The connection object to the target database (PostgreSQL).
            postgres_conn: The connection to the PostgreSQL database.
            migration_details_dict (dict): Contains all the necessary details for
            migration like source database, table, queries, etc.
            migration_table (str): The target migration table name.
            job_name (str): The name of the job to log migration status.

        Returns:
            None
        """
        try:
            if table_flag:
                from_database=migration_details_dict['from_database']
                from_table=migration_details_dict['from_table']

                if not self.is_valid_table_name(from_table):
                    full_from_table=f'[{from_database}].[dbo].[{from_table}]'
                    # logging.info(f"full table name {full_from_table}")
                else:
                    full_from_table=from_table
                logging.info(f"{trace_id} table to table migration")
                from_query=f"select * from {full_from_table} order by {primary_id_col}"
            else:
                logging.info(f"!!!!!!!!!!!!! query based migration")
                from_query=migration_details_dict['from_query']
                to_query=migration_details_dict['to_query']

            logging.info(f"{trace_id} common process for both")
            #establishing from conn
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            db_config=self.get_db_config(migration_details_dict)
            from_host=db_config['hostname']
            from_port=db_config['port']
            from_user=db_config['user']
            from_pwd=db_config['password']
            from_db_type=db_config['from_db_type']
            from_database=migration_details_dict['from_database']
            from_driver=os.getenv('MSSQL_DB_DRIVER')
            from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
            logging.info(f"{trace_id} Connection ssms: {from_connection}")
            primary_id_col=migration_details_dict['primary_id_column']
            logging.info(f"primary id column is {primary_id_col}")
            df_size=os.getenv('DF_SIZE')
            df_size=int(df_size)
            # db_config=self.get_db_config(migration_details_dict)
            to_table=migration_details_dict['to_table']
            success_count=0
            max_retries=3
            from_query=' '.join(from_query.split())
            from_query=from_query.rstrip(';')
            logging.info(f"{trace_id} {job_name}  from query before {from_query}")
            count_query=self.get_count_query(from_query)

            count_query=' '.join(count_query.split())
            logging.info(f"{trace_id} {job_name}COUNT QUERY  {count_query}")
            try:
                batch_queries,total_count=self.generate_batch_queries(count_query,from_query,from_connection,df_size,primary_id_col)

                if batch_queries is False and total_count is False:
                    logging.error(f"{trace_id} Error in generating batch queries")
                    error_msg="Error in generating batch queries"
                    update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                    self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                    return False
            except Exception as e:
                logging.error(f"{trace_id} Error in generating batch queries {e}")
                tb = traceback.format_exc()
                update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return False

            if total_count==0:
                logging.info(f"{trace_id} No records found for migration")
                msg=f"No records found for migration"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'total_count':total_count,'success':0,'failed':0,'job_status_msg':'SUCCESS'}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return True
            else:
                logging.info(f"Total count is {total_count}")
                update_dict={'total_count':total_count}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})


            if batch_queries:
                for query in batch_queries:
                    logging.info(f"executing query {query}")
                    attempt=0
                    df=None
                    try:
                        while attempt < max_retries:
                            if not self.check_connection(from_connection):
                                logging.warning(f"{trace_id} Connection lost. Attempting to reconnect...")
                                from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
                                if from_connection is None:
                                    logging.error("Failed to re-establish connection.")
                                    break
                            df=self.execute_query(from_connection,query)

                            if df is not None:
                                df = df.astype(object).mask(df.isna(), None)
                                logging.info(f"{job_name} Dataframe got is \n {df.head()}")
                                logging.info(f"{job_name} ################# The number of rows in the DataFrame is: {df.shape[0]}")
                                df=self.modify_uuid_cols(df)
                                break  # Exit the retry loop if successful
                            else:
                                logging.error(f"{trace_id} Error in executing query, retrying...")
                                attempt += 1
                                time.sleep(5)
                    except Exception as e:
                        logging.error(f"{trace_id} An error occurred: {str(e)}")
                        attempt += 1
                        time.sleep(5)


                    success_count=self.initate_complete_migration(df,to_connection,postgres_conn,migration_table,job_name,migration_details_dict,to_table,db_config,trace_id,total_count,success_count)
            else:
                logging.info(f"No batch queries check count")
                msg=f"No batch Queries formed, check count"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return True
        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"Error in first migration {e} {tb}")
            error_msg=f"Error in first migration {e} {tb}"
            self.update_table(postgres_conn,history_table,{'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)},{'trace_id':trace_id})
            return False

    def last_id_migration(
            self,
            table_flag,
            to_connection,
            postgres_conn,
            migration_details_dict,
            migration_table,
            job_name,
            trace_id
    ):
        """
        Migrates data from one database table to another using a batch processing approach.
        It performs migrations based on the last migrated record (identified by the `last_id`) and applies
        various checks such as connection validation, query execution, and retries in case of failure.

        Args:
            table_flag (bool): A flag indicating whether to perform table-to-table migration (True) or use custom queries (False).
            to_connection (object): The database connection object for the destination database.
            postgres_conn (object): The connection object for PostgreSQL (used if needed for custom queries).
            migration_details_dict (dict): A dictionary containing migration details such as the source and target tables, time columns, and last migrated ID.
            migration_table (str): The name of the migration table in the destination database.
            job_name (str): The name of the migration job.

        Returns:
            None: This function does not return any values. It performs data migration and logs the progress. If an error occurs, it is logged.

        Raises:
            ValueError: If no records are available for migration (i.e., batch queries return no results).
            Exception: If there is a failure during the migration process (e.g., database connection issues or query execution errors).
        """
        try:
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            to_db_name =migration_details_dict['to_database']
            to_table=migration_details_dict['to_table']
            time_column_check=migration_details_dict['time_column_check']
            time_columns = [col.strip() for col in time_column_check.split(',')]
            df_size=os.getenv('DF_SIZE')
            df_size=int(df_size)
            logging.info(f"{trace_id} {job_name} time column check got is {time_columns}")
            primary_id_col=migration_details_dict['primary_id_column']

            last_id=migration_details_dict['last_id']
            success_count=0
            # if last_id:

            #     try:
            #         if isinstance(last_id,str) or isinstance(last_id,int):
            #             if last_id == '[null]' or last_id == 'null' or last_id=='[]':
            #                 # logging.info(f"in if where last id is [null]")
            #                 last_id=self.update_last_id_list(to_db_name,to_table,time_columns,primary_id_col)

            #             else:
            #                 if last_id.startswith('{') and last_id.endswith('}'):
            #                     # Remove the curly braces
            #                     last_id = [int(last_id[1:-1])]
            #                 else:
            #                     # last_id=f'[{last_id}]'
            #                     last_id=json.loads(last_id)
            #                     logging.info(f"json loads last_id {last_id}")

            #     except Exception as e:
            #         logging.exception(f"{trace_id} {job_name} Erro loading last_id list {e}")
            #         last_id=self.update_last_id_list(to_db_name,to_table,time_columns,primary_id_col)
            #         # last_id=self.load_last_id(last_id)
            #     logging.info(f"{job_name} last_id after load_last_id is {last_id}")

            # if not last_id:
            #     last_id=self.update_last_id_list(to_db_name,to_table,time_columns,primary_id_col)


            if last_id:
                print(f"{job_name} initial last_id value: {last_id} (type: {type(last_id)})")
 
                try:
                    if isinstance(last_id, (str, int)):
                        print(f"{job_name} last_id is str/int, processing...")
 
                        if last_id in ('[null]', 'null', '[]','None'):
                            print(f"{job_name} last_id is null-like value ({last_id}), fetching from DB")
                            last_id = self.update_last_id_list(
                                to_table, primary_id_col, to_connection
                            )
 
                        else:
                            if isinstance(last_id, str) and last_id.startswith('{') and last_id.endswith('}'):
                                print(f"{job_name} last_id is in {{}} format, converting to list")
                                last_id = [int(last_id[1:-1])]
 
                            else:
                                print(f"{job_name} attempting json.loads on last_id")
                                last_id = json.loads(last_id)
                                print(f"{job_name} last_id after json.loads: {last_id}")
 
                except Exception as e:
                    print(
                        f"{trace_id} | {job_name} | "
                        f"Error while loading/parsing last_id ({last_id}): {e}"
                    )
                    print(f"{job_name} falling back to update_last_id_list from DB")
                    last_id = self.update_last_id_list(
                        to_table, primary_id_col, to_connection
                    )
 
                print(f"{job_name} final last_id after processing: {last_id}")
 
            else:
                print(f"{job_name} last_id is empty or None, fetching from DB")
                last_id = self.update_last_id_list(
                    to_table, primary_id_col, to_connection
                )
 
            print(f"{job_name} last_id used for sync: {last_id}")

                 

            ###need to get error ids from previous job
            error_ids_query=f"select error_id_list,job_end_time from {history_table} where job_name='{job_name}' and trace_id<>'{trace_id}' order by job_end_time desc limit 1"
            error_ids_df=self.execute_query(postgres_conn,error_ids_query)
            # logging.info(f"DF is {error_ids_df}")
            if not error_ids_df.empty:
                error_id_list = error_ids_df['error_id_list'][0]
                last_migrated_time_prev=error_ids_df['job_end_time'][0]
            else:
            # Handle the empty DataFrame case (e.g., return or log an error)
                logging.info(f"{trace_id} DataFrame 'error_ids_df' is empty.")
                error_id_list=[]
                last_migrated_time_prev=[]

            last_migrated_time_query=f"select job_end_time from {history_table} where job_name='{job_name}' and trace_id<>'{trace_id}' and job_status_msg='SUCCESS' order by id desc limit 1"
            last_migrated_df=self.execute_query(postgres_conn,last_migrated_time_query)
            if not last_migrated_df.empty:
                    last_migrated_time_job=last_migrated_df['job_end_time'][0]
            else:
                last_migrated_time_job=None
                logging.info(f"{trace_id} DataFrame 'job_end_df' is empty.")
                    # last_migrated_time_job=last_migrated_df['job_start_time'][0]
                # logging.info(f"Last migrated time is {last_migrated_time_job}")

            logging.info(f"{trace_id} Error id list {error_id_list}, type is {type(error_id_list)}")
            logging.info(f"{trace_id} Last migrated time is {last_migrated_time_job}")


            if table_flag:
                logging.info(f"{trace_id} Table to Table migration")
                from_table=migration_details_dict['from_table']
                from_database=migration_details_dict['from_database']
                if not self.is_valid_table_name(from_table):
                    full_from_table=f'[{from_database}].[dbo].[{from_table}]'
                    # logging.info(f"full table name {full_from_table}")
                else:
                    full_from_table=from_table
                logging.info(f"{trace_id} The last id migrated is {last_id} from column {time_column_check},{full_from_table}")
                from_query=self.get_updated_records_query(time_columns,last_id,full_from_table,None,error_id_list)

            else:
                if last_migrated_time_job:
                    last_migrated_time=last_migrated_time_job
                else:
                    last_migrated_time=migration_details_dict['last_migrated_time']

                logging.info(f"{trace_id} {job_name} The last id migrated is {last_id} from column {time_column_check}")
                logging.info(f"{job_name} calling from_query")
                from_query_=migration_details_dict['from_query']
                logging.info(f"from_query from db is {from_query_}")
                to_query=migration_details_dict['to_query']

                if "modified_date" in from_query_.lower() and "created_date" in from_query_.lower() and isinstance(last_id[0], str) :
                    logging.info("This condition handles syncing tables that have a UUID-type ID column.")
                    logging.info(f"{type(last_id[0])} {last_id}")
                    logging.info(f"{trace_id} last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} last migrated time after fn is {last_migrated_time_str} and type{type(last_migrated_time_str)}")
                    time_columns_dup=['DATEADD(MINUTE, -DATEDIFF(MINUTE, GETUTCDATE(), GETDATE()), CreatedDate)']
                    time_columns_dup.append('ModifiedDate')
                    last_id_dup=[last_migrated_time_str]
                    last_id_dup.append(last_migrated_time_str)
                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    #logging.info(time_columns_dup,"############################## time_columns_dup",last_id_dup) #it contains last id, last_migrated_time
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")


                elif (('deleteddate' in from_query_.lower() or 'deleted_date' in from_query_.lower())
                    and ('modifieddate' in from_query_.lower() or 'modified_date' in from_query_.lower())):

                    # last_migrated_time=migration_details_dict['last_migrated_time']
                    logging.info(f"Both deleteddate and modifieddate are present in the query")
                    logging.info(f"{trace_id} deleteddate,modifieddate last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} deleteddate,modifieddate last migrated time after fn is {last_migrated_time_str} and type {type(last_migrated_time_str)}")
                    time_columns_dup=copy.deepcopy(time_columns)
                    # time_columns_dup.append('ModifiedDate','DeletedDate')
                    last_id_dup=copy.deepcopy(last_id)
                    # last_id_dup.append(last_migrated_time_str,last_migrated_time_str)
                    time_columns_dup.extend(['ModifiedDate', 'DeletedDate'])
                    last_id_dup.extend([last_migrated_time_str, last_migrated_time_str])

                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")

                elif 'modifieddate' in from_query_.lower() or 'modified_date' in from_query_.lower():
                    # last_migrated_time=migration_details_dict['last_migrated_time']
                    logging.info(f"{trace_id} last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} last migrated time after fn is {last_migrated_time_str} and type{type(last_migrated_time_str)}")
                    time_columns_dup=copy.deepcopy(time_columns)
                    time_columns_dup.append('ModifiedDate')
                    last_id_dup=copy.deepcopy(last_id)
                    last_id_dup.append(last_migrated_time_str)

                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    #logging.info(time_columns_dup,"time_columns_dup",last_id_dup) it contains last id, last_migrated_time
                    #return None
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")

                #handling date_of_change for device_status_history table
                elif 'dateofchange' in from_query_.lower() or 'date_of_change' in from_query_.lower():
                    # last_migrated_time=migration_details_dict['last_migrated_time']
                    logging.info(f"{trace_id} dateofchange last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} dateofchange last migrated time after fn is {last_migrated_time_str} and type{type(last_migrated_time_str)}")
                    time_columns_dup=copy.deepcopy(time_columns)
                    time_columns_dup.append('DateOfChange')
                    last_id_dup=copy.deepcopy(last_id)
                    last_id_dup.append(last_migrated_time_str)

                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    #logging.info(time_columns_dup,"time_columns_dup",last_id_dup) it contains last id, last_migrated_time
                    #return None
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")
                #also need to handle when only deleted date is present
                elif 'deleteddate' in from_query_.lower() or 'deleted_date' in from_query_.lower():
                    logging.info(f"only deleteddate is present in the query")
                    logging.info(f"{trace_id} deleteddate last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} deleteddate,last migrated time after fn is {last_migrated_time_str} and type {type(last_migrated_time_str)}")
                    time_columns_dup=copy.deepcopy(time_columns)
                    time_columns_dup.append('DeletedDate')
                    last_id_dup=copy.deepcopy(last_id)
                    last_id_dup.append(last_migrated_time_str)

                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")

                else:
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    from_query=self.get_updated_records_query(time_columns,last_id,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} From query git is  {from_query}")

            logging.info(f"common process for both")
            #establishing from conn
            db_config=self.get_db_config(migration_details_dict)
            from_host=db_config['hostname']
            from_port=db_config['port']
            from_user=db_config['user']
            from_pwd=db_config['password']
            from_db_type=db_config['from_db_type']
            from_driver=os.getenv('MSSQL_DB_DRIVER')
            from_database=migration_details_dict['from_database']
            from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
            logging.info(f"{trace_id} Connection ssms: {from_connection}")

            from_query=' '.join(from_query.split())
            from_query=from_query.rstrip(';')
            logging.info(f"{trace_id} going to count query is {from_query}")
            count_query=self.get_count_query(from_query)

            try:
                batch_queries,total_count=self.generate_batch_queries(count_query,from_query,from_connection,df_size,time_column_check)

                if batch_queries is False and total_count is False:
                    logging.error(f"{trace_id} Error in generating batch queries")
                    error_msg="Error in generating batch queries"
                    update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                    self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                    return False

            except Exception as e:
                logging.error(f"{trace_id} Error in generating batch queries {e}")
                tb = traceback.format_exc()
                update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return False

            if total_count==0:
                logging.info(f"{trace_id} No records found for migration")
                msg=f"No records found for migration"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'total_count':total_count,'success':0,'failed':0,'job_status_msg':'SUCCESS'}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return True
            else:
                logging.info(f"Total count is {total_count}")
                update_dict={'total_count':total_count}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})


            max_retries=3
            if batch_queries:
                for query in batch_queries:
                    logging.info(f"{trace_id} {job_name} executing query {query}")
                    attempt=0
                    df=None
                    try:
                        while attempt < max_retries:
                            if not self.check_connection(from_connection):
                                logging.warning("Connection lost. Attempting to reconnect...")
                                from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
                                if from_connection is None:
                                    logging.error("Failed to re-establish connection.")
                                    break
                            df=self.execute_query(from_connection,query)

                            if df is not None:
                                df = df.astype(object).mask(df.isna(), None)
                                # logging.info(f"{trace_id} {job_name} Dataframe got is \n {df.head()}")
                                logging.info(f"{trace_id} {job_name}The number of rows in the DataFrame is: {df.shape[0]}")
                                df=self.modify_uuid_cols(df)
                                break  # Exit the retry loop if successful
                            else:
                                logging.error(f"{trace_id} {job_name} Error in executing query, retrying...")
                                attempt += 1
                                time.sleep(5)
                    except Exception as e:
                        logging.error(f"{trace_id} {job_name} An error occurred: {str(e)}")
                        attempt += 1
                        time.sleep(5)

                    if df is None:
                        logging.info(f"{trace_id} Error in executing query, check the query once")
                    else:
                        # df=self.execute_query(from_connection,from_query)
                        # df = df.astype(object).mask(df.isna(), None)
                        # logging.info(f"{job_name} DataFrame is \n {df.head()}")
                        logging.info(f"{trace_id} {job_name} ############# The number of rows in the DataFrame is: {df.shape[0]}")
                        # logging.info(f'{job_name} the last 5 rows:{df.tail(1)}')



                        success_count=self.initate_complete_migration(df,to_connection,postgres_conn,migration_table,job_name,migration_details_dict,to_table,db_config,trace_id,total_count,success_count)
            else:
                logging.info(f"{trace_id} No batch Queries formed, check count")
                msg=f"No batch Queries formed, check count"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return True
        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"{trace_id} Error in last_id_migration {e} {tb}")
            error_msg=f"Error in last_id_migration {e} {tb}"
            update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
            return False
    def execute_update_queries(self,queries,to_database,set_session):
        # logging.info(queries)
        # logging.info(to_database)
        db_name=to_database
        hostname = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

        try:
            cursor = postgres_conn.cursor()
            if set_session:
                logging.info(f"setting the session varible to true")
                cursor.execute("SELECT set_config('myvars.update_in_progress', 'true', true)")
                errors = []
            for query_dict in queries:
                # Loop through each query key-value pair in the dictionary
                for query_name, query_text in query_dict.items():
                    logging.info(f"Executing {query_name}: {query_text}")
                    start_time = time.time()
                    try:
                    # Execute the SQL query
                        cursor.execute(query_text)
                        end_time = time.time()

                        # Calculate the duration (in seconds)
                        duration = end_time - start_time
                        logging.info(f"Executed {query_name} successfully in {duration:.2f} seconds.")

                        # Optionally, commit the transaction if needed
                        #postgres_conn.commit()

                    except Exception as e:
                    # If there is an error, logging.info the error message and continue

                        logging.info(f"Error executing {query_name}: {e}")
                        errors.append({
                        "error_query": query_name,
                        "trigger_name":"error updating inventory data from 1.0",
                        "error_msg": str(e),
                        "error_timestamp":datetime.now(timezone.utc).replace(tzinfo=None)
                        })
                        postgres_conn.rollback()

            if set_session:
                logging.info(f"setting the session varible to false")
                cursor.execute("SELECT set_config('myvars.update_in_progress', 'false', true)")
            for err in errors:
                try:
                    insert_error = """
                    INSERT INTO public.trigger_error_logs (
                        trigger_name, error_msg,error_query, error_timestamp
                    )
                    VALUES (%s, %s, %s, %s, %s)
                    """
                    cursor.execute(insert_error, (
                        err["trigger_name"], err["error_msg"],
                         err["trigger_table"], err["error_query"],
                        err["error_timestamp"]
                    ))
                    postgres_conn.commit()
                    logging.info("Logged error to trigger_error_logs.")
                except Exception as insert_ex:
                    logging.info(f"Failed to log error to trigger_error_logs: {insert_ex}")
                    postgres_conn.rollback()
            postgres_conn.commit()
            cursor.close()
        except Exception as e:
            logging.info(f"Error connecting to database or creating cursor: {e}")
        finally:
        # Close the database connection
            if postgres_conn:
                postgres_conn.close()
                logging.info("Connection closed.")

    def execute_update_queries_bak_21_05_2025(self,queries,to_database):
        #taking backup this function to resolve the blocking pids issue in prod
        # logging.info(queries)
        # logging.info(to_database)
        db_name=to_database
        hostname = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

        try:
            cursor = postgres_conn.cursor()
            for query_dict in queries:
                # Loop through each query key-value pair in the dictionary
                for query_name, query_text in query_dict.items():
                    logging.info(f"Executing {query_name}: {query_text}")
                    start_time = time.time()
                    try:
                    # Execute the SQL query
                        cursor.execute(query_text)
                        end_time = time.time()

                        # Calculate the duration (in seconds)
                        duration = end_time - start_time
                        logging.info(f"Executed {query_name} successfully in {duration:.2f} seconds.")

                        # Optionally, commit the transaction if needed
                        postgres_conn.commit()

                    except Exception as e:
                    # If there is an error, logging.info the error message and continue
                        logging.error(f"Error executing {query_name}: {e}")
                        postgres_conn.rollback()
            cursor.close()
        except Exception as e:
            logging.error(f"Error connecting to database or creating cursor: {e}")
        finally:
        # Close the database connection
            if postgres_conn:
                postgres_conn.close()
                logging.info("Connection closed.")

    def initate_complete_migration(self,df,to_connection,postgres_conn,migration_table,job_name,migration_details_dict,to_table,db_config,trace_id,total_count,success_count=0):
        try:
            to_db_name =migration_details_dict['to_database']
            time_column_check=migration_details_dict['time_column_check']
            time_columns = [col.strip() for col in time_column_check.split(',')]

            # logging.info(f"time column check got is {time_columns}")
            primary_id_col=migration_details_dict['primary_id_column']
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')

            if not to_table:
                logging.info(f"{trace_id} to table is emty so getting temp_table and to_mapping list")
                temp_table=migration_details_dict['temp_table']
                to_mapping=migration_details_dict['table_mappings']

                logging.info(f"{trace_id} temp table to insert data is {temp_table}")
                logging.info(f"{trace_id} table mappings {to_mapping}")

                insert_records,success,failures,last_id_time=self.insert_records_postgresql_batch_5(to_connection,df,temp_table,primary_id_col,time_columns,trace_id)

                if last_id_time is None:
                    logging.info(f"{trace_id} last_id is {last_id_time}")
                    last_id_time=self.update_last_id_list(to_table, primary_id_col, to_connection)
                    logging.info(f"{trace_id} last_id after {last_id_time}")

                table_names = [item["table_name"] for item in to_mapping]
                logging.info(f"{trace_id} insertion in temp table is done, transferring to tables: {table_names}")

                logging.info(f"{trace_id} now neeed to insert queries in tables")

                insert_flag, inserted_records, failed_records, last_id_tm=self.insert_records_postgresql_to_mapping(postgres_conn,to_mapping,primary_id_col,time_columns)
                logging.info(f"insert_flag :{insert_flag}")
                logging.info(f"inserted_records :: {inserted_records} failed_records {failed_records}")
                logging.info(f"last_id_time_ is {last_id_tm}")

                if insert_flag:
                    logging.info(f"################################## Migration Successfull")

                else:
                    logging.warning(f"Errors in Migration")
                    last_id_tm=None

                # migration_details_dict_updated=self.update_migration_details_dict(migration_details_dict,insert_records,success,failures,last_id_time,db_config)
                # migration_details_dict_updated['table_mappings']=json.dumps(to_mapping)
                migration_details_dict_updated=self.update_migration_details_dict(insert_records,success,failures,last_id_time)
                logging.info(f"{job_name} migration details dict {migration_details_dict_updated}")
                logging.info(f"###################### Details to update in table \n Status:{migration_details_dict_updated['status']},Last ID:{migration_details_dict_updated['last_id']},Migration Update:{migration_details_dict_updated['migration_update']}")
                logging.info(f"Updating table")
                uu=self.update_table(postgres_conn,migration_table,migration_details_dict_updated,{'migration_name':job_name})
                return True

            else:
                logging.info(f"{trace_id} To table is {to_table}")
                # insert_records,success,failures,last_id_time=self.insert_records_postgresql_batch_5(to_connection,df,to_table,primary_id_col,time_columns)

                insert_records,success,failures,last_id_time,error_msg,error_id_list=self.insert_records_postgresql_batch_5(to_connection,df,to_table,primary_id_col,time_columns,trace_id)
                success_count+=success
                logging.warning(f"{trace_id} Error ID list is {error_id_list}")
                logging.info(f"success count is updated {success_count},{success}")

                if total_count:
                    if success_count+failures==total_count:
                        logging.info(f"Migration completed successfully")
                        job_status_msg='SUCCESS'
                    else:
                        job_status_msg='FAILED'

                if last_id_time is None:
                        last_id_time=self.update_last_id_list(to_table, primary_id_col, to_connection)



                # migration_details_dict_updated=self.update_migration_details_dict(migration_details_dict,insert_records,success,failures,last_id_time,db_config)
                migration_details_dict_updated=self.update_migration_details_dict(insert_records,success,failures,last_id_time,error_msg)

                logging.info(f"{trace_id} {job_name} ############################# Details to update in table \n Status:{migration_details_dict_updated['status']},Last_ID:{migration_details_dict_updated['last_id']},Migration Update:{migration_details_dict_updated['migration_update']}")
                logging.info(f"{trace_id} {job_name} Updating table")
                to_database=migration_details_dict['to_database']

                if migration_details_dict['is_update']:
                    queries=migration_details_dict['update_queries']
                    inv_update=migration_details_dict['inv_update']
                    self.execute_update_queries(queries,to_database,inv_update)
                    #self.execute_update_queries(queries,to_database)

                logging.info(f"{trace_id} {job_name} Updating tables after migration is done")
                uu=self.update_table(postgres_conn,migration_table,migration_details_dict_updated,{'migration_name':job_name})

                update_hist_table={'error_id_list':json.dumps(error_id_list),'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_msg,'success':success_count,'failed':failures,'job_status_msg':job_status_msg}
                self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})

                return success_count


        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"{trace_id} {job_name} error while completing migration: {e} {tb}")
            error_message=f"error while completing migration: {e} {tb}"
            update_hist_table={'error_id_list':json.dumps(error_id_list),'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_message}
            self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})
            return False


    def insert_records_postgresql_to_mapping(self,postgres_connection, tables_dict, migration_track_col, time_columns):
        logging.info(f"#######################################################")
        # logging.info(f"Starting postgres connection is {postgres_connection}")
        inserted_records = 0
        failed_records = 0
        insert_flag = True
        batch_size = 5000
        failed_log = []
        last_id_time = None
        total_start_time = time.time()

        def insert_table_data(df, table_name):
            nonlocal inserted_records, failed_records, last_id_time, insert_flag

            columns = df.columns.tolist()
            num_batches = math.ceil(len(df) / batch_size)
            # logging.info(f"Processing table {table_name} with {len(columns)} columns")
            # logging.info(f"Number of Batches Created: {num_batches} with batch size {batch_size}")

            # Prepare the SQL queries
            columns_str = ', '.join(columns)
            update_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in columns])

            insert_query_update = f'''
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({migration_track_col}) DO UPDATE
                SET {update_clause}
            '''
            insert_query_no_conflict = f'INSERT INTO {table_name} ({columns_str}) VALUES %s'

            for batch_index in range(num_batches):
                start_index = batch_index * batch_size
                end_index = min((batch_index + 1) * batch_size, len(df))

                batch_df = df.iloc[start_index:end_index]
                rows = [tuple(row) for row in batch_df.to_numpy()]

                batch_start_time = time.time()

                try:
                    with postgres_connection.cursor() as cur:
                        execute_values(cur, insert_query_no_conflict, rows)
                    postgres_connection.commit()
                    inserted_records += len(rows)
                except psycopg2.Error as e:
                    logging.warning(f"Error inserting batch {batch_index + 1} without ON CONFLICT: {e}")
                    postgres_connection.rollback()

                    try:
                        with postgres_connection.cursor() as cur:
                            execute_values(cur, insert_query_update, rows)
                        postgres_connection.commit()
                        inserted_records += len(rows)
                    except psycopg2.Error as e2:
                        logging.warning(f"Error inserting batch {batch_index + 1} with ON CONFLICT: {e2}")
                        postgres_connection.rollback()

                        for row_index, row in batch_df.iterrows():
                            try:
                                with postgres_connection.cursor() as cur:
                                    cur.execute(insert_query_no_conflict, (tuple(row),))
                                postgres_connection.commit()
                                inserted_records += 1
                            except psycopg2.Error as e3:
                                logging.warning(f"Error inserting row {row_index + start_index} without ON CONFLICT: {e3}")
                                postgres_connection.rollback()

                                try:
                                    with postgres_connection.cursor() as cur:
                                        cur.execute(insert_query_update, (tuple(row),))
                                    postgres_connection.commit()
                                    inserted_records += 1
                                except psycopg2.Error as e4:
                                    logging.warning(f"Error inserting row {row_index + start_index} with ON CONFLICT: {e4}")
                                    postgres_connection.rollback()
                                    failed_records += 1
                                    insert_flag = False
                                    failed_log.append({
                                        'table_name': table_name,
                                        'batch_index': batch_index,
                                        'row_index': row_index + start_index,
                                        'error': str(e4),
                                        'failed_id': row[migration_track_col]  # Capture ID of the failed record
                                    })
                                    with open('error_log.txt', 'a') as f:
                                        f.write(f"Failed row details:\nTable: {table_name}\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e4)}\nFailed ID: {row[migration_track_col]}\n\n")

                batch_end_time = time.time()
                logging.info(f"Inserted batch {batch_index + 1} of {num_batches} with {len(rows)} records")
                logging.info(f"Batch insertion time: {batch_end_time - batch_start_time:.2f} seconds")

                last_id_time = [batch_df[col].iloc[-1] for col in time_columns]

        for table_dict in tables_dict:
            query = table_dict.get("query")
            # logging.info(f"query is {query}")
            table_name = table_dict.get("table_name")
            logging.info(f"the data to be inserted on table {table_name}")

            try:

                df = self.execute_query(postgres_connection, query)
                df = df.astype(object).mask(df.isna(), None)
                logging.info(f"query result is \n {df.head()}")
                logging.info(f"The number of rows in the DataFrame is: {df.shape[0]}")

                insert_table_data(df, table_name)
            except Exception as e:
                logging.error(f"Error executing query or inserting data into table {table_name}: {e}")
                with open('error_log.txt', 'a') as f:
                    f.write(f"Error executing query or inserting data into table {table_name}: {str(e)}\n")

        total_end_time = time.time()
        logging.info(f"Total insertion time: {total_end_time - total_start_time:.2f} seconds")
        last_id_time_=self.jsonify_last_id(last_id_time)
        logging.info(f"last_id_time_ is {last_id_time_}")

        return insert_flag, inserted_records, failed_records, last_id_time_


    def modify_uuid_cols(self,df):
        # Regular expression pattern for UUID
        uuid_pattern = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')

        # Step 1: Identify columns that contain UUIDs
        uuid_columns = []
        for col in df.columns:
            if df[col].apply(lambda x: bool(uuid_pattern.match(str(x)))).any():
                uuid_columns.append(col)

        # Step 2: Convert identified UUID columns to strings
        for col in uuid_columns:
            # df[col] = df[col].astype(str)
            # Apply conversion only where value is a valid UUID
            df[col] = df[col].apply(lambda x: str(x) if pd.notna(x) and uuid_pattern.match(str(x)) else x)
        # logging.info the columns identified as containing UUIDs
        logging.info(f"Columns identified as containing UUIDs: {uuid_columns}")
        return df

    def check_connection(self, connection):
        """
        Check if the connection is still active by executing a simple query.

        Args:
            connection: The database connection object.

        Returns:
            bool: True if the connection is active, False otherwise.
        """
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT 1")
            return True
        # except pyodbc.Error:
        except pytds.DatabaseError:
            return False

    def recognize_format(self,s):
        pattern1 = r'^[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)+$'
        pattern2 = r'^\[[a-zA-Z0-9]+\](\.\[[a-zA-Z0-9]+\])+$'
        pattern3 = r'^[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)+$'          # No brackets format
        pattern4 = r'^\[[a-zA-Z0-9_]+\](\.\[[a-zA-Z0-9_]+\])+$'
        pattern5= r'^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)+$'

        if re.match(pattern1, s):
            return True
        elif re.match(pattern2, s):
            return True
        elif re.match(pattern3, s):
            return True
        elif re.match(pattern4, s):
            return True
        elif re.match(pattern5, s):
            return True
        else:
            return False

    def clean_query(self, original_query):
    # Split the query by 'ORDER BY' into parts
        parts = original_query.rsplit('ORDER BY')
        #return None
    # Count the number of ORDER BY clauses
        order_by_count = len(parts) - 1  # Each 'ORDER BY' splits the query into parts

    # Check if there are multiple ORDER BY clauses
        if order_by_count > 1:
        # Rebuild the query without the second ORDER BY clause
            query_without_second_order_by = parts[0] + 'ORDER BY' + ''.join(parts[1:2])  # Keep the first ORDER BY and everything after the first
        elif order_by_count == 1:
        # Only one ORDER BY found, return the part before it
            query_without_second_order_by = parts[0]
        else:
            # No ORDER BY found
            query_without_second_order_by = original_query

    # Remove trailing semicolon and whitespace
        query_cleaned = query_without_second_order_by.rstrip(';').strip()

        return query_cleaned  # Return both cleaned query


    def get_count_query(self,original_query):
        # Clean the original query
        cleaned_query = self.clean_query(original_query)

        # Construct the count query
        count_query = f"""
        SELECT COUNT(*) AS total_count
        FROM (
            {cleaned_query}
        ) AS subquery;
        """
        logging.info(f"count_query {count_query}")
        return count_query

    def generate_batch_queries(self, count_query, from_query, db_conn, df_size, time_column_check):
        """
        Generate batch SQL queries for pagination from a SQL Server database.

        Parameters:
        - count_query (str): SQL query to get the count of records.
        - from_query (str): SQL query to fetch the records.
        - df_size (int): Number of records per batch.

        Returns:
        - List[str]: List of SQL queries for each batch.
        """
        try:
            logging.info(f"primary id col is {time_column_check}")
            # List to hold the batch queries
            batch_queries = []

            with db_conn.cursor() as cursor:
                # Execute the count query
                cursor.execute(count_query)
                total_count = cursor.fetchone()[0]

            logging.info(f"TOTAL COUNT {total_count} type {type(total_count)}")
            if total_count == 0:
                return False,0
                # raise ValueError("No Updated Records in DB")

            # Split the query into words to extract the last 5 words
            # last_five_words = from_query.split()[-5:]  # Get the last 5 words
            last_five_words =  [word.lower() for word in from_query.split()[-4:]]
            # logging.info(f"Last five words of the query: {last_five_words}")

            # Check if 'order by' is in the last 5 words
            if 'order' in last_five_words and 'by' in last_five_words:
                # logging.info(f"'ORDER BY' clause present")
                # Use the existing ORDER BY clause
                from_query = from_query.rstrip(';')
                base_query = from_query
            else:
                # logging.info(f"Adding 'ORDER BY'")
                # logging.info(f"time_column_check col is {time_column_check}")
                # Add a placeholder ORDER BY clause
                base_query = f"{from_query} ORDER BY {time_column_check}"

            # Calculate the total number of batches needed
            num_batches = (total_count + df_size - 1) // df_size

            # Generate batch queries
            for batch_number in range(num_batches):
                # Calculate the offset
                offset = batch_number * df_size

                # Construct the batch query with OFFSET and FETCH NEXT
                batch_query = (
                    f"{base_query} "
                    f"OFFSET {offset} ROWS "
                    f"FETCH NEXT {df_size} ROWS ONLY"
                )
                # logging.info(f"batch_query : {batch_query}")

                # Append the batch query to the list
                batch_queries.append(batch_query)

            return batch_queries,total_count
        except Exception as e:
            logging.error(f"Exception in count checking {e}")
            return False,False


    def generate_batch_queries_bak9oct24(self,count_query, from_query,db_conn, df_size,primary_id_col): #in order by checking its checking in whole query
        """
        Generate batch SQL queries for pagination from a SQL Server database.

        Parameters:
        - count_query (str): SQL query to get the count of records.
        - from_query (str): SQL query to fetch the records.
        - df_size (int): Number of records per batch.

        Returns:
        - List[str]: List of SQL queries for each batch.
        """
        try:
            logging.info(f"primary id col is {primary_id_col}")
            # List to hold the batch queries
            batch_queries = []

            with db_conn.cursor() as cursor:
                # Execute the count query
                cursor.execute(count_query)
                total_count = cursor.fetchone()[0]

            logging.info(f"TOTAL COUNT {total_count} type {type(total_count)}")
            if total_count==0:
                raise ValueError("No Updated Records in DB")

            # Determine if the from_query already contains an ORDER BY clause
            if 'order by' in from_query.lower():
                logging.info(f"order by cluase present")
                # Use the existing ORDER BY clause
                from_query=from_query.rstrip(';')
                base_query = from_query

            else:
                logging.info(f"adding order by")
                logging.info(f"primary id col is {primary_id_col}")
                # Add a placeholder ORDER BY clause
                base_query = f"{from_query} ORDER BY {primary_id_col}"

            # Calculate the total number of batches needed
            # Assuming you will use `count_query` externally to determine the number of batches
            # For simplicity, let's assume a dummy total_count value here

            num_batches = (total_count + df_size - 1) // df_size

            # Generate batch queries
            for batch_number in range(num_batches):
                # Calculate the offset
                offset = batch_number * df_size

                # Construct the batch query with OFFSET and FETCH NEXT
                batch_query = (
                    f"{base_query} "
                    f"OFFSET {offset} ROWS "
                    f"FETCH NEXT {df_size} ROWS ONLY"
                )
                logging.info(f"batch_query : {batch_query}")

                # Append the batch query to the list
                batch_queries.append(batch_query)

            return batch_queries
        except Exception as e:
            logging.info(f"Exception in count checking {e}")
            return False

    def to_mssql_datetime(self,timestamp_str):
        """
        Convert a high-precision timestamp string to a format compatible with SQL Server's datetime.

        Args:
        - timestamp_str (str): A timestamp string with high precision (e.g., '2024-08-08 13:27:12.954566').

        Returns:
        - str: A string formatted as SQL Server datetime (e.g., '2024-08-08 13:27:12.954').
        """
        try:
            # Step 1: Parse the string timestamp into a Python datetime object
            dt = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S.%f')

            # Step 2: Truncate the microseconds to fit MSSQL datetime (3 digits of milliseconds)
            dt = dt.replace(microsecond=(dt.microsecond // 1000) * 1000)

            # Step 3: Convert the datetime object back to a string compatible with MSSQL datetime format
            mssql_datetime_str = dt.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

            return mssql_datetime_str
        except ValueError as e:
            raise ValueError(f"Invalid timestamp format: {timestamp_str}. Error: {e}")

    def get_all_records(self,connection,table_name,primary_id_col):
        try:
            df_rows=f"select * from {table_name} order by {primary_id_col}"
            df = self.execute_query(connection,df_rows)
            df = df.astype(object).mask(df.isna(), None)
            return df

        except Exception as e:
            logging.error(f"Error while fetching all records {e}")
            return None

    def load_last_id(self,last_id_str):
        try:
            # Attempt to convert to integer
            last_id_int = int(last_id_str)
            return last_id_int  # Return as integer if successful
        except ValueError:
            try:
                # Attempt to convert to datetime
                last_id_timestamp = datetime.strptime(last_id_str, '%Y-%m-%d %H:%M:%S')
                return last_id_timestamp
            except ValueError:
                try:
                    last_id_timestamp = datetime.fromisoformat(last_id_str)
                    return last_id_timestamp  # Return as datetime if successful
                except ValueError:
                    try:
                        last_id=json.loads(last_id_str)
                        return last_id
                    except ValueError:
                        logging.error(f"Error while loading last_id from db")
                        return None # Return None if conversion fails

    def enclose_uppercase_words(self,input_string):
        # Split the input string by commas and strip any surrounding whitespace
        words = [word.strip() for word in input_string.split(',')]

        # Function to check if a word contains uppercase characters
        def needs_quotes(word):
            return any(char.isupper() for char in word)

        # Enclose words with uppercase characters in double quotes
        quoted_words = [f'"{word}"' if needs_quotes(word) else word for word in words]

        # Join the words back into a single string separated by commas
        return ', '.join(quoted_words)

    def insert_dict(self, conn, table_name, data_dict,return_flag=False,return_col=None):
        """
        Insert a row into a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to insert into
        :param data_dict: Dictionary containing column-value pairs to insert
        """
        try:
            # Convert dictionary values to JSON strings if necessary
            for key, value in data_dict.items():
                if isinstance(value, dict):
                    data_dict[key] = json.dumps(value)

            # Generate the column names and placeholders for the SQL query
            columns = ', '.join(data_dict.keys())
            placeholders = ', '.join(['%s'] * len(data_dict))

            # Create the SQL query
            if return_flag:
                sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders}) RETURNING {return_col}"
            else:
                sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            values = list(data_dict.values())

            # logging.info(f"SQL Query: {sql_query}")
            # logging.info(f"Values: {values}")

            # Execute the query
            with conn.cursor() as cursor:
                cursor.execute(sql_query, values)
                if return_col:
                    return_val= cursor.fetchone()[0]
                conn.commit()
                # conn.commit()
            logging.info("Insert successful")
            if return_flag:
                return return_val
            else:
                return True
        except Exception as e:
            conn.rollback()
            logging.error(f"Error inserting into table: {e}")
            return False

    def is_valid_table_name(self,table_name):
        pattern = r'^\[\w+\]\.\[\w+\]\.\[\w+\]$'
        return re.match(pattern, table_name) is not None

    def update_table(self,conn, table_name, data_dict, condition_dict):
        """
        Update a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to update
        :param data_dict: Dictionary containing column-value pairs to update
        :param condition_dict: Dictionary containing column-value pairs for the WHERE condition
        """
        try:
            # Generate the SET part of the SQL query
            set_clause = ', '.join([f"{col} = %s" for col in data_dict.keys()])

            if condition_dict:

            # Generate the WHERE part of the SQL query
                where_clause = ' AND '.join([f"{col} = %s" for col in condition_dict.keys()])


            if condition_dict:
            # Complete SQL query
                sql_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
                values = list(data_dict.values()) + list(condition_dict.values())

            else:
                sql_query = f"UPDATE {table_name} SET {set_clause}"
                values = list(data_dict.values())

            # Combine the values for the SET and WHERE parts


            logging.info(f"SQL Quey {sql_query} and values are {values}")

            ## Execute the query
            with conn.cursor() as cursor:
                cursor.execute(sql_query, values)
                conn.commit()
            logging.info("################################## Update successful")
        except Exception as e:
            conn.rollback()
            logging.error(f"Error updating table: {e}")

    def camel_to_snake_case(self,camel_str):
        # Convert a camelCase or PascalCase string to snake_case
        return ''.join(['_' + i.lower() if i.isupper() else i for i in camel_str]).lstrip('_')

    def insert_records_postgresql_batch_5(self, postgres_connection, df, insert_table_name, primary_id_col, time_columns,trace_id):
        """
        Inserts records into a PostgreSQL table in batches, with error handling for individual rows.

        Args:
            postgres_connection: The connection object to the PostgreSQL database.
            df: The DataFrame containing the data to be inserted.
            insert_table_name: The name of the table where data will be inserted.
            migration_track_col: The column used for tracking the migration progress.
            time_columns: List of columns that hold timestamp data.

        Returns:
            A tuple containing:
            - insert_flag (bool): Indicates whether the insertion was successful.
            - inserted_records (int): The number of successfully inserted records.
            - failed_records (int): The number of failed records.
            - last_id_time (str): JSON string of the last timestamp(s) from the successfully inserted records.

        Process:
        1. Calculates the number of batches needed based on the batch size (5000).
        2. Attempts to insert each batch:
            a. First, with the ON CONFLICT clause to handle conflicts.
            b. If the batch insertion fails, tries inserting the batch without the ON CONFLICT clause.
            c. If the batch insertion still fails, attempts to insert each row individually:
                i. First, with the ON CONFLICT clause.
                ii. If the individual row insertion fails, tries without the ON CONFLICT clause.
        3. Logs errors for any rows that fail to insert.
        4. Tracks the number of successfully inserted and failed records.
        5. Calculates and logs the total insertion time.
        6. Serializes and returns the last timestamp(s) and id(S) from the successfully inserted records.

        Notes:
        - Retries for 3 times when insert/update fails
        - Logs detailed error messages and failed record IDs to 'error_log.txt'.
        """
        # logging.info(f"Inserting into table {insert_table_name}, column {migration_track_col}")
        # logging.info(f"time columns got are {time_columns}")
        try:

            inserted_records = 0
            failed_records = 0
            insert_flag = True
            batch_size = 5000
            failed_log = []
            last_id_time = None
            num_batches = math.ceil(len(df) / batch_size)
            error_msg='SUCCESS'
            error_id_list=[]
            stop_insertion=False
            logging.info(f"{trace_id} {insert_table_name} Records to insert: {df.shape[0]}")
            logging.info(f"{trace_id} {insert_table_name} No of Batches Created: {num_batches} with batch size {batch_size}")

            # Extract column names once
            columns = ', '.join(df.columns)
            # logging.info(f"Columns: {columns}")

            # Check for time_columns and convert to snake_case if not in columns
            time_column_snake_case = []

            for col in time_columns:
                if col not in columns:
                    # Convert camelCase to snake_case
                    snake_case_col = self.camel_to_snake_case(col)
                    time_column_snake_case.append(snake_case_col)
                else:
                    time_column_snake_case.append(self.camel_to_snake_case(col))  # Convert existing ones too

            logging.info(f"{trace_id} {insert_table_name} time_column_snake_case::: {time_column_snake_case}")

            # Prepare the update clause for ON CONFLICT
            #logging.info(update_clause)
            # Prepare the update clause for ON CONFLICT (excluding 'device_history_id')
            #update_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in df.columns  ])
            update_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in df.columns if col not in time_column_snake_case])

            #update_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in df.columns])
            # logging.info("*******************update_clause",update_clause)
            total_start_time = time.time()

            # Define the insert block operation
            def insert_block_operation():
                nonlocal inserted_records, failed_records, last_id_time, insert_flag,error_msg,stop_insertion,error_id_list

                for batch_index in range(num_batches):
                    # if stop_insertion:
                    #     break
                    start_index = batch_index * batch_size
                    end_index = min((batch_index + 1) * batch_size, len(df))

                    batch_df = df.iloc[start_index:end_index]
                    rows = [tuple(row) for row in batch_df.to_numpy()]

                    insert_query_update = f'''
                        INSERT INTO {insert_table_name} ({columns})
                        VALUES %s
                        ON CONFLICT ({primary_id_col}) DO UPDATE
                        SET {update_clause}
                    '''
                    # logging.info("#######################insert_query_update",insert_query_update)
                    # logging.info(f"update clause is {update_clause}")
                    insert_query_no_conflict = f'INSERT INTO {insert_table_name} ({columns}) VALUES %s'

                    batch_start_time = time.time()

                    try:
                        with postgres_connection.cursor() as cur:
                            # Attempt to insert the batch without ON CONFLICT clause
                            logging.info(f"{insert_table_name} Trying to insert without update")
                            execute_values(cur, insert_query_no_conflict, rows)
                        postgres_connection.commit()

                        inserted_records += len(rows)
                        logging.info(f"{trace_id} Inserted records are {inserted_records}")
                        # Update last_id_time with the values from the last row of the batch
                        last_id_time = [rows[-1][batch_df.columns.get_loc(col)] for col in time_column_snake_case]
                        # error_msg='Success'

                    except psycopg2.Error as e:
                        logging.warning(f"{trace_id} {insert_table_name} Warning inserting batch {batch_index + 1} without ON CONFLICT: {e}")
                        postgres_connection.rollback()  # Rollback after the first error

                        try:
                            with postgres_connection.cursor() as cur:
                                # Attempt to insert the batch with ON CONFLICT clause
                                logging.info(f"{trace_id} {insert_table_name} trying insert with update")
                                # logging.info("updating query execution starts")
                                # logging.info(f"insert query with update {insert_query_update}")
                                execute_values(cur, insert_query_update, rows)
                                # logging.info("executed the updating query execution starts")
                            postgres_connection.commit()
                            inserted_records += len(rows)

                            logging.info(f"{trace_id} Inserted records are {inserted_records}")
                            # Update last_id_time with the values from the last row of the batch
                            last_id_time = [rows[-1][batch_df.columns.get_loc(col)] for col in time_column_snake_case]
                            # error_msg='Success'

                        except psycopg2.Error as e2:
                            logging.warning(f"{trace_id} {insert_table_name} Warning inserting batch {batch_index + 1} with ON CONFLICT: {e2}")
                            postgres_connection.rollback()  # Rollback after the second error

                            # Try inserting rows individually
                            for row_index, row in batch_df.iterrows():
                                # if stop_insertion:
                                #     break
                                try:
                                    row_as_numpy = row.to_numpy()
                                    row_as_tuple = tuple(row_as_numpy)
                                    with postgres_connection.cursor() as cur:
                                        # Attempt to insert individual row without ON CONFLICT clause
                                        cur.execute(insert_query_no_conflict, (row_as_tuple,))
                                    postgres_connection.commit()
                                    inserted_records += 1
                                    error_msg='success'

                                    # Update last_id_time with the values from the current row
                                    last_id_time = [row[col] for col in time_column_snake_case]
                                except psycopg2.Error as e3:
                                    logging.warning(f"{insert_table_name} Error inserting row {row_index + start_index} without ON CONFLICT: {e3}")
                                    postgres_connection.rollback()  # Rollback after the third error

                                    try:
                                        row_as_numpy = row.to_numpy()
                                        row_as_tuple = tuple(row_as_numpy)
                                        with postgres_connection.cursor() as cur:
                                            # Attempt to insert individual row without ON CONFLICT clause
                                            cur.execute(insert_query_update, (row_as_tuple,))
                                        postgres_connection.commit()
                                        inserted_records += 1

                                        # Update last_id_time with the values from the current row
                                        last_id_time = [row[col] for col in time_column_snake_case]

                                    except psycopg2.Error as e4:
                                        logging.warning(f"{trace_id} {insert_table_name} Error inserting row {row_index + start_index} with ON CONFLICT: {e4}")
                                        postgres_connection.rollback()  # Rollback after the fourth error
                                        # stop_insertion = True
                                        error_id_=row[primary_id_col.lower()]
                                        logging.info(f"Error id is {error_id_}")
                                        error_id_list.append(error_id_)
                                        logging.info(f"Error id list is {error_id_list}")
                                        error_msg=str(e4)
                                        last_id_time = [row[col] for col in time_column_snake_case]
                                        failed_records += 1
                                        insert_flag = False
                                        # Log the failed row details
                                        failed_log.append({
                                            'batch_index': batch_index,
                                            'row_index': row_index + start_index,
                                            'error': str(e4),
                                            'failed_id': row['id']  # Capture ID of the failed record
                                        })
                                        # with open('error_log.txt', 'a') as f:
                                        #     f.write(f"Failed row details:\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e4)}\nFailed ID: {row['id']}\n\n")
                                        logging.error(
                                            f"{insert_table_name} Failed row details:\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e4)}\nFailed ID: {row['id']}\n\n"
                                        )
                    # else:
                    #     # If batch insertion is successful, count all rows as inserted
                    #     inserted_records += len(rows)

                    logging.info(f"{trace_id} Inserted records are {inserted_records}")

                    batch_end_time = time.time()
                    logging.info(f"{trace_id} {insert_table_name} Inserted batch {batch_index + 1} of {num_batches} with {len(rows)} records {batch_end_time - batch_start_time:.2f} seconds")
                    logging.info(f"{trace_id} {insert_table_name} Batch insertion time: {batch_end_time - batch_start_time:.2f} seconds")

                    # Update last_id_time with the time columns from the last row of the current batch
                    # last_id_time = [batch_df[col].iloc[-1] for col in time_columns] #uncomment this

                    # if batch_index == 4:
                    #     break

            # Retry the entire block operation up to 3 times
            # for attempt in range(3):
            try:
                insert_block_operation()
                # break  # Break the retry loop if successful
            except Exception as e:
                # logging.error(f"{trace_id} {insert_table_name} Error in whole insert block operation on attempt : {e}")
                last_id_time=None
                logging.error(
                    f"{trace_id} {insert_table_name} Error in whole insert block operation on attempt : {str(e)}\n"
                )
                error_msg=f"{trace_id} {insert_table_name} Error in whole insert block operation on attempt : {str(e)}"
                    # with open('error_log.txt', 'a') as f:
                    #     f.write(f"Error in whole insert block operation on attempt {attempt + 1}: {str(e)}\n")

            total_end_time = time.time()
            logging.info(f"{trace_id} {insert_table_name} Total insertion time: {total_end_time - total_start_time:.2f} seconds")

            # Serialize and jsonify the last_id_time
            logging.info(f"last_id_time is {last_id_time}")
            if last_id_time:
                last_id_time_ = self.serialize_timestamps_and_jsonify(last_id_time)
                logging.info(f"last_id_time_: {last_id_time_}")
            else:
                last_id_time=None

            if failed_records>0:
                last_id_time_=None

            # return insert_flag, inserted_records, failed_records, last_id_time_
        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"{trace_id} {insert_table_name} Error while inserting records {e}")
            error_msg=f"Error in inserting records {e} {tb}"
            return False,0,0,None,error_msg,error_id_list
        return insert_flag, inserted_records, failed_records, last_id_time_,error_msg,error_id_list


    def update_records_postgresql_batch(self, postgres_connection, df, update_table_name, migration_track_col, time_columns):
        """
        Updates records in a PostgreSQL table in batches, with error handling for individual rows.

        Args:
            postgres_connection: The connection object to the PostgreSQL database.
            df: The DataFrame containing the data to be updated.
            update_table_name: The name of the table where data will be updated.
            migration_track_col: The column used for tracking the migration progress.
            time_columns: List of columns that hold timestamp data.

        Returns:
            A tuple containing:
            - update_flag (bool): Indicates whether the update was successful.
            - updated_records (int): The number of successfully updated records.
            - failed_records (int): The number of failed records.
            - last_id_time (str): JSON string of the last timestamp(s) from the successfully updated records.

        Process:
        1. Calculates the number of batches needed based on the batch size (5000).
        2. Attempts to update each batch:
            a. Updates the batch records.
            b. If the batch update fails, tries updating the batch one record at a time.
        3. Logs errors for any rows that fail to update.
        4. Tracks the number of successfully updated and failed records.
        5. Calculates and logs the total update time.
        6. Serializes and returns the last timestamp(s) and id(S) from the successfully updated records.

        Notes:
        - Retries for 3 times when update fails
        - Logs detailed error messages and failed record IDs to 'error_log.txt'.
        """

        updated_records = 0
        failed_records = 0
        update_flag = True
        batch_size = 5000
        failed_log = []
        last_id_time = None
        num_batches = math.ceil(len(df) / batch_size)
        logging.info(f"############# Records to update: {df.shape[0]}")
        logging.info(f"########### No of Batches Created: {num_batches} with batch size {batch_size}")

        # Extract column names once, excluding the primary key column
        columns = [col for col in df.columns if col != 'id']
        column_names = ', '.join(columns)
        logging.info(f"Columns: {column_names}")

        # Prepare the set clause for the update statement
        set_clause = ', '.join([f"{col} = %s" for col in columns])
        update_query = f'''
            UPDATE {update_table_name}
            SET {set_clause}
            WHERE id = %s
        '''

        total_start_time = time.time()

        # Define the update block operation
        def update_block_operation():
            nonlocal updated_records, failed_records, last_id_time, update_flag

            for batch_index in range(num_batches):
                start_index = batch_index * batch_size
                end_index = min((batch_index + 1) * batch_size, len(df))

                batch_df = df.iloc[start_index:end_index]
                rows = [tuple(row) for row in batch_df.to_numpy()]

                batch_start_time = time.time()

                try:
                    with postgres_connection.cursor() as cur:
                        # Attempt to update the batch
                        logging.info(f"Trying to update batch {batch_index + 1}")
                        for row in rows:
                            cur.execute(update_query, (*row[1:], row[0]))
                    postgres_connection.commit()
                except psycopg2.Error as e:
                    logging.warning(f"Error updating batch {batch_index + 1}: {e}")
                    postgres_connection.rollback()  # Rollback after the first error

                    # Try updating rows individually
                    for row_index, row in batch_df.iterrows():
                        try:
                            with postgres_connection.cursor() as cur:
                                # Attempt to update individual row
                                cur.execute(update_query, (tuple(row[1:]), row['id']))
                            postgres_connection.commit()
                            updated_records += 1
                        except psycopg2.Error as e3:
                            logging.warning(f"Error updating row {row_index + start_index}: {e3}")
                            postgres_connection.rollback()  # Rollback after the third error
                            failed_records += 1
                            update_flag = False
                            # Log the failed row details
                            failed_log.append({
                                'batch_index': batch_index,
                                'row_index': row_index + start_index,
                                'error': str(e3),
                                'failed_id': row['id']  # Capture ID of the failed record
                            })
                            logging.error(
                                f"Failed row details:\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e3)}\nFailed ID: {row['id']}\n\n"
                            )
                            # with open('error_log.txt', 'a') as f:
                            #     f.write(f"Failed row details:\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e3)}\nFailed ID: {row['id']}\n\n")
                else:
                    # If batch update is successful, count all rows as updated
                    updated_records += len(rows)

                batch_end_time = time.time()
                logging.info(f"Updated batch {batch_index + 1} of {num_batches} with {len(rows)} records")
                logging.info(f"Batch update time: {batch_end_time - batch_start_time:.2f} seconds")

                # Update last_id_time with the time columns from the last row of the current batch
                last_id_time = [batch_df[col].iloc[-1] for col in time_columns]

        # Retry the entire block operation up to 3 times
        for attempt in range(3):
            try:
                update_block_operation()
                break  # Break the retry loop if successful
            except Exception as e:
                logging.error(f"Error in whole update block operation on attempt {attempt + 1}: {e}")
                # with open('error_log.txt', 'a') as f:
                #     f.write(f"Error in whole update block operation on attempt {attempt + 1}: {str(e)}\n")

        total_end_time = time.time()
        logging.info(f"Total update time: {total_end_time - total_start_time:.2f} seconds")

        # Serialize and jsonify the last_id_time
        last_id_time_ = self.serialize_timestamps_and_jsonify(last_id_time)
        logging.info(f"last_id_time_: {last_id_time_}")

        return update_flag, updated_records, failed_records, last_id_time_


    def log_failed_batch(self,batch_index, error):
        with open('error_log.txt', 'a') as f:
            f.write(f"Failed batch details:\nBatch index: {batch_index}\nError: {str(error)}\n\n")

    def serialize_timestamps_and_jsonify(self,input_list):
        try:
            if input_list:
                serialized_list = []

                for item in input_list:
                    if isinstance(item, Timestamp):
                        serialized_list.append(item.to_pydatetime().isoformat())
                    elif isinstance(item, datetime):
                        serialized_list.append(item.isoformat())
                    else:
                        serialized_list.append(item)

                return json.dumps(serialized_list)
            else:
                return None
        except Exception as e:
            logging.info(f"Error serialize_timestamps_and_jsonify - {e}")
            return None

    def update_last_id_list_bal_16_jan(self,db_name, insert_table_name, time_check_cols, primary_id_col):
        try:
            postgres_connection = self.create_postgres_connection(db_name)
            last_id_time = []
            with postgres_connection.cursor() as cursor:
                # Constructing the SELECT query dynamically for multiple columns
                select_cols = ', '.join(time_check_cols)
                if not primary_id_col:
                    query=f"SELECT {select_cols} FROM {insert_table_name} ORDER BY {select_cols} DESC LIMIT 1"
                else:
                    query = f"SELECT {select_cols} FROM {insert_table_name} ORDER BY {primary_id_col} DESC LIMIT 1"

                cursor.execute(query)
                result = cursor.fetchone()


                if result:
                    for value in result:
                        if isinstance(value, datetime):
                            last_id_time.append(value.isoformat())
                        else:
                            last_id_time.append(value)
                else:
                    last_id_time = None

        except Exception as fetch_error:
            last_id_time = None
            logging.error(f"{insert_table_name} Error fetching last inserted record: {fetch_error}")

        return last_id_time    

    def update_last_id_list(self, insert_table_name, primary_id_columns, psql_connection):
        """
        Fetches the latest row values based on primary ID or timestamp columns.
        """ 
        try:
            last_id_time = []
 
            with psql_connection.cursor() as cursor:
                # Build select column list
                select_cols = primary_id_columns
 
                # Use the first column for ordering
                order_col = primary_id_columns
 
                query = f"""
                    SELECT {select_cols}
                    FROM {insert_table_name}
                    ORDER BY {order_col} DESC
                    LIMIT 1
                """
 
                cursor.execute(query)
                result = cursor.fetchone()
 
                if result:
                    for value in result:
                        if isinstance(value, datetime):
                            last_id_time.append(value.isoformat())
                        else:
                            last_id_time.append(value)
                else:
                    last_id_time = None
 
        except Exception as fetch_error:
            last_id_time = None
            print(f"{insert_table_name} Error fetching last inserted record: {fetch_error}")
 
        return last_id_time


    def get_ssms_last_id(self, ssms_connection, full_from_table,id_column_10):
        """
            Retrieves the maximum ID from a specific table in the SQL Server database.

            Args:
                ssms_connection: The connection object to the SQL Server Management Studio (SSMS) database.
                full_from_table (str): The name of the table from which to fetch the maximum ID and last modified date.

            Returns:
                tuple: A tuple containing the maximum ID (int or None) .
                False: In case of an error during the query execution.
        """
        try:

        # Query to fetch the maximum ID and last modified date
            query = f"SELECT  TOP 1 {id_column_10} AS last_id  FROM {full_from_table} order by {id_column_10} desc;"
            logging.info(f"{query} query to get sandbox id  ")
        # Create a cursor and execute the query
            cursor = ssms_connection.cursor()
            cursor.timeout=360000
            cursor.execute(query)

            result = cursor.fetchone()
            last_id = result[0] if result else 0
            logging.info(f"last_id: {last_id} retrieved sandbox last id ")
            # Close the connection
            cursor.close()

            return last_id
        except Exception as e:
            logging.info(f"Error occurred in getting lastid from device_history table: {e}")
            return False

    def get_ssms_last_id_(self, ssms_connection, full_from_table): #removing on 11-dec-2024 fro revcustomer bug
        """
        Retrieves the maximum ID and last modified date from a specific table in the SQL Server database.

        Args:
            ssms_connection: The connection object to the SQL Server Management Studio (SSMS) database.
            full_from_table (str): The name of the table from which to fetch the maximum ID and last modified date.

        Returns:
            tuple: A tuple containing the maximum ID (int or None) and the last modified date in PostgreSQL format (str or None).
            False: In case of an error during the query execution.
        """
        try:
        # Query to fetch the maximum ID and last modified date
            query = f"SELECT MAX(id) AS last_id, MAX(modifieddate) AS last_modified_date FROM {full_from_table}"
            logging.info(f"{query}")
        # Create a cursor and execute the query
            cursor = ssms_connection.cursor()
            cursor.execute(query)

        # Fetch the result
            result = cursor.fetchone()
            if result:
                last_id = result[0]  # MAX(id)
                mssql_last_modified_date = result[1]  # MAX(modifieddate)

            # Convert MSSQL datetime to PostgreSQL-compatible format if it exists
                if mssql_last_modified_date:
                    psql_last_modified_date = mssql_last_modified_date.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    psql_last_modified_date = None
            else:
                last_id = None
                psql_last_modified_date = None

        # Close the cursor
            cursor.close()

        # Return the results as a tuple
            return last_id, psql_last_modified_date

        except Exception as e:
            logging.error(f"Error occurred:fn get_ssms_last_id {e}")
            return False

    def convert_timestamp_to_sql_datetime(self, ts):
        """
        Converts a pandas timestamp to a SQL-compatible datetime format.
        The function checks if the timestamp is null and returns None. Otherwise, it formats
        the timestamp to a string in the format 'YYYY-MM-DD HH:MM:SS.MMM' which is compatible
        with SQL datetime types.

        Args:
            ts (Timestamp or None): The pandas timestamp to convert.

        Returns:
            str or None: The formatted datetime string for SQL or None if the input is null.
        """
        if pd.isnull(ts):
            return None  # or 'NULL' if you are preparing a string for SQL queries
        return ts.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    def construct_merge_query(self, df, table_name, compare_column):
        """
        Constructs a SQL MERGE query for inserting or updating records in the target table.
        This function compares data from a pandas DataFrame with the target table using a specified
        comparison column and generates an appropriate SQL query.

        Args:
            df (pandas.DataFrame): The DataFrame containing the data to merge.
            table_name (str): The name of the target table.
            compare_column (str): The column to compare for matching records in the merge.

        Returns:
            str: The SQL MERGE query as a string.
        """
        compare_column=compare_column.lower()
        # if 'id' in df.columns:
        #     df = df.drop(columns=['id'])

        # Extract column names from the DataFrame to be used in the query
        columns = df.columns.tolist()

        # Prepare the column names for the query
        source_columns = ", ".join(columns)

        # Build the USING (VALUES...) section dynamically
        values_list = []
        for _, row in df.iterrows():
            values = []
            for col in columns:
                value = row[col]
                if pd.isnull(value):  # Handle NULL values
                    values.append("NULL")
                elif isinstance(value, str):  # Add quotes for string values
                    values.append(f"'{value}'")
                else:
                    values.append(str(value))  # For numeric or boolean values
            values_list.append(f"({', '.join(values)})")

        values_section = ",    ".join(values_list)

        # Build the UPDATE SET part by excluding the compare_column
        '''update_set_clause = ",        ".join(
            [
                f"target.{col} = source.{col}"
                for col in columns if col != compare_column or col != "Id" or col != "id"
            ]
        )
        logging.info(update_set_clause)'''
        update_set_clause = ",        ".join(
        [
        f"target.{col} = source.{col}"
        for col in columns
        if col.lower() != compare_column.lower()  # Exclude "id" and compare_column
        ]
        )
        #logging.info(update_set_clause)
        #return None
        # Remove 'id' column if it exists in the DataFrame
        '''if "id" in df.columns:
            psql_values = df["id"].tolist()
            df = df.drop(columns=["id"])'''
        if compare_column in df.columns:
            logging.info(f"{compare_column} in df columns ")
            psql_values = df[compare_column].tolist()
            df = df.drop(columns=[compare_column])
        else:
            psql_values=None
        columns2 = df.columns.tolist()
        # Build the INSERT part using all columns
        insert_columns = ", ".join(columns2)
        insert_values = ", ".join([f"source.{col}" for col in columns2])

        # Construct the full MERGE query
        query = f"""MERGE INTO {table_name} AS target
        USING (VALUES
            {values_section}
        ) AS source ({source_columns})
        ON target.{compare_column} = source.{compare_column}
        WHEN MATCHED THEN
            UPDATE SET
                {update_set_clause}
        WHEN NOT MATCHED THEN
            INSERT ({insert_columns})
            VALUES ({insert_values});
        """
        logging.info(f"Generated Merge Query   construct_merge_query:, {query}")
        # Construct the final MERGE query
        # query = f"""
        # MERGE INTO {table_name} AS target
        # USING (VALUES
        #     {values_section}
        # ) AS source ({source_columns})
        # ON target.{compare_column} = source.{compare_column}  -- Unique column
        # WHEN MATCHED THEN
        #     UPDATE SET
        #         {update_set_clause}
        # WHEN NOT MATCHED THEN
        #     INSERT ({insert_columns})
        #     VALUES ({insert_values});
        # """
        return query,psql_values

    def update_psql_id_with_10_return_ids(self,postgres_conn,table20,mssql_ids,psql_values,id_column_20):
        logging.info("updating the postgress sql ids ")
        if len(mssql_ids) != len(psql_values):
            raise ValueError("The length of inserted_ids and id_values must be the same")
        case_statements = []
        logging.info("mssql inserted ids are",mssql_ids)
        logging.info("pssql ids are ",psql_values)
        for mssql_id, psql_value in zip(mssql_ids, psql_values):
            case_statements.append(f"WHEN {id_column_20} ='{psql_value}' THEN '{mssql_id}'")
        logging.info(f"case_statements are : {case_statements}")
        update_query = f"""
        UPDATE {table20}
        SET {id_column_20} = CASE
            {' '.join(case_statements)}
            ELSE {id_column_20}
            END
        WHERE {id_column_20} IN ({', '.join(f"'{val}'" for val in psql_values)});
        """
        #logging.info(postgres_conn)
        logging.info("Generated Update Query:\n", update_query)
        # Execute the query
        try:
           with postgres_conn.cursor() as cursor:
            cursor.execute(update_query)  # Execute the query
            postgres_conn.commit()  # Commit the transaction
            logging.info("Query executed and changes committed successfully.")
        except Exception as e:
            postgres_conn.rollback()  # Rollback in case of error
            logging.error("Error occurred during query execution:", str(e))
            raise ValueError(f"Error in updating ids in postgresql with 1.0 ids in reverse sync")

    def insert_into_ssms(
        self, ssms_conn, df, insert_table_name, migration_track_col, time_columns,table_20,postgres_conn,id_column_10,id_column_20,primary_id_col
    ):
        """
        Inserts records into a SQL Server Management Studio (SSMS) database in batches.
        The method constructs and executes a merge query for inserting or updating records
        and handles errors by retrying failed batches and logging failures.

        Args:
            ssms_conn: The connection object to the SSMS database.
            df (pandas.DataFrame): The DataFrame containing the data to be inserted.
            insert_table_name (str): The name of the target table in the database.
            migration_track_col (str): The column used for tracking migration in the merge query.
            time_columns (list): The columns containing timestamp information for tracking the last record.

        Returns:
            bool: Returns True if the insertion was successful, False if there were failures.
        """
        try:

            inserted_records = 0
            failed_records = 0
            insert_flag = True
            batch_size = 50
            failed_log = []
            last_id_time = None
            num_batches = math.ceil(len(df) / batch_size)
            stop_insertion=False
            rev_error_id_list=[]
            error_msg=None
            logging.info(f"############# Records to insert: {df.shape[0]}")
            logging.info(f"########### No of Batches Created: {num_batches} with batch size {batch_size} {insert_table_name}")
            logging.info(f"time columns are {time_columns}")

            def insert_block_operation():
                """
                Performs the insert operation in batches, constructs the merge queries,
                and handles errors such as failed records and retries.
                """
                nonlocal inserted_records, failed_records, last_id_time, insert_flag,stop_insertion,rev_error_id_list
                for batch_index in range(num_batches):
                    # Get the start and end indices for the current batch
                    start_index = batch_index * batch_size
                    end_index = min((batch_index + 1) * batch_size, len(df))
                    # Extract the current batch from the DataFrame
                    batch_df = df.iloc[start_index:end_index]

                    # logging.info(f"batch_df is {batch_df.head()}")

                    # Construct the merge query for the batch
                    insert_query_update,psql_values = self.construct_merge_query(
                        batch_df, insert_table_name,id_column_10
                    )
                    #logging.info(f"insert_query_update {insert_query_update}")

                    if insert_query_update:
                        try:
                            # Execute the merge query and commit the transaction
                            cursor = ssms_conn.cursor()
                            # logging.info(cursor)

                            # logging.info(insert_query_update)

                            cursor.execute(insert_query_update)  # Execute the query
                            #mssql_ids = cursor.fetchall()

                            #mssql_ids=[(80,)]

                            #mssql_ids=list(mssql_ids[0])
                            # logging.info("these are before list",mssql_ids)
                            #mssql_ids=[item[0] for item in mssql_ids]
                            #results=[]
                            #for last_id_ssms in mssql_ids:
                                #result = self.convert_uuid_id(last_id_ssms)
                                #results.append(result)
                            #mssql_ids=results
                            # logging.info(mssql_ids)
                            #logging.info(f"the new id which is inserted in mssql {mssql_ids}")
                            logging.info(f"the postgress sql ids are {psql_values}")
                            # logging.info(mssql_ids)
                            # logging.info(table_20)
                            #logging.info(postgres_conn)

                            ssms_conn.commit()  # Commit the transaction
                            logging.info("Records are inserted into mssql database successfully")

                            #self.update_psql_id_with_10_return_ids(postgres_conn,table_20,mssql_ids,psql_values,id_column_20)
                            inserted_records += len(
                                batch_df
                            )  # Update the count of inserted records
                            last_row = batch_df.iloc[
                                -1
                            ]  # Get the last row in the batch

                            last_id_time = [
                                last_row[col]
                                for col in time_columns
                                if col in batch_df.columns
                            ]  # Capture time column values

                        except Exception as e:
                            # If the batch insertion fails, rollback and log the failure
                            ssms_conn.rollback()
                            logging.error(
                                f"########### Failed to execute query for batch {batch_index}: {e}"
                            )
                            failed_records += len(
                                batch_df
                            )  # Increment the count of failed records
                            failed_log.append(
                                {
                                    "batch_index": batch_index,
                                    "query": insert_query_update,
                                }
                            )
                            # Retry the insertion by executing individual queries for each row
                            try:
                                logging.info(
                                    f"############### Retrying with individual queries:"
                                )
                                for idx, row in batch_df.iterrows():
                                    # Construct the insert query for the individual row
                                    individual_insert_query,psql_values = (
                                        self.construct_merge_query(
                                            pd.DataFrame([row]),
                                            insert_table_name,
                                            migration_track_col,
                                        )
                                    )
                                    cursor.execute(
                                        insert_query_update
                                    )  # Execute the query
                                    ssms_conn.commit()  # Commit the transaction
                                    inserted_records += 1
                                    last_id_time = [
                                        row[col]
                                        for col in time_columns
                                        if col in batch_df.columns
                                    ]
                                    # logging.info(individual_insert_query)
                            except Exception as e:
                                # If individual queries fail, rollback and log the error
                                ssms_conn.rollback()
                                error_id=row['id']
                                rev_error_id_list.append(error_id)
                                logging.info(f"rev_error_id_list {rev_error_id_list}")
                                error_msg=f'error in insert_ssms rev_sync {e}'
                                logging.error(
                                    f"Failed to execute query for batch {batch_index}: {e}"
                                )
                                failed_records += len(
                                    batch_df
                                )  # Increment the count of failed records
                                failed_log.append(
                                    {
                                        "batch_index": batch_index,
                                        "query": insert_query_update,
                                    }
                                )
                                insert_flag = False

                    else:
                        # If no insert query was generated, flag as failed
                        insert_flag = False
                        raise ValueError(f"Couldn't get insert query for the records")

            # Retry mechanism for handling failed insert block operations
            # for attempt in range(3):
            try:
                insert_block_operation()
                # break  # Break the retry loop if successful
            except Exception as e:
                # logging.error(
                #     f"Error in whole insert block operation on attempt {attempt + 1}: {e}"
                # )
                last_id_time = None
                insert_flag = False
                # with open('error_log.txt', 'a') as f:
                # f.write(f"Error in whole insert block operation on attempt {attempt + 1}: {str(e)}\n")
                logging.error(
                    f"Error in whole insert block operation on attempt {str(e)}\n"
                )

        except Exception as e:
            # Handle unexpected errors and log them
            insert_flag = False
            tb = traceback.format_exc()
            error_msg=f"Exception in inserting records into 1.0 for Reverse Sync: {e} {tb}"
            logging.error(
                f"Exception in inserting records into 1.0 for Reverse Sync: {e}"
            )
            return False,error_msg,rev_error_id_list
        return insert_flag,error_msg,rev_error_id_list

    def convert_uuid_id(self,id):
        if isinstance(id, uuid.UUID):
            return str(id)
        uuid_pattern = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')
        if isinstance(id, str) and uuid_pattern.match(id):
            return str(id)  # Convert and return the UUID as a string
        return id

    def reverse_sync_migration(
        self, job_name, postgres_conn, reverse_sync_mappings, migration_details_dict,trace_id,postgres_hist_conn
    ):

        """
        Handles the reverse synchronization migration for data transfer between the source and target databases.
        It retrieves data from the source database using the provided reverse sync mappings and inserts it into
        the target database.

        Args:
            job_name (str): The name of the migration job.
            postgres_conn (connection): The connection to the PostgreSQL target database.
            reverse_sync_mappings (list): A list of mappings that define how to sync data between databases.
            migration_details_dict (dict): Dictionary containing the migration job details.

        Returns:
            None
        """
        try:
            logging.info(f"{trace_id} Starting Reverse sync")
            rev_error_id_list=[]
            error_msg=None
            # Get the database configuration for the source database
            db_config = self.get_db_config(migration_details_dict)
            from_host = db_config["hostname"]
            from_port = db_config["port"]
            from_user = db_config["user"]
            from_pwd = db_config["password"]
            from_db_type = db_config["from_db_type"]
            from_database = migration_details_dict["from_database"]
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            history_table=os.getenv("MIGRATIONS_HISTORY_TABLE")

            logging.info("Create a connection to the source database using the retrieved configuration")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            id_column_20 = migration_details_dict.get('primary_id_column')
            id_column_10 = migration_details_dict.get('time_column_check')
            logging.info(f"20 id column is {id_column_20}")
            logging.info(f"10 id got  column is {id_column_10}")

            # Iterate through each mapping item in reverse_sync_mappings
            # logging.info(f"From connection is {from_connection}")
            for dict_item in reverse_sync_mappings:
                from_20_query = dict_item["query"]
                table_10 = dict_item["table"]
                migration_track_col = dict_item["ref"]
                table_20=dict_item["table20"]
                logging.info(f"1.0 table is {table_10} 2.0 table is {table_20}")

                # Check if the table name is valid and construct the full table name
                if not self.is_valid_table_name(table_10):
                    full_from_table = f"[{from_database}].[dbo].[{table_10}]"
                    logging.info(f"full table name {full_from_table}")
                else:
                    full_from_table = table_10

                # Get the last ID from the source database
                logging.info(f"table 10 is {full_from_table}")
                last_id_ssms = self.get_ssms_last_id(from_connection, full_from_table,id_column_10)
                logging.info(f"{trace_id} last id from 1.0 is   convertbeforeint into uuid {last_id_ssms} {full_from_table} {id_column_20}")
                last_id_ssms=self.convert_uuid_id(last_id_ssms)
                logging.info(f"{trace_id} last id from 1.0 is after convertint into uuid {last_id_ssms} {full_from_table} {id_column_20}")

                # Clean up and format the query for retrieving updated records
                from_query_20 = " ".join(from_20_query.split())
                from_query_20 = from_query_20.rstrip(";")

                ###need to get error ids from previous job
                error_ids_query=f"select rev_sync_error_id,job_end_time from {history_table} where job_name='{job_name}' and trace_id<>'{trace_id}' order by job_end_time desc limit 1"
                error_ids_df=self.execute_query(postgres_hist_conn,error_ids_query)
                # logging.info(f"DF is {error_ids_df}")
                if not error_ids_df.empty:
                    error_id_list=error_ids_df['rev_sync_error_id'][0]
                    last_migrated_time_prev=error_ids_df['job_end_time'][0]
                else:
                # Handle the empty DataFrame case (e.g., return or log an error)
                    logging.info(f"{trace_id} DataFrame 'error_ids_df' is empty.")
                    error_id_list=[]
                    last_migrated_time_prev=[]
                logging.info(f"Error id list {error_id_list}, type is {type(error_id_list)}")

                last_migrated_time_query=f"select job_end_time from {history_table} where job_name='{job_name}' and trace_id<>'{trace_id}' and job_status_msg='SUCCESS' order by id desc limit 1"
                last_migrated_df=self.execute_query(postgres_hist_conn,last_migrated_time_query)
                if not last_migrated_df.empty:
                    last_migrated_time_job=last_migrated_df['job_end_time'][0]
                else:
                    last_migrated_time_job=None
                    logging.info(f"{trace_id} DataFrame 'job start time' is empty.")
                logging.info(f"Last migrated time is {last_migrated_time_job}")

                if last_migrated_time_job:
                    last_migrated_time=last_migrated_time_job
                else:
                    last_migrated_time = migration_details_dict["last_migrated_time"]


                # Check if the query involves 'modified_date', which means using a timestamp-based condition
                if "modified_date" in from_query_20.lower() and isinstance(last_id_ssms, int)  and id_column_20.lower() in from_20_query.lower():
                    logging.info(f"entered integer id part{last_id_ssms}")
                    # last_migrated_time = migration_details_dict["last_migrated_time"]
                    logging.info(f"{trace_id} last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    time_cols = [id_column_20, "modified_date"]
                    time_cols_ssms = [id_column_20, "modifieddate"]
                    primary_id_col = [id_column_20]
                    last_id = [last_id_ssms, f"{last_migrated_time}"]
                    logging.info(f"{trace_id} after modifying time col and last_migrated time{last_id_ssms}, {time_cols},{last_id}" )

                elif "modified_date" in from_20_query.lower() and "created_date" in from_20_query.lower() and isinstance(last_id_ssms, str):
                    logging.info("this part for the uuid columns")
                    time_cols=["modified_date","created_date"]
                    time_cols_ssms=["id"]
                    primary_id_col = None
                    #  last_migrated_time=migration_details_dict["last_migrated_time"]
                    last_id=[f"{last_migrated_time}",f"{last_migrated_time}"]
                    primary_id_col = [id_column_20]

                else:
                    # Default to using only the ID column for the condition
                    time_cols = [id_column_20]
                    time_cols_ssms = [id_column_20]
                    last_id = [last_id_ssms]
                    primary_id_col = [id_column_20]


                logging.info(f"{trace_id} before passing time_cols and last_id to get_updated_records_query these are the values {time_cols},{last_id}")

                # Get the SQL query to fetch updated records from the source database
                pgsql_from_query = self.get_updated_records_query(
                    time_cols, last_id, None, from_query_20,error_id_list
                )
                logging.info(f"{trace_id} after updating query to get get_updated_records_query {pgsql_from_query},{time_cols},{last_id}")

                df_from_20 = self.execute_query(postgres_conn, pgsql_from_query)
                if df_from_20 is None or df_from_20.shape[0] == 0:
                    logging.info("execute_query returned None.")
                    logging.info(f"{trace_id} execute_query returned None.")
                    return True,'SUCCESS',rev_error_id_list

                if df_from_20.empty or df_from_20.shape[0] == 0:
                    logging.info("DataFrame is empty; there are no updated records.")
                    logging.info(f"{trace_id} DataFrame is empty; there are no updated records.")
                    return True,'SUCCESS',rev_error_id_list

                else:
                    logging.info(f"df_from_20 is {df_from_20}")

                # Convert datetime columns to SQL-compatible format
                for col in df_from_20.columns:
                    if pd.api.types.is_datetime64_any_dtype(df_from_20[col]):
                        df_from_20[col] = df_from_20[col].apply(
                            self.convert_timestamp_to_sql_datetime
                        )

                # Replace NaN values with None and convert boolean values to integers (1/0)
                df_from_20 = df_from_20.astype(object).mask(df_from_20.isna(), None)
                #df_from_20.replace({True: 1, False: 0}, inplace=True)
                df_from_20 = df_from_20.applymap(lambda x: 1 if x is True else (0 if x is False else x))
                logging.info(f"############# Result DF:::::{df_from_20}")
                df_from_20=self.modify_uuid_cols(df_from_20)

                # Insert the data into the target database (SSMS)

                insert_flag,error_msg,rev_error_id_list=self.insert_into_ssms(
                    from_connection,
                    df_from_20,
                    full_from_table,
                    migration_track_col,
                    time_cols_ssms,
                    table_20,postgres_conn,
                    id_column_10,
                    id_column_20,primary_id_col
                )
            logging.info(f"Error id list {rev_error_id_list}")
            update_hist_table={'rev_sync_error_id':json.dumps(rev_error_id_list),'error_msg':error_msg}
            self.update_table(postgres_hist_conn,history_table,update_hist_table,{'trace_id':trace_id})
            return True,'SUCCESS',rev_error_id_list
        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"{trace_id} Error in reverse sync migration: {e}")
            error_message=f"{trace_id} Error in reverse sync migration: {e} {tb}"
            self.update_table(postgres_hist_conn,history_table,{'error_msg':error_message},{'trace_id':trace_id})
            return False,error_message,rev_error_id_list



    def delete_message_from_sqs(self, receipt_handle):
        try:
            queue_url=os.getenv("OPTIMIZATION_QUEUE_URL")
            sqs.delete_message(
                # QueueUrl="https://sqs.us-east-1.amazonaws.com/008971638399/optimisation_sync_uat.fifo",
                QueueUrl=queue_url,
                ReceiptHandle=receipt_handle,
            )
            logging.info("Message deleted from SQS successfully.")
        except Exception as e:
            logging.error(f"Error deleting message from SQS: {e}")
            raise

    def send_msg_to_opt_sync_queue(self, message_body):
        try:
            logging.info("-----------", message_body)
            # Initialize the SQS client
            logging.info("calling SQS QUEUEEEEEEEEEEEEEE")
            sqs_client = boto3.client("sqs", region_name="us-east-1")
            message_body["sqs_flag"] = True
            queue_url=os.getenv("OPTIMIZATION_QUEUE_URL")
            # queue_url = "https://sqs.us-east-1.amazonaws.com/008971638399/optimisation_sync_uat.fifo"
            # Send the message to the SQS queue
            message_group_id = str(uuid.uuid4())
            response = sqs_client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(message_body),
                MessageGroupId=message_group_id,
                MessageDeduplicationId=str(uuid.uuid4()),
            )

            logging.info(
                f"Message sent to SQS queue {queue_url}. Message ID: {response['MessageId']}"
            )
            return response["MessageId"]
        except Exception as e:
            logging.error(f"Error sending message to SQS queue: {e}")
            raise

    def function_to_check_sub_tenant_or_parent_name(self, postgres_conn, tenant_name):
        try:
            # SQL query to check tenant information
            query = """
                SELECT id,tenant_name, parent_tenant_id, db_name
                FROM public.tenant
                WHERE tenant_name = %s
                ORDER BY id DESC
                LIMIT 1;
            """

            # Execute the query with the tenant_id
            cursor = postgres_conn.cursor()
            cursor.execute(query, (tenant_name,))
            result = cursor.fetchone()

            # Check if the result exists
            if result:
                tenant_id, tenant_name, parent_tenant_id, db_name = result

                # Determine the flags based on parent_tenant_id
                if parent_tenant_id is not None:
                    parent_query = """
                    SELECT tenant_name
                    FROM public.tenant
                    WHERE id = %s
                    LIMIT 1;
                    """
                    cursor.execute(parent_query, (parent_tenant_id,))
                    parent_result = cursor.fetchone()

                    if parent_result:
                        tenant_name = parent_result[0]  # Overwrite with parent tenant name

                parent_tenant_flag = True if parent_tenant_id is None else False
                sub_tenant_flag = not parent_tenant_flag
                return tenant_name

            else:
                # If no result is found, raise an exception
                raise ValueError(f"No tenant found with tenant_id {tenant_name}")
        except Exception as e:
        # Handle any errors that may occur
            logging.info(f"Error occurred: {e}")
            return None, None, None  # Return None if there's an error

    def construct_condition_query(self,base_query, condition_column, value):
        """
        Replace placeholder in condition and append it to the base query.

        Args:
            base_query (str): The main SELECT query.
            condition_column (str): The condition string with placeholders like {device_id}.
            value (any): The value to insert into the condition (e.g., 1234).

        Returns:
            str: Fully constructed SQL query.
        """
        try:
            # Remove trailing semicolon if present
            base_query = base_query.strip().rstrip(';')
            # Create WHERE clause
            # Handle list or tuple as IN condition
            if isinstance(value, (list, tuple)):
            # Format values for SQL (assumes values are ints or properly sanitized strings)
                formatted_values = ', '.join([f"'{v}'" if isinstance(v, str) else str(v) for v in value])
                where_clause = f"WHERE {condition_column} IN ({formatted_values})"
            else:
                formatted_value = f"'{value}'" if isinstance(value, str) else value
                where_clause = f"WHERE {condition_column} = {formatted_value}"
            # Check if ORDER BY already exists
            if "ORDER BY" in base_query.upper():
                # Inject WHERE before ORDER BY
                parts = base_query.rsplit("ORDER BY", 1)
                full_query = f"{parts[0]} {where_clause} ORDER BY{parts[1]}"
            else:
                full_query = f"{base_query} {where_clause}"
            return full_query

        except KeyError as e:
            raise ValueError(f"Missing placeholder in condition: {e}")


    def inventory_live_sync(self, key_name, device_id=None):
        """
        Perform reverse data sync from PostgreSQL to MSSQL for specified  job.

        This function retrieves a list of migration job names from the `lambda_sync_jobs` table
        based on the given `key_name`. For each job, it fetches the associated reverse sync
        configuration, constructs condition-based queries, pulls data from PostgreSQL (2.0),
        and then updates the corresponding records in MSSQL (1.0) using a dynamically built
        MERGE (upsert) query.

        Args:
            key_name (str): The key identifier to fetch the list of migration job names from `lambda_sync_jobs`.
            device_id (int or list, optional): Device ID(s) to use for conditional filtering in the query.
            mobility_device_id (int or list, optional): Mobility device ID(s), reserved for future use or extended filters.

        Returns:
            bool: Returns True after successfully syncing or if no data is available to sync.

        Raises:
            Exception: Any unexpected error during query execution, database connection, or data transformation is caught and logged.
        """
        try:
            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            migration_table = "lambda_sync_jobs"
            job_scheduled_query = f"select migration_names_list from {migration_table} where key_name='{key_name}'"
            rows = self.execute_query(postgres_conn, job_scheduled_query)
            logging.info(f"{key_name}------Data from key name is {rows},{type(rows)}")
            job_names_list = rows["migration_names_list"][0]

            for job_name in job_names_list:
                migration_table = os.getenv('MIGRATION_TABLE')
                logging.info(f"migrations table {migration_table}")
                migration_details_dict = self.get_migration_details(job_name, postgres_conn, migration_table)
                logging.info(f"migrations details dict {migration_details_dict}")
                if not migration_details_dict:
                    logging.info(f"No migration config found for job: {job_name}")
                    continue


                reverse_sync_mappings = migration_details_dict["reverse_sync_mapping"]
                for dict_item in reverse_sync_mappings:
                    logging.info(f"dict_item gotten is {dict_item}")
                    from_20_query = dict_item["query"]
                    table_10 = dict_item["table"]
                    migration_track_col = dict_item["ref"]
                    table_20 = dict_item["table20"]
                    condition = dict_item.get("condition")
                    if not condition:
                        self.main_migration_func(job_name)
                        continue

                    #insert trace id
                    history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
                    hist_insert_data={'key_name':key_name,'job_name':job_name,'job_start_time':datetime.now(timezone.utc).replace(tzinfo=None),
                              'request_triggered_by':'optimization_sync_lambda','inv_id':device_id}

                    trace_id=self.insert_dict(postgres_conn,history_table,hist_insert_data,True,'trace_id')
                    logging.info(f"Trace Id after insertion is {trace_id}")


                    logging.info(f"1.0 table is {table_10}, 2.0 table is {table_20}, condition is {condition}")

                    full_query = self.construct_condition_query(from_20_query, condition, device_id)
                    logging.info(f"Final constructed query: {full_query}")

                    to_db_name = migration_details_dict['to_database']
                    logging.info(f"to databse is {to_db_name}")
                    to_connection = self.create_connection(db_type, hostname, to_db_name, user, password, port)

                    df_from_20 = self.execute_query(to_connection, full_query)

                    if df_from_20 is None or df_from_20.shape[0] == 0 or df_from_20.empty:
                        logging.info("execute_query returned None.")
                        logging.info(f"{trace_id} execute_query returned None.")
                        return True

                    for col in df_from_20.columns:
                        if pd.api.types.is_datetime64_any_dtype(df_from_20[col]):
                            df_from_20[col] = df_from_20[col].apply(
                                self.convert_timestamp_to_sql_datetime
                            )

                    # Replace NaN values with None and convert boolean values to integers (1/0)
                    df_from_20 = df_from_20.astype(object).mask(df_from_20.isna(), None)
                    #df_from_20.replace({True: 1, False: 0}, inplace=True)
                    df_from_20 = df_from_20.applymap(lambda x: 1 if x is True else (0 if x is False else x))
                    logging.info(f"############# Result DF:::::{df_from_20}")
                    df_from_20=self.modify_uuid_cols(df_from_20)
                    id_column_20 = migration_details_dict.get('primary_id_column')
                    id_column_10 = migration_details_dict.get('time_column_check')
                    db_config = self.get_db_config(migration_details_dict)
                    from_host = db_config["hostname"]
                    from_port = db_config["port"]
                    from_user = db_config["user"]
                    from_pwd = db_config["password"]
                    from_db_type = db_config["from_db_type"]
                    from_database = migration_details_dict["from_database"]
                    from_driver = os.getenv("MSSQL_DB_DRIVER")

                    logging.info("Create a connection to the source database using the retrieved configuration")
                    ssms_conn = self.create_connection(
                        from_db_type,
                        from_host,
                        from_database,
                        from_user,
                        from_pwd,
                        from_port,
                        from_driver,
                    )

                    if df_from_20 is None:
                        logging.info("execute_query returned None.")
                        return True

                    logging.info(f"data fetched successfully {df_from_20.head()}")

                    insert_query_update,psql_values = self.construct_merge_query(
                        df_from_20, table_10, id_column_10
                    )
                    logging.info(f"query constructed is {insert_query_update}")

                    if insert_query_update:
                        try:
                            cursor = ssms_conn.cursor()
                            cursor.execute(insert_query_update)  # Execute the query
                            ssms_conn.commit()  # Commit the transaction
                            logging.info("Records are inserted into MSSQL database successfully")

                        except Exception as e:
                            ssms_conn.rollback()
                            tb = traceback.format_exc()
                            msg=f"Error in {job_name} {e} {tb}"
                            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                            self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                            logging.error(f"An error occurred in inventory sync: {e}")
                    else:
                        logging.info("Insert query is not formed")


        except Exception as e:
            tb = traceback.format_exc()
            msg=f"Error in {job_name} {e} {tb}"
            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
            logging.error(f"An error occurred in inventory sync: {e}")
            logging.info(f"An error occurred in inventory sync: {e}")
    def updated_sms_charges_for_session_id(self, opt_session_id, psql_conn):
        """
        Updates the total SMS charges for a given optimization session in the PostgreSQL database.

        This function retrieves the total SMS charges associated with the provided optimization 
        session ID by aggregating data from the relevant tables (optimization_mobility_device_result 
        or optimization_device_result). If no records exist, it calculates SMS charges manually 
        from mobility/device history and customer rate plan. Finally, it updates the 
        optimization_session table with the computed SMS charge total.

        Args:
            opt_session_id (str): UUID of the optimization session.
            psql_conn (psycopg2 connection object): Active PostgreSQL database connection.

        Returns:
            bool: True if the update was successful, False otherwise.
        """
        try:
            logging.info(f" Starting SMS charges update for session_id: {opt_session_id}")
           



            # Step 1: Fetch service provider and instance details
            sp_id_query = """
                SELECT 
                    ose.service_provider_id,
                    oi.id AS instance_id,
                    ose.billing_period_start_date,
                    ose.billing_period_end_date,
                    oi.optimization_billing_period_id,
                    i.portal_type_id
                FROM optimization_session ose
                JOIN optimization_instance oi ON ose.id = oi.optimization_session_id
                JOIN serviceprovider sp ON sp.id = ose.service_provider_id
                JOIN integration i ON sp.integration_id = i.id
                WHERE ose.session_id = %s;
            """
            with psql_conn.cursor() as cursor:
                cursor.execute(sp_id_query, (opt_session_id,))
                sp_data = cursor.fetchone()

            if not sp_data:
                print(f" No optimization session found for session_id: {opt_session_id}")
                return False
            

            service_provider_id, instance_id, start_date, end_date, billing_period_id, portal_type_id = sp_data
            logging.info(f" Fetched session details: ServiceProviderID={service_provider_id}, InstanceID={instance_id}, StartDate={start_date}, EndDate={end_date}, BillingPeriodID={billing_period_id}, PortalTypeID={portal_type_id}")
            instance_ids_query = """
                SELECT oi.id
                FROM optimization_session ose
                JOIN optimization_instance oi ON ose.id = oi.optimization_session_id
                WHERE ose.session_id = %s;
            """
            with psql_conn.cursor() as cursor:
                cursor.execute(instance_ids_query, (opt_session_id,))
                instance_ids = [row[0] for row in cursor.fetchall()]

            logging.info(f" Found instance_ids for session_id {opt_session_id}: {instance_ids}")

            
            
            up_instance_id_query = """
                    UPDATE optimization_smi_result osr
                    SET instance_id = oq.instance_id
                    FROM optimization_queue oq
                    JOIN optimization_instance oi 
                        ON oi.id = oq.instance_id
                    JOIN optimization_session ose 
                        ON ose.id = oi.optimization_session_id
                    WHERE osr.queue_id = oq.id
                    AND ose.session_id=%s;
                """

            with psql_conn.cursor() as cursor:
                    cursor.execute(up_instance_id_query, (opt_session_id,))
                    psql_conn.commit()

            logging.info(f"Updated optimization_smi_result.instance_id to {instance_id} where matching queue_id exists.")
        

            # Step 2: Calculate total SMS charges for the instance
            if str(portal_type_id) == "2":
                sms_sum_query = """
                    SELECT COALESCE(SUM(omdr.sms_charge_amount), 0) AS sms_charge_total
                    FROM optimization_mobility_device_result omdr
                    JOIN optimization_queue oq ON omdr.queue_id = oq.id
                    JOIN optimization_instance oi ON oq.instance_id = oi.id
                    JOIN optimization_session ose ON ose.id = oi.optimization_session_id
                    WHERE ose.session_id = %s;
                """
            else:
                sms_sum_query = """
                    SELECT COALESCE(SUM(omdr.sms_charge_amount), 0) AS sms_charge_total
                    FROM optimization_device_result omdr
                    JOIN optimization_queue oq ON omdr.queue_id = oq.id
                    JOIN optimization_instance oi ON oq.instance_id = oi.id
                     JOIN optimization_session ose ON ose.id = oi.optimization_session_id
                    WHERE ose.session_id = %s;
                """

            logging.info(f" Executing query to get SMS charges for instance_id={instance_id}")
            with psql_conn.cursor() as cursor:
                cursor.execute(sms_sum_query, (opt_session_id,))
                sms_result = cursor.fetchone()

            sms_charge_total = sms_result[0] if sms_result else 0
            logging.info(f" Initial SMS charges fetched from result tables: {sms_charge_total}")

            # Step 2a: If no SMS charges found, calculate manually
            if sms_charge_total <= 0:
                logging.info(f" No SMS charge records found in result tables for instance_id={instance_id}. Calculating manually.")

                if str(portal_type_id) == "2":
                    sms_cal_query = """
                        SELECT SUM(crp.sms_rate * mdh.ctd_sms_usage) AS total_sms_charge_sum
                        FROM mobility_device_history mdh
                        JOIN optimization_smi osmi ON osmi.amop_device_id = mdh.id
                        JOIN optimization_instance oi ON oi.id = osmi.instance_id
                        JOIN optimization_session os ON os.id = oi.optimization_session_id
                        JOIN customerrateplan crp ON crp.id = mdh.customer_rate_plan_id
                        WHERE os.session_id = %s
                        AND oi.optimization_billing_period_id = mdh.billing_period_id
                        AND os.tenant_id = mdh.tenant_id;
                    """
                else:
                    sms_cal_query = """
                        SELECT SUM(crp.sms_rate * mdh.ctd_sms_usage) AS total_sms_charge_sum
                        FROM device_history mdh
                        JOIN optimization_smi osmi ON osmi.amop_device_id = mdh.id
                        JOIN optimization_instance oi ON oi.id = osmi.instance_id
                        JOIN optimization_session os ON os.id = oi.optimization_session_id
                        JOIN customerrateplan crp ON crp.id = mdh.customer_rate_plan_id
                        WHERE os.session_id = %s
                        AND oi.optimization_billing_period_id = mdh.billing_period_id
                        AND os.tenant_id = mdh.tenant_id;
                    """
                logging.info(f" Manual calculation SMS charge total query  {sms_cal_query}")
                with psql_conn.cursor() as cursor:
                    cursor.execute(sms_cal_query, (opt_session_id,))
                    sms_result = cursor.fetchone()
                    sms_charge_total = sms_result[0] if sms_result else 0
                    logging.info(f" Manual calculation SMS charge total: {sms_charge_total}")

            # Step 3: Update optimization_session table with total SMS charges
            update_query = """
                UPDATE optimization_session
                SET total_sms_charges_20 = %s
                WHERE session_id = %s;
            """
            with psql_conn.cursor() as cursor:
                cursor.execute(update_query, (sms_charge_total, opt_session_id))
                psql_conn.commit()

            logging.info(f" Updated total_sms_charges_20 = {sms_charge_total} for session_id = {opt_session_id}")
            return True

        except Exception as e:
            logging.info(f" Error in updated_sms_charges_for_session_id: {e}")
            psql_conn.rollback()
            return False



    def lambda_sync_jobs_(self, data, comm_group_flag=False):
        # completed_dict={}
        try:
            logging.info(f"######### In lambda sync job data: {data}")
            opt_session_uuid = None
            start_time = time.time()
            
            # sync start time
            
            if data.get("key_name") == "optimization_sync":
                    logging.info(f"Optimization sync started at: {datetime.datetime.now()}")
                    sync_start_time = time.time()
            else:
                    sync_start_time = None            
                        
            
            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            # hostname = os.get"amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"  # "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
            # port = "5432"
            # db_name = "Migration_Test"
            # user = "root"
            # password = "AmopTeam123"
            # db_type = "postgresql"
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            common_utils_db=os.getenv("COMMON_UTILS_DB_NAME")
            comm_postgres_con= self.create_connection(
                db_type, hostname,common_utils_db, user, password, port
            )
            if comm_group_flag:
                data = data.get("data", None)
            bulk_change_id=data.get("bulk_change_id",None)
            key_name_received = data.get("key_name", None)
            tenant_name = data.get('tenant_name',None)
            logging.info(f"tenant_name received {tenant_name}")
            if tenant_name:
                tenant_name=self.function_to_check_sub_tenant_or_parent_name(comm_postgres_con,tenant_name)
            logging.info(f"tenant_name finally gotten after checking subtenant {tenant_name}")
            tenant_id = data.get('tenant_id', None)
            if tenant_name == "":
                tenant_name = None
            if tenant_name is None and tenant_id is not None:
                try:
                    common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                    postgres_conn_common = self.create_connection(
                        db_type, hostname, common_db_name, user, password, port
                    )
                    tenant_name_query = f"select tenant_name from tenant where id={tenant_id}"
                    tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                    tenant_name = tenant_name_df['tenant_name'].iloc[0]
                except Exception as e:
                    logging.error(f"Error in getting tenant name from tenant_id: {e}")
                    tenant_id = None
                    pass
            mode = os.getenv("MODE")
            if tenant_id == 1 and mode=="UAT":
                tenant_name = "Altaworx Test"

            if tenant_name is None and tenant_id is None:
                logging.error(f"{key_name_received}: Tenant name and tenant id is None")
                return {'flag':False,'message':'Tenant Name and Tenant Id is None'}

            if tenant_name == "Altaworx Test":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx_central_beta"
            elif tenant_name == "Altaworx":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx_central_beta"
            else:
                try:
                    common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                    postgres_conn_common = self.create_connection(
                        db_type, hostname, common_db_name, user, password, port
                    )
                    tenant_name_query = f"select db_name from tenant where tenant_name='{tenant_name}'"
                    tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                    db_name = tenant_name_df['db_name'].iloc[0].lower()
                except Exception as e:
                    logging.error(f"Error in getting tenant name from tenant_id: {e}")
                    db_name = tenant_name
                    pass
                tenant_name_lcase = db_name
                tenant_name_ = tenant_name

            if key_name_received and tenant_name:
                key_name = f"{key_name_received}_{tenant_name_lcase.lower()}"
            else:
                key_name = key_name_received
            logging.info(f"Received Key name {key_name_received} and tenant name {tenant_name_lcase.lower()}, Final key formed is {key_name}")

            aws_scheduler=data.get('schedule_flag',None)
            logging.info(f"Schedule flag is {aws_scheduler}")
            from_20_flag=False

            service_provider_id=data.get('service_provider_id', None)
            device_id=data.get('device_id',None)
            mobility_device_id=data.get('mobility_device_id',None)
            json_data = self.load_json()
            telegence_ids = self.get_provider_ids(json_data, tenant_name_, ["Telegence"])
            logging.info(f"### save_data_to_10 telegence_ids is {telegence_ids}")
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            hist_insert_data={'key_name':key_name_received,'job_name':'live-sync','job_start_time':datetime.now(timezone.utc).replace(tzinfo=None),
                              'request_triggered_by':'optimization_sync_lambda'}

            trace_id=self.insert_dict(postgres_conn,history_table,hist_insert_data,True,'trace_id')
            logging.info(f"Trace Id after insertion is {trace_id}")

            if key_name_received == 'm2m_inventory_live_sync_from_20' and (device_id is not None or mobility_device_id is not None) :
                from_20_flag=True
                if service_provider_id and  int(service_provider_id) in telegence_ids:
                    key_name = f"mobility_inventory_live_sync_from_20_{tenant_name_lcase.lower()}"
                else:
                    key_name = f"m2m_inventory_live_sync_from_20_{tenant_name_lcase.lower()}"

            if key_name_received=='m2m_inventory_live_sync_from_20' and from_20_flag is True:
                logging.info(f"inventory sync ")
                logging.info(f"key name formed is {key_name}")
                if device_id:
                    id_to_send=device_id
                else:
                    id_to_send=mobility_device_id
                self.inventory_live_sync(key_name,id_to_send)
                return True

            if key_name_received == "optimization_setting_sync":
                logging.info(f"Optimization Setting Begining {key_name}")
                try:
                    self.optimization_setting_handler(f"optimization_setting_{tenant_name_lcase.lower()}",tenant_id,trace_id=trace_id)
                except Exception as e:
                    logging.info(f"Error in lambda_sync_jobs - optimization_setting_handler {e}")
                    if trace_id:
                        error_msg=f"Error in lambda_sync_jobs - optimization_setting_handler {e}"
                        job_status_msg='Failed'
                        update_hist_table={'error_id_list':None,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_msg,'success':0,'failed':0,'job_status_msg':job_status_msg}
                        self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})
                return True

            if key_name_received == "optimization_sync":
                opt_session_uuid = data.get("session_id")
            else:
                opt_session_uuid = None
            if key_name_received == "rev_service_line_sync":
                service_number = data.get("service_number")
            else:
                # opt_session_uuid=None
                service_number = None

            logging.info(f"Begining Migration for {key_name}--{opt_session_uuid}")
            migration_table = "lambda_sync_jobs"
            job_scheduled_query = f"select migration_names_list from {migration_table} where key_name='{key_name}'"
            rows = self.execute_query(postgres_conn, job_scheduled_query)
            logging.info(f"{key_name}------Data from key name is {rows},{type(rows)}")
            job_names_list = rows["migration_names_list"][0]
            logging.info(
                f"{key_name}--------Job names are {job_names_list},{type(job_names_list)}"
            )
            jobs_status_dict = {"Success": [], "failed": []}
            logging.info(
                f"{key_name}---------Job names are {job_names_list},{type(job_names_list)}"
            )

            try:
                for job in job_names_list:
                    if aws_scheduler is True:
                        try:
                            job_name_dict = {}
                            job_name_dict["job_name"] = job
                            time_elapsed = time.time() - start_time
                            logging.info(
                                f"Time elapsed since start: {time_elapsed:.2f} seconds before starting job: {job}"
                            )
                            logging.info(
                                f"Sending ip is {opt_session_uuid}- {job_name_dict}"
                            )
                            logging.info(f"Job started in lambda_sync_jobs: {job}")
                            job_start_time = time.time()
                            # Create the message body
                            data = {'key_name':key_name,'job_name': job, 'path': "/main_migration_func"}
                            logging.info(f"Sending job to SQS queue: {job}")
                            # Send message to SQS
                            migration_job=self.send_msg_to_opt_sync_queue(data)
                            if migration_job is True:
                                jobs_status_dict['Success'].append(job)
                                logging.info(f"{key_name}----Job is done {job}")
                            else:
                                jobs_status_dict['failed'].append(job)
                                logging.info(f"{key_name}---Errors in job {job}")
                            # Log success for job enqueue
                            jobs_status_dict['Success'].append(job)
                            logging.info(f"{key_name} - Job sent to SQS successfully: {job}")

                        except Exception as e:
                            jobs_status_dict["failed"].append(job)
                            logging.error(
                                f"{key_name} - Failed to send job {job} to SQS: {e}"
                            )
                    else:
                        try:
                            job_name_dict = {}
                            job_name_dict["job_name"] = job
                            time_elapsed = time.time() - start_time
                            logging.info(
                                f"Time elapsed since start: {time_elapsed:.2f} seconds before starting job: {job}"
                            )
                            logging.info(
                                f"Sending ip is {opt_session_uuid}- {job_name_dict}"
                            )
                            logging.info(f"Job started in lambda_sync_jobs: {job}")
                            job_start_time = time.time()

                            migration_job = self.main_migration_func(job, key_name)

                            job_end_time = time.time()
                            job_duration = job_end_time - job_start_time
                            if migration_job is True:
                                jobs_status_dict["Success"].append(job)
                                logging.info(
                                    f"{key_name}----Job is done {job} completed successfully in {job_duration:.2f} seconds"
                                )
                            else:
                                jobs_status_dict["failed"].append(job)
                                logging.info(
                                    f"{opt_session_uuid}----{key_name}---Errors in job {job} failed in {job_duration:.2f} seconds"
                                )
                            # Create the message body
                            # data = {'job_name': job, 'path': "/main_migration_func"}
                            # logging.info(f"Sending job to SQS queue: {job}")

                            # Send message to SQS
                            # migration_job=self.send_msg_to_opt_sync_queue(data)
                            # if migration_job is True:
                            #     jobs_status_dict['Success'].append(job)
                            #     logging.info(f"{key_name}----Job is done {job}")
                            # else:
                            #     jobs_status_dict['failed'].append(job)
                            #     logging.info(f"{key_name}---Errors in job {job}")
                            # Log success for job enqueue
                            # jobs_status_dict['Success'].append(job)
                            # logging.info(f"{key_name} - Job sent to SQS successfully: {job}")
                        except Exception as e:
                            # Log failure for job enqueue
                            jobs_status_dict["failed"].append(job)
                            logging.error(
                                f"{key_name} - Failed to send job {job} to SQS: {e}"
                            )

            #     for job in job_names_list:
            #         data={}
            #         data['job_name']=job
            #         migration_job=self.main_migration_func(job)
            #         if migration_job is True:
            #             jobs_status_dict['Success'].append(job)
            #             logging.info(f"{key_name}----Job is done {job}")
            #         else:
            #             jobs_status_dict['failed'].append(job)
            #             logging.info(f"{key_name}---Errors in job {job}")
            except Exception as e:
                logging.error(
                    f"Error in lamda_sync_jobs_ {key_name} in job {job}-- {e}"
                )

            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            # db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")

            # hostname = "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"  # "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
            # port = "5432"
            # # db_name = "altaworx_test"
            # user = "root"
            # password = "AmopTeam123"
            # db_type = "postgresql"

            try:

                if tenant_name:
                    common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                    tenant_name_q=f"select db_name from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                    logging.info(f"Tenant name query is {tenant_name_q}")
                    tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                    logging.info(f"Tenant DF is {tenant_name_res}")
                    if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                        tenant_name_ = tenant_name_res['db_name'][0]
                        db_name=tenant_name_
                        logging.info(f"Tenant name is {tenant_name_}")
                    else:
                        raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")

                else:
                    # db_name='altaworx_test'
                    logging.error(f"{opt_session_uuid} Tenant name is not provided")
            except Exception as e:
                logging.error(f"An error occurred loading tenant {opt_session_uuid} : {str(e)}")
                # db_name='altaworx_test'

            postgres_conn_altaworx = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            if service_number:
                logging.info(f"{key_name} -------- service_number is {service_number}")
                update_dict = {"rev_service_line_status": "completed"}
                service_number_update = self.update_table(
                    postgres_conn_altaworx,
                    "rev_service",
                    update_dict,
                    {"number": service_number},
                )

            if (
                opt_session_uuid
                and comm_group_flag == False
                and key_name_received == "optimization_sync"
            ):
                logging.info(f"{key_name}-----opt session id {opt_session_uuid}")
                opt_run_end_time = datetime.now()
                # opt_dict={'progress':'75'}
                opt_dict = {
                    "progress": "75",
                    "optimization_run_end_time": opt_run_end_time,
                }
                logging.info(
                    f"############### {key_name} Updating optimization_session where session_id is {opt_session_uuid}"
                )
                opt_update = self.update_table(
                    postgres_conn_altaworx,
                    "optimization_session",
                    opt_dict,
                    {"session_id": opt_session_uuid},
                )
                data_ = {
                    "session_id": opt_session_uuid,
                    "path": "/optimization_sync_comm_group",
                    "tenant_name":tenant_name,
                    "sync_start_time": sync_start_time
                }
                logging.info(f"Input data {opt_session_uuid} is {data_}")
                # oo=self.send_msg_to_opt_sync_queue(data_)
                # logging.info("oo----------comm group-------",oo)
                # oo=self.optimization_sync_comm_group(data_)
                try:
                    logging.info(f"{opt_session_uuid} Calling SQS with {data_}")
                    oo = self.send_msg_to_opt_sync_queue(data_)
                    logging.info("SQS Message sent successfully for Comm_group")
                except Exception as e:
                    logging.error(f"Message sending failed for comm_group: {e}")

            elif (
                opt_session_uuid
                and comm_group_flag is True
                and key_name_received == "optimization_sync"
            ):
                logging.info(
                    f"{opt_session_uuid}: {key_name} Sync is Completed, Setting Progress to 100 AND Starting SYnc of tables"
                )
                # job = 'OptimizationSync'
                # migration_job=self.main_migration_func(job)
                # data = {"key_name": "optimization_sync","session_id": opt_session_uuid}
                # try:
                #     sync_all_opt_tables = self.lambda_sync_jobs_(data)
                #     logging.info(f"{opt_session_uuid}:Sync of all optimization tables is completed")
                # except Exception as e:
                #     logging.exception(f"{opt_session_uuid}:Error in sync of all optimization tables, {e}")
                opt_run_end_time = datetime.now()
                logging.info(
                    f"{opt_session_uuid}:{job} Sync is Completed, Setting Progress to 100"
                )
                opt_dict = {
                    "progress": "100",
                    "optimization_run_end_time": opt_run_end_time,
                }

                try:
                    logging.info(f"Refreshing materialized view mv_optimization_session_charges {opt_session_uuid} before updating progress")
                    refresh_query = "REFRESH MATERIALIZED VIEW mv_optimization_session_charges;"
                    tenant_cursor=postgres_conn_altaworx.cursor()
                    tenant_cursor.execute("SET statement_timeout = 60000;")  # 60 seconds timeout
                    tenant_cursor.execute(refresh_query)
                    # #commit
                    postgres_conn_altaworx.commit()
                    tenant_cursor.close()
                    logging.info(f"Materialized view mv_optimization_session_charges refreshed successfully {opt_session_uuid}")
                except Exception as e:
                    postgres_conn_altaworx.rollback()  # ❗ rollback changes on error
                    logging.error(f"Error refreshing materialized view mv_optimization_session_charges: {e} {opt_session_uuid}")
                # completed_dict[opt_session_uuid]='Complete'

                opt_update = self.update_table(
                    postgres_conn_altaworx,
                    "optimization_session",
                    opt_dict,
                    {"session_id": opt_session_uuid},
                )
                self.updated_sms_charges_for_session_id(opt_session_uuid, postgres_conn_altaworx)
                
            # elif completed_dict is None:
            #     re_call=self.lambda_sync_jobs_(data)
            if bulk_change_id:
                update_dict = {"Progress": "Sync completed"}
                bulk_change_update = self.update_table(
                    postgres_conn_altaworx,
                    "sim_management_bulk_change",
                    update_dict,
                    {"id":bulk_change_id },
                )

            last_migrated_time = datetime.now()
            update_dict = {
                "sync_status": "Completed",
                "sync_job_status": json.dumps(jobs_status_dict),
                "last_migrated_time": last_migrated_time,
            }
            # update_dict=json.dumps(update_dict)
            logging.info(f"{opt_session_uuid} : sync update dict {update_dict}")
            update_sync_status = self.update_table(
                postgres_conn, migration_table, update_dict, {"key_name": key_name}
            )

            ##commenting for ticket 2114- new implementation if sync process
            # if not comm_group_flag:
            #     logging.info(f"Calling Lambda for error processes")
            #     comm_groups_sync=self.optimization_sync_comm_group(data)

        except Exception as e:
            logging.error(
                f"{opt_session_uuid}:Error in lamda_sync_jobs_ {key_name} {e}"
            )
            return job_names_list


    def fetch_run_status_ids_(self, from_connection, from_database, session_id):
        query = (
            f"SELECT RunStatusId FROM {from_database}.dbo.vwOptimizationInstance "
            f"WHERE SessionId='{session_id}'"
        )
        result = self.execute_query(from_connection, query)
        logging.info(f"Query Result: {result}")
        return set(result["RunStatusId"])

    def fetch_run_status_ids(
        self, from_connection, from_database, session_id, error_ids
    ):
        try:
            scheduler = MigrationScheduler()
            error_ids_list = ", ".join(map(str, error_ids))
            query = (
                f"SELECT RunStatusId FROM {from_database}.dbo.vwOptimizationInstance "
                f"WHERE SessionId='{session_id}'AND RunStatusId IN ({error_ids_list})"
            )
            result = scheduler.execute_query(from_connection, query)
            logging.info(f"Returning RunStatusIds {result}")
            return result
        except Exception as e:
            logging.error(f"Error in fetching run status ids {e}")
            return None

    def optimization_sync_comm_group(self, data):
        try:

            logging.info(f"Starting Optimiation Error Updates Sync {data}")
            logging.info("runinng using sqs  !!!!!!!!!!!!!")
            load_dotenv()

            last_hit_time = None
            sync_start_time = data.get("sync_start_time", None)
            if sync_start_time:
                logging.info(f"Optimization sync start time received: {datetime.datetime.fromtimestamp(sync_start_time)}")


            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")

            session_id = data.get("session_id")
            tenant_name=data.get('tenant_name',None)

            session_id = data.get("session_id")
            tenant_name=data.get('tenant_name',None)
            check_df_initial=data.get("check_df_initial",None)

            if isinstance(check_df_initial, list):
                check_df_initial = pd.DataFrame(check_df_initial)
            elif isinstance(check_df_initial, dict):
                check_df_initial = pd.DataFrame([check_df_initial])
            elif check_df_initial is None:
                check_df_initial = pd.DataFrame()
            else:
                print(f"Unexpected type for check_df_initial: {type(check_df_initial)}")
                logging.error(f"Unexpected type for check_df_initial: {type(check_df_initial)}")

            last_change_time=data.get("last_change_time",None)
            logging.info(f"[{session_id}] Initial check DataFrame: {check_df_initial}, Last change time: {last_change_time}")
            
            if tenant_name == 'Altaworx Test':
                tenant_name_ = 'altaworx'
                tenant_name_lcase = "altaworx"
                tenant_hostname=os.getenv("PSQL_DB_HOST")
                tenant_db_name='altaworx_central_beta'

            elif tenant_name == "Altaworx":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
                tenant_hostname=os.getenv("PSQL_DB_HOST")
                tenant_db_name='altaworx_central_beta'

            else:
                try:
                    common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                    postgres_conn_common = self.create_connection(
                        db_type, hostname, common_db_name, user, password, port
                    )
                    tenant_name_query = f"select db_name,db_config from tenant where tenant_name='{tenant_name}'"
                    tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                    logging.info(f"Tenant DF is {tenant_name_df.to_dict(orient='records')}")
                    db_name = tenant_name_df['db_name'].iloc[0].lower()
                    db_config=tenant_name_df['db_config'][0]
                    logging.info(f"db_config in if block is {db_config}, type {type(db_config)}")
                    tenant_db_name=db_name
                    if isinstance(db_config, str):
                        db_config = json.loads(db_config)
                        logging.info(f"db_config in if block is {db_config}")
                    tenant_hostname = db_config.get("hostname",None)

                    if tenant_hostname is None:
                        logging.info(f"Tenant hostname is not provided for tenant {tenant_name}")
                        raise ValueError(f"Tenant hostname is not provided for tenant {tenant_name}")
                                        
                except Exception as e:
                    logging.info(f"Error in getting tenant name from tenant_id: {e}")
                    db_name = tenant_name
                    tenant_name_lcase = db_name
                    tenant_name_ = tenant_name
            tenant_name_lcase = db_name
            tenant_name_ = tenant_name
            tenant_hostname=db_config['hostname']
            # if tenant_name == 'Altaworx Test':
            #     tenant_name_ = 'altaworx_beta'
            #     tenant_name_lcase = "altaworx_beta"
            # elif tenant_name == "Altaworx":
            #     tenant_name_ = "Altaworx_beta"
            #     tenant_name_lcase = "altaworx_beta"
            logging.info(f"{session_id} Tenant hostname is {tenant_hostname} {tenant_name_lcase}")

            # fetch the details of database as hosts will be different for each tenant
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            postgres_conn = self.create_connection(
                        db_type, hostname, db_name, user, password, port
                    )
            postgres_conn_tenant = self.create_connection(
                        db_type, tenant_hostname,tenant_db_name, user, password, port
                    )
            migrations_table = os.getenv('MIGRATION_TABLE')
            db_config_details = f"select from_db_config from {migrations_table} where migration_name='optimization_commgroup_commplan_{tenant_name_lcase.lower()}'"
            logging.info(f"db_config_details is {db_config_details}")
            db_config_details = self.execute_query(postgres_conn,db_config_details)
            
            logging.info(f"db_config_details is {db_config_details.to_dict(orient='records')}")
            logging.info(f"db_config_details is {db_config_details['from_db_config'].tolist()}")            
            db_config_details = db_config_details["from_db_config"].tolist()[0]

            from_host = db_config_details["hostname"]
            from_port = db_config_details["port"]
            from_user = db_config_details["user"]
            from_pwd = db_config_details["password"]


            # from_host = os.getenv("MSSQL_DB_HOST")
            # from_port = os.getenv("MSSQL_DB_PORT")
            # from_user = os.getenv("MSSQL_DB_USER")
            # from_pwd = os.getenv("MSSQL_DB_PASSWORD")
            from_db_type = os.getenv("MSSQL_DB_TYPE")
            from_database = os.getenv("MSSQL_DB_NAME")
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            error_ids = {1, 2, 3, 4, 5}
            return_dict = {}
            success_or_failure_ids={6,7}
            #empty dataframe to check the instances per each run status id
            # if not check_df_initial: 
            #     check_df_initial=pd.DataFrame()

            if check_df_initial is None or check_df_initial.empty:
                check_df_initial = pd.DataFrame()

            total_devices_count=0
            #before fetching the status ids , initially get the instances count for each runstatusid, and total sum of devices
            device_sum_query=f"select sum(devicecount) as device_count from vwoptimizationinstance where SessionId ='{session_id}' "
            logging.info(f"devicec_sum_query is {device_sum_query}")
            device_sum_df=self.execute_query(from_connection,device_sum_query)
            device_sum=device_sum_df.iloc[0]['device_count']
            if device_sum is None or device_sum == 0:
                logging.info(f"[{session_id}] Device count still 0. Optimization still running… waiting.")
                device_sum = 3 if device_sum is None else device_sum
            total_devices_count+=device_sum
            logging.info(f"total_device_count was {total_devices_count}")

            #total wait time for each devices - (2 min for each device)                        
            if total_devices_count < 10:
                total_wait_time_seconds = 1200
            else:
                total_wait_time_seconds= total_devices_count * 2 * 60               
            logging.info(f"Total wait time: {total_wait_time_seconds} seconds")
            if not last_change_time:
                last_change_time=time.time()
            loop_start_time = time.time()  # record loop start time
            
            for attempt in range(5):
                logging.info(
                    f"Attempt {attempt}: Executing query to fetch run status id's"
                )
                if attempt == 3:
                    logging.info(f"Attempt is {attempt} breaking.....")
                    logging.info(f"Restarting session {session_id} with SQS")

                    if isinstance(check_df_initial, pd.DataFrame):
                        check_df_serialized = check_df_initial.to_dict(orient="records")
                    else:
                        check_df_serialized = check_df_initial    

                    data_ = {
                        "session_id": session_id,
                        "path": "/optimization_sync_comm_group",
                        "timestamp": str(datetime.utcnow()),
                        "tenant_name": tenant_name_,
                        "check_df_initial":check_df_serialized,
                        "last_change_time":last_change_time
                    }
                    try:
                        logging.info("SQS Message sent successfully for Comm_group")
                        oo = self.send_msg_to_opt_sync_queue(data_)
                        logging.info("SQS Message sent successfully for Comm_group")
                    except Exception as e:
                        logging.error(f"Message sending failed for comm_group: {e}")
                    break
                else:
                    logging.info(f"Attempt is {attempt} continuing.....")
                
                logging.info(
                    f"Comm Group Sync {session_id} Attempt {attempt}: Executing query to fetch run status id's"
                )
                # Calculate elapsed time
                # Calculate elapsed time since last change
                elapsed_since_change = time.time() - last_change_time
                logging.info(f"[{session_id}] Elapsed time since last change: {elapsed_since_change / 60:.2f} minutes")

                # Check if no change for total_wait_time_seconds
                if elapsed_since_change >= total_wait_time_seconds:
                    logging.info(f"[{session_id}]  No change for {elapsed_since_change / 60:.2f} mins "
                        f"(>{total_wait_time_seconds / 60:.2f} mins). Exiting loop.")
                    update_dict={
                        "progress_msg": "Optimization in 1.0 may be stuck; no progress detected."
                    }
                    condition_dict={"session_id":session_id}
                    self.update_table(
                    postgres_conn_tenant,
                    "optimization_session",
                    update_dict,
                   condition_dict,
                )  
                    break

                #now fetching the groupby by instances
                runstatus_query=f"""select RunStatusId ,count(*) as instance_id_count
                                    from vwoptimizationinstance 
                                    where SessionId ='{session_id}'
                                    group by runstatusid"""
                run_status_df=self.execute_query(from_connection,runstatus_query)
                
                #if intial check df is empty then assign it to check df , if not then check if check df and this matches or not
                if check_df_initial.empty:
                    check_df_initial=run_status_df
                else:
                    # Compare current vs previous DataFrame
                    if check_df_initial.empty:
                        check_df_initial = run_status_df.copy()
                        logging.info(f"[{session_id}] Initial snapshot saved.")
                    else:
                        if run_status_df.equals(check_df_initial):
                            logging.info(f"[{session_id}]  No change detected this cycle.")
                            # do not reset timer here
                        else:
                            logging.info(f"[{session_id}]  Change detected in RunStatus distribution.")
                            logging.info(f"[{session_id}] Previous:{check_df_initial}")
                            logging.info(f"[{session_id}] Current:{run_status_df}")
                            # Update baseline + reset the change timer
                            check_df_initial = run_status_df.copy()
                            last_change_time = time.time()
                            logging.info(f"[{session_id}]  Change detected, timer reset.")
                # logging.info(f"Attempt {attempt}: Executing query to fetch run status id's")
                
                
                if last_hit_time:
                    diff = int(time.time() - last_hit_time)
                    logging.info(f"Last hit was {diff} seconds" if diff < 60 else f"Last hit was {diff//60} minutes")
                    last_hist_msg=f"{diff} seconds" if diff < 60 else f"{diff//60} minutes"
                    update_dict={
                        "last_update": last_hist_msg
                    }
                    condition_dict={"session_id":session_id}
                    self.update_table(
                    postgres_conn_tenant,
                    "optimization_session",
                    update_dict,
                   condition_dict
                )

                last_hit_time = time.time()                 
                
                error_ids_df = self.fetch_run_status_ids(
                    from_connection, from_database, session_id, error_ids
                )
                logging.info(
                    f"Attempt {attempt} error ids from 1.0 for session {session_id} -- {error_ids_df.to_dict(orient='records')}"
                )
                if error_ids_df is None:
                    logging.info(
                        f"Comm Group Sync {session_id} :: No such session Id found in 1.0 check the logs {session_id}"
                    )
                    return_dict = {
                        "flag": False,
                        "message": "No such session Id found in 1.0 check the logs",
                    }

                # elif error_ids_df.empty and attempt < 3:
                #     logging.info(
                #         f"Attempt {attempt} Comm Group Sync {session_id} No records with Errors or Comm Group Setup waiting for 5 min....."
                #     )
                #     return_dict = {
                #         "flag": False,
                #         "message": "No records with Errors or Comm Group Setup waiting for 1 min",
                #     }
                #     time.sleep(60)

                elif not error_ids_df.empty:
                    logging.info(
                        f"Attempt {attempt} Comm Group Sync {session_id} Found records with Errors or Comm Group Setup waiting for 5 min....."
                    )
                    return_dict = {
                        "flag": False,
                        "message": "Found records with Errors or Comm Group Setup waiting for 5 min",
                    }
                    time.sleep(3 * 60)
                else:
                    # <<=== CHANGE STARTS HERE ===>>
                    logging.info(
                        f"Comm Group Sync {session_id} :: No records found, sleeping 2 minutes before re-checking run status IDs"
                    )
                    time.sleep(2 * 60)
                   
                    # logging.info TIME SINCE LAST HIT BEFORE NEXT fetch
                    if last_hit_time:
                        diff = int(time.time() - last_hit_time)
                        logging.info(f"Last hit was {diff} seconds ago" if diff < 60 else f"Last hit was {diff//60} minutes ago")

                    last_hit_time = time.time()                
                                        
                    error_ids_df_retry = self.fetch_run_status_ids(
                        from_connection, from_database, session_id, error_ids
                    )

                    if not error_ids_df_retry.empty:
                        logging.info(
                            f"Comm Group Sync {session_id} :: Found records with Errors after 2 minutes, following wait & retry process"
                        )
                        return_dict = {
                            "flag": False,
                            "message": "Found records with Errors or Comm Group Setup after 2 min sleep, waiting for 3 min",
                        }
                        time.sleep(3 * 60)
                        continue
                    else:
                        logging.info(
                            f"Comm Group Sync {session_id} :: Still no records after 2 minutes, proceeding with sync"
                        )
                    # <<=== CHANGE ENDS HERE ===>>
                    for attempts in range(3):
                        
                        if last_hit_time:
                            diff = int(time.time() - last_hit_time)
                            logging.info(f"Last hit was {diff} seconds ago" if diff < 60 else f"Last hit was {diff//60} minutes ago")

                        last_hit_time = time.time() 
                                                
                        error_ids_df_sub = self.fetch_run_status_ids(
                        from_connection, from_database, session_id, success_or_failure_ids
                        )
                        if not error_ids_df_sub.empty:
                            logging.info(
                                f"Attempt {attempts} Comm Group Sync {session_id} found Success or Failure records, so begining the sync "
                            )
                            break
                        else:
                            logging.info(
                                f"Attempt {attempts} Comm Group Sync {session_id} Success or Failure records and Error records  not found, so begining the sync"
                            )
                            time.sleep(60)
                    logging.info(
                        f"@@@@ Comm Group Sync {session_id} Attempt {attempt}: Comm Group Setup records not found, so begining the sync"
                    )
                    device_sum_df=self.execute_query(from_connection,device_sum_query)
                    device_sum=device_sum_df.iloc[0]['device_count']
                    if device_sum is None or device_sum == 0:
                        logging.info(f"[{session_id}] Device count still 0. Optimization still running… waiting.")
                        logging.info(f"[{session_id}] Attempt {attempts + 1}: No changes detected after all retries. Marking optimization as possibly stuck.")
                        update_dict = {
                            "progress_msg": "Optimization in 1.0 may be stuck; Device count is still zero in 1.0"
                        }
                        condition_dict = {
                            "session_id": session_id
                        }

                        logging.info(f"[{session_id}] Updating optimization_session table with status message...")
                        self.update_table(
                            postgres_conn_tenant,
                            "optimization_session",
                            update_dict,
                            condition_dict,
                        )

                        logging.info(f"[{session_id}] Update completed: {update_dict}")
                    # Modified date is not being updated in 1.0 OptimizationInstance table, to handle it updating the last id for each session
                    last_instance_id = f"""SELECT TOP 1 Id FROM {from_database}.dbo.vwOptimizationInstance WHERE SessionId='{session_id}' ORDER BY Id ASC"""
                    last_instance_id_result = self.execute_query(
                        from_connection, last_instance_id
                    )
                    last_instance_id_ = last_instance_id_result["Id"].tolist()[0]
                    last_instance_id = int(last_instance_id_) - 1
                    # logging.info(f"Last Instance Id is {last_instance_id}")
                    logging.info(f"{session_id} Last Instance Id is {last_instance_id}")
                    # hostname = os.getenv("PSQL_DB_HOST")
                    # port = os.getenv("PSQL_DB_PORT")
                    # db_name = os.getenv("PSQL_DB_NAME")
                    # user = os.getenv("PSQL_DB_USER")
                    # password = os.getenv("PSQL_DB_PASSWORD")
                    # db_type = os.getenv("PSQL_DB_TYPE")

                    # hostname = os.getenv("")#"amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"  # "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
                    # port = "5432"
                    # db_name = "Migration_Test"
                    # db_main = "altaworx_test"
                    # user = "root"
                    # password = "AmopTeam123"
                    # db_type = "postgresql"

                    try:

                        if tenant_name:
                            common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                            tenant_name_q=f"select db_name from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                            logging.info(f"Tenant name query is {tenant_name_q}")
                            tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                            logging.info(f"Tenant DF is {tenant_name_res}")
                            if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                                tenant_name_ = tenant_name_res['db_name'][0]
                                db_main=tenant_name_
                                logging.info(f"Tenant name is {tenant_name}")
                            else:
                                raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")


                        else:
                            # db_main='altaworx_test'
                            logging.error("Tenant name is not provided")
                    except Exception as e:
                        logging.error(f"An error occurred loading tenant: {str(e)}")
                        # db_main='altaworx_test'

                    # postgres_conn = self.create_connection(
                    #     db_type, hostname, db_name, user, password, port
                    # )
                    last_id = f"{[last_instance_id]}"
                    logging.info(f"Last Instance Id is {last_id}")
                    update_dict = {"last_id": last_id}
                    load_dotenv()
                    # migrations_table=os.getenv('MIGRATION_TABLE')
                    uu = self.update_table(
                        postgres_conn,
                        migrations_table,
                        update_dict,
                        {"migration_name": f"optimization_instance_{tenant_name_lcase.lower()}"}
                    )

                    data_opt = {
                        "data": {
                            "key_name": "optimization_sync",
                            "session_id": session_id,
                            "tenant_name":tenant_name,
                            "opt_run_time":sync_start_time
                        }
                    }
                    status_flag = True
                    logging.info(f"Calling final Sync for Comm Group {session_id}")
                    logging.info(
                        f"data for Comm group syn is {data_opt}, status flag is {status_flag}"
                    )
                    try:
                        logging.info(f"[START] Optimization Queue sync initiated for session_id: {session_id}")

                        api_url = os.environ.get("SERVICE_LINE_API_URL", "")
                        if not api_url:
                            logging.warning(f"[CONFIG] SERVICE_LINE_API_URL not set in environment variables for session_id: {session_id}")

                        api_payload = {
                            "data": {
                                "path": "/lambda_sync_jobs_",
                                "key_name": "opt_queue_sync",
                                "tenant_name": tenant_name
                            }
                        }

                        logging.debug(f"[REQUEST] Sending POST to {api_url} with payload: {api_payload} for session_id: {session_id}")
                        response = requests.post(api_url, json=api_payload)

                        if response.status_code in (200, 504):
                            current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            logging.info(f"[SUCCESS] API call succeeded for Optimization Queue sync at {current_timestamp} for session_id: {session_id}")
                            inside_ver_flag = True
                        else:
                            logging.error(f"[FAILURE] API call failed with status code {response.status_code} for session_id: {session_id}")
                    except Exception as e:
                        logging.exception(f"[EXCEPTION] Error during Optimization Queue sync API call for session_id: {session_id}: {str(e)}")

                    opt_sync = self.lambda_sync_jobs_(data_opt, True)
                    return_dict = {
                        "flag": True,
                        "message": "Optimization Sync Successfull",
                    }
                    break

            logging.info("Attempts Completed,Retrying again")

            # data_opt={"data": {"key_name": "optimization_sync", "session_id": session_id}}
            # opt_sync=self.lambda_sync_jobs_(data_opt,True)
            # status_flag=True
        except Exception as e:
            logging.error(
                f"{session_id} Error in running optimization sync in case of comm group errors {e}"
            )
            return {"flag": False, "message": {e}}
        
        
        finally:
            # ---- TOTAL SYNC TIME ----
            if data.get("sync_start_time"):
                sync_start_time = data["sync_start_time"]
                sync_end_time = time.time()
                total_sync_seconds = sync_end_time - sync_start_time

                # Convert into readable format
                readable_total_time = self.format_time_readable(total_sync_seconds)

                logging.info(f"Total time taken for full optimization sync: {readable_total_time}")

                # Store into optimization_session table
                try:
                    update_dict = {"opt_run_time": readable_total_time}

                    self.update_table(
                        postgres_conn_tenant,
                        "optimization_session",
                        update_dict,
                        {"session_id": session_id}
                    )

                    logging.info(f"Updated opt_run_time = '{readable_total_time}' for session_id = {session_id}")

                except Exception as e:
                    logging.info(f"Error updating opt_run_time: {e}")

            else:
                logging.info("sync_start_time not found in data, cannot calculate total time.")            

            
                
                
            # FINAL last hit log
            
            if last_hit_time:
                diff = int(time.time() - last_hit_time)

                if diff < 60:
                    last_update_text = f"{diff} seconds"
                else:
                    last_update_text = f"{diff // 60} minutes"

                    logging.info(f"Last hit was {last_update_text}")
            else:
                last_update_text = None
                
            if last_update_text:
                try:
                    update_dict = {"last_update": last_update_text}

                    self.update_table(
                        postgres_conn_tenant,
                        "optimization_session",
                        update_dict,
                        {"session_id": session_id}
                    )
                    logging.info(f"Updated optimization_session.last_update with '{last_update_text}'")

                except Exception as e:
                    logging.info(f"Failed to update last_update in optimization_session: {e}")
        
        return return_dict

    def format_time_readable(self, seconds):
        seconds = int(seconds)
        minutes = seconds // 60
        hours = minutes // 60
        minutes = minutes % 60

        if hours > 0:
            if minutes > 0:
                return f"{hours} hours {minutes} minutes"
            else:
                return f"{hours} hours"
        else:
            return f"{minutes} minutes"
        
        
    '''def optimization_status_syncs(self):
        try:
            load_dotenv()
            logging.info(f"Begining Migration for statuses")
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            # hostname = "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"  # "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
            # port = "5432"
            # db_name = "Migration_Test"
            # db_main = "altaworx_test"
            # user = "root"
            # password = "AmopTeam123"
            # db_type = "postgresql"
            try:
                postgres_conn_altaworx = self.create_connection(
                    db_type, hostname, db_main, user, password, port
                )
                get_pending_session_ids = f"select session_id from optimization_session where progress<>'100' order by optimization_run_start_date asc nulls last"
                get_pending_session_id_result = self.execute_query(
                    postgres_conn_altaworx, get_pending_session_ids
                )
            except Exception as e:
                pending_session_ids = []
            if (
                get_pending_session_id_result is not None
                and not get_pending_session_id_result.empty
            ):
                pending_session_ids = get_pending_session_id_result[
                    "session_id"
                ].tolist()
            logging.info(f"result is {pending_session_ids}")
            result_dict = {}
            for session_id in pending_session_ids:
                logging.info(f"Session id is {session_id}")
                data = {"key_name": "optimization_sync", "session_id": session_id}
                logging.info(f"Session id is {session_id} is starting, data is {data}")
                try:
                    result = self.optimization_sync_comm_group(data)
                    if result["flag"]:
                        result_dict[session_id] = "Success"
                    else:
                        result_dict[session_id] = f"Failed-{result['message']}"

                except Exception as e:
                    logging.error(
                        f"Error in optimization_sync_comm_group for session_id {session_id}: {e}"
                    )
                    result_dict[session_id] = f"Failed: {str(e)}"

                opt_dict = {"optimization_status_syncs": result_dict[session_id]}
                logging.info(
                    f"############### Updating optimization_session where session_id is {session_id}"
                )
                opt_update = self.update_table(
                    postgres_conn_altaworx,
                    "optimization_session",
                    opt_dict,
                    {"session_id": session_id},
                )

            logging.info(f"Session id is {session_id} is done")
            logging.info(f"Result dict is {result_dict}")

        except Exception as e:
            logging.error(f"Error in optimization_status_syncs {e}")
            return {"flag": False, "message": {e}}
        return {"flag": True, "message": result_dict}'''

    def get_processed_count(
        self, from_connection, check_view, opt_session_id, instance_ids_tuple,union_flag
    ):
        try:
            if union_flag:
                processed_count=0
                not_processed_count=0
                if len(instance_ids_tuple)==1:
                    instance_ids_tuple=str(instance_ids_tuple).replace(",","")
                processed_count_query=f"""SELECT SUM(cnt) AS total_count
                                        FROM (
                                                SELECT COUNT(*) as cnt FROM AltaworxCentral_Test.dbo.vwOptimizationDeviceResult_CustomerChargeQueue
                                                WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=1 and OptimizationInstanceId in {instance_ids_tuple}
                                                union all
                                                SELECT COUNT(*) FROM AltaworxCentral_Test.dbo.vwOptimizationMobilityDeviceResult_CustomerChargeQueue
                                                WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=1 and OptimizationInstanceId in {instance_ids_tuple}
                                            ) AS combined_counts
                                            """
                processed_count_result=self.execute_query(from_connection,processed_count_query)

                logging.info(f"Processed Count Query {processed_count_query}")
                logging.info(f"Processed Count Result {processed_count_result}")
                if processed_count_result.empty:
                    processed_count=0
                else:
                    processed_count=processed_count_result['total_count'].iloc[0]

                logging.info(f"Processed Count {processed_count}")
                not_processed_count_query=f"""SELECT SUM(cnt) AS total_count
                                            FROM (
                                                SELECT COUNT(*) as cnt FROM AltaworxCentral_Test.dbo.vwOptimizationDeviceResult_CustomerChargeQueue
                                                WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=0 and OptimizationInstanceId in {instance_ids_tuple}
                                                union all
                                                SELECT COUNT(*) as mobility_count FROM AltaworxCentral_Test.dbo.vwOptimizationMobilityDeviceResult_CustomerChargeQueue
                                                WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=0 and OptimizationInstanceId in {instance_ids_tuple}
                                            ) AS combined_counts"""
                not_processed_count_result=self.execute_query(from_connection,not_processed_count_query)
                logging.info(f"Not Processed Count Query {not_processed_count_query}")
                logging.info(f"Not Processed Count Result {not_processed_count_result}")
                if not_processed_count_result.empty:
                        not_processed_count=0
                else:
                    not_processed_count=not_processed_count_result['total_count'].iloc[0]
                logging.info(f"Not Processed Count {not_processed_count}")
                return processed_count,not_processed_count
            else:
                processed_count = 0
                not_processed_count = 0
                if len(instance_ids_tuple) == 1:
                    instance_ids_tuple = str(instance_ids_tuple).replace(",", "")
                processed_count_query = f"SELECT COUNT(*) FROM {onepoint_o_database}.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=1 and OptimizationInstanceId in {instance_ids_tuple}"
                # processed_count_query=f"SELECT COUNT(*) FROM AltaworxCentral_Test.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=1"
                processed_count_result = self.execute_query(
                    from_connection, processed_count_query
                )
                logging.info(f"Processed Count Query {processed_count_query}")
                logging.info(f"Processed Count Result {processed_count_result}")
                if processed_count_result.empty:
                    processed_count = 0
                else:
                    processed_count = processed_count_result[""].iloc[0]
                logging.info(f"Processed Count {processed_count}")

                # not_processed_count_query=f"SELECT COUNT(*) FROM AltaworxCentral_Test.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=0"
                not_processed_count_query = f"SELECT COUNT(*) FROM {onepoint_o_database}.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=0 and OptimizationInstanceId in {instance_ids_tuple}"
                not_processed_count_result = self.execute_query(
                    from_connection, not_processed_count_query
                )
                logging.info(f"Not Processed Count Query {not_processed_count_query}")
                logging.info(f"Not Processed Count Result {not_processed_count_result}")
                if not_processed_count_result.empty:
                    not_processed_count = 0
                else:
                    not_processed_count = not_processed_count_result[""].iloc[0]
                logging.info(f"Not Processed Count {not_processed_count}")
                return processed_count, not_processed_count
        except Exception as e:
            logging.error(f"Error in get_processed_count {e}")
            return {"flag": False, "message": {e}}


    def load_json(self):
        """
        Loads a JSON file and returns the data.

        :param file_path: Absolute path to the JSON file.
        :return: Parsed JSON data as a dictionary, or None if an error occurs.

        """
        # Define the JSON file path
        FILE_PATH = "tenant_based_serviceproviders.json"
        file_path=FILE_PATH
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return json.load(file)
        except FileNotFoundError:
            logging.warning(f"Error: JSON file not found at {file_path}")
        except json.JSONDecodeError:
            logging.warning(f"Error: Invalid JSON format in {file_path}")
        except Exception as e:
            logging.exception(f"Unexpected error while reading JSON: {e}")

        return {}  # Return None if an error occurs


    def get_provider_ids(self,json_data, tenant_name, provider_names):
        """Fetches only the IDs of specified providers for a given tenant."""
        return [
            details["id"]
            for provider_name, details in json_data.get(tenant_name, {}).items()
            if provider_name in provider_names
        ]

    def push_charges_sync(self, data):
        try:
            load_dotenv()
            logging.info(f"In lambda sync job data received for push charges {data}")

            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")

            key_name_received=data.get('key_name')
            logging.info(f"Key name {key_name_received}")
            tenant_name=data.get('tenant_name')
            opt_session_id = data.get("session_id")
            service_provider_id = data.get("service_provider_id")
            service_provider_ids = data.get("service_provider_ids")
            sync_call_first = data.get("sync_call_first", False)
            instance_ids = data.get("instance_id", None)
            total_count = data.get("total", None)
            sqs_flag = data.get("sqs_flag", False)
            tota_count_int = int(total_count)
            logging.info(f"Total count is {tota_count_int}")
            instance_ids_tuple = tuple(instance_ids)
            logging.info(f"Instance Ids {instance_ids}")
            #adding tenant name key handling
            service_provider_ids=data.get('service_provider_ids',None)
            tenant_name=data.get('tenant_name',None)
            common_utils_db=os.getenv("COMMON_UTILS_DB_NAME")
            comm_postgres_con= self.create_connection(
                db_type, hostname,common_utils_db, user, password, port
            )
            if isinstance(service_provider_ids,str) and len(service_provider_ids)>0:
                union_flag=True
            else:
                union_flag=False

            if tenant_name:
                tenant_name=self.function_to_check_sub_tenant_or_parent_name(comm_postgres_con,tenant_name)
            logging.info(f"tenant_name finally gotten after checking subtenant {tenant_name}")

            if tenant_name is None:
                logging.info(f"{key_name_received}: Tenant name and tenant id is None")
                return {'flag':False,'message':'Tenant Name and Tenant Id is None'}

            if tenant_name == "Altaworx Test":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
            elif tenant_name == "Altaworx":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
            else:
                try:
                    common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                    postgres_conn_common = self.create_connection(
                        db_type, hostname, common_db_name, user, password, port
                    )
                    tenant_name_query = f"select db_name from tenant where tenant_name='{tenant_name}'"
                    tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                    db_name = tenant_name_df['db_name'].iloc[0].lower()
                except Exception as e:
                    logging.info(f"Error in getting tenant name from tenant_id: {e}")
                    db_name = tenant_name
                    pass
                tenant_name_lcase = db_name
                tenant_name_ = tenant_name

            if key_name_received and tenant_name:
                key_name = f"{key_name_received}_{tenant_name_lcase.lower()}"
            else:
                key_name = key_name_received
            logging.info(f"Received Key name {key_name_received} and tenant name {tenant_name_lcase.lower()}, Final key formed is {key_name}")

            json_data = self.load_json()
            telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])
            if service_provider_id in telegence_ids:
                logging.info(
                    f"Service Provider ID {service_provider_id} is mobility for session id {opt_session_id}"
                )
                mobility_flag = True
            else:
                mobility_flag = False

            logging.info(
                f"Begining Migration for {key_name}-session id {opt_session_id}"
            )
            if mobility_flag:
                check_view = "vwOptimizationMobilityDeviceResult_CustomerChargeQueue"
            else:
                check_view = "vwOptimizationDeviceResult_CustomerChargeQueue"

            # fetch the details of database as hosts will be different for each tenant
            # hostname = os.getenv("PSQL_DB_HOST")
            # port = os.getenv("PSQL_DB_PORT")
            # db_name = os.getenv("PSQL_DB_NAME")
            # user = os.getenv("PSQL_DB_USER")
            # password = os.getenv("PSQL_DB_PASSWORD")
            # db_type = os.getenv("PSQL_DB_TYPE")
            postgres_conn = self.create_connection(
                        db_type, hostname, db_name, user, password, port
                    )
            migrations_table = os.getenv('MIGRATION_TABLE')
            db_config_details = f"select from_db_config from {migrations_table} where migration_name='optimization_commgroup_commplan_{tenant_name.lower()}'"

            db_config_details = self.execute_query(postgres_conn,db_config_details)
            db_config_details = db_config_details["from_db_config"].tolist()[0]
            if isinstance(db_config_details, str):  # Convert only if it's a string
                db_config_details = json.loads(db_config_details)

            from_host = db_config_details["hostname"]
            from_port = db_config_details["port"]
            from_user = db_config_details["user"]
            from_pwd = db_config_details["password"]
            # from_host = os.getenv("MSSQL_DB_HOST")
            # from_port = os.getenv("MSSQL_DB_PORT")
            from_db_type = os.getenv("MSSQL_DB_TYPE")
            from_database = os.getenv("MSSQL_DB_NAME")
            # from_user = os.getenv("MSSQL_DB_USER")
            # from_pwd = os.getenv("MSSQL_DB_PASSWORD")
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            logging.info(
                f"session id {opt_session_id} From Host {from_host} From Port {from_port} From DB Type {from_db_type} From Database {from_database} From User {from_user} From Pwd {from_pwd} From Driver {from_driver}"
            )
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(
                f"session id {opt_session_id} From Connection {from_connection}"
            )
            # get_query=f"SELECT id FROM AltaworxCentral_Test.dbo.OptimizationSession where sessionid='{opt_session_id}'"
            # result=self.execute_query(from_connection,get_query)
            # opt_session_id=result['id'].iloc[0]

            # check_query = f"SELECT * FROM {onepoint_o_database}.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}'"
            # logging.info(f"Check Query {check_query}")
            # check_query_result = self.execute_query(from_connection, check_query)
            # logging.info(
            #     f"Result f Query {opt_session_id}: {check_query_result.head()}"
            # )

            MAX_RETRIES = 3
            RETRY_DELAY = 10
            check_query = f"SELECT * FROM {onepoint_o_database}.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}'"

            for attempt in range(1, MAX_RETRIES + 1):
                try:
                    logging.info(
                        f"session id {opt_session_id} | Attempt {attempt}/{MAX_RETRIES} | Executing check query"
                    )

                    check_query_result = self.execute_query(from_connection, check_query)

                    if check_query_result is None:
                        raise Exception("Query returned None (timeout or execution failure)")

                    logging.info(
                        f"session id {opt_session_id} | Check query succeeded | Rows: {len(check_query_result)}"
                    )
                    break

                except Exception as e:
                    logging.error(
                        f"session id {opt_session_id} | Attempt {attempt} failed: {e}",
                        exc_info=True
                    )

                    if attempt == MAX_RETRIES:
                        logging.error(
                            f"session id {opt_session_id} | Check query failed after {MAX_RETRIES} attempts"
                        )
                        raise

                    logging.info(
                        f"session id {opt_session_id} | Recreating MSSQL connection and retrying in {RETRY_DELAY}s"
                    )

                    from_connection = self.create_connection(
                        from_db_type,
                        from_host,
                        from_database,
                        from_user,
                        from_pwd,
                        from_port,
                        from_driver,
                    )
                    time.sleep(RETRY_DELAY)

            # MAX_RETRIES = 3
            # RETRY_DELAY = 10  # seconds

            # check_query = f"SELECT * FROM {onepoint_o_database}.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}'"

            # check_query_result = None

            # for attempt in range(1, MAX_RETRIES + 1):
            #     try:
            #         logging.info(
            #             f"session id {opt_session_id} | "
            #             f"Attempt {attempt}/{MAX_RETRIES} | Executing check query"
            #         )

            #         check_query_result = self.execute_query(from_connection, check_query)

            #         logging.info(
            #             f"session id {opt_session_id} | "
            #             f"Check query succeeded | Rows: {check_query_result.head()}"
            #         )
            #         break 
                
            #     except Exception as e:
            #         logging.error(
            #             f"session id {opt_session_id} | "
            #             f"Attempt {attempt} failed executing check query: {e}",
            #             exc_info=True
            #         )

            #         if attempt == MAX_RETRIES:
            #             logging.error(
            #                 f"session id {opt_session_id} | "
            #                 f"Check query failed after {MAX_RETRIES} attempts"
            #             )
            #             raise  # let outer try/except handle it
                    
            #         logging.info(
            #             f"session id {opt_session_id} | Retrying in {RETRY_DELAY} seconds..."
            #         )
            #         time.sleep(RETRY_DELAY)
    

    
            # if check_query_result.empty:
            #     logging.info(f"No records found for the session id {opt_session_id} in {check_view}")
            #     logging.error(f"No records found for the session id {opt_session_id} in {check_view}")
            #     return {"flag":False,"message":f"No records found for the session id {opt_session_id} in {check_view}"}
            # else:
            # hostname = os.getenv("PSQL_DB_HOST")
            # port = os.getenv("PSQL_DB_PORT")
            # # db_name = os.getenv("PSQL_MAIN_DB")
            # user = os.getenv("PSQL_DB_USER")
            # password = os.getenv("PSQL_DB_PASSWORD")
            # db_type = os.getenv("PSQL_DB_TYPE")

            try:

                if tenant_name:
                    common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                    tenant_name_q=f"select db_name from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                    logging.info(f"Tenant name query is {tenant_name_q}")
                    tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                    logging.info(f"Tenant DF is {tenant_name_res}")
                    if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                        tenant_name_ = tenant_name_res['db_name'][0]
                        db_name=tenant_name_
                        logging.info(f"Tenant name is {tenant_name_}")
                    else:
                        raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")


                else:
                    logging.error(f"An error occurred loading tenant  :No tenant name found")
                    # db_name='altaworx_test'
            except Exception as e:
                logging.error(f"An error occurred loading tenant  : {str(e)}")
                # db_name='altaworx_test'


            logging.info(
                f"Hostname {hostname} Port {port} DB Name {db_name} User {user} Password {password} DB Type {db_type}"
            )
            postgres_conn_altaworx = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"Main conn in push charges {postgres_conn_altaworx}")

            retries = 4
            for attempt in range(retries):
                logging.info(
                    f"session id {opt_session_id} Attempt {attempt}: Executing query to fetch processed count"
                )
                processed_count, not_processed_count = self.get_processed_count(
                    from_connection, check_view, opt_session_id, instance_ids_tuple,union_flag
                )

                update_dict = {"push_charges_not_processed_count": int(processed_count)}
                logging.info(
                    f"session id {opt_session_id} Counts returned -- update_dict {update_dict}"
                )
                logging.info(
                    f"############### Updating optimization_session where session_id is {opt_session_id},update_dict={update_dict}"
                )
                if processed_count == 0 and sync_call_first:
                    logging.info("dont update")
                    uu = self.update_table(
                        postgres_conn_altaworx,
                        "optimization_session",
                        update_dict,
                        {"id": int(opt_session_id)},
                    )
                else:
                    uu = self.update_table(
                        postgres_conn_altaworx,
                        "optimization_session",
                        update_dict,
                        {"id": int(opt_session_id)},
                    )

                # if processed_count==0:
                #     logging.info(f"Processed count 0 ")
                #     update_dict={"push_charges_processed_count":int(processed_count)}
                #     uu=self.update_table(postgres_conn_altaworx,'optimization_session',update_dict,{'id':int(opt_session_id)})
                # else:

                # update_dict={'push_charges_not_processed_count':int(not_processed_count),'push_charges_processed_count':int(processed_count)}
                # update_dict={'push_charges_not_processed_count':int(not_processed_count),'push_charges_processed_count':int(processed_count)}

                # if not_processed_count==0 and processed_count>0:
                if (
                    processed_count == tota_count_int
                    or processed_count > tota_count_int
                ):
                    logging.info(
                        f"Total Match session id {opt_session_id} processed_count-{processed_count}"
                    )
                    update_dict = {
                        "push_charges_not_processed_count": int(processed_count)
                    }
                    if processed_count == 0 and sync_call_first:
                        uu = self.update_table(
                            postgres_conn_altaworx,
                            "optimization_session",
                            update_dict,
                            {"id": int(opt_session_id)},
                        )
                    else:
                        uu = self.update_table(
                            postgres_conn_altaworx,
                            "optimization_session",
                            update_dict,
                            {"id": int(opt_session_id)},
                        )
                    # logging.info(f"session id {opt_session_id} breaking the loop not_processed_count-{not_processed_count},processed_count-{processed_count}")
                    processed_flag = True
                    break
                elif attempt == retries - 1:
                    data_ = {
                        "session_id": opt_session_id,
                        "path": "/push_charges_sync",
                        "key_name": "optimization_sync_push_charges",
                        "instance_id": instance_ids,
                        "total": total_count,
                        "service_provider_id": service_provider_id,
                        "service_provider_ids":service_provider_ids,
                        "sqs_flag": True,
                        "timestamp": str(datetime.utcnow()),
                        "tenant_name": tenant_name
                    }
                    # logging.info(f"session id {opt_session_id} Attempts are completed,forcing the processed flag and syncing the data {attempt}")
                    # processed_flag=True
                    logging.info(
                        f"session id {opt_session_id} Attempts are completed calling SQS with {data_}"
                    )
                    processed_flag = False
                    try:
                        logging.info(f"SQS Message sent successfully for Push Charges")
                        oo = self.send_msg_to_opt_sync_queue(data_)
                        logging.info(f"SQS Message sent successfully for Push Charges")
                    except Exception as e:
                        logging.error(f"Message sending failed for Push Charges: {e}")

                else:
                    logging.info(
                        f" session id {opt_session_id} Records are not processed for the session id {opt_session_id} in {check_view}, Waiting for the next sync"
                    )
                    time.sleep(60)
            if processed_flag:
                logging.info(
                    f"All records are processed for the session id {opt_session_id} in {check_view}, Starting the sync"
                )
                logging.info(f"Begining Migration for {key_name}")
                hostname = os.getenv("PSQL_DB_HOST")
                port = os.getenv("PSQL_DB_PORT")
                db_name = os.getenv("PSQL_DB_NAME")
                user = os.getenv("PSQL_DB_USER")
                password = os.getenv("PSQL_DB_PASSWORD")
                db_type = os.getenv("PSQL_DB_TYPE")
                logging.info(
                    f"Hostname {hostname} Port {port} DB Name {db_name} User {user} Password {password} DB Type {db_type}"
                )
                postgres_conn = self.create_connection(
                    db_type, hostname, db_name, user, password, port
                )
                migration_table = "lambda_sync_jobs"
                job_scheduled_query = f"select migration_names_list from {migration_table} where key_name='{key_name}'"
                rows = self.execute_query(postgres_conn, job_scheduled_query)
                logging.info(
                    f"session id {opt_session_id} Data from key name is {rows},{type(rows)}"
                )
                job_names_list = rows["migration_names_list"][0]
                logging.info(
                    f"session id {opt_session_id} Job names are {job_names_list},{type(job_names_list)}"
                )
                jobs_status_dict = {"Success": [], "failed": []}
                logging.info(
                    f"session id {opt_session_id} Job names are {job_names_list},{type(job_names_list)}"
                )
                try:
                    for job in job_names_list:
                        migration_job = self.main_migration_func(job, key_name)
                        # migration_job=True
                        logging.info(
                            f"session id {opt_session_id} migration job has run -- {job}"
                        )
                        if migration_job is True:
                            jobs_status_dict["Success"].append(job)
                            logging.info(f"Job is done {job}")
                        else:
                            jobs_status_dict["failed"].append(job)
                            logging.info(f"Errors in job {job}")
                except Exception as e:
                    logging.info(
                        f"Error in push_charges_sync {key_name} in job {job}-- {e}"
                    )
        except Exception as e:
            logging.info(f"Error in push_charges_sync {key_name} {e}")



    def optimization_sync_comm_group_bak_24dec24(
        self, data
    ):  # removing on for ticket 2114 (implemention function for comm group error)
        try:
            logging.info(f"Starting Optimiation Error Updates Sync....")
            load_dotenv()
            session_id = data.get("session_id")
            from_host = os.getenv("MSSQL_DB_HOST")
            from_port = os.getenv("MSSQL_DB_PORT")
            from_user = os.getenv("MSSQL_DB_USER")
            from_pwd = os.getenv("MSSQL_DB_PASSWORD")
            from_db_type = os.getenv("MSSQL_DB_TYPE")
            from_database = os.getenv("MSSQL_DB_NAME")
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            # logging.info(f"from driver {from_driver}")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            error_ids = {1, 2, 3, 4, 5}
            for attempt in range(3):
                logging.info(f"Attempt {attempt}: Executing query to fetch run status id's")
                error_ids_df = self.fetch_run_status_ids(
                    from_connection, from_database, session_id, error_ids
                )
                if not error_ids_df.empty:
                    logging.info(
                        f"Found records with Errors or Comm Group Setup waiting for 5 min....."
                    )
                    time.sleep(30)
                else:
                    logging.info(
                        f"Attempt {attempt}: Comm Group Setup records not found, so begining the sync"
                    )
                    data_opt = {
                        "data": {
                            "key_name": "optimization_sync",
                            "session_id": session_id,
                        }
                    }
                    opt_sync = self.lambda_sync_jobs_(data_opt, True)

            logging.info(f"Attempts Completed,Syncing the data")
            data_opt = {
                "data": {"key_name": "optimization_sync", "session_id": session_id}
            }
            opt_sync = self.lambda_sync_jobs_(data_opt, True)
        except Exception as e:
            logging.error(
                f"Error in running optimization sync in case of comm group errors {e}"
            )
            return {"flag": False, "message": {e}}
        return {"flag": True, "message": "Optimization Sync Successfull"}

    def optimization_sync_comm_group_old(self, data):
        try:
            logging.info(f"Starting Optimiation Error Updates Sync....")
            load_dotenv()
            session_id = data.get("session_id")
            from_host = os.getenv("MSSQL_DB_HOST")
            from_port = os.getenv("MSSQL_DB_PORT")
            from_user = os.getenv("MSSQL_DB_USER")
            from_pwd = os.getenv("MSSQL_DB_PASSWORD")
            from_db_type = os.getenv("MSSQL_DB_TYPE")
            from_database = os.getenv("MSSQL_DB_NAME")
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            # logging.info(f"from driver {from_driver}")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )

            retries = 3
            for attempt in range(3):
                logging.info(
                    f"Attempt {attempt}: Executing query to fetch run status id's"
                )
                unique_run_status_ids = self.fetch_run_status_ids(
                    from_connection, from_database, session_id
                )
                logging.info(
                    f"Attempt-{attempt}: Run Status ids::{unique_run_status_ids}"
                )
                comm_group_error_id = 2
                error_ids = {1, 2, 3, 4, 5}
                if unique_run_status_ids & error_ids:
                    logging.info(
                        f"Found records with Errors or Comm Group Setup waiting for 5 min....."
                    )
                    time.sleep(4 * 60)
                else:
                    logging.info(
                        f"Comm Group Setup records not found, so begining the sync"
                    )
                    data_opt = {
                        "data": {
                            "key_name": "optimization_sync",
                            "session_id": session_id,
                        }
                    }
                    opt_sync = self.lambda_sync_jobs_(data_opt, flag=True)

            logging.info(f"Attempts Completed,Syncing the data")
            data_opt = {
                "data": {"key_name": "optimization_sync", "session_id": session_id}
            }
            opt_sync = self.lambda_sync_jobs_(data_opt, Flag=True)

        except Exception as e:
            logging.error(
                f"Error in running optimization sync in case of comm group errors {e}"
            )
            return {"flag": False, "message": {e}}
        return {"flag": True, "message": "Optimization Sync Successfull"}

    def get_mapping_details(self, conn,transfer_name):
        """
        this function used to get mapping details for optimization_setting
        """
        try:
            query = f"SELECT col_mapping_10_to_20 FROM mapping_table WHERE transfer_name ='{transfer_name}' "
            query_result = self.execute_query(conn, query)
            return query_result.to_dict(orient="records")[0]
        except Exception as e:
            logging.info(f"Error while fetching the details - {e}")
            return {}

    def update_optimization_setting_table(
        self, columns_mapping, result_data, rev_settings_dict, to_connection
    ):
        columns_mapping_dict = dict(columns_mapping)
        swapped_columns_mapping_dict = {v: k for k, v in columns_mapping_dict.items()}
        settings_dict = dict(
            zip(result_data["setting_key"], result_data["setting_value"])
        )
        set_clause = []
        values = []
        for setting_key, setting_value in settings_dict.items():
            actual_column_name = swapped_columns_mapping_dict.get(setting_key)
            if actual_column_name:
                set_clause.append(f"{actual_column_name} = %s")
                values.append(setting_value)
        logging.info(f"set clause is {set_clause}")
        logging.info(f"Now adding rev setting to the set clause")

        if rev_settings_dict:
            for rev_key, rev_value in rev_settings_dict.items():
                set_clause.append(f"{rev_key} = %s")
                values.append(rev_value)
        logging.info(f"final set clause {set_clause}")
        logging.info(f"final values are {values}")

        if set_clause:
            update_query = f"""
                    UPDATE optimization_setting
                    SET {', '.join(set_clause)}
                                """

        logging.info(f"swapped_columns_mapping_dict {swapped_columns_mapping_dict}")
        logging.info(f"settings_dict------{settings_dict}")
        logging.info(f"update_query----------- {update_query}")
        logging.info(f"values {values}")
        try:
            # Creating a cursor to execute the query
            with to_connection.cursor() as cur:
                # Execute the update query with the values
                cur.execute(update_query, tuple(values))

                # Commit the transaction
                to_connection.commit()
                logging.info("Update successful")

        except Exception as e:
            # Handle any exceptions that occur during the update
            logging.error(f"Error updating optimization_setting table: {e}")
            to_connection.rollback()
        return None

    def optimization_setting_handler_bak(self, job_name,tenant_name=None):
        try:
            logging.info(f"starting the job for optimzation_settings table {job_name}")
            load_dotenv()
            msg=None
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            db_name = os.getenv("PSQL_DB_NAME")

            logging.info(
                f" {job_name} postgress sql db configuration loaded successfully"
            )
            tenant_json=self.load_json()
            if tenant_name:
                tenant_id_dict=tenant_json.get('TenanatIds')
                tenant_id=tenant_id_dict.get(tenant_name)

            # logging.info(hostname,port)

            # Create the PostgreSQL connection to the source database
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"*********************** Executing job: {job_name}")

            load_dotenv()
            migration_table=os.getenv('MIGRATION_TABLE')
            migrations_history_table=os.getenv('MIGRATION_HISTORY_TABLE')
            hist_insert_data={'key_name':job_name,'job_name':job_name,'job_start_time':datetime.now(timezone.utc).replace(tzinfo=None),
                              'request_triggered_by':'optimization_sync_lambda_trigger'}
            trace_id=self.insert_dict(postgres_conn,migrations_history_table,hist_insert_data,True,'trace_id')
            # migration_table='migrations_2'
            logging.info(f"migrations table {migration_table}")
            migration_details_dict = self.get_migration_details(
                job_name, postgres_conn, migration_table
            )

            table_flag = migration_details_dict["table_flag"]
            logging.info(f"!!!!!!!!!!!!!!!!!!! Table Flag is {table_flag}")
            to_hostname = os.getenv("PSQL_DB_HOST")
            to_port = os.getenv("PSQL_DB_PORT")
            to_db_name = migration_details_dict["to_database"]
            to_user = os.getenv("PSQL_DB_USER")
            to_password = os.getenv("PSQL_DB_PASSWORD")
            to_db_type = os.getenv("PSQL_DB_TYPE")
            to_table = migration_details_dict["to_table"]
            from_query = migration_details_dict["from_query"]
            # logging.info(from_query)
            mapping_details_dict = self.get_mapping_details(postgres_conn)
            logging.info(f"mapping_details_dict is {mapping_details_dict}")
            columns_setting = mapping_details_dict["col_mapping_10_to_20"][
                "optimizationsetting"
            ].items()

            db_config = self.get_db_config(migration_details_dict)
            from_host = db_config["hostname"]
            from_port = db_config["port"]
            from_user = db_config["user"]
            from_pwd = db_config["password"]
            from_db_type = db_config["from_db_type"]
            from_database = migration_details_dict["from_database"]
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            load_dotenv()
            basemultitenant=os.getenv('BASE_MULTI_TENANT_DB')
            from_query_rev_settings = f"""SELECT MAX(CASE WHEN ObjectId = 28 THEN co.customname END) AS revio_ftp_host,
                                        MAX(CASE WHEN ObjectId = 29 THEN co.customname END) AS revio_ftp_username,
                                        MAX(CASE WHEN ObjectId = 30 THEN co.customname END) AS revio_ftp_password,
                                        MAX(CASE WHEN ObjectId = 31 THEN co.customname END) AS rev_io_ftp_path,
                                        MAX(CASE WHEN ObjectId = 32 THEN co.customname END) AS rev_io_push_customer_charge_type
                                    FROM
                                        {basemultitenant}.dbo.CustomObject co
                                    WHERE
                                        TenantId = {tenant_id} AND ObjectId IN (28, 29, 30, 31, 32);"""

            from_query_rev_settings_ = " ".join(from_query_rev_settings.split())
            logging.info(f"from_query_rev_settings_ is {from_query_rev_settings_}")
            multi_tenant_host = os.getenv("BASE_MULTI_TENANT_HOST")
            port = os.getenv("FROM_DB_PORT")
            user = os.getenv("FROM_DB_USER")
            password = os.getenv("FROM_DB_PASSWORD")
            db_type = os.getenv("FROM_DB_TYPE")
            db_name = os.getenv("BASE_MULTI_TENANT_DB")
            driver = os.getenv("FROM_DB_DRIVER")
            multi_tenant_conn = self.create_connection(
                db_type, multi_tenant_host, db_name, user, password, port
            )
            logging.info(f"multi tenant connn is {multi_tenant_conn}")

            result = self.execute_query(from_connection, from_query)
            logging.info(f"optimization setting result is {result}")

            result2 = self.execute_query(multi_tenant_conn, from_query_rev_settings_)
            result2_dict = result2.to_dict(orient="records")[0]
            rev_settings_dict = result2_dict
            logging.info(f"Second result is {result2_dict}")

            to_connection = self.create_connection(
                to_db_type, to_hostname, to_db_name, to_user, to_password, to_port
            )
            logging.info(f"to_connection is {to_connection}")
            self.update_optimization_setting_table(
                columns_setting, result, rev_settings_dict, to_connection
            )

            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,migrations_history_table,update_dict,{'trace_id':trace_id})
            # self.update_optimization_setting_table(columns_setting,result,to_connection)
        except Exception as e:
            # If any error occurs, log the error and set return_flag to False
            return_flag = False
            tb = traceback.format_exc()
            msg=f"Error in optimization setting {job_name} {e} {tb}"
            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,migrations_history_table,update_dict,{'trace_id':trace_id})
            logging.info(f"Error in job {job_name} -{e}")
            return return_flag
        return True

    '''''
    def update_optimization_setting_table(self,columns_mapping,result_data,to_connection):
        columns_mapping_dict = dict(columns_mapping)
        swapped_columns_mapping_dict = {v: k for k, v in columns_mapping_dict.items()}
        settings_dict = dict(zip(result_data['setting_key'], result_data['setting_value']))
        set_clause = []
        values = []
        for setting_key, setting_value in settings_dict.items():
            actual_column_name = swapped_columns_mapping_dict.get(setting_key)
            if actual_column_name:
                set_clause.append(f"{actual_column_name} = %s")
                values.append(setting_value)
        if set_clause:
            update_query = f"""
                    UPDATE optimization_setting
                    SET {', '.join(set_clause)}
                                """

        logging.info(f"swapped_columns_mapping_dict {swapped_columns_mapping_dict}")
        logging.info(f"settings_dict------{settings_dict}")
        logging.info(f"update_query----------- {update_query}")
        logging.info(f"values {values}")
        try:
            # Creating a cursor to execute the query
            with to_connection.cursor() as cur:
                # Execute the update query with the values
                cur.execute(update_query, tuple(values))

                # Commit the transaction
                to_connection.commit()
                logging.info("Update successful")

        except Exception as e:
            # Handle any exceptions that occur during the update
            logging.error(f"Error updating optimization_setting table: {e}")
            to_connection.rollback()
        return None

    def optimization_setting_handler(self,job_name):
        try:
            logging.info(f"starting the job for optimzation_settings table {job_name}")
            load_dotenv()
            hostname = os.getenv('PSQL_DB_HOST')
            port = os.getenv('PSQL_DB_PORT')
            user = os.getenv('PSQL_DB_USER')
            password = os.getenv('PSQL_DB_PASSWORD')
            db_type = os.getenv('PSQL_DB_TYPE')
            db_name=os.getenv('PSQL_DB_NAME')
            logging.info(f" {job_name} postgress sql db configuration loaded successfully")
            # logging.info(hostname,port)

            # Create the PostgreSQL connection to the source database
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"*********************** Executing job: {job_name}")

            load_dotenv()
            migration_table=os.getenv('MIGRATION_TABLE')
            # migration_table='migrations_2'
            logging.info(f"migrations table {migration_table}")
            migration_details_dict=self.get_migration_details(job_name,postgres_conn,migration_table)

            table_flag=migration_details_dict['table_flag']
            logging.info(f"!!!!!!!!!!!!!!!!!!! Table Flag is {table_flag}")
            to_hostname = os.getenv('PSQL_DB_HOST')
            to_port = os.getenv('PSQL_DB_PORT')
            to_db_name =migration_details_dict['to_database']
            to_user = os.getenv('PSQL_DB_USER')
            to_password = os.getenv('PSQL_DB_PASSWORD')
            to_db_type = os.getenv('PSQL_DB_TYPE')
            to_table=migration_details_dict['to_table']
            from_query=migration_details_dict['from_query']
            #logging.info(from_query)
            mapping_details_dict=self.get_mapping_details(postgres_conn)
            logging.info("1234567",mapping_details_dict)
            columns_setting=mapping_details_dict['col_mapping_10_to_20']['optimizationsetting'].items()

            db_config=self.get_db_config(migration_details_dict)
            from_host=db_config['hostname']
            from_port=db_config['port']
            from_user=db_config['user']
            from_pwd=db_config['password']
            from_db_type=db_config['from_db_type']
            from_database=migration_details_dict['from_database']
            from_driver=os.getenv('MSSQL_DB_DRIVER')
            from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
            result=self.execute_query(from_connection,from_query)
            logging.info(result)
            to_connection=self.create_connection(to_db_type,to_hostname,to_db_name,to_user,to_password,to_port)
            logging.info(to_connection)
            self.update_optimization_setting_table(columns_setting,result,to_connection)
        except Exception as e:
            # If any error occurs, log the error and set return_flag to False
            return_flag = False
            logging.info(f"Error in job {job_name} -{e}")
        return True''' ""
    def optimization_setting_handler(self, job_name,tenant_id,tenant_name=None,trace_id=None):
        try:
            logging.info(f"starting the job for optimzation_settings table {job_name}")
            load_dotenv()
            msg=None
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            db_name = os.getenv("PSQL_DB_NAME")
            transfer_name=job_name

            logging.info(
                f" {job_name} postgress sql db configuration loaded successfully"
            )
            tenant_json=self.load_json()
            if tenant_name:
                tenant_id_dict=tenant_json.get('TenanatIds')
                tenant_id=tenant_id_dict.get(tenant_name)

            # logging.info(hostname,port)

            # Create the PostgreSQL connection to the source database
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"*********************** Executing job: {job_name}")

            load_dotenv()
            migration_table=os.getenv('MIGRATION_TABLE')
            migrations_history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            # hist_insert_data={'key_name':job_name,'job_name':job_name,'job_start_time':datetime.now(timezone.utc).replace(tzinfo=None),
            #                   'request_triggered_by':'optimization_sync_lambda_trigger'}
            # trace_id=self.insert_dict(postgres_conn,migrations_history_table,hist_insert_data,True,'trace_id')
            # migration_table='migrations_2'
            logging.info(f"migrations table {migration_table}")
            migration_details_dict = self.get_migration_details(
                job_name, postgres_conn, migration_table
            )

            table_flag = migration_details_dict["table_flag"]
            logging.info(f"!!!!!!!!!!!!!!!!!!! Table Flag is {table_flag}")
            to_hostname = os.getenv("PSQL_DB_HOST")
            to_port = os.getenv("PSQL_DB_PORT")
            to_db_name = migration_details_dict["to_database"]
            to_user = os.getenv("PSQL_DB_USER")
            to_password = os.getenv("PSQL_DB_PASSWORD")
            to_db_type = os.getenv("PSQL_DB_TYPE")
            to_table = migration_details_dict["to_table"]
            from_query = migration_details_dict["from_query"]
            # logging.info(from_query)
            mapping_details_dict = self.get_mapping_details(postgres_conn,transfer_name)
            logging.info(f"mapping_details_dict is {mapping_details_dict}")
            columns_setting = mapping_details_dict["col_mapping_10_to_20"][
                "optimizationsetting"
            ].items()

            db_config = self.get_db_config(migration_details_dict)
            from_host = db_config["hostname"]
            from_port = db_config["port"]
            from_user = db_config["user"]
            from_pwd = db_config["password"]
            from_db_type = db_config["from_db_type"]
            from_database = migration_details_dict["from_database"]
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            load_dotenv()
            basemultitenant=os.getenv('BASE_MULTI_TENANT_DB')
            from_query_rev_settings = f"""SELECT MAX(CASE WHEN ObjectId = 28 THEN co.customname END) AS revio_ftp_host,
                                        MAX(CASE WHEN ObjectId = 29 THEN co.customname END) AS revio_ftp_username,
                                        MAX(CASE WHEN ObjectId = 30 THEN co.customname END) AS revio_ftp_password,
                                        MAX(CASE WHEN ObjectId = 31 THEN co.customname END) AS rev_io_ftp_path,
                                        MAX(CASE WHEN ObjectId = 32 THEN co.customname END) AS rev_io_push_customer_charge_type
                                    FROM
                                        {basemultitenant}.dbo.CustomObject co
                                    WHERE
                                        TenantId = {tenant_id} AND ObjectId IN (28, 29, 30, 31, 32);"""

            from_query_rev_settings_ = " ".join(from_query_rev_settings.split())
            logging.info(f"from_query_rev_settings_ is {from_query_rev_settings_}")
            multi_tenant_host = os.getenv("BASE_MULTI_TENANT_HOST")
            port = os.getenv("FROM_DB_PORT")
            user = os.getenv("BASE_MULTI_TENANT_USER")
            password = os.getenv("BASE_MULTI_TENANT_PASSWORD")
            db_type = os.getenv("FROM_DB_TYPE")
            db_name = os.getenv("BASE_MULTI_TENANT_DB")
            driver = os.getenv("FROM_DB_DRIVER")
            multi_tenant_conn = self.create_connection(
                db_type, multi_tenant_host, db_name, user, password, port
            )
            logging.info(f"multi tenant connn is {multi_tenant_conn}")

            result = self.execute_query(from_connection, from_query)
            logging.info(f"optimization setting result is {result}")

            result2 = self.execute_query(multi_tenant_conn, from_query_rev_settings_)
            result2_dict = result2.to_dict(orient="records")[0]
            rev_settings_dict = result2_dict
            logging.info(f"Second result is {result2_dict}")

            to_connection = self.create_connection(
                to_db_type, to_hostname, to_db_name, to_user, to_password, to_port
            )
            logging.info(f"to_connection is {to_connection}")
            self.update_optimization_setting_table(
                columns_setting, result, rev_settings_dict, to_connection
            )

            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'job_status_msg':'Success'}
            self.update_table(postgres_conn,migrations_history_table,update_dict,{'trace_id':trace_id})
            # self.update_optimization_setting_table(columns_setting,result,to_connection)
        except Exception as e:
            # If any error occurs, log the error and set return_flag to False
            return_flag = False
            tb = traceback.format_exc()
            msg=f"Error in optimization setting {job_name} {e} {tb}"
            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,migrations_history_table,update_dict,{'trace_id':trace_id})
            logging.info(f"Error in job {job_name} -{e}")
            return return_flag
        return True



##Calling the main method of class
# if __name__ == "__main__":
#     scheduler = MigrationScheduler()
#     #scheduler.main()
# scheduler.main_migration_func("automation_rule_altaworx")
