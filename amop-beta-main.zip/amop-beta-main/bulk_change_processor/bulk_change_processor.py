"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
import json
import logging
import os
import ast
import boto3
import requests
import os
import pandas as pd
import queue
from common_utils.db_utils import DB
import psycopg2
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
from pandas import Timestamp
from datetime import datetime ,timezone
from dotenv import load_dotenv
from dateutil.relativedelta import relativedelta
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
# from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random
import xlsxwriter
import hashlib

logging = Logging(name="bulk_change_processor")

common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }


function_registry= {
  "AT&T - Telegence - UAT ONLY": {
    "actions": [
      {
        "change_type": "Activate New Service",
        "function_name": "telegence_bc_activate_new_service"
      },
      {
        "change_type": "Archive",
        "function_name": "telegence_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "telegence_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "telegence_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "telegence_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "telegence_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "telegence_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "telegence_bc_update_device_status"
      },
      {
        "change_type": "Change Phone Number",
        "function_name": "telegence_bc_change_phone_number"
      },
      {
        "change_type": "Update PPU address",
        "function_name": "telegence_bc_update_ppu_address"
      },
      {
        "change_type": "Update Features",
        "function_name": "telegence_bc_update_feature"
      },
      {
        "change_type": "Create Rev Service",
        "function_name": "telegence_bc_create_rev_service"
      },
      {
        "change_type": "Refresh A Line",
        "function_name": "telegence_refresh_a_line"
      },
      {
      "change_type": "Line Sync",
      "function_name": "telegence_bc_line_sync"
    },
    {
      "change_type": "Reset Voicemail Password",
      "function_name": "telegence_bc_reset_voicemail_password"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "telegence_bc_private_network_ip"
    }
    ]
  },
  "AT&T - Telegence": {
    "actions": [
      {
        "change_type": "Activate New Service",
        "function_name": "telegence_bc_activate_new_service"
      },
      {
        "change_type": "Archive",
        "function_name": "telegence_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "telegence_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "telegence_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "telegence_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "telegence_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "telegence_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "telegence_bc_update_device_status"
      },
      {
        "change_type": "Change Phone Number",
        "function_name": "telegence_bc_change_phone_number"
      },
      {
        "change_type": "Update PPU address",
        "function_name": "telegence_bc_update_ppu_address"
      },
      {
        "change_type": "Update Features",
        "function_name": "telegence_bc_update_feature"
      },
      {
        "change_type": "Create Rev Service",
        "function_name": "telegence_bc_create_rev_service"
      },
      {
        "change_type": "Refresh A Line",
        "function_name": "telegence_refresh_a_line"
      },
      {
      "change_type": "Line Sync",
      "function_name": "telegence_bc_line_sync"
      },
      {
        "change_type": "Reset Voicemail Password",
        "function_name": "telegence_bc_reset_voicemail_password"
      },
      {
      "change_type": "Change Private Static IP Address",
      "function_name": "telegence_bc_private_network_ip"
     }
      
    ]
  },
  "Verizon - ThingSpace PN": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username /Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "Verizon - ThingSpace IoT": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZN 5G/FWA 4740948": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username /Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
    ]
  },
  "VZWCR 8280-CRBEAST": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 1256-cyberree": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 1481-CYBEREN": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 1628-LFW": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 2215-SO01": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 3433-CRSKRAKN": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 5488-CRFWAFED5G": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 6242-CRMBBFWA5G": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 8280-CRBEAST": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "VZWCR 8593-cybersol": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "verizon_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "verizon_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "verizon_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "verizon_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "verizon_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "verizon_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "verizon_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "verizon_bc_line_sync"
    },
    {
      "change_type": "Change Private Static IP Address",
      "function_name": "verizon_bc_private_network_ip"
    }
    ]
  },
  "Multi-Carrier SIM": {
      "actions": [
        {
          "change_type": "Archive",
          "function_name": "webbing_bc_archive_devices"
        },
        {
          "change_type": "Assign Customer",
          "function_name": "webbing_bc_assign_customer"
        },
        {
          "change_type": "Change Customer Rate Plan",
          "function_name": "webbing_bc_change_customer_rate_plan"
        },
        {
          "change_type": "Change Carrier Rate Plan",
          "function_name": "webbing_bc_change_carrier_rate_plan"
        },
        {
          "change_type": "Update Device Status",
          "function_name": "webbing_bc_update_device_status"
        },
        {
        "change_type": "Line Sync",
        "function_name": "webbing_bc_line_sync"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "webbing_bc_edit_username_cost_center"
      }
      ]
  },

  "Webbing": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "webbing_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "webbing_bc_assign_customer"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "webbing_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "webbing_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "webbing_bc_update_device_status"
      },
      {
      "change_type": "Line Sync",
      "function_name": "webbing_bc_line_sync"
    },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "webbing_bc_edit_username_cost_center"
      }
      

    ]
  },
  "AT&T - POD19": {
    "actions": [
    {
        "change_type": "Change Communication Plan",
        "function_name": "pod19_bc_change_communication_plan"
    },  
      {
        "change_type": "Archive",
        "function_name": "pod19_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "pod19_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "pod19_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "pod19_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "pod19_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "pod19_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "pod19_bc_line_sync"
      },
      {
        "change_type": "Send SMS",
        "function_name": "pod19_bc_send_sms"
      },
      {
        "change_type": "Change Private Static IP Address",
        "function_name": "pod19_bc_private_network_ip"
      }
      


    ]
  },
  "AT&T - POD19 - BBOW": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "pod19_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "pod19_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "pod19_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "pod19_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "pod19_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "pod19_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "pod19_bc_line_sync"
      }

    ]
  },
  "AT&T - POD19 - ENT": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "pod19_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "pod19_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "pod19_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "pod19_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "pod19_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "pod19_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "pod19_bc_line_sync"
      },
      

    ]
  },
  "POND IoT": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "pondiot_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "pondiot_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "pondiot_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "pondiot_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "pondiot_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "pondiot_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "pondiot_bc_line_sync"
      }
    ]
  },
  "Pond IoT": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "pondiot_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "pondiot_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "pondiot_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "pondiot_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "pondiot_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "pondiot_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "pondiot_bc_line_sync"
      }
    ]
  },
  "AT&T - Cisco Jasper": {
    "actions": [
       {
        "change_type": "Change Communication Plan",
        "function_name": "ciscojasper_bc_change_communication_plan"
        }, 
      {
        "change_type": "Archive",
        "function_name": "ciscojasper_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "ciscojasper_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "ciscojasper_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "ciscojasper_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "ciscojasper_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "ciscojasper_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "ciscojasper_bc_line_sync"
      },
      {
        "change_type": "Send SMS",
        "function_name": "ciscojasper_bc_send_sms"
      },
      {
        "change_type": "Change Private Static IP Address",
        "function_name": "ciscojasper_bc_private_network_ip"
      }
    
    ]
    },
    "Teal": {
    "actions": [
      
      {
        "change_type": "Assign Customer",
        "function_name": "teal_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "teal_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "teal_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "teal_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "teal_bc_line_sync"
      },
      {
        "change_type": "Change Private Static IP Address",
        "function_name": "teal_bc_private_network_ip"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "teal_bc_edit_username_cost_center"
      }
    ]
  },
  "Kore": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "kore_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "kore_bc_assign_customer"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "kore_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "kore_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "kore_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "kore_bc_line_sync"
      }
    ]
    },

  "Verizon-Kore Wireless": {
    "actions": [
      {
        "change_type": "Archive",
        "function_name": "kore_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "kore_bc_assign_customer"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "kore_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "kore_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "kore_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "kore_bc_line_sync"
      }
    ]
    },

  "T-Mobile Jasper": {
    "actions": [
        {
      "change_type": "Change Communication Plan",
      "function_name": "tmobilejasper_bc_change_communication_plan"
    },
      {
        "change_type": "Archive",
        "function_name": "tmobilejasper_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "tmobilejasper_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "tmobilejasper_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "tmobilejasper_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "tmobilejasper_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "tmobilejasper_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "tmobilejasper_bc_line_sync"
      },
      {
        "change_type": "Send SMS",
        "function_name": "tmobilejasper_bc_send_sms"
      },
      {
        "change_type": "Change Private Static IP Address",
        "function_name": "tmobilejasper_bc_private_network_ip"
      }
    ]
    },
  "T-Mobile": {
    "actions": [
        {
      "change_type": "Change Communication Plan",
      "function_name": "tmobilejasper_bc_change_communication_plan"
    },
      {
        "change_type": "Archive",
        "function_name": "tmobilejasper_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "tmobilejasper_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "tmobilejasper_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "tmobilejasper_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "tmobilejasper_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "tmobilejasper_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "tmobilejasper_bc_line_sync"
      },
      {
        "change_type": "Send SMS",
        "function_name": "tmobilejasper_bc_send_sms"
      },
      {
        "change_type": "Change Private Static IP Address",
        "function_name": "tmobilejasper_bc_private_network_ip"
      }
    ]
    },  
  "Rogers Sandbox": {
    "actions": [
    {
      "change_type": "Change Communication Plan",
      "function_name": "rogers_bc_change_communication_plan"
    },
      {
        "change_type": "Archive",
        "function_name": "rogers_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "rogers_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "rogers_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "rogers_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "rogers_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "rogers_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "rogers_bc_line_sync"
      },
      {
        "change_type": "Send SMS",
        "function_name": "rogers_bc_send_sms"
      },
      {
        "change_type": "Change Private Static IP Address",
        "function_name": "rogers_bc_private_network_ip"
      }
    ]
    },
  "Rogers": {
    "actions": [
    {
      "change_type": "Change Communication Plan",
      "function_name": "rogers_bc_change_communication_plan"
    },
      {
        "change_type": "Archive",
        "function_name": "rogers_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "rogers_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "rogers_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "rogers_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "rogers_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "rogers_bc_update_device_status"
      },
      {
        "change_type": "Line Sync",
        "function_name": "rogers_bc_line_sync"
      },
      {
        "change_type": "Send SMS",
        "function_name": "rogers_bc_send_sms"
      },
      {
        "change_type": "Change Private Static IP Address",
        "function_name": "rogers_bc_private_network_ip"
      }
    ]
    },
  "Telegence_Beta": {
    "actions": [
      {
        "change_type": "Activate New Service",
        "function_name": "telegence_bc_activate_new_service"
      },
      {
        "change_type": "Archive",
        "function_name": "telegence_bc_archive_devices"
      },
      {
        "change_type": "Assign Customer",
        "function_name": "telegence_bc_assign_customer"
      },
      {
        "change_type": "Change Carrier Rate Plan",
        "function_name": "telegence_bc_change_carrier_rate_plan"
      },
      {
        "change_type": "Change Customer Rate Plan",
        "function_name": "telegence_bc_change_customer_rate_plan"
      },
      {
        "change_type": "Change ICCID/IMEI",
        "function_name": "telegence_bc_change_iccid_imei"
      },
      {
        "change_type": "Edit Username/Cost Center",
        "function_name": "telegence_bc_edit_username_cost_center"
      },
      {
        "change_type": "Update Device Status",
        "function_name": "telegence_bc_update_device_status"
      },
      {
        "change_type": "Change Phone Number",
        "function_name": "telegence_bc_change_phone_number"
      },
      {
        "change_type": "Update PPU address",
        "function_name": "telegence_bc_update_ppu_address"
      },
      {
        "change_type": "Update Features",
        "function_name": "telegence_bc_update_feature"
      },
      {
        "change_type": "Create Rev Service",
        "function_name": "telegence_bc_create_rev_service"
      },
      {
        "change_type": "Refresh A Line",
        "function_name": "telegence_refresh_a_line"
      },
      {
      "change_type": "Line Sync",
      "function_name": "telegence_bc_line_sync"
      },
      {
        "change_type": "Reset Voicemail Password",
        "function_name": "telegence_bc_reset_voicemail_password"
      },
      {
      "change_type": "Change Private Static IP Address",
      "function_name": "telegence_bc_private_network_ip"
     }
      
    ]
  }
  }

container_mapping = {
    "AT&T - Telegence - UAT ONLY": "Telegence",
    "AT&T - Telegence": "Telegence",
    "Verizon - ThingSpace IoT":"Verizon",
    "VZWCR 8280-CRBEAST":"Verizon",
    "Verizon - ThingSpace PN":"Verizon",
    "VZN 5G/FWA 4740948":"Verizon",
    "Webbing":"Webbing",
    "AT&T - POD19":"POD19",
    "AT&T - POD19 - BBOW":"POD19",
    "AT&T - POD19 - ENT":"POD19",
    "POND IoT":"PondIOT",
    "AT&T - Cisco Jasper":"CiscoJasper",
    "Teal":"Teal",
    "Kore":"Kore",
    "T-Mobile Jasper":"TMobileJasper",
    "T-Mobile":"TMobileJasper",
    "Rogers Sandbox":"rogers",
    "Pond IoT":"PondIOT",
    "Rogers":"rogers",
    "Multi-Carrier SIM":"Webbing",
    "Verizon-Kore Wireless":"Kore",
    "VZWCR 1256-cyberree": "Verizon",
    "VZWCR 1481-CYBEREN": "Verizon",
    "VZWCR 1628-LFW": "Verizon",
    "VZWCR 2215-SO01":"Verizon",
    "VZWCR 3433-CRSKRAKN":"Verizon",
    "VZWCR 5488-CRFWAFED5G":"Verizon",
    "VZWCR 6242-CRMBBFWA5G":"Verizon",
    "VZWCR 8280-CRBEAST":"Verizon",
    "VZWCR 8593-cybersol":"Verizon",
    "Telegence_Beta":"TelegenceBeta"
}

port_mapping = {
    "AT&T - Telegence - UAT ONLY": 5000,
    "AT&T - Telegence": 5000,
    "Verizon - ThingSpace IoT":5002,
    "VZWCR 8280-CRBEAST":5002,
    "Verizon - ThingSpace PN":5002,
    "VZN 5G/FWA 4740948":5002,
    "Webbing":5003,
    "Multi-Carrier SIM":5003,
    "AT&T - POD19":5004,
    "AT&T - POD19 - BBOW":5004,
    "AT&T - POD19 - ENT":5004,
    "POND IoT":5005,
    "Pond IoT":5005,
    "AT&T - Cisco Jasper":5006,
    "Teal":5007,
    "Kore":5008,
    "Verizon-Kore Wireless":5008,
    "T-Mobile Jasper":5009,
    "T-Mobile":5009,
    "Rogers Sandbox":5010,
    "Rogers":5010,
    "VZWCR 1256-cyberree": 5002,
    "VZWCR 1481-CYBEREN": 5002,
    "VZWCR 1628-LFW": 5002,
    "VZWCR 2215-SO01":5002,
    "VZWCR 3433-CRSKRAKN":5002,
    "VZWCR 5488-CRFWAFED5G":5002,
    "VZWCR 6242-CRMBBFWA5G":5002,
    "VZWCR 8280-CRBEAST":5002,
    "VZWCR 8593-cybersol":5002,
    "Telegence_Beta":5011,
}

def funtion_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
        
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    # Route to appropriate endpoint handler
    if path == "/bulk_change_processor":
        result = bulk_change_processor(data)
    elif path == "/get_bulk_change_audit_trial_logs":
        result = get_bulk_change_audit_trial_logs(data)
    elif path == "/get_standard_iccid_msisdn_data":
        result = get_standard_iccid_msisdn_data(data)
    elif path == "/generate_combined_templates":
        result = generate_combined_templates(data)
    elif path == "/bulk_upload_all_change_types_from_excel":
        result = bulk_upload_all_change_types_from_excel(data)
    elif path == "/crossprovider_device_history_sync":
        result = crossprovider_device_history_sync(data)
    elif path == "/schedule_bulk_change_execution":
        result = schedule_bulk_change_execution(data)    
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


# Initialize SQS client once
sqs = boto3.client('sqs')

def get_sqs_url(service_provider,change_type,common_utils_database):
    '''
    Function to get the SQS URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The SQS URL if found, otherwise None.'''
    sqs_url=None
    sqs_details= common_utils_database.get_data(
    "bulk_change_provider_sqs", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["sqs_url"]
    )
    if not sqs_details.empty:
        sqs_url=sqs_details.iloc[0]['sqs_url']
        return sqs_url
    else:
        return sqs_url

def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None

    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit"]
    )
    logging.info('carrier_details',carrier_details)
    if not carrier_details.empty:
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        return carrier_api_url,carrier_limit,app_id,app_secret
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret

    
def bulk_change_processor(data):
    '''
    Function to prioritize bulk change requests based on the number of IDs provided.
    It sends the request to an SQS queue with a priority attribute based on the number of IDs.
    Args:
        data (dict): Request data containing user/tenant information and IDs.
    Returns:
    '''
    logging.info(f"Received data for priority processor: %s", data)
    start_time = time.time()
    ## Validate required fields
    change_type= data.get("change_type", "")
    service_provider = data.get("service_provider", "")
    bulk_change_id = data.get("bulk_change_id", "")
    username = data.get("username", "")
    created_by = data.get("created_by")
    parent_provider_name = data.get("parent_provider_name", "")

    # Check if required fields are present
    if not change_type or not service_provider:
        logging.error("Missing required fields: change_type or service_provider")
        return {"flag":False,"message": "change_type and service_provider are required fields"}
    # DB connections
    try:
        database = DB(data.get("db_name", ""), **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Request Initiated"
        )
    ## Validate tenant name and get tenant ID
    tenant_name = data.get("tenant_name", "")
    if not tenant_name:
        logging.error("Tenant name is required in the request data.")
        return {"flag":False,"message": "Tenant name is required."}
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    tenant_details = common_utils_database.get_data(
      "tenant", {"tenant_name": tenant_name}, ["id","parent_tenant_id"]
    )
    #"change_phone_number_frequency_setting"

    if not isinstance(tenant_details, pd.DataFrame) or tenant_details.empty:
        logging.error("Tenant ID not found or invalid response for tenant name: %s. Response: %s", tenant_name, tenant_details)
        return {"flag": False, "message": "Tenant ID not found."}

    tenant_id = int(tenant_details.iloc[0]['id'])
    parent_tenant_id=tenant_details['parent_tenant_id'].to_list()[0]
    #frequency_setting=tenant_details.iloc[0]['change_phone_number_frequency_setting']
    data["tenant_id"] = tenant_id
    data["parent_tenant_id"] = parent_tenant_id
    #data["frequency_setting"]=frequency_setting
    service_provider_data=database.get_data(
        "serviceprovider", {"service_provider_name": service_provider,"is_active":True}, ["id","integration_id","write_is_enabled"])
    if not service_provider_data.empty:
        service_provider_id = int(service_provider_data.iloc[0]['id'])
        integration_id = int(service_provider_data.iloc[0]['integration_id'])
        carrier_enabled=service_provider_data.iloc[0]["write_is_enabled"]

        data["service_provider_id"] = service_provider_id
        data["integration_id"] = integration_id
    else:
        logging.error("Service provider ID not found for service provider: %s", service_provider)
        return {"flag":False,"message": "Service provider ID not found."}
    # IDs from input
    ids = data.get('iccids') or data.get('msisdns') or []
    ##updating the bulk change request with uploaded count
    database.update_dict(
            'sim_management_bulk_change',
            {
                "uploaded": len(ids),
                "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            {'id': bulk_change_id}
        )
    # Validate IDs
    if not isinstance(ids, list):
        return {"error": "iccids/msisdns must be a list"}
    ##updating the status of the bulk change request to PROCESSING
    if bulk_change_id:
        logging.info("Updating status of bulk change request with ID: %s", bulk_change_id)
        # Update the status to PROCESSING
        database.update_dict(
                "sim_management_bulk_change",
                { "status": "PROCESSING"},
                {"id": bulk_change_id},
                
            )
    bulk_change_audit_action(
            data, common_utils_database,
            action=f"Request Validated"
        )
    bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number"]
        ).rename(columns={"subscriber_number": "msisdn"})
    msisdn_to_request_id = {}
    data_log=[]
    if not bulk_requests_df.empty:
      msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))

    if not carrier_enabled and change_type not in ["Archive","Change Customer Rate Plan","Edit Username/Cost Center","Assign Customer"]:
        logging.info(f"### Carrier Writes are disabled for this service provider {service_provider} ")
        database.update_dict(
                "sim_management_bulk_change",
                { "status": "ERROR"},
                {"id": bulk_change_id},
                
            )
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,"status_details":"Writes are disabled for this service provider",
                    "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
            and_conditions={"bulk_change_id": bulk_change_id}
          )
        for msisdn in bulk_requests_df["msisdn"].tolist():
          data_log.append({
              "bulk_change_id": bulk_change_id,
              "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
              "log_entry_description": "Update AMOP",
              "request_text": "Bulk Change Processer",
              "has_errors": True,
              "response_status": "ERROR",
              "response_text": "Writes are disabled for this service provider",
              "error_text": "Carrier writes are Disabled",
              "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
              "processed_by": created_by,
              "created_by": created_by,
              "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
              "is_deleted": False,
              "is_active": True,
            })
        database.insert_data(data_log, "sim_management_bulk_change_log")
        return {"flag":False,"message": f"Carrier Writes are disabled for this service provider {service_provider}"}
    if change_type == 'Assign Customer' and ('Telegence' in service_provider or 'Telegence' in parent_provider_name):
      data['msisdns'] = data.pop('iccids', '')
    #validating the sims
    if change_type not in ('Activate New Service','Line Sync'):
        data=validating_sims(data,database,common_utils_database)
    logging.info(f"Request after validation{data}")
    # Find the function name from registry
    if parent_provider_name:
        actions = function_registry.get(parent_provider_name, {}).get("actions", [])
    else:
        actions = function_registry.get(service_provider, {}).get("actions", [])
    #actions = function_registry.get(service_provider, {}).get("actions", [])
    matching_action = next(
        filter(lambda a: a["change_type"] == change_type, actions),
        None
    )
    function_name = matching_action["function_name"] if matching_action else None
    if not function_name:
        return {"flag":False,"message": f"No function found for service provider '{service_provider}' and change event type '{change_type}'."}
    logging.info("Function to call: %s", function_name)
    bulk_change_audit_action(
            data, common_utils_database,
            action=f"In Bulk Change Processor"
        )
    # get the container name based on  provider
    if parent_provider_name:
        container_name = container_mapping.get(parent_provider_name, None)
        port = port_mapping.get(parent_provider_name, None)
    else:
        container_name = container_mapping.get(service_provider, None)
        port = port_mapping.get(service_provider, None)

    if not container_name:
        logging.error(f"Container name not found for provider: {parent_provider_name} or {service_provider}")
        return {"flag":False,"message": f"Container name not found for provider:{parent_provider_name} or {service_provider}"}
    if not port:
        logging.error(f"port  not found for  provider:{parent_provider_name} or {service_provider}")
        return {"flag":False,"message": f"port not found for provider: {parent_provider_name} or {service_provider}"}
    ## Prepare the data to be sent to the container , update path with the function name
    data["path"] = f"/{function_name}"
    logging.info("Data to be sent to the container: %s", data)

    ##URL needs to be changed 
    url = f"http://{os.environ['EC2_HOST']}:{port}/{container_name}_BulkChange_Handler"
    # bulk_change_audit_action(
    #         data, common_utils_database,
    #         action=f"Request Forwarded to EC2 Container"
    #     )
    logging.info(f"Forwarding request to EC2 endpoint: {url}")
    ##call the container
    try:
        try:
            ##call the container with retries
            logging.info(f"Calling container with data: {data}")
            result=post_with_retries(url, data, retries=1)
            response={"flag": True, "message": "Request forwarded to EC2 successfully"}
            try:
                # End time calculation
                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                time_consumed = int(float(time_consumed))
                audit_data_user_actions = {
                    "service_name": "bulk_change_processor",
                    "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "created_by": username,
                    "time_consumed_secs": time_consumed,
                    "status": "Success - Request forwarded to EC2 route",
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": f'''Bulk Change request forwarded to EC2 route for service provider: {service_provider} 
                              and change type: {change_type} and bulk_change_id: {bulk_change_id}''',
                    "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### Audit logging failed: {e}")
            return response
        except Exception as e:
            logging.exception(f"HTTP forward failed{e}")
            response = {"flag": False, "error": "Forward to EC2 route failed", "details": str(e)}
            error_message = f"Error during bulk change processing: {str(e)}"
            error_type = str(type(e).__name__)
            try:
                # Log failure to error log table
                error_data = {
                    "service_name": "bulk_change_processor",
                    "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "error_message": error_message,
                    "error_type": error_type,
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": f"Error during bulk change processing for service provider: {service_provider} and change type: {change_type} and bulk_change_id: {bulk_change_id}",
                    "module_name": "Bulk Change",
                    "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
            except Exception as e:
                logging.exception(f"### Logging error to DB failed: {e}")
            return response
    except requests.RequestException as e:
        logging.exception("HTTP forward failed")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response={"flag": False, "error": "Forward to EC2 route failed", "details": str(e)}
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "bulk_change_processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change processing for service provider: {service_provider} and change type: {change_type} and bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
        return response
    


def post_with_retries(url, json, retries=1):
    '''
    main container caller function
    Args:
        url (str): The URL to send the POST request to.
        json (dict): The JSON data to include in the POST request.
        retries (int): Number of retry attempts in case of failure.
    '''
    delay = 1
    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(url, json=json, timeout=60)
            logging.info(f"#### bulk_change_processor to container api call response : {resp}")
            if resp.status_code < 400:
                return resp.json()
        except requests.RequestException:
            pass  # ignore and retry

        logging.warning("Attempt %d failed; retrying in %ds", attempt, delay)
        time.sleep(delay + random.uniform(0, 0.5))
        delay *= 2
    logging.error("All %d attempts failed", retries)
    return None  # After all retries fail

def validating_sims(data,database,common_utils_database):
    """
    Validates SIMs (ICCID or MSISDN) based on availability and active status.

    Args:
        data (dict): Request data containing 'iccids' or 'msisdns'.

    Returns:
        dict: Updated data with only validated SIMs.
    """
    logging.info(f"Received data for validating sims: %s", data)
    # Validate required fields
    iccids = data.get("iccids", [])
    msisdns = data.get("msisdns", [])
    tenant_id = data.get("tenant_id", None)
    bulk_change_id = data.get("bulk_change_id", None)
    service_provider_id=data.get("service_provider_id",None)
    try:
        # Determine which key to use for validation
        filter_key = "iccid" if iccids else "msisdn"
        values = iccids if iccids else msisdns

        if not values:
            return {"error": "No ICCIDs or MSISDNs provided for validation."}

        # Query only active SIMs matching the ICCIDs or MSISDNs
        filter_conditions = {"is_active": True, filter_key: values,"tenant_id":tenant_id,"service_provider_id":service_provider_id}
        df = database.get_data("sim_management_inventory", filter_conditions,['iccid','msisdn'])

        # Extract validated values
        validated = df[filter_key].tolist() if not df.empty else []
        invalid = list(set(values) - set(validated))
        #Keeping it disabled to avoid incorrect INVALID status and error counts 
        # if invalid:
        #      # Use update_dict with in_conditions to match multiple entries
        #     database.update_dict(
        #         "sim_management_bulk_change_request",
        #         {"status": "INVALID"},
        #         and_conditions={"bulk_change_id": bulk_change_id},  # optional pre-filter
        #         in_conditions={filter_key: invalid}
        #     )
        # ##updating the counts
        # database.update_dict(
        #         'sim_management_bulk_change',
        #         {
        #             "errors": len(invalid),
        #             "processed_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        #         },
        #         {'id': bulk_change_id}
        #     )
        # Replace original list in data
        data[filter_key + "s"] = validated
        if iccids:
            data["invalid_iccids"] = invalid
        else:
            data["invalid_msisdns"] = invalid
            invalid_ids_query = """
                SELECT id 
                FROM sim_management_bulk_change_request  
                WHERE bulk_change_id = %s 
                AND (subscriber_number IS NULL OR TRIM(subscriber_number) = '')
            """
            params = [bulk_change_id]

            # Execute the query
            invalid_ids_df = database.execute_query(invalid_ids_query, params=params)

            # Add to data if any invalid records are found
            if not invalid_ids_df.empty:
                data["invalid_ids"] = invalid_ids_df["id"].to_list()
        return data
    except Exception as e:
        logging.error("Error during SIM validation: %s", str(e))
        return data


    
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
           
    except Exception as e:
            logging.exception(f"### Error logging user actions: {e}")
            logging.info("User action audited successfully.")
    except Exception as e:
        logging.error(f"Error auditing user action: {e}")



def get_bulk_change_audit_trial_logs(data):
    """
    Retrieve audit-trial logs for a bulk change operation.

    If no audit records are found, returns a default entry
    indicating that the operation was processed in version 1.0.

    Parameters:
        data (dict): Dictionary with keys:
            db_name (str): Tenant's database name.
            tenant_name (str): Name of the tenant.
            z_access_token (str): Authentication token.
            client_id (str): Client identifier.
            Partner (str): Partner information.
            session_id (str, optional): Session ID (default: "client_call").
            bulk_change_id (int): ID of the bulk change.
            offset (int, optional): Pagination offset (default: 0).
            module_name (str, optional): Name of the module.
            username (str, optional): User requesting the operation.
            request_received_at (str, optional): Timestamp of request.

    Returns:
        dict: Response containing:
            flag (bool): Indicates operation success.
            message (str): Info about the fetch result.
            bulk_change_audit_data (list of dict):
                - Each dict has 'id' (int) and 'action' (str or None).
                - If empty, contains single record {'id': 1, 'action': 'Bulk Change Request was initiated in 1.0'}.
            recall_flag (bool): Reserved field for future use.
    """
    ## Fetching the required params
    logging.info(f"Request recieved for get_bulk_change_audit_trial_logs is :{data}")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    try:
        ##Common Utils Database Connection
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.exception(f"Exception while connecting to common utils database: {e}")
    complete_audit_data_dict=[{"id":1,"action":"Bulk Change Request Initiated"},{"id":2,"action":"Request Validated"},{"id":3,"action":"In Bulk Change Processor"},{"id":4,"action":"Bulk Change Process Initiated"},{"id":5,"action":"Processing With Carrier APIs"},{"id":6,"action":"Sync To 1.0 Tables"},{"id":7,"action":"Sync Finished"},{"id":8,"action":"Auditing"},{"id":9,"action":"Bulk Change Process Completed"}]
    bulk_change_id = data.get('list_view_data_id')
    if not bulk_change_id:
        response = {"flag": False, "message": "Bulk Change ID is missing"}
        return response
    try:
        bulk_change_audit_data=common_utils_database.get_data('bulk_change_auditing',{'bulk_change_id':str(bulk_change_id)},['action'],order={"id": "asc"})
        if not bulk_change_audit_data.empty:
            db_actions = {rec['action'] for rec in bulk_change_audit_data.to_dict(orient="records")}
            bulk_change_audit_data = [
                entry for entry in complete_audit_data_dict
                if entry['action'] in db_actions
            ]
        else:
            bulk_change_audit_data=[{'id': 1, 'action': 'Bulk Change Request Was Initiated in 1.0'}]
        response={"flag":True,"message":"Bulk Change Audit Trial fecthed successfully","bulk_change_audit_data":bulk_change_audit_data,"recall_flag":False,"complete_audit_data_dict":complete_audit_data_dict}
        try:
            audit_data_user_actions = {
                "module_name": "Bulk Change Processor",
                "created_by": username,
                "status": "True",
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "comments": f"bulk_change_audit logs proesseced for the bulk_change_id {bulk_change_id}",
                "service_name": "get_bulk_change_audit_trial_logs",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return response

    except Exception as e:
        logging.exception(f"Exception while fetching bulk change audit trial  data: {e}")
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_bulk_change_audit_trial_logs",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": "",
                "module_name": "Bulk Change Processor",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return {
            "flag": True,
            "message": "Unable to fetch bulk change audit trial data",
            "complete_audit_data_dict":complete_audit_data_dict,
            "bulk_change_audit_data":{},
            "recall_flag":False
        }

def get_standard_iccid_msisdn_data(data):
    '''
    Function to get standard ICCID and MSISDN data based on provided ICCIDs or MSISDNs.
    Args:
        data (dict): Request data containing 'iccids', 'msisdns', 'tenant
            _id', 'service_provider_name', and optional 'db_name'.
    Returns:
        dict: Response containing either 'msisdns' or 'iccids' based on input.
        If neither 'iccids' nor 'msisdns' are provided, returns an error
        message.
    '''
    logging.info(f"Received data for standardization: %s", data)
    ## Validate required fields
    iccids = data.get('iccids',None)
    msisdns = data.get('msisdns',None)
    iccids_imei_map = data.get('iccids_imei_map',None)
    msisdns_imei_map = data.get('msisdns_imei_map',None)
    tenant_name = data.get('tenant_name')
    service_provider_name = data.get('service_provider', None)
    iccid_ip_map = data.get('iccid_ip_map',None)
    change_type = data.get('change_type', "")

    try:
        database = DB(data.get("db_name", ""), **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}

    response = {"flag": True}  

    try:
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'

        tenant_details = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )
        if tenant_details.empty:
            logging.error("Tenant ID not found for tenant name: %s", tenant_name)
            return {"flag": False, "message": "Tenant ID not found."}

        tenant_id = int(tenant_details.iloc[0]['id'])
        sim_identifier_map = []

        # Block 1: Handle ICCIDs -> MSISDNs
        if iccids:
            logging.info(f"Fetching msisdns for iccids")
            sim_identifier_msisdn = database.get_data(
                "sim_management_inventory",
                {
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "service_provider_display_name": service_provider_name,
                    "iccid": iccids
                },
                ['iccid', 'msisdn']
            ).to_dict(orient="records")

            sim_identifier_map.extend(sim_identifier_msisdn)
            found_iccids = {row['iccid'] for row in sim_identifier_msisdn}
            for iccid in iccids:
                if iccid not in found_iccids:
                    sim_identifier_map.append({"iccid": iccid, "msisdn": iccid})

            msisdn_list = [row['msisdn'] for row in sim_identifier_map]
            response["msisdns"] = msisdn_list
            response["message_iccids"] = "Successfully fetched msisdns for the provided iccids."

        # Block 2: Handle MSISDNs -> ICCIDs
        if msisdns:
            logging.info(f"Fetching iccids for msisdns")
            sim_identifier_iccid = database.get_data(
                "sim_management_inventory",
                {
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "service_provider_display_name": service_provider_name,
                    "msisdn": msisdns
                },
                ['msisdn', 'iccid']
            ).to_dict(orient="records")
 
            sim_identifier_map.extend(sim_identifier_iccid)
            found_msisdns = {row['msisdn'] for row in sim_identifier_iccid}
            for msisdn in msisdns:
                if msisdn not in found_msisdns:
                    sim_identifier_map.append({"msisdn": msisdn, "iccid": msisdn})
 
            iccid_list = [row['iccid'] for row in sim_identifier_map]
            msisdn_list = [row['msisdn'] for row in sim_identifier_map]
            if 'telegence' in service_provider_name.lower() and  change_type.lower() == "archive":
                response["msisdns"] = msisdn_list
            else :
                response["iccids"] = iccid_list
            response["message_msisdns"] = "Successfully fetched iccids for the provided msisdns."
 
        # Block 3: ICCIDs -> IMEI
        if iccids_imei_map:
            iccid_keys = list(iccids_imei_map.keys())
            sim_identifier_msisdn = database.get_data(
                "sim_management_inventory",
                {
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "service_provider_display_name": service_provider_name,
                    "iccid": iccid_keys
                },
                ['iccid', 'msisdn']
            ).to_dict(orient="records")
            iccid_to_msisdn = {row['iccid']: row['msisdn'] for row in sim_identifier_msisdn}

            final_map = {}
            for iccid, imei in iccids_imei_map.items():
                msisdn = iccid_to_msisdn.get(iccid, iccid)
                final_map[msisdn] = imei

            response["msisdns_imei_map"] = final_map

        # Block 4: MSISDNs -> IMEI
        if msisdns_imei_map:
            msisdn_keys = list(msisdns_imei_map.keys())
            sim_identifier_iccid = database.get_data(
                "sim_management_inventory",
                {
                    "is_active": True,
                    "tenant_id": tenant_id,
                    "service_provider_display_name": service_provider_name,
                    "msisdn": msisdn_keys
                },
                ['msisdn', 'iccid']
            ).to_dict(orient="records")
            msisdn_to_iccid = {row['msisdn']: row['iccid'] for row in sim_identifier_iccid}

            final_map = {}
            for msisdn, imei in msisdns_imei_map.items():
                iccid = msisdn_to_iccid.get(msisdn, msisdn)
                final_map[iccid] = imei

            response["iccids_imei_map"] = final_map

        # Block 5: ICCID/IP map
        if iccid_ip_map:
            keys_are_iccids = bool(iccids)  # True if iccids were provided
            keys_list = list(iccid_ip_map.keys())

            if keys_are_iccids:
                sim_identifier_msisdn = database.get_data(
                    "sim_management_inventory",
                    {
                        "is_active": True,
                        "tenant_id": tenant_id,
                        "service_provider_display_name": service_provider_name,
                        "iccid": keys_list
                    },
                    ['iccid', 'msisdn']
                ).to_dict(orient="records")
                iccid_to_msisdn = {row['iccid']: row['msisdn'] for row in sim_identifier_msisdn}
                final_map = {iccid_to_msisdn.get(k, k): v for k, v in iccid_ip_map.items()}
            else:
                sim_identifier_iccid = database.get_data(
                    "sim_management_inventory",
                    {
                        "is_active": True,
                        "tenant_id": tenant_id,
                        "service_provider_display_name": service_provider_name,
                        "msisdn": keys_list
                    },
                    ['msisdn', 'iccid']
                ).to_dict(orient="records")
                msisdn_to_iccid = {row['msisdn']: row['iccid'] for row in sim_identifier_iccid}
                final_map = {msisdn_to_iccid.get(k, k): v for k, v in iccid_ip_map.items()}

            response["iccids_ip_map"] = final_map
            response["message_ip_map"] = "Successfully mapped ICCIDs/MSISDNs to IPs."

        return response

    except Exception as e:
        logging.error("Error while fetching the standard msisdn and iccid: %s", e)
        response={"flag": False, "message": "Fetching Failed", "details": str(e)}
        return response



#######################functions by kumar and puja ##############################

##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs
  
def load_integration_authentication_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_integration_authentication_id.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_integration_authentication_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_integration_authentication_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_integration_authentication_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs

def get_integration_authentication_id_by_unique_name(json_data, tenant_name):
    """
    Fetches the integration authentication ID for a given tenant from JSON data.
    
    Args:
        json_data (dict): JSON data containing tenant integration authentication information
        tenant_name (str): Name of the tenant to look up
        
    Returns:
        int or None: The integration authentication ID if found, None otherwise
    """
    logging.info(f"### get_integration_authentication_id_by_unique_name Tenant Name: {tenant_name}")
    return json_data.get(tenant_name, {}).get("INTEGRATION_AUTHENTICATION_ID", None)

def get_integration_id_by_unique_name(json_data, tenant_name, unique_name):
    """Fetches 'main_name' of a provider based on its unique name."""
    return json_data.get(tenant_name, {}).get(unique_name, {}).get("integration_id", None)

def get_provider_ids(json_data, tenant_name, provider_names):
    """Fetches only the IDs of specified providers for a given tenant."""
    return [
        details["id"]
        for provider_name, details in json_data.get(tenant_name, {}).items()
        if provider_name in provider_names
    ]
def capitalize_columns(df):
    """Capitalizes the column names of the DataFrame."""
    df.columns = df.columns.str.replace("_", " ").str.title()
    return df

#   download template code
#helper functions
def sorted_unique(data_list):
    """Helper function to sort a list and remove any None values."""
    return sorted(filter(None, set(data_list)))


def apply_strict_date_validation(worksheet, column_name, column_list):
    """
    Apply strict date validation to a column using xlsxwriter.
    
    Args:
        worksheet: xlsxwriter worksheet object
        column_name: Name of the column to validate
        column_list: List of all columns in the sheet
    """
    if column_name in column_list:
        try:
            col_idx = column_list.index(column_name)  # 0-based for xlsxwriter
            
            # Create date validation for xlsxwriter
            validation = {
                'validate': 'date',
                'criteria': 'between',
                'minimum': datetime(1900, 1, 1),
                'maximum': datetime(2099, 12, 31),
                'error_title': 'Invalid Date Format',
                'error_message': 'Enter date in strict YYYY-MM-DD format only. Example: 2025-12-02',
                'input_title': 'Date Format',
                'input_message': 'Enter date as YYYY-MM-DD (e.g., 2025-12-02)'
            }
            
            # Apply validation - xlsxwriter uses 0-based indices
            # data_validation(first_row, first_col, last_row, last_col, options)
            worksheet.data_validation(1, col_idx, 1000000, col_idx, validation)
            logging.info(f"Applied date validation to column {column_name}")
            
        except Exception as e:
            logging.error(f"Error applying date validation to {column_name}: {str(e)}")


def add_data_validation(worksheet, column_letter, options, 
                                   allow_blank=True,workbook=None):
    """
    xlsxwriter data validation that handles long lists properly.
    Always shows all options, regardless of character count.
    
    Args:
        worksheet: xlsxwriter worksheet object
        column_letter: Excel column letter (e.g., 'A', 'B')
        options: List of dropdown options
        workbook: REQUIRED - xlsxwriter workbook object
        allow_blank: Whether to allow blank cells
        max_rows: Maximum rows to apply validation to
    """
    if not options:
        return None
    
    if not workbook:
        logging.error("Workbook parameter is REQUIRED for xlsxwriter data validation")
        return None
    
    # Convert column letter to 0-based column index
    col_idx = ord(column_letter.upper()) - ord('A')
    
    # Clean options
    options_str = [str(opt).strip() for opt in options if opt is not None and str(opt).strip()]
    
    if not options_str:
        return None
 
    max_rows=1000000
    # Generate unique name
    sheet_name = worksheet.get_name()
    col_name = column_letter   # e.g. "A"
    timestamp = int(time.time())
    unique_hash = hashlib.md5(f"{sheet_name}_{col_name}_{timestamp}".encode()).hexdigest()[:8]
    range_name = f"HIDDEN_{unique_hash}"
    hidden_sheet_name = f"_hidden_{unique_hash}"
    workbook.define_name(range_name,
        f"='{sheet_name}'!${col_name}:${col_name}"
    )    
    try:
        # Add hidden sheet
        hidden_sheet = workbook.add_worksheet(hidden_sheet_name)
        hidden_sheet.hide()  # Hide the sheet
        
        # Write ALL options to hidden sheet
        for i, option in enumerate(options_str):
            hidden_sheet.write(i, 0, option)
        
        # Create named range
        range_name = f'DV_{unique_hash}'
        workbook.define_name(range_name, f"={hidden_sheet_name}!$A$1:$A${len(options_str)}")
        
        # Setup validation
        validation = {
            'validate': 'list',
            'source': f'={range_name}',
            'error_title': 'Invalid Entry',
            'error_message': 'Please select from the dropdown list',
            'input_title': '',
            'input_message': ''
        }
        
        if allow_blank:
            validation['ignore_blank'] = True
        
        # Apply validation
        # xlsxwriter: data_validation(first_row, first_col, last_row, last_col, options)
        worksheet.data_validation(1, col_idx, max_rows, col_idx, validation)
        
        return hidden_sheet_name
        
    except Exception as e:
        logging.error(f"Error creating data validation: {str(e)}")
        
        # Fallback: Use inline list if possible
        formula_str = '"' + ','.join(options_str) + '"'
        if len(formula_str) <= 255:
            validation = {
                'validate': 'list',
                'source': formula_str,
                'error_title': 'Invalid Entry',
                'error_message': 'Please select from the dropdown list'
            }
            if allow_blank:
                validation['ignore_blank'] = True
            worksheet.data_validation(1, col_idx, max_rows, col_idx, validation)
            return "INLINE_FALLBACK"
        
        return None


def apply_iccid_msisdn_validation(worksheet, column_name, column_list, workbook):
    """
    Apply ICCID or MSISDN validation to a column using xlsxwriter,
    and force the column to text format to prevent scientific notation.
    
    Args:
        worksheet: xlsxwriter worksheet object
        column_name: Name of the column to validate ('ICCID' or 'MSISDN')
        column_list: List of all columns in the sheet
        workbook: xlsxwriter workbook object (required for text format)
    """
    if column_name in column_list:
        try:
            col_idx = column_list.index(column_name)  # 0-based index
            excel_col_letter = chr(65 + col_idx)  # Convert to Excel letter

            # Create a text format to prevent scientific notation
            text_format = workbook.add_format({'num_format': '@'})
            worksheet.set_column(col_idx, col_idx, 20, text_format)  # width 20, format text

            # Updated validation: Check if the cell value is a valid digit string (can be converted to number) and meets length
            if column_name == "ICCID":
                validation = {
                    'validate': 'custom',
                    'value': f'AND(NOT(ISERROR(VALUE({excel_col_letter}2))), LEN({excel_col_letter}2)>=14, LEN({excel_col_letter}2)<=22)',
                    'error_title': 'Invalid ICCID Format',
                    'error_message': 'ICCID must be 14-22 digits (numbers only)',
                    'input_title': 'ICCID Format',
                    'input_message': 'Enter ICCID as 14-22 digits (numbers only)',
                    'ignore_blank': True
                }
            elif column_name == "MSISDN":
                validation = {
                    'validate': 'custom',
                    'value': f'AND(NOT(ISERROR(VALUE({excel_col_letter}2))), LEN({excel_col_letter}2)>=10, LEN({excel_col_letter}2)<=18)',
                    'error_title': 'Invalid Subscriber Number',
                    'error_message': 'Subscriber Number must be 10-18 digits (numbers only)',
                    'input_title': 'Subscriber Number Format',
                    'input_message': 'Enter Subscriber Number as 10-18 digits (numbers only)',
                    'ignore_blank': True
                }
            else:
                return

            # Apply validation from row 2 to row 1,000,000
            worksheet.data_validation(1, col_idx, 1000000, col_idx, validation)
            logging.info(f"Applied {column_name} validation and text format to Devices sheet")

        except Exception as e:
            logging.error(f"Error applying {column_name} validation: {str(e)}")


#without smaple data three sheet
def generate_combined_templates(data):
    """
    Generates a combined Excel file with multiple templates for "All Change Type" module.
    This function creates sheets for all change type
    in a single Excel file.
    
    Parameters:
        data (dict): A dictionary containing request data including tenant and service provider info.
        
    Returns:
        dict: A response dictionary with blob data for the combined templates.
    """
    try:
        logging.info(f"### generate_combined_templates data receieved : {data}")
        # Get required parameters from data
        tenant_database = data.get('db_name')
        tenant_name = data.get('tenant_name')
        access_token=data.get('access_token')
        service_provider = data.get('service_provider')
        role_name = data.get("role_name","Super Admin")
        username=data.get("username","")
        service_provider_id=data.get("service_provider_id","")
        if not access_token:
            readme_flag=False
        else:
            readme_flag=True
        service_provider_change_type_data = []
        template_columns = []
        bulk_customer_columns = [] 
        bulk_change_columns = []
        archive_columns = []  
        line_columns = [] 
        cost_user_columns = [] 
        change_iccid_columns=[]
        bulk_carrier_columns=[]
        ip_columns=[]
        ppu_columns=[]
        reset_columns=[]
        phone_columns=[]
        update_feature_codes_columns=[]
        send_sms_columns=[]
        refresh_a_line_columns=[]
        all_possible_columns=[]
        private_network_range_table=None
        private_network_range_table_role=None
        bulk_communication_columns = [] 
        comm_plan_flag = False
        comm_plan_df = pd.DataFrame()
        #database connection
        try:
            # Database connections
            database = DB(tenant_database, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        except Exception as e:
            logging.exception(f"Error while connecting database{e}")
        def apply_header_formatting(worksheet, columns, workbook):
            """Apply gray background and border to header row"""
            header_format = workbook.add_format({
                'bold': True,
                'bg_color': '#D3D3D3',
                'border': 1,
                'align': 'center',
                'valign': 'vcenter'
            })
            for col_num, value in enumerate(columns):
                worksheet.write(0, col_num, value, header_format)
        integration_authentication_json_data = load_integration_authentication_json()
        integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)

        tenant_data = common_utils_database.get_data(
            table_name="tenant",
            condition={"tenant_name": tenant_name},
            columns=["id", "billing_platform_flag", "parent_tenant_id"]
        )
        tenant_id = int(tenant_data["id"].iloc[0])
        parent_tenant_id = tenant_data["parent_tenant_id"].iloc[0]
        billing_platform_flag = tenant_data["billing_platform_flag"].iloc[0]

        # Determine integration ID
        if not integration_authentication_id and parent_tenant_id:
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
                parent_tenant_data = common_utils_database.get_data(
                "tenant", {"id": parent_tenant_id},
                ["tenant_name"]
                )
                parent_tenant_name = parent_tenant_data["tenant_name"].iloc[0]
                integration_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)
        else:
            integration_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
        # Fetch all active mappings
        sp_ct_data = database.get_data(
            "sim_management_bulk_change_type_service_provider",
            {"is_active": True},
            ["change_type", "service_provider"],
        ).to_dict(orient="records")
        
        # First sort normally
        sp_ct_data = sorted(
            sp_ct_data,
            key=lambda x: x["service_provider"] or ""
        )
        
        # Remove "Change Carrier Rate Plan" if user not Super/Partner Admin
        if role_name not in ("Super Admin", "Partner Admin") or parent_tenant_id:
            sp_ct_data = [
                item for item in sp_ct_data
                if item["change_type"] != "Change Carrier Rate Plan"
            ]
        # filter by service provider
        if service_provider:
            # Only keep change_types where service_provider matches
            service_provider_change_type_data = list(dict.fromkeys(
                item["change_type"]
                for item in sp_ct_data
                if item["service_provider"] == service_provider
            ))
        
        ##handling if service provider name not comes
        if not service_provider_id:
            service_provider_id_feature=database.get_data('serviceprovider',{"is_active":True,"service_provider_name":service_provider},["id"])
            if service_provider_id_feature is None or service_provider_id_feature.empty:
                logging.warning(f"Service provider not found in DB: {service_provider}")
                service_provider_id_feature = None  
            else:
                service_provider_id_feature = int(service_provider_id_feature["id"].iloc[0])
        # fetch provider id
        try:
            json_data = load_json()

            service_provider_ids = get_provider_ids(
                json_data, tenant_name, ["Telegence"]
            )
            service_provider_id = service_provider_ids[0] if service_provider_ids else None
        except Exception as e:
            logging.error(f"Error loading JSON: {e}")
            json_data = {}                 
            service_provider_id = None 
        #load provider based json
        try:
            config = load_json()
            service_provider_mappings = config.get("ServiceProviderMappings", {})
            service_provider_lower = service_provider.lower()

            # Find provider configuration dynamically
            provider_config = None
            for provider_key, config_data in service_provider_mappings.items():
                if provider_key.lower() == "default":
                    continue
                unique_names = config_data.get("unique_names", [])
                if any(name.lower() == service_provider_lower for name in unique_names):
                    provider_config = config_data
                    break
            
            # Use default if no specific provider found
            if not provider_config:
                provider_config = service_provider_mappings.get("default", {})
                
        except Exception as e:
            logging.error(f"Error loading service provider mappings: {str(e)}")
            provider_config = service_provider_mappings.get("default", {})
        template_columns = provider_config.get("template_columns", ["Target Status"])
        logging.info(f"template_columns:{template_columns}")
        payload_template = provider_config.get("payload_template", {})
        request_template = payload_template.get("Request", {})
        # Get provider-specific template columns for Device Status
        required_dataframes = provider_config.get("dataframes", [])
        logging.info(f"required_dataframes:{required_dataframes}")
        sample_data = provider_config.get("sample_data", {})
        # Store all change types in a set for faster lookup
        change_types_set = set(service_provider_change_type_data)
        # Helper function to check if any change type is present
        def has_any_change_type(target_types):
            return bool(change_types_set.intersection(target_types))

        # Check and fetch data based on change types
        # 1. Private Static IP or Activate New Service
        if has_any_change_type({"Change Private Static IP Address", "Activate New Service"}):
            result = get_pdp_apn(service_provider,database)
            pdp_df = result["pdp_df"]
            apn_df = result["apn_df"]
            private_network_range_table_role = result["private_network_range_table_role"]
        # 2. Multiple change types need rate plan data
        if has_any_change_type({"Change Private Static IP Address", "Activate New Service", "Update Device Status", "Change Carrier Rate Plan", "Reset Voicemail Password"}):
            result = get_rate_plan(database,service_provider,service_provider_change_type_data,tenant_id,username,common_utils_database,role_name,readme_flag)
            customer_rate_plan_code_df = result["customer_rate_plan_code_df"]
            active_customer_rate_plan_code_df = result["active_customer_rate_plan_code_df"]
            carrier_rate_plan_df = result["carrier_rate_plan_df"]
            billing_account_data = result["billing_account_data"]
            private_network_range_table=result["private_network_range_table"]
        # 3. Change types need customer rate plan
        if has_any_change_type({"Change Customer Rate Plan", "Change ICCID/IMEI"}):
            result = get_customer_rate_plan(tenant_id, database, service_provider)
            rate_plan_df=result["rate_plan_df"]
        # 4. Change types need state data
        if has_any_change_type({"Update Device Status", "Update PPU address"}):
            result= get_state_data()
            state_df=result["state_df"]

        # 5. Change types need rate pool
        if has_any_change_type({"Change ICCID/IMEI", "Change Customer Rate Plan", "Assign Customer"}):
            result = get_rate_pool(database, tenant_id, service_provider)
            rate_pool_df=result["rate_pool_df"]
        # 6. Change types need customer name
        if has_any_change_type({"Change Customer Rate Plan", "Assign Customer"}):
            result= get_customer(role_name,billing_platform_flag,integration_id,tenant_id,service_provider_change_type_data,database,tenant_name,common_utils_database)
            customer_name_df=result["customer_name_df"]
        # 7. Change types need feature codes
        if has_any_change_type({"Activate New Service", "Update Features"}):
            result= get_feature_code(service_provider_id,service_provider,service_provider_change_type_data,database,service_provider_id_feature)
            soc_codes=result["soc_codes"]
            feature_code_df=result["feature_code_df"]
        # Create an Excel writer to combine multiple sheets
        bio = BytesIO()
        with pd.ExcelWriter(bio, engine='xlsxwriter') as writer:
            pd.DataFrame().to_excel(writer, sheet_name='Sample Data', index=False)
            assign_customer_ws=None
            device_status_ws=None
            carrier_rate_plan_ws=None
            customer_rate_plan_ws=None
            devices_columns = ["ICCID", "MSISDN","IMEI","IP Address"]
            # Create devices sheet 
            devices_result_df = pd.DataFrame(columns=devices_columns)
            # Create sample data
            devices_sample = {
                "ICCID": "12345678901234567890",
                "MSISDN": "1216156118",
                "IMEI":"12345676543345",
                "IP Address":"10.96.72.0"
            }
            devices_sample_df = pd.DataFrame([devices_sample])
            devices_sample_df = capitalize_columns(devices_sample_df)
            
            devices_result_df.to_excel(writer, sheet_name='Devices', index=False) 
                
            # Get the workbook and worksheet
            workbook = writer.book
            devices_ws = writer.sheets['Devices']
            apply_header_formatting(devices_ws, devices_columns, workbook)
            arc_width=devices_ws.set_column(0, len(archive_columns) - 1, 20)
            apply_iccid_msisdn_validation(devices_ws, "ICCID", devices_columns,workbook)
            apply_iccid_msisdn_validation(devices_ws, "MSISDN", devices_columns,workbook)
            # Fetch ip address range dataframe based on role
            if role_name not in ('Super Admin', 'Partner Admin'):
                private_network_range_table=private_network_range_table 
            else:
                private_network_range_table=private_network_range_table_role 
            # Create a NEW worksheet for ip address range
            if private_network_range_table is not None and not private_network_range_table.empty:
                try:
                    # Create the new sheet with DataFrame data
                    private_network_range_table.to_excel(writer, sheet_name='IP Address Range', index=False)
                    
                    # Get the worksheet object
                    ip_range_ws = writer.sheets['IP Address Range']
                    ip_range_columns = private_network_range_table.columns.tolist()
                    apply_header_formatting(ip_range_ws, ip_range_columns, workbook)

                    ip_range_ws.set_column("A:C", 25)                         
                    apn_options = private_network_range_table["APN"].dropna().unique().tolist()
                    apn_options = [str(opt) for opt in apn_options if opt is not None]
                    
                    if apn_options:
                        apn_col_letter = 'A'  # APN is in column A
                        add_data_validation(ip_range_ws, apn_col_letter, apn_options, workbook=workbook)
                                                
                except Exception as e:
                    logging.error(f"Error creating IP Address Range sheet: {str(e)}")
            else:
                # Create empty sheet if no data
                empty_df = pd.DataFrame(columns=["APN", "PDP", "IP Range"])
                empty_df.to_excel(writer, sheet_name='IP Address Range', index=False)
            if "Activate New Service" in service_provider_change_type_data : 
                logging.info("Generating activate new service template...")
                # Define columns for Bulk Change template - First sheet
                bulk_change_columns = [
                    "Billing Account Number",
                    "Rate Plan Code",
                    "Feature Codes",
                    "Rate Plan Group",
                    "Rate Pool",
                    "Assign Customer",
                    "Private Static APN",
                    "PDP Name",
                    "Subscriber First Name",
                    "Subscriber Last Name",
                    "Street Number",
                    "Street Direction",
                    "Street Name",
                    "City",
                    "State",
                    "Zip"
                ]
                if role_name in ('Super Admin', 'Partner Admin'):
                    rate_plan_code_index = bulk_change_columns.index("Rate Plan Code")
                    bulk_change_columns.insert(rate_plan_code_index + 1, "Customer Rate Plan")
                # Create main template sheet for Bulk Change - with some empty rows
                bulk_change_df = pd.DataFrame(columns=bulk_change_columns)
                # Add some empty rows for data entry
                for i in range(1):  
                    bulk_change_df.loc[i] = [""] * len(bulk_change_columns)
                
                # Create sample data for Bulk Change
                bulk_change_sample_dict = {
                    "Billing Account Number": "287353909490",
                    "Rate Plan Code": "10GB Mobile Select for GM Vehicle 4G LTE -- MBSV10GCC",
                    "Feature Codes": "APEX 100Mbps -- APEX100",
                    "Rate Plan Group": "G332540494",
                    "Rate Pool": "B287256845357RCKPOOL",
                    "Assign Customer": "3M Logistics -- 300007745 -- RevIO",
                    "Private Static APN": "Creefcc1.mcs",
                    "PDP Name": "CREEFCC1E1",
                    "Subscriber First Name": "User",
                    "Subscriber Last Name": "Test", 
                    "Street Number": "123",
                    "Street Direction": "North",
                    "Street Name": "Main Street",
                    "City": "Los Angeles",
                    "State": "CA",
                    "Zip": "90001"
                }
                if role_name in ("Super Admin", "Partner Admin"):
                    items = list(bulk_change_sample_dict.items())
                    idx = [i for i, (k, _) in enumerate(items) if k == "Rate Plan Code"][0] + 1

                    bulk_change_sample_dict = dict(
                        items[:idx] +
                        [("Customer Rate Plan", "10GB Data Device 5G - No Tether - Reeves -- MSBAN1GM5")] +
                        items[idx:]
                    )

                # Create sample DataFrames
                bulk_change_sample_df = pd.DataFrame([bulk_change_sample_dict])
                
                # Fetch data for dropdowns
                revio_customers_df = None
                customer_rate_pool_group_df = None

                #1.fetch rate plan - at top
                #2.fetch feature code- at top
                # 3. Fetch Rate Plan Group (Customer Rate pool Group),4.rate pool
                customer_rate_pool_group_df_1 = database.get_data(
                    "mobility_device_usage_aggregate",
                    {
                        "is_active": True,
                        "service_provider": service_provider
                    },
                    ["data_group_id","pool_id"]
                )               
                # Apply DISTINCT in Python
                if customer_rate_pool_group_df_1 is not None and not customer_rate_pool_group_df_1.empty:
                    customer_rate_pool_group_df = customer_rate_pool_group_df_1.drop_duplicates(subset=["data_group_id"])
                    rate_pool_df1 = customer_rate_pool_group_df_1.drop_duplicates(subset=["pool_id"])
                if customer_rate_pool_group_df_1 is not None and not isinstance(customer_rate_pool_group_df_1, bool) and not customer_rate_pool_group_df_1.empty:
                    customer_rate_pool_group_df = pd.DataFrame({"Rate Plan Group": sorted_unique(customer_rate_pool_group_df_1["data_group_id"].to_list())})
                    rate_pool_list = sorted_unique(customer_rate_pool_group_df_1["pool_id"].to_list())
                    rate_pool_df1 = pd.DataFrame({"Rate Pool": rate_pool_list})

                else:
                    customer_rate_pool_group_df = pd.DataFrame(columns=["Rate Plan Group"])
                    rate_pool_df1 = pd.DataFrame(columns=["Rate Pool"])
                #5.fetch customer name
                # ---- Fetch RevIO customers 
                df_1 = database.get_data(
                    "revcustomer",
                    {
                        "is_active": True,
                        "tenant_id": tenant_id,
                        "integration_authentication_id": integration_authentication_id
                    },
                    ["customer_name", "rev_customer_id"]
                )
                if df_1 is not None and not df_1.empty:
                    df_1 = df_1.copy()
                    df_1["customer_name"] = (
                        df_1["customer_name"].astype(str)

                    )
                else:
                    df_1 = pd.DataFrame(columns=["customer_name"])

                # ---- Fetch BP customers ONLY if billing_platform_flag ----
                df_2 = pd.DataFrame(columns=["customer_name"])
                if billing_platform_flag:
                    df_2 = database.get_data(
                        "customers",
                        {
                            "tenant_id": tenant_id,
                            "is_active": True,
                            "billing_platform_flag": True
                        },
                        ["customer_name", "id"]
                    )
                    if df_2 is not None and not df_2.empty:
                        df_2["customer_name"] = (
                            df_2["customer_name"].astype(str)
                        )
                    else:
                        df_2 = pd.DataFrame(columns=["customer_name"])
                # ---- Combine 
                df = pd.concat([df_1, df_2], ignore_index=True)

                if not df.empty:
                    revio_customers_df = pd.DataFrame({
                        "Assign Customer": sorted(df["customer_name"].unique().tolist())
                    })
                else:
                    revio_customers_df = pd.DataFrame(columns=["Assign Customer"])

                # Write Bulk Change sheets
                bulk_change_df.to_excel(writer, sheet_name='Activate New Service', index=False)
                # Get the workbook after writing
                workbook = writer.book
                # Add data validation to Bulk Change sheet
                bulk_change_ws = writer.sheets['Activate New Service']
                apply_header_formatting(bulk_change_ws, bulk_change_columns, workbook)

                bulk_change_width=bulk_change_ws.set_column(0, len(bulk_change_columns) - 1, 27)

                # Map columns to their indices (0-based for Python, 1-based for Excel)
                column_mapping = {col: idx + 1 for idx, col in enumerate(bulk_change_columns)}

                # 1. Rate Plan Code
                # -------- Rate Plan Code (ALL ROLES) --------
                
                if role_name in ("Super Admin", "Partner Admin"):
                    if carrier_rate_plan_df is not None and not carrier_rate_plan_df.empty:
                        rate_plan_code_options = sorted_unique(
                            carrier_rate_plan_df.iloc[:, 0].tolist()
                        )
                    else:
                        rate_plan_code_options = []   
                else:
                    if customer_rate_plan_code_df is not None and not customer_rate_plan_code_df.empty:
                        rate_plan_code_options = sorted_unique(
                            customer_rate_plan_code_df.iloc[:, 0].tolist()
                        )
                    else:
                        rate_plan_code_options = []

                # 2. Feature Codes -unique column name  
                if feature_code_df is not None and not feature_code_df.empty:
                    feature_options = sorted_unique(feature_code_df.iloc[:, 0].tolist())  
                else:
                    feature_options = []

                if revio_customers_df is not None and not revio_customers_df.empty:
                    customer_options = sorted_unique(revio_customers_df.iloc[:, 0].tolist())  
                else:
                    customer_options = []

                # Then when calling add_data_validation_unique_unique, pass these unique lists:
                if rate_plan_code_options:
                    col_idx = column_mapping["Rate Plan Code"]
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(bulk_change_ws, col_letter, rate_plan_code_options,workbook=workbook)
                # -------- Customer Rate Plan (ONLY Super Admin / Partner Admin) --------
                if role_name in ("Super Admin", "Partner Admin"):
                    if active_customer_rate_plan_code_df is not None and not active_customer_rate_plan_code_df.empty:
                        customer_rate_plan_options = sorted_unique(active_customer_rate_plan_code_df.iloc[:, 0].tolist()) 
                    else:
                        customer_rate_plan_options = []
                        
                    if customer_rate_plan_options:
                        col_idx = column_mapping["Customer Rate Plan"]
                        col_letter = get_column_letter(col_idx)
                        add_data_validation(
                            bulk_change_ws,
                            col_letter,
                            customer_rate_plan_options,
                            workbook=workbook
                        )
                    
                if feature_options:
                    col_idx = column_mapping["Feature Codes"]
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(bulk_change_ws, col_letter, feature_options,workbook=workbook)

                if customer_options:
                    col_idx = column_mapping["Assign Customer"]
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(bulk_change_ws, col_letter, customer_options,workbook=workbook)

                # 3. Add dropdown for Rate Plan Group (Column D)
                if customer_rate_pool_group_df is not None and not customer_rate_pool_group_df.empty:
                    rate_group_options = customer_rate_pool_group_df["Rate Plan Group"].tolist()
                    col_idx = column_mapping["Rate Plan Group"]
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(bulk_change_ws, col_letter, rate_group_options,workbook=workbook)

                # 4. Add dropdown for Rate Pool (Column E)
                if rate_pool_df1 is not None and not rate_pool_df1.empty:
                    rate_pool_options = rate_pool_df1["Rate Pool"].tolist()
                    col_idx = column_mapping["Rate Pool"]
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(bulk_change_ws, col_letter, rate_pool_options,workbook=workbook)

                # 6. Add dropdown for Private Static APN (Column G)
                if apn_df is not None and not apn_df.empty:
                    apn_options = apn_df["Private Static APN"].tolist()
                    col_idx = column_mapping["Private Static APN"]
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(bulk_change_ws, col_letter, apn_options,workbook=workbook)

                # 7. Add dropdown for PDP Name (Column H)
                if pdp_df is not None and not pdp_df.empty:
                    pdp_options = pdp_df["PDP Name"].tolist()
                    col_idx = column_mapping["PDP Name"]
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(bulk_change_ws, col_letter, pdp_options,workbook=workbook)
                # 8. Add dropdown for State (Column O) - Only codes as requested
                if state_df is not None and not state_df.empty:
                    state_options = state_df["Code"].tolist()
                    col_idx = column_mapping["State"]
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(bulk_change_ws, col_letter, state_options,workbook=workbook)
            if "Archive" in service_provider_change_type_data:
                logging.info("Generating archive template...")
                archive_columns=["Save Changes"]
                archive_result_df = pd.DataFrame(columns=archive_columns)
                archive_sample={"Save Changes":"True"}
                archive_sample_df = pd.DataFrame([archive_sample])
                archive_sample_df = capitalize_columns(archive_sample_df)
                
                archive_result_df.to_excel(writer, sheet_name='Archive', index=False) 
                    
                # Get the workbook and worksheet
                workbook = writer.book
                archive_ws = writer.sheets['Archive']
                apply_header_formatting(archive_ws, archive_columns, workbook)

                arc_width=archive_ws.set_column(0, len(archive_columns) - 1, 20)
                # create save changes 
                col_idx = archive_columns.index("Save Changes") + 1
                col_letter = get_column_letter(col_idx)
                add_data_validation(archive_ws, col_letter, ["True", "False"],workbook=workbook)
                logging.info("Archive sheet created with plain ICCID and MSISDN columns")
            if "Assign Customer" in service_provider_change_type_data:
                logging.info("Generating Assign Customer template...")
               
                # Define ALL possible columns
                all_possible_columns = [
                    "Billing Customer",
                    "Create Service/Product",
                    "Billing Provider",
                    "Service Type",
                    "Billing Product",
                    "Billing Package",
                    "Rate",
                    "Prorate",
                    "Effective Date",
                    "Use Carrier Activation",
                    "Product Description",
                    "Customer Pool",
                    "Customer Rate Plan"
                ]
 
               
                # Columns that should ALWAYS be displayed
                always_display_columns = [
                    "Billing Customer",
                    "Product Description",
                    "Customer Pool",
                    "Customer Rate Plan"
                ]
               
                assign_customer_sample = {
                    "Billing Customer": "3M Logistics -- 300007745 -- RevIO",
                    "Customer Rate Plan": "1--Test",
                    "Effective Date": "YYYY-MM-DD",
                    "Customer Pool": "CrossTest--101",
                    "Prorate": "True",
                    "Use Carrier Activation": "False",
                    "Create Service/Product": "True",
                    "Billing Provider": "AT&T - POD19",
                    "Service Type": "Wireless",
                    "Billing Product": "100 Free Minutes-1074",
                    "Billing Package": "15MB Data Only Pooled Plan-1171",
                    "Rate":"0"
                }
               
                # Create DataFrame with ALL columns initially
                assign_customer_df = pd.DataFrame(columns=all_possible_columns)
                for i in range(1):
                    assign_customer_df.loc[i] = [""] * len(all_possible_columns)
               
                # Initialize all DataFrames
                assign_cust_rate_plan_df = None
                assign_customer_name_df = None
                rev_provider_df = None
                rev_service_type_df = None
                rev_product_rate_df = None
                rev_package_df = None
               
                # 1. Fetch Billing Customer
                assign_customer_name_df=customer_name_df
                # 2. Fetch Customer Rate Plan
                assign_cust_rate_plan_df = rate_plan_df
              
                # 3. Fetch Customer Pool
                
                assign_cust_rate_pool_df = rate_pool_df

                # 4. Fetch Billing Provider (conditional)
       
                rev_provider_data = database.get_data(
                    "rev_provider",
                    {
                        "is_active": True,
                        "integration_authentication_id": integration_id
                    },
                    ["description", "provider_id"]
                )
                if (
                    rev_provider_data is not None
                    and not isinstance(rev_provider_data, bool)
                    and not rev_provider_data.empty
                ):
                    rev_provider_data["description"] = (
                        rev_provider_data["description"] + " -- " +
                        rev_provider_data["provider_id"].astype(str)
                    )
                    rev_provider_df = pd.DataFrame({
                        "Billing Provider": sorted(
                            rev_provider_data["description"].unique().tolist()
                        )
                    })
                else:
                    rev_provider_df = pd.DataFrame(columns=["Billing Provider"])
               
                # 5. Fetch Service Type (conditional)
                if "mode" in request_template:
                    service_provider_type = 'mobility'
                else:
                    service_provider_type = 'm2m'
               
                service_type_description_data = database.get_data(
                    'service_type_mapping',
                    {"service_provider_type": service_provider_type},
                    ["service_type_description"]
                )
                service_type_description_list = []
                if service_type_description_data is not None and not service_type_description_data.empty:
                    try:
                        service_type_description_list = json.loads(service_type_description_data['service_type_description'].iloc[0] or '[]')
                    except:
                        service_type_description_list = []
               
                rev_service_type_df = database.get_data(
                    "rev_service_type",
                    {
                        "is_active": True,
                        "integration_authentication_id": integration_id,
                        "description": service_type_description_list
                    },
                    ["description", "service_type_id"]
                )
                if (
                    rev_service_type_df is not None
                    and not isinstance(rev_service_type_df, bool)
                    and not rev_service_type_df.empty
                ):
                    rev_service_type_df["Service Type"] = (
                        rev_service_type_df["description"].astype(str) + " -- " +
                        rev_service_type_df["service_type_id"].astype(str)
                    )
                    rev_service_type_df = rev_service_type_df[["Service Type"]]
                else:
                    rev_service_type_df = pd.DataFrame(columns=["Service Type"])
               
                # 6. Fetch Billing Product (conditional)
                rev_product_df = database.get_data(
                    "rev_product",
                    {
                        "is_active": True,
                        "integration_authentication_id": integration_id,
                    },
                    ["description", "product_id"],
                )

                if (
                    rev_product_df is None
                    or isinstance(rev_product_df, bool)
                    or rev_product_df.empty
                ):
                    rev_product_rate_df = pd.DataFrame(columns=["Billing Product"])

                else:
                    product_ids = rev_product_df["product_id"].tolist()

                    if not product_ids:
                        rev_product_rate_df = pd.DataFrame(columns=["Billing Product"])
                    else:
                        product_ids_tuple = tuple(product_ids)
                       
                        rev_product_package_query = """
                            SELECT rpp.product_id, rp.rate
                            FROM rev_package_product rpp
                            INNER JOIN rev_product rp ON rp.product_id = rpp.product_id
                            WHERE rp.product_id IN %s
                            AND rp.integration_authentication_id = %s
                            AND rpp.integration_authentication_id = %s
                        """
                        
                        rev_product_package_df = database.execute_query(
                            rev_product_package_query,
                            params=(
                                product_ids_tuple,
                                integration_id,
                                integration_id,
                            ),
                            flag=True,
                        )

                        if (
                            rev_product_package_df is not None
                            and not isinstance(rev_product_package_df, bool)
                            and not rev_product_package_df.empty
                        ):
                            rate_lookup = dict(
                                zip(
                                    rev_product_package_df["product_id"],
                                    rev_product_package_df["rate"],
                                )
                            )

                        else:
                            rate_lookup = {}
                       
                        rev_product_df["rate"] = rev_product_df["product_id"].map(
                            lambda x: rate_lookup.get(x, "")
                        )
                       
                        rev_product_df = rev_product_df.drop_duplicates(
                            subset=["description", "product_id"]
                        )
                       
                        rev_product_df["Billing Product"] = (
                            rev_product_df["description"].astype(str) + " - " +
                            rev_product_df["product_id"].astype(str) 
                        )
                       
                        rev_product_rate_df = rev_product_df[["Billing Product"]]

               
                # 7. Fetch Billing Package 
                # Step 1: Get the package data
                package_data = database.execute_query(
                    f"""
                    SELECT 
                        package_id, 
                        MAX(description) AS description,
                        provider_id
                    FROM rev_package 
                    WHERE integration_authentication_id IN ({integration_id})
                    AND is_active = true 
                    AND is_deleted = false
                    GROUP BY package_id, provider_id;
                    """,
                    True,
                )

                if isinstance(package_data, pd.DataFrame) and not package_data.empty:

                    # Step 2: Create Billing Package column
                    package_data["Billing Package"] = (
                        package_data["description"].astype(str)
                        + " - "
                        + package_data["package_id"].astype(str)
                    )

                    # Step 3: Fetch package-product mapping (if needed later)
                    package_ids = package_data["package_id"].unique().tolist()

                    if package_ids:
                        package_data_mapping_query = f"""
                             SELECT
                                rpp.description AS description, rpo.rate AS rate, rpp.package_id AS package_id,
                                rpp.product_id AS product_id, rpa.provider_id AS provider_id
                            FROM public.rev_package_product rpp
                            INNER JOIN rev_product rpo on rpp.product_id = rpo.product_id
                            INNER JOIN rev_package rpa on rpp.package_id::INTEGER= rpa.package_id::INTEGER
                            WHERE  rpo.integration_authentication_id IN ({integration_id})
                            AND rpp.integration_authentication_id IN ({integration_id})
                            AND rpa.integration_authentication_id IN ({integration_id})
                            AND rpp.is_active = true and rpp.is_deleted = false and  rpa.is_active = true and rpa.is_deleted = false
                        """
                        package_product_data = database.execute_query(package_data_mapping_query, True)

                        if isinstance(package_product_data, pd.DataFrame) and not package_product_data.empty:
                            product_map = (
                                package_product_data
                                .groupby("package_id")["product_id"]
                                .apply(lambda x: ",".join(map(str, sorted(set(x.astype(int))))))
                                .reset_index()
                            )
                            product_map['package_id'] = product_map['package_id'].astype(str)
                            product_map = product_map.set_index('package_id')['product_id'].to_dict()
                            def build_billing_package(row):
                                products = product_map.get(row["package_id"])
                                if products:
                                    return f"{row['Billing Package']} -- {products}"
                                res=row["Billing Package"]
                                return res

                            package_data["Billing Package"] = package_data.apply(
                                build_billing_package,
                                axis=1
                            )
                    rev_package_df = package_data[["Billing Package"]].drop_duplicates()

                else:
                    rev_package_df = pd.DataFrame(columns=["Billing Package"])


               
                # Write to Excel with ALL columns
                assign_customer_df.to_excel(writer, sheet_name="Assign Customer", index=False)
               
                workbook = writer.book
                assign_customer_ws = writer.sheets["Assign Customer"]
                apply_header_formatting(assign_customer_ws, all_possible_columns, workbook)

                assign_customer_width=assign_customer_ws.set_column(0, len(all_possible_columns) - 1, 27)

                # Add data validations for ALL columns
                # 1. Billing Customer (column A)
                if assign_customer_name_df is not None and not assign_customer_name_df.empty:
                    col_idx = all_possible_columns.index("Billing Customer") + 1
                    col_letter = get_column_letter(col_idx)
                    # Get the column name (could be "Billing Customer" or "Customer Name")
                    column_name = assign_customer_name_df.columns[0]
                    add_data_validation(
                        assign_customer_ws,
                        col_letter,
                        assign_customer_name_df[column_name].tolist(),workbook=workbook  
                    )

                # 2. Create Service/Product (column D)
                col_idx = all_possible_columns.index("Create Service/Product") + 1
                col_letter = get_column_letter(col_idx)
                add_data_validation(assign_customer_ws, col_letter, ["True", "False"],workbook=workbook)
               
                # 3. Billing Provider (column E  )
                if rev_provider_df is not None and not rev_provider_df.empty:
                    col_idx = all_possible_columns.index("Billing Provider") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(
                        assign_customer_ws,
                        col_letter,
                        rev_provider_df["Billing Provider"].tolist(),workbook=workbook
                    )
               
                # 4. Service Type (column F )
                if rev_service_type_df is not None and not rev_service_type_df.empty:
                    col_idx = all_possible_columns.index("Service Type") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(
                        assign_customer_ws,
                        col_letter,
                        rev_service_type_df["Service Type"].tolist(),workbook=workbook
                    )
               
                # 5. Billing Product (column G )
                if rev_product_rate_df is not None and not rev_product_rate_df.empty:
                    col_idx = all_possible_columns.index("Billing Product") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(
                        assign_customer_ws,
                        col_letter,
                        rev_product_rate_df["Billing Product"].tolist(),workbook=workbook
                    )
               
                # 6. Billing Package (column H)
                if rev_package_df is not None and not rev_package_df.empty:
                    col_idx = all_possible_columns.index("Billing Package") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(
                        assign_customer_ws,
                        col_letter,
                        rev_package_df["Billing Package"].tolist(),workbook=workbook
                    )
               
                # 7. Prorate (column I)
                col_idx = all_possible_columns.index("Prorate") + 1
                col_letter = get_column_letter(col_idx)
                add_data_validation(assign_customer_ws, col_letter, ["True", "False"],workbook=workbook)

               
                # 10. Use Carrier Activation (column K)
                col_idx = all_possible_columns.index("Use Carrier Activation") + 1
                col_letter = get_column_letter(col_idx)
                add_data_validation(assign_customer_ws, col_letter, ["True", "False"],workbook=workbook)
                              
                # 11. Customer Pool (column M)
                if assign_cust_rate_pool_df is not None and not assign_cust_rate_pool_df.empty:
                    col_idx = all_possible_columns.index("Customer Pool") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(
                        assign_customer_ws,
                        col_letter,
                        assign_cust_rate_pool_df["Customer Rate Pool"].tolist(),workbook=workbook
                    )
               
                # 12. Customer Rate Plan (column N)
                if assign_cust_rate_plan_df is not None and not assign_cust_rate_plan_df.empty:
                    col_idx = all_possible_columns.index("Customer Rate Plan") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(
                        assign_customer_ws,
                        col_letter,
                        assign_cust_rate_plan_df["Customer Rate Plan"].tolist(),workbook=workbook
                    )
               
            
                logging.info("Assign Customer template generated with hidden conditional columns")
            if "Change Carrier Rate Plan" in service_provider_change_type_data:
                    logging.info("Generating Bulk Carrier Rate Plan template...")
                    #columns for carrier rate plan sheet
                    bulk_carrier_columns = [
                            "Carrier Rate Plan",
                            "Effective Date",
                            "Communication Plan",
                        ]
                    if "mode" in request_template:
                        # Remove Communication Plan if present
                        if "Communication Plan" in bulk_carrier_columns:
                            bulk_carrier_columns.remove("Communication Plan")

                        bulk_carrier_columns.append("Optimization Group")

                    carrier_result_df = pd.DataFrame(columns=bulk_carrier_columns)

                    for i in range(1):
                        carrier_result_df.loc[i] = [""] * len(bulk_carrier_columns)
                    
                    # Create sample data sheet
                    bulk_carrier_sample_dict = {
                        "Carrier Rate Plan": "Altaworx LLC - 5MB Plan -- ARPMB5",
                        "Effective Date": "2025-12-02",
                        "Communication Plan": "Altaworx EVX M2M Fixed IP LTE/SMS - USCAN",
                    }
                    # Write to Excel first
                    carrier_result_df.to_excel(writer, sheet_name="Carrier Rate Plan", index=False)
                    
                    # Get the workbook and worksheet
                    workbook = writer.book
                    carrier_rate_plan_ws = writer.sheets["Carrier Rate Plan"]
                    apply_header_formatting(carrier_rate_plan_ws, bulk_carrier_columns, workbook)

                    carrier_rate_plan_width=carrier_rate_plan_ws.set_column(0, len(bulk_carrier_columns) - 1, 19)

                    
                    # 1.carrier rtae plan dropdown
                    comm_plan_df = pd.DataFrame(columns=["Communication Plan"])
                    optimization_group_df = pd.DataFrame(columns=["Optimization Group"])
                                        
                    # 2.Communication plan
                    try:
                        comm_plan_result = database.get_data(
                            "sim_management_communication_plan",
                            {"service_provider_name": service_provider, "is_active": True},
                            ["communication_plan_name"]
                        )
                        comm_plan_flag = True

                        if comm_plan_result is not None and not isinstance(comm_plan_result, bool) and not comm_plan_result.empty:
                            # Create sorted unique DataFrame
                            comm_plan_df = pd.DataFrame({
                                "Communication Plan": sorted_unique(comm_plan_result["communication_plan_name"].to_list())
                            })
                        else:
                            logging.warning("No communication plans found")
                            comm_plan_df = pd.DataFrame(columns=["Communication Plan"])

                    except Exception as e:
                        logging.error(f"Error fetching comm_plan_df: {str(e)}")
                        comm_plan_df = pd.DataFrame(columns=["Communication Plan"])

                    # 3.Optimization group for Telegence
                    if "mode" in request_template:
                        try:
                            optimization_group_result = database.get_data(
                                "optimization_group",
                                {"service_provider_name": service_provider, "is_active": True},
                                ["optimization_group_name"],
                            )

                            if (optimization_group_result is not None and 
                                not isinstance(optimization_group_result, bool) and 
                                not optimization_group_result.empty):
                                
                                optimization_group_df = pd.DataFrame({
                                    "Optimization Group": sorted_unique(
                                        optimization_group_result["optimization_group_name"].to_list()
                                    )
                                })
                            else:
                                logging.warning("No optimization groups found")
                                optimization_group_df =pd.DataFrame(columns=["Optimization Group"])

                        except Exception as e:
                            logging.error(f"Error fetching optimization_group_df: {str(e)}")
                            optimization_group_df=pd.DataFrame(columns=["Optimization Group"])
                    
                    # Add data validations
                    if not carrier_rate_plan_df.empty:
                        logging.info(f"### entered ")
                        
                        try:
                            if 'Telegence' in service_provider:
                                carrier_col_name = "Rate Plan Code"
                            else:
                                carrier_col_name = "Carrier Rate Plan"
                            logging.info(f"### carrier_rate_plan_df : {carrier_rate_plan_df}")
                            # carrier_options = carrier_rate_plan_df["Carrier Rate Plan"].tolist()
                            carrier_options = carrier_rate_plan_df[carrier_col_name].tolist()
                            logging.info(f"### carrier options : {carrier_options}")
                            col_letter = get_column_letter(bulk_carrier_columns.index("Carrier Rate Plan") + 1)
                            add_data_validation(carrier_rate_plan_ws, col_letter, carrier_options,workbook=workbook)
                        except Exception as e:
                            logging.error(f"Error adding Carrier Rate Plan dropdown: {str(e)}")

                    #  code for adding Communication Plan dropdown:
                    if not comm_plan_df.empty:
                        try:
                            # Check if "Communication Plan" is still in the columns list
                            if "Communication Plan" in bulk_carrier_columns:
                                comm_options = comm_plan_df["Communication Plan"].tolist()
                                col_letter = get_column_letter(bulk_carrier_columns.index("Communication Plan") + 1)
                                add_data_validation(carrier_rate_plan_ws, col_letter, comm_options,workbook=workbook)
                        except Exception as e:
                            logging.error(f"Error adding Communication Plan dropdown: {str(e)}")

                    if "mode" in request_template and not optimization_group_df.empty:
                        try:
                            opt_options = optimization_group_df["Optimization Group"].tolist()
                            col_letter = get_column_letter(bulk_carrier_columns.index("Optimization Group") + 1)
                            add_data_validation(carrier_rate_plan_ws, col_letter, opt_options,workbook=workbook)
                        except Exception as e:
                            logging.error(f"Error adding Optimization Group dropdown: {str(e)}")
                    
                    logging.info("Carrier Rate Plan sheet created successfully")
                    
            if "Change Communication Plan" in service_provider_change_type_data:
                logging.info("Generating Bulk Communication Plan template...")
                
                # Columns for communication plan sheet
                bulk_communication_columns = ["Communication Plan"]
                communication_result_df = pd.DataFrame(columns=bulk_communication_columns)
                # Create sample data sheet
                bulk_comm_plan_sample_dict = {
                    "Communication Plan": "Altaworx EVX M2M Fixed IP LTE/SMS - USCAN"
                }
                for i in range(1):
                    communication_result_df.loc[i] = [""] * len(bulk_communication_columns)
                
                # Write to Excel first
                communication_result_df.to_excel(writer, sheet_name="Communication Plan", index=False)
                
                # Get the workbook and worksheet
                workbook = writer.book
                communication_plan_ws = writer.sheets["Communication Plan"]
                apply_header_formatting(communication_plan_ws, bulk_communication_columns, workbook)
                
                communication_plan_ws.set_column(0, len(bulk_communication_columns) - 1, 19)
                # Check if communication plan data was already fetched in Carrier Rate Plan section
                if not comm_plan_flag:
                    # Fetch communication plans only if not already fetched
                    comm_plan_df = pd.DataFrame(columns=["Communication Plan"])
                    
                    try:
                        comm_plan_result = database.get_data(
                            "sim_management_communication_plan",
                            {"service_provider_name": service_provider, "is_active": True},
                            ["communication_plan_name"]
                        )
                        
                        if comm_plan_result is not None and not isinstance(comm_plan_result, bool) and not comm_plan_result.empty:
                            # Create sorted unique DataFrame
                            comm_plan_df = pd.DataFrame({
                                "Communication Plan": sorted_unique(comm_plan_result["communication_plan_name"].to_list())
                            })
                        else:
                            logging.warning("No communication plans found")
                            comm_plan_df = pd.DataFrame(columns=["Communication Plan"])
                            
                    except Exception as e:
                        logging.error(f"Error fetching comm_plan_df: {str(e)}")
                        comm_plan_df = pd.DataFrame(columns=["Communication Plan"])
                else:
                    logging.info("Using previously fetched communication plan data")
                
                # Add data validation for Communication Plan dropdown
                if not comm_plan_df.empty:
                    try:
                        comm_options = comm_plan_df["Communication Plan"].tolist()
                        col_letter = get_column_letter(bulk_communication_columns.index("Communication Plan") + 1)
                        add_data_validation(communication_plan_ws, col_letter, comm_options, workbook=workbook)
                    except Exception as e:
                        logging.error(f"Error adding Communication Plan dropdown: {str(e)}")
                
                logging.info("Communication Plan sheet created successfully") 
            
            if "Change Customer Rate Plan" in service_provider_change_type_data:
                # SHEET 2: Bulk Customer Rate Plan Template
                logging.info("Generating Bulk Customer Rate Plan template...")
                
                # Create columns for Bulk Customer Rate Plan - provider-specific
                bulk_customer_columns = ["Customer Rate Plan", "Effective Date", "Customer Rate Pool"]
                
                # Add Customer Name ONLY IF billing_platform_flag is True AND not already in columns
                if billing_platform_flag and "Customer Name" not in bulk_customer_columns:
                    bulk_customer_columns.append("Customer Name")
                
                # Create main template sheet with some empty rows
                bulk_result_df = pd.DataFrame(columns=bulk_customer_columns)
                # # Add some empty rows for data entry
                for i in range(1):  
                    bulk_result_df.loc[i] = [""] * len(bulk_customer_columns)
                
                # Create sample data sheet
                bulk_sample_dict = {
                    "Customer Rate Plan": "Test Plan 4907 -- 5464",
                    "Effective Date": "YYYY-MM-DD",
                    "Customer Rate Pool": "Altaworx CFU -- 3",
                }
                
                # Add Customer Name to sample ONLY if it's in the columns
                if "Customer Name" in bulk_customer_columns:
                    bulk_sample_dict["Customer Name"] = "4F Applied Technologies"
                
                bulk_sample_df = pd.DataFrame([bulk_sample_dict])
                bulk_sample_df = capitalize_columns(bulk_sample_df)
                #fecth rate plan
                customer_rate_plan_df = rate_plan_df
                #fecth rate pool
                customer_rate_pool_df = rate_pool_df
                #fetch customer
                bulk_result_df.to_excel(writer, sheet_name='Customer Rate Plan', index=False)
                
                # Add data validation to Customer Rate Plan sheet
                customer_rate_plan_ws = writer.sheets['Customer Rate Plan']
                apply_header_formatting(customer_rate_plan_ws, bulk_customer_columns, workbook)

                customer_rate_plan_width=customer_rate_plan_ws.set_column(0, len(bulk_customer_columns) - 1, 20)

                # Add dropdown for Customer Rate Plan
                if customer_rate_plan_df is not None and not customer_rate_plan_df.empty:
                    rate_plan_options = customer_rate_plan_df["Customer Rate Plan"].tolist()
                    col_idx = bulk_customer_columns.index("Customer Rate Plan") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(customer_rate_plan_ws, col_letter, rate_plan_options,workbook=workbook)
                
                # Add dropdown for Customer Rate Pool
                if customer_rate_pool_df is not None and not customer_rate_pool_df.empty:
                    rate_pool_options = customer_rate_pool_df["Customer Rate Pool"].tolist()
                    col_idx = bulk_customer_columns.index("Customer Rate Pool") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(customer_rate_plan_ws, col_letter, rate_pool_options,workbook=workbook)
                
                # Add dropdown for Customer Name (if applicable)
                if "Customer Name" in bulk_customer_columns and customer_name_df is not None and not customer_name_df.empty:
                    customer_name_options = customer_name_df["Customer Name"].tolist()
                    col_idx = bulk_customer_columns.index("Customer Name") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(customer_rate_plan_ws, col_letter, customer_name_options,workbook=workbook)
            if "Change ICCID/IMEI" in service_provider_change_type_data:
                 # SHEET 2: change iccid imei Template
                logging.info("Generating change iccid imei template...")
                
                # Create columns for change iccid imei - provider-specific
                change_iccid_columns = ["New ICCID","New IMEI","Customer Rate Plan",  "Customer Rate Pool"]
                
                # Create main template sheet with some empty rows
                change_iccid_result_df = pd.DataFrame(columns=change_iccid_columns)
                # # Add some empty rows for data entry
                for i in range(1):  
                    change_iccid_result_df.loc[i] = [""] * len(change_iccid_columns)
                
                # Create sample data sheet
                change_iccid_sample_dict = {
                    "New ICCID":"12345678901234567890",
                    "New IMEI":"123456789012345",
                    "Customer Rate Plan": "10GB Data Device 5G - No Tether - Reeves -- MS5GDONTRY",
                    "Customer Rate Pool": "AMOP Test -- 21",
 
                    
                }
                change_iccid_sample_df = pd.DataFrame([change_iccid_sample_dict])

                change_iccid_sample_df = capitalize_columns(change_iccid_sample_df)
                change_iccid_result_df.to_excel(writer, sheet_name='Change ICCID & IMEI', index=False)
                
                # Add data validation to Change Iccid Imei sheet
                rate_plan_ws = writer.sheets['Change ICCID & IMEI']
                apply_header_formatting(rate_plan_ws, change_iccid_columns, workbook)

                rate_plan_width=rate_plan_ws.set_column(0, len(change_iccid_columns) - 1, 20)

                
                # Add dropdown for CChange Iccid Imei
                if rate_plan_df is not None and not rate_plan_df.empty:
                    rate_plan_options = rate_plan_df["Customer Rate Plan"].tolist()
                    col_idx = change_iccid_columns.index("Customer Rate Plan") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(rate_plan_ws, col_letter, rate_plan_options,workbook=workbook)
                
                # Add dropdown for Customer Rate Pool
                if rate_pool_df is not None and not rate_pool_df.empty:
                    rate_pool_options = rate_pool_df["Customer Rate Pool"].tolist()
                    col_idx = change_iccid_columns.index("Customer Rate Pool") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(rate_plan_ws, col_letter, rate_pool_options,workbook=workbook)
            if "Change Phone Number" in service_provider_change_type_data:
                logging.info("Generating change phone number template...")
                phone_columns = ["Save Changes"]
                # Create main template sheet with some empty rows 
                phone_result_df = pd.DataFrame(columns=phone_columns)
                # Create sample data
                phone_sample = {
                    "Save Changes": "True",
                }
                phone_sample_df = pd.DataFrame([phone_sample])
                phone_sample_df = capitalize_columns(phone_sample_df)
                
                phone_result_df.to_excel(writer, sheet_name='Change Phone Number', index=False)                     
                    
                # Get the workbook and worksheet
                workbook = writer.book
                phone_ws = writer.sheets['Change Phone Number']
                apply_header_formatting(phone_ws, phone_columns, workbook)

                phone_width=phone_ws.set_column(0, len(phone_columns) - 1, 10)
                # create save changes 
                col_idx = phone_columns.index("Save Changes") + 1
                col_letter = get_column_letter(col_idx)
                add_data_validation(phone_ws, col_letter, ["True", "False"],workbook=workbook)
                logging.info("Change Phone number sheet created with MSISDN columns")
            if "Change Private Static IP Address" in service_provider_change_type_data:
                logging.info("Generating chnage private static ip address template...")
                try:
                    config = load_json()
                    service_ip_mappings = config.get("ServiceIpMappings", {})
                    service_provider_lower = service_provider.lower()

                    # Find provider configuration dynamically
                    provider_config = None
                    for provider_key, config_data in service_ip_mappings.items():
                        if provider_key.lower() == "default":
                            continue
                        unique_names = config_data.get("unique_names", [])
                        if any(name.lower() == service_provider_lower for name in unique_names):
                            provider_config = config_data
                            break
                    
                    # Use default if no specific provider found
                    if not provider_config:
                        provider_config = service_ip_mappings.get("default", {})
                        
                except Exception as e:
                    logging.error(f"Error loading service provider mappings: {str(e)}")
                    provider_config = service_ip_mappings.get("default", {})
            
                
                # Get provider-specific template columns for Device Status
                ip_columns = provider_config.get("ip_columns", [ "Save Changes"])
                logging.info(f"ip_columns:{ip_columns}")
                ip_sample = provider_config.get("ip_sample", {})
               
                # Create main template sheet with some empty rows 
                ip_result_df = pd.DataFrame(columns=ip_columns)
                
                # Add empty rows for data entry
                for i in range(2):
                    ip_result_df.loc[i] = [""] * len(ip_columns)
               
                ip_sample_df = pd.DataFrame([ip_sample])
                ip_sample_df = capitalize_columns(ip_sample_df)
                
                # Write the template sheet
                ip_result_df.to_excel(writer, sheet_name='Private Static IP Address', index=False)
                
                # Get the workbook and worksheet
                workbook = writer.book
                ip_ws = writer.sheets['Private Static IP Address']
                apply_header_formatting(ip_ws, ip_columns, workbook)

                ip_width=ip_ws.set_column(0, len(ip_columns) - 1, 23)
                pdp_data = pd.DataFrame()
                apn_data = pd.DataFrame()
                has_billing = "Billing Account Number" in ip_columns
                has_pdp = "PDP Name" in ip_columns
                has_apn = "Private Static APN" in ip_columns
                if "Save Changes" in ip_columns:
                    col_idx = ip_columns.index("Save Changes") + 1  
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(ip_ws, col_letter, ["True", "False"],workbook=workbook)
                # 1.billing account number dropdown
                #2.fetch pdp dropdown
                if has_pdp:
                    pdp_data=pdp_df
                if has_apn:
                    apn_data=apn_df
                
                # Add dropdown for Billing Account Number
                if not billing_account_data.empty and has_billing:
                    try:
                        billing_options = billing_account_data["Billing Account Number"].tolist()
                        # Filter out any None values
                        billing_options = [str(opt) for opt in billing_options if opt is not None]
                        col_idx = ip_columns.index("Billing Account Number") + 1
                        col_letter = get_column_letter(col_idx)   
                        add_data_validation(ip_ws, col_letter, billing_options,workbook=workbook)
                    except Exception as e:
                        logging.error(f"Error adding billing account dropdown: {str(e)}")
                
                # Add dropdown for PDP Name
                if not pdp_data.empty:
                    try:
                        pdp_options = pdp_data["PDP Name"].tolist()
                        # Filter out any None values
                        pdp_options = [str(opt) for opt in pdp_options if opt is not None]
                        col_idx = ip_columns.index("PDP Name") + 1
                        col_letter = get_column_letter(col_idx)  # FIXED: pass col_idx, not col_letter

                        add_data_validation(ip_ws, col_letter, pdp_options,workbook=workbook)
                    except Exception as e:
                        logging.error(f"Error adding PDP dropdown: {str(e)}")
                #Add dropdown for apn
                if not apn_data.empty:
                    try:
                        apn_options = apn_data["Private Static APN"].tolist()
                        # Filter out any None values
                        apn_options = [str(opt) for opt in apn_options if opt is not None]
                        col_idx = ip_columns.index("Private Static APN") + 1
                        col_letter = get_column_letter(col_idx)  # FIXED: pass col_idx, not col_letter

                        add_data_validation(ip_ws, col_letter, apn_options,workbook=workbook)
                    except Exception as e:
                        logging.error(f"Error adding apn dropdown: {str(e)}")


                
                logging.info("Change Private Static IP Address sheet created successfully")    
            if "Edit Username/Cost Center" in service_provider_change_type_data:
                logging.info("Generating edit username cost center template...")
                cost_user_columns = ["Contact Name","Cost Center"]
                # Create main template sheet with some empty rows 
                costcenter_result_df = pd.DataFrame(columns=cost_user_columns)
                # Create sample data
                cost_center_sample = {
                    "Contact Name":"Tester",
                    "Cost Center":"Testing232"
                }
                costcneter_sample_df = pd.DataFrame([cost_center_sample])
                costcneter_sample_df = capitalize_columns(costcneter_sample_df)
                costcenter_result_df.to_excel(writer, sheet_name='Edit Username & Cost Center', index=False)                     
                # Get the workbook and worksheet
                workbook = writer.book
                archive_ws = writer.sheets['Edit Username & Cost Center']
                apply_header_formatting(archive_ws, cost_user_columns, workbook)

                archive_width=archive_ws.set_column(0, len(cost_user_columns) - 1, 13)
                logging.info("username costcenter sheet created with desired columns")       
            if "Line Sync" in service_provider_change_type_data:
                logging.info("Generating line sync template...")
                line_columns = ["Save Changes"]
                # Create main template sheet with some empty rows 
                line_result_df = pd.DataFrame(columns=line_columns)
                # Create sample data
                line_sample = {
                    "Save Changes":"True"
                }
                line_sample_df = pd.DataFrame([line_sample])
                line_sample_df = capitalize_columns(line_sample_df)
                
                line_result_df.to_excel(writer, sheet_name='Line Sync', index=False)                     
                    
                # Get the workbook and worksheet
                workbook = writer.book
                line_ws = writer.sheets['Line Sync']
                apply_header_formatting(line_ws, line_columns, workbook)

                line_width=line_ws.set_column(0, len(line_columns) - 1, 10)
                 # create save changes 
                col_idx = line_columns.index("Save Changes") + 1
                col_letter = get_column_letter(col_idx)
                add_data_validation(line_ws, col_letter, ["True", "False"],workbook=workbook)
                logging.info("Line Sync sheet created with plain ICCID and MSISDN columns")
            if "Send SMS" in service_provider_change_type_data:
                logging.info("Generating send sms template...")
                send_sms_columns = [ "Message Text"]
                
                # Create main template sheet with some empty rows 
                send_sms_columns_df = pd.DataFrame(columns=send_sms_columns)
                
                # Add empty rows for data entry
                for i in range(1): 
                    send_sms_columns_df.loc[i] = [""] * len(send_sms_columns)
                
                # Create sample data  
                send_sms_sample = {
                    "Message Text" :"Hi",
                }
                send_sms_sample_df = pd.DataFrame([send_sms_sample])
                send_sms_sample_df = capitalize_columns(send_sms_sample_df)
                
                # Write to Excel
                send_sms_columns_df.to_excel(writer, sheet_name='Send SMS', index=False)
                # Get the workbook and worksheet
                workbook = writer.book
                send_sms_ws = writer.sheets['Send SMS']
                apply_header_formatting(send_sms_ws, send_sms_columns, workbook)

                send_sms_width=send_sms_ws.set_column(0, len(send_sms_columns) - 1, 13)

                logging.info("Update Feature Codes sheet created with multi-select SOC codes")    
            if "Refresh A Line" in service_provider_change_type_data:
                logging.info("Generating refresh a line template...")
                refresh_a_line_columns = ["Billing Account Number"]
                # Create main template sheet with some empty rows 
                refresh_a_line_result_df = pd.DataFrame(columns=refresh_a_line_columns)

                for i in range(1):  
                    refresh_a_line_result_df.loc[i] = [""] * len(refresh_a_line_columns)
                
                billing_account_numbers = billing_account_data
            
                # Create sample data
                refresh_a_line_sample = {
                    "Billing Account Number":"1234567890"
                }
                refresh_a_line_sample_df = pd.DataFrame([refresh_a_line_sample])
                refresh_a_line_sample_df = capitalize_columns(refresh_a_line_sample_df)
                refresh_a_line_result_df.to_excel(writer, sheet_name='Refresh A Line', index=False)                     
                # Get the workbook and worksheet
                workbook = writer.book
                refresh_a_line_ws = writer.sheets['Refresh A Line']
                apply_header_formatting(refresh_a_line_ws, refresh_a_line_columns, workbook)

                refresh_width=refresh_a_line_ws.set_column(0, len(refresh_a_line_columns) - 1, 23)

                ### adding dropdown for billing account number column 
                if "Billing Account Number" in refresh_a_line_columns and billing_account_numbers is not None:
                    col_idx = refresh_a_line_columns.index("Billing Account Number") + 1
                    col_letter = get_column_letter(col_idx)
                    if not billing_account_numbers.empty:
                        billing_options = billing_account_numbers["Billing Account Number"].dropna().astype(str).tolist()
                    else:
                        billing_options = []
                    
                    add_data_validation(refresh_a_line_ws, col_letter, billing_options,workbook=workbook)
  
                logging.info("Refresh A Line sheet created with desired columns")
            if "Reset Voicemail Password" in service_provider_change_type_data:
                logging.info("Generating reset voicemail password template...")
                # Fixed column names 
                reset_columns = [
                    "Billing Account Number", 
                    "New Voicemail PIN", 
                ]
                
                # Create main template sheet with some empty rows 
                reset_result_df = pd.DataFrame(columns=reset_columns)
                
                # Add empty rows for data entry
                for i in range(1):
                    reset_result_df.loc[i] = [""] * len(reset_columns)
                
                # Create sample data
                reset_sample = {
                    "Billing Account Number": "287280157017",
                    "New Voicemail PIN": "0123",
                }
                
                reset_sample_df = pd.DataFrame([reset_sample])
                reset_sample_df = capitalize_columns(reset_sample_df)
                billing_account_numbers=billing_account_data
                
                # Write the template sheet
                reset_result_df.to_excel(writer, sheet_name='Reset Voicemail Password', index=False)
                
                # Get the workbook and worksheet
                workbook = writer.book
                reset_ws = writer.sheets['Reset Voicemail Password']
                apply_header_formatting(reset_ws, reset_columns, workbook)

                reset_width=reset_ws.set_column(0, len(reset_columns) - 1, 27)

                if not billing_account_data.empty:
                    billing_options = billing_account_data["Billing Account Number"].dropna().astype(str).tolist()
                    col_idx = reset_columns.index("Billing Account Number") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(reset_ws, col_letter, billing_options,workbook=workbook)
                else:
                    col_idx = reset_columns.index("Billing Account Number") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(reset_ws, col_letter, [],workbook=workbook)
                    
                logging.info("Reset voice mail password sheet created with desired columns")
            if "Update Device Status" in  service_provider_change_type_data :   
            
                # SHEET 1: Bulk Update Device Status Template
                logging.info("Generating Bulk Update Device Status template...")
                
                
                # Create main template sheet with some sample rows
                result_df = pd.DataFrame(columns=template_columns)
                # Add some empty rows for data entry
                for i in range(1):  
                    result_df.loc[i] = [""] * len(template_columns)
                
                # Initialize all possible dataframes
                activation_profile_df = None
                reason_codes_df = None
                status_df = None
    
                integration_df = database.get_data(
                    "serviceprovider",
                    {"service_provider_name": service_provider, "is_active": True},
                    ["integration_id"],
                )
                if integration_df is not None and not isinstance(integration_df, bool) and not integration_df.empty:
                    integration_id_1 = integration_df["integration_id"].to_list()[0]
                    if integration_id_1 is not None :
                        # Fetch device_status data for status_df
                        status_df = database.get_data(
                            "device_status",
                            {
                                "integration_id": integration_id_1,
                                "allows_api_update": True,
                                "is_active": True,
                            },
                            ["display_name", "id", "status"],
                        )
                        
                        if status_df is not None and not isinstance(status_df, bool) and not status_df.empty:
                            if "Mode" in template_columns and "status" in status_df.columns:
                                status_df["Mode"] = status_df["status"].astype(str)
                                status_df["Target Status"] = status_df["display_name"].astype(str)
                                status_df = status_df[["Target Status", "Mode"]]
                            else:
                                status_df["Target Status"] = status_df["display_name"].astype(str)
                                status_df = status_df[["Target Status"]]
                        else:
                            # Create empty status_df with appropriate columns
                            if "Mode" in template_columns:
                                status_df = pd.DataFrame(columns=["Target Status", "Mode"])
                            else:
                                status_df = pd.DataFrame(columns=["Target Status"])
                # Dynamically create required dataframes based on provider configuration
                for df_name in required_dataframes:
                    
                    if df_name == "customer_rate_plan_code_df":
                        # Check if service provider is AT&T Telegence , AT&T - Telegence - UAT ONLY
                        if "Mode" in template_columns :    
                            customer_rate_plan_code_df=customer_rate_plan_code_df
                                
                    elif df_name == "activation_profile_df":
                        #fetch kore activation for update device status
                        activation_profile_df = database.get_data(
                            "kore_activation_profiles",
                            {},
                            ["activation_profile_name", "carrier_rate_plan_data"]
                        )  
                        if activation_profile_df is not None and not isinstance(activation_profile_df, bool) and not activation_profile_df.empty:
                            activation_profile_df["Kore Activation Profile"] = activation_profile_df["activation_profile_name"].astype(str) + " -- " + activation_profile_df["carrier_rate_plan_data"].astype(str)
                            activation_profile_df = activation_profile_df[["Kore Activation Profile"]]
                        else:
                            activation_profile_df = pd.DataFrame(columns=["Kore Activation Profile"])

                    elif df_name == "reason_codes_df":
                        logging.info("reasoncode ")
                        if "Mode" in template_columns:   
                            reason_codes_df = database.get_data(
                                "telegence_device_status_reason_code",
                                {"is_active": True},
                                ["reason_code"],
                            )
                        else:
                            reason_codes_df = database.get_data(
                                "thingspace_device_status_reason_code",
                                {"is_active": True},
                                ["device_status_id", "description", "reason_code"],
                            )
                        
                        if reason_codes_df is not None and not isinstance(reason_codes_df, bool) and not reason_codes_df.empty:
                            reason_codes_df["Reason Code"] = reason_codes_df["reason_code"].astype(str)
                            reason_codes_df = reason_codes_df[["Reason Code"]]
                        else:
                            reason_codes_df = pd.DataFrame(columns=["Reason Code"])

                    elif df_name == "state_df":
                        state_df = state_df

                # Create sample DataFrame from configuration
                sample_df = pd.DataFrame([sample_data])
                sample_df = capitalize_columns(sample_df)
                # Write bulk update device status sheets
                result_df.to_excel(writer, sheet_name='Update Device Status', index=False)            
                # Get the workbook and worksheet objects for adding data validation
                workbook = writer.book
                device_status_ws = writer.sheets['Update Device Status']
                apply_header_formatting(device_status_ws, template_columns, workbook)
                device_width=device_status_ws.set_column(0, len(template_columns) - 1, 29)
               
                #private static ip address
                if "Private static Ip Address" in template_columns: 
                    col_idx = template_columns.index("Private static Ip Address") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(device_status_ws, col_letter, ["Restricted", "Unrestricted"],workbook=workbook)
                # Add data validation (dropdowns) to the Update Device Status sheet
                if "Target Status" in template_columns and status_df is not None and not status_df.empty:
                    target_status_options = status_df["Target Status"].tolist()
                    col_idx = template_columns.index("Target Status") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(device_status_ws, col_letter, target_status_options,workbook=workbook)
                
                if "Mode" in template_columns and status_df is not None and not status_df.empty and "Mode" in status_df.columns:
                    mode_options = status_df["Mode"].dropna().unique().tolist()
                    col_idx = template_columns.index("Mode") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(device_status_ws, col_letter, mode_options,workbook=workbook)
                
                if "Reason Code" in template_columns and reason_codes_df is not None and not reason_codes_df.empty:
                    reason_code_options = reason_codes_df["Reason Code"].tolist()
                    col_idx = template_columns.index("Reason Code") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(device_status_ws, col_letter, reason_code_options,workbook=workbook)
                # Add dropdown for Rate Plan Code if it exists in template columns and dataframe is available
                if "Rate Plan Code" in template_columns and customer_rate_plan_code_df is not None and not customer_rate_plan_code_df.empty:
                    rate_plan_options = customer_rate_plan_code_df["Rate Plan Code"].tolist()
                    col_idx = template_columns.index("Rate Plan Code") + 1
                    col_letter = get_column_letter(col_idx)
                    res=add_data_validation(device_status_ws, col_letter, rate_plan_options,workbook=workbook)
                
                # Add dropdown for Kore Activation Profile if it exists in template columns
                if "Kore Activation Profile" in template_columns and activation_profile_df is not None and not activation_profile_df.empty:
                    activation_options = activation_profile_df["Kore Activation Profile"].tolist()
                    col_idx = template_columns.index("Kore Activation Profile") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(device_status_ws, col_letter, activation_options,workbook=workbook)
                
                # Add dropdown for State Code if it exists in template columns
                if "State Code" in template_columns and state_df is not None and not state_df.empty:
                    state_code_options = state_df["Code"].tolist()
                    col_idx = template_columns.index("State Code") + 1
                    col_letter = get_column_letter(col_idx)
                    add_data_validation(device_status_ws, col_letter, state_code_options,workbook=workbook)
            if "Update Features" in service_provider_change_type_data:
                logging.info("Generating update feature codes template...")
                update_feature_codes_columns = ["Update Feature Codes", "Remove Feature Codes", "Overwrite Feature Codes"]
                
                # Create main template sheet with some empty rows 
                update_feature_codes_df = pd.DataFrame(columns=update_feature_codes_columns)
                
                # Add empty rows for data entry
                for i in range(1): 
                    update_feature_codes_df.loc[i] = [""] * len(update_feature_codes_columns)
                #fetch feature code
            
                
                # Create sample data  
                update_feature_codes_sample = {
                    "Update Feature Codes": "SDFLIWTWN,AZIRDX1GB",  
                    "Remove Feature Codes": "AZIRDX1GB,SDFLIWTWN", 
                    "Overwrite Feature Codes": True
                }
                update_feature_codes_sample_df = pd.DataFrame([update_feature_codes_sample])
                update_feature_codes_sample_df = capitalize_columns(update_feature_codes_sample_df)
                
                # Write to Excel
                update_feature_codes_df.to_excel(writer, sheet_name='Update Feature Codes', index=False)
                
                # Get the workbook and worksheet
                workbook = writer.book
                update_feature_codes_ws = writer.sheets['Update Feature Codes']
                apply_header_formatting(update_feature_codes_ws, update_feature_codes_columns, workbook)
                feature_width=update_feature_codes_ws.set_column(0, len(update_feature_codes_columns) - 1, 25)

                # Add multi-select dropdowns for SOC codes
                if soc_codes:
                    # For "Remove Feature Codes" column
                    if "Remove Feature Codes" in update_feature_codes_columns:
                        col_idx = update_feature_codes_columns.index("Remove Feature Codes") + 1
                        col_letter = get_column_letter(col_idx)
                        # Use the new multi-select function
                        add_data_validation(update_feature_codes_ws, col_letter, soc_codes,workbook=workbook)
                    
                    # For "Update Feature Codes" column  
                    if "Update Feature Codes" in update_feature_codes_columns:
                        col_idx = update_feature_codes_columns.index("Update Feature Codes") + 1
                        col_letter = get_column_letter(col_idx)
                        # Use the new multi-select function
                        add_data_validation(update_feature_codes_ws, col_letter, soc_codes,workbook=workbook)
                
                # Add dropdown for Overwrite Feature Codes (True/False)
                if "Overwrite Feature Codes" in update_feature_codes_columns:
                    col_idx = update_feature_codes_columns.index("Overwrite Feature Codes") + 1
                    col_letter = get_column_letter(col_idx)
                    # Regular single-select dropdown for True/False
                    add_data_validation(update_feature_codes_ws, col_letter, ['True', 'False'],workbook=workbook)
    
                logging.info("Update Feature Codes sheet created with multi-select SOC codes")    
            if "Update PPU address" in service_provider_change_type_data:
                logging.info("Generating update ppu address template...")
                ppu_columns = [
                    "Billing Account Number", "Role", "First Name", "Last Name",
                    "Street Number", "Street Direction", "Street Name", "City", "State", "Zip Code",
                ]
                
                # Create main template sheet with some empty rows 
                ppu_result_df = pd.DataFrame(columns=ppu_columns)
                
                # Add empty rows for data entry (FIX: need to actually add rows to the DataFrame)
                for i in range(1):
                    ppu_result_df.loc[i] = [""] * len(ppu_columns)
                
                # Create sample data
                ppu_sample = {
                    "Billing Account Number": "287353813562",
                    "Role": "Subscriber",
                    "First Name": "Phani",
                    "Last Name": "Test",
                    "Street Number": "455",
                    "Street Direction": "Magnolia Ave",
                    "Street Name": "Magnolia Ave",
                    "City": "Fairhope",
                    "State": "AL",
                    "Zip Code": "36532",
                }
                ppu_sample_df = pd.DataFrame([ppu_sample])
                ppu_sample_df = capitalize_columns(ppu_sample_df)
                
                ppu_result_df.to_excel(writer, sheet_name='Update PPU Address', index=False)                     
                
                # Get the workbook and worksheet
                workbook = writer.book
                ppu_ws = writer.sheets['Update PPU Address']
                apply_header_formatting(ppu_ws, ppu_columns, workbook)
                ppu_width=ppu_ws.set_column(0, len(ppu_columns) - 1, 27)


                #1.fetch state dropdown
                # Add dropdown for State if it exists in ppu_columns
                if "State" in ppu_columns and state_df is not None and not state_df.empty:
                    state_code_options = state_df["Code"].tolist()
                    col_idx = ppu_columns.index("State") + 1
                    col_letter = get_column_letter(col_idx)
                    
                    # Apply data validation
                    try:
                        helper_col = add_data_validation(ppu_ws, col_letter, state_code_options,workbook=workbook)
                    except Exception as e:
                        logging.error(f"Error applying state dropdown: {str(e)}")            
            if device_status_ws:
            # Apply to device_status_ws if column exists
                apply_strict_date_validation(device_status_ws, "Effective Date", template_columns)
            # Apply to customer_rate_plan_ws if column exists
            if customer_rate_plan_ws:
                apply_strict_date_validation(customer_rate_plan_ws, "Effective Date", bulk_customer_columns)
            if carrier_rate_plan_ws:
                apply_strict_date_validation(carrier_rate_plan_ws, "Effective Date", bulk_carrier_columns)
            if assign_customer_ws:
                apply_strict_date_validation(assign_customer_ws, "Effective Date", all_possible_columns)
            # combined sample data
            logging.info("Generating simple combined sample data sheet as first sheet...")
            #  len(bulk_customer_columns),
            # Calculate max columns needed
            max_template_cols = max(
                len(template_columns),
                len(bulk_customer_columns),
                len(bulk_change_columns),
                len(archive_columns),
                len(cost_user_columns),
                len(line_columns),
                len(change_iccid_columns),
                len(bulk_carrier_columns),
                len(ip_columns),
                len(ppu_columns),
                len(reset_columns),
                len(phone_columns),len(send_sms_columns),len(update_feature_codes_columns),len(refresh_a_line_columns),len(all_possible_columns)
            )
            
            # Create empty DataFrame with correct structure
            combined_sample_df = pd.DataFrame(columns=["Change Type"])
            combined_sample_df.to_excel(writer, sheet_name='Sample Data', index=False)

            workbook = writer.book
            sample_ws = writer.sheets['Sample Data']
            
            # Create formats for sample data sheet - DO NOT DUPLICATE
            header_gray_format = workbook.add_format({
                'bold': True,
                'align': 'center',
                'valign': 'vcenter',
                'bg_color': '#D3D3D3',
                'border': 1
            })
            regular_format = workbook.add_format({
                'align': 'left', 
                'valign': 'vcenter',
                'border': 1
            })
            
            sample_ws.set_column(0, 0, 27)  # Set width for column A to 25

            current_row = 0  # xlsxwriter uses 0-based indexing

            # Header row - "Change Type" in column A, "Column Data" in column B (NO empty columns)
            sample_ws.write(current_row, 0, "Change Type", header_gray_format)

            # "Column Data" header starts from column B (2nd column) - NO EMPTY COLUMNS
            COLUMN_DATA_START_COL = 1  # 0-based indexing
            column_data_end_col = COLUMN_DATA_START_COL + max_template_cols - 1

            # Merge cells for "Column Data" header starting from column B
            if column_data_end_col > COLUMN_DATA_START_COL:
                sample_ws.merge_range(current_row, COLUMN_DATA_START_COL, 
                                    current_row, column_data_end_col, 
                                    "Column Data", header_gray_format)
            else:
                sample_ws.write(current_row, COLUMN_DATA_START_COL, "Column Data", header_gray_format)

            current_row += 1

            # FREEZE PANES - For xlsxwriter, freeze the first row and first column
            sample_ws.freeze_panes(1, 1)

            # Build sample data for all change types
            change_type_sections = []
           
            if "Activate New Service" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Activate New Service",
                    "columns": bulk_change_columns,
                    "sample": bulk_change_sample_dict,
                    "width":27
                })
            if "Archive" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Archive",
                    "columns": archive_columns,
                    "sample": archive_sample,
                    "width":20 

                })
            if "Assign Customer" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Assign Customer",
                    "columns": all_possible_columns,
                    "sample": assign_customer_sample,
                    "width":27  

                })
            if "Change Carrier Rate Plan" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Carrier Rate Plan",
                    "columns": bulk_carrier_columns,
                    "sample": bulk_carrier_sample_dict,
                    "width":19  

                })
            if "Change Communication Plan" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Communication Plan",
                    "columns": bulk_communication_columns,
                    "sample": bulk_comm_plan_sample_dict,
                    "width":19  

                })       
            if "Change Customer Rate Plan" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Customer Rate Plan",
                    "columns": bulk_customer_columns,
                    "sample": bulk_sample_dict,
                    "width":25  

                })
            if "Change ICCID/IMEI" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Change ICCID & IMEI",
                    "columns": change_iccid_columns,
                    "sample": change_iccid_sample_dict,
                    "width":20

                })
            if "Change Phone Number" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Change Phone Number",
                    "columns": phone_columns,
                    "sample": phone_sample,
                    "width":10  

                })
            if "Change Private Static IP Address" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Private Static IP Address",
                    "columns": ip_columns,
                    "sample": ip_sample,
                    "width":23  

                })
            if "Edit Username/Cost Center" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Edit Username & Cost Center",
                    "columns": cost_user_columns,
                    "sample": cost_center_sample,
                    "width":13  

                })
            if "Line Sync" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Line Sync",
                    "columns": line_columns,
                    "sample": line_sample,
                    "width":10 

                })
            if "Refresh A Line" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Refresh A Line",
                    "columns": refresh_a_line_columns,
                    "sample": refresh_a_line_sample,
                    "width":23  

                })
            if "Reset Voicemail Password" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Reset Voicemail Password",
                    "columns": reset_columns,
                    "sample": reset_sample,
                    "width":27  

                })
            if "Send SMS" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Send SMS",
                    "columns": send_sms_columns,
                    "sample": send_sms_sample,
                    "width":13  

                })
            if "Update Device Status" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Update Device Status",
                    "columns": template_columns,
                    "sample": sample_data,
                    "width":29
                })
            if "Update Features" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Update Feature Codes",
                    "columns": update_feature_codes_columns,
                    "sample": update_feature_codes_sample,
                    "width":25  

                })
            if "Update PPU address" in service_provider_change_type_data:
                change_type_sections.append({
                    "title": "Update PPU Address",
                    "columns": ppu_columns,
                    "sample": ppu_sample,
                    "width":27  

                })
                        # loop through each section dynamically
            

            for section in change_type_sections:
                title = section["title"]
                columns = section["columns"]
                sample_vals = section["sample"]
                width=section["width"]

                # Title merge cell with gray background and border (column A, 2 rows tall)
                # ALL Change Type cells in column A get gray
                sample_ws.merge_range(
                    current_row, 0, 
                    current_row + 1, 0, 
                    title, 
                    header_gray_format  # Gray background for ALL Change Type cells
                )

                # Set column widths for this section's data columns
                for col_idx in range(len(columns)):
                    sample_ws.set_column(
                        COLUMN_DATA_START_COL + col_idx, 
                        COLUMN_DATA_START_COL + col_idx, 
                        width
                    )

                # Header rows with gray background (starting column B) - ONLY HEADERS
                for col_idx, col_name in enumerate(columns, start=COLUMN_DATA_START_COL):
                    # Header row - gray background
                    sample_ws.write(current_row, col_idx, col_name, header_gray_format)
                    
                    # Sample row - NO gray background for sample data
                    sample_val = sample_vals.get(col_name, "")
                    sample_ws.write(current_row + 1, col_idx, sample_val, regular_format)
                
                # Move down for next section (2 rows + spacing)
                current_row += 5
      
        logging.info("Simple combined sample data sheet created successfully as first sheet")
        # Get the blob data
        bio.seek(0)
        blob_data = base64.b64encode(bio.read())
        bio.close() 
        
        if not blob_data:
            logging.error("ERROR: blob_data is empty after reading BytesIO")
            return {"flag": False, "message": "Failed to generate Excel file - empty blob"}
        
        logging.info(f"Successfully generated blob data of size: {len(blob_data)} bytes")
        
        # Create response
        response = {"flag": True, "blob": blob_data.decode("utf-8")}
        
        # Log audit
        audit_data_user_actions = {
            "service_name": "download_bulk_upload_template",
            "created_date": data.get("request_received_at"),
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"download bulk upload template - All Change Type (Combined) for {service_provider}",
            "module_name": "Bulk Change",
            "request_received_at": data.get("request_received_at"),
        }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        
        return response
        
    except Exception as e:
        logging.exception(f"Exception occurred in generate_combined_templates: {e}")
        
        # Log error
        error_data = {
            "service_name": "generate_combined_templates",
            "created_date": data.get("request_received_at"),
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": "failed while download templates for all change type",
            "module_name": "Bulk Change",
            "request_received_at": data.get("request_received_at"),
        }
        
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        
        return {"flag": False, "message": f"Failed to generate combined templates !! {e}"}


#helper function for download templates
#fetch pdp apn    
def get_pdp_apn(service_provider,database):
    """
    Fetches PDP, APN, and Private Static IP range data for a given service provider.
 
    This function queries the service_provider_apn_pdp_ip table once and prepares:
    - PDP dropdown data
    - Private Static APN dropdown data
    - Private Static IP range mapping table
 
    Args:
        service_provider (str): Name of the service provider for which PDP/APN data is required.
        database (DB): Database connection object used to execute queries.
 
    Returns:
        tuple:
            - pdp_df (pandas.DataFrame): DataFrame containing unique PDP names
            - apn_df (pandas.DataFrame): DataFrame containing unique Private Static APNs
            - private_network_range_table_role (pandas.DataFrame): DataFrame mapping
    """
    logging.info(f"Fetching PDP/APN data for service provider: {service_provider}")
    # Default empty DataFrames
    pdp_df = pd.DataFrame(columns=["PDP Name"])
    apn_df = pd.DataFrame(columns=["Private Static APN"])
    private_network_range_table_role = pd.DataFrame(columns=["APN", "PDP", "IP Range"])
    try:
        # Fetch APN / PDP / IP data ONCE  role si super admin
        pdp_apn_full_df=database.get_data("service_provider_apn_pdp_ip",{"service_provider":service_provider},["service_provider","apn","ip_text","pdp"])

        if (
            pdp_apn_full_df is not None
            and not isinstance(pdp_apn_full_df, bool)
            and not pdp_apn_full_df.empty
        ):
            pdp_apn_full_df = pdp_apn_full_df.copy()

            #  PDP dropdown 
            pdp_df = pd.DataFrame({
                "PDP Name": sorted_unique(
                    pdp_apn_full_df["pdp"].dropna().astype(str).tolist()
                )
            })

            #  APN dropdown ]
            apn_df = pd.DataFrame({
                "Private Static APN": sorted_unique(
                    pdp_apn_full_df["apn"].dropna().astype(str).tolist()
                )
            })

            #  Private Static Range table 
            private_network_range_table_role = (
                pdp_apn_full_df
                .dropna(subset=["apn", "pdp"])
                .loc[:, ["apn", "pdp", "ip_text"]]
                .rename(columns={
                    "apn": "APN",
                    "pdp": "PDP",
                    "ip_text": "IP Range"
                })
                .reset_index(drop=True)
            )
        logging.info("APN / PDP / Private Static data prepared successfully")
        return {
            "flag": True,
            "pdp_df": pdp_df,
            "apn_df": apn_df,
            "private_network_range_table_role": private_network_range_table_role,
            "message": "PDP/APN data fetched successfully"
        }
    except Exception as e:
        logging.info(f"failed while fetch pdp/apn/Private Static data :{e}")
        return {
            "flag":False,
            "pdp_df": pdp_df,
            "apn_df": apn_df,
            "private_network_range_table_role": private_network_range_table_role,
            "message": "Failed to fetch PDP/APN data"
        }


#fetch rate plan, billing account number 
def get_rate_plan(database,service_provider,service_provider_change_type_data,tenant_id,username,common_utils_database,role_name,readme_flag):
    """
    Fetches rate plan, carrier rate plan, billing account, and private network data
    based on service provider, user role, and selected bulk change types.
 
    Args:
        database (DB): Database connection object used to fetch data from database
        service_provider (str): Name of the service provider (e.g., AT&T, Verizon) for which rate plan
        service_provider_change_type_data (set | list): Collection of selected bulk change types that determines which data
        tenant_id (int): Tenant identifier used to scope data to the correct tenant.
        username (str): Username of the logged-in user requesting the data.
        role_name (str): Role of the user (e.g., Super Admin, Partner Admin, Agent) which controls data visibility and access rules.
 
    Returns:
        tuple:
            - customer_rate_plan_code_df (pandas.DataFrame): DataFrame containing customer rate plan display values
            - carrier_rate_plan_df (pandas.DataFrame): DataFrame containing carrier rate plans for dropdown display, typically used for Change Carrier Rate Plan,
            - billing_account_data (pandas.DataFrame): DataFrame containing billing account numbers,
            - private_network_range_table (pandas.DataFrame): DataFrame mapping private static APNs to PDPs and IP ranges.
    """
    logging.info(f"### Fetching rate plan data for service provider: {service_provider}")
    if 'Telegence' in service_provider:
        carrier_col_name = "Rate Plan Code"
    else:
        carrier_col_name = "Carrier Rate Plan"
    customer_rate_plan_code_df = pd.DataFrame(columns=["Rate Plan Code"])
    active_customer_rate_plan_code_df = pd.DataFrame(columns=["Customer Rate Plan"])
    carrier_rate_plan_df=pd.DataFrame(columns=["Rate Plan Code"])
    billing_account_data=pd.DataFrame(columns=["Billing Account Number"])
    private_network_range_table=pd.DataFrame(columns=["APN", "PDP", "IP Range"])
    try:
        if role_name not in ('Super Admin', 'Partner Admin'):

            
            if {"Activate New Service","Reset Voicemail Password","Refresh A Line"}.intersection(service_provider_change_type_data):
                user_data = common_utils_database.get_data(
                    "user_module_tenant_mapping",
                    {
                        "user_name": username,
                        "tenant_id": tenant_id
                    },
                    ["customer_group"]
                )
                if not user_data.empty:
                    customer_group = user_data['customer_group'].iloc[0]         
                    if customer_group:
                        if {"Change Carrier Rate Plan","Update Device Status","Reset Voicemail Password","Refresh A Line","Activate New Service"}.intersection(service_provider_change_type_data):
                            # Get rate plan names from customer group
                            group_data = database.get_data(
                                "customergroups",
                                {"name": customer_group},
                                ["rate_plan_name","billing_account_number"]
                            )
                            
                            if not group_data.empty:
                                rate_plan_names = group_data['rate_plan_name'].iloc[0]
                                billing_account_data = pd.DataFrame({
                                    "Billing Account Number": group_data["billing_account_number"].dropna().unique().tolist()
                                })
                                # Parse the string representation into an actual list
                                try:
                                    # Clean the string and split into list
                                    rate_plan_str = rate_plan_names.strip("[]")
                                    # Use regex to extract quoted strings
                                    rate_plan_list = re.findall(r'"([^"]*)"', rate_plan_str)
                                    if rate_plan_list:
                                        # Build safe IN clause
                                        p = ', '.join([f"'{name}'" for name in rate_plan_list])
                                    logging.info(f"Rate Plan List: {rate_plan_list}")
                                    if "Activate New Service" in service_provider_change_type_data:
                                        if rate_plan_list:
                                            rate_plan_tuple = tuple(rate_plan_list)

                                            query = f"""
                                                SELECT rate_plan_name, soc_code
                                                FROM customerrateplan
                                                WHERE
                                                    is_active = TRUE
                                                    AND service_provider_name = '{service_provider}'
                                                    AND rate_plan_name IN {rate_plan_tuple}
                                                    AND tenant_id = {tenant_id}
         
                                                ORDER BY rate_plan_name
                                            """

                                            df = database.execute_query(query, True)
                                            records = df.to_dict(orient='records')

                                            # Build "rate_plan_name -- soc_code"
                                            records = [
                                                f"{rec['rate_plan_name']} -- {rec['soc_code'] or ''}"
                                                for rec in records
                                            ]


                                        customer_rate_plan_code_df = pd.DataFrame({"Rate Plan Code": records})

                                except Exception as e:
                                    logging.warning(f"Error parsing rate_plan_names string: {e}")
                                    rate_plan_list = []
                        if "Change Private Static IP Address" in service_provider_change_type_data:
                            private_network_df = database.get_data(
                                "customergroups",
                                {"name": customer_group, "is_active": True,"tenant_id": tenant_id},
                                ["private_networks_json"],
                            )
                        
                            if private_network_df is not None and not isinstance(private_network_df, bool) and not private_network_df.empty:
                                private_network_json = private_network_df.iloc[0]["private_networks_json"]
                            
                                all_pdp = set()
                                private_network_table=[]
                                private_network_range_table=None
                                if private_network_json and isinstance(private_network_json, list):
                                    for item in private_network_json:
                                        if isinstance(item, dict):
                                            pdp = item.get("pdp")
                                            apn = item.get("apn")
                                            ip_text = item.get("ip_range", "")
                                            service_provider_val = item.get("service_provider", "")
                                            # Check if service provider matches
                                            if pdp and service_provider_val and service_provider == service_provider_val:
                                                all_pdp.add(pdp)
                                            if pdp and apn and service_provider_val and service_provider == service_provider_val:
                                                private_network_table.append({
                                                    "apn": apn,
                                                    "pdp": pdp,
                                                    "ip_text": ip_text,
                                                    "service_provider": service_provider_val
                                                })
                            
                                if all_pdp:
                                    pdp_data = pd.DataFrame({
                                        "PDP Name": sorted(list(all_pdp))
                                    })
                                else:
                                    logging.warning(f"No PDP names found for service provider {service_provider}")

                                if private_network_table:
                                    private_network_range_table = pd.DataFrame(
                                        private_network_table,
                                        columns=["apn", "pdp", "ip_text"]
                                    )
                                    private_network_range_table.rename(
                                        columns={"apn": "APN", "pdp": "PDP", "ip_text": "IP Range"},
                                        inplace=True
                                    )

                                else:
                                    private_network_range_table = pd.DataFrame(columns=["APN", "PDP", "IP Range"])
                    if "Activate New Service" not  in service_provider_change_type_data:
                        query = f"""
                            SELECT crp.rate_plan_name, carp.rate_plan_code
                            FROM customerrateplan crp
                            JOIN customer_rate_plan_jasper_carrier_rate_plan crpjcrp
                                ON crp.id = crpjcrp.customer_rate_plan_id
                            JOIN carrier_rate_plan carp
                                ON crpjcrp.jasper_carrier_rate_plan_id = carp.id
                            WHERE crp.rate_plan_name IN ({p})
                        """
                        result = database.execute_query(query, True)   
                        if result is not None and not result.empty:
                            # Create display names by combining rate_plan_name and rate_plan_code
                            result["display_name"] = result["rate_plan_name"] + " -- " + result["rate_plan_code"]
                            rate_plan_list = sorted_unique(result["display_name"].to_list())
                            # Create DataFrame with proper column name
                            customer_rate_plan_code_df = pd.DataFrame({"Rate Plan Code": rate_plan_list})
                        else:
                            customer_rate_plan_code_df = pd.DataFrame(columns=["Rate Plan Code"])
            else:#update device status
                #fetch customer rate plan as original_names
                if readme_flag:
                    query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{username}' and tenant_id={tenant_id}"
                    filters = common_utils_database.execute_query(query, True)
                    if filters.empty:
                        query = f"""
                            SELECT customers, service_provider, customer_group
                            FROM user_module_tenant_mapping
                            WHERE user_name = '{username}' AND tenant_id = {tenant_id}
                        """
                        filters = common_utils_database.execute_query(query, True)
                else:
                    query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{username}' and tenant_id={tenant_id}"

                    filters = common_utils_database.execute_query(query, True)
                # Extract customer group if exists
                try:
                    customer_group = filters["customer_group"].to_list()[0]
                except:
                    customer_group = None
                if customer_group:
                    customer_group_data = database.get_data(
                        "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
                    )

                    if not customer_group_data.empty:
                        # Extract rate plan names
                        try:
                            customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
                        except Exception as e:
                            logging.exception("Error extracting rate_plan_name:", e)
                # Get additional rate plans created by this user
                try:
                    customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{username}'
                    '''
                    customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
                    if not customer_rate_plan_df.empty:
                        existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
                        if existing_rate_plans:
                            # Clean the customer value
                            fixed_customer_rate_plan_list=[]
                            # Clean the customer value
                            # If you want to ensure it's always a list:
                            if isinstance(customer_rate_plan_name, str):
                                customer_rate_plan_list = [customer_rate_plan_name]
                            elif isinstance(customer_rate_plan_name, tuple):
                                customer_rate_plan_list = list(customer_rate_plan_name)
                            else:
                                customer_rate_plan_list = customer_rate_plan_name  # Already a list

                            fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas
                            logging.info('customer_ rate plan list before extend:', fixed_customer_rate_plan_list)

                            # Extend with existing customers
                            fixed_customer_rate_plan_list.extend(existing_rate_plans)
                            logging.info('customer rate plan_list after extend:', fixed_customer_rate_plan_list)

                            # Optional: Convert back to tuple if needed
                            customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                            logging.info('final customer rate plan tuple:', customer_rate_plan_name)

                except Exception as e:
                    logging.exception(f"Error while fetching the customers for the user {username}: {e}")
                # Get original customer rate plan names from db_config
                try:
                    original_names = customer_rate_plan_name
                except Exception as e:
                    logging.exception(f"Exception while getting the customer_rate_plan_name {e}")
                    original_names = []
                        # Save the original customer rate plan names before deletion
                
                if original_names:
                    try:
                        quoted_names = [f"'{name}'" for name in original_names]
                        p = ','.join(quoted_names)
                        # Query to get both rate_plan_name and rate_plan_code
                        query = f"""
                            SELECT crp.rate_plan_name, carp.rate_plan_code
                            FROM customerrateplan crp
                            JOIN customer_rate_plan_jasper_carrier_rate_plan crpjcrp
                                ON crp.id = crpjcrp.customer_rate_plan_id
                            JOIN carrier_rate_plan carp
                                ON crpjcrp.jasper_carrier_rate_plan_id = carp.id
                            WHERE crp.rate_plan_name IN ({p})
                        """
                        result = database.execute_query(query, True)

                        # Create mapping from rate_plan_name to rate_plan_code
                        name_to_code = result.set_index('rate_plan_name')['rate_plan_code'].to_dict() if not result.empty else {}

                        # Fetch carrier rate plan data
                        carrier_data = database.get_data(
                            "carrier_rate_plan",
                            {
                                "service_provider": str(service_provider),
                                "is_active": True,
                                "is_retired": False,
                            },
                            ["friendly_name", "rate_plan_code"],
                        )

                        # Create mapping from rate_plan_code to friendly_name
                        code_to_friendly = carrier_data.set_index('rate_plan_code')['friendly_name'].to_dict() if not carrier_data.empty else {}
                        
                        # Build the rate plan list
                        rate_plan_codes = []
                        for name in original_names:
                            code = name_to_code.get(name)
                            if code and code in code_to_friendly:
                                # Use friendly_name as the display value
                                rate_plan_codes.append(code_to_friendly[code])
                        
                        # Create DataFrame
                        if rate_plan_codes:
                            customer_rate_plan_code_df = pd.DataFrame({"rate_plan_code": rate_plan_codes})
                            customer_rate_plan_code_df = customer_rate_plan_code_df.sort_values(by="rate_plan_code", ascending=True)
                            customer_rate_plan_code_df["Rate Plan Code"] = customer_rate_plan_code_df["rate_plan_code"].astype(str)
                            customer_rate_plan_code_df = customer_rate_plan_code_df[["Rate Plan Code"]]
                        else:
                            customer_rate_plan_code_df = pd.DataFrame(columns=["Rate Plan Code"])
                            
                    except Exception as e:
                        logging.exception(f"Error processing AT&T Telegence rate plans for agent: {str(e)}")
                        customer_rate_plan_code_df = pd.DataFrame(columns=["Rate Plan Code"])
                
                else:
                    customer_rate_plan_code_df = pd.DataFrame(columns=["Rate Plan Code"])
            
        else:  # For Super Admin and Partner Admin roles
            logging.info(f"service_provider_change_type_data: {service_provider_change_type_data}")
            if {"Change Private Static IP Address","Reset Voicemail Password","Refresh A Line"
                }.intersection(service_provider_change_type_data):
                billing_account_query = f"""
                        SELECT DISTINCT billing_account_number
                        FROM sim_management_inventory
                        WHERE tenant_id = {tenant_id}
                        AND is_active = true
                        AND billing_account_number IS NOT NULL
                        ORDER BY billing_account_number
                    """
                billing_account_df = database.execute_query(billing_account_query, flag=True)
                if billing_account_df is not None and not isinstance(billing_account_df, bool) and not billing_account_df.empty:
                    billing_account_data = pd.DataFrame({
                        "Billing Account Number": billing_account_df["billing_account_number"].tolist()
                    })
            
            if {"Update Device Status","Change Carrier Rate Plan","Activate New Service"}.intersection(service_provider_change_type_data):
                logging.info(f"service_provider: {service_provider}")
                # Get all carrier rate plans for AT&T Telegence
                carrier_data = database.get_data(
                    "carrier_rate_plan",
                    {
                        "service_provider": service_provider,
                        "is_active": True
                    },
                    ["friendly_name", "rate_plan_code"]
                )
                if "Change Carrier Rate Plan" in service_provider_change_type_data:
                    if (carrier_data is not None and 
                        not isinstance(carrier_data, bool) and 
                        not carrier_data.empty):

                        # Sort and reset index
                        carrier_data = carrier_data.sort_values(
                            by="friendly_name", ascending=True
                        ).reset_index(drop=True)
                        # Combine friendly_name with rate_plan_code if friendly_name is None
                        carrier_data['temp_name'] = carrier_data['friendly_name'].fillna(
                            carrier_data['rate_plan_code']
                        )
                        # Create sorted unique list for dropdown
                        carrier_dropdown_list = carrier_data['temp_name'].tolist()
                        carrier_rate_plan_df = pd.DataFrame({carrier_col_name: sorted(set(carrier_dropdown_list))})
                    else:
                        logging.warning("No carrier rate plans found or query failed")
                        carrier_rate_plan_df = pd.DataFrame(columns=[carrier_col_name])

                if "Activate New Service" in service_provider_change_type_data:
                    logging.info("### activate new service flow to fetch rate plan")
                    customer_data=database.get_data(
                        "customerrateplan",
                            {
                                "service_provider_name": service_provider,
                                "is_active": True,
                                "tenant_id": tenant_id
                            },
                             ["rate_plan_name", "soc_code"]
                        )
                    if (
                        customer_data is not None
                        and not isinstance(customer_data, bool)
                        and not customer_data.empty
                    ):
                        customer_data = customer_data.sort_values(
                            by="rate_plan_name",
                            ascending=True
                        ).reset_index(drop=True)
                        # take only rows where soc_code is NOT NULL
                        customer_data = customer_data[customer_data["soc_code"].notna()]
                        customer_data["temp_name"] = customer_data["rate_plan_name"].combine_first(
                            customer_data["soc_code"]
                        )

                        customer_data["Customer Rate Plan"] = (
                            customer_data["temp_name"].astype(str)
                            + " -- "
                            + customer_data["soc_code"].fillna("").astype(str)
                        )

                        active_customer_rate_plan_code_df = customer_data[["Customer Rate Plan"]]
                    else:
                        active_customer_rate_plan_code_df = pd.DataFrame(columns=["Customer Rate Plan"])

                if "Update Device Status" in service_provider_change_type_data:
                    if (
                        carrier_data is not None
                        and not isinstance(carrier_data, bool)
                        and not carrier_data.empty
                    ):
                        carrier_data = carrier_data.sort_values(
                            by="friendly_name",
                            ascending=True
                        ).reset_index(drop=True)

                        carrier_data["temp_name"] = carrier_data["friendly_name"].combine_first(
                            carrier_data["rate_plan_code"]
                        )

                        carrier_data["Rate Plan Code"] = (
                            carrier_data["temp_name"].astype(str)
                            + " -- "
                            + carrier_data["rate_plan_code"].fillna("").astype(str)
                        )

                        customer_rate_plan_code_df = carrier_data[["Rate Plan Code"]]
                    else:
                        customer_rate_plan_code_df = pd.DataFrame(columns=["Rate Plan Code"])
                
        return {
                "flag":True,
                "customer_rate_plan_code_df": customer_rate_plan_code_df,
                "active_customer_rate_plan_code_df":active_customer_rate_plan_code_df,
                "carrier_rate_plan_df": carrier_rate_plan_df,
                "billing_account_data": billing_account_data,
                "private_network_range_table":private_network_range_table,
                "message": "Successfully fetch rate plan data"
            }   
    except Exception as e:
        logging.info(f"### Failed to fetch rate plan / billing account data: :{e}")
        return {
            "flag":False,
            "customer_rate_plan_code_df": customer_rate_plan_code_df,
            "active_customer_rate_plan_code_df":active_customer_rate_plan_code_df,
            "carrier_rate_plan_df": carrier_rate_plan_df,
            "billing_account_data": billing_account_data,
            "private_network_range_table":private_network_range_table,
            "message": "Failed to fetch rate plan data"
        }      


#fetch customer rate plan for change iccid imei,customer rate plan chnage type
def get_customer_rate_plan(tenant_id,database,service_provider):  
    """
    Fetches active customer rate plans for a given tenant and service provider.
 
    It retrieves all active customer rate plans that match the provided
    service provider and tenant, and prepares them in a display-friendly
    format for dropdown selection.
 
    Args:
        tenant_id (int): Tenant identifier used to filter customer rate plans belonging to a specific tenant.
        database (DB): Database connection object used to execute the rate plan query.
        service_provider (str): Name of the service provider used to filter rate plans
 
    Returns:
        pandas.DataFrame:DataFrame containing customer rate plans ,

    """
    logging.info(f"### Fetching rate plan data for service provider: {service_provider}") 
    rate_plan_df=pd.DataFrame(columns=["Customer Rate Plan"])
    try:
        rate_plan_query = f'''
                SELECT rate_plan_name, id,rate_plan_code
                FROM public.customerrateplan
                WHERE is_active = True
                AND service_provider_name LIKE '%%{service_provider}%%'
                AND tenant_id = {tenant_id}
                ORDER BY rate_plan_name ASC
            '''
        rate_plan_df = database.execute_query(rate_plan_query, flag=True, no_filter_append=True)
        if (
            rate_plan_df is not None
            and not isinstance(rate_plan_df, bool)
            and not rate_plan_df.empty
        ):
            
            if not rate_plan_df.empty:
                rate_plan_df["Customer Rate Plan"] = (
                    rate_plan_df["rate_plan_name"].astype(str) + " -- " +
                    rate_plan_df["id"].astype(str)
                )

                rate_plan_df = rate_plan_df[["Customer Rate Plan"]]
            else:
                rate_plan_df = pd.DataFrame(columns=["Customer Rate Plan"])
        else:
            rate_plan_df = pd.DataFrame(columns=["Customer Rate Plan"])  
        return {
            "flag":True,
            "rate_plan_df": rate_plan_df,
            "message": "Successfully fetch rate plan for chnage iccid,customer rateplan chnage type"
        }       
    except Exception as e:
        logging.info(f"### Failed to fetch rate plan: :{e}")
        return {
            "flag":False,
            "rate_plan_df": rate_plan_df,
            "message": "Failed to fetch rate plan for chnage iccid,customer rateplan chnage type"
        }   

#state df
def get_state_data(): 
    """
    Fetch and prepare U.S. state names data.
 
    Returns:
        pandas.DataFrame:
            A DataFrame with the following columns:
                - State Name (str): Full name of the U.S. state
                - Code (str): Two-letter state code
 
            If no state data is available, an empty DataFrame with
            columns ["State Name", "Code"] is returned.
    """
    logging.info("### Fetching state data")
    state_df=pd.DataFrame(columns=["Code"]) 
    try:
        #state data
        state_data = sorted([
            {"name": "Alabama", "code": "AL"}, {"name": "Alaska", "code": "AK"}, {"name": "Arizona", "code": "AZ"},
            {"name": "Arkansas", "code": "AR"}, {"name": "California", "code": "CA"}, {"name": "Colorado", "code": "CO"},
            {"name": "Connecticut", "code": "CT"}, {"name": "District of Columbia", "code": "DC"}, {"name": "Delaware", "code": "DE"},
            {"name": "Florida", "code": "FL"}, {"name": "Georgia", "code": "GA"}, {"name": "Hawaii", "code": "HI"},
            {"name": "Idaho", "code": "ID"}, {"name": "Illinois", "code": "IL"}, {"name": "Indiana", "code": "IN"},
            {"name": "Iowa", "code": "IA"}, {"name": "Kansas", "code": "KS"}, {"name": "Kentucky", "code": "KY"},
            {"name": "Louisiana", "code": "LA"}, {"name": "Maine", "code": "ME"}, {"name": "Maryland", "code": "MD"},
            {"name": "Massachusetts", "code": "MA"}, {"name": "Michigan", "code": "MI"}, {"name": "Minnesota", "code": "MN"},
            {"name": "Mississippi", "code": "MS"}, {"name": "Missouri", "code": "MO"}, {"name": "Montana", "code": "MT"},
            {"name": "Nebraska", "code": "NE"}, {"name": "Nevada", "code": "NV"}, {"name": "New Hampshire", "code": "NH"},
            {"name": "New Jersey", "code": "NJ"}, {"name": "New Mexico", "code": "NM"}, {"name": "New York", "code": "NY"},
            {"name": "North Carolina", "code": "NC"}, {"name": "North Dakota", "code": "ND"}, {"name": "Ohio", "code": "OH"},
            {"name": "Oklahoma", "code": "OK"}, {"name": "Oregon", "code": "OR"}, {"name": "Pennsylvania", "code": "PA"},
            {"name": "Rhode Island", "code": "RI"}, {"name": "South Carolina", "code": "SC"}, {"name": "South Dakota", "code": "SD"},
            {"name": "Tennessee", "code": "TN"}, {"name": "Texas", "code": "TX"}, {"name": "Utah", "code": "UT"},
            {"name": "Vermont", "code": "VT"}, {"name": "Virginia", "code": "VA"}, {"name": "Washington", "code": "WA"},
            {"name": "West Virginia", "code": "WV"}, {"name": "Wisconsin", "code": "WI"}, {"name": "Wyoming", "code": "WY"},
        ], key=lambda x: x["name"])
        if state_data:
            state_df = pd.DataFrame(state_data)
            if "name" in state_df.columns and "code" in state_df.columns:
                state_df["State Name"] = state_df["name"].astype(str)
                state_df["Code"] = state_df["code"].astype(str)
                state_df = state_df[["State Name", "Code"]]
        else:
            state_df = pd.DataFrame(columns=["State Name", "Code"])
        return {
            "flag":True,
            "state_df": state_df,
            "message": "Successfully fetch state data"
        }
    except Exception as e:
        logging.info(f"### Failed to fetch state data: :{e}")
        return {
            "flag":False,
            "state_df": state_df,
            "message": "Failed to fetch state data"
        }

#fetch rate pool
def get_rate_pool(database,tenant_id,service_provider):
    """
    Fetch active customer rate pools for a given tenant and service provider.
 
    Parameters:
        database: Database connection object used to execute queries.
        tenant_id (int): Tenant identifier.
        service_provider (str): Service provider name used for filtering rate pools.
 
    Returns:
        dict:
            {
                "flag" (bool): Indicates success or failure of the operation.
                "rate_pool_df" (pandas.DataFrame):
                    DataFrame with column:
                        - "Customer Rate Pool" (formatted as "name -- id")
                "message" (str): Status message describing the result.
            }
    """
    logging.info(f"Fetching rate pool data for tenant_id: {tenant_id} and service_provider: {service_provider}")
    rate_pool_df=pd.DataFrame(columns=["Customer Rate Pool"]) 
    try:
        customer_rate_pool_query = f'''
                SELECT name, id
                FROM public.customer_rate_pool
                WHERE is_active = True
                AND service_provider_name LIKE '%%{service_provider}%%'
                AND tenant_id = {tenant_id}
                ORDER BY name ASC
            '''
        rate_pool_df = database.execute_query(customer_rate_pool_query, flag=True, no_filter_append=True)

        if (
            rate_pool_df is not None
            and not isinstance(rate_pool_df, bool)
            and not rate_pool_df.empty
        ):

            rate_pool_df["Customer Rate Pool"] = (
                rate_pool_df["name"].astype(str)
                + " -- "
                + rate_pool_df["id"].astype(str)
            )

            rate_pool_df = rate_pool_df[["Customer Rate Pool"]]
           
        else:
            rate_pool_df = pd.DataFrame(columns=["Customer Rate Pool"])
        return {
            "flag":True,
            "rate_pool_df": rate_pool_df,
            "message": "Successfully  fetch rate pool"
        }

    except Exception as e:
        logging.info(f"### Failed to fetch rate pool :{e}")
        return {
            "flag":False,
            "rate_pool_df": rate_pool_df,
            "message": "Failed to fetch rate pool"
        }

#fetch customer name 
def get_customer(role_name,billing_platform_flag,integration_id,tenant_id,service_provider_change_type_data,database,tenant_name,common_utils_database):
    """
    Fetch customer names based on role permissions, billing platform settings,
    tenant configuration, and service provider change type.
 
    Parameters:
        role_name (str): Role of the logged-in user.
        billing_platform_flag (bool): Indicates billing platform enabled status.
        integration_id (int): Integration authentication ID.
        tenant_id (int): Tenant identifier.
        service_provider_change_type_data (list): Change type data affecting customer context.
        database: Database connection for tenant-specific tables.
        tenant_name (str): Name of the tenant.
        common_utils_database: Database connection for common utility tables.
 
    Returns:
        pandas.DataFrame:
            A DataFrame containing customer names with column:
                - "Customer Name" or "Billing Customer" (based on context)
    """
    logging.info(f"Fetching customer data for role_name: {role_name} and billing_platform_flag: {billing_platform_flag}")
    # fetching customer names based on the module_status and billing_platform_flag
    if "Assign Customer" in service_provider_change_type_data:
        customer_name_df = pd.DataFrame(columns=["Billing Customer"])
    else:
        customer_name_df = pd.DataFrame(columns=["Customer Name"])
    try:
        role_module_data = common_utils_database.get_data(
            "role_module",
            {
                "role": role_name
            },
            ["sub_module"]    
        )

        module_status = False
        if not role_module_data.empty:
            try:
                # Parse JSON safely with fallback
                sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                # Strict nested check
                if "People" in sub_modules:
                    people_modules = sub_modules["People"]
                    if isinstance(people_modules, list):  # Ensure it's a list
                        module_status = "Billing Customers" in people_modules

            except json.JSONDecodeError:
                logging.error(f"Invalid JSON in sub_module for role: {role_name}")
            except KeyError:
                pass  # People section not present
            except Exception as e:
                logging.error(f"Unexpected error processing modules: {str(e)}")


        if module_status and tenant_name != 'WingTel' and billing_platform_flag == False:
            customer_name_list = sorted_unique(
                database.get_data(
                    "revcustomer",
                    {"is_active": True, "bp_customer": False, "integration_authentication_id": integration_id, "tenant_id": tenant_id, "status": ['open', 'Open', 'OPEN']},
                    concat_columns=["customer_name", "rev_customer_id"]
                )["concat_column"].to_list()
            )
            # Convert list to DataFrame with proper column name
            customer_name_df = pd.DataFrame({"Customer Name": customer_name_list})
            
        elif module_status and billing_platform_flag:
            # Both revcustomer and customers
            query = f"""
                SELECT customer_name, rev_customer_id AS id
                FROM revcustomer
                WHERE is_active = TRUE
                AND integration_authentication_id = {integration_id}
                AND tenant_id = {tenant_id}
                AND status IN ('open', 'Open', 'OPEN')
            """
            df1 = database.execute_query(query, flag=True, non_flag='True')
            # Format customer_name
            df1["customer_name"] = df1["customer_name"]
            df2 = database.get_data(
                "customers",
                {"tenant_id": str(tenant_id), "is_active": True, "billing_platform_flag": True},
                ["customer_name", "id"],
            )
            df2["customer_name"] = df2["customer_name"]
            df = pd.concat([df1, df2], ignore_index=True, sort=False)

            customer_name_list = sorted(df["customer_name"].unique().tolist()) if not df.empty else []
            # Convert list to DataFrame with proper column name
            customer_name_df = pd.DataFrame({"Customer Name": customer_name_list})

        else:
            # Build SQL query
            customer_name_data = database.get_data(
                table_name="customers",
                condition={
                    "tenant_id": tenant_id,
                    "is_active": True
                },
                columns=["customer_name", "id"]
            )

            if customer_name_data is not None and not customer_name_data.empty:
                #customer_name_data["customer_name"] = customer_name_data["customer_name"] + " -- " + customer_name_data["id"].astype(str)
                customer_name_data["customer_name"] = customer_name_data["customer_name"]
                customer_name_df = pd.DataFrame({"Customer Name": sorted(customer_name_data["customer_name"].unique().tolist())})
            else:
                customer_name_df = pd.DataFrame(columns=["Customer Name"])
        return {
            "flag":True,
            "customer_name_df": customer_name_df,
            "message": "Successfully  fetch customer name"
        }
    except Exception as e:
        logging.info(f"### Failed to fetch customer name for customer rate plan and assign customer change type :{e}")
        return {
            "flag":False,
            "customer_name_df": customer_name_df,
            "message": "Failed to fetch customer name"
        }

#fecth feature codes
def get_feature_code(service_provider_id,service_provider,service_provider_change_type_data,database,service_provider_id_feature):
    """
    Fetch feature codes for service activation or feature update operations.Feature codes are returned in a UI-friendly DataFrame, and SOC codes
    required for update operations are returned separately.
 
    Parameters:
        service_provider_id (int): Service provider identifier.
        service_provider (str): Service provider name used for filtering feature codes.
        service_provider_change_type_data (list): List of change types (e.g., "Activate New Service", "Update Features").
        database: Database connection object used for data retrieval.
        service_provider_id_feature (int):  Service provider ID used specifically for feature update queries.
    Returns:dict:{
                "flag" (bool): Indicates success or failure.
                "feature_code_df" (pandas.DataFrame):
                    DataFrame containing:
                        - "Feature Codes" (list of SOC/feature codes)
                "soc_codes" (list):
                    Raw SOC codes used for update feature operations.
                "message" (str): Status message describing the result.}
    """
    logging.info(f"Fetching feature code for service_provider_id: {service_provider_id} and service_provider: {service_provider}")
    feature_code_df=pd.DataFrame(columns=["Feature Codes"])
    soc_codes=[]
    try:
        if "Update Features" in service_provider_change_type_data:
            soc_codes_data = database.get_data(
                    table_name="mobility_feature",
                    condition={
                        "service_provider_id": service_provider_id_feature,
                        "is_active": True,
                        "is_deleted": False,
                        "is_retired": False,
                    },
                    columns=["soc_code"],
                    order={"soc_code": "asc"},
                )
            if soc_codes_data is not None and not soc_codes_data.empty:
                soc_codes = soc_codes_data["soc_code"].tolist()
            else:
                soc_codes = []
        if "Activate New Service" in service_provider_change_type_data:
            #  Fetch Feature Codes
            feature_result = database.get_data(
                "mobility_feature",
                {
                    "service_provider_name": service_provider,
                    "is_active": True,
                    "is_retired": False
                },
                ["friendly_name", "soc_code"]
            )
            # Create the concatenated column in Python
            if feature_result is not None and not feature_result.empty:
                feature_result["feature_code"] = (
                    feature_result["soc_code"].astype(str)
                )
            if (
                feature_result is not None 
                and not isinstance(feature_result, bool) 
                and not feature_result.empty
            ):
                feature_codes_list = sorted_unique(feature_result["feature_code"].to_list())
                feature_code_df = pd.DataFrame({"Feature Codes": feature_codes_list})
            else:
                feature_code_df = pd.DataFrame(columns=["Feature Codes"])
        return {
            "flag":True,
            "feature_code_df": feature_code_df,
            "soc_codes":soc_codes,
            "message": "Successfully fetch feature code"
        }
    except Exception as e:
        logging.info(f"### Failed to fetch feature codes:{e}")
        return {
            "flag":False,
            "feature_code_df": feature_code_df,
            "soc_codes":soc_codes,
            "message": "Failed to fetch feature code"
        }
        

def bulk_upload_all_change_types_from_excel(data):
    """
    Wrapper function to process multiple bulk change types in parallel.
    
    Args:
        data (dict): Input data containing Excel file and processing details
            - blob_data: Base64 encoded Excel file
            - service_provider: Service provider name
            - db_name: Database name
            - username: User performing the action
            - session_id: Session ID
            - tenant_name: Tenant name
            - request_received_at: Timestamp
            - change_type: Can be "All" or specific type
    
    Returns:
        dict: Combined results from all processed change types
    """
    logging.info(f"### bulk_upload_all_change_types_from_excel called with data keys: ")
    
    # Database connection
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "Database connection failed",
            "error": str(e)
        }
    
    try:
        # Process blob data
        blob_data = data.get("blob_data", None)
        if not blob_data:
            return {
                "flag": False,
                "message": "No blob data provided"
            }
        
        # Extract and decode the blob data
        if "," in blob_data:
            blob_data = blob_data.split(",", 1)[1]
        
        # Add padding for base64 decoding
        blob_data += "=" * (-len(blob_data) % 4)
        
        file_stream = BytesIO(base64.b64decode(blob_data))
        
        # Read all sheets from Excel
        uploaded_excel = pd.read_excel(
            file_stream, 
            engine="openpyxl", 
            sheet_name=None,
            dtype={'Iccid': str, 'ICCID': str, 'Msisdn': str, 'MSISDN': str}  # Common column name variations
        )
        # taking the tenant_id 
        tenant_id = data.get("tenant_id", None)
        if not tenant_id:
            tenant_name = data.get("tenant_name")
            if tenant_name =="Altaworx Test":
                tenant_name = "Altaworx"
            tenant_data = common_utils_database.get_data(
                "tenant",
                {"tenant_name": tenant_name},
                ["id"]
            )
            tenant_id = tenant_data.iat[0, 0] if not tenant_data.empty else None
            data["tenant_id"] = int(tenant_id) if tenant_id else None
            if not tenant_id:
                return {
                    "flag": False,
                    "message": "Tenant not found"
                }

        logging.info(f"### Uploaded Excel sheets found: {list(uploaded_excel.keys())}")
        all_sheets_empty = True
        for sheet_name, df in uploaded_excel.items():
            # Skip "Devices" sheet from empty check
            if sheet_name == "Devices" or sheet_name == "Sample Data" or sheet_name=="IP Address Range":
                continue
            
            # ALSO SKIP HIDDEN SHEETS (those starting with '_hidden_')
            if sheet_name.startswith('_hidden_'):
                logging.info(f"### Skipping hidden sheet '{sheet_name}' from empty check")
                continue
            
            # Remove empty rows (all NaN) and check if any data remains
            df_clean = df.dropna(how='all')
            logging.info(f"### Sheet '{sheet_name}' has {len(df_clean)} rows after removing empty rows")
            if len(df_clean) > 0:
                all_sheets_empty = False
                break

        if all_sheets_empty:
            logging.info("### All non-hidden sheets are empty, returning error message")
            return {
                "flag": False,
                "error_type": "Warning",
                "message": "Fill the data in at least one Excel sheet. All sheets are empty."
            }
        
        # Remove blob data from original data dict
        original_data = data.copy()
        original_data.pop("blob_data", None)
        
        # Create result queue for thread outputs
        result_queue = queue.Queue()
        threads = []
        results = {}
        
        common_sheet_name = "Devices"
        if common_sheet_name in uploaded_excel:
            common_df = uploaded_excel[common_sheet_name]
            common_df = common_df.replace({pd.NA: "", pd.NaT: "", np.nan: ""}).fillna("")
            common_df.columns = common_df.columns.str.strip().str.title()
            
            # Extract columns
            iccids = common_df.loc[common_df["Iccid"].str.strip() != "", "Iccid"].astype(str).str.strip().tolist()
            msisdns = common_df.loc[common_df["Msisdn"].str.strip() != "", "Msisdn"].astype(str).str.strip().tolist()
            imeis = common_df['Imei'].astype(str).str.strip().tolist() if 'Imei' in common_df.columns else []
            ip_addresses = common_df['Ip Address'].astype(str).str.strip().tolist() if 'Ip Address' in common_df.columns else []
            
            if iccids and msisdns:
                return {
                        "flag": False,
                        "message": "Both ICCID and MSISDN columns are present. Only one column should be present. in the Devices sheet",
                        "error_type": "Warning"
                    } 
            if not iccids and not msisdns:
                return {
                    "flag": False,
                    "message": "Please provide either ICCIDs or MSISDNs in the Devices sheet.",
                    "error_type": "Warning"
                }
            
            # Add to original_data for use in subfunctions
            original_data['iccids'] = iccids
            original_data['msisdns'] = msisdns
            original_data['imeis'] = imeis
            original_data['ip_addresses'] = ip_addresses
            
            logging.info(f"### Extracted from common sheet: ICCIDs={len(iccids)}, MSISDNs={len(msisdns)}, IMEIs={len(imeis)}, IPs={len(ip_addresses)}")
        else:
            return {
                "flag": False,
                "message": f"Required sheet '{common_sheet_name}' not found in uploaded file."
            }
        
        # ---------- CROSS SHEET VALIDATION : Assign Customer vs Customer Rate Plan ----------
        if (
            "Assign Customer" in uploaded_excel
            and "Customer Rate Plan" in uploaded_excel
            and not uploaded_excel["Assign Customer"].dropna(how="all").empty
            and not uploaded_excel["Customer Rate Plan"].dropna(how="all").empty
        ):
            assign_df = uploaded_excel["Assign Customer"].replace(
                {pd.NA: "", pd.NaT: "", np.nan: ""}
            ).fillna("")
            assign_df.columns = assign_df.columns.str.strip().str.title()

            crp_df = uploaded_excel["Customer Rate Plan"].replace(
                {pd.NA: "", pd.NaT: "", np.nan: ""}
            ).fillna("")
            crp_df.columns = crp_df.columns.str.strip().str.title()

            # -------- Extract UNIQUE non-empty values --------
            billing_customers = assign_df["Billing Customer"].str.strip()
            billing_customers = billing_customers[billing_customers != ""].unique()

            customer_pools = assign_df["Customer Pool"].str.strip()
            customer_pools = customer_pools[customer_pools != ""].unique()

            customer_rate_plans_assign = assign_df["Customer Rate Plan"].str.strip()
            customer_rate_plans_assign = customer_rate_plans_assign[
                customer_rate_plans_assign != ""
            ].unique()

            effective_dates_assign = assign_df["Effective Date"].astype(str).str.strip()
            effective_dates_assign = effective_dates_assign[
                effective_dates_assign != ""
            ].unique()
            # Handle optional Customer Name column (billing_platform_flag based)
            if "Customer Name" in crp_df.columns:
                customer_names = crp_df["Customer Name"].astype(str).str.strip()
                customer_names = customer_names[customer_names != ""].unique()
            else:
                customer_names = []

            customer_rate_pools = crp_df["Customer Rate Pool"].str.strip()
            customer_rate_pools = customer_rate_pools[customer_rate_pools != ""].unique()

            customer_rate_plans_crp = crp_df["Customer Rate Plan"].str.strip()
            customer_rate_plans_crp = customer_rate_plans_crp[
                customer_rate_plans_crp != ""
            ].unique()

            effective_dates_crp = crp_df["Effective Date"].astype(str).str.strip()
            effective_dates_crp = effective_dates_crp[
                effective_dates_crp != ""
            ].unique()

            # -------- Compare with EMPTY-AWARE LOGIC --------
            mismatched_columns = []

            if (len(billing_customers) > 0 and len(customer_names) > 0) and (
                set(billing_customers) != set(customer_names)
            ):
                mismatched_columns.append("Customer Name")

            if (len(customer_pools) > 0 and len(customer_rate_pools) > 0) and (
                set(customer_pools) != set(customer_rate_pools)
            ):
                mismatched_columns.append("Customer Rate Pool")

            if (len(customer_rate_plans_assign) > 0 and len(customer_rate_plans_crp) > 0) and (
                set(customer_rate_plans_assign) != set(customer_rate_plans_crp)
            ):
                mismatched_columns.append("Customer Rate Plan")

            if (len(effective_dates_assign) > 0 and len(effective_dates_crp) > 0) and (
                set(effective_dates_assign) != set(effective_dates_crp)
            ):
                mismatched_columns.append("Effective Date")

            if mismatched_columns:
                return {
                    "flag": False,
                    "error_type": "Warning",
                    "message": (
                        "Assign Customer and Customer Rate Plan sheets contain different values in "
                        f"{', '.join(mismatched_columns)}. "
                        "Please fill the same data in both sheets."
                    )
                }

        # ---- CROSS SHEET VALIDATION : Communication Plan vs Carrier Rate Plan for Communication plan column ----
        if (
            "Communication Plan" in uploaded_excel
            and "Carrier Rate Plan" in uploaded_excel
            and not uploaded_excel["Communication Plan"].dropna(how="all").empty
            and not uploaded_excel["Carrier Rate Plan"].dropna(how="all").empty
        ):
            comm_df = uploaded_excel["Communication Plan"].replace(
                {pd.NA: "", pd.NaT: "", np.nan: ""}
            ).fillna("")
            comm_df.columns = comm_df.columns.str.strip().str.title()

            carrier_df = uploaded_excel["Carrier Rate Plan"].replace(
                {pd.NA: "", pd.NaT: "", np.nan: ""}
            ).fillna("")
            carrier_df.columns = carrier_df.columns.str.strip().str.title()

            # ---- Extract Communication Plan values from both sheets ----
            # Handle optional Communication Plan column safely

            if "Communication Plan" in comm_df.columns:
                comm_values = (
                    comm_df["Communication Plan"]
                    .astype(str)
                    .str.strip()
                )
                comm_values = comm_values[comm_values != ""].unique()
            else:
                comm_values = []

            if "Communication Plan" in carrier_df.columns:
                carrier_values = (
                    carrier_df["Communication Plan"]
                    .astype(str)
                    .str.strip()
                )
                carrier_values = carrier_values[carrier_values != ""].unique()
            else:
                carrier_values = []

            # ---- Validation Rule ----
            # Case 1: One sheet empty → OK
            if len(comm_values) == 0 or len(carrier_values) == 0:
                logging.info("### Communication Plan validation skipped because one sheet is empty")

            # Case 2: Both present → Must match
            elif set(comm_values) != set(carrier_values):
                return {
                    "flag": False,
                    "error_type": "Warning",
                    "message": (
                        "Communication Plan values mismatch between "
                        "Carrier Rate Plan sheet and Communication Plan sheet. "
                        "If you provide values in both sheets, they must be the same."
                    )
                }

        # ---------- END CROSS SHEET VALIDATION ----------
        # Check which sheets exist and create corresponding threads
        sheet_to_function_map = {
            "Customer Rate Plan": process_customer_rate_plan_sheet,
            "Update Device Status": process_device_status_sheet,
            "Activate New Service": process_activate_new_service_sheet,
            "Archive": process_archive_sheet ,
            "Edit Username & Cost Center": process_edit_cost_center_sheet ,
            "Line Sync": process_line_sync_sheet,
            "Update Feature Codes":process_update_feature_codes_sheet,
            "Refresh A Line": process_refresh_a_line_sheet,
            "Update PPU Address":process_update_ppu_address_sheet,
            "Carrier Rate Plan":process_carrier_rate_plan_sheet,
            "Assign Customer":process_assign_customer_sheet,  
            "Private Static IP Address":process_private_static_ip_address_sheet,
            "Change Phone Number":process_change_phone_number_sheet,
            "Send SMS":process_send_sms_sheet,
            "Reset Voicemail Password":process_reset_voice_email_password_sheet,
            "Change ICCID & IMEI":process_change_iccid_imei_sheet,
            "Communication Plan":process_communication_plan_sheet
        }
        # Update device Status Customer Rate Plan Activate New Service 
        
        # Determine which change types to process
        sheets_to_process = []

        # Check which sheets exist in the uploaded file
        for sheet_name, sheet_func in sheet_to_function_map.items():
            if sheet_name in uploaded_excel:
                sheets_to_process.append((sheet_name, sheet_func))
            else:
                logging.warning(f"### Sheet '{sheet_name}' not found in uploaded file")
        
        if not sheets_to_process:
            return {
                "flag": False,
                "message": f"No valid sheets found for processing."
            }
        # Create and start threads for each sheet
        for sheet_name, sheet_func in sheets_to_process:
            logging.info(f"sheetname:{sheet_name}")
            sheet_data = uploaded_excel[sheet_name]
            sheet_data = sheet_data.replace({pd.NA: "", pd.NaT: "", np.nan: ""})
            sheet_data = sheet_data.fillna("")
            sheet_data.columns = sheet_data.columns.str.strip().str.title()
            
            # COLUMN UNIFORMITY IccidVALIDATION (NON-BLOCKING) 
            allowed_variable_columns = {"Iccid","Msisdn"}  # MSISDN always allowed
            # Remove ICCID for Change Phone Number
            if sheet_name == "Change Phone Number":
                allowed_variable_columns.discard("Iccid")

            if sheet_name == "Activate New Service":
                allowed_variable_columns.discard("Msisdn")
                allowed_variable_columns.update({"Imei","Feature Codes"})    
            
            if sheet_name == "Private Static IP Address":
                allowed_variable_columns.update({"Private Static Ip"})

            if sheet_name == "Change ICCID & IMEI":
                allowed_variable_columns.update({"Imei"})

            if sheet_name == "Update Feature Codes":
                allowed_variable_columns.update({"Update Feature Codes","Remove Feature Codes"})
                
            if sheet_name == "Assign Customer":
                allowed_variable_columns.update({"Billing Product"})    


            invalid_columns = []
            for col in sheet_data.columns:
                if col in allowed_variable_columns:
                    continue
                unique_vals = (
                    sheet_data[col]
                    .replace(
                        ["", " ", "nan", "NaN", "none", "None", "NULL", "null"],
                        pd.NA
                    )
                    .dropna()
                    .unique()
                )

                if len(unique_vals) > 1:
                    invalid_columns.append(col)

            # If validation fails → record error and SKIP this sheet
            if invalid_columns:
                result_queue.put({
                    "change_type": sheet_name,
                    "result": {
                        "flag": False,
                        "message": (
                            f"Validation failed. Column(s) {invalid_columns} must contain "
                            f"only one unique value."
                        )
                    }
                })
                logging.error(
                    f"### Validation failed for sheet '{sheet_name}', columns: {invalid_columns}"
                )
                continue
            # ---- END VALIDATION ----
            # Create thread ONLY if validation passed
            thread = threading.Thread(
                target=lambda sd=sheet_data, od=original_data, sf=sheet_func,
                            sn=sheet_name, q=result_queue:
                    process_sheet_in_thread(sd, od, sf, sn, q),
                daemon=False,
                name=f"Thread_{sheet_name}_{len(threads)}"
            )
            threads.append(thread)
            thread.start()
            logging.info(f"### Started thread for sheet: {sheet_name}")
        
        # Wait for all threads to complete
        logging.info(f"### Waiting for {len(threads)} threads to complete...")
        for thread in threads:
            thread.join()
        logging.info("### All threads completed")
        # Collect results from queue
        all_successful = True
        error_messages = []
        
        while not result_queue.empty():
            sheet_result = result_queue.get()
            if sheet_result:
                change_type = sheet_result.get("change_type")
                result_data = sheet_result.get("result", {})
                results[change_type] = {
                    "change_type": change_type,
                    "result": result_data
                }
                
                # Check if this sheet had validation errors (flag is False)
                if not result_data.get("flag", True):
                    all_successful = False
                    error_msg = result_data.get("message", f"Error in {change_type}")
                    error_messages.append(f"{change_type}: {error_msg}")

        # Prepare combined message if there are errors
        if not all_successful:
            combined_message = ""
            if error_messages:
                combined_message = "\n".join(error_messages)
            
            try:
                # Audit logging for failure case
                audit_comments_failed = {
                    "processed_sheets": [sheet for sheet, _ in sheets_to_process],
                    "failed_results": {k: v["result"].get("message", "Unknown error") for k, v in results.items() if not v["result"].get("flag", True)},
                    "warning": "For Some change types failed validation"
                }
                
                audit_data_user_actions = {
                    "service_name": "bulk_upload_all_change_types_from_excel",
                    "created_date": original_data.get("request_received_at", datetime.now()),
                    "created_by": original_data.get("username", ""),
                    "status": "Failed",
                    "session_id": original_data.get("session_id", ""),
                    "tenant_name": original_data.get("tenant_name", ""),
                    "comments": json.dumps(audit_comments_failed, default=str),
                    "module_name": "Bulk Changes",
                    "request_received_at": original_data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.error(f"### bulk_upload_all_change_types_from_excel auditing failed in error case: {e}")
            
            # Return failure response
            response = {
                "flag": False,
                "total_change_types_processed": f"{len(results)} change type(s) processed successfully",
                "message": combined_message,
                "error_type": "Warning",
                "data": results  # Still include results so UI knows which specific ones failed
            }
            logging.info(f"#### response : {response}")
            return response
        
        # If all successful, proceed with original success flow
        try:
            # Audit logging
            audit_comments = {
                "processed_sheets": [sheet for sheet, _ in sheets_to_process],
                "results_summary": {k: v["result"].get("flag", False) for k, v in results.items()}
            }
            
            audit_data_user_actions = {
                "service_name": "bulk_upload_all_change_types_from_excel",
                "created_date": original_data.get("request_received_at", datetime.now()),
                "created_by": original_data.get("username", ""),
                "status": "Success",
                "session_id": original_data.get("session_id", ""),
                "tenant_name": original_data.get("tenant_name", ""),
                "comments": json.dumps(audit_comments, default=str),
                "module_name": "Bulk Changes",
                "request_received_at": original_data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
           logging.error(f"### bulk_upload_all_change_types_from_excel auditing failed in success case: {e}")
        
        # Return final success response
        response = {
            "flag": True,
            "message": f"{len(results)} change type(s) processed successfully",
            "data": results,
            "error_type": ""
        }
        logging.info(f"#### response : {response}")
        return response
    except Exception as e:
        # Error handling
        error_type = type(e).__name__
        error_msg = f"Exception in bulk_upload_all_change_types_from_excel: {str(e)}"
        logging.exception(error_msg)
        
        try:
            error_data = {
                "service_name": "bulk_upload_all_change_types_from_excel",
                "created_date": original_data.get("request_received_at", datetime.now()),
                "error_message": str(e),
                "error_type": error_type,
                "users": original_data.get("username", ""),
                "session_id": original_data.get("session_id", ""),
                "tenant_name": original_data.get("tenant_name", ""),
                "comments": "Bulk changes processing failed",
                "module_name": "Bulk Changes",
                "request_received_at": original_data.get("request_received_at"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(f"Failed to log error to database: {logging_error}")
        
        return {
            "flag": False,
            "message": "Bulk changes processing failed",
            "error": str(e)
        }
    
     
def process_sheet_in_thread(sheet_data, data, sheet_func, sheet_name, result_queue):
    """
    Process a single sheet in a thread and put result in queue.
    
    Args:
        sheet_data (DataFrame): The sheet data
        data (dict): Original input data
        sheet_func (function): Function to process the sheet
        sheet_name (str): Name of the sheet
        result_queue (Queue): Queue to put results in
    """
    try:
        logging.info(f"### Thread processing sheet: {sheet_name}")
        map_sheet_to_change_type = {
        "Customer Rate Plan": "Change Customer Rate Plan",
        "Update Device Status": "Update Device Status",
        "Activate New Service": "Activate New Service",
        "Archive":"Archive",
        "Edit Username & Cost Center":"Edit Username/Cost Center",
        "Line Sync":"Line Sync",
        "Update Feature Codes":"Update Features",
        "Refresh A Line": "Refresh A Line",
        "Update PPU Address" : "Update PPU address",
        "Carrier Rate Plan":"Change Carrier Rate Plan",
        "Assign Customer":"Assign Customer",
        "Private Static IP Address":"Change Private Static IP Address",
        "Change Phone Number":"Change Phone Number",
        "Send SMS":"Send SMS",
        "Reset Voicemail Password":"Reset Voicemail Password",
        "Change ICCID & IMEI" :"Change ICCID/IMEI",
        "Communication Plan":"Change Communication Plan"
         }
        # Update device Status Customer Rate Plan Activate New Service 
        
        # Call the appropriate sheet processing function
        result = sheet_func(sheet_data, data)
        
        # Put result in queue
        result_queue.put({
            "change_type": map_sheet_to_change_type.get(sheet_name),
            "sheet_name": sheet_name,
            "result": result
        })
        
    except Exception as e:
        logging.error(f"### Error processing sheet {sheet_name} in thread: {str(e)}")
        result_queue.put({
            "change_type": map_sheet_to_change_type.get(sheet_name),
            "sheet_name": sheet_name,
            "result": {
                "flag": False,
                "message": f"Error processing {sheet_name}: {str(e)}",
                "error": str(e)
            }
        })
      
     
     
     
def process_customer_rate_plan_sheet(df, data):
    """
    Process Template_Customer_Rate sheet for Customer Rate Plan changes.
    Args:
        df (DataFrame): The sheet data
        data (dict): Input data
    Returns:
        dict: Processed payload for Customer Rate Plan changes
    """
    
    logging.info(f"### process_customer_rate_plan_sheet called")
    db_name = data.get("db_name", "")
    # Connect to DB
    try:
        tenant_database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
   
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for customer rate plan"
            }
        # Extract essential keys safely from original data 
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
        devices_final = all_devices if all_devices else all_msisdns  
       
        # Extract first row payload fields
        first_row = df.iloc[0]        
        # Parse effective date
        effective_date_raw = str(first_row.get("Effective Date", "")).strip()
        effective_date_obj = pd.to_datetime(effective_date_raw, errors="coerce")

        effective_date = (
            effective_date_obj.replace(hour=19, minute=0, second=0, microsecond=0)
            .strftime("%Y-%m-%dT%H:%M:%S")
            if pd.notna(effective_date_obj)
            else None
        )

        # validating the customer rate and customer rate pool
        customer_rate_plan_raw = str(first_row.get("Customer Rate Plan", "")).strip()
        null_values = {"", "nan", "none", "null", "na", "n/a", "undefined",None}

        if not customer_rate_plan_raw or customer_rate_plan_raw.lower() in null_values:
            return {"flag": False, "message": "Customer Rate Plan column must have a valid value"}
        
        customer_rate_pool_raw = str(first_row.get("Customer Rate Pool", "")).strip()
 
        customer_rate_plan = customer_rate_plan_raw.split("--")[0].strip()
        customer_rate_pool = customer_rate_pool_raw.split("--")[0].strip()
        if customer_rate_plan:
            rate_plan_data = tenant_database.get_data(
                "customerrateplan",
                {"rate_plan_name": customer_rate_plan, "is_active": True},
                ["id"]  
            )
            if not rate_plan_data.empty:
                customer_rate_plan_id = rate_plan_data["id"].to_list()[0]
            else :
                return {
                    "flag": False,
                    "message": "Customer rate plan is not exist"}  
         
        customer_rate_pool_id = None
        if customer_rate_pool :
            rate_pool_data = tenant_database.get_data(
                "customer_rate_pool",
                {"name": customer_rate_pool, "is_active": True},
                ["id"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool_id = rate_pool_data["id"].to_list()[0]
 
        customer_name_raw = str(first_row.get("Customer Name", ""))
        # Extract only actual customer name (0th part)
        if customer_name_raw :
            customer_name = customer_name_raw.split("--")[0].strip()        
        else :
            customer_name = None
           
        # Create the payload structure
        changed_data = {
            "OverrideValidation": False,
            "Devices": devices_final,
            "CustomerRatePlanUpdate": {
                "EffectiveDate": effective_date,
                "CustomerRatePlanId": f"{customer_rate_plan} -- {customer_rate_plan_id}",
                "CustomerRatePoolId": f"{customer_rate_pool} -- {customer_rate_pool_id}" if customer_rate_pool and customer_rate_pool_id else None,
                "customerName": customer_name,
            }
        }
        payload = {
            "changed_data": changed_data,
            "iccids": devices_final,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        logging.info(f"### Customer Rate Plan Payload Ready: {payload}")
        try :
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_customer_rate_plan_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Customer Rate Plan Change",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_customer_rate_plan_sheet auditing failed in success case :{e}")
        return {
            "flag": True,
            "message": "Customer Rate Plan data processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_customer_rate_plan_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_customer_rate_plan_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_customer_rate_plan_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_customer_rate_plan_sheet auditing failed in error case :{e}")
       
        return {
            "flag": False,
            "message": "Customer rate plan Bulk change failed",
            "error": str(e)
        }     
def process_device_status_sheet(valid_df, data):
    """
    Process Template_Update_Device_Status sheet for Device Status updates.
    
    Args:
        df (DataFrame): The sheet data
        data (dict): Input data
        
    Returns:
        dict: Processed payload for Device Status updates
    """
    logging.info(f"### process_device_status_sheet called")
    service_provider = data.get("service_provider", "")
    db_name = data.get("db_name", "")
    
    # Connect to DB
    try:
        tenant_database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"Error in process_device_status_sheet: {str(e)}")
        return {
            "flag": False,
            "message": "database connection is failed",
            "error": str(e)
        }
    
    try:
        if valid_df.empty:
            return {
                "flag": True,
                "message": f"No valid records for update device status"
            }

        # taking data from Devices sheet        
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
        all_imeis = data.get("imeis")
 
        if  all_devices:
            identifier_col = "iccid"
        else:
            identifier_col = "msisdn"

        final_devices = all_devices if all_devices else all_msisdns
        if not all_devices and not all_msisdns :
            return {
                "flag": False,
                "message": "retry uploading by giving values in the template",
                "data": []
            }
            
        # Get device status id based on providers
        integration_id = None
        service_provider_id = None
        integration_df = tenant_database.get_data(
            "serviceprovider",
            {"service_provider_name": service_provider, "is_active": True},
            ["integration_id","id"]
        )
        if isinstance(integration_df, pd.DataFrame) and not integration_df.empty:
            integration_id = integration_df["integration_id"].to_list()[0]    
            service_provider_id = integration_df["id"].to_list()[0]    
        
        sim_statuses = set()

        # Validate using ICCIDs
        if final_devices:
            status_rows = tenant_database.get_data(
                table_name="sim_management_inventory",
                condition={
                    "is_active": True,
                    identifier_col : final_devices,
                    "service_provider_id" : service_provider_id
                },
                columns=["sim_status"]
            )
            logging.info(f"### status_rows : {status_rows}")

            if isinstance(status_rows, pd.DataFrame) or not status_rows.empty:    
                if "sim_status" in status_rows.columns:
                    sim_statuses = set(
                        status_rows["sim_status"]
                        .replace(["", None, "nan"], pd.NA)
                        .unique()
                    )
                if len(sim_statuses) > 1:
                    return {
                        "flag": False,
                        "message": (
                            "All entered SIMs must have the same SIM status. "
                            f"Found SIM statuses: {list(sim_statuses)}"
                        )
                    }
                if len(sim_statuses) == 0 :
                    return {
                        "flag": False,
                        "message": (
                            "Entered invalid sims please enter valid sims"
                        )
                    }

        # Get first valid row for first_row_data
        first_row_data = None
        update_status = None
        
        if not valid_df.empty:
            first_row = valid_df.iloc[0]
            # effective extraction 
            effective_date_val = str(first_row.get("Effective Date", "")).strip()
            effective_date_obj = pd.to_datetime(effective_date_val, errors="coerce")
            effective_date = effective_date_obj.strftime("%Y-%m-%dT%H:%M:%S") if pd.notna(effective_date_obj) else ""

            update_status = str(first_row.get('Target Status', ''))
            if not update_status or update_status.strip().lower() in {"", "nan", "none", "null", "na", "n/a", "undefined",None}:
                return {"flag": False, "message": "Target Status column must have a valid value"}

            # -------- Activation Profile Conditional Validation --------
            activation_required_statuses = {"a", "activate", "activated", "active"}

            if update_status.lower() in activation_required_statuses:
                if "Kore Activation Profile" in valid_df.columns:
                    kore_activation_value = str(first_row.get("Kore Activation Profile") or "").strip()
                    if not kore_activation_value:
                        return {
                            "flag": False,
                            "message": "Kore Activation Profile is mandatory when Target Status is Active"
                        }

            mode = None  # default
            status_mode_mapping = {
                "Restore Suspended": "R",
                "Cancel Subscriber": "C",
                "Restore Cancelled": ["M", "R"],  # multiple modes possible
                "Suspended": "S",
            }
            if update_status:
                mapped_value = status_mode_mapping.get(update_status)

                if isinstance(mapped_value, list):
                    # choose logic if multiple modes exist
                    # example: take first one
                    mode = mapped_value[0]
                else:
                    mode = mapped_value
 
            first_row_data = {
                "UpdateStatus": update_status,
                "effectiveDate": effective_date,
                "RatePlanCode": str(first_row.get("Rate Plan Code", "")).strip() or None,
                "MdnZipCode": str(first_row.get("Mdn Zip Code", "")).strip() or None,
                "publicIpRestriction": str(first_row.get("Public Ip Restriction", "")).strip() or None,
                "thingSpacePPU": {
                    "FirstName": str(first_row.get("First Name", "")).strip() or None,
                    "LastName": str(first_row.get("Last Name", "")).strip() or None,
                    "AddressLine": str(first_row.get("Address Line", "")).strip() or None,
                    "City": str(first_row.get("City", "")).strip() or None,
                    "State": str(first_row.get("State Code", "")).strip() or None,
                    "ZipCode": str(first_row.get("Mdn Zip Code", "")).strip() or None,
                    "Country": str(first_row.get("Country", "")).strip() or None,
                    "ipAddress": str(first_row.get("Ip Address", "")).strip() or None,
                },
                "activation_profile": str(first_row.get("Kore Activation Profile", "")).strip() or None,
                "mode":mode,
                "reason_code": str(first_row.get("Reason Code", "")).strip() or None
            }
            logging.info("First row parsed -> %s", first_row_data)
        
        # Load service provider mappings from JSON
        try:
            # Assuming load_json function is available
            config = load_json()  # You'll need to import/define this
            service_provider_mappings = config.get("ServiceProviderMappings", {})
            service_provider_lower = service_provider.lower()
            
            # Find provider configuration dynamically
            provider_config = next(
                (
                    cfg
                    for cfg in service_provider_mappings.values()
                    if any(name.lower() == service_provider_lower for name in cfg.get("unique_names", []))
                ),
                service_provider_mappings.get("default", {})
            )
        except Exception as e:
            logging.error(f"Error loading service provider mappings: {str(e)}")
            provider_config = service_provider_mappings.get("default", {})
        
        status_field = provider_config.get("status_field", "status")
        
        # Fetch device_status data
        device_status_id = None
        sim_status_display = None
        status_value = None
            
        status_df = tenant_database.get_data(
            "device_status",
            {
                "integration_id": integration_id,
                "allows_api_update": True,
                "is_active": True,
                "display_name": update_status
            },
            ["display_name", "id", "status"],
        )
        
        if isinstance(status_df, pd.DataFrame) and not status_df.empty:
            device_status_id = status_df["id"].to_list()[0]
            sim_status_display = status_df["display_name"].to_list()[0]
            status_value = status_df["status"].to_list()[0]
        
        # Prepare payload template
        payload_template = provider_config.get("payload_template", {})
        
        # Prepare template variables
        template_vars = {
            "sim_status": update_status if 'status_code' in status_field else status_value,
            "effectiveDate": first_row_data.get("effectiveDate") if first_row_data else "",
            "device_status_id": device_status_id,
            "update_status": status_value if 'status_code' in status_field else update_status,
            "mode": first_row_data.get("mode") if first_row_data else None,
            "reason_code": first_row_data.get("reason_code") if first_row_data else None,
            "RatePlanCode": first_row_data.get("RatePlanCode") if first_row_data else None,
            "MdnZipCode": first_row_data.get("MdnZipCode") if first_row_data else None,
            "thingSpacePPU": first_row_data.get("thingSpacePPU") if first_row_data else {},
            "ipAddress": first_row_data.get("thingSpacePPU", {}).get("ipAddress") if first_row_data else None,
            "activation_profile": first_row_data.get("activation_profile") if first_row_data else None
        }
        
        # Recursive function to replace template variables
        def replace_template_vars(obj, variables):
            if isinstance(obj, dict):
                return {k: replace_template_vars(v, variables) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [replace_template_vars(item, variables) for item in obj]
            elif isinstance(obj, str) and obj.startswith('{') and obj.endswith('}'):
                var_name = obj[1:-1]
                return variables.get(var_name, obj)
            else:
                return obj
        
        # Build the final payload
        new_changed_data = replace_template_vars(payload_template, template_vars)
        new_changed_data["Devices"] = all_devices if all_devices else all_msisdns
        
        logging.info(f"### Using {service_provider} specific changed_data format: {new_changed_data}")
        
        # Construct the final payload
        payload = {
            "changed_data": new_changed_data,
            "iccids": all_devices  if all_devices else all_msisdns,
            "imeids": all_imeis,
            "is_msisdns": False if all_devices else True
        }
        try :
            # Audit logging
            audit_data_user_actions = {
                "service_name": "process_device_status_sheet",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Update Device Status",
                    "iccids": all_devices if all_devices else all_msisdns,
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_device_status_sheet auditing failed in success case :{e}") 
        return {
            "flag": True,
            "data": payload,
            "message": "Data submitted successfully"
        }
        
    except Exception as e:
        # Error handling
        error_type = type(e).__name__
        try:
            error_data = {
                "service_name": "process_device_status_sheet",
                "created_date": data.get("request_received_at"),
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "update device status failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(f"Failed to log error to database: {logging_error}")
        
        return {
            "flag": False,
            "message": "update device status bulk change failed",
            "error": str(e)
        }
         
def process_activate_new_service_sheet(df, data):
    """
    Process Template_Activate_New_Service sheet for activating new services.
    
    Args:
        df (DataFrame): The sheet data
        data (dict): Input data
        
    Returns:
        dict: Processed payload for activating new services
    """
    logging.info(f"### process_activate_new_service_sheet called")
    db_name = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    request_received_at = data.get("request_received_at", datetime.now())
    
    # Connect to DB
    try:
        tenant_database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for activate new service"
            }
        # Check for null values in required columns (first record only)
        first_row = df.iloc[0]
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_imeis  = data.get("imeis")
        if not all_devices : 
            return {
                "flag": False,
                "message": "No Iccids given to perform activate new service"
            }
        devices_final = all_devices 
        
        # Extract values from first row
        billing_account = str(first_row.get("Billing Account Number", "")).strip()
        # Remove decimal if present (e.g., "287256845357.00" → "287256845357")
        if "." in billing_account:
            billing_account = billing_account.split(".")[0]

        subscriber_first = str(first_row.get("Subscriber First Name", "")).strip() or None
        subscriber_last = str(first_row.get("Subscriber Last Name", "")).strip() or None
        street_number = str(first_row.get("Street Number", "")).strip() or None
        street_direction = str(first_row.get("Street Direction", "")).strip() or None
        street_name = str(first_row.get("Street Name", "")).strip() or None
        city = str(first_row.get("City", "")).strip() or None
        state = str(first_row.get("State", "")).strip() or None
        zip_code = str(first_row.get("Zip", "")).strip() or ""
        if "." in zip_code:
            zip_code = zip_code.split(".")[0]
        rate_plan = str(first_row.get("Rate Plan Code", "")).strip() or None
        customer_rate_plan = str(first_row.get("Customer Rate Plan", "")).strip() or None
        rate_pool = str(first_row.get("Rate Pool", "")).strip() or None
        customer_name_raw = str(first_row.get("Assign Customer", "")).strip() or None
        rate_plan_group = str(first_row.get("Rate Plan Group", "")).strip() or None
        pdp_name = str(first_row.get("Pdp Name", "")).strip() or None
        static_ip_apn = str(first_row.get("Private Static APN", "")).strip() or None
        private_static_ip_address  = str(first_row.get("Private Statics Ip Address", "")).strip() or None 
        # validating mandatory column values 
        invalid_values = {"", "nan", "none", "null", "na", "n/a", "undefined", None}
        required_fields = {
            "Subscriber First Name": subscriber_first,
            "Subscriber Last Name": subscriber_last,
            "Street Number": street_number,
            "Street Name": street_name,
            "City": city,
            "State": state,
            "Zip": zip_code if zip_code else "",
            "Rate Plan Code": rate_plan,
            "Billing Account Number" : billing_account
        }
        invalid_columns = []
        for col, val in required_fields.items():
            if val in invalid_values:
                invalid_columns.append(col)
        if invalid_columns:
            return {
                "flag": False,
                "message": f"Invalid or missing values in column(s): {invalid_columns}"
            }
        
        # Customer lookup logic
        customer_id = None
        billing_platform_flag = data.get("billing_platform_flag",False)
        if customer_name_raw :
            # Extract only actual customer name (0th part)
            customer_name = customer_name_raw.split("--")[0].strip() 
        else : 
            customer_name = None
        if customer_name:
            # First check in revcustomer table
            rev_data = tenant_database.get_data(
                "revcustomer",
                {"customer_name": customer_name, "is_active": True},
                ["customer_name", "rev_customer_id"]
            )
            
            if not rev_data.empty:
                customer_id = rev_data["rev_customer_id"].to_list()[0]
            else :     
                # Then check in customers table
                customer_data = tenant_database.get_data(
                    "customers",
                    {"customer_name": customer_name, "is_active": True},
                    ["id", "customer_name"]
                )

                if not customer_data.empty:
                    customer_id = customer_data["id"].to_list()[0]
        # taking all the feature codes 
        feature_code_list = list(
    dict.fromkeys(
        str(code).strip()
        for code in df["Feature Codes"]
        if code is not None
        and str(code).strip()
        and str(code).lower() not in {"nan", "none", "null"}
    )
)            
        # Build dynamic offeringCode entries
        offering_code_characteristics = []

        for idx, code in enumerate(feature_code_list, start=1):
            offering_code_characteristics.append({
                "name": f"offeringCode{idx}",
                "value": code
            })
        # Build the TelegenceActivationRequest payload
        telegence_activation_request = {
            "billingAccount": {
                "id": str(billing_account) if billing_account else ""
            },
            "relatedParty": [
                {
                    "id": "",
                    "role": "subscriber",
                    "firstName": subscriber_first if subscriber_first else "",
                    "lastName": subscriber_last if subscriber_last else "",
                    "address": {
                        "streetNumber": street_number if street_number else "",
                        "streetDirection": street_direction if street_direction else "",
                        "streetName": street_name if street_name else "",
                        "streetType": "",
                        "city": city if city else "",
                        "state": state if state else "",
                        "zipCode": zip_code if zip_code else ""
                    }
                }
            ],
            "service": {
                "category": {
                    "id": "",
                    "name": ""
                },
                "name": "",
                "serviceSpecification": {
                    "id": "12",
                    "href": "Mobility Services"
                },
                "serviceQualification": {},
                "serviceCharacteristic": [
                    {
                        "name": "serviceZipCode",
                        "value": str(zip_code) if zip_code else ""
                    },
                    {
                        "name": "singleUserCode",
                        "value": None
                    },
                    {
                        "name": "equipmentType",
                        "value": "G"
                    },
                    {
                        "name": "deviceTechnologyType",
                        "value": "UMTS"
                    },
                    {
                        "name": "IMEI",
                        "value": ""
                    },
                    {
                        "name": "sim",
                        "value": ""
                    }
                ] + offering_code_characteristics
                ,
                "status": "",
                "subscriberNumber": ""
            }
        }
        static_iP_provision = {
            "PDPName": pdp_name,
            "IPAddressCode": private_static_ip_address,
            "LteIndicator": False,
            "DefaultAPN": False,
            "StaticIPAPN": static_ip_apn
            }
        rate_plan_soc_code = ""
        customer_rate_plan_name = ""
        # Extract left part of customer_rate_plan before '--'
        if customer_rate_plan:
            if customer_rate_plan and "--" in customer_rate_plan:
                customer_rate_plan_name = customer_rate_plan.split("--", 1)[0].strip()
        if not customer_rate_plan:
            # Extract right part of rate_plan after '--'
            if rate_plan and "--" in rate_plan:
                rate_plan_soc_code = rate_plan.split("--", 1)[1].strip()
                rate_plan_name = rate_plan.split("--", 1)[0].strip()
        
        # Build the changed_data payload
        changed_data = {
            "TelegenceActivationRequest": telegence_activation_request,
            "CarrierDataGroup": rate_plan_group,
            "CarrierRatePool": rate_pool if rate_pool else "",
            "AddCustomerRatePlan": False,
            "CustomerRatePlanId": customer_rate_plan_name if customer_rate_plan_name else rate_plan_name,
            "CustomerRatePlan": rate_plan if rate_plan and customer_rate_plan  else rate_plan_soc_code,
            "StaticIPProvision": static_iP_provision
        }
        
        # Build the main payload
        payload = {
            "customer_name": customer_name,
            "customer_rate_plan_name_update": customer_rate_plan_name if customer_rate_plan_name else rate_plan_name,
            "customer_id": customer_id,
            "billing_platform": billing_platform_flag,
            "changed_data": changed_data,
            "iccids": all_devices,
            "imeids":all_imeis ,
            "is_msisdns": False 

        }
        logging.info(f"### Activation Service Payload Ready")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_activate_new_service_sheet",
                "created_date": request_received_at,
                "created_by": username,
                "status": "Success",
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps({
                    "change_type": "Activate New Service",
                    "devices": devices_final,
                    "customer_name": customer_name
                }),
                "module_name": "Bulk Change",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_activate_new_service_sheet auditing failed in success case :{e}") 
        
        return {
            "flag": True,
            "message": "Activation service data processed successfully",
            "data": payload
        }
        
    except Exception as e:
        logging.error(f"### something went wrong in process_activate_new_service_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_activate_new_service_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_activate_new_service_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_activate_new_service_sheet auditing failed in error case :{e}")
        return {
            "flag": False,
            "message": "Activation service bulk change failed",
            "error": str(e)
        }
  
def process_archive_sheet(df, data):
    """
    Processes the Archive bulk change Excel sheet and prepares the payload
    for Customer Rate Plan related changes.

    Args:
        df (pandas.DataFrame):
            DataFrame containing the uploaded Archive sheet data.

        data (dict): used for auditing purpose

    Returns:
        dict:
            A dictionary containing the processing status and result.
    """
    logging.info(f"### process_archive_sheet called with data :  {data}")
    
    # Connecting to database 
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        # Get the first value from the column
        if "Save Changes" in df.columns:
            flag = df["Save Changes"].iloc[0] if not df["Save Changes"].empty else None
        else:
            flag = None 
        # Treat everything as False unless explicitly True
        is_true = False

        if flag is not None and not pd.isna(flag):
            if str(flag).strip().lower() in {"true", "1", "yes"}:
                is_true = True

        if not is_true:
            return {
                "flag": True,
                "message": "Archive change type is not allowed"
            }  
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
       
        devices_final = all_devices if all_devices else all_msisdns
            
        # Create the payload structure
        changed_data = {
            "OverrideValidation": False,
            "Devices": devices_final
        }
        payload = {
            "changed_data": changed_data,
            "iccids": all_devices if  all_devices else all_msisdns,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        
        logging.info(f"### archive Payload Ready: {payload}")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_archive_sheet",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Archive",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_archive_sheet auditing failed in success case :{e}")    
        return {
            "flag": True,
            "message": "Archive data processed successfully",
            "data": payload
        }
        
    except Exception as e:
        logging.error(f"### something went wrong in process_archive_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_archive_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_archive_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_archive_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Archive bulk change failed",
            "error": str(e)
        }        
    

def process_edit_cost_center_sheet(df, data):
    """
    Processes the Edit Cost Center bulk change Excel sheet and prepares
    the payload for updating cost center and contact name details.

    Args:
        df (pandas.DataFrame):
            DataFrame containing the uploaded Edit Cost Center sheet data.

        data (dict): 
            Used for auditing purpose.

    Returns:
        dict:
            A dictionary containing the processing status and result.
    """
    logging.info(f"### process_edit_cost_center_sheet called with data : {data}")
    
    # Connect to DB
    try:
        # tenant_database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for edit username cost center"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
       
        devices_final = all_devices if all_devices else all_msisdns
        
        # Extract first row payload fields
        first_row = df.iloc[0]
        cost_center = str(first_row.get("Cost Center", "")).strip()
        contact_name = str(first_row.get("Contact Name", "")).strip()
       
        # Create the payload structure
        changed_data = {
            "OverrideValidation": False,
            "Devices": devices_final,
         "ContactName": contact_name,
         "CostCenter1": cost_center
        }
        payload = {
            "changed_data": changed_data,
            "iccids":all_devices  if all_devices else all_msisdns,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        logging.info(f"### Edit cost center Payload Ready: {payload}")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_edit_cost_center_sheet",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Edit cost center",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_edit_cost_center_sheet auditing failed in success case :{e}")
        
        return {
            "flag": True,
            "message": "Edit cost center data processed successfully",
            "data": payload
        }
        
    except Exception as e:
        logging.error(f"### something went wrong in process_edit_cost_center_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_edit_cost_center_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_edit_cost_center_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_edit_cost_center_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Edit cost center bulk change failed",
            "error": str(e)
        }
        

def process_line_sync_sheet(df, data):
    """
    Processes the Line Sync bulk change Excel sheet and prepares
    the payload for synchronizing line details.

    Args:
        df (pandas.DataFrame):
            DataFrame containing the uploaded Line Sync sheet data.

        data (dict):
            Used for auditing purpose.

    Returns:
        dict:
            A dictionary containing the processing status and result.
    """
    logging.info(f"### process_edit_cost_center_sheet called with data : {data}")
    
    # Connect to DB
    try:
        # tenant_database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        #  Get the first value from the column, not the entire Series
        if "Save Changes" in df.columns:
            flag = df["Save Changes"].iloc[0] if not df["Save Changes"].empty else None
        else:
            flag = None
        # Treat everything as False unless explicitly True
        is_true = False
 
        if flag is not None and not pd.isna(flag):
            if str(flag).strip().lower() in {"true", "1", "yes"}:
                is_true = True
 
        if not is_true:
            return {
                "flag": True,
                "message": "Line Sync change type is not allowed"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
       
        devices_final = all_devices if all_devices else all_msisdns
        
        if not devices_final:
            return {
                "flag": False,
                "message": "No valid ICCID/MSISDN found for processing."
            }
       
        # Create the payload structure
        changed_data = {
              "iccids" : devices_final
        }
        payload = {
            "changed_data": changed_data,
            "iccids": all_devices if all_devices else all_msisdns,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        
        logging.info(f"### Line sync Payload Ready: {payload}")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_line_sync_sheet",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Line sync",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_edit_cost_center_sheet auditing failed in success case :{e}")
           
        return {
            "flag": True,
            "message": "Line sync data processed successfully",
            "data": payload
        }
        
    except Exception as e:
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_line_sync_sheet",
                "created_date": data.get("request_received_at"),
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "Line sync failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_line_sync_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Line sync bulk change failed",
            "error": str(e)
        }        
        

def process_refresh_a_line_sheet(df, data):
    """
    Processes the Refresh A Line bulk change Excel sheet and prepares
    the payload required for refreshing SIM lines.

    Args:
        df (pandas.DataFrame):
            DataFrame containing the uploaded Refresh A Line sheet data.

        data (dict):
            Used for auditing purpose.

    Returns:
        dict:
            A dictionary containing the processing status and result.
    """
    logging.info(f"### process_refresh_a_line_sheet called")
    # Connect to DB
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for refresh a line"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
       
        devices_final = all_devices if all_devices else all_msisdns
            
        # Extract first row payload fields
        first_row = df.iloc[0]
        billing_account_number = str(first_row.get("Billing Account Number", "")).strip()
        if "." in billing_account_number:
            billing_account_number = billing_account_number.split(".")[0]
        # validating the billing account number
        null_values = {"", "nan", "none", "null", "na", "n/a", "undefined",None}
        if not billing_account_number or billing_account_number in null_values:
            return {"flag": False, "message": "Billing Account Number column must have a valid value"}    
       
        # Create the payload structure
        changed_data = {
                 "RefreshLine": {
                    "requestType": "resendOTAProfile",
                    "billingAccount": {
                        "id": str(billing_account_number) if billing_account_number else ""
                    },
                    "serviceCharacteristic": [
                        {
                        "name": "sim",
                        "value": ""
                        }
                    ]
                    }
        }
        payload = {
            "changed_data": changed_data,
            "iccids": all_devices if all_devices else all_msisdns,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        logging.info(f"### Refresh A Line Payload Ready: {payload}")
        try :
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_refresh_a_line_sheet",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Refresh A Line",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_refresh_a_line_sheet auditing failed in success case :{e}")

        return {
            "flag": True,
            "message": "Refresh A Line data processed successfully",
            "data": payload
        }
        
    except Exception as e:
        logging.error(f"### something went wrong in process_refresh_a_line_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_refresh_a_line_sheet",
                "created_date": data.get("request_received_at"),
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "Refresh A Line failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_refresh_a_line_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Refresh A Line bulk change failed",
            "error": str(e)
        }  

def process_update_feature_codes_sheet(df, data):   
    """
    Processes the Update Feature Codes bulk change Excel sheet and prepares
    the payload for adding or removing feature/offering codes for SIMs.

    Args:
        df (pandas.DataFrame):
            DataFrame containing the uploaded Update Feature Codes sheet data.

        data (dict):
            Used for auditing purpose.

    Returns:
        dict:
            A dictionary containing the processing status and result.
    """
    logging.info(f"### process_update_feature_codes_sheet called df : {df}")    
    # Connect to DB
    try:
        common_utils_database = DB('common_utils', **db_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for update feature code"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
        # taking the 1st record to form the payload     
        first_row = df.iloc[0]

        # Convert column values to list, remove nulls and duplicates
        add_offering_codes = list(
            set(
                str(code).strip()
                for code in df["Update Feature Codes"]
                if str(code).strip() and str(code).lower() != "nan"
            )
        )
        
        remove_offering_codes = list(
            set(
                str(code).strip()
                for code in df["Remove Feature Codes"]
                if str(code).strip() and str(code).lower() != "nan"
            )
        )
        # VALIDATION logic for add_offering_codes or remove_offering_codes
        if not add_offering_codes and not remove_offering_codes:
            return {
                "flag": False,
                "message": "Please enter at least one value in either 'Update Feature Codes' or 'Remove Feature Codes' column"
            }
        raw_overwrite_value = str(first_row.get("Overwrite Feature Codes", False)).strip()
        overwrite_feature_codes = (
            True
            if str(raw_overwrite_value).strip().lower() in ["true", "1", "yes"]
            else False
        )
        # Create the payload structure
        changed_data = {
                "serviceCharacteristic": [
                    {
                        "name": "addOfferingCode",
                        "value": add_offering_codes
                    },
                    {
                        "name": "removeOfferingCode",
                        "value": remove_offering_codes
                    }
                    ]
        }
        payload = {
            "changed_data": changed_data,
            "overwrite":bool(overwrite_feature_codes) ,
            "iccids": all_devices if all_devices else all_msisdns,
            "imeids":[],
            "is_msisdns": False if all_devices else True
            
        }
 
        logging.info(f"### update feature codes Payload Ready: {payload}")
        try :
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_update_feature_codes_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Update Feature Codes",
                    "devices": all_devices
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_update_feature_codes_sheet auditing failed in success case :{e}")
        return {
            "flag": True,
            "message": "update feature codes data processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_update_feature_codes_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_update_feature_codes_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_update_feature_codes_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_update_feature_codes_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Update feature Codes Bulk change failed",
            "error": str(e)
        }

def process_carrier_rate_plan_sheet(df, data):
    """
    Process the Carrier Rate Plan bulk change Excel sheet and construct
    a validated payload for downstream bulk change execution.

    Parameters:
    df : pandas.DataFrame => DataFrame created from the uploaded Excel sheet.
    data : dict => Metadata related to the request context, including:

    Returns:
    dict
        {
            "flag": True/False,
            "message": "Carrier Rate Plan data processed successfully/failed",
            "data": {
                "changed_data": {...},
                "iccids": [...],
                "imeids": [],
                "is_msisdns": bool
            }
        }
    """
    logging.info("### process_carrier_rate_plan_sheet called")

    db_name = data.get("db_name", "")
    try:
        tenant_database = DB(db_name, **db_config)
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"],
            **common_utils_database_config
        )
    except Exception as e:
        return {
            "flag": False,
            "message": "Database connection failed",
            "error": str(e)
        }

    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for carrier rate plan"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
       
        devices_final = all_devices if all_devices else all_msisdns
        first_row = df.iloc[0]
        # validating the effective date 
        effective_date_raw = str(first_row.get("Effective Date", "")).strip()
        effective_date_obj = pd.to_datetime(effective_date_raw, errors="coerce")
        effective_date = (
            effective_date_obj.strftime("%Y-%m-%dT%H:%M:%S.000Z")
            if pd.notna(effective_date_obj)
            else None
        )
        
        # validating the carrier rate plan
        carrier_rate_plan = str(first_row.get("Carrier Rate Plan", ""))
        null_values = {"", "nan", "none", "null", "na", "n/a", "undefined",None}
        # validating the mandatory column values 
        if not carrier_rate_plan or carrier_rate_plan.lower() in null_values:
            return {"flag": False, "message": "Carrier Rate Plan column must have a valid value"}

        if not carrier_rate_plan:
            return {
                "flag": False,
                "message": "Carrier Rate Plan is mandatory"
            }
        
        rate_plan_name = None
        carrier_rate_plan = carrier_rate_plan.strip()

        # Try friendly_name (TRIM)
        query = """
        SELECT friendly_name
        FROM carrier_rate_plan
        WHERE TRIM(friendly_name) = %s
        AND is_active = true
        LIMIT 1
        """
        rate_plan_data = tenant_database.execute_query(
            query,
            flag=True,
            params=[carrier_rate_plan]
        )

        if isinstance(rate_plan_data, pd.DataFrame) and not rate_plan_data.empty:
            rate_plan_name = rate_plan_data["friendly_name"].iloc[0]

        else:
            # Try rate_plan_code (TRIM)
            query = """
            SELECT rate_plan_code
            FROM carrier_rate_plan
            WHERE TRIM(rate_plan_code) = %s
            AND is_active = true
            LIMIT 1
            """
            rate_plan_data = tenant_database.execute_query(
                query,
                flag=True,
                params=[carrier_rate_plan]
            )

            if isinstance(rate_plan_data, pd.DataFrame) and not rate_plan_data.empty:
                rate_plan_name = rate_plan_data["rate_plan_code"].iloc[0]

        # Final validation
        if not rate_plan_name:
            return {
                "flag": False,
                "message": "Carrier Rate Plan does not exist"
            }
        
        
        comm_plan_flag = False
        communication_plan = None
        optimization_group_name = None
        if "Communication Plan" in df.columns:
            comm_plan_flag = True
      
        if comm_plan_flag:
            communication_plan_raw= str(first_row.get("Communication Plan", ""))
            if communication_plan_raw.lower() not in null_values:    
                comm_plan_data = tenant_database.get_data("sim_management_communication_plan",
                                    {"communication_plan_name": communication_plan_raw, "is_active": True},
                                    ["communication_plan_name"],
                                )
                if not comm_plan_data.empty:
                    communication_plan = comm_plan_data["communication_plan_name"].iloc[0]
                else : 
                    return {"flag":False , "message":f"Given communication plan :{communication_plan_raw} does not exist"}    
            changed_data = {
                "CarrierRatePlanUpdate": {
                    "CarrierRatePlan": rate_plan_name,
                    "CommPlan": communication_plan,
                    "EffectiveDate": effective_date
                }}    
        else:
            optimization_group_name_raw = str(first_row.get("Optimization Group", ""))
            if optimization_group_name_raw.lower() not in null_values:
                optimization_group_data = tenant_database.get_data(
                                "optimization_group",
                                {"optimization_group_name": optimization_group_name_raw, "is_active": True},
                                ["optimization_group_name"],
                            )
                if not optimization_group_data.empty:
                    optimization_group_name = optimization_group_data["optimization_group_name"].iloc[0] 
                else : 
                    return{                
                        "flag": False,
                        "message": f"Given optimization group: {optimization_group_name_raw} does not exist"}
                    
            subscriber_numbers = ", ".join(all_msisdns) if all_msisdns else ""
            
            changed_data = {
                "CarrierRatePlanUpdate": {
                    "CarrierRatePlan": rate_plan_name,
                    "EffectiveDate": effective_date,
                    "OptimizationGroup": optimization_group_name,
                    "SubscriberNumber": subscriber_numbers
                }
            }

        payload = {
            "changed_data": changed_data,
            "iccids": all_devices if all_devices else all_msisdns,
            "imeids": [],
            "is_msisdns": False if all_devices else True
        }

        logging.info(f"### Carrier Rate Plan Payload Ready: {payload}")
        try : 
            audit_data_user_actions = {
                "service_name": "process_carrier_rate_plan_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Carrier Rate Plan Change",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(
                audit_data_user_actions,
                "audit_user_actions"
            )
        except Exception as e :
           logging.error(f"### process_carrier_rate_plan_sheet auditing failed in success case :{e}")
        return {
            "flag": True,
            "message": "Carrier Rate Plan data processed successfully",
            "data": payload
        }

    except Exception as e:
        logging.error(f"### process_carrier_rate_plan_sheet failed: {e}")

        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_carrier_rate_plan_sheet",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "Carrier Rate Plan bulk change failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception:
            logging.error(f"### process_carrier_rate_plan_sheet auditing failed in error case :{e}")
        return {
            "flag": False,
            "message": "Carrier Rate Plan bulk change failed",
            "error": str(e)
        } 


def process_update_ppu_address_sheet(df, data):
    """
    Processes the Update PPU Address bulk change Excel sheet and prepares
    the payload required to update the billing/user address for a SIM.

    Args:
        df (pandas.DataFrame):
            DataFrame containing the uploaded Update PPU Address sheet data.
        data (dict):
            Request metadata used for auditing and logging purposes,
            such as username, session ID, tenant name, and timestamps.

    Returns:
        dict:
            A dictionary containing:
                - flag (bool): Indicates success or failure of processing.
                - message (str): Descriptive status message.
                - data (dict, optional): Prepared payload including
                  changed_data, identifiers (ICCIDs/MSISDNs), and flags
                  required for further processing.
    """
    logging.info(f"### process_update_ppu_address_sheet called")
    
    # Connect to DB
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for update ppu address"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
       
        devices_final = all_devices if all_devices else all_msisdns
        # Extract first row payload fields
        first_row = df.iloc[0]
        zip_code_raw = str(first_row.get("Zip Code", "")).strip() or ""
        if "." in zip_code_raw:
            zip_code_raw = zip_code_raw.split(".")[0]
        if not zip_code_raw:
            return {
                "flag": False,
                "message": "Zip Code cannot be empty"
            }

        if not zip_code_raw.isdigit() or len(zip_code_raw) != 5:
            return {
                "flag": False,
                "message": "Invalid Zip Code. Zip Code must be exactly 5 digits."
            }
        zip_code = zip_code_raw
        billing_account_number = str(first_row.get("Billing Account Number", "")).strip()
        if "." in billing_account_number:
            billing_account_number = billing_account_number.split(".")[0]

       
        # Create the payload structure
        changed_data = {
                "UserAddress": {
                    "billingAccount": {
                        "id": str(billing_account_number) if billing_account_number else "" 
                    },
                    "relatedParty": {
                        "role": str(first_row.get("Role", "")).strip(),
                        "firstName": str(first_row.get("First Name", "")).strip(),
                        "lastName": str(first_row.get("Last Name", "")).strip(),
                        "address": {
                            "streetNumber": str(first_row.get("Street Number", "")).strip(),
                            "streetDirection": str(first_row.get("Street Direction", "")).strip(),
                            "streetName": str(first_row.get("Street Name", "")).strip(),
                            "streetType": str(first_row.get("Street Type", "")).strip(),
                            "city": str(first_row.get("City", "")).strip(),
                            "state": str(first_row.get("State", "")).strip(),
                            "zipCode": zip_code if zip_code else ""
                        }
                    }
                }
            }
        
        payload = {
            "changed_data": changed_data,
            "iccids": all_devices if all_devices else all_msisdns,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        
        logging.info(f"### Update Ppu Address Payload Ready: {payload}")
        try: 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_update_ppu_address_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Update PPU address",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_update_ppu_address_sheet auditing failed in success case :{e}")
        
        return {
            "flag": True,
            "message": "Update ppu Address data processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_update_ppu_address_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_update_ppu_address_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_update_ppu_address_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_update_ppu_address_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Update PPU Address Bulk change failed",
            "error": str(e)
        }   


def process_assign_customer_sheet(df, data):
    """
    Process the **Assign Customer** bulk change Excel sheet and construct
    a validated payload for downstream customer assignment execution.
 
    Parameters:
        df (pandas.DataFrame):
            Uploaded Excel sheet data containing Assign Customer details.
        data (dict):
            Metadata and runtime information required for processing.
 
    Returns:
        dict:{
                "flag": True,
                "message": "Assign Customer data processed successfully",
                "data": {
                    "changed_data": dict,
                    "iccids": list,
                    "imeids": list,
                    "is_msisdns": bool
                }
            }
    """
    logging.info(f"### process_assign_customer_sheet called df :{df}")
    db_name = data.get("db_name", "")
    tenant_id = data.get("tenant_id")
   
    # Connect to DB
    try:
        tenant_database = DB(db_name, **db_config)
        common_utils_database = DB('common_utils', **db_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
   
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for assign customer"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
       
        devices_final = all_devices if all_devices else all_msisdns
       
        # Extract first row payload fields
        first_row = df.iloc[0]
        billing_platform = False
       
        # Parse effective date
        effective_date_raw = str(first_row.get("Effective Date", "")).strip()
        effective_date_obj = pd.to_datetime(effective_date_raw, errors="coerce")

        effective_date = (
            effective_date_obj.replace(hour=19, minute=0, second=0, microsecond=0)
            .strftime("%Y-%m-%dT%H:%M:%S")
            if pd.notna(effective_date_obj)
            else None
        )

        
        customer_name_raw = str(first_row.get("Billing Customer", "")).strip()
        customer_rate_plan_raw =str(first_row.get("Customer Rate Plan", "")).strip()
        customer_rate_pool =str(first_row.get("Customer Pool", "")).strip()
        create_rev_service =first_row.get("Create Service/Product", False)
        billing_provider_raw = str(first_row.get("Billing Provider", ""))
        service_type =first_row.get("Service Type", "")
        prorate =first_row.get("Prorate", False)
        user_carrier_activation =first_row.get("Use Carrier Activation", False)
        product_description = str(first_row.get("Product Description", ""))      
        rate_value = first_row.get("Rate", None)
        if rate_value is None or pd.isna(rate_value) or str(rate_value).strip() == '':
            rate_list = []
        else:
            try:
                rate_list = [int(float(str(rate_value).strip()))]
            except (ValueError, TypeError):
                rate_list = []
       
        null_values = {"", "nan", "none", "null", "na", "n/a", "undefined",None}
        if not customer_name_raw or customer_name_raw.lower() in null_values:
            return {"flag": False, "message": "Billing Customer column must have a valid value"}
       
        billing_package_raw = str(first_row.get("Billing Package", "")).strip()
        billing_product_raw = str(first_row.get("Billing Product", "")).strip()
        logging.info(f"#### billing_package_raw : {billing_package_raw} and billing_product_raw : {billing_product_raw}")
        if create_rev_service :
            invalid_values = {"", "nan", "none", "null", "na", "n/a", "undefined", None}
            required_fields = {
                "Billing Provider": billing_provider_raw,
                "Service Type": service_type,
            }
            invalid_columns = []
            for col, val in required_fields.items():
                if val in invalid_values:
                    invalid_columns.append(col)
            if invalid_columns:
                return {
                    "flag": False,
                    "message": f"Invalid or missing values in column(s): {invalid_columns}"
                }
           
            invalid_values = {"", "nan", "none", "null", "na", "n/a", "undefined", None}
            billing_product_valid = billing_product_raw not in invalid_values
            billing_package_valid = billing_package_raw not in invalid_values
 
            # XOR validation: exactly ONE must be present
            if billing_product_valid == billing_package_valid:
                return {
                    "flag": False,
                    "message": "Provide exactly one: Billing Product OR Billing Package (not both, not none)"
                }
        # taking product ids from  billing_package if not billing product/s is not given    
        product_ids = []
        # If Billing Product is empty, try getting product ids from Billing Package
        if not billing_product_raw and billing_package_raw:
            # Example format: "Some Name - 100 -- 101,102,103"
            ids_part = billing_package_raw.split(" -- ")[-1].strip()
            product_ids = [
                pid.strip()
                for pid in ids_part.split(",")
                if pid.strip().isdigit()
            ]
 
        # Remove duplicates while preserving order
        product_ids = list(dict.fromkeys(product_ids))   
        # taking package id 
        package_id = ""
        if billing_package_raw:
            try:
                package_part = billing_package_raw.split(" - ")[-1]
                package_id = int(package_part.split(" -- ")[0].strip())
            except Exception:
                package_id = ""    
       
        billing_product_ids = list(
                dict.fromkeys(
                    str(value).split(" - ")[-1].strip()
                    for value in df["Billing Product"]
                    if value is not None
                    and str(value).strip()
                    and " - " in str(value)
                    and str(value).split(" - ")[-1].strip().isdigit()
                )
            )
       
        # consider billing_product_ids based on the given package
        if not billing_product_ids:
            billing_product_ids = product_ids
        if not billing_product_ids and not product_ids:
            logging.warning("No billing product IDs provided In Excel")    
 
        rev_customer_name = None
        billing_provider_id = billing_provider_raw.split("--")[1].strip() if "--" in billing_provider_raw else None
        customer_name = None
        customer_id = None
        rate_plan_code = None
        if customer_name_raw:
            # Extract only actual customer name (0th part)
            customer_name = customer_name_raw.split("--")[0].strip()
            # ---------- Check in revcustomer table using TRIM ----------
            query = """
            SELECT customer_name, rev_customer_id FROM revcustomer
            WHERE BTRIM(REPLACE(customer_name, CHR(9), '')) = %s
            AND is_active = true AND tenant_id = %s
            LIMIT 1
            """
            rev_data = tenant_database.execute_query(
                query,
                flag=True,
                params=[customer_name, tenant_id]
            )

            if isinstance(rev_data, pd.DataFrame) and not rev_data.empty:
                rev_customer_name = rev_data["customer_name"].iloc[0]
                customer_id = rev_data["rev_customer_id"].iloc[0]
                billing_platform = False

            # ---------- If not found, check in customers table ----------
            if not rev_customer_name:
                query = """
                SELECT customer_name, id FROM customers
                WHERE BTRIM(REPLACE(customer_name, CHR(9), '')) = %s
                AND is_active = true AND tenant_id = %s
                LIMIT 1
                """
                customer_data = tenant_database.execute_query(
                    query,
                    flag=True,
                    params=[customer_name, tenant_id]
                )

                if isinstance(customer_data, pd.DataFrame) and not customer_data.empty:
                    customer_name = customer_data["customer_name"].iloc[0]
                    customer_id = customer_data["id"].iloc[0]
                    billing_platform = True
                else:
                    return {
                        "flag": False,
                        "message": f"given customer : {customer_name} is not valid"
                    }
       
        customer_rate_plan = customer_rate_plan_raw.split("--")[0].strip()
        if customer_rate_plan:
            if not effective_date or effective_date is None :
                return{"flag":False ,"message":"when customer rate plan is given then effective date is mandatory field"}
            rate_plan_data = tenant_database.get_data(
                "customerrateplan",
                {"rate_plan_name": customer_rate_plan, "is_active": True},
                ["rate_plan_code"]  
            )
            if not rate_plan_data.empty:
                rate_plan_code = rate_plan_data["rate_plan_code"].to_list()[0]
            else :
                return {"flag":False ,"message":"Given customer rate plan does not exist"}    

        # 1. Effective date enable — starting (default)
        if not create_rev_service:
            effective_date = effective_date if effective_date else ""

        # 2. Create service = ON, prorate = ON → enable
        if create_rev_service and prorate and not user_carrier_activation:
            effective_date = effective_date if effective_date else ""

        # 3. Create service = ON, prorate = OFF → disable
        if create_rev_service and not prorate:
            effective_date = ""

        # 4. Create service = ON, prorate = OFF, customer rate plan selected → enable
        if create_rev_service and not prorate and customer_rate_plan:
            effective_date = effective_date if effective_date else ""

        # 5. Create service = ON, prorate = ON, carrier activation = ON → disable
        if create_rev_service and prorate and user_carrier_activation:
            effective_date = ""

        # 6. Create service = ON, prorate = ON, carrier activation = ON,
        #    customer rate plan selected → disable
        if create_rev_service and prorate and user_carrier_activation and customer_rate_plan:
            effective_date = ""
            
    
        # Create the payload structure
        changed_data = {
            "Number": "",
            "ICCID": "",
            "CreateRevService": bool(create_rev_service) if pd.notna(create_rev_service) else False,
            "IntegrationAuthenticationId": "",
            "AddCarrierRatePlan": False,
            "CarrierRatePlan": None,
            "CommPlan": "",
            "UseAgentAccount": False,
            "JasperDeviceID": "",
            "SiteId": None,
            "AddCustomerRatePlan": False,
            "CustomerRatePlan": f"{customer_rate_plan} -- {rate_plan_code}" if customer_rate_plan and rate_plan_code else "",
            "CustomerRatePool": customer_rate_pool if customer_rate_pool else None,
            "DeviceId": None,
            "RevCustomerId": f"{customer_name} -- {customer_id}",
            "ProviderId": billing_provider_id,
            "ServiceTypeId": str(service_type),
            "RevProductId": billing_product_ids,
            "RevPackageId": package_id if package_id else "",
            "RateList": rate_list,
            "Prorate": bool(prorate) if pd.notna(prorate) else False ,
            "useCarrierActivation": bool(user_carrier_activation) if pd.notna(user_carrier_activation) else False,
            "Description": product_description,
            "EffectiveDate": effective_date,
            "ActivatedDate": effective_date,
            "UsagePlanGroupId": None
            }    
        payload = {
            "billing_platform":billing_platform,
            "use_carrier_activation": bool(user_carrier_activation) if pd.notna(user_carrier_activation) else False,
            "changed_data": changed_data,
            "iccids":all_devices  if all_devices else all_msisdns,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
       
        logging.info(f"### Assign Customer Payload Ready: {payload}")
        try :
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_assign_customer_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Assign Customer",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_assign_customer_sheet auditing failed in success case :{e}")
               
        return {
            "flag": True,
            "message": "Assign Customer data processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_assign_customer_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_assign_customer_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_assign_customer_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_assign_customer_sheet auditing failed in error case :{e}")
       
        return {
            "flag": False,
            "message": "Assign Customer Bulk change failed",
            "error": str(e)
        }
        

def process_reset_voice_email_password_sheet(df, data):
    """
    Process the Reset Voicemail Password bulk upload sheet and prepare
    the payload required to reset voicemail PINs for sims.

    Args:
        df (pandas.DataFrame):
            DataFrame containing the uploaded Reset Voicemail Password sheet.

        data (dict):
            Dictionary containing request metadata such as:

    Returns:
        dict:
                {
                    "flag": True,
                    "message": "Reset Voicemail Password change type processed successfully",
                    "data": {
                        "changed_data": {valid payload},
                        "iccids": <list>,
                        "imeids": [],
                        "is_msisdns": <bool>
                    }
                }

    """
    logging.info(f"### process_reset_voice_email_password_sheet called")
    
    # Connect to DB
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for reset voice email password"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
       
        devices_final = all_devices if all_devices else all_msisdns
        
        # Extract first row payload fields
        first_row = df.iloc[0]
        billing_account_number =str(first_row.get("Billing Account Number", "")).strip()
        if "." in billing_account_number:
            billing_account_number = billing_account_number.split(".")[0]
        new_voice_email__pin = str(first_row.get("New Voicemail Pin", "")).strip()
        if "." in new_voice_email__pin:
            new_voice_email__pin = new_voice_email__pin.split(".")[0]
       
        # Create the payload structure
        changed_data = {
            "OverrideValidation": False,
            "Devices":devices_final,
            "billingAccount": {
            "id": str(billing_account_number) if  billing_account_number else ""
            },
            "serviceCharacteristic": [
            {
                "name": "newPin",
                "value": new_voice_email__pin if new_voice_email__pin else ""
            }
            ]
        }
        payload = {
            "changed_data": changed_data,
            "iccids": all_devices if all_devices else all_msisdns,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        
        logging.info(f"### Reset voice email password Payload Ready: {payload}")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_reset_voice_email_password_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Reset Voicemail Password",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_reset_voice_email_password_sheet auditing failed in success case :{e}") 
        
        return {
            "flag": True,
            "message": "Reset Voicemail Password change type processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_reset_voice_email_password_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_reset_voice_email_password_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_reset_voice_email_password_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_reset_voice_email_password_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Reset Voicemail Password Bulk change failed",
            "error": str(e)
        }
        
def process_change_phone_number_sheet(df, data):
    """
    Process a bulk upload sheet for changing phone numbers or sending SMS to devices 
    identified by MSISDN (or ICCID, if extended). Prepares the payload for downstream 
    processing and logs the audit and error information in the database.

    Args:
        df (pandas.DataFrame): 
            DataFrame representing the uploaded Excel sheet. Expected columns include:
        data (dict): 
            Dictionary containing metadata for request and logging, e.g.:

    Returns:
        dict: Result dictionary with the following structure:
            {
                "flag": True/Flag,      
                "message":"Send SMS data processed successfully/failed",
            }
    """
    logging.info(f"### process_change_phone_number_sheet called with data : {data}")
    # Connect to DB
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        #Get the first value from the column
        if "Save Changes" in df.columns:
            flag = df["Save Changes"].iloc[0] if not df["Save Changes"].empty else None
        else:
            flag = None 
        # Treat everything as False unless explicitly True
        is_true = False
 
        if flag is not None and not pd.isna(flag):
            if str(flag).strip().lower() in {"true", "1", "yes"}:
                is_true = True
 
        if not is_true:
            return {
                "flag": True,
                "message": "Change Phone Number change type is not allowed"
            }
 
        # Extract essential keys from original data safely
        all_msisdns = data.get("msisdns")
        if not all_msisdns:
            return {
                "flag": False,
                "message": "No valid ICCID/MSISDN found for processing."
            }
        # taking today's date as by default 
        effective_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000Z")
        # Create the payload structure
        changed_data = {
            "old_msisdn": all_msisdns,
            "new_msisdn": all_msisdns,
            "effective_date": effective_date
        }
        payload = {
            "changed_data": changed_data,
            "iccids": all_msisdns,
            "imeids":[],
            "is_msisdns": True
        }
        
        logging.info(f"### Send sms Payload Ready: {payload}")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_change_phone_number_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "change phone number",
                    "devices": all_msisdns
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_change_phone_number_sheet auditing failed in success case :{e}")    
        
        return {
            "flag": True,
            "message": "Change Phone number processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_change_phone_number_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_change_phone_number_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_change_phone_number_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_change_phone_number_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Change phone Number Bulk change failed",
            "error": str(e)
        } 
    
      
def process_send_sms_sheet(df, data):
    """
    Process the Send SMS bulk upload sheet and prepare payload for sending SMS
    to devices identified by ICCID or MSISDN.

    Args:
        df (pandas.DataFrame):
            DataFrame containing the uploaded Send SMS Excel sheet data.
        data (dict):
            Dictionary containing request metadata such as:
    Returns:
        dict:
                {
                    "flag": True/False,
                    "message": "Send SMS data processed successfully/failed",
                    "data": {
                        "changed_data": {
                            "messageText": <str>
                        }
                }
    """
    logging.info(f"### process_send_sms_sheet called with data : {data}")
    # Connect to DB
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for send sms"
            }
        # Extract essential keys from original data safely
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
        
        devices_final = all_devices if all_devices else all_msisdns
        
        # Extract first row payload fields
        first_row = df.iloc[0]
        message_text = first_row.get("Message Text", "")
        if pd.isna(message_text) or str(message_text).strip() == "":
            return {
                "flag": False,
                "message": "Given message is empty. Enter a valid message."
            }

        # Convert to clean string
        message_text = str(message_text).strip()
        # Create the payload structure
        changed_data = {"messageText": message_text}
        payload = {
            "changed_data": changed_data,
            "iccids": devices_final,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        
        logging.info(f"### Send sms Payload Ready: {payload}")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_send_sms_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Send SMS",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_send_sms_sheet auditing failed in success case :{e}")
        
        return {
            "flag": True,
            "message": "Send SMS data processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_send_sms_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_send_sms_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_send_sms_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_send_sms_sheet auditing failed in error case :{e}")
        
        return {
            "flag": False,
            "message": "Send SMS Bulk change failed",
            "error": str(e)
        }    

def process_private_static_ip_address_sheet(df, data):
    """
    Process the Change Private Static IP Address bulk upload sheet and
    prepare the payload required to update private static IP addresses
    for devices identified by ICCID or MSISDN.
 
    Args:
        df (pandas.DataFrame):DataFrame containing the uploaded bulk change sheet.
 
        data (dict):
            Dictionary containing request metadata such as: username , session_id , tenant_name etc.
 
    Returns:
        dict:
                {
                    "flag": True,
                    "message": "Private Static Ip Address change type processed successfully",
                    "data": {
                        "changed_data": <dict>,
                        "iccids": <list>,
                        "imeids": [],
                        "is_msisdns": <bool>,
                        "iccid_ip_map": <dict>
                    }
                }
    """
    logging.info(f"### process_private_static_ip_address_sheet called")
    # Connect to DB
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
   
    try:
        # Normalize column names
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for private static ip address"
            }
        # Get identifiers from data
        all_iccids = data.get("iccids") or []
        all_msisdns = data.get("msisdns") or []
        ip_list = data.get("ip_addresses") or []

        devices_final = all_iccids if all_iccids else all_msisdns

        if not devices_final:
            return {
                "flag": False,
                "message": "No valid ICCID or MSISDN found in request data."
            }

        if not ip_list:
            return {
                "flag": False,
                "message": "No valid Private Static IP addresses found in uploaded sheet."
            }

        # Map identifiers to IPs (1:1 by order)
        if len(ip_list) != len(devices_final):
            return {
                "flag": False,
                "message": "Number of IP addresses must match number of ICCIDs/MSISDNs."
            }

        iccid_ip_map = dict(zip(devices_final, ip_list))

        # Use first row for remaining payload fields
        first_row = df.iloc[0]
        
        pdp_name = "" 
        pdp_id = ""
        private_static_apn = ""
        billing_account_number = ""
        null_values = {"", "nan", "none", "null", "na", "n/a", "undefined",None}
        # validating the mandatory columns 
        if "Pdp Name" in df.columns:        
            pdp_name = str(first_row.get("Pdp Name", ""))
            if not pdp_name or pdp_name.lower() in null_values:
                    return {"flag": False, "message": "Pdp Name column must have a valid value"}    
        if  "Pdp Id" in df.columns : 
            pdp_id = str(first_row.get("Pdp Id", "")) 
            if not pdp_id or pdp_id.lower() in null_values:
                    return {"flag": False, "message": "Pdp Id column must have a valid value"}  
        if  "Private Static Apn" in df.columns : 
            private_static_apn = str(first_row.get("Private Static Apn", "")) 
            if not private_static_apn or private_static_apn.lower() in null_values:
                    return {"flag": False, "message": "Private Static Apn column must have a valid value"}        
        if  "Billing Account Number" in df.columns : 
            billing_account_number = str(first_row.get("Billing Account Number", "")).strip()
            if "." in billing_account_number:
                billing_account_number = billing_account_number.split(".")[0]  
                if not billing_account_number or billing_account_number.lower() in null_values:
                    return {"flag": False, "message": "Billing Account Number column must have a valid value"}                      
       
        # Get current date for effectiveDate
        current_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
       
        # Create the payload structure to handle different service providers
        if pdp_id and private_static_apn : 
            changed_data = {
                "changedData": {
                "ipv6Address": "",
                "apn": private_static_apn,
                "pdpId": pdp_id
                }
            }
        elif pdp_name and billing_account_number :     
            changed_data = {
                "changedData": {
                    "pdpName": pdp_name,
                    "billingAccountNumber": str(billing_account_number) if billing_account_number else "",
                    "subscriber": [
                        {
                            "subscriberNumber": "",
                            "ipAddressRecord": {
                                "ipAddress": "",
                                "ipAddressCode": "",
                                "ipAddressType": ""
                            },
                            "effectiveDate": current_date
                        }
                    ]
                }
            }
        else : 
            changed_data = {
                "changedData": {
                "ipAddress": ""
                }}
            
        payload = {
            "changed_data": changed_data,
            "iccids": devices_final,
            "imeids": [],
            "is_msisdns": False if all_iccids else True,
            "iccid_ip_map": iccid_ip_map
        }
       
        logging.info(f"### Change Private Static IP Address Payload Ready. Processed {len(df)} rows.")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_private_static_ip_address_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Change Private Static IP Address",
                    "devices_count": len(devices_final),
                    "rows_processed": len(df),
                    "iccid_ip_map_count": len(iccid_ip_map)
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_private_static_ip_address_sheet auditing failed in success case :{e}")
       
        return {
            "flag": True,
            "message": "Private Static Ip Address change type processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_private_static_ip_address_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_private_static_ip_address_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_private_static_ip_address_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_private_static_ip_address_sheet auditing failed in error case :{e}")
       
        return {
            "flag": False,
            "message": "Private Static Ip Address Bulk change failed",
            "error": str(e)
        }
                
        
def process_change_iccid_imei_sheet(df, data):
    """
    Process the Change ICCID / IMEI bulk change Excel sheet and construct
    a validated payload for downstream ICCID / IMEI update execution.

    Parameters:
        df (pandas.DataFrame):
            Uploaded Excel sheet data containing Change ICCID / IMEI details.

        data (dict):
            Metadata and runtime information required auditing purpose

    Returns:
        dict:
            {
                "flag": bool,
                "message": str,
                "data": {
                    "changed_data": dict,
                    "iccids": list,
                    "imeids": list,
                    "is_msisdns": bool
                }
            }
    """
    logging.info(f"### process_change_iccid_imei_sheet called with data :{data}")
    service_provider = data.get("service_provider")
    
    # Connect to DB
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
    
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for change Iccid/Imei"
            }

        # Extract MSISDNs from original data
        all_msisdns = data.get("msisdns")
            
        # Extract ICCIDs and IMEIs from the DataFrame (sheet data)
        all_devices = []
        new_imeis = []

        # Get unique non-empty values from the sheet
        if 'New Iccid' in df.columns:
            # Keep as pandas Series for filtering
            iccids_series = df['New Iccid'].dropna().astype(str).str.strip()
            # Filter out empty strings
            all_devices = iccids_series[iccids_series != ""].tolist()

        if 'New Imei' in df.columns:
            # Keep as pandas Series for filtering
            imeis_series = df['New Imei'].dropna().astype(str).str.strip()
            # Filter out empty strings
            new_imeis = imeis_series[imeis_series != ""].tolist()

        devices_final = all_devices if all_devices else new_imeis

        if not devices_final:
            return {
                "flag": False,
                "message": "No valid ICCID/IMEI found for processing."
            }
        if not all_msisdns : 
            return {
                "flag": False,
                "message": "No valid MSISDN found for processing"
            }
        if len(devices_final) != len(all_msisdns):
            return {
                "flag": False,
                "message":"enter same no of iccid/imei(Change ICCID IMEI sheet)  and msisdns(Devices sheet)"
            }        
             
        # Extract first row payload fields
        first_row = df.iloc[0]
        customer_rate_plan = (
            str(first_row.get("Customer Rate Plan")).split("--")[0].strip()
            if pd.notna(first_row.get("Customer Rate Plan")) else None
        )

        customer_rate_pool = (
            str(first_row.get("Customer Rate Pool")).split("--")[0].strip()
            if pd.notna(first_row.get("Customer Rate Pool")) else None
        )
        # for taking service provider based payload 
        config = load_json()
        service_provider_mappings = config.get("ServiceProviderMappings", {})
        service_provider_lower = service_provider.lower()

        provider_config = next(
            (
                cfg
                for cfg in service_provider_mappings.values()
                if any(name.lower() == service_provider_lower for name in cfg.get("unique_names", []))
            ),
            {}
        )
        payload_template = provider_config.get("payload_template", {})
        request_template = payload_template.get("Request", {})

        if "mode" in request_template: 
        # Create the payload structure
            changed_data = {
                "UpdateStatus": None,
                    "IsIgnoreCurrentStatus": False,
                    "PostUpdateStatusId": 0,
                    "Request": {
                        "OldICCID": all_msisdns if all_msisdns else None,
                        "NewICCID": all_devices if all_devices else None,
                        "OldIMEI": None,
                        "NewIMEI": new_imeis,
                        "serviceCharacteristic": [
                        {
                            "name": "reasonCode",
                            "value": "CUST_OWN_EQU"
                        },
                        {
                            "name": "serviceZipCode",
                            "value": ""
                        },
                        {
                            "name": "technologyType",
                            "value": ""
                        },
                        {
                            "name": "IMEI",
                            "value": ""
                        },
                        {
                            "name": "sim",
                            "value": ""
                        }
                        ]
                    },
                    "RevService": {
                        "Number": None,
                        "ICCID": None,
                        "CreateRevService": False,
                        "IntegrationAuthenticationId": 0,
                        "AddCarrierRatePlan": False,
                        "CarrierRatePlan": None,
                        "CommPlan": None,
                        "UseAgentAccount": False,
                        "JasperDeviceID": None,
                        "SiteId": 0,
                        "AddCustomerRatePlan": True,
                        "CustomerRatePlan": customer_rate_plan,
                        "CustomerRatePool": customer_rate_pool,
                        "DeviceId": 0,
                        "RevCustomerId": None,
                        "ProviderId": None,
                        "ServiceTypeId": 0,
                        "Prorate": False,
                        "Description": None,
                        "ActivatedDate": None,
                        "UsagePlanGroupId": None
                    },
                    "RevServiceProductCreateModel": None,
                    "IntegrationAuthenticationId": None
            }
        else :     
            changed_data = {
            "UpdateStatus": None,
            "IsIgnoreCurrentStatus": False,
            "PostUpdateStatusId": 0,
            "Request": {
            "OldICCID": all_msisdns if all_msisdns else None,
            "NewICCID": all_devices if all_devices else None,
            "OldIMEI": None,
            "NewIMEI": new_imeis,
            "MSISDN": None,
            "EID": None,
            "IdentifierType": 0,
            "AddCustomerRatePlan": True,
            "CustomerRatePlan": customer_rate_plan,
            "CustomerRatePool": customer_rate_pool
            },
            "RevService": None,
            "RevServiceProductCreateModel": None,
            "IntegrationAuthenticationId": None
        }
        payload = {
            "changed_data": changed_data,
            "iccids": all_devices  if all_devices else all_msisdns,
            "imeids": new_imeis,
            "is_msisdns": False if all_devices else True
            
        }
        logging.info(f"### change iccid/imei Payload Ready: {payload}")
        try : 
            # AUDIT LOG ENTRY
            audit_data_user_actions = {
                "service_name": "process_change_iccid_imei_sheet",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Change iccid/imei",
                    "devices": devices_final
                }),
                "module_name": "Sim Management",
                "request_received_at": data.get("request_received_at"),
            }
            
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_change_iccid_imei_sheet auditing failed in success case :{e}")    
        
        return {
            "flag": True,
            "message": "Change iccid/imei data processed successfully",
            "data": payload
        }
        
    except Exception as e:
        logging.error(f"### something went wrong in process_change_iccid_imei_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_change_iccid_imei_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_change_iccid_imei_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_change_iccid_imei_sheet auditing failed in error case :{e}")
       
        return {
            "flag": False,
            "message": "Change iccid imei Bulk change failed",
            "error": str(e)
        }          
                                          
def process_communication_plan_sheet(df, data):
    """
    Process Communication Plan sheet for Communication Plan change.
    Args:
        df (DataFrame): The sheet data
        data (dict): Input data
    Returns:
        dict: Processed payload for Communication plan change type
    """
    
    logging.info(f"### process_communication_plan_sheet called")
    db_name = data.get("db_name", "")
    service_provider = data.get("service_provider", "")
    # Connect to DB
    try:
        tenant_database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {
            "flag": False,
            "message": "database connection failed",
            "error": str(e)
        }
   
    try:
        if df.empty:
            return {
                "flag": True,
                "message": f"No valid records found for Communication Plan"
            }
        # Extract essential keys safely from original data 
        all_devices = data.get("iccids")
        all_msisdns = data.get("msisdns")
        devices_final = all_devices if all_devices else all_msisdns  
       
        # Extract first row payload fields
        first_row = df.iloc[0]        
        # validating the communication plan name
        comm_plan_name = str(first_row.get("Communication Plan", "")).strip()
        null_values = {"", "nan", "none", "null", "na", "n/a", "undefined",None}

        if not comm_plan_name or comm_plan_name.lower() in null_values:
            return {"flag": False, "message": "Communication Plan column must have a valid value"}
         
        comm_plan_id = ""
        comm_plan_data = pd.DataFrame()
        if comm_plan_name :
            comm_plan_data = tenant_database.get_data(
            "sim_management_communication_plan",
            {"communication_plan_name": comm_plan_name,"service_provider_name": service_provider, "is_active": True},
            ["id"]   
        )
        if not comm_plan_data.empty:
            comm_plan_id = comm_plan_data["id"].iloc[0]
        else:
            return {"flag": False, "message": f"Invalid communication plan name: {comm_plan_name} for {service_provider}"}
 
        # Create the payload structure
        changed_data = {
            "Comm_plan_name": comm_plan_name,
            "Comm_plan_id":int(comm_plan_id) if comm_plan_id else ""
        }
        payload = {
            "changed_data": changed_data,
            "iccids": devices_final,
            "imeids":[],
            "is_msisdns": False if all_devices else True
        }
        logging.info(f"### Communication plan Payload Ready: {payload}")
        try :
            # AUDIT LOG ENTRY 
            audit_data_user_actions = {
                "service_name": "process_communication_plan_sheet",
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps({
                    "change_type": "Change Communication Plan",
                    "devices": devices_final
                }),
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### process_communication_plan_sheet auditing failed in success case :{e}")
        return {
            "flag": True,
            "message": "Communication Plan data processed successfully",
            "data": payload
        }
    except Exception as e:
        logging.error(f"### something went wrong in process_communication_plan_sheet error : {e}")
        # ERROR LOGGING
        error_type = type(e).__name__
        try:
            common_utils_database.log_error_to_db({
                "service_name": "process_communication_plan_sheet",
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "process_communication_plan_sheet failed",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at"),
            }, "error_log_table")
        except Exception as e:
            logging.error(f"### process_communication_plan_sheet auditing failed in error case :{e}")
       
        return {
            "flag": False,
            "message": "Communication plan Bulk change failed",
            "error": str(e)
        }                 
            

def crossprovider_device_history_sync(data):
    """
    Synchronizes cross-provider device history by identifying devices with usage
    that are not already in cross-provider history and inserting them.
    
    This function filters device usage records to find devices that have data usage
    but are not present in the cross-provider device history table, then creates
    cross-provider history records for those devices.
    
    Args:
        data (dict): Request data containing:
            - tenant_name (str): Name of the tenant
            - service_provider (str): Service provider name
            - created_by (str, optional): User who created the sync. Defaults to "Kore_Container"
            - usage_date (str): Date for which to sync usage data
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - records_synced (int, optional): Number of records synchronized
    
    Raises:
        Exception: Any errors during database operations or data processing
    """
    logging.info(f"Received data for crossprovider_device_history_sync: {data}")
    tenant_id = data.get("tenant_id")
    service_provider_id = data.get("service_provider_id")
    created_by = data.get("created_by", "Kore_Container")
    usage_date = data.get("usage_date")
    
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        tenant_df = common_utils_database.get_data(
            table_name="tenant",
            condition={"id": tenant_id, "is_active": True},
            columns=["tenant_name","db_name"]
        )
        if tenant_df is None or tenant_df.empty:
            return {"flag": False, "message": f"Tenant '{tenant_id}' not found."}
        
        tenant_name = tenant_df.iloc[0]["tenant_name"]
        db_name=str(tenant_df.iloc[0]["db_name"])
        tenant_database = DB(db_name, **db_config)

        # fetch service_provider_id from serviceproviders table
        service_provider_df = tenant_database.get_data(
            "serviceprovider",
            {"id": service_provider_id, "is_active": True},
            ["service_provider_name"]
        )
        if service_provider_df is None or service_provider_df.empty:
            return {"flag": False, "message": f"Service provider '{service_provider_id}' not found."}
        service_provider = service_provider_df.iloc[0]["service_provider_name"]


        # Fetch device history data for the given usage_date
        device_id_column = "mobility_device_id" if "Telegence" in service_provider else "m2m_device_id"
        device_usage_query = f"""
            SELECT {device_id_column}
            FROM device_usage
            WHERE usage_date = %s AND created_by = %s AND data_usage > 0
        """
        device_usage_df = tenant_database.execute_query(device_usage_query, params=[usage_date, created_by])
        logging.info(f"### crossprovider_device_history_sync length of device_usage_df : {len(device_usage_df)}")

        # fetch latest billing_period_id from billing_periods table
        billing_period_query = """
            SELECT id FROM billing_period where service_provider = %s 
            AND is_active = TRUE ORDER BY id DESC LIMIT 1
        """
        billing_period_df = tenant_database.execute_query(billing_period_query, params=[service_provider])
        if billing_period_df is None or billing_period_df.empty:
            return {"flag": False, "message": f"No active billing period found for service provider '{service_provider}'."}
        billing_period_id = int(billing_period_df.iloc[0]["id"])
        logging.info(f"### crossprovider_device_history_sync billing_period_id : {billing_period_id}")

        # fetch cross_provider_device_ids from cross_provider_device_history table for the given service_provider and billing_period_id
        
        cross_provider_device_column = "mobility_device_id" if "Telegence" in service_provider else "m2m_device_id"
        cross_provider_devices_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"service_provider_id": service_provider_id, 
             "billing_period_id": billing_period_id,
             "tenant_id": tenant_id,
             "is_active": True
             },
             [cross_provider_device_column]
        )
        logging.info(f"### crossprovider_device_history_sync length of cross_provider_devices_df : {len(cross_provider_devices_df)}")
        # Get all inventory data for all device usage records
        all_device_ids = device_usage_df[device_id_column].tolist()
        if not all_device_ids:
            return {"flag": True, "message": "No device usage records found."}
            
        inventory_device_column = "mobility_device_id" if "Telegence" in service_provider else "device_id"
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_device_column: all_device_ids, "is_active": True, "service_provider_id": service_provider_id, "tenant_id": tenant_id}
        )
        
        # Split into new and existing records
        if not cross_provider_devices_df.empty:
            cross_provider_device_ids = set(cross_provider_devices_df[cross_provider_device_column].tolist())
            new_device_ids = [did for did in all_device_ids if did not in cross_provider_device_ids]
            existing_device_ids = [did for did in all_device_ids if did in cross_provider_device_ids]
        else:
            new_device_ids = all_device_ids
            existing_device_ids = []
        
        def build_record(row):
            return {
                "m2m_device_id": row.get("device_id"),
                "mobility_device_id": row.get("mobility_device_id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "msisdn": row.get("msisdn"),
                "imsi": row.get("imsi"),
                "imei": row.get("imei"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "created_by": row.get("created_by"),
                "created_date": row.get("created_date"),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "account_number": row.get("rev_customer_id"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": tenant_id,
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "username": row.get("username"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "last_activated_date": row.get("last_activated_date"),
                "billing_period_id": billing_period_id,
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "cost_center": row.get("cost_center"),
                "communication_plan": row.get("communication_plan"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "is_active": True,
                "is_deleted": False,
            }
        
        # Process new records for insertion
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df["device_id"].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
            
        # Process existing records for update
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df["device_id"].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        
        # Insert new records
        inserted_count = 0
        if new_records:
            tenant_database.insert_data(new_records, "cross_provider_device_history")
            inserted_count = len(new_records)
            logging.info(f"Inserted {inserted_count} new cross-provider device history records")
        
        # Update existing records
        updated_count = 0
        if update_records:
            success = tenant_database.bulk_update_data(
                "cross_provider_device_history", 
                update_records, 
                search_column=cross_provider_device_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id, "tenant_id": tenant_id}
            )
            if success:
                updated_count = len(update_records)
                logging.info(f"Updated {updated_count} existing cross-provider device history records")
            
        # Success audit logging
        try:
            audit_data = {
                "service_name": "crossprovider_device_history_sync",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync completed for {service_provider} on {usage_date}",
                "module_name": "Inventory Management",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")

        device_history_sync(billing_period_id,inventory_df,db_name,service_provider_id,tenant_id,all_device_ids,usage_date,created_by,tenant_name)
            
        return {
            "flag": True, 
            "message": f"Successfully synced cross-provider device history: {inserted_count} inserted, {updated_count} updated",
            "records_inserted": inserted_count,
            "records_updated": updated_count
        }
        
    except Exception as e:
        logging.error(f"Error in crossprovider_device_history_sync: {e}")
        
        # Error audit logging
        try:
            error_data = {
                "service_name": "crossprovider_device_history_sync",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync failed for {service_provider} on {usage_date}",
                "module_name": "Inventory Management",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")
            
        return {"flag": False, "message": f"Error in crossprovider_device_history_sync: {str(e)}"}
    
def device_history_sync(billing_period_id,inventory_df,db_name,service_provider_id,tenant_id,all_device_ids,usage_date,created_by,tenant_name):
    logging.info(f"Starting device_history_sync for billing_period_id: {billing_period_id}, service_provider_id: {service_provider_id} usage_date: {usage_date}")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        tenant_database = DB(db_name, **db_config)
        device_history_df = tenant_database.get_data(
            "device_history",
            {"service_provider_id": service_provider_id, 
            "billing_period_id": billing_period_id,
            "tenant_id": tenant_id,
            "is_active": True
            },
            ['id']
        )

        if not device_history_df.empty:
            device_history_ids = set(device_history_df['id'].tolist())
            new_device_ids = [did for did in all_device_ids if did not in device_history_ids]
            existing_device_ids = [did for did in all_device_ids if did in device_history_ids]
        else:
            new_device_ids = all_device_ids
            existing_device_ids = []
        logging.info(f"device_history_sync - new_device_ids count: {len(new_device_ids)}, existing_device_ids count: {len(existing_device_ids)}")
        def build_record(row):
            return {
                "id": row.get("device_id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "changed_date": datetime.now(),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "last_usage_date": row.get("last_usage_date"),
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "is_pushed": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "device_tenant_id":row.get("dt_id"),
                "tenant_id": tenant_id
            }
        
        # Process new records for insertion
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df["device_id"].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
            
        # Process existing records for update
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df["device_id"].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        
        # Insert new records
        inserted_count = 0
        if new_records:
            tenant_database.insert_data(new_records, "device_history")
            inserted_count = len(new_records)
            logging.info(f"Inserted {inserted_count} new device history records")
        
        # Update existing records
        updated_count = 0
        if update_records:
            success = tenant_database.bulk_update_data(
                "device_history", 
                update_records, 
                search_column='id',
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id, "tenant_id": tenant_id}
            )
            if success:
                updated_count = len(update_records)
                logging.info(f"Updated {updated_count} existing device history records")
            
        # Success audit logging
        try:
            audit_data = {
                "service_name": "device_history_sync",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"device history sync completed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")

    except Exception as e:
        logging.error(f"Error in device_history_sync: {e}")
        # Error audit logging
        try:
            error_data = {
                "service_name": "device_history_sync",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"device history sync failed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")

def create_schedule(trigger_time_str, payload):
    """
    Creates a one-time AWS EventBridge Scheduler job to invoke a target Lambda.
    Parses the given UTC ISO timestamp, formats it to the required
    AWS `at()` expression format, and schedules the Lambda with
    the provided payload.

    Args:
        trigger_time_str (str): Execution time in ISO format (UTC). => Example: "2026-02-23T13:43:00.000Z"
        payload (dict): Data to be passed to the target Lambda function.

    Returns:
        dict: Response from scheduler.create_schedule API.
    """
    logging.info(f"### create_schedule trigger_time_str : {trigger_time_str} and payload : {payload}")
    start_time = time.time()
    try:
        scheduler = boto3.client("scheduler",region_name="us-east-1")
        request_received_at = payload.get("request_received_at")
        # step-1 : taking required env variables 
        ### here ARN stands for amazon resource name 
        BULK_CHANGE_LAMBDA_ARN = os.getenv("BULK_CHANGE_LAMBDA_ARN")
        SCHEDULER_INVOKE_ROLE_ARN = os.getenv("SCHEDULER_INVOKE_ROLE_ARN")
        
        # step-2 : connection to database
        try:
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as db_exception:
            logging.error(f"### create_schedule Failed to connect to the database:{str(db_exception)}")
            return {"error": "Database connection failed.", "details": str(db_exception)}

        # step-3 : Convert from DD-MM-YYYY HH:MM:SS to required format
        dt = datetime.fromisoformat(trigger_time_str.replace("Z", "+00:00"))
        formatted_time = dt.strftime("%Y-%m-%dT%H:%M:%S")  # AWS expects UTC ISO without 'Z'
        schedule_name = f"dynamic-trigger-{uuid.uuid4()}" # generate unique schedule_name 
        logging.info(f"### Creating schedule for {schedule_name} at time {formatted_time}")
        lambda_payload = {"data":payload}
        logging.info(f"### create_schedule calling scheduler.create_schedule with lambda_payload : {lambda_payload} ")
        
        # step-4 : creating schedular for the given effective date 
        response = scheduler.create_schedule(
            Name=schedule_name,
            ScheduleExpression=f"at({formatted_time})",
            ScheduleExpressionTimezone="UTC",
            FlexibleTimeWindow={
                "Mode": "FLEXIBLE",
                "MaximumWindowInMinutes": 2
            },
            ActionAfterCompletion="DELETE",  # auto delete after execution
            Target={
                "Arn": BULK_CHANGE_LAMBDA_ARN,
                "RoleArn": SCHEDULER_INVOKE_ROLE_ARN,
                "Input": json.dumps(lambda_payload)
            }
        )
        # step-5 : auditing in success case 
        try:
            end_time = time.time()
            time_consumed = int(end_time - start_time)
            audit_data = {
                "service_name": "create_schedule",
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "comments": f"Schedule name : {schedule_name} created for {formatted_time} with payload : {lambda_payload}",
                "tenant_name": payload.get("tenant_name"),
                "module_name": "Bulk Change",
                "created_by": payload.get("username"),
                "request_received_at":request_received_at
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")

        except Exception as audit_error:
            logging.exception(f"Audit logging failed (Success case): {audit_error}")
        return response
    
    except Exception as e:
        logging.exception("### Error while creating schedule")
        # step-6 : auditing in Error case 
        try:
            end_time = time.time()
            time_consumed = int(end_time - start_time)
            audit_data = {
                "service_name": "create_schedule",
                "status": "Failed",
                "time_consumed_secs": time_consumed,
                "comments": f"Failed to create schedule for {trigger_time_str} with payload : {payload}",
                "tenant_name": payload.get("tenant_name"),
                "module_name": "Bulk Change",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "request_received_at":request_received_at
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.exception(f"Audit logging failed (Failure case): {audit_error}")
        return {"flag": False, "message": str(e)}    
            

def schedule_bulk_change_execution(data):
    """
    Schedules or immediately executes a bulk change based on effective_date.
    
    A) If an effective_date is provided and is in the future (UTC), a one-time AWS EventBridge schedule is created and DB status
    is updated to SCHEDULED.
    B) If no effective_date is provided, the bulk change Lambda is invoked immediately.

    Returns:
        dict: {
            "flag": bool,   # True if scheduled/invoked successfully
            "message": str  # Result message
        }
    """

    logging.info(f"### Entered schedule_bulk_change_execution function with data :{data}")
    start_time = time.time()
    ### validation message if data is empty 
    if not data:
        return {"flag": False, "message": "bulk change procesor payload is empty"}

    try:
        ### step-1 extracting the input params : 
        changed_data = data.get("changed_data", [])
        first_record = {}
        # Ensure changed_data is list
        if isinstance(changed_data, list) and changed_data:
            first_record = changed_data[0]
        elif isinstance(changed_data, dict):
            first_record = changed_data
        ### taking the effective date     
        effective_date = (first_record.get("effective_date") or first_record.get("EffectiveDate"))
        change_type = data.get("change_type")
        bulk_change_lambda = os.getenv("bulk_change_lambda")
        bulk_change_id = data.get("bulk_change_id")
        db_name = data.get("db_name")
        username = data.get("username")
        tenant_name = data.get("tenant_name")
        service_provider = data.get("service_provider")
        request_received_at = data.get("request_received_at")
        data["path"] = "/bulk_change_processor"
        scheduled = False
        status_flag = False
        result_message = "Unknown Error"
        if not bulk_change_id:
            return{"flag":False , "message":"missing bulk change id"}  

        # step-2 connect to database :
        try:
            tenant_database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as db_exception:
            logging.error(f"### schedule_bulk_change_execution Failed to connect to the database:{str(db_exception)}")
            return {"error": "Database connection failed.", "details": str(db_exception)}

        if effective_date:
            # Extract only date part (YYYY-MM-DD)
            effective_date_only = effective_date.split("T")[0]

            # Convert to date object
            effective_dt = datetime.strptime(effective_date_only, "%Y-%m-%d").date()
            today_date = datetime.now(timezone.utc).date()
            logging.info(f"### schedule_bulk_change_execution | effective_date: {effective_date_only} | effective_dt: {effective_dt} | today_date: {today_date} | is_future: {effective_dt > today_date}")

            # step-3 : Effective Date is Future → Schedule
            if effective_dt > today_date:
                # If scheduling still needs a time, append fixed time here
                formatted_trigger_time = f"{effective_date_only}T19:00:00"
                # step-4 call create_schedule function to create the schedular 
                schedule_response = create_schedule(formatted_trigger_time, data)

                if schedule_response.get("ResponseMetadata", {}).get("HTTPStatusCode") == 200:
                    scheduled = True
                    ### updating status in sim_management_bulk_change table 
                    tenant_database.update_dict(
                        "sim_management_bulk_change",
                        {"status": "SCHEDULED"},
                        {"id": bulk_change_id},
                    )  
        
                    # Update each request row as SCHEDULED in sim_management_bulk_change_request table 
                    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    # step-5 : update in the sim_management_bulk_change_request table records & insert into sim_management_bulk_change_log table
                    bulk_requests_df = tenant_database.get_data(
                        "sim_management_bulk_change_request",
                        {"bulk_change_id": bulk_change_id},
                        ["id", "iccid"]
                    )
                    if not bulk_requests_df.empty:
                        # Update request table as SCHEDULED
                        tenant_database.update_dict(
                            "sim_management_bulk_change_request",
                            {
                                "status": "SCHEDULED",
                                "is_processed": False,
                                "has_errors": False,
                                "processed_date": None,
                                "status_details": f"Scheduled for {formatted_trigger_time}"
                            },
                            and_conditions={"bulk_change_id": bulk_change_id}
                        )
                        # Insert log entries for history
                        log_entries = []
                        for _, row in bulk_requests_df.iterrows():
                            log_entries.append({
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": row["id"],
                                "log_entry_description": f"{change_type} scheduled for effective date {formatted_trigger_time}",
                                "request_text": "Schedule Execution",
                                "has_errors": False,
                                "response_status": "SCHEDULED",
                                "response_text": "Request scheduled successfully",
                                "error_text": "",
                                "processed_date": now,
                                "processed_by": username,
                                "created_by": username,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            })

                        if log_entries:
                            tenant_database.insert_data(log_entries,"sim_management_bulk_change_log")
                            # tenant_database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
                    else:
                        raise Exception("No bulk request rows found")
                    result_message = f"{change_type} scheduled successfully for {formatted_trigger_time}"
                    status_flag = True
                else:
                    raise Exception("Scheduler creation failed")

            # step-6 : Effective Date Exists and is not Future date → Immediate Lambda Invocation
            else:
                logging.info("### schedule_bulk_change_execution Invoking bulk change lambda immediately")
                lambda_client = boto3.client("lambda")
                invoke_response = lambda_client.invoke(
                    FunctionName=bulk_change_lambda,
                    InvocationType="Event",
                    Payload=json.dumps(
                        {"data": data}
                    ).encode("utf-8"),
                )

                if invoke_response.get("StatusCode") in [200, 202]:    
                    result_message = f"{change_type} triggered immediately"
                    status_flag = True
                else:
                    raise Exception("Immediate Lambda invocation failed")
        # step-7 : auditing in success case 
        end_time = time.time()
        time_consumed = int(end_time - start_time)
        try : 
            audit_data = {
                "service_name": "schedule_bulk_change_execution",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Bulk change type for service provider: {service_provider}, change_type: {change_type}, bulk_change_id: {bulk_change_id}, execution_type: {'Scheduled' if scheduled else 'Immediate'}, effective_date: {effective_date if effective_date else 'Not Provided'}, payload : {data}",
                "request_received_at":request_received_at
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.exception(f"### Logging error failed in success case : {audit_error}")
        return {"flag": status_flag,"message": result_message}

    except Exception as e:
        logging.exception("### Error in schedule_bulk_change_execution")
        # step-8 : aduit in failure case 
        try:
            error_data = {
                "service_name": "schedule_bulk_change_execution",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "tenant_name": data.get("tenant_name"),
                "module_name": "Bulk Change",
                "comments": f"Error during bulk change type scheduling for change type : {change_type}",
                "request_received_at":request_received_at
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.exception(f"### Logging error failed: {audit_error} in Error case")

        return {
            "flag": False,
            "message": f"Bulk change type scheduling is failed for change type : {change_type}",
            "details": str(e)
        }
