import json
from opensearchpy import OpenSearch, helpers
import psycopg2
# from datetime import datetime
from datetime import datetime, timedelta, timezone
import uuid
from multiprocessing import Pool
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests.auth import HTTPBasicAuth
import time
import re
import os
import boto3
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import decimal
from dateutil.parser import parse as parse_datetime

logging = Logging(name="hybrid_logstash")

db_config = {  
    'port': os.getenv('PORT'),      
    'user': os.getenv('USER'),
    'host': os.getenv('HOST'),     
    'password': os.getenv('PASSWORD'),
    "multi_schema":False,
}

sns_client = boto3.client('sns')

# Configuration
BATCH_SIZE = 50000  # Adjust this batch size based on testing
NUM_PROCESSES = 2  # Number of processes (matches the number of vCPUs in your PostgreSQL instance)
batch_count = 0
# Connect to OpenSearch
def get_opensearch_client(tenant_name):
    if tenant_name in ["fourg_biz"]:
        host = "https://search-amopsearchbeta-isceq2fj5lksbvthco6p3f2nee.us-east-1.es.amazonaws.com"
    else:
        host = 'https://search-amopsearchuat-dzxpse4exyj37kauestkbgeady.us-east-1.es.amazonaws.com'
    auth = ('admin', 'Amopteam@123')  # Use your OpenSearch credentials
    return OpenSearch(
        [host],
        http_auth=auth,
        use_ssl=True,
        verify_certs=True,
        timeout=60
    )

def send_sns_alert(subject, message):
    topic_arn = os.environ.get('SNS_TOPIC_ARN','arn:aws:sns:us-east-1:008971638399:amop-beta')
    if not topic_arn:
        logging.info("SNS_TOPIC_ARN is not set in environment variables")
        return
    try:
        sns_client.publish(
            TopicArn=topic_arn,
            Subject=subject,
            Message=message
        )
    except Exception as e:
        logging.info(f"Failed to send SNS alert: {e}")

def parse_any_date(value):
    """Try to convert various date string formats to YYYY-MM-DD. Return unmodified if not a recognized date."""
    if value in (None, 'null', 'NULL', ''):
        return None

    date_formats = [
        '%Y-%m-%d',              # 2025-07-24
        '%m-%d-%Y',              # 07-24-2025
        '%m-%d-%y',              # 07-23-25
        '%d-%m-%Y',              # 24-07-2025
        '%d/%m/%Y',              # 24/07/2025
        '%m/%d/%Y',              # 07/24/2025
    ]

    if isinstance(value, str):
        for fmt in date_formats:
            try:
                dt = datetime.strptime(value, fmt)
                return dt.strftime('%Y-%m-%d')
            except Exception:
                continue
        # Try parsing ISO (fromisoformat)
        try:
            dt = datetime.fromisoformat(value)
            return dt.strftime('%Y-%m-%d')
        except Exception:
            pass
    return value


def normalize_dates(obj):
    """Recursively normalize only date-formatted strings in nested dicts/lists to YYYY-MM-DD."""
    if isinstance(obj, dict):
        return {k: normalize_dates(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [normalize_dates(i) for i in obj]
    elif isinstance(obj, str):
        if is_date_string(obj):
            return parse_any_date(obj)
        else:
            return obj
    else:
        return obj

def is_date_string(value):
    if not isinstance(value, str):
        return False
    # Regex for YYYY-MM-DD, YYYY-MM-DDTHH:MM:SS, etc.
    date_patterns = [
        r'^\d{4}-\d{2}-\d{2}$',
        r'^\d{2}-\d{2}-\d{4}$',
        r'^\d{2}/\d{2}/\d{4}$',
        r'^\d{2}/\d{2}/\d{2}$',
        r'^\d{2}-\d{2}-\d{2}$',
        r'^\d{4}/\d{2}/\d{2}$',
    ]
    for pattern in date_patterns:
        if re.match(pattern, value):
            return True
    return False

def get_db_config_details(tenant_name):
    logging.info(f"get_db_config_details function called for {tenant_name}")
    common_utils_database = None
    try:
        common_utils_database = DB("common_utils",**db_config)
        db_config_details = common_utils_database.get_data("tenant",{"tenant_name":tenant_name},["db_config"])["db_config"].to_list()[0]
        # db_config_dict = json.loads(tenant_db_details.iloc[0]["db_config"])
        logging.info(f"###db_config_details db_config_details:{db_config_details}")
        db_name = db_config_details.get("database")
        tenant_db_config = {
            "host": db_config_details.get("hostname"),
            "port": db_config_details.get("port"),
            "user": db_config_details.get("user"),
            "password": db_config_details.get("password"),
        }
        return db_name, tenant_db_config
    except Exception as e:
        logging.info(f"Error fetching db config details: {e}")
        return None
    finally:
        common_utils_database.close()
        
        
def get_values(portal_code, bulk_change_id, tenant_name, db_config_details):
    logging.info(f"get_values function called")
    
    if not db_config_details or not isinstance(db_config_details, (list, tuple)) or len(db_config_details) != 2:
        logging.error(f"Invalid db_config_details for tenant {tenant_name}: {db_config_details}")
        return []
    db_name, tenant_db_config = db_config_details
    if not db_name:
        logging.error(f"DB name missing for tenant: {tenant_name}")
        return []

    if not tenant_db_config:
        logging.error(f"DB config is NULL for tenant: {tenant_name}")
        return []

    if isinstance(tenant_db_config, str):
        tenant_db_config = json.loads(tenant_db_config) 

    if not isinstance(tenant_db_config, dict):
        logging.error(f"DB config is not a dict for tenant: {tenant_name}")
        return []   
    rev_column_name = None
    if portal_code == 2:
        column_name = "msisdn"
        rev_column_name = "service_number"
    elif portal_code == 0:
        column_name = "iccid"
        rev_column_name = "iccid"
    else:
        logging.error(f"Unknown portal_code: {portal_code}")
        return []
    
    try:
        tenant_database = DB(db_name, **tenant_db_config)
        bulk_request_data = tenant_database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            [column_name]
        )
        if hasattr(bulk_request_data, "empty"):
            if bulk_request_data.empty:
                return []
            return {rev_column_name:bulk_request_data[column_name].astype(str).tolist()}
        values = []
        for row in bulk_request_data:
            if isinstance(row, dict):
                values.append(row[column_name])
            elif isinstance(row, (list, tuple)):
                values.append(row[0])
            else:
                values.append(row)
        
        return {rev_column_name:values}
    except Exception as e:
        logging.exception(f"DB error for tenant {tenant_name}: {e}")
        return []
    finally:
        tenant_database.close()


def bulk_rev_assuarance_index(table_name, db_name, column_name, list_of_values):
    conn = None
    try:
        logging.info(f"Fetching data for {table_name} from {db_name} of {column_name}")
        conn = connect_to_postgres(db_name)
        schema = get_table_schema(conn, table_name)
        columns_list = ', '.join([f'"{col}"' for col in schema.keys()])
        # Identify the primary key column dynamically
        primary_key_column = "id"  # Assuming 'id' is always the primary key (even if not the first column)
        last_id = None
        where_condition = f'"{column_name}" = ANY(%s)'
        params = [list_of_values]
        while True:
            if last_id:
                query = f"""
                    SELECT {columns_list} 
                    FROM {table_name} 
                    WHERE {where_condition} 
                        AND "{primary_key_column}" > %s
                    ORDER BY "{primary_key_column}" ASC 
                    LIMIT %s
                """
                query_params = tuple(params + [last_id, BATCH_SIZE])
            else:
                query = f"""
                    SELECT {columns_list} 
                    FROM {table_name} 
                    WHERE {where_condition}
                    ORDER BY "{primary_key_column}" ASC 
                    LIMIT %s
                """
                query_params = tuple(params + [BATCH_SIZE])

            with conn.cursor() as cur:
                cur.execute(query, query_params)
                rows = cur.fetchall()
                if not rows:
                    break

                yield (table_name, rows, schema)
                # Get the index of the primary key column dynamically
                primary_key_index = list(schema.keys()).index(primary_key_column)
                last_id = rows[-1][primary_key_index]  # Use the last processed primary key for pagination
    except Exception as e:
        logging.info(f"[fetch_and_bulk_index_data] Error: {e}")
        raise  # Re-raise the exception to be handled by the caller
    finally:
        if conn:
            conn.close()

    

def lambda_handler(event, context):
    try:
        # Print the payload from the event
        logging.info("Lambda triggered from scheduler")
        logging.info(f"Payload received: {json.dumps(event)}")
        tenant_name= event.get("tenant_name")
        view_name = event.get("view_name")
        start_date = event.get("start_date")
        end_date =  event.get("end_date")
        
        
        path = event.get("path" , None)
        if path:
            tenant_name= event.get("tenant_name",None)
            portal_code = event.get("portal_code",None)
            bulk_change_id = event.get("bulk_change_id",None)
            if tenant_name is None:
                logging.info("Tenant name not found in event")
                return
            if portal_code is None:
                logging.info("Portal code not found in event")
                return 
            if bulk_change_id is None:
                logging.info("Bulk change id not found in event")
                return
            db_config_details = get_db_config_details(tenant_name)
            db_name  = db_config_details[0]
            es = get_opensearch_client(db_name)
            data_dict = get_values(portal_code, bulk_change_id, tenant_name, db_config_details)
            logging.info(f"dict_of_values : {data_dict}")
            column_name, list_of_values = next(iter(data_dict.items()))
            for data in bulk_rev_assuarance_index(view_name, db_name, column_name, list_of_values):
                bulk_index_data(data, db_name, es)
                
            return {"path":path,"status":"Sucessfully Indexed"}

        es = get_opensearch_client(tenant_name)

        if not start_date:
            logging.info("Error: Invalid or missing start_date.")
            return  

        # Print the calculated dates
        logging.info(f"Start Date: {start_date}")
        logging.info(f"End Date: {end_date}")
        start_time = time.time() 

        try:
            lambda_flag = True
            update_flag(view_name,lambda_flag,tenant_name)
            logging.info(f"Updated true for {view_name}")
            process_table(view_name, tenant_name, start_date, end_date, es)
            logging.info(f"Processed table for {view_name} successfully")
        except psycopg2.errors.QueryCanceled as e:
            logging.info("PostgreSQL query timed out")
            send_sns_alert("PostgreSQL Query Timeout", f"Query for {view_name} timed out (12 Minutes) of {tenant_name}")
            logging.info(f"### Exception {e}")
            insert_audit_record(
                view_name=view_name,
                tenant_name=tenant_name,
                error_msg=f"TIMEOUT: {str(e)}"
            )
        except Exception as e:
            logging.info(f"Error processing table: {e}")
            insert_audit_record(
                view_name=view_name,
                tenant_name=tenant_name,
                error_msg=str(e)
            )
        finally:
            lambda_flag = False
            try:
                update_flag(view_name, lambda_flag, tenant_name)
                logging.info(f"Updated false for {view_name}")
            except Exception as e:
                logging.info(f"Failed to reset flag for {view_name}: {e}")
        

        end_time = time.time()  # Record the end time

        execution_time = end_time - start_time

        logging.info(f"Execution time: {execution_time} seconds")

        
        return {
            'statusCode': 200,
            'body': json.dumps(f"Lambda processed {view_name} with startdate : {start_date} and enddate: {end_date}")
        }

    except Exception as e:
        logging.info(f"Error in Lambda function: {e}")
        if view_name and tenant_name:
            insert_audit_record(
                view_name=view_name,
                tenant_name=tenant_name,
                error_msg=f"LAMBDA LEVEL ERROR: {str(e)}"
            )
        return {
            'statusCode': 500,
            'body': json.dumps("Internal server error")
        }

def update_flag(view_name,flag,tenant_name):
    conn = None
    if tenant_name == 'common_utils':
        tenant_name = 'altaworx_central_beta'
    try:
        conn = connect_to_postgres(tenant_name)
        query="""
        UPDATE opensearch_lambda_status
        SET flag = %s
        WHERE view_name = %s;
        """
    
        with conn.cursor() as cur:
            cur.execute(query, (flag, view_name))
        conn.commit()  # Commit the transaction
    except Exception as e:
        logging.info(f"Error updating flag: {e}")
    finally:
        conn.close()  # Always close the connection


def connect_to_postgres(db_name):
    if db_name in ['fourg_biz']:
        host = "amopbetapostgresdb2.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
    else:
        host = "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"

    return psycopg2.connect(
        dbname=db_name,
        user="root",
        password="AmopTeam123",
        host=host,
        port="5432",
        options='-c statement_timeout=720000'
    )

def parse_datetime(value):
    if value in (None, 'null', 'NULL', ''):
        return None
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value)  # Assuming ISO format is used
        except ValueError:
            try:
                return datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f')  # If it's in the format with microseconds
            except ValueError:
                logging.info(f"Warning: Unable to parse date time string: {value}\n")
                return None
    elif isinstance(value, datetime):
        return value
    return None



def get_table_schema(conn, table_name):
    query = """
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_name = %s
        ORDER BY ordinal_position
    """
    try:
        with conn.cursor() as cur:
            cur.execute(query, (table_name,))
            columns = cur.fetchall()
        return {column[0]: column[1] for column in columns}
    except Exception as e:
        logging.info(f"[get_table_schema] Error: {e}")
    
    

def parse_datetime(value):
    if value in (None, 'null', 'NULL', ''):
        return None
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value).isoformat()
        except ValueError:
            try:
                return datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f').isoformat()
            except ValueError:
                logging.info(f"Warning: Unable to parse date time string: {value}\n")
                return value
    elif isinstance(value, datetime):
        return value.isoformat()
    return value

def convert_value_bk(value, data_type):
    if value in (None, 'null', 'NULL', ''):
        return None
    if data_type == 'boolean':
        return str(value).lower() in ('true', '1')
    elif data_type == 'timestamp without time zone':
        return parse_datetime(value).isoformat() if isinstance(value, str) else value.isoformat()
    elif data_type == ('character varying', 'text'):
        return str(value)
    elif data_type == 'integer':
        return int(value)
    elif data_type == 'real':
        return float(value)
    elif data_type == 'uuid':
        try:
            return str(uuid.UUID(value))
        except ValueError:
            logging.info(f"Warning: Invalid UUID format: {value}\n")
            return value
    elif data_type == 'json':
        if isinstance(value, list):
            return value  # Directly return if the value is already a list
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            logging.info(f"Warning: Invalid JSON format: {value}\n")
            return value
    return value

from datetime import datetime, timedelta, time as dt_time
from dateutil.parser import parse as dateutil_parse

def adjust_midnight_to_previous_second(value):
    if value is None:
        return None

    if isinstance(value, str):
        value = dateutil_parse(value)

    if not isinstance(value, datetime):
        return value

    if value.time() == dt_time(0, 0, 0) and value.year <= 2025:
        return value - timedelta(seconds=1)

    return value


def convert_value(value, data_type, column_name):
    if value in (None, 'null', 'NULL', '','{}', '[]') or (isinstance(value, (dict, list)) and not value):
        return None
    try:
        if column_name in ['billing_cycle_end_date']:
            value = adjust_midnight_to_previous_second(value)
        if data_type == 'boolean':
            return str(value).lower() in ('true', '1')
        elif data_type == 'timestamp without time zone':
            if isinstance(value, str):
                value = dateutil_parse(value)

            if isinstance(value, datetime):
                return value.isoformat()

            return None
        elif data_type in ('character varying', 'text'):
            return str(value)
        elif data_type == 'integer':
            return int(value)
        elif data_type == 'real':
            return float(value)
        elif isinstance(value, decimal.Decimal):
            return float(value)
        elif data_type == 'uuid':
            return str(uuid.UUID(value))
        elif data_type == 'json':
            if isinstance(value, (dict, list)):
                return value  # Keep as object/array
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                logging.info(f"Warning: Invalid JSON format: {value}\n")
                return None
        # Optional fallback for unknown types
        else:
            return value
    except Exception as e:
        logging.info(f"[convert_value] Error converting value '{value}' with type '{data_type}': {e}")
        return None

def bulk_index_data(batch_data,db_name,es):
    table_name, rows, schema = batch_data
    index_name = f"{table_name}_{db_name}"
    index_name = index_name.lower()
    logging.info(f"index_name : {index_name}")
    actions = []
    for item in rows:
        doc = {}
        for i, column_name in enumerate(schema.keys()):
            value = item[i]
            data_type = schema[column_name]
            converted_value = convert_value(value, data_type, column_name)
            # if column_name == 'billing_cycle_end_date':
            #     print(f"billing_cycle_end_date --> {converted_value}") 
            doc[column_name] = converted_value

        if 'id' not in doc:
            logging.info(f"Warning: 'id' key not found in document for {table_name} --------'{index_name}': {doc}")
            break
        
        doc = normalize_dates(doc)
        
        action = {
            "_op_type": "index",  # Use "update" if you want to update existing documents
            "_index": index_name,
            '_id': doc['id'],
            "_source": doc,
        }

        actions.append(action)
        
    try:
        response = helpers.bulk(es, actions)
        logging.info(f"Successfully indexed {response[0]} documents for {table_name} and {index_name}")
    except Exception as e:
        logging.info(f"Error indexing documents: {e}")
        insert_audit_record(
        view_name=table_name,
        tenant_name=db_name,
        error_msg=f"BULK INDEX ERROR: {str(e)}"
    )


def fetch_and_bulk_index_data(table_name, db_name, start_date, end_date):
    conn = None
    try:
        logging.info(f"Fetching data for {table_name} from {start_date} to {end_date}")
        conn = connect_to_postgres(db_name)
        schema = get_table_schema(conn, table_name)
        columns_list = ', '.join([f'"{col}"' for col in schema.keys()])
        # Identify the primary key column dynamically
        primary_key_column = "id"  # Assuming 'id' is always the primary key (even if not the first column)
        last_id = None
        if table_name in ['vw_combined_rev_service_products','vw_combined_rev_service_products_with_out_variance'] and db_name == 'altaworx_central_beta':
            # start_date is a dict with 3 fields
            if isinstance(start_date, str):
                start_date = json.loads(start_date)
            conditions = []
            params = []

            for col, val in start_date.items():
                if val:
                    conditions.append(f"{col} > %s")
                    params.append(val)

            # (modified_date > %s OR rev_modified_date > %s OR inv_modified_date > %s)
            where_condition = "(" + " OR ".join(conditions) + ")"
        else:
            where_condition = "modified_date > %s"
            params = [start_date]
        while True:
            if last_id:
                query = f"""
                    SELECT {columns_list} 
                    FROM {table_name} 
                    WHERE {where_condition} 
                        AND "{primary_key_column}" > %s
                    ORDER BY "{primary_key_column}" ASC 
                    LIMIT %s
                """
                query_params = tuple(params + [last_id, BATCH_SIZE])
            else:
                query = f"""
                    SELECT {columns_list} 
                    FROM {table_name} 
                    WHERE {where_condition}
                    ORDER BY "{primary_key_column}" ASC 
                    LIMIT %s
                """
                query_params = tuple(params + [BATCH_SIZE])

            with conn.cursor() as cur:
                cur.execute(query, query_params)
                rows = cur.fetchall()
                if not rows:
                    break

                yield (table_name, rows, schema)
                # Get the index of the primary key column dynamically
                primary_key_index = list(schema.keys()).index(primary_key_column)
                last_id = rows[-1][primary_key_index]  # Use the last processed primary key for pagination
    except Exception as e:
        logging.info(f"[fetch_and_bulk_index_data] Error: {e}")
        raise  # Re-raise the exception to be handled by the caller
    finally:
        if conn:
            conn.close()


def process_table(table_name, db_name, start_date, end_date, es):
    # table_name, db_name = table_info
    for batch_data in fetch_and_bulk_index_data(table_name, db_name, start_date, end_date):
        logging.info(f"Got data for {table_name} between {start_date} and {end_date}")
        bulk_index_data(batch_data,db_name,es)



def insert_audit_record(view_name, tenant_name, error_msg):
    conn = None
    try:
        conn = connect_to_postgres(tenant_name)

        query = """
        INSERT INTO open_search_error_audit
        (view_name, db_name, error_msg)
        VALUES (%s, %s, %s);
        """

        with conn.cursor() as cur:
            cur.execute(query, (view_name, tenant_name, str(error_msg)[:2000]))
        conn.commit()

    except Exception as e:
        logging.info(f"Failed to insert audit record: {e}")
    finally:
        if conn:
            conn.close()