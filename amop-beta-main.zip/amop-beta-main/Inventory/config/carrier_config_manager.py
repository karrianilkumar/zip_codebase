import json
import os
from typing import Dict, Any, Optional
from common_utils.logging_utils import Logging
logging = Logging(name="carrier_config_manager")

class CarrierConfigManager:
    """Manages carrier configuration for different environments and tenants."""
    
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = 'config/carrier_config.json'
        self.config_path = config_path
        self._config = None
        self._load_config()
    
    def _load_config(self):
        """Load configuration from JSON file."""
        try:
            with open(self.config_path, 'r') as f:
                self._config = json.load(f)
        except Exception as e:
            logging.error(f"Failed to load carrier config: {e}")
            self._config = {"providers": {}, "environment_mappings": {}}
    
    def get_provider_config(self, service_provider: str) -> Optional[Dict[str, Any]]:
        """Get configuration for a specific provider and environment."""
        # Map environment-specific provider names
        mapped_provider = self._get_mapped_provider_name(service_provider)
        logging.info(f"Mapped provider: {mapped_provider}")
        return self._config.get("providers", {}).get(mapped_provider)
   
    def _get_mapped_provider_name(self, service_provider: str) -> str:
        """Map provider name based on environment."""
        env_mappings = self._config.get("providers", {}).get(service_provider, {})
        return env_mappings.get(service_provider, service_provider)
   
    def get_device_type(self, service_provider: str) -> str:
        """Get device type (msisdn/iccid) for provider."""
        config = self.get_provider_config(service_provider)
        return config.get("device_type", "iccid") if config else "iccid"
 
    
    def build_request_config(self, service_provider: str, operation: str, **kwargs) -> Dict[str, Any]:
        """Build complete request configuration with substituted values."""
        provider_config = self.get_provider_config(service_provider)
        if not provider_config:
            return None
        
        operation_config = provider_config.get(operation, {})
        if not operation_config:
            return None
        
        # Deep copy to avoid modifying original config
        request_config = json.loads(json.dumps(operation_config))
        
        # Substitute placeholders in templates
        self._substitute_placeholders(request_config, kwargs)
        
        return request_config
    
    def _substitute_placeholders(self, obj: Any, substitutions: Dict[str, Any]):
        """Recursively substitute placeholders in configuration."""
        if isinstance(obj, dict):
            for key, value in obj.items():
                obj[key] = self._substitute_placeholders(value, substitutions)
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                obj[i] = self._substitute_placeholders(item, substitutions)
        elif isinstance(obj, str):
            for key, value in substitutions.items():
                if value is not None:
                    obj = obj.replace(f"{{{key}}}", str(value))
        return obj
    
    def get_all_providers_by_device_type(self, environment: str = "PROD") -> Dict[str, list]:
        """Get providers grouped by device type."""
        providers = {"msisdn": [], "iccid": []}
        
        for provider_name in self._config.get("providers", {}):
            mapped_name = self._get_mapped_provider_name(provider_name, environment)
            device_type = self.get_device_type(provider_name, environment)
            providers[device_type].append(mapped_name)
        
        return providers