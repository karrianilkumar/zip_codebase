"""
@Author1 : Phaneendra.Y
@Author2 :Ajay
@Author3 :Puja
Created Date: 05-09-2025
"""

# Importing the necessary Libraries
import os
import json
import time
import threading
import boto3 # type: ignore
import pandas as pd # type: ignore
from datetime import datetime
import numpy as np
import base64
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from config.carrier_config_manager import CarrierConfigManager

# from refactored_status_update import send_device_update_status_bulk
from refactored_carrier_apis import send_carrier_rate_plan_update,send_device_update_status_bulk

from inventory_utils import(
    create_bulk_change_record,
    bulkchange_lambda_caller,
    load_integration_authentication_json,
    get_integration_authentication_id_by_unique_name
)
from change_type_dropdown import (
    customers_dropdown_inventory,
    carrier_activation_date_rate_plans,
    inventory_dropdowns_data,
    fetch_cost_centers,
    update_features_pop_up_data,
    statuses_inventory,
    reason_codes_inventory,
    get_rev_service_type_bulk_change_data,
    get_assign_customer_bulk_change_data,
    )


logging = Logging(name="inventory")
config_manager = CarrierConfigManager()
# Database configuration
common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }


def clean_tuple(tpl):
    """
    Formats a tuple for SQL queries, handling edge cases like None values and single-item tuples.
    
    Args:
        tpl (tuple or None): The tuple to format
        
    Returns:
        str or tuple: A properly formatted string representation of the tuple for SQL queries,
                     or an empty tuple if the input is None or not a tuple
    """
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        logging.exception(f"### clean_tuple Exception while converting {e}")
        return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name,readme_flag):
    """
    Creates a database configuration dictionary with user-specific filters based on tenant and role.
    
    Args:
        user (str): Username to look up permissions for
        db_config_making (dict): Base database configuration to extend
        tenant_database (str): Name of the tenant database
        tenant_name (str): Name of the tenant
        role_name (str): User's role (e.g., 'Super Admin')
        readme_flag (bool): Flag to determine query format (client_id vs user_name)
        
    Returns:
        dict: Modified database configuration with user-specific filters
    """
    logging.info(f"db_config_maker is in progress {role_name}")
    # Connect to common_utils database to get tenant info
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"],**common_utils_database_config)
    # Get tenant ID and parent tenant ID
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    # Bypass filtering for Super Admin users
    if role_name in ('Super Admin','Partner Admin') and not parent_tenant_id:
        logging.info(f"Getting access filters for  in tenant: {tenant_name} with role: {role_name} in if condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name in ('Super Admin','Partner Admin') and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in else condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name =="Agent Partner Admin" and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in elif second condition")
        pass
    else:
        logging.info(f"Getting access filin tenant: {tenant_name} with role: {role_name} in else condition")
        pass
    if tenant_id:
        tenant_id=int(tenant_id)
    #Get user permissions from mapping table
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)
        if filters.empty:
            query = f"""
                SELECT customers, service_provider, customer_group
                FROM user_module_tenant_mapping
                WHERE user_name = '{user}' AND tenant_id = {tenant_id}
            """
            filters = common_utils_database.execute_query(query, True)
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

        filters = common_utils_database.execute_query(query, True)
    # Connect to tenant database
    database = DB(tenant_database, **db_config)
    # Extract customer group if exists
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except Exception as e:
        logging.info(f"### db_config_maker customer_group exception : {e}")
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    # If user has a customer group, get additional filters from it
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            # Extract rate plan names
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception(f"### db_config_maker Error extracting rate_plan_name : {e}")
            # Extract customer names
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception(f"### db_config_maker Error extracting customer_names : {e}")
                customer_names=None
            # Extract billing account number
            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception(f"### db_config_maker Error extracting billing_data : {e}")
                billing_account_number=None
            # Extract feature codes
            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"### db_config_maker Error extracting feature_data : {e}")
    # Set customer filter - use customer group names if available, otherwise use direct mapping
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except Exception as e:
            logging.exception(f"### db_config_maker Error extracting customer : {e}")
            customer = None
    else:
        customer=customer_names
    #customer=clean_tuple(customer)
    # Get service provider info and convert names to IDs
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except Exception as e:
        logging.info(f"### db_config_maker service_provider exception : {e}")
        service_provider = None
        service_provider_id = None
    # Get additional customers created by this user
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer_list = [customer]
                elif isinstance(customer, tuple):
                    customer_list = list(customer)
                else:
                    customer_list = customer  # Already a list

                fixed_customer_list = customer_list.copy()

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info('customer_list before extend:', customer_list)

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info('customer_list after extend:', fixed_customer_list)

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info('final customer tuple:', customer)
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"### db_config_maker Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Get additional rate plans created by this user
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)

    except Exception as e:
        logging.exception(f"### db_config_maker Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Update configuration with all filters
    logging.info(f"{user} user is service_provider is {service_provider} and service_provider_id is {service_provider_id} and ")
    if role_name =="Agent Partner Admin" and parent_tenant_id:
        db_config_making["customers"] = None
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = None
        db_config_making["feature_codes"] = None
        db_config_making["billing_account_number"] = None
        return db_config_making
    else:
        db_config_making["customers"] = customer
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
        db_config_making["feature_codes"] = feature_codes
        db_config_making["billing_account_number"] = billing_account_number
        return db_config_making


def function_caller(data, path, access_token=None):
    """
    Main function caller that handles database configuration setup and routes requests.

    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler

    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts

    Returns:
        Result of the called endpoint function or error response
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
        
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    # Extract username from request data (handling different field names)
    user = data.get("username",'')
    sqs_call = data.get('sqs_call',False) # Flag for SQS direct calls
    logging.info(f"### function_caller data recevied in function_caller is {data}")
    logging.info(f"### function_caller path received is {path}")
    # Fallback username field
    if not user:
        user = data.get("user_name",'')
    # Get target database name
    tenant_database = data.get("db_name",'')
    # Handle different authentication scenarios for API Calls and UI Calls
    if not access_token:
        ##UI Call
        # Regular user flow (no access token)
        role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
        # Special case for test tenant
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        readme_flag=False
        # Build database config for UI Calls
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
        logging.info(f"### function_caller db_config is created {path}")
    elif sqs_call:
        # SQS direct call flow (bypasses normal auth)
        logging.info("### function_caller sqs falg is true so skipped all the steps and calling the API")
        pass
    else:
        #API Call
        # Service account flow (using access token)
        logging.info(f"### function_caller path gotten is {path}")
        # Connect to common utils database
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        user = data.get("client_id", "")
        # Get service account info
        service_data = common_utils_database.get_data(
            "service_accounts", {"client_id": user}
        )

        if service_data.empty:
            logging.info(f"### function_caller Invalid client ID: {user}")
            return {"flag": False, "message": "Invalid client ID"}
        # Extract service account permissions
        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}
        )
        tenant_database = tenant_data["db_name"].to_list()[0]
        data['tenant_name']=tenant_name
        data['db_name']=tenant_database
        readme_flag=True
        # Build database config for service account
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
    # Route to appropriate endpoint handler

    path_function_map = {
        "/service_provider_change_types": service_provider_change_types,
        "/update_carrier_rate_plan": update_carrier_rate_plan,
        "/update_customer_rate_plan": update_customer_rate_plan,
        "/edit_cost_center": update_edit_cost_center,
        "/update_private_network_ip":update_private_network_ip,
        "/update_status": update_device_status,
        "/send_sms":send_sms,
        #"/update_feature_codes": update_feature_codes,
        "/update_features": update_features,
        "/update_assign_customer": update_assign_customer,
        "/update_line_sync":inventory_line_sync_update,
        "/update_phone_number":update_change_phone_number,
        "/edit_cost_center_20":edit_cost_center_20,
        "/change_customer_rate_plan_20":change_customer_rate_plan_20,
        "/update_device_status_20" : update_device_status_20,
        "/change_carrier_rate_plan_20":change_carrier_rate_plan_20,
        "/update_line_sync_20" : inventory_line_sync_update_20,
        "/update_feature_codes_20" : update_feature_codes_20,
        "/assign_customer_20":assign_customer_20,
        "/update_ppu_address": update_ppu_address,
        "/update_user_name": update_user_name,
        "/reset_voicemail_password":reset_voicemail_password,
        "/update_refresh_a_line":update_refresh_a_line,
        "/update_communication_plan": update_communication_plan,
        "/sim_management_action_history_update":sim_management_action_history_update,
        "/update_user_name_20":update_user_name_20,
        "/update_change_phone_number_20":update_change_phone_number_20,
        "/update_ppu_address_20":update_ppu_address_20,
        "/update_refresh_a_line_20":update_refresh_a_line_20,
        "/customers_dropdown_inventory":lambda data: customers_dropdown_inventory(data, db_config,common_utils_database_config),
        "/carrier_activation_date_rata_plans":lambda data: carrier_activation_date_rate_plans(data,db_config_withoutfilter,common_utils_database_config),
        "/inventory_dropdowns_data":lambda data: inventory_dropdowns_data(data, db_config,common_utils_database_config),
        "/fetch_cost_centers":lambda data: fetch_cost_centers(data, db_config,common_utils_database_config),
        "/update_features_pop_up_data":lambda data: update_features_pop_up_data(data, db_config,common_utils_database_config),
        "/statuses_inventory":lambda data: statuses_inventory(data, db_config,db_config_withoutfilter,common_utils_database_config),
        "/reason_codes_inventory":lambda data: reason_codes_inventory(data, db_config,common_utils_database_config),
        "/get_rev_service_type_bulk_change_data":lambda data: get_rev_service_type_bulk_change_data(data, db_config,common_utils_database_config),
        "/get_assign_customer_bulk_change_data":lambda data: get_assign_customer_bulk_change_data(data, db_config,db_config_withoutfilter,common_utils_database_config),
        "/insert_audit_logs":insert_audit_logs
        
    }
    # Use the map to call the corresponding function
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.info(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


def update_device_status(data):
    """
    Updates device status for multiple devices in bulk operation.
    
    This function processes bulk device status updates by validating inventory data,
    creating a bulk change record, and calling the carrier API for status updates.
    It handles the complete workflow including audit logging and error handling.
    
    Args:
        data (dict): Request data containing:
            - changed_data (list): List of device records to update, each containing:
                - sim_status (str): New device status
                - device_status_id (int): Status ID
                - mode (str, optional): Update mode
                - reason_code (str, optional): Reason code for status change
            - service_provider_display_name (str): Service provider name
            - tenant_name (str): Tenant name
            - db_name (str): Database name
            - username (str, optional): Username for audit logging
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - message (str): Status message with bulk change ID on success
    
    Raises:
        Exception: Any errors during bulk update processing are caught and logged
    """
    logging.info(f"### update_device_status data received: {data}")

    changed_data = data.get("changed_data", [])
    db_name=data.get("db_name", "")
    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}

    # Extract common values from first record (used throughout)
    first_record = changed_data[0]
    device_status = first_record.get("sim_status", "")
    tenant_name=data.get("tenant_name")
    change_event_type=data.get("change_event_type")
    username=data.get("username", "")
    device_status_id = first_record.get("device_status_id")
    mode = first_record.get("mode")
    reason_code = first_record.get("reason_code")
    parent_provider_name=data.get("parent_provider_name","")
    logging.info(f"### parent_provider_name in update_device_status is {parent_provider_name}")


    # Validate inventory
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    # Extract validated data (safe single lookups)
    tenant_database = validate_response["tenant_database"]
    inventory_data = validate_response["inventory_data"]
    tenant_data = validate_response["tenant_data"]
    service_provider_data = validate_response["service_provider_data"]
    common_utils_database = validate_response["common_utils_database"]

    tenant_id = int(tenant_data["id"].iloc[0])
    service_provider_id = int(service_provider_data["id"].iloc[0])
    service_provider = data.get("service_provider_display_name", "")
    # Audit logs (async) 
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### update_device_status Error updating action history: {e}")
    # Add metadata to data dict for consistency
    data.update({
        "change_event_type": "Update Device Status",
        "service_name": "update_status",
    })

    try:
        # Create bulk change record
        bulk_change_id, change_event_id = create_bulk_change_record(
            data, service_provider_id, tenant_id, tenant_database,
            data["change_event_type"], len(changed_data)
        )
        logging.info(f"### update_device_status bulk_change_id: {bulk_change_id}")
        if parent_provider_name:
            service_provider=parent_provider_name
        # Prepare args for bulk status update
        result = send_device_update_status_bulk(
            data=data,
            tenant_database=tenant_database,
            service_provider=service_provider,
            device_status=device_status,
            changed_data=changed_data,
            bulk_change_id=bulk_change_id,
            status_id=device_status_id,
            tenant_data=tenant_data,
            inventory_data=inventory_data,
            mode=mode,
            reason_code=reason_code,
            common_utils_database_config=common_utils_database_config
        )
        if not result["flag"]:
            error_data = data.copy()
            error_data["flag"] = False
            error_data["message"] = result.get("message", "An error occurred during bulk update")
            error_data["comments"] = json.dumps(changed_data)
            try:
                insert_audit_logs(error_data)
            except Exception as exception:
                logging.warning(f"### update_device_status error auditing failed: {exception}")
            return result

        logging.info(f"### update_device_status result: {result}")
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_device_status auditing failed: {exception}")
        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulk_change_id}"}
    except Exception as e:
        logging.error(f"### Error in update_device_status: {e}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_device_status error auditing failed: {exception}")
        return {"flag": False, "message": "An error occurred during bulk update"}


#sub functions
def service_provider_change_types(data):
    """
    Retrieves allowed change types for a specific service provider.

    Args:
        data (dict): Contains service_provider_id, db_name

    Returns:
        dict: Response with flag and list of allowed change_types
    """
    service_provider_id = data.get("service_provider_id", "")
    db_name = data.get("db_name", "")
    try:
        tenant_database = DB(db_name, **db_config_withoutfilter)
        change_type_ids = tenant_database.get_data(
            "smi_change_type_mapping",
            {"serviceprovider_id": int(service_provider_id), "is_allowed": True},
            ["change_type_id"],
        )["change_type_id"].to_list()

        change_types_df = tenant_database.get_data(
            "inventory_change_type",
            {"status": "active"},
            ["id", "change_type_name"],
        )
        # Get names for the change_type_ids
        change_types_names = (
            change_types_df[change_types_df["id"].isin(change_type_ids)]["change_type_name"]
            .sort_values()        # ensure ascending order
            .to_list()
        )
        return {"flag": True, "change_types": change_types_names}

    except Exception as exception:
        logging.error(f"### Error in service_provider_change_types: {exception}")
        return {"flag": True, "change_types": []}

#data validatuon
def validate_inventory_data(data):
    """
    Validates inventory data and database connections for device operations.
    
    Args:
        data (dict): Contains changed_data, service_provider_display_name, tenant_name, and db_name
    
    Returns:
        dict: Response with flag, validated data objects, and error messages if validation fails
    """
    logging.info(f"### validate_inventory_data Request Data: {data}")
    changed_data = data.get("changed_data", [])
    if isinstance(changed_data, list):
        row_ids = [record.get("id") for record in changed_data if "id" in record]
    else:
        row_ids = [changed_data.get("id")]

    # Extract and validate required input parameters
    service_provider = data.get("service_provider_display_name", "")

    # Validate tenant name is provided
    tenant_name = data.get("tenant_name")
    if not tenant_name:
        return {"flag": False, "message": "No tenant name provided."}

    # Handle special case for Altaworx Test tenant
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    # Get database name for tenant-specific operations
    db_name = data.get("db_name", "")

    try:
        # Initialize database connections
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        # Validate tenant exists in the system
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name,"is_active":True},
        )
        if tenant_data.empty:
            return {"flag": False, "message": "Tenant not found."}

        # Connect to tenant-specific database
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Retrieve inventory details for the specified device
        inventory_data = tenant_database.get_data(
            "sim_management_inventory",
            {"id": row_ids}
        )
        if inventory_data.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Validate service provider exists in tenant database
        service_provider_data = tenant_database.get_data(
            "serviceprovider",
            {"service_provider_name": service_provider},
            ["id", "integration_id"],
        )
        if service_provider_data.empty:
            return {"flag": False, "message": "Service provider not found."}
        
        return {
            "flag": True,
            "inventory_data": inventory_data,
            "tenant_data": tenant_data,
            "service_provider_data": service_provider_data,
            "tenant_database": tenant_database,
            "common_utils_database": common_utils_database,
        }
    except Exception as exception:
        logging.exception(f"### validate_inventory_data Exception : {exception}")
        return {"flag": False, "message": f"Error validating inventory data.{exception}"}


def fetch_previous_current_value(data,inventory_data):
    """Fetch previous and current values based on change event type"""
    # result = validate_inventory_data(data)
    # if not result["flag"]:
    #     return None, None
        
    change_event_type = data.get("change_event_type", "")
    changed_data = data.get("changed_data", [{}])
    first_record = changed_data[0] if changed_data else {}
    
    if change_event_type == 'Update feature':
        previous_value = inventory_data["telegence_features"].iloc[0]
        current_value = first_record.get("telegence_features", "")
    elif change_event_type == 'Update Customer Rate Plan':
        previous_value = inventory_data["customer_rate_plan_name"].iloc[0]
        current_value = first_record.get("customer_rate_plan_name", "")
    elif change_event_type == 'Update Carrier Rate Plan':
        previous_value = inventory_data["carrier_rate_plan_name"].iloc[0]
        current_value = first_record.get("carrier_rate_plan_name", "")
    elif change_event_type == 'Update Status':
        previous_value = inventory_data["sim_status"].iloc[0]
        current_value = first_record.get("sim_status", "")
    elif change_event_type == "Line Sync":
        key = list(first_record.keys())[1] if len(first_record.keys()) > 1 else None
        previous_value = inventory_data[key].iloc[0] if key in inventory_data.columns else ""
        current_value = first_record.get(key, "")
    elif change_event_type == "Assign Customer":
        previous_value = inventory_data["customer_name"].iloc[0]
        current_value = first_record.get("customer_name", "")
    elif change_event_type == "Change Phone Number":
        previous_value = inventory_data["msisdn"].iloc[0]
        current_value = first_record.get("msisdn", "")
    elif change_event_type == "Update PPU address":
        previous_value = inventory_data["user_address"].iloc[0]
        current_value = first_record.get("user_address", "")    
    elif change_event_type == "Edit Username/Cost Center":
        previous_value = inventory_data["username"].iloc[0]
        current_value = first_record.get("username", "")    
    else:
        previous_value = inventory_data["cost_center"].iloc[0]
        current_value = first_record.get("cost_center", "")
    
    return previous_value, current_value

 
#sim management inventory action history updating
def inventory_action_history_update(data, result):
    """Update inventory action history for all changed records with field-level details"""
    inventory_data = result["inventory_data"]
    logging.info(f"### inventory_action_history_update data received : {data}")
    
    if not result["flag"]:
        logging.info("### No data found for service provider.")
        return
    
    # Get common data
    service_provider_id = result["service_provider_data"]["id"].iloc[0]
    tenant_id = result["tenant_data"]["id"].iloc[0]
    tenant_database = result["tenant_database"]
    
    # Process each record in changed_data
    changed_data = data.get("changed_data", [])
    logging.info(f"### inventory_action_history_update changed_data:{changed_data}")
    update_to_action_table=[]
    for record in changed_data:
        row_id = record.get("id")
        if not row_id:
            continue
            
        single_record = inventory_data[inventory_data["id"] == row_id]
        if single_record.empty:
            continue
            
        # Extract data from the single record
        msisdn = single_record["msisdn"].iloc[0]
        account_number = single_record["account_number"].iloc[0]
        customer_name = single_record["customer_name"].iloc[0]
        mobility_device_id = single_record["mobility_device_id"].iloc[0]
        device_id = single_record["device_id"].iloc[0]
        iccid = single_record["iccid"].iloc[0]
        
        # Get field-level changes if available  
        field_changes = record.get("field_changes", [])
        
        if field_changes:
            # Create one history record for each changed field
            for field_change in field_changes:
                sim_management_inventory_action_history = {
                    "iccid": str(iccid),
                    "sim_management_inventory_id": row_id,
                    "msisdn": str(msisdn),
                    "username": str(data.get("username", "")),
                    "change_event_type": str(data.get("change_event_type", "")),
                    "date_of_change": datetime.utcnow(),
                    "changed_by": str(data.get("username", "")),
                    "is_deleted": False,
                    "is_active": True,
                    "service_provider_id": int(service_provider_id),
                    "customer_account_number": str(account_number),
                    "tenant_id": int(tenant_id),
                    "service_provider": str(data.get("service_provider_display_name", "")),
                    "bulk_change_id": int(data.get("bulk_change_id", 0)) if data.get("bulk_change_id") else None,
                    "uploaded_file_id": int(data.get("uploaded_file_id", 0)) if data.get("uploaded_file_id") else None,
                    "previous_value": str(field_change.get('previous_value', '')),
                    "current_value": str(field_change.get('current_value', '')),
                    "changed_field": str(field_change.get('field', '')),
                    "customer_account_name": str(customer_name),
                    "m2m_device_id": int(device_id) if device_id else None,
                    "mobility_device_id": int(mobility_device_id) if mobility_device_id else None,
                }
                update_to_action_table.append(sim_management_inventory_action_history)
                
                
        else:
            # Fallback to original behavior if no field changes available
            previous_value, current_value = fetch_previous_current_value({
                **data,
                "changed_data": [record]
            }, single_record)
            
            sim_management_inventory_action_history = {
                "iccid": str(iccid),
                "sim_management_inventory_id": row_id,
                "msisdn": str(msisdn),
                "username": str(data.get("username", "")),
                "change_event_type": str(data.get("change_event_type", "")),
                "date_of_change": datetime.utcnow(),
                "changed_by": str(data.get("username", "")),
                "is_deleted": False,
                "is_active": True,
                "service_provider_id": int(service_provider_id),
                "customer_account_number": str(account_number),
                "tenant_id": int(tenant_id),
                "service_provider": str(data.get("service_provider_display_name", "")),
                "bulk_change_id": int(data.get("bulk_change_id", 0)) if data.get("bulk_change_id") else None,
                "uploaded_file_id": int(data.get("uploaded_file_id", 0)) if data.get("uploaded_file_id") else None,
                "previous_value": str(previous_value) if previous_value else None,
                "current_value": str(current_value) if current_value else None,
                "changed_field": str(data.get("change_event_type", "")),
                "customer_account_name": str(customer_name),
                "m2m_device_id": int(device_id) if device_id else None,
                "mobility_device_id": int(mobility_device_id) if mobility_device_id else None,
            }
            update_to_action_table.append(sim_management_inventory_action_history)
    if update_to_action_table:
        # Insert history record - FIXED: Use correct variable names
        try:
            tenant_database.insert_data(update_to_action_table, "sim_management_inventory_action_history")
            logging.info(f"### History inserted for ICCID: {iccid}")
        except Exception as e:
            logging.error(f"### Error inserting history for ICCID {iccid}: {e}")


#audit log updating
def insert_audit_logs(data):
    """
    Records audit information for inventory operations into the database.
    Based on the operation outcome (success or failure), this function logs 
    the details into either the `audit_user_actions` table (for successful 
    actions) or the `error_log_table` (for failed actions).

    Args:
        data (dict): Input request payload containing:
            - tenant_id (int, optional): ID of the tenant.
            - tenant_name (str, optional): Name of the tenant.
            - user_id (int, optional): ID of the user performing the action.
            - username (str, optional): Name of the user performing the action.
            - service_provider_display_name (str, optional): Name of the service being invoked.
            - session_id (str, optional): Unique session identifier.

    Returns:
        None: The function does not return a value but writes logs to the 
        appropriate audit/error tables.        

    """
    logging.info(f"### insert_audit_logs Request Data: {data}")


    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = (data.get("request_received_at")or datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    logging.info(f"### insert_audit_logs Request Received At: {request_received_at}")
    message = data.get("message", "")
    change_type = data.get("change_type", "")
    start_time = time.time()
    service_provider = data.get("service_provider_display_name", "")
    session_id = data.get("session_id", "")
    error_type = data.get('error_type',"")
    comments = data.get('comments', "")
    #  Prefix message if request is from README   
    if data.get("z_access_token"):         
        message = f"This request came from README - {message}"
    
    # Initialize database connection
    common_utils_db = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config ) 
    
    if data.get("flag") : 
        try:
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            
            audit_data_user_actions = {
                "service_name":data.get('service_name'),
                "created_by": username,
                "status": True,
                "session_id":session_id,
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Inventory",
                "comments": message,
                "request_received_at": request_received_at
            }
        
            insert_audit=common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
            logging.info(f"### Audit :{audit_data_user_actions}")
            logging.info(f"### Audit inserted :{insert_audit}")
        except Exception as exception:
            
            logging.exception(f"### Audit logging (success) failed for tenant: {tenant_name}, service_provider: {service_provider}, change_type: {change_type}")
    else :
        try:
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            
            error_data = {
                "service_name": data.get('service_name'),
                "error_message": message,
                "error_type":error_type,
                "users": username,
                "tenant_name": tenant_name,
                "module_name": "Inventory",
                "comments": comments,
                "session_id":session_id,
                "request_received_at":request_received_at 
            }
        
            common_utils_db.update_audit(error_data, "error_log_table")
            logging.info(f"### Error :{error_data}")
        except Exception as exception:
            logging.warning(f"### Error logging failed for tenant : {tenant_name} and service_provider : {service_provider} and change_type : {change_type}  and error :  {exception}")


def update_carrier_rate_plan(data):
    """
    Updates carrier rate plan for multiple devices through bulk change processing.
    
    Args:
        data (dict): Request payload containing:
            - tenant_name (str): Name of the tenant
            - service_provider_display_name (str): Service provider name
            - changed_data (list): List of device records to update, each containing:
                - modified_by (str): User performing the change
                - carrier_rate_plan_name (str): New carrier rate plan name
                - communication_plan (str, optional): Communication plan
                - OptimizationGroup (str, optional): Optimization group
                - effective_date (str, optional): Date when change takes effect
    
    Returns:
        dict: Response with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message describing the operation result
    """
    logging.info(f"### update_carrier_rate_plan Request Data: {data}")
    # Validate input data
    db_name = data.get("db_name", "")
    changed_data = data.get("changed_data", [])
    parent_provider_name=data.get("parent_provider_name","")
    logging.info(f"### parent_provider_name in update_carrier_rate_plan is {parent_provider_name}")
    
    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}

    # Extract parameters from first record
    changed_record = changed_data[0]
    tenant_name = data.get("tenant_name")
    username = changed_record.get("modified_by", "")
    raw_value = changed_record.get("carrier_rate_plan_name", "") or ""
    # Split by " -- "
    parts = [p.strip() for p in raw_value.split("--")]
    # Remove empty strings
    non_empty = [p for p in parts if p]
    # Pick the first non-empty or ""
    carrier_rate_plan_name = non_empty[0] if non_empty else ""
    communication_plan = changed_record.get("communication_plan", "")
    optimization_group = changed_record.get("OptimizationGroup", "")
    effective_date = changed_record.get("effective_date") or ""

    service_provider = data.get("service_provider_display_name", "")
    change_event_type = "Change Carrier Rate Plan"

    # Validate inventory data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    # Extract validated components
    tenant_database = validate_response["tenant_database"]
    inventory_data = validate_response["inventory_data"]
    tenant_data = validate_response["tenant_data"]
    service_provider_data = validate_response["service_provider_data"]
    common_utils_database = validate_response["common_utils_database"]

    # Extract IDs using iloc for better performance
    tenant_id = int(tenant_data["id"].iloc[0])
    service_provider_id = int(service_provider_data["id"].iloc[0])
    
    # Update data with metadata
    data.update({
        "change_event_type": change_event_type,
        "service_name": "update_carrier_rate_plan",
    })
    
    # Start async action history logging
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### update_carrier_rate_plan Error updating action history: {e}")

    try:
        # Get integration ID using iloc for better performance
        integration_id = tenant_database.get_data(
            "serviceprovider", {"id": service_provider_id}, ["integration_id"]
        )["integration_id"].iloc[0]

        # Create bulk change record
        bulk_change_id, change_event_id = create_bulk_change_record(
            data, service_provider_id, tenant_id, tenant_database,
            change_event_type, len(changed_data)
        )
        logging.info(f"### update_carrier_rate_plan bulk_change_id: {bulk_change_id}")
        if parent_provider_name:
            service_provider=parent_provider_name
        # Execute carrier rate plan update
        result = send_carrier_rate_plan_update(
            data,
            tenant_database,
            changed_data,
            tenant_data,
            inventory_data,
            service_provider,
            service_provider_id,
            integration_id,
            carrier_rate_plan_name,
            effective_date,
            optimization_group,
            bulk_change_id,
            communication_plan,
            change_event_id,
            common_utils_database_config=common_utils_database_config
        )
        
        # Handle result and audit logging
        audit_data = data.copy()
        audit_data["flag"] = result["flag"]
        #audit_data["message"] = result.get("message", "Carrier rate plan update completed")
        audit_data["message"] = json.dumps(changed_data)
        
        
        if not result["flag"]:
            audit_data["error_type"] = "CarrierRatePlanUpdateError"
        
        # Async audit logging
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_carrier_rate_plan auditing failed: {exception}")
        
        if result["flag"]:
            return {"flag": True, "message": f"Data Updated Successfully for bulk change id: {bulk_change_id}"}
        else:
            return result
            
    except Exception as e:
        logging.exception(f"### Error in update_carrier_rate_plan: {e}")
        
        # Error audit logging
        error_data = data.copy()
        error_data.update({
            "flag": False,
            "message": str(e),
            "comments": json.dumps(changed_data),
            "error_type": type(e).__name__
        })
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_carrier_rate_plan error auditing failed: {exception}")
        
        return {"flag": False, "message": "An error occurred during carrier rate plan update"}


#customer rate plan chnage type
def update_customer_rate_plan(data):
    """
    Updates customer rate plan for multiple devices in inventory.
    
    This function validates the input data, checks if the specified customer rate plan
    and optional rate pool exist, then updates the inventory records with the new
    rate plan information.
    
    Args:
        data (dict): Request data containing:
            - changed_data (list): List of device records to update, each containing:
                - id (int): Device inventory ID
                - customer_rate_plan_name (str): New customer rate plan name
                - customer_rate_pool_name (str, optional): Customer rate pool name
            - service_provider_display_name (str): Service provider name
            - tenant_name (str): Tenant name
            - db_name (str): Database name
    
    Returns:
        dict: Response with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
    """
    logging.info(f"### update_customer_rate_plan Request Data Received: {data}")
    # --- Input extraction ---
    tenant_name=data.get("tenant_name", "")
    username=data.get("username", "")
    service_provider=data.get("service_provider_display_name", "")
    access_token=data.get("access_token", "")
    db_name=data.get("db_name", "")
    change_event_type = data.get("change_event_type", "")
    changed_data = data.get("changed_data", [])
    modified_by=changed_data[0].get("modified_by", "")
    changed_data = data.get("changed_data", [])
    parent_provider_name=data.get("parent_provider_name","")
    logging.info(f"### parent_provider_name in update_customer_rate_plan is {parent_provider_name}")

    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}

    # --- Validation ---
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
    inventory_data = validate_response["inventory_data"]
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    service_provider_data=validate_response["service_provider_data"]
    service_provider_id=int(service_provider_data["id"].iloc[0])
    tenant_data=validate_response["tenant_data"]
    tenant_id=int(tenant_data["id"].iloc[0])
    iccids = inventory_data["iccid"].tolist()
    uploaded_len=len(iccids)
    msisdns = inventory_data["msisdn"].tolist()
    data["service_name"]= "update_customer_rate_plan"
    
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    # -- required fields extract from data---
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    customer_name=next((record.get("customer_name") for record in changed_data), None)
    customer_id = next((record.get("customer_id") for record in changed_data), None)
      # Split by " -- "
    parts = [p.strip() for p in customer_name.split("--")]
    # Remove empty strings
    non_empty = [p for p in parts if p]
    # Pick the first non-empty or ""
    customer_name = non_empty[0] if non_empty else ""
    if not customer_id:
        for rec in changed_data:
            rec.pop("customer_id", None)
    customer_rate_plan_name = next((r.get("customer_rate_plan_name") for r in changed_data), None)
    if not customer_rate_plan_name:
        return {"flag": False, "message": "No customer rate plan name provided"}  
    
    # update action_history_logs
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### update_customer_rate_plan Error updating action history: {e}")
        
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len)
        
        logging.info(f"### update_customer_rate_plan bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        #extract data for prepare change request
        if customer_rate_plan_name.lower() == 'no change':
            customer_rate_plan_id = -1
            customer_data_allocation_mb = None
        else:
            rate_plan_data = tenant_database.get_data(
                "customerrateplan", {"rate_plan_name": customer_rate_plan_name, "is_active": True,"tenant_id":tenant_id}, ["id","plan_mb"]
            )
            if rate_plan_data.empty:
                return {"flag": False, "message": "Customer rate plan not found"}
            customer_rate_plan_id = int(rate_plan_data["id"].iloc[0])
            customer_data_allocation_mb=rate_plan_data["plan_mb"].iloc[0]

        # Validate rate pool
        customer_rate_pool_id = None
        customer_rate_pool_name = next((r.get("customer_rate_pool_name") for r in changed_data), None)
        if customer_rate_pool_name:
            rate_pool_data = tenant_database.get_data(
                "customer_rate_pool", {"name": customer_rate_pool_name, "is_active": True}, ["id"]
            )
            if rate_pool_data.empty:
                return {"flag": False, "message": "Customer rate pool not found"}
            customer_rate_pool_id = int(rate_pool_data["id"].iloc[0])
        # Get device type from configuration - NO HARDCODED LISTS
        if parent_provider_name:
            service_provider=parent_provider_name
        device_type = config_manager.get_device_type(service_provider)
        device_list = iccids if device_type == "iccid" else msisdns
        
        if not device_list:
            return {"flag": False, "message": f"No {device_type.upper()}s provided for {service_provider}"}
        # -- change request payload --
        customer_update = {"CustomerRatePlanId": int(customer_rate_plan_id)}
        if effective_date:
            customer_update["EffectiveDate"] = effective_date
        if customer_name:
            customer_update["customerName"] = customer_name
        if customer_id:
            customer_update["customerId"] = customer_id
        if customer_rate_pool_id:
            customer_update["CustomerPoolId"] = int(customer_rate_pool_id)
        if customer_data_allocation_mb:
            customer_update["CustomerDataAllocationMB"] = int(customer_data_allocation_mb)

        # Build change_request_payload
        change_request_payload = {
            "OverrideValidation": False,
            "Devices": device_list,
            "ServiceProviderId": int(service_provider_id),
            "ChangeType": int(change_type_id),
            "ProcessChanges": True,
            "CustomerRatePlanUpdate": customer_update,
        }
        logging.info(f"### change_request_payload:{change_request_payload}")
        # ✅ convert "" -> None in both changed_data & data
        for rec in changed_data:
            if rec.get("customer_rate_pool_name") == "":
                rec["customer_rate_pool_name"] = None

        # ✅ update back to main data dictionary
        data["changed_data"] = changed_data
        # call chnage request
        bulk_change_request(
            tenant_name=tenant_name,
            modified_by=modified_by,
            tenant_id=tenant_id,
            tenant_database=tenant_database,
            changed_data=changed_data,
            bulkchange_id=bulkchange_id,
            inventory_data=inventory_data,
            change_request_payload=change_request_payload
        )
 
        # take first record because all changeddata same
        record = changed_data[0]

        # build only expects keys
        telegence_payload = {
            "customer_rate_plan_name": record.get("customer_rate_plan_name", "") if customer_rate_plan_name else None,
            "customer_rate_pool_name": record.get("customer_rate_pool_name") if customer_rate_pool_name else None,
            "effective_date": effective_date if effective_date else ""
        }

        #bulk change lambda calling
        logging.info(f"### update_customer_rate_plan msisdn_list : {msisdns}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=telegence_payload,
            common_utils_database_config=common_utils_database_config
        )        
        # audit logging
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_customer_rate_plan auditing failed: {exception}")
        logging.info(f"### update_customer_rate_plan audit data : {audit_data}")
        return {"flag": True, "message": f"Data Updated Successfully for bulk change id{bulkchange_id}"}
    except Exception as exception:
        logging.exception(f"### update_customer_rate_plan Error: {exception}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(exception)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(exception).__name__,
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_customer_rate_plan error auditing failed: {exception}")
        return {"flag": False, "message": "Error updating customer rate plan"}

#edit cost center chnage type
def update_edit_cost_center(data):
    """
    Updates the cost center for multiple devices in inventory and syncs with carrier API.

    Args:
        data (dict): Request data containing device and cost center information

    Returns:
        dict: Response indicating success or failure of the operation
    """
    logging.info(f"### Edit Cost Center Request Data Received : {data}")

    # Extract and validate input
    tenant_name=data.get("tenant_name", "")
    service_provider=data.get("service_provider_display_name", "")
    access_token=data.get("access_token", "")
    carrier_api_status = data.get("carrier_api_status", True)
    parent_provider_name=data.get("parent_provider_name","")
    
    changed_data = data.get("changed_data", [])
    data["service_name"] = "edit_cost_center"
    db_name=data.get("db_name", "")
    username = changed_data[0].get("username")
    modified_by=changed_data[0].get("modified_by", "")
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    logging.info(f"### parent_provider_name : {parent_provider_name}")
    if not changed_data:
        return {"flag": False, "message": "No data provided for update"}
    cost_center = changed_data[0].get("cost_center", "")
    if not cost_center:
        return {"flag": False, "message": "Cost center value is required"}
    # Validate inventory data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    service_provider_data=validate_response["service_provider_data"]
    tenant_data = validate_response["tenant_data"]
    tenant_id = int(tenant_data["id"].iloc[0])
    service_provider_id=int(service_provider_data["id"].iloc[0])
    msisdns = inventory_data["msisdn"].tolist()
    iccids = inventory_data["iccid"].tolist()
    uploaded_len=len(iccids)
    data["change_event_type"]="Edit Username/Cost Center"
    logging.info(f"### update_edit_cost_center Request Data Receivedupdated: {data}")
    
    

    change_event_type = data.get("change_event_type", "")
    
    # update action_history_logs
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### update_edit_cost_center Error updating action history: {e}")
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len)

        logging.info(f"### update_ppu_address bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        # Get device type from configuration - NO HARDCODED LISTS
        if parent_provider_name:
            service_provider=parent_provider_name
        device_type = config_manager.get_device_type(service_provider)
        device_list = iccids if device_type == "iccid" else msisdns
        
        if not device_list:
            return {"flag": False, "message": f"No {device_type.upper()}s provided for {service_provider}"}
       
        change_request_payload={
        "ContactName": username if username else "",
        "CostCenter1": cost_center if cost_center else "",
        "ServiceProviderId": service_provider_id,
        "ChangeType": change_type_id
        }
        logging.info(f"### change_request_payload:{change_request_payload}")
        logging.info(f"### update_edit_cost_center changed_data1 : {changed_data}")
        bulk_change_request(
            tenant_name,
            modified_by,tenant_id,
            tenant_database,
            changed_data,
            
            bulkchange_id,
            inventory_data,change_request_payload
        )
                

        #bulk change lambda calling
        logging.info(f"### update_ppu_address msisdn_list : {msisdns}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config
        )      
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_edit_cost_center auditing failed: {exception}")
        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulkchange_id}"}
        
    except Exception as exception:
        logging.exception(f"### Error in update_edit_cost_center: {exception}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(exception)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(exception).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_edit_cost_center error auditing failed: {exception}")
        return {"flag": False, "message": "Cost center update failed"}

### To update communication plan
def update_communication_plan(data):
    """
    It updates the communication plan for single or multiple devices based on the provided data.

    Args:
        data (dict): Request payload containing:
            - tenant_name (str): Tenant name.
            - service_provider_display_name (str): Service provider display name.
            - parent_provider_name (str, optional): Parent service provider name.
            - db_name (str): Tenant database name.
            - changed_data (list[dict]): List of change records. Each record must include:
                - Comm_plan_name (str): Target communication plan name.
                - username (str): User initiating the change.
                - modified_by (str): User identifier for auditing.

    Returns:
        dict: Response object containing:
            - flag (bool): Indicates success or failure.
            - message (str): Success or error message describing the result.
    """
    logging.info(f"### update_communication_plan Request Data Received : {data}")

    # Extract and validate input
    tenant_name=data.get("tenant_name", "")
    service_provider=data.get("service_provider_display_name", "")
    parent_provider_name=data.get("parent_provider_name","")
    
    changed_data = data.get("changed_data", [])
    if not changed_data:
        return {"flag": False, "message": "No data provided to update communication plan"}
    data["service_name"] = "update_communication_plan"
    db_name=data.get("db_name", "")
    username = changed_data[0].get("username")
    modified_by=changed_data[0].get("modified_by", "")
    logging.info(f"### parent_provider_name : {parent_provider_name}")
    comm_plan_name = changed_data[0].get("Comm_plan_name", "")
    if not comm_plan_name:
        return {"flag": False, "message": "Communication plan name is required"}
    # Validate inventory data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    tenant_database = validate_response["tenant_database"]
    inventory_data = validate_response["inventory_data"]
    service_provider_data=validate_response["service_provider_data"]
    tenant_data = validate_response["tenant_data"]
    tenant_id = int(tenant_data["id"].iloc[0])
    service_provider_id=int(service_provider_data["id"].iloc[0])
    msisdns = inventory_data["msisdn"].tolist()
    iccids = inventory_data["iccid"].tolist()
    uploaded_len=len(iccids)
    data["change_event_type"]="Change Communication Plan"
    logging.info(f"### update_communication_plan Request Data Receivedupdated: {data}")
    
    change_event_type = data.get("change_event_type", "")
    
    # update action_history_logs
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### update_communication_plan Error updating action history: {e}")
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len)

        logging.info(f"### update_ppu_address bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        # Get device type from configuration - NO HARDCODED LISTS
        if parent_provider_name:
            service_provider=parent_provider_name
        device_type = config_manager.get_device_type(service_provider)
        device_list = iccids if device_type == "iccid" else msisdns
        
        if not device_list:
            return {"flag": False, "message": f"No {device_type.upper()}s provided for {service_provider}"}
        
        # validating the communication plan name
        comm_plan_id = None
        comm_plan_data = tenant_database.get_data(
            "sim_management_communication_plan",
            {"communication_plan_name": comm_plan_name,"service_provider_name": service_provider, "is_active": True},
            ["id"]   
        )
        if not comm_plan_data.empty:
            comm_plan_id = comm_plan_data["id"].iloc[0]
        else:
            return {"flag": False, "message": f"Invalid communication plan name: {comm_plan_name} for {service_provider}"}    
                
        change_request_payload= {"Comm_plan_name": comm_plan_name, "Comm_plan_id": int(comm_plan_id)}
        logging.info(f"### change_request_payload:{change_request_payload}")
        logging.info(f"### update_communication_plan changed_data1 : {changed_data}")
        bulk_change_request(
            tenant_name,
            modified_by,tenant_id,
            tenant_database,
            changed_data,
            bulkchange_id,
            inventory_data,change_request_payload
        )

        #bulk change lambda calling
        logging.info(f"### update_ppu_address msisdn_list : {msisdns}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config
        )      
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_communication_plan auditing failed: {exception}")
        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulkchange_id}"}
        
    except Exception as exception:
        logging.exception(f"### Error in update_communication_plan: {exception}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(exception)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(exception).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_communication_plan error auditing failed: {exception}")
        return {"flag": False, "message": "update communication plan update failed"}


#update feature change type
def update_features(data):
    """
    Updates mobility feature offering codes (add/remove) for multiple MSISDNs in 
    the inventory and synchronizes the changes with the carrier API.

    Args:
        data (dict): Request payload containing:
            - service_provider_display_name (str): Carrier/Service Provider name.
            - change_event_type (str): Type of change event (e.g., feature update).
            - changed_data (list[dict]): List of configuration change details,
              each containing `MobilityConfigurationIDsToAdd` and/or 
              `MobilityConfigurationIDsToRemove`.

    Returns:
        dict: Response with keys:
            - flag (bool): Indicates overall success or failure.
            - successful_ids (list[str]): List of MSISDNs successfully updated.
            - message (str, optional): Error message if operation failed.
    """
    
    logging.info(f"### update_features Request Data Received : {data}")

    # Input validation
    service_provider= data.get("service_provider_display_name", "")
    changed_data = data.get("changed_data", [])
    modified_by=changed_data[0].get("modified_by")
    tenant_name=data.get("tenant_name", "")
    username=data.get("username", "")
    access_token=data.get("access_token", "")
    db_name=data.get("db_name", "")
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    data["service_name"] = "update_features"

    
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    tenant_database = validate_response.get("tenant_database", {})
    tenant_data = validate_response.get("tenant_data", {})
    tenant_id=int(tenant_data["id"].iloc[0])
    common_utils_database = validate_response.get("common_utils_database", {})
    inventory_data = validate_response.get("inventory_data", {})
    service_provider_data = validate_response.get("service_provider_data", {})
    service_provider_id=int(service_provider_data["id"].iloc[0])
    data["change_event_type"]="Update Features"
    change_event_type = data.get("change_event_type", "")

    # update action_history_logs
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### update_features Error updating action history: {e}")
    
    msisdn_list = inventory_data["msisdn"].unique().tolist()
    iccids = inventory_data["iccid"].tolist()
    uploaded_len=len(iccids)
    add_codes, remove_codes, successful_ids = [], [], []

    
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len)

        logging.info(f"### update_features bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        add_codes, remove_codes = [], []
        

        # take the first record only
        first_record = changed_data[0]

        # extract config details
        config_details = first_record.get("configuration_change_details", {})
        logging.info(f"### config_details : {config_details}")

        # initialize add/remove codes
        add_codes = config_details.get("MobilityConfigurationIDsToAdd", [])
        remove_codes = config_details.get("MobilityConfigurationIDsToRemove", [])

        #change request paylaod
        change_request_payload={
            "serviceCharacteristic": [
                {
                "name": "addOfferingCode",
                "value": add_codes
                },
                {
                "name": "removeOfferingCode",
                "value": remove_codes
                }
            ]
        }
        bulk_change_request(
            tenant_name,
            modified_by,tenant_id,
            tenant_database,
            changed_data,
        
            bulkchange_id,
            inventory_data,change_request_payload
        )
                

        #bulk change lambda calling
        logging.info(f"### update_feature msisdn_list : {msisdn_list}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdn_list,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config
        )      
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_features auditing failed: {exception}")
 
        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulkchange_id}"}
        
        
    except Exception as exception:
        logging.exception(f"### Exception in update_features: {exception}")
        # Prepare error data for audit logging
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(exception)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(exception).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_features error auditing failed: {exception}")
        return {"flag": False, "message": "Error in update_features"}

# assign customer chnage type
def update_assign_customer(data):
    """
    Updates customer assignment for SIM/device inventory records. 
    This includes validating input data, updating customer details, 
    creating bulk change records, logging actions, and triggering 
    downstream bulk change processes.

    Args:
        data (dict): Input payload containing:
            - tenant_name (str): Tenant name (e.g., "Altaworx")
            - username (str): Name of the user performing the action
            - service_provider (str): Service provider display name
            - changed_data (list[dict]): List of records to update, with fields like:
                - customer_name (str): New customer name to assign
                - effective_date (str, optional): Effective date of the change
            - change_event_type (str): Type of change event (e.g., "Assign Customer")
            - Other metadata fields required for validation/logging

    Returns:
        dict: Response object with keys:
            - flag (bool): Indicates success or failure of the update
            - message (str): Human-readable status or error message
            - response_data (list, optional): Response from bulk change processing
    """
    logging.info(f"### update_assign_customer Request Data: {data}")
    data["service_name"] = "update_assign_customer"
    changed_data = data.get("changed_data", [])
    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}
    # validating changed data
    customer_name = changed_data[0].get("customer_name")
    # Split by " -- "
    parts = [p.strip() for p in customer_name.split("--")]
    # Remove empty strings
    non_empty = [p for p in parts if p]
    # Pick the first non-empty or ""
    customer_name = non_empty[0] if non_empty else ""
    if not customer_name:
        return {"flag": False, "message": "No customer name provided for update"}

    # Validate input data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
    # Extract validated data
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    tenant_data = validate_response["tenant_data"]
    service_provider_data = validate_response["service_provider_data"]
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    db_name = data.get("db_name")
    
    # tenant name mapping
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    change_event_type = data.get("change_event_type")
    tenant_id = tenant_data["id"].iloc[0]
    
    # Remove duplicate ICCIDs and MSISDNs
    inventory_data = inventory_data.drop_duplicates(subset=["iccid"])
    iccids = inventory_data["iccid"].tolist()
    msisdns = inventory_data["msisdn"].tolist()
    # Length of uploaded records for storing insim management bulk change chagne table 
    uploaded_len = len(iccids)
    billing_platform_flag = data.get('billing_platform_flag', False)
    role_name = data.get("role_name","")
    
    # Fetch role module data to determine if "Billing Customers" module is assigned
    role_module_data = common_utils_database.get_data(
        "role_module",
        {"role": role_name},
        ["sub_module"],
    )
    # Initialize default status
    module_status = False
    if not role_module_data.empty:
        try:
            # Parse JSON safely with fallback
            sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

            # Strict nested check
            if "People" in sub_modules:
                people_modules = sub_modules["People"]
                if isinstance(people_modules, list):  # Ensure it's a list
                    module_status = "Billing Customers" in people_modules
                    logging.info(f"### update_assign_customer Billing Customers module status: {module_status}")
        except Exception as e:
            logging.error(f"### update_assign_customer Unexpected error processing module_status: {str(e)}")

    # validating customer_name in revcustomer or customers table based on module status and billing_platform_flag
    rev_customer_id = None
    site_id = ""
    try:
        # Only revcustomer query
        if module_status and billing_platform_flag is False:
            rev_data = tenant_database.get_data(
                "revcustomer",
                {"customer_name": customer_name, "is_active": True,"tenant_id":int(tenant_id)},
                ["rev_customer_id"]
            )
            if not rev_data.empty:
                rev_customer_id = rev_data["rev_customer_id"].to_list()[0]
            else:
                rev_data = tenant_database.get_data(
                "customers",
                {"customer_name": customer_name, "is_active": True ,"tenant_id":int(tenant_id)},
                ["id"]) 
                if not rev_data.empty:
                    rev_customer_id = rev_data["id"].to_list()[0]
                    site_id = rev_customer_id
                else:
                    return {"flag": False, "message": "Customer not found"} 
            logging.info(f"### update_assign_customer rev_customer_id :  {rev_customer_id} ")
        # First revcustomer query, if not found then customers query    
        elif module_status and billing_platform_flag:
            rev_data = tenant_database.get_data(
                "revcustomer",
                {"customer_name": customer_name, "is_active": True ,"tenant_id":int(tenant_id)},
                ["rev_customer_id"]
            )
            if not rev_data.empty:
                rev_customer_id = rev_data["rev_customer_id"].to_list()[0]
            else: 
                rev_data = tenant_database.get_data(
                "customers",
                {"customer_name": customer_name, "is_active": True ,"tenant_id":int(tenant_id)},
                ["id"]) 
                if not rev_data.empty:
                    rev_customer_id = rev_data["id"].to_list()[0]
                    site_id = rev_customer_id
                else:
                    return {"flag": False, "message": "Customer not found"} 
            logging.info(f"### update_assign_customer rev_customer_id :  {rev_customer_id} ")  
        # Only customers query       
        else:
            rev_data = tenant_database.get_data(
                "customers",
                {"customer_name": customer_name, "is_active": True ,"tenant_id":int(tenant_id)},
                ["id"]) 
            if not rev_data.empty:
                rev_customer_id = rev_data["id"].to_list()[0]
                site_id = rev_customer_id
            else:
                return {"flag": False, "message": "Customer not found"}  
            logging.info(f"### update_assign_customer rev_customer_id :  {rev_customer_id} ")
        data["SiteId"] = site_id
        # Update action history logs
        try:
            threading.Thread(target=update_action_history_logs, args=(
                tenant_name, db_name, inventory_data, change_event_type, username
            ), daemon=True).start()
        except Exception as e:
            logging.error(f"### update_assign_customer Error updating action history: {e}")
            
        # Create bulk change record
        service_provider_id = service_provider_data["id"].iloc[0] if isinstance(service_provider_data["id"], pd.Series) else service_provider_data["id"]
        bulkchange_id, change_type_id = create_bulk_change_record(
            data, service_provider_id, tenant_id, tenant_database, change_event_type, uploaded_len
        )
        logging.info(f"### update_assign_customer bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")

        # Insert bulk change requests
        response_data = bulk_change_request_assign_customer(
            data,tenant_name,tenant_database,tenant_data,changed_data,bulkchange_id,inventory_data,common_utils_database,rev_customer_id
        )
        logging.info(f"### update_assign_customer response_data : {response_data} ")

        # Call bulkchange_lambda_caller to invoke the bulk change processor 
        bulkchange_lambda_caller_response = bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config
        )
        logging.info(f"### update_assign_customer bulkchange_lambda_caller response : {bulkchange_lambda_caller_response} ")

        # Insert audit logs
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_assign_customer auditing failed and error :  {exception}")    
        logging.info(f"### update_assign_customer insert_audit_logs completed")
        return {"flag": True, "message": "Data Updated Successfully", "response_data":response_data }

    except Exception as e:
        logging.exception(f"### update_assign_customer Error: {e}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_assign_customer error case auditing failed and error :  {exception}")    
        return {"flag": False, "message": "Error updating customer assignment"}
    
    
# prepare change request for assign customer    
def bulk_change_request_assign_customer(data,
    tenant_name,
    tenant_database,
    tenant_data,
    changed_data,
    bulkchange_id,
    inventory_data,
    common_utils_database,
    rev_customer_id
):
    """
    Creates and inserts bulk change request rows for assigning a customer to sim management bulkchange request table.

    This function:
        - Uses the first record from `changed_data` to build common values (customer, rate plans, etc.)
        - Looks up customer rate plan and rate pool IDs
        - Maps ICCIDs to inventory details for accurate request payloads
        - Builds one bulk change request row per ICCID/MSISDN pair
        - Inserts all rows into the `sim_management_bulk_change_request` table in parallel

    Args:
        tenant_name (str): Name of the tenant (e.g., "Altaworx").
        iccids (list[str]): List of ICCIDs to process.
        msisdns (list[str]): List of MSISDNs corresponding to the ICCIDs.
        service_provider_data (DataFrame|dict): Service provider details (must include `id`).
        tenant_database (DB): Database connection object for the tenant schema.
        tenant_data (DataFrame|dict): Tenant details (must include `id`).
        changed_data (list[dict]): List of request records, only the first one is used for bulk fields.
        bulkchange_id (int|str): Unique ID of the parent bulk change operation.
        inventory_data (DataFrame): Inventory records used for device_id and customer_id lookups.

    Returns:
        dict: Response object containing:
            - flag (bool): Success indicator
            - message (str): Status message
            - bulkchange_id (int|str): ID of the bulk change created
    """
    # extracting the input data
    logging.info(f"### bulk_change_request_assign_customer Request Data: {data}")
    provider_id = data.get("ProviderId","")
    rev_product_id = data.get("RevProductId",[])
    rev_package = data.get("RevPackageId", "")
    rev_package_id = rev_package.get("value", "") if isinstance(rev_package, dict) else ""
    rate_list = data.get("RateList",[])
    usage_plan_group_id = data.get("UsagePlanGroupId",None)
    description = data.get("Description","")
    create_rev_service_flag = data.get("createRevService",False)
    site_id = data.get("SiteId","")
    # Take the first record only
    first_record = changed_data[0]
    modified_by = first_record.get("modified_by")
    effective_date = first_record.get("effective_date","")
    service_type_id = first_record.get("service_type_id")
    customer_rate_plan_name = first_record.get("customer_rate_plan_name","")
    customer_rate_pool_name = first_record.get("customer_rate_pool_name","")

    # Fetch IDs from database
    customer_rate_plan_id = None
    customer_rate_pool_id = None
    # validating customer rate plan 

    if customer_rate_plan_name:
        rate_plan_data = tenant_database.get_data(
            "customerrateplan",
            {"rate_plan_name": customer_rate_plan_name, "is_active": True},
            ["id"]
        )
        if not rate_plan_data.empty:
            customer_rate_plan_id = rate_plan_data["id"].to_list()[0]
    # validating customer rate pool
    if customer_rate_pool_name:
        rate_pool_data = tenant_database.get_data(
            "customer_rate_pool",
            {"name": customer_rate_pool_name, "is_active": True},
            ["id"]
        )
        if not rate_pool_data.empty:
            customer_rate_pool_id = rate_pool_data["id"].to_list()[0]        

    # Tenant and Service Provider IDs
    tenant_id = tenant_data["id"].iloc[0] if isinstance(tenant_data["id"], pd.Series) else tenant_data["id"]

    # Build inventory lookup
    inventory_lookup = {
        rec["iccid"]: rec
        for rec in inventory_data.to_dict(orient="records")
        if rec.get("iccid")
    }
    logging.info(f"### bulk_change_request_assign_customer inventory_lookup : {inventory_lookup}")
    tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name},
            ["id","parent_tenant_id"]
            )
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    integration_authentication_json_data = load_integration_authentication_json()
    integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
    if not integration_authentication_id and parent_tenant_id:
        if parent_tenant_id:
            parent_tenant_id=int(parent_tenant_id)
            parent_tenant_data = common_utils_database.get_data(
            "tenant", {"id": parent_tenant_id},
            ["tenant_name"]
            )
            parent_tenant_name = parent_tenant_data["tenant_name"].to_list()[0]
            integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)
    else:
        integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, 'Altaworx')

    logging.info(f"integration_authentication_id : {integration_authentication_id}")

    # Build one row per ICCID
    def build_request_row(iccid):
        logging.info(f"### bulk_change_request_assign_customer build_request_row iccid : {iccid}")
        record = inventory_lookup.get(iccid, {})
        if not isinstance(record, dict):
            record = {}
        # taking the integration_authentication_id 
        # Build change_request payload using first_record values
        change_request = {
            "Number": record.get("msisdn", "") ,
            "ICCID": record.get("iccid", ""),
            "IntegrationAuthenticationId":integration_authentication_id,
            "CreateRevService": create_rev_service_flag,
            "AddCarrierRatePlan": False,
            "CarrierRatePlan": None,
            "CommPlan": "",
            "UseAgentAccount": False,
            "JasperDeviceID": "",
            "SiteId":site_id,
            "AddCustomerRatePlan": False,
            "CustomerRatePlan": str(customer_rate_plan_id) if customer_rate_plan_id else None,
            "CustomerRatePool": str(customer_rate_pool_id or ""),
            "DeviceId": record.get("mobility_device_id") or record.get("device_id") or "",
            "RevCustomerId": str(rev_customer_id) if rev_customer_id else "",
            "ProviderId": provider_id,
            "ServiceTypeId": str(service_type_id or ""),
            "RevPackageId": rev_package_id,
            "RateList": rate_list,
            "Prorate": False,
            "useCarrierActivation": False,
            "Description": description,
            "EffectiveDate": f"{effective_date}" if effective_date else "",
            "ActivatedDate":None,
            "UsagePlanGroupId": usage_plan_group_id,
            "RevProductIdList": rev_product_id,
        }
        return {
            "iccid": iccid,
            "subscriber_number":  record.get("msisdn", ""),
            "bulk_change_id": str(bulkchange_id),
            "tenant_name": tenant_name,
            "created_by": modified_by,
            "processed_by": modified_by,
            "status": "NEW",
            "tenant_id": int(tenant_id),
            "device_id": record.get("device_id") or record.get("mobility_device_id"),
            "is_active": True,
            "is_deleted": False,
            "change_request": json.dumps(change_request),
        }
        
    # Build rows in parallel (subscriber_number/MSISDN optional)
    device_pairs = inventory_data[["iccid", "msisdn"]].dropna(subset=["iccid"]).to_dict(orient="records")
    parallel_requests = min(10, len(device_pairs))
    with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
        futures = [executor.submit(build_request_row, rec["iccid"]) for rec in device_pairs]
        create_new_bulk_change_request_dict = [future.result() for future in futures]
        logging.info(f"### bulk_change_request_assign_customer create_new_bulk_change_request_dict : {create_new_bulk_change_request_dict}")

    # Insert into database
    request_id = tenant_database.insert_data(
        create_new_bulk_change_request_dict,
        "sim_management_bulk_change_request",
    )
    logging.info(f"### bulk_change_request_assign_customer Request Data: {request_id}")
    response = {
        "flag": True,
        "message": "Successful Assign Customer Requests Inserted",
        "bulkchange_id": bulkchange_id,
    }
    return response

    
# device history updating
def insert_device_history_records(tenant_name, username, iccids, service_provider, db_name,msisdns,effective_date=None,access_token = None):
    """
    Invokes Lambda function to update device history tables.
    
    Args:
        tenant_name (str): Name of the tenant
        username (str): Username performing the operation
        iccids (list): List of ICCID values to update
        service_provider (str): Service provider name
        db_name (str): Database name
    
    Returns:
        dict: False response if Lambda invocation fails, True otherwise
    """
    try:
        logging.info(f"### Invoking insert_device_history_records Lambda iccids : {iccids} , msisdns : {msisdns}, effective_date : {effective_date}")
        env = os.environ.get("ENV", "BETA").upper()
        lambda_name = "module_management_beta" if env == "BETA" else "module_management"
        lambda_payload = {
            "data": {
                "data": {
                    "tenant_name": tenant_name,
                    "username": username,
                    "path": "/update_device_history_tables",
                    "iccids": iccids,
                    "service_provider":service_provider,
                    "db_name": db_name,
                    "msisdns":msisdns,
                    "effective_date":effective_date,
                    "access_token":access_token
                }
            }
        }
        lambda_client = boto3.client('lambda')
        invoke_response = lambda_client.invoke(
            FunctionName = lambda_name,
            InvocationType = 'Event',
            Payload = json.dumps(lambda_payload),
        )
        logging.info(f"### insert_device_history_records Lambda invoked :{invoke_response}")
        return True
    except Exception as exception:
        logging.exception(f"### Error during insert_device_history_records: {exception}")
        return False

# line sync change type
def inventory_line_sync_update(data):
    """
    Perform an individual line synchronization between the local inventory and the carrier API.

    This function validates the incoming request payload, fetches the latest line details 
    (by ICCID or MSISDN) from the configured carrier API, and updates the local 
    `sim_management_inventory` table with the latest information if available.

    Args:
        data (dict): Input request containing:
            - service_provider_display_name (str): Name of the carrier/service provider.
            - other fields required by `validate_inventory_data`.

    Returns:
        dict: Response object with the following keys:
            - flag (bool): Indicates success (True) or failure (False).
            - message (str): Human-readable status message.

    """
    try:
        logging.info(f"### inventory_line_sync_update Request Data: {data}")
        change_event_type = data["change_event_type"]
        data['service_name'] = 'inventory_line_sync_update'
        tenant_name=data.get("tenant_name", "")
        username=data.get("username", "")
        db_name=data.get("db_name", "")

        changed_data = data.get("changed_data", [])
        first_record = changed_data[0] if changed_data else {}
        modified_by = first_record.get("modified_by")  # fallback to username

        # Validate input data
        try:
            validate_response = validate_inventory_data(data)
        except Exception as e:
            logging.exception(f"### inventory_line_sync_update Error during validate_inventory_data : {e}")
            return {"flag": False, "message": "Validation failed"}

        if not validate_response["flag"]:
            return validate_response

        # Extract validated data
        tenant_database = validate_response["tenant_database"]
        common_utils_database = validate_response["common_utils_database"]
        inventory_data = validate_response["inventory_data"]
        tenant_data = validate_response["tenant_data"]
        service_provider_data = validate_response["service_provider_data"]
        tenant_id = int(tenant_data["id"].iloc[0])
        # Prepare device lists for carrier API
        iccids = inventory_data["iccid"].tolist()
        msisdns = inventory_data["msisdn"].tolist()
        uploaded_len = len(iccids)
        # Create bulk change record
        service_provider_id = service_provider_data["id"].iloc[0] if isinstance(service_provider_data["id"], pd.Series) else service_provider_data["id"]

        # update action_history_logs
        try:
            threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
        except Exception as e:
            logging.error(f"### inventory_line_sync_update Error updating action history: {e}")
        # Create bulk change record
        bulkchange_id, change_type_id = create_bulk_change_record(
            data, service_provider_id, tenant_id,tenant_database , change_event_type, uploaded_len
        )
        logging.info(f"### inventory_line_sync_update : bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")

        # Build a minimal change_request_payload (you can customize as needed)
        change_request_payload = None  
        # Call bulk_change_request to create bulk change request rows
        response_data = bulk_change_request(
            tenant_name,
            modified_by,
            tenant_id,
            tenant_database,
            changed_data,
            bulkchange_id,
            inventory_data,
            change_request_payload
        )
        logging.info(f"### inventory_line_sync_update response_data : {response_data} ")

        # Call bulkchange_lambda_caller to invoke the bulk change processor
        bulkchange_lambda_caller_response = bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config
        )
        logging.info(f"### inventory_line_sync_update bulkchange_lambda_caller response : {bulkchange_lambda_caller_response}")

        # Insert audit logs
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### inventory_line_sync_update auditing failed: {exception}")
        logging.info(f"### inventory_line_sync_update auditing is completed")
        return {"flag": True, "message": "Data Updated Successfully", "response_data":response_data }

    except Exception as e:
        logging.exception(f"### inventory_line_sync_update Error: {e}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### inventory_line_sync_update error case auditing failed: {exception}")
        return {"flag": False, "message": "Error updating line sync change type"}


def build_detailed_update_dict(api_record, inventory_row, keys_to_check):
    """
    Build update dictionary with detailed field-level change tracking.
    
    Args:
        api_record (dict): Data from carrier API
        inventory_row (pd.Series): Current inventory data
        keys_to_check (list): Fields to compare
    
    Returns:
        tuple: (to_update_dict, field_changes_list)
    """
    to_update = {}
    field_changes = []
    
    for key in keys_to_check:
        api_value = api_record.get(key)

        # Skip if API value is None or NaN
        if api_value is None or (isinstance(api_value, float) and pd.isna(api_value)):
            continue  

        # SPECIFIC FIX FOR DATE FIELDS
        if key in ['effective_date', 'activation_date', 'expiry_date'] and api_value == '':
            # Convert empty string to None for date fields
            api_value = None

        current_value = inventory_row.get(key)

        # Handle None/NaN for current value
        if pd.isna(current_value) or current_value is None:
            current_value = ""
        
        # Convert to string for safe comparison
        str_current = str(current_value).strip()
        str_api = str(api_value).strip() if api_value is not None else "None"
        
        if str_current != str_api:
            to_update[key] = api_value
            field_changes.append({
                'field': key,
                'previous_value': str_current,
                'current_value': str_api
            })
            logging.info(f"### Field changed: {key}, From: '{str_current}', To: '{str_api}'")
    
    return to_update, field_changes
# store action history table
def update_action_history_logs(tenant_name, db_name, inventory_data, change_event_type, username):
    """
    Updates action history logs with inventory changes and tracks audit information.
    
    Args:
        tenant_name (str): Name of the tenant
        tenant_database: Database connection for tenant-specific operations
        common_utils_database: Database connection for common utilities
        inventory_data (pd.DataFrame): Inventory data to log
        change_event_type (str): Type of change event performed
        username (str): Username of the user performing the action
    
    Returns:
        bool: True if successful, False otherwise
    """
    #db conncetion for tenant with safe 
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    database = DB(db_name, **db_config_withoutfilter)
    start_time = time.time()
    logging.info(f"### update_action_history_logs Request Data: {tenant_name}, {change_event_type}, {username},{inventory_data}")
    try:
        action_history_records = [
                {
                    "tenant_id": row["tenant_id"],
                    "iccid": row["iccid"],
                    "msisdn": row["msisdn"],
                    "imei": row["imei"],
                    "sim_status": row["sim_status"],
                    "action_performed": change_event_type,
                    "date_activated": row["date_activated"],
                    "last_activated_date": row["last_activated_date"],
                    "carrier_cycle_usage_bytes": row["carrier_cycle_usage_bytes"],
                    "customer_rate_plan_name": row["customer_rate_plan_name"],
                    "billing_cycle_end_date": row["billing_cycle_end_date"],
                    "modified_by": username,
                    "action_type": "Update Inventory"
                }
                for row in inventory_data.to_dict(orient="records")
            ]
        logging.info(f"### update_action_history_logs action_history_records : {action_history_records}")
        
        # Insert into logs
        insert_id = database.insert_data(action_history_records, "action_history_logs")
        #logging.info(f"### update_action_history_logs Successfully inserted action history logs for ICCID: {iccid} and MSISDN: {msisdn}")

        logging.info(f"### update_action_history_logs Inserted {insert_id} action_history_logs")
        logging.info(f"### update_action_history_logs Updated {len(action_history_records)} action_history_logs")
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "update_action_history_logs",
                "created_by": username,
                "status": "True",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "comments": f"update action history logs for change type {change_event_type}",
                "module_name": "Sim Management",
                "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### update_action_history_logs audit_user_actions Exception is {e}")
        return True
    except Exception as e:
        logging.exception(f"### update_action_history_logs Unexpected error : {e}")
        try:
            error_data = {
                "service_name": "update_action_history_logs",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"update_action_history_logs failed for chnage type {change_event_type}",
                "module_name": "Sim management",
                "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### update_action_history_logs error_log_table exception : {e}")
        return False


def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        # Handle pd.Timestamp and NaT
        return data.strftime("%m-%d-%Y %I:%M:%S %p") if pd.notna(data) else None
    elif data is pd.NaT:  # Directly check for pd.NaT
        return None
    elif isinstance(data, np.datetime64):  # Handle numpy datetime64
        return str(data) if pd.notna(data) else None
    elif pd.api.types.is_integer(data):  # Check explicitly for integers
        return int(data)
    elif pd.api.types.is_float(data):  # Check explicitly for floats
        return float(data)
    elif pd.isna(data):  # Handle NaN or missing values
        return None
    else:
        return data  # Return as is for other types
    

def edit_cost_center_20(data):
    """
    This function is a wrapper for the README-documented endpoint `edit_cost_center_20`. 
    It updates cost center for a given device (Iccids/Msisdns) in tenant inventory.

    Args:
        data (dict): Input payload with fields:
            - tenant_name (str): Tenant name (e.g., "Altaworx")
            - service_provider (str): Service provider display name
            - changed_data (dict): Dictionary containing {"cost_center": str}
            - iccid (str, optional): ICCID of the device
            - msisdn (str, optional): MSISDN of the device
            - db_name (str): Tenant database name
            - username (str, optional): User performing the operation

    Returns:
        dict: Result object with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - updated_ids (list, optional): IDs of updated records
    """
    try:
        # Extract inputs safely
        logging.info(f"### edit_cost_center_20 data received : {data}")
        service_provider = data.get("service_provider", "")
        if not service_provider : 
            return {"flag":False , "message":"service provider is not provided"}
        cost_center = data.get("changed_data", {}).get("cost_center")
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        db_name = data.get("db_name", "")


        # Add metadata for auditing
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Edit Cost Center"
        # data["request_received_at"] = datetime.now()
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
         # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}
        data["username"] = username =  client_id 

        service_data = common_utils_database.get_data(
            "service_accounts",
            {"client_id": client_id, "is_active": "True"}  
        )

        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        data["tenant_name"] =   tenant_name

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"  

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}
        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"### edit_cost_center_20 tenant_id : {tenant_id} and db_name : {db_name}")  
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Build filter condition for inventory
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Prepare changed_data (without explicit for-loop)
        changed_data = (
            inventory_df[["id"]]
            .assign(cost_center=cost_center, modified_by=username)
            .to_dict(orient="records")
        )
        logging.info(f"### edit_cost_center_20 changed_data : {changed_data}")

        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### edit_cost_center_20 data : {data}")

        # Call update function
        return update_edit_cost_center(data)

    except Exception as exception:
        logging.exception(f"### edit_cost_center_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating cost center."}   

def change_customer_rate_plan_20(data):
    """
    Update customer rate plan for a given device (ICCIDs/MSISDNs) in tenant inventory.

    Args:
        data (dict): Input payload with fields:
            - tenant_name (str): Tenant name (e.g., "Altaworx")
            - service_provider (str): Service provider display name
            - changed_data (dict): Dictionary containing new customer rate plan details
            - iccids (list, optional): List of ICCIDs
            - msisdns (list, optional): List of MSISDNs
            - db_name (str): Tenant database name
            - username (str, optional): User performing the operation
            - z_access_token (str, optional): Access token for service account validation
            - client_id (str, optional): Client ID (required if z_access_token is provided)

    Returns:
        dict: Result object with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - updated_ids (list, optional): IDs of updated records
    """
    try:
        logging.info(f"### change_customer_rate_plan_20 data received : {data}")
        # Extract inputs safely
        service_provider = data.get("service_provider", "")
        if not service_provider : 
            return {"flag":False , "message":"service provider is not provided"}
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        db_name = data.get("db_name", "")

        # Extract fields from changed_data
        changed_input = data.get("changed_data", [])
        customer_rate_plan_name = changed_input.get("customer_rate_plan_name","")
        if not customer_rate_plan_name : 
            return {"flag": False , "message":"customer rate plan is not provided"}
        customer_rate_pool_name = changed_input.get("customer_rate_pool_name","")
        sub_tenant_carrier_rate_plan_name = customer_rate_plan_name
        

        # Add metadata for auditing
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Change Customer Rate Plan"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        # If z_access_token is provided → validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}
        data["username"] = username =  client_id 

        service_data = common_utils_database.get_data(
            "service_accounts",
            {"client_id": client_id, "is_active": "True"}  
        )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        data["tenant_name"] = tenant_name

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Build filter condition for inventory
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Prepare changed_data (vectorized, no manual loop)
        changed_data = (
            inventory_df[["id"]]
            .assign(
                customer_rate_plan_name=customer_rate_plan_name,
                customer_rate_pool_name=customer_rate_pool_name,
                sub_tenant_carrier_rate_plan_name=sub_tenant_carrier_rate_plan_name,
                modified_by=username,
            )
            .to_dict(orient="records")
        )
        logging.info(f"### change_customer_rate_plan_20 changed_data : {changed_data}")

        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### change_customer_rate_plan_20 data : {data}")

        # Call update function
        return update_customer_rate_plan(data)

    except Exception as exception:
        logging.exception(f"### change_customer_rate_plan_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating customer rate plan."}

def update_device_status_20(data):
    """
    Update SIM/device status in tenant inventory.

    Args:
        data (dict): Input payload with fields:
            - tenant_name (str): Tenant name (e.g., "Altaworx")
            - service_provider (str): Service provider display name
            - changed_data (dict): Dictionary containing new status details
            - iccids (list, optional): List of ICCIDs
            - msisdns (list, optional): List of MSISDNs
            - db_name (str): Tenant database name
            - username (str, optional): User performing the operation
            - z_access_token (str, optional): Access token for service account validation
            - client_id (str, optional): Client ID (required if z_access_token is provided)

    Returns:
        dict: Result object with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - updated_ids (list, optional): IDs of updated records
    """
    try:
        logging.info(f"### update_device_status_20 data received : {data}")

        # Extract inputs
        tenant_name = data.get("tenant_name", "")
        service_provider = data.get("service_provider", "")
        username = data.get("username", "")
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        z_access_token = data.get("z_access_token")
        db_name = data.get("db_name")

        # Extract fields from changed_data
        changed_input = data.get("changed_data", {})
        sim_status = changed_input.get("sim_status") 
        public_ip_restriction = changed_input.get("public_ip_restriction", "")
        reason_code = changed_input.get("reason_code", "")
        imei = changed_input.get("imei", "")
        telegence_additional_details = changed_input.get("telegence_additional_details", "")

        # Add metadata for auditing
        data["table_name"] = "sim_management_inventory"
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Update Status"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        data["template_name"] = "Inventory Status Update"

        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        # validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}

        service_data = common_utils_database.get_data(
        "service_accounts",
        {"client_id": client_id, "is_active": "True"}  
            )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        data["role_name"] =role_name
        logging.info(f"### update_device_status_20 role_name - {role_name}")

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
        data["tenant_name"] = tenant_name

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"tenant_id : {tenant_id} and db_name : {db_name}")

        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)
        
        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Build filter condition
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id", "iccid", "msisdn"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Fetch integration_id for service provider
        integration_id = tenant_database.get_data(
            "serviceprovider",
            {"service_provider_name": service_provider},
            ["integration_id"]
        )["integration_id"].to_list()[0]

        #  Fetch allowed status list for this carrier
        allowed_status_list = tenant_database.get_data(
            "device_status",
            {
                "is_deleted": False,
                "is_active": True,
                "allows_api_update": True,
                "integration_id": integration_id,
            },
            ["id", "status", "description", "display_name"]
        )
        status_lower = sim_status.lower()
        allowed_status_list = allowed_status_list[
            (allowed_status_list["status"].str.lower() == status_lower) |
            (allowed_status_list["description"].str.lower() == status_lower) |
            (allowed_status_list["display_name"].str.lower() == status_lower)
        ]
        logging.info(f"### allowed status list is {allowed_status_list}")

        if allowed_status_list.empty:
            return {"flag": False, "message": "No allowed statuses found for this carrier."}

        # Take first matching device_status_id
        device_status_id = allowed_status_list["id"].to_list()[0]
        data["device_status_id"] = device_status_id

        # Validate requested status if z_access_token provided
        if z_access_token:
            original_allowed_status_list = [str(s) for s in allowed_status_list["status"].to_list()]
            if sim_status not in original_allowed_status_list:
                return {
                    "flag": False,
                    "message": f"Status '{sim_status}' is not allowed. The allowed status list for the carrier is {original_allowed_status_list}"
                }

        # Prepare changed_data
        changed_data = (
            inventory_df[["id", "iccid"]]
            .assign(
                sim_status=sim_status,
                device_status_id=device_status_id,
                modified_by=username,
                public_ip_restriction=public_ip_restriction,
                reason_code=reason_code,
                imei=imei,
                telegence_additional_details=telegence_additional_details
            )
            .to_dict(orient="records")
        )
        logging.info(f"### changed_data : {changed_data}")

        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### data : {data}")

        # Call update function
        return update_device_status(data)

    except Exception as exception:
        logging.exception(f"### update_device_status_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating SIM/device status."}

def change_carrier_rate_plan_20(data):
    """
    Update carrier rate plan for a given device (ICCIDs/MSISDNs) in tenant inventory.

    Args:
        data (dict): Input payload with fields:
            - tenant_name (str): Tenant name (e.g., "Altaworx")
            - service_provider (str): Service provider display name
            - changed_data (dict): Dictionary containing new carrier rate plan details
            - iccids (list, optional): List of ICCIDs
            - msisdns (list, optional): List of MSISDNs
            - db_name (str): Tenant database name
            - username (str, optional): User performing the operation
            - z_access_token (str, optional): Access token for service account validation
            - client_id (str, optional): Client ID (required if z_access_token is provided)

    Returns:
        dict: Result object with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - updated_ids (list, optional): IDs of updated records
    """
    try:
        logging.info(f"### change_carrier_rate_plan_20 data received : {data}")

        # Extract inputs safely
        service_provider = data.get("service_provider", "")
        if not service_provider : 
            return {"flag":False , "message":"service provider is not provided"}
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        db_name = data.get("db_name")

        # Extract fields from changed_data
        changed_input = data.get("changed_data", {})
        carrier_rate_plan_name = changed_input.get("carrier_rate_plan_name")
        if not carrier_rate_plan_name : 
            return {"flag":False , "message":"carrier rate plan is not provided"}
        communication_plan = changed_input.get("communication_plan","")

        # Add metadata for auditing
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Update Carrier Rate Plan"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        # validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}
        data["username"] = username =  client_id

        service_data = common_utils_database.get_data(
            "service_accounts",
            {"client_id": client_id, "is_active": "True"}  
        )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        data["tenant_name"] = tenant_name

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"### change_carrier_rate_plan_20 tenant_id : {tenant_id} and db_name : {db_name}")
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Build filter condition for inventory
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Prepare changed_data (vectorized, no manual loop)
        changed_data = (
            inventory_df[["id"]]
            .assign(
                carrier_rate_plan_name=carrier_rate_plan_name,
                communication_plan=communication_plan,
                modified_by=username,
            )
            .to_dict(orient="records")
        )
        logging.info(f"### change_carrier_rate_plan_20 changed_data : {changed_data}")

        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### change_carrier_rate_plan_20 data : {data}")

        # Call update function
        return update_carrier_rate_plan(data)

    except Exception as exception:
        logging.exception(f"### change_carrier_rate_plan_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating carrier rate plan."} 


def inventory_line_sync_update_20(data):
    """
    Perform an inventory Line Sync update for given devices (ICCIDs/MSISDNs).

    Args:
        data (dict): Input payload with fields:
            - tenant_name (str): Tenant name
            - service_provider (str): Service provider display name
            - changed_data (dict): Dictionary with line sync fields
            - iccids (list, optional): List of ICCIDs
            - msisdns (list, optional): List of MSISDNs
            - db_name (str): Tenant database name
            - username (str, optional): User performing the operation
            - z_access_token (str, optional): Access token for service account validation
            - client_id (str, optional): Client ID (required if z_access_token is provided)

    Returns:
        dict: Result object with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - updated_ids (list, optional): IDs of updated records
    """
    try:
        logging.info(f"### inventory_line_sync_update_20 data received : {data}")

        # Extract inputs safely
        tenant_name = data.get("tenant_name", "")
        service_provider = data.get("service_provider", "")
        username = data.get("username", "")
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        z_access_token = data.get("z_access_token")
        db_name = data.get("db_name")

        # Extract fields from changed_data

        # Add metadata for auditing
        data["table_name"] = "sim_management_inventory"
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Line Sync"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        # If z_access_token is provided → validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}

        service_data = common_utils_database.get_data(
        "service_accounts",
        {"client_id": client_id, "is_active": "True"}  
        )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        logging.info(f"### inventory_line_sync_update_20 update_line_sync role_name - {role_name}")
        data["tenant_name"] = tenant_name

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"### inventory_line_sync_update_20 tenant_id : {tenant_id} and db_name : {db_name}")
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Build filter condition for inventory
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id", "iccid", "msisdn"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Prepare changed_data (merge original with inventory IDs)
        changed_data = (
            inventory_df[["id"]]
            .assign(modified_by=username)
            .to_dict(orient="records")
        )
        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### inventory_line_sync_update_20 update_line_sync data : {data}")

        # Call update function
        return inventory_line_sync_update(data)

    except Exception as exception:
        logging.exception(f"### inventory_line_sync_update_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating line sync."}

def update_feature_codes_20(data):
    """
    Update feature codes for a given device (ICCIDs/MSISDNs) in tenant inventory.

    Args:
        data (dict): Input payload with fields:
            - tenant_name (str): Tenant name (e.g., "Altaworx")
            - service_provider (str): Service provider display name
            - configuration_change_details (dict): Dict containing effective_date, telegence_features, and mobility configs
            - iccids (list, optional): List of ICCIDs
            - msisdns (list, optional): List of MSISDNs
            - db_name (str): Tenant database name
            - username (str, optional): User performing the operation
            - z_access_token (str, optional): Access token for service account validation
            - client_id (str, optional): Client ID (required if z_access_token is provided)

    Returns:
        dict: Result object from update_features()
    """
    try:
        logging.info(f"### update_feature_codes_20 data received : {data}")

        # Extract inputs safely
        tenant_name = data.get("tenant_name", "")
        service_provider = data.get("service_provider", "")
        username = data.get("username", "")
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        z_access_token = data.get("z_access_token")
        db_name = data.get("db_name")

        # Extract fields from configuration_change_details
        config_details = data.get("configuration_change_details", {}) or {}
        effective_date = config_details.get("effective_date","")

        mobility_ids_to_add = config_details.get("MobilityConfigurationIDsToAdd", [])
        mobility_ids_to_remove = config_details.get("MobilityConfigurationIDsToRemove", [])


        #  Ensure proper final structure
        configuration_change_details = {
            "MobilityConfigurationIDsToAdd": mobility_ids_to_add,
            "MobilityConfigurationIDsToRemove": mobility_ids_to_remove,
            "MobilityConfigurationsCurrent": mobility_ids_to_add
        }
        # telegence_features = str(mobility_ids_to_add)
        if  mobility_ids_to_add:
            telegence_features = ",".join(mobility_ids_to_add)
        elif mobility_ids_to_remove:
            telegence_features = ",".join(mobility_ids_to_remove)
        else:
            return {"flag": False, "message": "Either MobilityConfigurationIDsToAdd or MobilityConfigurationIDsToRemove is required."}         


        logging.info(f"### update_feature_codes_20 configuration_change_details : {configuration_change_details}")
        logging.info(f"### update_feature_codes_20 mobility_ids_to_add : {mobility_ids_to_add}")
        logging.info(f"### update_feature_codes_20 mobility_ids_to_remove : {mobility_ids_to_remove}")


        # Add metadata for auditing
        data["table_name"] = "sim_management_inventory"
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Update feature"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        # validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}

        service_data = common_utils_database.get_data(
        "service_accounts",
        {"client_id": client_id, "is_active": "True"}  
        )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        data["tenant_name"] = tenant_name
        role_name = service_data["role"].to_list()[0]
        logging.info(f"### update_feature_codes_20 role_name - {role_name}")

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"### update_feature_codes_20 tenant_id : {tenant_id} and db_name : {db_name}")
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Build filter condition for inventory
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id", "iccid", "msisdn"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Prepare changed_data (vectorized, no manual loop)
        changed_data = [
            {
                "id": int(row["id"]),
                "telegence_features": telegence_features,
                "modified_by": username,
                "configuration_change_details": {
                    "MobilityConfigurationIDsToAdd": config_details.get("MobilityConfigurationIDsToAdd", []),
                    "MobilityConfigurationIDsToRemove": config_details.get("MobilityConfigurationIDsToRemove", []),
                    "MobilityConfigurationsCurrent": telegence_features ,  
                },
                "mobility_configuration_ids": row.get("mobility_configuration_ids", []), 
            }
            for _, row in inventory_df.iterrows()
        ]

        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### update_feature_codes_20 data : {data}")

        # Call update function
        return update_features(data)

    except Exception as exception:
        logging.exception(f"### update_feature_codes_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating feature codes."}


def assign_customer_20(data):
    """
    Prepares payload for assigning customer to inventory records.
    Validates tenant and inventory, then calls update_assign_customer.
    """
    try:
        logging.info(f"### assign_customer_20 data received : {data}")
        # Extract inputs safely
        tenant_name = data.get("tenant_name", "")
        service_provider = data.get("service_provider", "")
        username = data.get("username", "")
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        z_access_token = data.get("z_access_token")
        # Extract fields from changed_data
        changed_input = data.get("changed_data", [])
        db_name = data.get("db_name")

        effective_date = changed_input.get("effective_date")
        customer_name = changed_input.get("customer_name")
        customer_rate_plan_name = changed_input.get("customer_rate_plan_name")
        customer_rate_pool_name = changed_input.get("customer_rate_pool_name","")
        sub_tenant_carrier_rate_plan_name = changed_input.get(
            "customer_rate_plan_name"
        )
        # Add metadata for auditing
        data["table_name"] = "sim_management_inventory"
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Assign Customer"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )
        # Validate tenant/service account
        if z_access_token:
            client_id = data.get("client_id", "")
            if not client_id:
                return {"flag": False, "message": "Client ID is required with z_access_token"}
            service_data = common_utils_database.get_data(
            "service_accounts",
            {"client_id": client_id, "is_active": "True"}  
            )
            if service_data.empty:
                return {"flag": False, "message": "Invalid client ID"}
            tenant_name = service_data["tenant"].to_list()[0]
            role_name = service_data["role"].to_list()[0]
            logging.info(f"### assign_customer_20 role_name - {role_name}")
        else:
            role_name = data.get("role_name", None)
        data["role_name"] = role_name if role_name else None
        data["tenant_name"] = tenant_name    
        # # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id","billing_platform_flag"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}
        tenant_id = int(tenant_df.iloc[0]["id"])
        billing_platform_flag = tenant_df.iloc[0]["billing_platform_flag"]
        data["billing_platform_flag"] = bool(billing_platform_flag)
        logging.info(f"tenant_id : {tenant_id} and db_name : {db_name}")

        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)
        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)
        # Build filter condition for inventory
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}
        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id", "iccid", "msisdn"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}
        # Prepare changed_data (vectorized)
        changed_data = (
            inventory_df[["id"]]
            .assign(
                effective_date=effective_date,
                customer_name=customer_name,
                customer_rate_plan_name=customer_rate_plan_name,
                customer_rate_pool_name=customer_rate_pool_name,
                sub_tenant_carrier_rate_plan_name=sub_tenant_carrier_rate_plan_name,
                modified_by=username,
            )
            .to_dict(orient="records")
        )
        # Add to payload
        data["changed_data"] = changed_data
        logging.info(f"### data : {data}")
        # Call update function
        return update_assign_customer(data)
    except Exception as exception:
        logging.exception(f"### assign_customer_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while assigning customer."}
 

def get_writes_enable_for_service_provider(data):
    """
    Checks if write operations are enabled for the service provider
    from the ServiceProvider table, filtered by tenant_id.
 
    Args:
        tenant_database (DB): Tenant-specific DB connection object.
        tenant_id (int): ID of the tenant whose service provider we are checking.
 
    Returns:
        dict: Contains 'write_is_enabled' flag and a descriptive message.
    """
    logging.info(f"### Request Data recieved for get_writes_enable_for_service_provider {data}")
    # Default to False if no active service provider found
    write_is_enabled = False
    ## Fetching the required params
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    module_name=data.get("module_name","")
    username=data.get("username","")
    service_provider=data.get('service_provider')
    try:
        ##Common Utils Database Connection
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(tenant_database, **db_config_withoutfilter)
    except Exception as e:
        logging.exception(f"### bulk_change_status Exception while connecting to common utils database: {e}") 

    try:
        # Query the ServiceProvider table to fetch write_is_enabled status
        # Filter by tenant_id and only consider active service providers
        service_provider_data = database.get_data(
            "serviceprovider",
            {"is_active": True,"service_provider_name":service_provider},
            ["write_is_enabled"]
        )
        # If data is returned, extract the write_is_enabled value from the first row
        if not service_provider_data.empty:
            write_is_enabled = bool(service_provider_data["write_is_enabled"].iloc[0])
 
        # Audit log to capture the decision for future traceability
        logging.info(
            f"Tenant Name: {tenant_name} | write_is_enabled: {write_is_enabled}"
        )
        response={"flag":True,"write_is_enabled":write_is_enabled,"message":"Carrier write is enabled as per ServiceProvider table." if write_is_enabled
                   else "Carrier write is disabled as per ServiceProvider table."}
        try:
            audit_data_user_actions = {
                "module_name": module_name,
                "created_by": username,
                "status": "True",
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "comments": f"checking writes enabled for service_provider or not {service_provider} for user{username}",
                "service_name": "get_writes_enable_for_service_provider",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### bulk_change_status Exception is {e}")
        return response
    except Exception as e:
        # Log database errors for troubleshooting
        logging.error(f"DB connection error for Tenant Name: {tenant_name} | Error: {e}")
        logging.exception(f"### get_writes_enable_for_service_provider Exception while fetching validation data: {e}")
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        message=f"Failed to fetch the validation details"
        try:
            # Log error to database
            error_data = {
                "service_name": "get_writes_enable_for_service_provider",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message":str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": message,
                "module_name": module_name,
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### get_writes_enable_for_service_provider Exception is {e}")
        return {
            "flag": True,
            "write_is_enabled": False,
            "message": message
        }

def update_user_name(data):
    """
    Updates the username  for SIM inventory records and triggers bulk change workflows.

    This function validates input data, prepares bulk change records, calls the carrier API (via `bulk_change_request`), and triggers 
    bulk change lambda. It also inserts audit logs for tracking both successful and failed updates.

    Args:
        data (dict): Request payload containing the following keys:
            - changed_data (dict | str): Fields to update (username, cost_center, modified_by).
            - old_data (dict, optional): Previous inventory record data, used for service provider info.
            - service_provider_display_name (str, optional): Service provider name.
            - tenant_name (str): Tenant name.
            - db_name (str): Database name for tenant.
            - Any additional metadata required for validation and logging.

    Returns:
        dict: A dictionary with status of the operation:
            - {"flag": True, "message": "Data Updated Successfully for bulk change id:<id>"}
              if update is successful.
            - {"flag": False, "message": "<error_message>"}
              if validation or processing fails.
    """
    logging.info(f"### update_user_name Request Data: {data}")

    # Validate input parameters
    changed_data = data.get("changed_data", {})
    old_data = data.get("old_data", {})
    login_username = data.get("username", "")
    if old_data:
        service_provider_display_name = old_data.get("service_provider_display_name", "")
        data["service_provider_display_name"] = service_provider_display_name
    
    if isinstance(changed_data, str):
        changed_data = json.loads(changed_data)

    # Put parsed version back into data, so validate_inventory_data sees dict/list
    data["changed_data"] = changed_data
    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}
    
    # username = changed_data.get("username")
    username = changed_data.get("username")
    modified_by=changed_data.get("modified_by","")
    cost_center = changed_data.get("cost_center", "")


    if not username:
        return {"flag": False, "message": "No username provided for update"}
    
    # Validate input data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
        
    # Extract validated data
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    tenant_data = validate_response["tenant_data"]
    tenant_id=int(tenant_data["id"].iloc[0])
    service_provider_data = validate_response["service_provider_data"]
    service_provider_id=int(service_provider_data["id"].iloc[0])
    data["change_event_type"]="Edit Username/Cost Center"
    change_event_type = data.get("change_event_type", "")

    # Extract request parameters
    service_provider = data.get("service_provider_display_name", "")
    tenant_name=data.get("tenant_name", "")
    db_name=data.get("db_name", "")

    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    # Prepare device lists for carrier API
    iccids = inventory_data["iccid"].tolist()
    uploaded_len=len(iccids)
    msisdns = inventory_data["msisdn"].tolist()
    data["service_name"] = "update_user_name"

    # Background update for action history
    try:
        logging.info("### update action logs")
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, login_username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### Error update_user_name updating action history: {e}")

    
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len)

        logging.info(f"### update_user_name bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        #change request paylaod
        change_request_payload={
        "ContactName": username if username else "",
        "CostCenter1": cost_center if cost_center else "",
        "ServiceProviderId": service_provider_id,
        "ChangeType": change_type_id
        }
        #call to chnage request
        bulk_change_request(
                tenant_name,
                modified_by,tenant_id,
                tenant_database,
                changed_data,
                
                bulkchange_id,
                inventory_data,change_request_payload
        )
                

        #bulk change lambda calling
        logging.info(f"### update_user_name msisdn_list : {msisdns}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config

        )      
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_user_name auditing failed: {exception}")

        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulkchange_id}"}
        
    except Exception as e:
        logging.exception(f"### update_username Error: {e}")

        # Prepare error data for audit logging
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_user_name error auditing failed: {exception}")
        return {"flag": False, "message": "Error updating username"}

def update_change_phone_number(data):
    """
    Updates phone numbers for multiple inventory devices through carrier API integration.
    
    This function processes phone number change requests by validating input data,
    calling carrier APIs to perform the number changes, and updating 
    inventory database with successful changes. 
    
    Args:
        data (dict): Request payload containing:
            - tenant_name (str): Name of the tenant
            - username (str): User performing the phone number change
            - service_provider_display_name (str): Service provider name
            - access_token (str, optional): Access token for authentication
            - db_name (str): Database name for tenant operations
            - change_event_type (str): Type of change event ("Change Phone Number")
            - carrier_api_status (bool, optional): Whether to use carrier API (default: False)
            - table_name (str, optional): Target table name for updates
            - changed_data (list): List of phone number change records, each containing:
                - id (int): Device inventory record ID
                - old_msisdn (str): Current phone number
                - msisdn (str): New phone number to assign
                - effective_date (str, optional): Date when change takes effect
    
    Returns:
        dict: Response with keys:
            - flag (bool): Success/failure indicator
            - message (str, optional): Status message for simple operations
    """

    logging.info(f"### update_change_phone_number Request Data: {data}")

    # Validate input data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    service_provider_data = validate_response["service_provider_data"]
    service_provider_id=int(service_provider_data["id"].iloc[0])
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    parent_provider_name=data.get("parent_provider_name","")
    msisdns = inventory_data["msisdn"].unique().tolist()
    iccids = inventory_data["iccid"].unique().tolist()
    uploaded_len=len(iccids)
    tenant_data = validate_response["tenant_data"]
    tenant_id=int(tenant_data["id"].iloc[0])
    data["service_name"] = "change_phone_number"
    logging.info(f"### parent_provider_name : {parent_provider_name}")
    # Extract request parameters
    db_name=data.get("db_name", "")

    service_provider = data.get("service_provider_display_name", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")

    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    change_event_type = data.get("change_event_type", "")
    tenant_id = tenant_data["id"].tolist()[0]
    changed_data = data.get("changed_data", [])
    modified_by=changed_data[0].get("modified_by","")
    
    access_token = data.get("access_token", "")
    effective_date = next((record.get("effective_date") for record in changed_data), None)
    # Background update for action history
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### Error update_change_phone_number updating action history: {e}")
        
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len) 
        logging.info(f"### update_change_phone_number bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        # Get device type from configuration - NO HARDCODED LISTS
        if parent_provider_name:
            service_provider=parent_provider_name
        device_type = config_manager.get_device_type(service_provider)
        device_list = iccids if device_type == "iccid" else msisdns
        
        if not device_list:
            return {"flag": False, "message": f"No {device_type.upper()}s provided for {service_provider}"}
        

        old_msisdn = [item.get("msisdn") for item in changed_data if "msisdn" in item]
        logging.info(f"### update_change_phone_number old_msisdn : {old_msisdn}")
        change_request_payload = {
        
            "old_msisdn": old_msisdn,
            "new_msisdn": old_msisdn,
            "effective_date": effective_date
            }

        logging.info(f"### update_change_phone_number change_request_payload : {change_request_payload}")
        logging.info(f"### update_change_phone_number changed_data : {changed_data}")
        #call to chnage request
        bulk_change_request(
                tenant_name,
                modified_by,tenant_id,
                tenant_database,
                changed_data,        
                bulkchange_id,
                inventory_data,change_request_payload
        )
                

        #bulk change lambda calling
        logging.info(f"### update_change_phone_number msisdn_list : {msisdns}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config
        )      
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_change_phone_number auditing failed: {exception}")
        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulkchange_id}"}
  

    except Exception as e:
        logging.exception(f"### Error during phone number change process{e}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_change_phone_number error auditing failed: {exception}")
        return {"flag": False, "message": "Failed to change phone number"}


# def update_refresh_a_line(data):
#     logging.info(f"### refresh_a_line Request Data: {data}")

#     # Validate input parameters
#     changed_data = data.get("changed_data", [])
#     if not changed_data:
#         return {"flag": False, "message": "No records provided for update"}

#     # Validate input data
#     validate_response = validate_inventory_data(data)
#     if not validate_response["flag"]:
#         return validate_response
        
#     # Extract validated data
#     tenant_database = validate_response["tenant_database"]
#     common_utils_database = validate_response["common_utils_database"]
#     inventory_data = validate_response["inventory_data"]

#     # Extract request parameters
#     service_provider = data.get("service_provider_display_name", "")
#     tenant_name=data.get("tenant_name", "")
#     username=data.get("username", "")
#     db_name=data.get("db_name", "")

#     if tenant_name == "Altaworx Test":
#         tenant_name = "Altaworx"

#     # Prepare device lists for carrier API
#     msisdns = inventory_data["msisdn"].tolist()
    
#     access_token=data.get("access_token", "")
#     change_event_type = data.get("change_event_type")
#     change_event_type = data.get("change_event_type")
#     data["service_name"] = "refresh_a_line"
#     # Background update for action history
#     try:
#         threading.Thread(
#             target=update_action_history_logs,
#             args=(tenant_name, tenant_database, common_utils_database, inventory_data, change_event_type, username),
#             daemon=True
#         ).start()
#     except Exception as e:
#         logging.error(f"### Error updating action history: {e}")
#     try:
#         msisdn_map = inventory_data.set_index("id")["msisdn"].to_dict()

#         carrier_response = send_refresh_a_line_request(service_provider, change_event_type
#                                                     ,common_utils_database,tenant_database,msisdn_map,changed_data)
#         if not carrier_response["flag"]:
#             return {"flag": False, "message": carrier_response["message"]}
#         records_to_update = carrier_response["data"]
#         updated = tenant_database.bulk_update_data("sim_management_inventory", records_to_update, "id")
#         if updated:
#             logging.info(f"### update_refresh_a_line Bulk DB update done for {len(records_to_update)} records.")
#             audit_data = data.copy()
#             audit_data["flag"] = True
#             audit_data["message"] = json.dumps(changed_data)
#             # Update inventory action history and device history 
#             try:
#                 threading.Thread(target=inventory_action_history_update, args=(data, validate_response), daemon=True).start()
#                 insert_device_history_records(tenant_name, username, [], service_provider, db_name, msisdns, access_token)
#                 threading.Thread(target=insert_audit_logs, args=(audit_data, ), daemon=True).start()
#             except Exception as thread_error:
#                 logging.warning(f"### update_refresh_a_line Background task failed: {thread_error}")
#             return {"flag": True, "message": "Data Updated Successfully"}
#         else:
#             return {"flag": False, "message": "Failed to update Refresh A Line"}
#     except Exception as e:
#         logging.exception(f"### Error during refresh_a_line process: {e}")
#         # Prepare error data for audit logging
#         error_data = data.copy()
#         error_data["flag"] = False
#         error_data["message"] = str(e)
#         error_data["comments"] = json.dumps(changed_data)
#         error_data["error_type"] = type(e).__name__
#         threading.Thread(target=insert_audit_logs, args=(error_data, ), daemon=True).start()
#         return {"flag": False, "message": "Failed to update Refresh A Line"}

def update_refresh_a_line(data):
    """
    Handles the 'refresh_a_line' change type request for SIM/device inventory records.
    this change type triggers a refresh action on the carrier side based on the response we will modify in the database for that sim. 
    
    Args:
        data (dict): Request payload containing:
            - tenant_name (str): Name of the tenant.
            - username (str): Requesting user.
            - changed_data (list): List of updated records with `refresh_a_line` info.
            - change_event_type (str): Event type for tracking.

    Returns:
        dict: Response with:
            - "flag" (bool): Status of the operation.
            - "message" (str): Success or failure details.
    """
    
    logging.info(f"### refresh_a_line Request Data: {data}")
    # Validate input parameters
    db_name=data.get("db_name","")
    changed_data = data.get("changed_data", [])
    if not changed_data:
        return {"flag": False, "message": "No changed records provided for update"}

    # Validate input data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
        
    # Extract validated data
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    tenant_id = int(validate_response["tenant_data"]["id"].iloc[0])
    tenant_name=data.get("tenant_name", "")
    username=data.get("username", "")
    # Prepare device lists for carrier API
    iccids = inventory_data["iccid"].tolist()
    msisdns = inventory_data["msisdn"].tolist()
    uploaded_len = len(iccids)
    service_provider_id = int(validate_response["service_provider_data"]["id"].iloc[0])
    # mapping the tenant name
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    
    change_event_type = data.get("change_event_type")
    data["service_name"] = "update_refresh_a_line"
    # Background update for action history
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### Error updating action history: {e}")
    try:
        # Create bulk change record
        bulkchange_id, change_type_id = create_bulk_change_record(
            data, service_provider_id, tenant_id, tenant_database, change_event_type, uploaded_len
        )
        logging.info(f"### update_refresh_a_line : bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")

        # Build the correct change_request_payload for DB insert
        first_record = changed_data[0] if changed_data else {}
        refresh_payload = first_record.get("refresh_a_line", {})
        modified_by = first_record.get("modified_by")

        change_request_payload = {
            "RefreshLine": refresh_payload
        }
        # Call the bulk_change_request for inserting change requests
        response_data = bulk_change_request(
            tenant_name,
            modified_by,
            tenant_id,
            tenant_database,
            changed_data,
            bulkchange_id,
            inventory_data,
            change_request_payload
        )
        logging.info(f"### update_refresh_a_line response_data : {response_data} ")

        # Call Lambda for bulk change processor invocation
        bulkchange_lambda_caller_response = bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config
        )
        logging.info(f"### update_refresh_a_line bulkchange_lambda_caller response : {bulkchange_lambda_caller_response}")
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_refresh_a_line auditing failed: {exception}")
        logging.info(f"### refresh_a_line auditing is completed")    
        return {"flag": True, "message": "Data Updated Successfully", "response_data":response_data }

    except Exception as e:
        logging.exception(f"### Error during refresh_a_line process: {e}")
        # Prepare error data for audit logging
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_refresh_a_line error auditing failed: {exception}")    
        return {"flag": False, "message": "Failed to update Refresh A Line"}


def update_ppu_address_20(data):
    """
    Update PPU (Primary Place of Use) address for one or more devices (ICCIDs/MSISDNs) 
    in the tenant inventory, and trigger corresponding customer rate plan updates.

    Args:
        data (dict): Input payload with fields:
            - tenant_name (str, optional): Tenant name (e.g., "Altaworx"). 
            - service_provider (str): Service provider display name
            - changed_data (dict, optional): Dictionary containing new PPU address details
            - iccids (list, optional): List of ICCIDs to update
            - msisdns (list, optional): List of MSISDNs to update
            - UserAddress (str, required inside changed_data): New PPU address to update

    Returns:
        dict: Result object with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - updated_ids (list, optional): IDs of updated inventory records
    """
    try:
        logging.info(f"### update_ppu_address_20 data received : {data}")
        # Extract inputs safely
        service_provider = data.get("service_provider", "")
        if not service_provider : 
            return {"flag":False , "message":"service provider is not provided"}
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        db_name = data.get("db_name")

        # Extract fields from changed_data (list of dicts)
        changed_input = data.get("changed_data", {})
        if not changed_input:
            return {"flag": False, "message": "changed_data is missing"}
        user_address = changed_input.get("UserAddress", {})
        if not user_address:
            return {"flag": False, "message": "UserAddress is not provided"}

        # Add metadata for auditing
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Update PPU address"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )
        # If z_access_token is provided → validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}
        data["username"] = username =  client_id 

        service_data = common_utils_database.get_data(
            "service_accounts",
            {"client_id": client_id, "is_active": "True"}  
        )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        data["tenant_name"] = tenant_name

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"### update_ppu_address_20 tenant_id : {tenant_id} and db_name : {db_name}")
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)

        # Build filter condition for inventory
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id","msisdn"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        changed_data = [
            {
                "id": row["id"],
                "msisdn": row["msisdn"],
                "user_address": {
                    "billingAccount": {"id": user_address["billingAccount"]},
                    "relatedParty": user_address.get("relatedParty", {})
                },
                "modified_by": username
            }
            for _, row in inventory_df.iterrows()
            ]

        logging.info(f"### update_ppu_address_20 changed_data : {changed_data}")

        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### update_ppu_address_20 data : {data}")

        # Call update function
        return update_ppu_address(data)

    except Exception as exception:
        logging.exception(f"### update_ppu_address_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating ppu addresss."}
    

def update_change_phone_number_20(data):
    """
    Change phone number for one or more devices (MSISDNs) in the tenant inventory, 
    validate service account credentials, and trigger corresponding update actions.

    Args:
        data (dict): Input payload with fields:
            - service_provider (str): Service provider display name
            - client_id (str): Service account client ID for validation
            - changed_data (dict): Dictionary containing:
                - old_msisdns (list): List of old MSISDNs to be changed
            - tenant_name (str, optional): Tenant name (resolved internally if not provided)
    Returns:
        dict: Result object with keys:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - changed_data (list, optional): List of updated records with fields:
                - id (int): Inventory record ID
                - msisdn (str): Current MSISDN in inventory
                - old_msisdn (str): Old MSISDN being changed
                - modified_by (str): User/client ID that triggered the change
    """
    try:
        logging.info(f"### update_change_phone_number_20 data received : {data}")
        # Extract inputs safely
        service_provider = data.get("service_provider", "")
        if not service_provider : 
            return {"flag":False , "message":"service provider is not provided"}
        db_name = data.get("db_name")

        # Extract fields from changed_data
        changed_input = data.get("changed_data", {})
        if not changed_input:
            return {"flag": False, "message": "changed_data is missing"}

        old_msisdns = changed_input.get("old_msisdn", [])
        if not old_msisdns:
            return {"flag": False, "message": "old msisdns are not given"}

        # Add metadata for auditing
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Change Phone Number"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        # If z_access_token is provided → validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}
        data["username"] = username =  client_id 

        service_data = common_utils_database.get_data(
            "service_accounts",
            {"client_id": client_id, "is_active": "True"}  
        )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        data["tenant_name"] = tenant_name

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"### update_change_phone_number_20 tenant_id : {tenant_id} and db_name : {db_name}")
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)
        # Build filter condition for inventory
        filter_condition = {"msisdn": old_msisdns, "tenant_id": tenant_id, "is_active": True}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id","msisdn"]
        )
        # Rename column msisdn -> old_msisdn
        inventory_df = inventory_df.rename(columns={"msisdn": "old_msisdn"})
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Prepare changed_data (vectorized, no manual loop)
        changed_data = []
        for _, row in inventory_df.iterrows():
            changed_data.append({
                "id": int(row["id"]),
                "effective_date": datetime.now().strftime("%m/%d/%Y"),  # today's date
                "modified_by": username,
                "old_msisdn": row["old_msisdn"],
                "msisdn": row["old_msisdn"]  # keeping same as old for now
            })
        logging.info(f"### update_change_phone_number_20 changed_data : {changed_data}")

        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### update_change_phone_number_20 data : {data}")
        # Call update function
        return update_change_phone_number(data)

    except Exception as exception:
        logging.exception(f"### update_change_phone_number_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating change phone number."}  


def update_user_name_20(data):
    """
    Change the username for one or more devices (ICCIDs or MSISDNs) in the tenant inventory, 
    validate the service account credentials, and trigger corresponding update and auditing actions.

    Args:
        data (dict): Input payload with the following keys:
            - service_provider (str): Service provider display name (required)
            - changed_data (dict): Dictionary containing:
                - username (str): New username to update (required)
            - iccids (list, optional): List of ICCIDs of devices to update
            - msisdns (list, optional): List of MSISDNs of devices to update
            - other metadata keys (optional): Any additional keys for auditing, e.g., change_event_type, request_received_at

    Returns:
        dict: Result object with keys:
            - flag (bool): Indicates whether the operation was successful or not
            - message (str): Status message describing the result
            - changed_data (list, optional): List of updated inventory records, each containing:
                - id (int): Inventory record ID
                - msisdn (str): Current MSISDN in inventory
                - iccid (str, optional): ICCID of the device
                - modified_by (str): User/client ID that triggered the change
                - username (str): Updated username value
    """
    try:
        logging.info(f"### update_user_name_20 data received : {data}")
        # Extract inputs safely
        service_provider = data.get("service_provider", "")
        if not service_provider : 
            return {"flag":False , "message":"service provider is not provided"}
        iccid = data.get("iccid")
        msisdn = data.get("msisdn")
        db_name = data.get("db_name")

        # Extract fields from changed_data
        changed_input = data.get("changed_data", {})
        if not changed_input:
            return {"flag": False, "message": "changed data is not provided"}

        # Get the first dict in the list
        first_name = changed_input.get("first_name", "")
        if not first_name:
            return {"flag": False, "message": "user first name is not provided"}
        last_name= changed_input.get("last_name", "")  
        username_to_update =  f"{first_name} {last_name}".strip()

        # Add metadata for auditing
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Edit Username/Cost Center"  
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )
        # If z_access_token is provided → validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}
        data["username"] = username =  client_id 

        service_data = common_utils_database.get_data(
            "service_accounts",
            {"client_id": client_id, "is_active": "True"}  
        )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        data["tenant_name"] = tenant_name
        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"### update_user_name_20 tenant_id : {tenant_id} and db_name : {db_name}")
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)
        # Build filter condition for inventory
        if iccid:
            filter_condition = {"iccid": iccid, "tenant_id": tenant_id, "is_active": True}
        elif msisdn:
            filter_condition = {"msisdn": msisdn, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}
        first_id = int(inventory_df.iloc[0]["id"])    

        # Prepare changed_data (vectorized, no manual loop)
        changed_data = {
            "id": first_id,
            "username" :username_to_update,
            "modified_by":username
        }
        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### update_user_name_20 data : {data}")

        # Call update function
        return update_user_name(data)

    except Exception as exception:
        logging.exception(f"### update_user_name_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating user name."}   


def update_refresh_a_line_20(data):
    """
    Refresh a line (Resend OTA profile) for one or more devices (ICCIDs/MSISDNs) 
    in the tenant inventory, validate client credentials, and trigger corresponding
    update and auditing actions.

    Args:
        data (dict): Input payload with the following keys:
            - service_provider (str): Service provider display name (required)
            - client_id (str): Client ID associated with the service account (required)
            - iccids (list, optional): List of ICCIDs of devices to refresh
            - msisdns (list, optional): List of MSISDNs of devices to refresh
            - billingAccount (str): Billing account ID required for refresh operation
    Returns:
        dict: Result object with keys:
            - flag (bool): Indicates whether the operation was successful or not
            - message (str): Status message describing the result
    """
    try:
        logging.info(f"### update_refresh_a_line_20 data received : {data}")
        # Extract inputs safely
        service_provider = data.get("service_provider", "")
        if not service_provider : 
            return {"flag":False , "message":"service provider is not provided"}
        iccids = data.get("iccids")
        msisdns = data.get("msisdns")
        db_name = data.get("db_name")

        # Extract fields from changed_data
        billing_account_id = data.get("billingAccount","")
        if not billing_account_id : 
            return {"flag":False , "message":"billing account id is not provided"}

        # Add metadata for auditing
        data["service_provider_display_name"] = service_provider
        data["change_event_type"] = "Refresh A Line"
        data["request_received_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Initialize common_utils DB
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config
        )

        # If z_access_token is provided → validate service account
        client_id = data.get("client_id", "")
        if not client_id:
            return {"flag": False, "message": "Client ID is required with z_access_token"}
        data["username"] = username =  client_id 

        service_data = common_utils_database.get_data(
            "service_accounts",
            {"client_id": client_id, "is_active": "True"}  
        )
        if service_data.empty:
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        data["tenant_name"] = tenant_name

        # Handle special case for Altaworx Test tenant
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"

        # Validate tenant exists
        tenant_df = common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name, "is_active": True},
            ["id"]
        )
        if tenant_df.empty:
            return {"flag": False, "message": "Tenant not found."}

        tenant_id = int(tenant_df.iloc[0]["id"])
        logging.info(f"### update_refresh_a_line_20 tenant_id : {tenant_id} and db_name : {db_name}")
        response = get_writes_enable_for_service_provider(data)
        data["carrier_api_status"] = response.get("write_is_enabled", False)

        # Connect to tenant-specific DB
        tenant_database = DB(db_name, **db_config_withoutfilter)
        # Build filter condition for inventory
        if iccids:
            filter_condition = {"iccid": iccids, "tenant_id": tenant_id, "is_active": True}
        elif msisdns:
            filter_condition = {"msisdn": msisdns, "tenant_id": tenant_id, "is_active": True}
        else:
            return {"flag": False, "message": "Either ICCID or MSISDN is required."}

        # Fetch inventory details
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            filter_condition,
            ["id","iccid"]
        )
        if inventory_df.empty:
            return {"flag": False, "message": "Inventory details not found."}

        # Fixed structure for refresh_a_line
        fixed_refresh_a_line = {
            "requestType": "resendOTAProfile",
            "billingAccount": {
                "id":billing_account_id
            },
            "serviceCharacteristic": [
                {
                    "name": "sim",
                    "value": ""
                }
            ]
        }
        # Prepare changed_data (vectorized, no manual loop)
        changed_data = (
            inventory_df[["id", "iccid"]]
            .assign(
                refresh_a_line=[fixed_refresh_a_line] * len(inventory_df),
                modified_by=username
            )
            .to_dict(orient="records")
        )
        # Add to payload for audit/update function
        data["changed_data"] = changed_data
        logging.info(f"### update_refresh_a_line_20 data : {data}")
        # Call update function
        return update_refresh_a_line(data)

    except Exception as exception:
        logging.exception(f"### update_refresh_a_line_20 Exception : {exception}")
        return {"flag": False, "message": "Unexpected error while updating refresh a line."} 


def update_ppu_address(data):
    """
    Bulk update of PPU address for multiple MSISDNs in the inventory
    and synchronize the changes with the AMLC Telegence API.
 
    Args:
        data (dict): Request payload containing:
            - tenant_name (str): Tenant/Partner name.
            - username (str): User performing the action.
            - service_provider_display_name (str): Carrier/Service Provider name.
            - change_event_type (str): Type of change (e.g., "update_ppu_address").
            - changed_data (list[dict]): List of objects with:
                  {
                      "msisdn": "<msisdn>",
                      "UserAddress": { <address fields> }
                  }
            - carrier_api_status (bool): Whether to call carrier API or not.
            - db_name (str): Database name.
            - access_token (str): Access token for history sync (optional).
 
    Returns:
        dict: Response with keys:
            - flag (bool): Overall success or failure.
            - successful_msisdns (list[str]): List of MSISDNs successfully updated.
            - failed_msisdns (list[str]): List of MSISDNs failed to update.
            - message (str): Summary message.
    """
 
    logging.info(f"### update_ppu_address Request Data Received : {data}")
 
    # --- Input extraction ---
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider = data.get("service_provider_display_name", "")
    change_event_type = data.get("change_event_type")
    changed_data = data.get("changed_data", [])
    carrier_api_status = data.get("carrier_api_status", False)
    db_name = data.get("db_name", "")
    access_token = data.get("access_token", "")
    data["service_name"] = "ppu_address" 
    modified_by=changed_data[0].get("modified_by", "")

 
    # --- Validation ---
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
 
    tenant_database = validate_response.get("tenant_database", {})
    common_utils_database = validate_response.get("common_utils_database", {})
    inventory_data = validate_response.get("inventory_data", {})
    service_provider_data=validate_response["service_provider_data"]
    service_provider_id=int(service_provider_data["id"].iloc[0])
    tenant_data=validate_response["tenant_data"]
    tenant_id=int(tenant_data["id"].iloc[0])
    msisdn_list = inventory_data["msisdn"].unique().tolist()
    iccids = inventory_data["iccid"].unique().tolist()
    uploaded_len=len(iccids)
 
    # Audit logs (async) 
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, username),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### update_ppu_address Error updating action history: {e}")
 
    # logging.info(f"### update_ppu_address MSISDN to Payload mapping: {msisdn_to_payload}")
    common_user_address = changed_data[0].get("user_address", {})
    logging.info(f"### update_ppu_address common_user_address : {common_user_address}")
    if not common_user_address : 
        return {"flag": False, "message": "No user address found in the request"}
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len)
        
        logging.info(f"### update_ppu_address bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        if "user_address" not in changed_data[0]:
            return {"flag": False, "message": "No user address found in the request"}

        change_request_payload = {
            "UserAddress": changed_data[0]["user_address"]
        }
        logging.info(f"### update_ppu_address change_request_payload : {change_request_payload}")
        bulk_change_request(
                tenant_name,
                modified_by,tenant_id,
                tenant_database,
                changed_data,
                
                bulkchange_id,
                inventory_data,change_request_payload
        )
        logging.info(f"### update_ppu_address process_bulk_change_requests completed")
        #bulk change lambda calling
        logging.info(f"### update_ppu_address msisdn_list : {msisdn_list}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdn_list,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=changed_data,
            common_utils_database_config=common_utils_database_config
        )        
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_ppu_address auditing failed: {exception}")
        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulkchange_id}"}
       
    except Exception as e:
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_ppu_address error auditing failed: {exception}")
        logging.exception(f"### update_ppu_address Exception: {e}")
        return {"flag": False, "message": "Error in update_ppu_address"}





def sim_management_action_history_update(data):
    """
    Updates sim management action history table with change records.
    
    Args:
        data (dict): Contains iccids/msisdns, change_type, tenant info, 
                    old_inventory_data, and bulk_change_id for tracking changes.
    
    Returns:
        None: Inserts action history records into database.
    """
    
    logging.info(f"### sim_management_action_history_update data:{data}")
    # Input extraction
    old_inventory_data = data.get("old_inventory_data", []) 
    success_full_iccids = data.get("iccids", [])
    success_full_msisdns = data.get("msisdns", [])
    change_event_type = data.get("change_type")
    tenant_name = data.get("tenant_name")
    service_provider = data.get("service_provider")
    db_name = data.get("db_name")
    bulk_change_id = data.get("bulk_change_id")
    changed_field = data.get("changed_field")
    tenant_id = data.get("tenant_id")
    username = data.get("username")

    tenant_database = DB(db_name, **db_config_withoutfilter)
    update_to_action_table = []
    logging.info(f"### sim_management_action_history_update changed_field:{changed_field}")

    try:
        # Filter inventory
        if success_full_msisdns:
            inventory_filter = {
                "msisdn": success_full_msisdns,
                "tenant_id": tenant_id,
                "service_provider_display_name": service_provider,
                "is_active": True
            }
        else:
            inventory_filter = {
                "iccid": success_full_iccids,
                "tenant_id": tenant_id,
                "service_provider_display_name": service_provider,
                "is_active": True
            }
        inventory_data = tenant_database.get_data("sim_management_inventory", inventory_filter)
        lookup_data_ids = success_full_iccids if success_full_iccids else success_full_msisdns

        # Function to process a single record
        def process_record(lookup_id):
            try:
                record = inventory_data[inventory_data["iccid"] == lookup_id] if success_full_iccids else inventory_data[inventory_data["msisdn"] == lookup_id]
                if record.empty:
                    return None

                row_id = record["id"].iloc[0]
                iccid = record["iccid"].iloc[0]
                msisdn = record["msisdn"].iloc[0]
                service_provider_id = record["service_provider_id"].iloc[0]
                account_number = record["account_number"].iloc[0]
                customer_name = record["customer_name"].iloc[0]
                mobility_device_id = record["mobility_device_id"].iloc[0]
                device_id = record["device_id"].iloc[0]

                # Previous value from old_inventory_data
                previous_record = next((r for r in old_inventory_data if r.get("msisdn") == msisdn), {})
                logging.info(f"### sim_management_action_history_update previous_record:{previous_record}")
                previous_value = previous_record.get(changed_field, None)
                logging.info(f"### sim_management_action_history_update previous_value:{previous_value}")
                current_value = record[changed_field].iloc[0] if changed_field in record.columns else None
                               
                # Use field_changes from data if passed - look for matching record by ID or ICCID/MSISDN
                # Look for matching record in changed_data
                record_changes = None
                for change_record in data.get("changed_data", []):
                    if (change_record.get("id") == row_id or 
                        change_record.get("iccid") == iccid or 
                        change_record.get("msisdn") == msisdn):
                        record_changes = change_record
                        break
                        
                field_changes = record_changes.get("field_changes", []) if record_changes else []
                # Create a separate history record for each changed field --line sync purpose
                if field_changes:
                    for change in field_changes:
                        update_to_action_table.append({
                            "iccid": str(iccid),
                            "sim_management_inventory_id": int(row_id),
                            "msisdn": str(msisdn),
                            "username": str(username),
                            "change_event_type": str(change_event_type),
                            "date_of_change": datetime.utcnow(),
                            "changed_by": str(username),
                            "is_deleted": False,
                            "is_active": True,
                            "service_provider_id": int(service_provider_id),
                            "customer_account_number": str(account_number),
                            "tenant_id": int(tenant_id),
                            "service_provider": str(service_provider),
                            "bulk_change_id": int(bulk_change_id),
                            "uploaded_file_id": None,
                            "previous_value": format_for_db(change.get("previous_value")),
                            "current_value": format_for_db(change.get("current_value")),
                            "changed_field": str(change.get("field")),
                            "customer_account_name": str(customer_name),
                            "m2m_device_id": int(device_id) if device_id else None,
                            "mobility_device_id": int(mobility_device_id) if mobility_device_id else None,
                        })
                    # Already processed field changes, skip default single field return
                    return None

                # Fallback for single changed_field (backward compatibility)-all types
                return {
                    "iccid": str(iccid),
                    "sim_management_inventory_id": int(row_id),
                    "msisdn": str(msisdn),
                    "username": str(username),
                    "change_event_type": str(change_event_type),
                    "date_of_change": datetime.utcnow(),
                    "changed_by": str(username),
                    "is_deleted": False,
                    "is_active": True,
                    "service_provider_id": int(service_provider_id),
                    "customer_account_number": str(account_number),
                    "tenant_id": int(tenant_id),
                    "service_provider": str(service_provider),
                    "bulk_change_id": int(bulk_change_id),
                    "uploaded_file_id": None,
                    "previous_value": format_for_db(previous_value),
                    "current_value": format_for_db(current_value),
                    "changed_field": str(changed_field),
                    "customer_account_name": str(customer_name),
                    "m2m_device_id": int(device_id) if device_id else None,
                    "mobility_device_id": int(mobility_device_id) if mobility_device_id else None,
                }
                

            except Exception as e:
                logging.error(f"### Error processing record {lookup_id}: {e}")
                return None

        # Process all records in parallel
        parallel_requests = min(10, len(lookup_data_ids))  # Set max threads, adjust as needed
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            futures = [executor.submit(process_record, lookup_id) for lookup_id in lookup_data_ids]
            for future in as_completed(futures):
                result = future.result()
                if result:
                    update_to_action_table.append(result)

        # Insert into DB
        if update_to_action_table:
            tenant_database.insert_data(update_to_action_table, "sim_management_inventory_action_history")
            logging.info(f"### History inserted for {len(update_to_action_table)} ICCIDs")
        return True

    except Exception as e:
        logging.error(f"### Error in sim_management_action_history_update: {e}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["error_type"] = type(e).__name__
        threading.Thread(target=insert_audit_logs, args=(error_data,), daemon=True).start()
        return False


def format_for_db(value):
    """
    Convert a value to a format suitable for DB storage in a character varying field.
    - If value is dict or list, convert to JSON string.
    - If value is string, number, or bool, keep as string.
    - If value is None, return None.
    """
    if value is None:
        return None
    elif isinstance(value, (dict, list)):
        return json.dumps(value)  # convert dict/list to JSON string
    else:
        return str(value) 

# # change request for ppu,username,edit cost center,feature,change phone number,customer rate plan
# def bulk_change_request(
#         tenant_name,
#         modified_by,
#         tenant_id,
#         tenant_database,
#         changed_data,
#         bulkchange_id,
#         inventory_data,
#         change_request_payload
# ):
#     """
#     Inserts bulk change requests into DB.
#     Handles per-SIM message when 'messageText' exists in changed_data.
#     """

#     logging.info(f"### bulk_change_request changed_data:{changed_data}")

#     # Normalize changed_data
#     if isinstance(changed_data, dict):
#         changed_data = [changed_data]
#     elif not isinstance(changed_data, list):
#         return {"flag": False, "message": "changed_data must be a dict or list of dicts"}

#     # Check if any specific SIM has custom message text
#     has_individual_message = any(
#         isinstance(record, dict) and record.get("messageText")
#         for record in changed_data
#     )

#     # Build inventory lookup for faster access
#     inventory_lookup = {row["id"]: row for _, row in inventory_data.iterrows()}

#     sim_management_bulk_change_request = []

#     for record in changed_data:
#         inv_row = inventory_lookup.get(record.get("id"))
#         if not inv_row:
#             logging.warning(f"[bulk_change_request] Inventory not found for id: {record.get('id')}")
#             continue

#         # Create payload for each SIM
#         payload = change_request_payload.copy()
#         payload["ICCID"] = inv_row.get("iccid")
#         payload["MDN"] = inv_row.get("msisdn")

#         # Override message text per SIM if provided
#         if has_individual_message and record.get("messageText"):
#             payload["MessageText"] = record.get("messageText")

#         sim_management_bulk_change_request.append({
#             "iccid": inv_row["iccid"],
#             "subscriber_number": inv_row.get("msisdn"),
#             "bulk_change_id": str(bulkchange_id),
#             "tenant_name": tenant_name,
#             "created_by": modified_by,
#             "processed_by": modified_by,
#             "status": "NEW",
#             "device_id": int(inv_row["device_id"]) if inv_row.get("device_id") else None,
#             "tenant_id": int(tenant_id),
#             "is_active": True,
#             "is_deleted": False,
#             "change_request": (
#                 json.dumps(payload)
#                 if has_individual_message
#                 else json.dumps(change_request_payload)
#             )
#         })

#     logging.info(f"### process_bulk_change_requests payload rows: {len(sim_management_bulk_change_request)}")
#     logging.debug(f"### Final Payload: {sim_management_bulk_change_request}")

#     request_id = None
#     if sim_management_bulk_change_request:
#         request_id = tenant_database.insert_data(
#             sim_management_bulk_change_request,
#             "sim_management_bulk_change_request",
#         )

#     logging.info(f"### DB Insert Completed request_id:{request_id}")

#     return {
#         "flag": True,
#         "message": "Successful New Bulk Change Request Has Been Inserted",
#         "sim_management_bulk_change_request": request_id,
#         "bulkchange_id": bulkchange_id,
#     }


# change request for ppu,username,edit cost center,feature,change phone number,customer rate plan
def bulk_change_request(
            tenant_name,
            modified_by,
            tenant_id,
            tenant_database,
            changed_data,
            bulkchange_id,
            inventory_data,
            change_request_payload
    ):
    """
    Creates and inserts bulk change requests for various change types 
    (e.g., PPU, username, cost center edit, feature update, phone number change, customer rate plan have same type of change request payload) 
    into the tenant database.
    Args:
        tenant_name (str): Name of the tenant for which the request is made.
        modified_by (str): Username of the person initiating the change request.
        tenant_id (int): Unique identifier of the tenant.
        tenant_database (object): Database handler object with an 'insert_data' method.
        changed_data (dict or list of dict): Records to be updated; each record must contain an 'id' key 
                                             corresponding to the inventory data.
        bulkchange_id (str or int): Unique identifier for the bulk change operation.
        inventory_data (DataFrame): Pandas DataFrame containing inventory details with keys like 'id', 'iccid', 
                                    'msisdn', 'device_id'.
        change_request_payload (dict): Payload describing the changes to be applied, which will be stored in the 
                                       'change_request' field as JSON.
    Returns:
        tuple: 
            - dict: Contains the database request ID under key 'sim_management_bulk_change_request'.
            - dict: Contains operation status with keys:
                * 'flag' (bool): True if the request was successfully processed.
                * 'message' (str): Description of the operation.
                * 'bulkchange_id' (str/int): The bulk change request identifier.

    """
    logging.info(f"### bulk_change_request changed_data:{changed_data}")
    
    # Normalize changed_data
    if isinstance(changed_data, dict):
        # Single record → convert to list of one dict
        changed_data = [changed_data]
    elif isinstance(changed_data, list):
        # Already a list → use as is
        pass
    else:
        # Invalid type
        return {"flag": False, "message": "changed_data must be a dict or a list of dicts"}
    
    # Create a lookup dict to avoid filtering inventory_data repeatedly
    inventory_lookup = {row["id"]: row for _, row in inventory_data.iterrows()}
    # detect sms mode
    is_single_iccid_mode = (
        isinstance(change_request_payload, dict)
        and change_request_payload.get("change_event_type") == "Send SMS"
    )

    # If SMS mode, remove it so it will not go to DB
    if is_single_iccid_mode:
        change_request_payload.pop("change_event_type", None)

    


    # list comprehension build
    sim_management_bulk_change_request = [
        {
            "iccid": inv_row["iccid"],
            "subscriber_number": inv_row.get("msisdn"),
            "msisdn": inv_row.get("msisdn"),
            "bulk_change_id": str(bulkchange_id),
            "tenant_name": tenant_name,
            "created_by": modified_by,
            "processed_by": modified_by,
            "status": "NEW",
            "device_id": int(inv_row["device_id"]) if inv_row.get("device_id") else None,
            "tenant_id": int(tenant_id),
            "is_active": True,
            "is_deleted": False,
            "change_request": json.dumps(
                (
                    {
                        **change_request_payload,
                        "ICCID": inv_row["iccid"],      # per record
                        "MDN": inv_row.get("msisdn")
                    }
                )
                if is_single_iccid_mode
                else change_request_payload           # normal case - full list
            )
        }
        for record in changed_data
        if record.get("id") in inventory_lookup
        for inv_row in [inventory_lookup[record.get("id")]]
    ]

    logging.info(f"### process_bulk_change_requests sim_management_bulk_change_request:{sim_management_bulk_change_request}")
    request_id = None
    if sim_management_bulk_change_request:
        request_id = tenant_database.insert_data(
            sim_management_bulk_change_request,
            "sim_management_bulk_change_request",
        )
    logging.info(f"### process_bulk_change_requests request_id:{request_id}")

    return {
            "flag": True,
            "message": "Successful New Bulk Change Request Has Been Inserted ",
            "sim_management_bulk_change_request": request_id,
            "bulkchange_id": bulkchange_id,
        }


#private network ip chnage type
def update_private_network_ip(data):
    """
    Updates the Private Network Ip for multiple devices in inventory and syncs with carrier API.

    Args:
        data (dict): Request data containing device and cost center information

    Returns:
        dict: Response indicating success or failure of the operation
    """
    logging.info(f"### Private Network IP Request Data Received : {data}")

    # Extract and validate input
    tenant_name=data.get("tenant_name", "")
    service_provider=data.get("service_provider_display_name", "")
    access_token=data.get("access_token", "")
    carrier_api_status = data.get("carrier_api_status", True)
    data["service_name"] = "private_network_ip"
    db_name=data.get("db_name", "") 
    changed_data = data.get("changed_data", [])
    if not changed_data:
        return {"flag": False, "message": "No data provided for update"}
    modified_by = changed_data[0].get("modified_by", "")
    first_change_request = changed_data[0].get("changeRequest", {})
    ip_address = first_change_request.get("ipv6Address", "")


    # Validate inventory data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response

    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    service_provider_data=validate_response["service_provider_data"]
    tenant_data = validate_response["tenant_data"]
    tenant_id = int(tenant_data["id"].iloc[0])
    service_provider_id=int(service_provider_data["id"].iloc[0])
    msisdns = inventory_data["msisdn"].tolist()
    iccids = inventory_data["iccid"].tolist()
    uploaded_len=len(iccids)
    data["change_event_type"]="Change Private Static IP Address"
    logging.info(f"### update_private_network_ip Request Data Receivedupdated: {data}")
    
    change_event_type = data.get("change_event_type", "")
    
    # update action_history_logs
    try:
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, ip_address),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### update_private_network_ip Error updating action history: {e}")
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len)

        logging.info(f"### update_private_network_ip bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        lambda_changed_data = {
            "changedData": first_change_request  # use the request from frontend
        }     
        change_request_payload=lambda_changed_data
        logging.info(f"### change_request_payload:{change_request_payload}")
        logging.info(f"### update_private_network_ip changed_data1 : {changed_data}")
        bulk_change_request(
            tenant_name,
            modified_by,tenant_id,
            tenant_database,
            changed_data,
            
            bulkchange_id,
            inventory_data,change_request_payload
        )  
        #bulk change lambda calling
        logging.info(f"### update_private_network_ip msisdn_list : {msisdns}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=lambda_changed_data,
            common_utils_database_config=common_utils_database_config
        )      
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### update_private_network_ip auditing failed: {exception}")
        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulkchange_id}"}
        
    except Exception as exception:
        logging.exception(f"### Error in update_private_network_ip: {exception}")
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(exception)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(exception).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### update_private_network_ip error auditing failed: {exception}")
        return {"flag": False, "message": "Cost center update failed"}



def send_sms(data):
    """
    send sms for SIM inventory records and triggers bulk change workflows.

    This function validates input data, prepares bulk change records, calls the carrier API (via `bulk_change_request`), and triggers 
    bulk change lambda. It also inserts audit logs for tracking both successful and failed updates.

    Args:
        data (dict): Request payload containing the following keys:
            - changed_data (dict | str): Fields to update (username, cost_center, modified_by).
            - old_data (dict, optional): Previous inventory record data, used for service provider info.
            - service_provider_display_name (str, optional): Service provider name.
            - tenant_name (str): Tenant name.
            - db_name (str): Database name for tenant.
            - Any additional metadata required for validation and logging.

    Returns:
        dict: A dictionary with status of the operation:
            - {"flag": True, "message": "Data Updated Successfully for bulk change id:<id>"}
              if update is successful.
            - {"flag": False, "message": "<error_message>"}
              if validation or processing fails.
    """
    logging.info(f"### send_sms Request Data: {data}")

    # Validate input parameters
    changed_data = data.get("changed_data", [])
    if isinstance(changed_data, str):
        changed_data = json.loads(changed_data)

    # Put parsed version back into data, so validate_inventory_data sees dict/list
    data["changed_data"] = changed_data
    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}
    
    # username = changed_data.get("username")
    message_text = changed_data[0].get("message_text")
    if not message_text:
        return {"flag": False, "message": "No message_text provided for update"}
    modified_by=changed_data[0].get("modified_by","")
    # Validate input data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
        
    # Extract validated data
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    tenant_data = validate_response["tenant_data"]
    tenant_id=int(tenant_data["id"].iloc[0])
    service_provider_data = validate_response["service_provider_data"]
    service_provider_id=int(service_provider_data["id"].iloc[0])
    data["change_event_type"]="Send SMS"
    change_event_type = data.get("change_event_type", "")

    # Extract request parameters
    service_provider = data.get("service_provider_display_name", "")
    tenant_name=data.get("tenant_name", "")
    db_name=data.get("db_name", "")

    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    # Prepare device lists for carrier API
    iccids = inventory_data["iccid"].tolist()


    uploaded_len=len(iccids)
    msisdns = inventory_data["msisdn"].tolist()
    
    data["service_name"] = "send_sms"

    # Background update for action history
    try:
        logging.info("### update action logs")
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, message_text),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### Error send_sms updating action history: {e}")

    
    try:
        #for bulk change id preparation
        bulkchange_id,change_type_id=create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len)

        logging.info(f"### send_sms bulkchange_id : {bulkchange_id} ,change_type_id:{change_type_id}")
        #change request paylaod
        change_request_payload={
            "ServiceProviderId": service_provider_id,
            "ChangeType":change_type_id ,
            "MessageText": message_text,
            "MessageType": "Text",
            "MessageEncoding": "TEXT",
            "ICCID":iccids ,
            "MDN": msisdns,
            "change_event_type":change_event_type
            }
        #call to chnage request
        bulk_change_request(
                tenant_name,
                modified_by,tenant_id,
                tenant_database,
                changed_data,
                
                bulkchange_id,
                inventory_data,change_request_payload
        )
                

        #bulk change lambda calling
        logging.info(f"### send_sms msisdn_list : {msisdns}")
        # Extract only message_text for lambda
        lambda_changed_data = {"messageText": message_text}

        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=lambda_changed_data,
            common_utils_database_config=common_utils_database_config

        )      
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        # auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### send_sms auditing failed: {exception}")

        return {"flag": True, "message": f"Data Updated Successfully for bulk change id:{bulkchange_id}"}
        
    except Exception as e:
        logging.exception(f"### send_sms Error: {e}")

        # Prepare error data for audit logging
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### send_sms error auditing failed: {exception}")
        return {"flag": False, "message": "Error send sms"}      
        
        
def reset_voicemail_password(data):
    """
    Reset voicemail password for SIM inventory records and triggers bulk change workflows.

    This function validates input data, prepares bulk change records, calls the carrier API (via `bulk_change_request`), 
    and triggers bulk change lambda. It also inserts audit logs for tracking both successful and failed updates.

    Args:
        data (dict): Request payload containing the following keys:
            - changed_data (dict | str): Fields containing voicemail reset parameters.
            - old_data (dict, optional): Previous inventory record data, used for service provider info.
            - service_provider_display_name (str, optional): Service provider name.
            - tenant_name (str): Tenant name.
            - db_name (str): Database name for tenant.
            - Any additional metadata required for validation and logging.

    Returns:
        dict: A dictionary with status of the operation:
            - {"flag": True, "message": "Data Updated Successfully for bulk change id:<id>"}
              if update is successful.
            - {"flag": False, "message": "<error_message>"}
              if validation or processing fails.
    """
    logging.info(f"### reset_voicemail_password Request Data: {data}")

    # Validate input parameters
    changed_data = data.get("changed_data", [])
    if isinstance(changed_data, str):
        changed_data = json.loads(changed_data)

    # Put parsed version back into data, so validate_inventory_data sees dict/list
    data["changed_data"] = changed_data
    if not changed_data:
        return {"flag": False, "message": "No records provided for update"}
    
    # Extract voicemail reset parameters from the first item in changed_data array
    pin = changed_data[0].get("pin")
    
    # Validate required parameters
    if not pin:
        return {"flag": False, "message": "No newPin provided for voicemail reset"}
    
    modified_by = data.get("modified_by", "")

    # Validate input data
    validate_response = validate_inventory_data(data)
    if not validate_response["flag"]:
        return validate_response
        
    # Extract validated data
    tenant_database = validate_response["tenant_database"]
    common_utils_database = validate_response["common_utils_database"]
    inventory_data = validate_response["inventory_data"]
    tenant_data = validate_response["tenant_data"]
    tenant_id = int(tenant_data["id"].iloc[0])
    service_provider_data = validate_response["service_provider_data"]
    service_provider_id = int(service_provider_data["id"].iloc[0])
    data["change_event_type"] = "Reset Voicemail Password"
    change_event_type = data.get("change_event_type", "")

    # FIX: Get billing account from inventory data
    # Assuming inventory_data has a 'billing_account_number' column
    billing_account_id = None
    if not inventory_data.empty and "billing_account_number" in inventory_data.columns:
        billing_account_id = inventory_data["billing_account_number"].iloc[0]
        logging.info(f"### Retrieved billing account from inventory: {billing_account_id}")
    
    # Validate billing account exists
    if not billing_account_id:
        logging.error(f"### No billing account found in inventory records. Available columns: {inventory_data.columns.tolist()}")
        return {"flag": False, "message": "No billing account found in inventory records"}

    # Extract request parameters
    service_provider = data.get("service_provider_display_name", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")

    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    # Prepare device lists for carrier API
    iccids = inventory_data["iccid"].tolist()
    uploaded_len = len(iccids)
    msisdns = inventory_data["msisdn"].tolist()
    
    data["service_name"] = "reset_voicemail_password"

    # Debug logging to verify data
    logging.info(f"### reset_voicemail_password - Inventory data columns: {inventory_data.columns.tolist()}")
    logging.info(f"### reset_voicemail_password - First few inventory records: {inventory_data.head(3).to_dict('records')}")
    logging.info(f"### reset_voicemail_password - Billing account to be used: {billing_account_id}")
    logging.info(f"### reset_voicemail_password - PIN to be used: {pin}")
    logging.info(f"### reset_voicemail_password - MSISDNs to process: {msisdns}")

    # Background update for action history
    try:
        logging.info("### update action logs for voicemail password reset")
        threading.Thread(
            target=update_action_history_logs,
            args=(tenant_name, db_name, inventory_data, change_event_type, f"Reset voicemail PIN to {pin}"),
            daemon=True
        ).start()
    except Exception as e:
        logging.error(f"### Error reset_voicemail_password updating action history: {e}")

    
    try:
        # For bulk change id preparation
        bulkchange_id, change_type_id = create_bulk_change_record(data, service_provider_id, tenant_id, tenant_database, change_event_type, uploaded_len)

        logging.info(f"### reset_voicemail_password bulkchange_id : {bulkchange_id} , change_type_id: {change_type_id}")
        

        # Include billingAccount in the payload
        lambda_changed_data = {
            "billingAccount": {
                "id": billing_account_id
            },
            "serviceCharacteristic": [
                {
                    "name": "newPin",
                    "value": pin  
                }
            ]
        }
        
        # Change request payload for voicemail reset
        change_request_payload = {
            "OverrideValidation": False,
            "Devices": msisdns,
            "billingAccount": {
                "id": billing_account_id 
            },
            "ServiceProviderId": service_provider_id,
            "ChangeType": change_type_id,
            "Request": {
                "serviceCharacteristic": [
                    {
                        "name": "newPin",
                        "value": pin
                    }
                ]
            }
        }
        
        # Call to change request
        bulk_change_request(
            tenant_name,
            modified_by,
            tenant_id,
            tenant_database,
            changed_data,
            bulkchange_id,
            inventory_data,
            change_request_payload
        )
                
        # Bulk change lambda calling - PASS THE CORRECTED changed_data WITH BILLING ACCOUNT
        logging.info(f"### reset_voicemail_password devices : {msisdns}")
        logging.info(f"### reset_voicemail_password passing lambda_changed_data: {lambda_changed_data}")
        bulkchange_lambda_caller(
            data=data,
            msisdns=msisdns,
            iccids=iccids,
            bulkchange_id=bulkchange_id,
            bulk_change_data=lambda_changed_data, 
            common_utils_database_config=common_utils_database_config
        )      
        
        audit_data = data.copy()
        audit_data["flag"] = True
        audit_data["message"] = json.dumps(changed_data)
        
        # Auditing 
        try:
            insert_audit_logs(audit_data)
        except Exception as exception:
            logging.warning(f"### reset_voicemail_password auditing failed: {exception}")

        return {"flag": True, "message": f"Voicemail password reset successfully for bulk change id: {bulkchange_id}"}
        
    except Exception as e:
        logging.exception(f"### reset_voicemail_password Error: {e}")

        # Prepare error data for audit logging
        error_data = data.copy()
        error_data["flag"] = False
        error_data["message"] = str(e)
        error_data["comments"] = json.dumps(changed_data)
        error_data["error_type"] = type(e).__name__
        try:
            insert_audit_logs(error_data)
        except Exception as exception:
            logging.warning(f"### reset_voicemail_password error auditing failed: {exception}")
        return {"flag": False, "message": "Error resetting voicemail password"}

