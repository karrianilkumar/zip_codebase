"""
@Author1 : Ajay Reddi
@Author2 :
@Author3 :
Created Date: 05-09-2025
"""

import os
import json
import time
import ast
import boto3
from datetime import datetime,timezone
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging

logging = Logging(name="inventory_utils")

def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs

def get_provider_ids(json_data, tenant_name, provider_names):
    """Fetches only the IDs of specified providers for a given tenant."""
    return [
        details["id"]
        for provider_name, details in json_data.get(tenant_name, {}).items()
        if provider_name in provider_names
    ]


def load_integration_authentication_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_integration_authentication_id.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_integration_authentication_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_integration_authentication_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_integration_authentication_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs

def get_integration_authentication_id_by_unique_name(json_data, tenant_name):
    """
    Fetches the integration authentication ID for a given tenant from JSON data.
    
    Args:
        json_data (dict): JSON data containing tenant integration authentication information
        tenant_name (str): Name of the tenant to look up
        
    Returns:
        int or None: The integration authentication ID if found, None otherwise
    """
    logging.info(f"### get_integration_authentication_id_by_unique_name Tenant Name: {tenant_name}")
    return json_data.get(tenant_name, {}).get("INTEGRATION_AUTHENTICATION_ID", None)


def clean_tuple(tpl):
    """
    Formats a tuple for SQL queries, handling edge cases like None values and single-item tuples.
    
    Args:
        tpl (tuple or None): The tuple to format
        
    Returns:
        str or tuple: A properly formatted string representation of the tuple for SQL queries,
                     or an empty tuple if the input is None or not a tuple
    """
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        logging.exception(f"### clean_tuple Exception while converting {e}")
        return ()


def create_bulk_change_record(data,service_provider_id,tenant_id,tenant_database,change_event_type,uploaded_len):
    change_type_id = tenant_database.get_data(
            "sim_management_bulk_change_type", {"display_name": change_event_type}, ["id"]
        )["id"].to_list()[0]
    logging.info(f"### change_type_id for chnage request preparation:{change_type_id}")
    service_provider = data.get("service_provider_display_name")
    username = data.get("username")
    create_new_bulk_change_dict = {
        "service_provider": service_provider,
        "change_request_type_id": str(change_type_id),
        "change_request_type": change_event_type,
        "service_provider_id": str(service_provider_id),
        "modified_by": username,
        "status": "NEW",
        "uploaded": str(uploaded_len),
        "is_active": "True",
        "is_deleted": "False",
        "created_by": username,
        "processed_by": username,
        "tenant_id": str(tenant_id),
        "source":"Inventory"
    }
    # Insert new bulk change data into the database
    bulk_change_id = tenant_database.insert_data(
        create_new_bulk_change_dict, "sim_management_bulk_change"
    )
    return bulk_change_id,change_type_id

def bulkchange_lambda_caller(data, msisdns, iccids, bulkchange_id, bulk_change_data,common_utils_database_config,device_status_id=None):
    """
    Invokes AWS Lambda function for bulk change processing asynchronously.
    
    Args:
        data (dict): Original request data containing tenant and user information
        msisdns (list): List of MSISDN identifiers for devices
        iccids (list): List of ICCID identifiers for devices
        bulkchange_id (int): Unique identifier for the bulk change request
        bulk_change_data (list): Processed bulk change data to be sent to Lambda
        device_status_id (int, optional): Device status identifier for status change operations
    
    Returns:
        dict or None: Lambda invoke response if successful, None if failed
    """
    logging.info(f"### bulkchange_lambda_caller bulkchange_id:{bulk_change_data}")
    
    # step-1 : Extract required parameters from request data
    tenant_name = data.get("tenant_name")
    rolename = data.get("role_name")
    username = data.get("username")
    request_received_at = data.get("request_received_at")
    access_token = data.get("access_token")
    db_name = data.get("db_name")
    sessionID = data.get("sessionID")
    change_type = data.get("change_event_type")
    changed_data = data.get("changed_data")
    service_provider = data.get("service_provider_display_name")
    bulk_change_lambda = os.getenv("bulk_change_lambda")
    parent_provider_name=data.get("parent_provider_name","")

    start_time = time.time()
    # step-2 : Extract the required values from changed data 
    # Normalize changed_data
    if isinstance(changed_data, dict):
        # Single record → convert to list of one dict
        changed_data = [changed_data]
    elif isinstance(changed_data, list):
        # Already a list → use as is
        pass
    else:
        # Invalid type
        return {"flag": False, "message": "changed_data must be a dict or a list of dicts"}
    # Extract modified_by from first record
    first_record = changed_data[0] if changed_data else {}
    # account_number = data["changed_data"][0]["account_number"]
    account_number = None
    if isinstance(changed_data, list) and changed_data:
        # changed_data is a non-empty list
        account_number = changed_data[0].get("account_number")
    elif isinstance(changed_data, dict):
        # changed_data is a dict
        account_number = changed_data.get("account_number")
    ### future effective date handling : 
    effective_date = first_record.get("effective_date")    
    modified_by = first_record.get("modified_by")
    # step-3 : connection to database 
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as db_exception:
        logging.error(f"### create_schedule Failed to connect to the database:{str(db_exception)}")
        return {"error": "Database connection failed.", "details": str(db_exception)}
    # assign customer change type validation 
    if change_type == 'Assign Customer' and ('Telegence' in service_provider or 'Telegence' in parent_provider_name):
        msisdn_key=msisdns
    else:
        msisdn_key=iccids
    try:
        execution_type = "Immediate"
        # Future effective date handling condition
        effective_dt = None
        if effective_date:
            try:
                effective_dt = datetime.strptime(effective_date, "%Y-%m-%d").date()
            except ValueError:
                effective_dt = None

        today_date = datetime.utcnow().date()
        is_future = effective_dt is not None and effective_dt > today_date
        
        # step-4 : check the effective date is future date or not incase of change type is Change Customer Rate Plan/Assign Customer if yes then call scheduler 
        if change_type in ["Change Customer Rate Plan", "Assign Customer"] and is_future:
            execution_type = "Scheduled"
            logging.info(f"### Date Comparison | effective_date: {effective_date} | effective_dt: {effective_dt} | today_date: {today_date} | is_future: {is_future}")
            logging.info("#### bulkchange_lambda_caller entered Scheduled block")
            scheduler_payload = {"data":{
                "tenant_name": tenant_name,
                "path": "/schedule_bulk_change_execution",
                "role_name": rolename,
                "username": username,
                "request_received_at": request_received_at,
                "access_token": access_token,
                "db_name": db_name,
                "sessionID": sessionID,
                "service_provider": service_provider,
                "change_type": change_type,
                "created_by": modified_by,
                "changed_data": bulk_change_data,
                "msisdns": msisdns,
                "iccids": msisdn_key,
                "bulk_change_id": bulkchange_id,
                "account_number": account_number,
                "device_status_id": device_status_id,
                "source": "Inventory",
                "parent_provider_name": parent_provider_name
            }}
            actual_payload = json.dumps(scheduler_payload).encode("utf-8")
        # step-5 : if the effective date is not future date then call the bulk change processor     
        else:
            logging.info(f"#### bulkchange_lambda_caller entered Immediate block")
            execution_type = "Immediate"
            lambda_payload = {
                "data": {
                    "tenant_name": tenant_name,
                    "path": "/bulk_change_processor",
                    "role_name": rolename,
                    "username": username,
                    "request_received_at": request_received_at,
                    "access_token": access_token,
                    "db_name": db_name,
                    "sessionID": sessionID,
                    "service_provider": service_provider,
                    "change_type": change_type,
                    "created_by": modified_by,
                    "changed_data": bulk_change_data,
                    "msisdns": msisdns,
                    "iccids": msisdn_key,
                    "bulk_change_id": bulkchange_id,
                    "account_number": account_number,
                    "device_status_id": device_status_id,
                    "source": "Inventory",
                    "parent_provider_name": parent_provider_name
                }
            }
            actual_payload = json.dumps(lambda_payload).encode("utf-8")

        logging.info(f"### bulkchange_lambda_caller actual_payload:{actual_payload} and execution_type : {execution_type}")
        # step-6 : call the schedular / bulk change processor apis dynamically 
        lambda_client = boto3.client('lambda')
        invoke_response = lambda_client.invoke(
            FunctionName=bulk_change_lambda,
            InvocationType='Event',
            Payload=actual_payload,
        )

        logging.info(f"### bulkchange_lambda_caller invoke_response:{invoke_response}")

        # setp-7 : auditing in success case
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "bulkchange_lambda_caller",
                "created_by": username,
                "status": "True",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "comments": f"successful call bulk change lambda for change type {change_type}, execution_type: {execution_type} with payload : {actual_payload}",
                "module_name": "Sim Management",
                "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### bulkchange_lambda_caller audit_user_actions Exception is {e}")
        return invoke_response

    except Exception as e:
        logging.exception(f"### bulkchange_lambda_caller Error: {e}")
        #setp-8 : auditing in Error case
        try:
            error_data = {
                "service_name": "bulkchange_lambda_caller",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"call bulkc change lambda failed for chnage type {change_type}",
                "module_name": "Sim management",
                "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### bulkchange_lambda_caller error_log_table exception : {e}")
        return None
    
    
def normalize_bulk_change_request(v):
    if isinstance(v, str):
        if v.strip() in ["True", "False"]:
            return v.strip() == "True"
        if v.isdigit():
            return int(v)
        # try JSON first
        try:
            return json.loads(v)
        except Exception:
            pass
        # try Python literal (handles "{'mode':'M','reasonCode':'CR'}")
        try:
            return ast.literal_eval(v)
        except Exception:
            return v
    return v
