"""
main.py

Module for handling API requests and routing them to the appropriate function.

Functions:
- lambda_handler(event,context=None)
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24

"""
##importing necessary libraries
import json
import time
import os
import boto3
import pytz
import datetime
import base64
from datetime import datetime
from common_utils.email_trigger import get_memory_usage, memory_sns
from Inventory import function_caller
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from common_utils.authentication_check import get_client_id


# Dictionary to store database configuration settings retrieved from environment variables.
common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }

logging = Logging(name="main")


def lambda_handler(event, context):
    """
    Handles incoming API requests and routes them to the appropriate function.

    Args:
        event (dict): The incoming API request event.

    Returns:
        dict: A dictionary containing the response status code and body.

    Example:
        >>> event = {'data': {'path': '/get_modules'}}
        >>> lambda_handler(event)
        {'statusCode': 200, 'body': '{"flag": True, "modules": [...]}'}
    """
    function_name = context.function_name if context else "sim_management"
    logging.info("Lambda function started: %s", function_name)
    value=None
    result=None
    # Record the start time of the function
    performance_matrix = {}
    start_time = time.time()
    performance_matrix["start_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}."
        f"{int((start_time % 1) * 1000):03d}"
    )


    data = event.get("data")
    if not data:
        return {"message": "No details provided or Invalid details", "status_code": 400}

    if data:
        try:
            data = data
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid JSON in body"}),
            }
    else:
        data = {}

    if "data" in data:
        data = data.get("data")

    service_path = event.get("path")
    if service_path:
        data["path"] = service_path

    path = data.get("path")

    result = {}
    # token validation
    verified_request = True
    access_token = data.get("z_access_token", "")
    ui_token = data.get("access_token", "")
    # Capture the hit time when the request is received (same as before)
    hit_time = time.time()
    hit_time_formatted = datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
        "%Y-%m-%d %H:%M:%S"
    )
    logging.info(
        f"Hit Time: {hit_time_formatted}, Request Received at: {hit_time_formatted}"
    )

    if access_token:
        client_id = get_client_id(access_token)
        data["client_id"] = client_id
        data["username"] = client_id
        logging.info("Client ID: %s", client_id)
    
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config

    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_platform_flag=False
        
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }    


    request_received_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info("Routing request for path: %s", path)
    # Route based on the path and method
    if verified_request:
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
        try:
            if tenant_name:
                billing_platform_flag=common_utils_database.get_data('tenant',{"tenant_name":tenant_name},['billing_platform_flag'])['billing_platform_flag'].to_list()[0]
            else:
                billing_platform_flag=False
        except Exception as e:
            logging.exception(f"Exception occured while fecthing the billing platform flag: {e}")
        data['billing_platform_flag']=billing_platform_flag
        result=function_caller(data,path,access_token)
        value = result.get('flag') if result is not None else False
    # database Connection
    if value == False:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        
        status_code = 400  # You can change this to an appropriate error code
        logging.error("Error in result: %s", result)
        # Sending email
        try:
            result_response = send_email("Exception Mail")
            if isinstance(result, dict) and result.get("flag") is False:
                logging.info(result)
            else:
                to_emails, cc_emails, subject, body, from_email, partner_name = (
                    result_response
                )
                common_utils_database.update_dict(
                    "email_templates",
                    {"last_email_triggered_at": request_received_at},
                    {"template_name": "Exception Mail"},
                )
                query = """
                    SELECT parents_module_name, sub_module_name, child_module_name, partner_name
                    FROM email_templates
                    WHERE template_name = 'Exception Mail'
                """
                # Execute the query and fetch the result
                email_template_data = common_utils_database.execute_query(query, True)
                if not email_template_data.empty:
                    # Unpack the results
                    (
                        parents_module_name,
                        sub_module_name,
                        child_module_name,
                        partner_name,
                    ) = email_template_data.iloc[0]
                else:
                    # If no data is found, assign default values or log an error
                    parents_module_name = ""
                    sub_module_name = ""
                    child_module_name = ""
                    partner_name = ""

                # Email audit logging
                error_message = result.get(
                    "error", "Unknown error occurred"
                )  # Extracting the error message
                email_audit_data = {
                    "template_name": "Exception Mail",
                    "email_type": "Application",
                    "partner_name": partner_name,
                    "email_status": "success",
                    "from_email": from_email,
                    "to_email": to_emails,
                    "cc_email": cc_emails,
                    "comments": f"{path} - Error: {error_message}",  # Adding error message to comments
                    "subject": subject,
                    "body": body,
                    "action": "Email triggered",
                    "parents_module_name": parents_module_name,
                    "sub_module_name": sub_module_name,
                    "child_module_name": child_module_name,
                }
                common_utils_database.update_audit(email_audit_data, "email_audit")
        except:
            pass

    elif value == True:
        status_code = 200
    else:
        status_code = 500
        result = {"message": "Something went wrong, while processing the request!"}

    # Capture the request completion time in IST
    request_completed_time = time.time()
    request_completed_time_formatted = datetime.now(
        pytz.timezone("Asia/Kolkata")
    ).strftime("%Y-%m-%d %H:%M:%S")

    # Calculate the time difference between hit time and request completed time
    time_taken = round(
        request_completed_time - hit_time, 4
    )  # Round to 4 decimal places
    logging.info(
        f"Request Completed: {request_completed_time_formatted}, Time Taken: {time_taken} seconds"
    )

    # Record the end time of the function
    end_time = time.time()
    performance_matrix["end_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )
    performance_matrix["execution_time"] = f"{end_time - start_time:.4f}"
    logging.info(
        f"Request processed at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
    )

    performance_matrix["execution_time"] = f"{end_time - start_time:.4f} seconds"
    logging.info(f"Function performance_matrix: {performance_matrix} seconds")
    logging.info(
        "Lambda function execution completed in %.4f seconds", end_time - start_time
    )

    memory_limit = int(context.memory_limit_in_mb)
    memory_used = int(get_memory_usage()) + 100
    final_memory_used = get_memory_usage()
    logging.info(
        f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
    )
    memory_sns(memory_limit, memory_used, context)

    if access_token or (not access_token and not ui_token):
        if 'flag' in result:
            result.pop('flag')
        if "status_code" in result:
            return result
        else:
            return result
    else:
        return {
            "statusCode": status_code,
            "body": json.dumps(result),
            "performance_matrix": json.dumps(performance_matrix),
            "started": hit_time_formatted,
            "time_taken": time_taken,
            "request_completed_time_formatted": request_completed_time_formatted,
        }
