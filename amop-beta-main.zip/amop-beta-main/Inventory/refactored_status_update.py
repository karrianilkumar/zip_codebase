"""
@Author1 : Ajay
Created Date: 12-09-2025
"""

import json
from common_utils.logging_utils import Logging
from inventory_utils import bulkchange_lambda_caller,normalize_bulk_change_request
from config.carrier_config_manager import CarrierConfigManager

logging = Logging(name="status_update")
config_manager = CarrierConfigManager()
      

def send_device_update_status_bulk(
    data,
    tenant_database,
    service_provider,
    device_status,
    changed_data,
    bulk_change_id,
    status_id,
    tenant_data,
    inventory_data,
    mode,
    reason_code,
    common_utils_database_config
):
    """
    Processes bulk device status updates by building carrier-specific requests.
    
    This function creates bulk change request records for device status updates,
    handling different carrier configurations and request formats. It processes
    inventory data, builds carrier-specific payloads, and stores requests for
    asynchronous processing.
    
    Args:
        data (dict): Original request data
        tenant_database (DB): Database connection for tenant-specific operations
        service_provider (str): Name of the service provider/carrier
        device_status (str): Target device status (e.g., 'active', 'suspended')
        changed_data (list): List of device records to update
        bulk_change_id (int): ID of the bulk change operation
        status_id (int): Device status ID
        tenant_data (DataFrame): Tenant information
        inventory_data (DataFrame): Device inventory data
        mode (str): Update mode
        reason_code (str): Reason code for status change
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - processed_count (int, optional): Number of records processed
    
    Raises:
        Exception: Any errors during request building or database operations
    """
    
    # Build base request parameters
    request_params = {
        "device_status": device_status,
        "Request": {},
        "IsIgnoreFlag": False,
        "IntegrationId": 0,
        "PostUpdateStatusId": status_id,
        "mode": mode,
        "reasonCode": reason_code,
        "activation_profile": changed_data[0].get("activation_profile", ""),
    }

    # Build request config
    request_config = config_manager.build_request_config(
        service_provider, "bulk_status_update", **request_params
    )
    logging.info(f"### send_device_update_status_bulk request_config: {request_config}")

    if not request_config:
        return {
            "flag": False,
            "message": f"Failed to build request config for: {service_provider}",
        }
    
    try:
        # Normalize request values
        change_request_dict = {
            k: normalize_bulk_change_request(v)
            for k, v in request_config.get("change_request", {}).items()
        }

        thingsspace_template = change_request_dict.pop("ThingsSpaceHandler", None)
        case_update = change_request_dict.pop("CaseUpdateHandler", None)
        if case_update:
            change_request_dict["UpdateStatus"] = device_status.upper()
        base_change_request = json.dumps(change_request_dict)

        # Extract tenant metadata
        created_by = changed_data[0].get("modified_by")
        tenant_name = tenant_data["tenant_name"].iloc[0]
        tenant_id = int(tenant_data["id"].iloc[0])

        sim_management_bulk_change_request = []
        processed_iccids, processed_msisdns = [], []

        for record in changed_data:
            rec_id = record.get("id")
            inv_row = inventory_data[inventory_data["id"] == rec_id]

            if inv_row.empty:
                continue

            iccid = inv_row["iccid"].iloc[0]
            msisdn = inv_row["msisdn"].iloc[0] if "msisdn" in inv_row.columns else None
            device_id = inv_row["device_id"].iloc[0] if "device_id" in inv_row.columns else None

            processed_iccids.append(iccid)
            processed_msisdns.append(msisdn)

            # Build request JSON for ThingsSpace
            change_request = base_change_request
            try:
                if thingsspace_template:
                    # Rate Plan
                    rate_plan_code = record.get("rate_plan_code", "")
                    rate_plan_code = rate_plan_code.split("--")[0].strip() if "--" in rate_plan_code else rate_plan_code
                    change_request = change_request.replace("{RatePlanCode}", rate_plan_code)

                    # Telegence details
                    telegence_additional_details = record.get("telegence_additional_details", [])
                    thingSpacePPU = telegence_additional_details[0] if telegence_additional_details else {}

                    replacements = {
                        "{MdnZipCode}": str(thingSpacePPU.get("ZipCode", "")),
                        "{ipAddress}": str(thingSpacePPU.get("IPAddress", "")),
                        "{IMEI}": str(thingSpacePPU.get("IMEI", "")),
                        "{ICCID}": iccid or "",
                    }

                    for placeholder, value in replacements.items():
                        change_request = change_request.replace(placeholder, value)

                    # Proper JSON object for nested thingSpacePPU
                    thingSpacePPU_json = json.dumps(thingSpacePPU)
                    change_request = change_request.replace("\"{thingSpacePPU}\"", thingSpacePPU_json)

            except Exception as e:
                logging.error(f"### send_device_update_status_bulk error while building change_request: {e}")

            # Append request record
            sim_management_bulk_change_request.append({
                "iccid": iccid,
                "subscriber_number": msisdn,
                "bulk_change_id": str(bulk_change_id),
                "tenant_name": tenant_name,
                "created_by": created_by,
                "processed_by": created_by,
                "status": "NEW",
                "device_id": int(device_id) if device_id else None,
                "tenant_id": tenant_id,
                "is_active": True,
                "is_deleted": False,
                "change_request": change_request,
            })

        # Insert to DB
        if sim_management_bulk_change_request:
            tenant_database.insert_data(
                sim_management_bulk_change_request,
                "sim_management_bulk_change_request",
            )

        logging.info(f"### send_device_update_status_bulk change_request: {change_request}")

        # Call bulkchange lambda handler
        response = bulkchange_lambda_caller(
            data,
            processed_msisdns,
            processed_iccids,
            bulk_change_id,
            change_request_dict,
            common_utils_database_config=common_utils_database_config,
            device_status_id=status_id
        )

        logging.info(f"### send_device_update_status_bulk bulkchange_lambda_caller response: {response}")
        return {"flag": True, "message": response}
    except Exception as e:
        logging.error(f"### send_device_update_status_bulk error: {e}")
        return {"flag": False, "message": f"An error occurred during bulk update"}

