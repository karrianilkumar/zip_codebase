import os
import re
import json
import time
import datetime
import pandas as pd # type: ignore

from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import serialize_data
from inventory_utils import (
    load_integration_authentication_json,
    get_integration_authentication_id_by_unique_name,
    load_json,
    get_provider_ids,
    clean_tuple
)

logging = Logging(name="change_type_dropdown")


def customers_dropdown_inventory(data,db_config,common_utils_database_config):
    """
    Fetches the customer names associated with a given service provider, either by service provider name or ID,
    depending on the specified module.

    Parameters:
        data (dict): A dictionary containing the following keys:
            - 'module_name' (str): The module name (e.g., 'SimManagement Inventory').
            - 'service_provider' (str): The name of the service provider (required if 'module_name' is not 'SimManagement Inventory').
            - 'service_provider_id' (str): The ID of the service provider (required if 'module_name' is 'SimManagement Inventory').
            - 'db_name' (str): The name of the tenant database to connect to.

    Returns:
        dict: A dictionary with the following keys:
            - 'flag' (bool): Indicates whether the operation was successful.
            - 'customer_name' (list): A list of customer names associated with the service provider.
              If no customers are found, an empty list is returned.
            - 'message' (str, optional): An error message if the operation failed (e.g., no active service provider found).
    """
    module_name = data.get("module_name", "")
    service_provider_name = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "6")
    billing_platform_flag=data.get('billing_platform_flag',False)
    role_name = data.get("role_name", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    tenant_name = data.get("tenant_name", "")
    if db_config and "billing_account_number" in db_config:
        del db_config["billing_account_number"]
    if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
    else:
        # Default case: fetch only from the database
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

    parent_result = common_utils_database.get_data(
    table_name="tenant",
    condition={"tenant_name": tenant_name},  # safe filter
    columns=["parent_tenant_id"])

    # Extract parent_tenant_id safely
    if parent_result is not False and not parent_result.empty:
        parent_tenant_id = parent_result["parent_tenant_id"].iloc[0]
    else:
        parent_tenant_id = None  # or handle error case
        
    role_module_data = common_utils_database.get_data(
        "role_module",
        {"role": role_name},
        ["sub_module"],
    )

    # Initialize default status
    module_status = False

    if not role_module_data.empty:
        try:
            # Parse JSON safely with fallback
            sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

            # Strict nested check
            if "People" in sub_modules:
                people_modules = sub_modules["People"]
                if isinstance(people_modules, list):  # Ensure it's a list
                    module_status = "Billing Customers" in people_modules

        except json.JSONDecodeError:
            logging.error(f"Invalid JSON in sub_module for role: {role_name}")
        except KeyError:
            pass  # People section not present
        except Exception as e:
            logging.error(f"Unexpected error processing modules: {str(e)}")
    integration_authentication_json_data = load_integration_authentication_json()
    integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
    if not integration_authentication_id:
        parent_result = common_utils_database.get_data(
            table_name="tenant",
            condition={"tenant_name": tenant_name},  # safe parameter binding
            columns=["parent_tenant_id"]
        )

        # Extract parent_tenant_id safely
        if parent_result is not False and not parent_result.empty:
            parent_tenant_id = parent_result["parent_tenant_id"].iloc[0]
            if parent_tenant_id:
                parent_tenant_id = int(parent_tenant_id)
        else:
            parent_tenant_id = None  # or handle as needed    
        parent_result = common_utils_database.get_data(
            table_name="tenant",
            condition={"id": parent_tenant_id},  # safe parameter binding
            columns=["tenant_name"]
        )

        # Extract tenant_name safely
        if parent_result is not False and not parent_result.empty:
            parent_tenant_name = parent_result["tenant_name"].iloc[0]

            # Use it in your existing function
            integration_authentication_id = get_integration_authentication_id_by_unique_name(
                integration_authentication_json_data,
                parent_tenant_name
            )
        else:
            parent_tenant_name = None
            integration_authentication_id = None
    
    # Initialize DB connection
    try:
        tenant_database = data.get("db_name", "")
        # database Connection
        database = DB(tenant_database, **db_config)
        # Get the service provider namee
        
        if module_name == "SimManagement Inventory":
            service_provider_query = database.get_data(
                "serviceprovider",
                {"is_active": True, "id": service_provider_id},
                ["id"],
            )

            if service_provider_query.empty:
                # Handle case where no service provider was found
                return {
                    "flag": False,
                    "message": "No active service provider found with the provided name.",
                }
            # Extract the service provider name
            service_provider_id = service_provider_query["id"].to_list()[0]

            if module_status and tenant_name != 'WingTel' and billing_platform_flag is False:
                # Only revcustomer query
                df = database.get_data(
                    "revcustomer",
                    {
                    "is_active": True,
                    "bp_customer":False,
                    "integration_authentication_id": integration_authentication_id,
                    "tenant_id": tenant_id,
                    "status": ['open', 'Open', 'OPEN'],
                    },
                    ["customer_name", "rev_customer_id"],
                )
                df.rename(columns={"rev_customer_id": "id"}, inplace=True)
                if df.empty:
                    # Only customers query
                    df = database.get_data(
                        "customers",
                        {
                        "tenant_id": str(tenant_id),
                        "is_active": True
                        },
                        ["customer_name", "id"],order={"customer_name": "asc"}
                    )

            elif module_status and billing_platform_flag:
                # Both revcustomer AND customers queries
                df1 = database.get_data(
                    "revcustomer",
                    {
                    "is_active": True,
                    "bp_customer":False,
                    "integration_authentication_id": integration_authentication_id,
                    "tenant_id": tenant_id,"status":['open', 'Open', 'OPEN']
                    },
                    ["customer_name", "rev_customer_id"]
                ).rename(columns={"rev_customer_id": "id"})
                df1["customer_name"] = df1["customer_name"] + " -- RevIO"

                df2 = database.get_data(
                    "customers",
                    {"tenant_id": str(tenant_id), "is_active": True,"billing_platform_flag":True},
                    ["customer_name", "id"],
                )
                df2["customer_name"] = df2["customer_name"] + " -- BP"

                df = pd.concat([df1, df2], ignore_index=True, sort=False)
                

            else:
                # Only customers query
                df = database.get_data(
                    "customers",
                    {
                    "tenant_id": str(tenant_id),
                    "is_active": True
                    },
                    ["customer_name", "id"],
                )

            # Now map to customer_names list/dict
            if df.empty:
                customer_names = []
            else:
                df = df.rename(columns={"id": "customer_id"})
                # Create dict sorted by customer_name
                customer_names = dict(
                    sorted(zip(df["customer_name"], df["customer_id"]), key=lambda x: x[0])
                )
        else:
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
                service_provider_query = database.get_data(
                    "serviceprovider",
                    {"is_active": True, "service_provider_name": service_provider_name},
                    ["service_provider_name"],
                )
            else:
                service_provider_query = database.get_data(
                    "serviceprovider",
                    {"is_active": True, "service_provider_name": service_provider_name},
                    ["service_provider_name"],
                )

            if service_provider_query.empty:
                # Handle case where no service provider was found
                return {
                    "flag": False,
                    "message": "No active service provider found with the provided name.",
                }
            # Extract the service provider name
            service_provider_name = service_provider_query[
                "service_provider_name"
            ].to_list()[0]

            if module_status and tenant_name != 'WingTel' and billing_platform_flag is False:
                # Only revcustomer query
                df = database.get_data(
                    "revcustomer",
                    {
                    "is_active": True,
                    "bp_customer":False,
                    "integration_authentication_id": integration_authentication_id,
                    "tenant_id": tenant_id,
                     "status": ['open', 'Open', 'OPEN'],
                    },
                    ["customer_name", "rev_customer_id"],
                )
                df.rename(columns={"rev_customer_id": "id"}, inplace=True)

            elif module_status and billing_platform_flag:
                # Both revcustomer AND customers queries
                df1 = database.get_data(
                    "revcustomer",
                    {
                    "is_active": True,
                    "bp_customer":False,
                    "integration_authentication_id": integration_authentication_id,
                    "tenant_id": tenant_id,
                     "status": ['open', 'Open', 'OPEN'],
                    },
                    ["customer_name", "rev_customer_id"],
                )
                df1.rename(columns={"rev_customer_id": "id"}, inplace=True)

                df2 = database.get_data(
                    "customers",
                    {
                    "tenant_id": str(tenant_id),
                    "is_active": True,
                    "billing_platform_flag": billing_platform_flag
                    },
                    ["customer_name", "id"],
                )
                # Combine both DataFrames vertically
                df2.rename(columns={"bp_account_number": "id"}, inplace=True)
                df = pd.concat([df1, df2], ignore_index=True, sort=False)  # :contentReference[oaicite:1]{index=1}

            else:
                # Only customers query
                df = database.get_data(
                    "customers",
                    {
                    "tenant_id": str(tenant_id),
                    "is_active": True,
                    "billing_platform_flag": billing_platform_flag
                    },
                    ["customer_name", "id"],
                )

            # Now map to customer_names list/dict
            if df.empty:
                customer_names = []
            else:
                df = df.rename(columns={"id": "customer_id"})
                customer_names = dict(zip(df["customer_name"], df["customer_id"]))

        # Return the final response
        return {"flag": True, "customer_name": customer_names, "module_status":module_status}
    except Exception as e:
        message = f"An error occurred during the import: {str(e)}"
        error_type = type(e).__name__
        try:
            error_data = {
                "service_name": "customers_dropdown_inventory",
                "created_date": data.get("request_received_at"),
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": tenant_database,
                "comments": message,
                "module_name": "Inventory",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(f"Failed to log error to database: {logging_error}")
        return {"flag": False, "customer_name": []}



def carrier_activation_date_rate_plans(data,db_config_withoutfilter,common_utils_database_config):
    """
    Retrieves carrier activation date and eligible rate plans for a specific ICCID.
    
    This function fetches the last activation date for a device and returns customer
    rate plans that are configured to use carrier activation dates.
    
    Args:
        data (dict): Request data containing:
            - iccid (str): ICCID of the device to query
            - db_name (str): Database name for tenant-specific queries
            - tenant_name (str): Name of the tenant
            - username (str, optional): Username for error logging
            - session_id (str, optional): Session ID for error logging
            - request_received_at (str, optional): Request timestamp for error logging
        db_config (dict): Database configuration parameters
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - activation_date: Last activation date for the device
            - rate_plans (list): Sorted list of rate plan names that use carrier activation
    
    Raises:
        ValueError: If ICCID is not provided or no activation date is found
    """
    try:
        logging.info(f"Received request data for carrier_activation_date_rate_plans: {data}")
        iccid = data.get("iccid",None)
        msisdn = data.get("msisdn",None)
        tenant_database = data.get("db_name", "")
        tenant_name = data.get("tenant_name",None)
        # Fetching the tenant id
        if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
        else:
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        if not iccid and not msisdn:
            raise ValueError("ICCID or MSISDN is required to fetch carrier activation date.")
        database = DB(tenant_database, **db_config_withoutfilter)

        # Fetch rate plans that are active and use carrier activation
        rate_plans = database.get_data("customerrateplan", {"use_carrier_activation": True, "is_active": True}, ["rate_plan_name"])
        
        filter_condition = {"tenant_id": tenant_id, "is_active":True}
        if iccid:
            filter_condition["iccid"] = iccid
        if msisdn:
            filter_condition["msisdn"] = msisdn
        
        activation_result = database.get_data(
            table_name="sim_management_inventory",
            condition=filter_condition,  # safe parameter binding
            columns=["last_activated_date"]
        )

        # Extract activation date safely
        if activation_result is False or activation_result.empty:
            raise ValueError("No activation date found for the provided ICCID.")

        activation_date = activation_result["last_activated_date"].iloc[0]

        logging.info(f"Carrier activation date for ICCID {iccid} is {activation_date}.")
        
        return serialize_data({
            "flag": True,
            "activation_date": activation_date,
            "rate_plans": sorted(rate_plans["rate_plan_name"].to_list())
        })
    except Exception as e:
        logging.info(f"Error fetching details for carrier_activation_date_rate_plans: {e}")
        error_type = type(e).__name__
        try:
            error_data = {
                "service_name": "carrier_activation_date_rate_plans",
                "created_date": data.get("request_received_at"),
                "error_message": str(e),
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": tenant_database,
                "comments": "carrier activation data rate plans failed",
                "module_name": "Inventory",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as logging_error:
            logging.error(f"### carrier_activation_date_rate_plans error_log_table exception: {logging_error}")
        return {
            "flag": False,
            "activation_date": None,
            "rate_plans": []
        }
    
def inventory_dropdowns_data(data, db_config,common_utils_database_config):
    """
    Retrieves dropdown data for inventory management based on dropdown type.
    
    This function fetches various dropdown options including carrier rate plans,
    communication plans, customer rate plans, and rate pools based on the specified
    dropdown type and service provider.
    
    Args:
        data (dict): Request data containing:
            - dropdown (str): Type of dropdown data to fetch ("Carrier Rate Plan", etc.)
            - service_provider_id (str): ID of the service provider
            - db_name (str): Database name for tenant-specific queries
            - Partner (str): Partner/tenant name
            - username (str, optional): Username for error logging
            - session_id (str, optional): Session ID for error logging
            - request_received_at (str, optional): Request timestamp for error logging
        db_config (dict): Database configuration parameters
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - communication_rate_plan_list (dict): Mapping of rate plans to communication plans
            - rate_plan_list (list): List of formatted rate plan names
            - rate_plan_code_list (list): List of rate plan codes
            - communication_plan_list (list): List of communication plan names
            - rate_pool_list (list, optional): List of customer rate pools
            - message (str): Status message
    """
    try:
        del db_config['feature_codes']
    except Exception as e:
        logging.exception(f"Exception while removing db config variables: {e}")
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    # Extract parameters from the input data
    dropdown = data.get("dropdown", "")
    # Retrieve service provider ID based on the list view data ID
    service_provider_id = data.get("service_provider_id", "")
    logging.info(f"Service provider ID retrieved: {service_provider_id}")
    Partner = data.get("Partner", "")
    common_utils_database = DB( os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    start_time = time.time()

    if Partner == "Altaworx Test":
        tenant_id = 1  # Hardcoded ID for test tenant
    else:
        # Fetch tenant ID from database
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": Partner}, ["id"]
        )["id"].to_list()[0]
    try:
        if dropdown == "Carrier Rate Plan":
            service_provider = database.get_data(
                "serviceprovider",
                {"id":service_provider_id},
                ["service_provider_name"]
            )["service_provider_name"].to_list()[0]
            # Retrieve rate plans for the specified service provider
            rate_plan_list_data = database.get_data(
                "sim_management_communication_plan",
                {
                    "service_provider_id": service_provider_id,"is_active":True, "tenant_id":tenant_id
                },  # Use the retrieved service_provider_id
                ["communication_plan_name"],
            )

            # Convert the DataFrame column to a list
            communication_plan_list = rate_plan_list_data["communication_plan_name"].to_list()
            # Retrieve rate plans for the specified service provider

            carrier_data = database.get_data(
                table_name="carrier_rate_plan",
                condition={"service_provider_id": service_provider_id, "is_active": True},  # safe filter
                columns=["rate_plan_code", "friendly_name"],
                order={"friendly_name": "asc"}  # ordering safely
            )

            # Combine friendly_name and rate_plan_code as before
            if carrier_data is not False and not carrier_data.empty:
                carrier_data['temp_name'] = carrier_data['friendly_name'].combine_first(
                    carrier_data['rate_plan_code']
                )
            else:
                carrier_data = pd.DataFrame(columns=["rate_plan_code", "friendly_name", "temp_name"])

            rate_plan_list = (
                (carrier_data['temp_name'] + ' -- ' + carrier_data['rate_plan_code'].fillna(""))
                .drop_duplicates()
                .to_list()
            )


            # Convert the DataFrame column to a list
            rate_plan_code_list = carrier_data["rate_plan_code"].drop_duplicates().to_list()


            # Check if there are any rate plans to process
            if not rate_plan_list:
                logging.info("No rate plans found.")
                response = {
                    "flag": True,
                    "communication_rate_plan_list": {},
                    "rate_plan_list":[],
                    "rate_plan_code_list": [],
                    "communication_plan_list":[],
                    "message": 'No Rate Plans Found',
                }
                return response
            else:
                # Prepare the query to get all communication plans for the rate plans in one go
                placeholders = ", ".join(["%s"] * len(rate_plan_code_list))
                query = f"""
                SELECT carrier_rate_plan_name, communication_plan_name
                FROM public.smi_communication_plan_carrier_rate_plan
                WHERE carrier_rate_plan_name IN ({placeholders});
                """
                # Execute the query with the rate_plan parameters
                df = database.execute_query(query, params=rate_plan_code_list)

                # Handle empty results safely
                if df is False or df.empty:
                    df = pd.DataFrame(columns=["carrier_rate_plan_name", "communication_plan_name"])

                # Initialize a dictionary with all rate plan keys and empty lists
                communication_plans_dict = {plan: [] for plan in rate_plan_code_list}

                # Check if df is a DataFrame and has results
                if isinstance(df, pd.DataFrame) and not df.empty:
                    for _, row in df.iterrows():
                        plan_name = row["carrier_rate_plan_name"]
                        comm_plan_name = row["communication_plan_name"]
                        communication_plans_dict[plan_name].append(comm_plan_name)
                else:
                    logging.info("No results found or query failed.")

                def sorted_unique(data_list):
                    """Helper function to sort a list and remove any None values."""
                    return sorted(filter(None, set(data_list)))

                optimization_group_dropdown = sorted_unique(
                    database.get_data(
                        "optimization_group",
                        {"service_provider_name": service_provider, "is_active": True},
                        ["optimization_group_name"],
                    )["optimization_group_name"].to_list()
                )

                # Now you can work with the communication_plans_dict as needed
                logging.info(communication_plans_dict)
                # Prepare and return the response
                message = "Dropdown data fetched successfully"
                response = {
                    "flag": True,
                    "communication_rate_plan_list": communication_plans_dict,
                    "communication_plan_list":sorted(communication_plan_list, key=lambda x: (x is None, x)) if communication_plan_list else [],
                    "rate_plan_list":sorted(rate_plan_list, key=lambda x: (x is None, x)) if rate_plan_list else [],
                    "rate_plan_code_list": sorted(rate_plan_code_list, key=lambda x: (x is None, x)) if rate_plan_code_list else [],
                    "optimization_group_dropdown": optimization_group_dropdown,
                    "message": message,
                }
                try:
                   # End time calculation
                    end_time = time.time()
                    time_consumed = f"{end_time - start_time:.4f}"
                    time_consumed = int(float(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "inventory_dropdowns_data",
                        "created_by": data.get("username", " "),
                        "status": str(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "session_id": data.get("session_id", " "),
                        "tenant_name": Partner,
                        "comments": f"fetching inventory dropdown data - {dropdown}",
                        "module_name": "Sim Management",
                        "request_received_at": data.get("request_received_at", datetime.datetime.now()),
                    }
                    common_utils_database.update_audit(
                        audit_data_user_actions, "audit_user_actions"
                    )
                except Exception as e:
                    logging.exception(f"### inventory_dropdowns_data audit_user_actions Exception is {e}")
                return response
       
        elif dropdown == "Update Communication Plan":
            comm_plan_df = pd.DataFrame()
            # Fetch communication plans for selected service provider
            comm_plan_df = database.get_data(
                "sim_management_communication_plan",
                {
                    "service_provider_id": service_provider_id,
                    "is_active": True
                },
                ["communication_plan_name"]
            )

            # Convert to list safely
            communication_plan_list = (
                comm_plan_df["communication_plan_name"]
                .dropna()
                .replace([None], pd.NA)
                .dropna()
                .drop_duplicates()
                .tolist()
                if comm_plan_df is not False and not comm_plan_df.empty
                else []
            )

            response = {
                "flag": True,
                "communication_plan_list": sorted(communication_plan_list),
                "message": "Dropdown data fetched successfully"
            }
            return response
        
        elif dropdown=="Update PPU address":
            state= sorted(
                    [
                        {"name": "Alabama", "code": "AL"},
                        {"name": "Alaska", "code": "AK"},
                        {"name": "Arizona", "code": "AZ"},
                        {"name": "Arkansas", "code": "AR"},
                        {"name": "California", "code": "CA"},
                        {"name": "Colorado", "code": "CO"},
                        {"name": "Connecticut", "code": "CT"},
                        {"name": "District of Columbia", "code": "DC"},
                        {"name": "Delaware", "code": "DE"},
                        {"name": "Florida", "code": "FL"},
                        {"name": "Georgia", "code": "GA"},
                        {"name": "Hawaii", "code": "HI"},
                        {"name": "Idaho", "code": "ID"},
                        {"name": "Illinois", "code": "IL"},
                        {"name": "Indiana", "code": "IN"},
                        {"name": "Iowa", "code": "IA"},
                        {"name": "Kansas", "code": "KS"},
                        {"name": "Kentucky", "code": "KY"},
                        {"name": "Louisiana", "code": "LA"},
                        {"name": "Maine", "code": "ME"},
                        {"name": "Maryland", "code": "MD"},
                        {"name": "Massachusetts", "code": "MA"},
                        {"name": "Michigan", "code": "MI"},
                        {"name": "Minnesota", "code": "MN"},
                        {"name": "Mississippi", "code": "MS"},
                        {"name": "Missouri", "code": "MO"},
                        {"name": "Montana", "code": "MT"},
                        {"name": "Nebraska", "code": "NE"},
                        {"name": "Nevada", "code": "NV"},
                        {"name": "New Hampshire", "code": "NH"},
                        {"name": "New Jersey", "code": "NJ"},
                        {"name": "New Mexico", "code": "NM"},
                        {"name": "New York", "code": "NY"},
                        {"name": "North Carolina", "code": "NC"},
                        {"name": "North Dakota", "code": "ND"},
                        {"name": "Ohio", "code": "OH"},
                        {"name": "Oklahoma", "code": "OK"},
                        {"name": "Oregon", "code": "OR"},
                        {"name": "Pennsylvania", "code": "PA"},
                        {"name": "Rhode Island", "code": "RI"},
                        {"name": "South Carolina", "code": "SC"},
                        {"name": "South Dakota", "code": "SD"},
                        {"name": "Tennessee", "code": "TN"},
                        {"name": "Texas", "code": "TX"},
                        {"name": "Utah", "code": "UT"},
                        {"name": "Vermont", "code": "VT"},
                        {"name": "Virginia", "code": "VA"},
                        {"name": "Washington", "code": "WA"},
                        {"name": "West Virginia", "code": "WV"},
                        {"name": "Wisconsin", "code": "WI"},
                        {"name": "Wyoming", "code": "WY"},
                    ],
                    key=lambda x: x["name"],
                )
            message = "Dropdown data fetched successfully"
            response = {
                "flag": True,
                "state": state}
            return response
            
        else:
            try:
                service_provider_name=database.get_data('serviceprovider',{"id":service_provider_id},['service_provider_name'])['service_provider_name'].to_list()[0]
                customer_rate_plan_query = '''
                SELECT distinct rate_plan_name
                FROM public.customerrateplan
                WHERE service_provider_name LIKE %s AND is_active = True and tenant_id = %s
                '''

                # Define parameters for the query
                params = [f"%{service_provider_name}%", tenant_id]

                # Execute the query
                rate_plan_list = database.execute_query(customer_rate_plan_query, True, params=params)['rate_plan_name'].dropna().replace([None], pd.NA).dropna().tolist()

                # Query to fetch DISTINCT names and handle service_provider_id matching
                customer_rate_pool_query = '''
                SELECT name
                FROM public.customer_rate_pool
                WHERE (service_provider_id::text LIKE %s OR service_provider_ids LIKE %s)
                AND is_active = true and tenant_id = %s
                '''

                # Parameters for both placeholders (same value for both)
                params = [f"%{service_provider_id}%", f"%{service_provider_id}%", tenant_id]

                # Execute query
                df = database.execute_query(customer_rate_pool_query,params=params)

                # Extract unique names (if results exist)
                rate_pool_list = df["name"].drop_duplicates().replace([None], pd.NA).dropna().tolist() if df is not None and not df.empty else []


                # Remove duplicates (redundant if using DISTINCT, but safe to keep)
                rate_pool_list = list(set(rate_pool_list)) if rate_pool_list else None

                # Prepare and return the response
                message = "Dropdown data fetched successfully"
                response = {
                    "flag": True,
                    "rate_pool_list": sorted(rate_pool_list) if rate_pool_list else None,
                    "rate_plan_list": sorted(rate_plan_list) if rate_plan_list else [],
                    "message": message,
                }
                
                return response

            except Exception as e:
                # Handle any exceptions that occur in the else block
                logging.exception(
                    "Error occurred while fetching rate plan or rate pool data."
                )
                message = "Error occurred while fetching rate plan or rate pool data."
                response = {
                    "flag": False,
                    "rate_pool_list": [],
                    "rate_plan_list": [],
                    "message": message,
                }
                # Error Management
                error_data = {
                    "service_name": "inventory_dropdowns_data",
                    "error_message": str(e),
                    "error_type": type(e).__name__,
                    "user": data.get("username", " "),
                    "session_id": data.get("session_id", " "),
                    "tenant_name": Partner,
                    "comments": message,
                    "module_name": "Inventory",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
                return response
    except Exception as e:
        logging.exception(e)
        # Prepare and return the response
        message = "Dropdown data fetched successfully"
        response = {
            "flag": True,
            "communication_rate_plan_list": {},
            "message": message,
        }
        # Error Management
        error_data = {
            "service_name": "inventory_dropdowns_data",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "user": data.get("username", " "),
            "session_id": data.get("session_id", " "),
            "tenant_name": Partner,
            "comments": message,
            "module_name": "Inventory",
            "request_received_at": data.get("request_received_at"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return response

def fetch_cost_centers(data, db_config,common_utils_database_config):
    """
    Fetches cost centers for Kore service provider from the database.
    
    This function retrieves cost center information specifically for Kore providers,
    formatting the data as "cost_center_name -- cost_center_pk" for display purposes.
    
    Args:
        data (dict): Request data containing:
            - service_provider_id (str): ID of the service provider
            - tenant_name (str): Name of the tenant (defaults to 'Altaworx')
            - db_name (str): Database name for tenant-specific queries
            - username (str, optional): Username for error logging
            - sessionID (str, optional): Session ID for error logging
            - request_received_at (str, optional): Request timestamp for error logging
            - Partner (str, optional): Partner name for error logging
        db_config (dict): Database configuration parameters
    
    Returns:
        dict: Response containing:
            - flag (bool): Always True indicating successful processing
            - cost_centers (list): List of formatted cost center strings for Kore providers,
                                 empty list for non-Kore providers or on error
    """
    logging.info(f"## fetch_cost_centers Received request data: {data}")
    tenant_name = data.get('tenant_name', 'Altaworx')
    mode = os.getenv('ENV', 'UAT')
    if mode == 'UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
    service_provider_id = data.get("service_provider_id", "")
    tenant_database = data.get("db_name", None)
    if tenant_database is None:
        return {"flag": False, "message": "Database name not provided"}
    database = DB(tenant_database, **db_config)

    response = {"flag": True, "cost_centers": []}

    try:
        json_data = load_json()
        kore_ids = get_provider_ids(json_data, tenant_name, ["Koremain"])
        # Fetch cost centers only for Kore providers
        if service_provider_id in kore_ids:
            query = "select cost_center_name,cost_center_pk from kore_cost_centers"
            cost_centers_df = database.execute_query(query, True)

            # Format the cost center list
            response["cost_centers"] = cost_centers_df.apply(
                lambda row: f"{row['cost_center_name']} -- {row['cost_center_pk']}", axis=1
            ).tolist()

        return response

    except Exception as e:
        logging.exception(f"Error occurred while fetching cost centers : {e}")

        # Log error to the common database
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        common_utils_database.log_error_to_db(
            {
                "service_name": "fetch_cost_centers",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "Inventory",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )

        return response

def update_features_pop_up_data(data, db_config,common_utils_database_config):
    '''
    Fetch and return active SOC codes (features) for a given service provider,
    and log the activity or any errors to the audit/error tables.
    Args:
        data (dict): A dictionary containing:
            - db_name (str, optional): Name of the tenant database.
            - service_provider_id (int, optional): ID of the service provider.
            - service_provider_name (str, optional): Name of the service provider.
            - request_received_at (str): Timestamp when the request arrived.
            - username (str): Name or identifier of the user making the request.
            - sessionID (str): Session identifier for tracking.
            - Partner (str): Tenant/partner name used for auditing.
    Returns:
        dict: A response dictionary containing:
            - flag (bool): True if operation succeeded or failed gracefully.
            - soc_codes (list[dict] or {}): List of SOC code dicts with keys
              ['id', 'friendly_name', 'soc_code'] if successful; empty dict otherwise.
            - message (str): Descriptive message about the outcome.
    Behavior:
        1. Establishes connections to tenant-specific and common-utils databases.
        2. Determines `service_provider_id`:
            - Uses provided ID, or
            - Looks up by `service_provider_name` if ID is missing.
        3. Queries the tenant database for active, non-deleted, non-retired
           mobility_feature entries tied to the service provider.
        4. On success:
            - Returns the list of SOC codes ordered by friendly_name.
            - Logs a "Success" entry in `audit_user_actions`.
        5. On failure:
            - Logs exception details in `error_log_table`.
            - Returns an empty `soc_codes` and an appropriate failure message.

    Raises:
        None: All exceptions are caught internally and logged;
            function always returns a dict with 'flag' and 'message'.
    '''
    logging.info(f"Request Recieved for the update_features_pop_up_data is:{data}")
    # Initialize the database connection
    tenant_database = data.get("db_name", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    service_provider_id = data.get("service_provider_id",None)
    service_provider_name=data.get("service_provider_name",None)
    ##handling if service provider name not comes
    if not service_provider_id:
        service_provider_id=database.get_data('serviceprovider',{"is_active":True,"service_provider_name":service_provider_name},["id"])["id"].to_list()[0]
        if not service_provider_id:
            response={"flag":False,"message":"Service Provider ID Not Found"}
            return response
    ##fetching the features
    try:        
        feature_codes_result = database.get_data(
            table_name="mobility_feature",
            condition={
                "service_provider_id": service_provider_id,
                "is_active": True,
                "is_deleted": False,
                "is_retired": False
            },
            columns=["id", "friendly_name", "soc_code"],
            order={"friendly_name": "asc"}  # safe ordering
        )

        # Convert to list of dictionaries safely
        if feature_codes_result is not False and not feature_codes_result.empty:
            soc_codes = feature_codes_result.to_dict(orient='records')
        else:
            soc_codes = []
        response = {
            "flag": True,
            "soc_codes": soc_codes,
            "message": "soc codes retrieved successfully",
        }
        return response
    except Exception as e:
        logging.exception(f"### update_features_pop_up_data Error occured while getting soc codes {e}")
        response = {
            "flag": True,
            "soc_codes": {},
            "message": "soc codes retrieved failed",
        }
        common_utils_database.log_error_to_db(
            {
                "service_name": "update_features_pop_up_data",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "Inventory",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return response

def statuses_inventory(data, db_config,db_config_withoutfilter,common_utils_database_config):
    """
    Retrieves device status values and reason codes for inventory management.
    
    This function fetches available device statuses that allow API updates and associated
    reason codes based on the service provider's integration. It also handles role-based
    filtering for customer rate plans.
    
    Args:
        data (dict): Request data containing:
            - service_provider_id (str): ID of the service provider
            - role_name (str): User role name for permission filtering
            - tenant_name (str): Name of the tenant (defaults to 'Altaworx')
            - service_provider (str): Name of the service provider
            - db_name (str): Database name (defaults to 'altaworx_central')
            - username (str, optional): Username for error logging
            - sessionID (str, optional): Session ID for error logging
            - request_received_at (str, optional): Request timestamp for error logging
        db_config (dict): Database configuration parameters
    
    Returns:
        dict: Response containing:
            - flag (bool): Always True indicating successful processing
            - update_status_values (dict): Dictionary mapping status display names to IDs
            - reason_codes (list): List of available reason codes
            - states (list, optional): US states list for address fields
            - activation_profiles (list, optional): Kore activation profiles if applicable
    """
    logging.info(f"### statuses_inventory Request Data received {data}")
    service_provider_id = data.get("service_provider_id", "")
    role_name = data.get("role_name", "")
    tenant_name = data.get('tenant_name', 'Altaworx')
    mode = os.getenv('ENV', 'UAT')
    if mode == 'UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
    service_provider_name = data.get("service_provider", None)
    tenant_database = data.get("db_name", "altaworx_central")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    tenant_name = data.get("tenant_name", "")

    if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
    else:
        # Default case: fetch only from the database
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
    response = {"flag": True}
    try:        
        # Use get_data helper to safely fetch parent_tenant_id
        parent_result = common_utils_database.get_data(
            table_name="tenant",
            condition={"tenant_name": tenant_name},  # safe filter
            columns=["parent_tenant_id"]
        )

        # Extract and process parent_tenant_id safely
        if parent_result is not False and not parent_result.empty:
            parent_tenant_id = parent_result["parent_tenant_id"].iloc[0]
            if parent_tenant_id is not None:
                parent_tenant_id = int(parent_tenant_id)
                tenant_id = parent_tenant_id
        else:
            parent_tenant_id = None
            tenant_id = None  # handle as needed

        integration_id = database.get_data(
            "serviceprovider", {"id": service_provider_id}, ["integration_id"]
        )["integration_id"].to_list()[0]
        status_dict =database.get_data(
            "device_status",
            {"integration_id": integration_id, "is_active": True, "is_deleted": False,"allows_api_update": True},
            ["display_name", "id"],
        )

        if status_dict.empty:
            statuses = {}
        else:
            statuses = dict(zip(status_dict["display_name"], status_dict["id"]))
        response["update_status_values"] = statuses

        reason_codes = database.execute_query(
            """
            SELECT t.reason_code
            FROM telegence_device_status_reason_code t
            JOIN device_status d ON d.id = t.device_status_id
            WHERE t.is_active = TRUE
            AND t.is_deleted = FALSE
            AND d.integration_id = %s
            """,
            True,
            params=[integration_id]
        ).to_dict(orient="records")

        response["reason_codes"] = reason_codes
         # ##Adding additional account number condition for verizon 
        try:
            account_numbers_df = database.get_data(
                "integration_authentication",
                {
                    "service_provider_id": service_provider_id,
                    "is_active": True
                },
                ["oauth2_custom1", "oauth2_custom2", "oauth2_custom3", "oauth2_custom4"]
            )

            if not account_numbers_df.empty:
                account_numbers = [
                    value
                    for value in account_numbers_df.iloc[0].tolist()
                    if value not in (None, "", "NULL")
                ]
                response["account_numbers"]=account_numbers
        except Exception as e:
            logging.exception(f"unable to get the account number {e}")
            response["account_numbers"]=[]

        original_names = db_config.get("customer_rate_plan_name", '')
        if role_name not in ("Super Admin", "Partner Admin") and original_names:
            # Save the original customer rate plan names before deletion
            #original_names = db_config["customer_rate_plan_name"]
            logging.info('original_names',original_names)
            original_names=clean_tuple(original_names)
            agent_database = DB(tenant_database, **db_config_withoutfilter)

            # Get rate plan code mapping

            placeholders = ", ".join(["%s"] * len(original_names))

            query = f"""
                SELECT crp.rate_plan_name, carp.rate_plan_code
                FROM customerrateplan crp
                JOIN customer_rate_plan_jasper_carrier_rate_plan crpjcrp
                    ON crp.id = crpjcrp.customer_rate_plan_id
                JOIN carrier_rate_plan carp
                    ON crpjcrp.jasper_carrier_rate_plan_id = carp.id
                WHERE crp.rate_plan_name IN ({placeholders})
                AND crp.tenant_id = %s
            """

            # Combine parameters: original_names + tenant_id
            params = list(original_names) + [tenant_id]

            # Execute query safely
            result = agent_database.execute_query(query, True, params=params)
            name_to_code = result.set_index('rate_plan_name')['rate_plan_code'].to_dict() if not result.empty else {}

            # Get valid rate plan codes
            carrier_data = agent_database.get_data(
                "carrier_rate_plan",
                {
                    "service_provider_id": service_provider_id,
                    "is_active": True,
                    "is_deleted": False,
                    "is_retired": False
                },
                columns=["rate_plan_code"]
            )

            # Create set of valid codes
            valid_codes = set(carrier_data['rate_plan_code']) if not carrier_data.empty else set()

            # Build final dropdown structure
            dropdown_list = []
            for rate_plan_name in original_names:
                code = name_to_code.get(rate_plan_name)
                dropdown_list.append({
                    "rate_plan": rate_plan_name,
                    "code": code if code in valid_codes else None
                })
            response["carrier_rate_plan"] = dropdown_list
        else:
            # Use get_data helper instead of raw SQL
            carrier_data = database.get_data(
                table_name="carrier_rate_plan",
                condition={
                    "service_provider_id": service_provider_id,
                    "is_active": True
                },
                columns=["friendly_name", "rate_plan_code"],
                order={"friendly_name": "asc"}
            )

            # Add temp_name column safely
            if carrier_data is not False and not carrier_data.empty:
                carrier_data["temp_name"] = carrier_data["friendly_name"].combine_first(
                    carrier_data["rate_plan_code"]
                )
            else:
                carrier_data = pd.DataFrame(columns=["friendly_name", "rate_plan_code", "temp_name"])


            carrier_rate_plan = (carrier_data['temp_name'] + ' -- ' + carrier_data['rate_plan_code'].fillna("")).to_list()
            carrier_rate_plan_code = carrier_data["rate_plan_code"].to_list()
            response["carrier_rate_plan"] = carrier_rate_plan
            response["carrier_rate_plan_code"] = carrier_rate_plan_code

        response["state"] = sorted(
                    [
                        {"name": "Alabama", "code": "AL"},
                        {"name": "Alaska", "code": "AK"},
                        {"name": "Arizona", "code": "AZ"},
                        {"name": "Arkansas", "code": "AR"},
                        {"name": "California", "code": "CA"},
                        {"name": "Colorado", "code": "CO"},
                        {"name": "Connecticut", "code": "CT"},
                        {"name": "District of Columbia", "code": "DC"},
                        {"name": "Delaware", "code": "DE"},
                        {"name": "Florida", "code": "FL"},
                        {"name": "Georgia", "code": "GA"},
                        {"name": "Hawaii", "code": "HI"},
                        {"name": "Idaho", "code": "ID"},
                        {"name": "Illinois", "code": "IL"},
                        {"name": "Indiana", "code": "IN"},
                        {"name": "Iowa", "code": "IA"},
                        {"name": "Kansas", "code": "KS"},
                        {"name": "Kentucky", "code": "KY"},
                        {"name": "Louisiana", "code": "LA"},
                        {"name": "Maine", "code": "ME"},
                        {"name": "Maryland", "code": "MD"},
                        {"name": "Massachusetts", "code": "MA"},
                        {"name": "Michigan", "code": "MI"},
                        {"name": "Minnesota", "code": "MN"},
                        {"name": "Mississippi", "code": "MS"},
                        {"name": "Missouri", "code": "MO"},
                        {"name": "Montana", "code": "MT"},
                        {"name": "Nebraska", "code": "NE"},
                        {"name": "Nevada", "code": "NV"},
                        {"name": "New Hampshire", "code": "NH"},
                        {"name": "New Jersey", "code": "NJ"},
                        {"name": "New Mexico", "code": "NM"},
                        {"name": "New York", "code": "NY"},
                        {"name": "North Carolina", "code": "NC"},
                        {"name": "North Dakota", "code": "ND"},
                        {"name": "Ohio", "code": "OH"},
                        {"name": "Oklahoma", "code": "OK"},
                        {"name": "Oregon", "code": "OR"},
                        {"name": "Pennsylvania", "code": "PA"},
                        {"name": "Rhode Island", "code": "RI"},
                        {"name": "South Carolina", "code": "SC"},
                        {"name": "South Dakota", "code": "SD"},
                        {"name": "Tennessee", "code": "TN"},
                        {"name": "Texas", "code": "TX"},
                        {"name": "Utah", "code": "UT"},
                        {"name": "Vermont", "code": "VT"},
                        {"name": "Virginia", "code": "VA"},
                        {"name": "Washington", "code": "WA"},
                        {"name": "West Virginia", "code": "WV"},
                        {"name": "Wisconsin", "code": "WI"},
                        {"name": "Wyoming", "code": "WY"},
                    ],
                    key=lambda x: x["name"],
                )

        # Fetching the Activation Profiles and Returning for Kore Provider
        json_data = load_json()
        kore_ids=get_provider_ids(json_data, tenant_name, ["Koremain"])
        if service_provider_name == "Kore" or service_provider_id in kore_ids:
            try:
                # kore_activation_profiles_data = database.get_data(
                #     "kore_activation_profiles", {}, ["activation_profile_name","carrier_rate_plan_data"]
                # )
                kore_activation_profiles_query = "select activation_profile_name,carrier_rate_plan_data from kore_activation_profiles"
                kore_activation_profiles_data = database.execute_query(
                    kore_activation_profiles_query, True
                )
                # Creating the list of concatenated values
                kore_activation_profiles = kore_activation_profiles_data.apply(
                    lambda row: f"{row['activation_profile_name']} -- {row['carrier_rate_plan_data']}",
                    axis=1,
                ).tolist()
                response["activation_profiles"] = kore_activation_profiles
            except Exception as e:
                logging.warning(f"### statuses_inventory Exception in fetching the activation profiles is {e}")
                response["activation_profiles"] = []
        response["Device_Status_dropdown"] = database.get_data(
            "device_status",
            {
                "integration_id": integration_id,
                "allows_api_update": True,
                "is_active": True,
            },
            ["display_name", "id", "status"],
        ).to_dict(orient="records")
        return response
    except Exception as e:
        logging.exception(f"### statuses_inventory Exception while fetching statuses : {e}")
        response = {"flag": True, "update_status_values": []}
        json_data = load_json()
        kore_ids=get_provider_ids(json_data, tenant_name, ["Koremain"])
        if service_provider_name == "Kore" or service_provider_id in kore_ids:
            response["activation_profiles"] = []
        common_utils_database.log_error_to_db(
            {
                "service_name": "statuses_inventory",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "Inventory",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return response

def reason_codes_inventory(data, db_config,common_utils_database_config):
    """
    Retrieves reason codes for device status updates based on service provider and status.
    
    This function fetches reason codes from either Telegence or ThingSpace tables
    depending on the service provider, filtered by device status and integration ID.
    
    Args:
        data (dict): Request data containing:
            - service_provider_id (str): ID of the service provider
            - status (str): Device status to filter reason codes
            - tenant_name (str): Name of the tenant (defaults to 'Altaworx')
            - service_provider (str): Name of the service provider
            - db_name (str): Database name (defaults to 'altaworx_central')
            - username (str, optional): Username for error logging
            - sessionID (str, optional): Session ID for error logging
            - request_received_at (str, optional): Request timestamp for error logging
        db_config (dict): Database configuration parameters
    
    Returns:
        dict: Response containing:
            - flag (bool): Always True indicating successful processing
            - reason_codes (list): List of dictionaries with reason_code, description, and status
                                 Empty list if error occurs
    """
    logging.info(f"### reason_codes_inventory data {data}")
    service_provider_id = data.get("service_provider_id", "")
    status = data.get("status", "")
    tenant_name=data.get('tenant_name','Altaworx')
    mode=os.getenv('ENV','UAT')
    if mode=='UAT':
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
    service_provider_name = data.get("service_provider", None)
    tenant_database = data.get("db_name", "altaworx_central")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    tenant_name = data.get("tenant_name", "")
    if 'Telegence' in service_provider_name:
        table_name = 'telegence_device_status_reason_code'
    else:
        table_name = 'thingspace_device_status_reason_code'

    if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
    else:
        # Default case: fetch only from the database
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
    
    # Use get_data helper instead of raw SQL
    parent_result = common_utils_database.get_data(
        table_name="tenant",
        condition={"tenant_name": tenant_name},  # safe filter
        columns=["parent_tenant_id"]
    )

    # Extract parent_tenant_id safely
    if parent_result is not False and not parent_result.empty:
        parent_tenant_id = parent_result["parent_tenant_id"].iloc[0]
        if parent_tenant_id is not None:
            parent_tenant_id = int(parent_tenant_id)
            tenant_id = parent_tenant_id
    else:
        parent_tenant_id = None
        tenant_id = None  # or handle as needed


    response = {"flag": True}
    try:
        integration_id = database.get_data(
            "serviceprovider", {"id": service_provider_id, "is_active":True}, ["integration_id"]
        )["integration_id"].to_list()[0]

        reason_codes = database.execute_query(
                                                """
                                                SELECT t.reason_code, t.description, d.description as status
                                                FROM {} t
                                                JOIN device_status d ON d.id = t.device_status_id
                                                WHERE t.is_active = TRUE
                                                AND t.is_deleted = FALSE
                                                AND d.integration_id = %s
                                                AND d.description = %s
                                                """.format(table_name),
                                                True,
                                                params=[integration_id, status]
                                            ).to_dict(orient="records")

        response["reason_codes"] = reason_codes
        return response
    except Exception as e:
        logging.exception("Exception while fetching statuses")
        response = {"flag": True, "reason_codes": []}

        common_utils_database.log_error_to_db(
            {
                "service_name": "reason_codes_inventory",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "Inventory",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return response


def form_depandent_dropdown_format_bulk_change(data, main_col, sub_col):
    """
    Formats data for dependent dropdowns by grouping unique values from sub_col by main_col values.
    Uses sets to eliminate duplicates in the sub_col values.
    
    Args:
        data (list): List of dictionaries containing the data to be formatted
        main_col (str): Key name for the main column to group by
        sub_col (str): Key name for the sub-column values to be grouped
        
    Returns:
        dict: Dictionary with main_col values as keys and sorted lists of unique sub_col values as values
    """
    logging.info(f"### form_depandent_dropdown_format_bulk_change data : {data}")
    result = {}

    # Iterate over each item in the list
    for item in data:
        main_col_value = item[main_col]
        sub_col_value = item[sub_col]

        # If the service provider is already a key in the dictionary, add the change type to the set (to avoid duplicates)
        if main_col_value in result:
            result[main_col_value].add(sub_col_value)  # Use set to eliminate duplicates
        else:
            # If the service provider is not a key, create a new set with the change type
            result[main_col_value] = {
                sub_col_value
            }  # Initialize as a set to ensure uniqueness

    # Convert the sets back to sorted lists
    for key in result:
        result[key] = sorted(result[key])  # Sort the set and convert it back to a list

    return result



def get_rev_service_type_bulk_change_data(data,db_config,common_utils_database_config):
    """
    Description:
        Retrieves device history data from the database based on unique identifiers
        and columns provided in the input data. Validates the access token and logs
        the request, then fetches and returns the device history if the token is valid.

    Parameters:
        data (dict): Input data containing necessary parameters for querying the database
                     and determining which data needs to be returned.

    Returns:
        dict: Response data containing success or failure status, a message, and the requested data.
    """
    logging.info(f"### get_rev_service_type_bulk_change_data Request Data: {data}")
    try:
        del db_config['tenant_ids']
    except Exception as e:
        logging.exception(f"Exception occurred while removing the filters: {e}")

    # Extract necessary parameters from the input data
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    request_received_at = data.get("request_received_at", None)
    session_id = data.get("session_id", None)
    role_name=data.get('role_name','Super Admin')
    # Database connection parameters
    tenant_database = data.get("db_name", "altaworx_central")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name},
            ["id","parent_tenant_id"]
            )
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    integration_authentication_json_data = load_integration_authentication_json()
    integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
    if not integration_authentication_id and parent_tenant_id:
        if parent_tenant_id:
            parent_tenant_id=int(parent_tenant_id)
            parent_tenant_data = common_utils_database.get_data(
            "tenant", {"id": parent_tenant_id},
            ["tenant_name"]
            )
            parent_tenant_name = parent_tenant_data["tenant_name"].to_list()[0]
            integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)
    else:
        integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, 'Altaworx')
    logging.info(f"integration_authentication_id : {integration_authentication_id}")

    try:
        # Initialize response data container
        response_data = {}

        # Extract specific change-related parameters
        service_provider = data.get("service_provider", None)
        Change_type = data.get("change_type", None)
        logging.info(f"Change_type is {Change_type}")

        def sorted_unique(data_list):
            """Helper function to sort a list and remove any None values."""
            return sorted(filter(None, set(data_list)))


        # If no service provider is specified, return service provider-change type mappings
        dropdown_data = {}
        if not service_provider:
            response_data["new_change_SP_CT_map"] = sorted(
                database.get_data(
                    "sim_management_bulk_change_type_service_provider",
                    {"is_active": True},
                    ["change_type", "service_provider"],
                ).to_dict(orient="records"),
                key=lambda x: x["service_provider"] or "",
            )
            # Remove "Change Carrier Rate Plan" if not Super Admin
            if role_name not in ("Super Admin", "Partner Admin"):
                response_data["new_change_SP_CT_map"] = [
                    item for item in response_data["new_change_SP_CT_map"]
                    if item["change_type"] != "Change Carrier Rate Plan"
                ]
            dropdown_data["new_change_SP_CT_map"] = (
                form_depandent_dropdown_format_bulk_change(
                    response_data["new_change_SP_CT_map"],
                    "service_provider",
                    "change_type",
                )
            )
        else:
            # Retrieve screen sequence for the given service provider and change type
            response_data["screen_names_seq"] = sorted(
                database.get_data(
                    "bulk_change_popup_screens",
                    {"service_provider": service_provider, "change_type": Change_type},
                    ["screen_names_seq"],
                )["screen_names_seq"].to_list()
            )
            if response_data["screen_names_seq"]:
                response_data["screen_names_seq"] = response_data["screen_names_seq"][0]
            dropdown_data = {}

            # dropdown_data["rev_service_type"] = sorted_unique(
            #     database.get_data(
            #         "rev_service_type",
            #         {"is_active": True, "integration_authentication_id":integration_authentication_id},
            #         concat_columns=["description", "service_type_id"],
            #     )["concat_column"].to_list()
            # )
            if 'Telegence' in service_provider:
                service_provider_type='mobility'
            else:
                service_provider_type='m2m'
            service_type_description_df=database.get_data('service_type_mapping',{"service_provider_type":service_provider_type},["service_type_description"])['service_type_description']
            if service_type_description_df.empty:
                service_type_description_list='[]'
            else:
                service_type_description_list=service_type_description_df.to_list()[0]
            service_type_description_list = json.loads(service_type_description_list)
            dropdown_data["rev_service_type"] = sorted_unique(
                database.get_data(
                    "rev_service_type",
                    {"is_active": True, "integration_authentication_id":integration_authentication_id,"description":service_type_description_list},
                    concat_columns=["description", "service_type_id"],
                )["concat_column"].to_list()
            )
            logging.info(
                    f"### get_rev_service_type_bulk_change_data dropdown_data['rev_service_type'] is {dropdown_data.get('rev_service_type')} and integration_authentication_id: {integration_authentication_id}"
                )


        # Message indicating success
        message = "New Bulk change popups data sent successfully"
        response = {"flag": True, "message": message, "dropdown_data": dropdown_data}
        return response

    except Exception as e:
        # Log the error and prepare an error response
        logging.exception(f"Something went wrong and error is: {e}")
        message = "Something went wrong while getting New Bulk change popups"
        # Log error to the database
        error_data = {
            "service_name": "get_rev_service_type_bulk_change_data",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Inventory",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")

        # Return the error response
        return {"flag": False, "message": message}


def get_assign_customer_bulk_change_data(data,db_config,db_config_withoutfilter,common_utils_database_config):
    """
    Description:
        Retrieves device history data from the database based on unique identifiers
        and columns provided in the input data. Validates the access token and logs
        the request, then fetches and returns the device history if the token is valid.

    Parameters:
        data (dict): Input data containing necessary parameters for querying the database
                     and determining which data needs to be returned.

    Returns:
        dict: Response data containing success or failure status, a message, and the requested data.
    """
    # logging.info(f"Request Data: {data}")
    # Start time calculation to measure the duration of the function execution

    try:
        del db_config['tenant_ids']
    except Exception as e:
        logging.exception(f"Exception occurred while removing the filters: {e}")

    # Extract necessary parameters from the input data
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    request_received_at = data.get("request_received_at", None)
    session_id = data.get("session_id", None)
    billing_platform_flag=data.get('billing_platform_flag',False)
    
    module_name = data.get("module_name", None)
    role_name=data.get('role_name','Super Admin')
    # Database connection parameters
    tenant_database = data.get("db_name", "altaworx_central")
    database = DB(tenant_database, **db_config_withoutfilter)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    if tenant_name == "Altaworx Test":
            tenant_id = 1
    else:
        tenant_id_query = f"select id from tenant where tenant_name='{tenant_name}'"
        tenant_id = common_utils_database.execute_query(tenant_id_query,True)['id'].to_list()[0]

    integration_authentication_json_data = load_integration_authentication_json()
    integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
    if not integration_authentication_id:
        query=f'''select parent_tenant_id from tenant where tenant_name='{tenant_name}'
        '''
        parent_tenant_id=common_utils_database.execute_query(query,True)['parent_tenant_id'].to_list()[0]
        if parent_tenant_id:
            parent_tenant_id=int(parent_tenant_id)
        parent_tenant_query=f'''select tenant_name from tenant where id={parent_tenant_id}
        '''
        parent_tenant_name=common_utils_database.execute_query(parent_tenant_query,True)['tenant_name'].to_list()[0]
        integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)

    try:
        # Initialize response data container
        response_data = {}

        # Extract specific change-related parameters
        service_provider = data.get("service_provider", None)
        Change_type = data.get("change_type", None)
        logging.info(f"Change_type is {Change_type}")
        Create_Service_Product = data.get("Create Service/Product", None)

        def sorted_unique(data_list):
            """Helper function to sort a list and remove any None values."""
            return sorted(filter(None, set(data_list)))

        # Handle the case when "Create Service/Product" flag is True
        if Create_Service_Product:
            # Fetch dropdown data for various categories
            response_data["rev_customer_dropdown"] = sorted_unique(
                database.get_data(
                    "revcustomer",
                    {"is_active": True,
                     "status": ['open', 'Open', 'OPEN'],},
                    concat_columns=["customer_name", "rev_customer_id"],
                )["concat_column"].to_list()
            )
            response_data["rev_service_type"] = sorted_unique(
                database.get_data(
                    "rev_service_type",
                    {"is_active": True},
                    concat_columns=["description", "service_type_id"],
                )["concat_column"].to_list()
            )
            response_data["rev_product"] = sorted_unique(
                database.get_data(
                    "rev_product",
                    {"is_active": True},
                    concat_columns=["description", "product_id"],
                )["concat_column"].to_list()
            )

            message = "New Bulk change popups data sent successfully"
            response = {"flag": True, "message": message, "Modules": response_data}
            return response

        # If no service provider is specified, return service provider-change type mappings
        if not service_provider:
            response_data["new_change_SP_CT_map"] = sorted(
                database.get_data(
                    "sim_management_bulk_change_type_service_provider",
                    {"is_active": True},
                    ["change_type", "service_provider"],
                ).to_dict(orient="records"),
                key=lambda x: x["service_provider"] or "",
            )
            # Remove "Change Carrier Rate Plan" if not Super Admin
            if role_name not in ("Super Admin", "Partner Admin"):
                response_data["new_change_SP_CT_map"] = [
                    item for item in response_data["new_change_SP_CT_map"]
                    if item["change_type"] != "Change Carrier Rate Plan"
                ]
            response_data["new_change_SP_CT_map"] = (
                form_depandent_dropdown_format_bulk_change(
                    response_data["new_change_SP_CT_map"],
                    "service_provider",
                    "change_type",
                )
            )
        else:
            # Retrieve screen sequence for the given service provider and change type
            response_data["screen_names_seq"] = sorted(
                database.get_data(
                    "bulk_change_popup_screens",
                    {"service_provider": service_provider, "change_type": Change_type},
                    ["screen_names_seq"],
                )["screen_names_seq"].to_list()
            )
            if response_data["screen_names_seq"]:
                response_data["screen_names_seq"] = response_data["screen_names_seq"][0]
            dropdown_data = {}

            # Fetch role module data with efficient query
            role_module_data = common_utils_database.get_data(
                "role_module",
                {"role": role_name},
                ["sub_module"],
            )

            # Initialize default status
            module_status = False

            if not role_module_data.empty:
                try:
                    # Parse JSON safely with fallback
                    sub_modules = json.loads(role_module_data.iat[0, 0] or '{}')

                    # Strict nested check
                    if "People" in sub_modules:
                        people_modules = sub_modules["People"]
                        if isinstance(people_modules, list):  # Ensure it's a list
                            module_status = "Billing Customers" in people_modules

                except json.JSONDecodeError:
                    logging.error(f"Invalid JSON in sub_module for role: {role_name}")
                except KeyError:
                    pass  # People section not present
                except Exception as e:
                    logging.error(f"Unexpected error processing modules: {str(e)}")


            # Process different change types and prepare respective dropdown data

            try:
                if role_name not in ('Super Admin'):
                    del db_config['billing_account_number']
            except Exception as e:
                logging.exception(f"Exception occurred while removing the filters: {e}")

            databases = DB(tenant_database, **db_config)

            if module_status and tenant_name!='WingTel' and  billing_platform_flag==False:


                dropdown_data["rev_customer_dropdown"] = sorted_unique(
                    database.get_data(
                        "revcustomer",
                        {"is_active": True, "integration_authentication_id":integration_authentication_id, "tenant_id":tenant_id,
                            "status": ['open', 'Open', 'OPEN'],},
                        concat_columns=["customer_name", "rev_customer_id"],
                    )["concat_column"].to_list()
                )
            elif module_status and billing_platform_flag:
                # Both revcustomer and customers
                df1 = database.get_data(
                    "revcustomer",
                    {
                        "is_active": True,
                        "integration_authentication_id": integration_authentication_id,
                        "tenant_id": tenant_id,
                        "status": ['open', 'Open', 'OPEN'],
                    },
                    ["customer_name", "rev_customer_id"],
                ).rename(columns={"rev_customer_id": "id"})
                df1["customer_name"] = df1["customer_name"] + " -- " + df1["id"].astype(str) + " -- RevIO"

                df2 = database.get_data(
                    "customers",
                    {"tenant_id": str(tenant_id), "is_active": True,"billing_platform_flag":True},
                    ["customer_name", "id"],
                )
                df2["customer_name"] = df2["customer_name"] + " -- " + df2["id"].astype(str) + " -- BP"

                df = pd.concat([df1, df2], ignore_index=True, sort=False)

                dropdown_data["rev_customer_dropdown"] = (
                    sorted(df["customer_name"].unique().tolist())
                    if not df.empty else []
                )

            else:

                customer_names_query = databases.get_data(
                    "customers",
                    {"tenant_id": str(tenant_id), "is_active": True},
                    ["customer_name", "id"],
                )
                # If no customers are found, return an empty list
                if customer_names_query.empty:
                    dropdown_data["rev_customer_dropdown"] = []
                else:
                    customer_names_query = customer_names_query.rename(columns={"id": "customer_id"})
                    # Create a dictionary first and then convert to list
                    customer_dict = dict(zip(customer_names_query["customer_name"], customer_names_query["customer_id"]))
                    dropdown_data["rev_customer_dropdown"] = [f"{name} -- {id}" for name, id in customer_dict.items()]

        # Message indicating success
        message = "New Bulk change popups data sent successfully"
        response = {"flag": True, "message": message, "dropdown_data": dropdown_data}

        return response

    except Exception as e:
        # Log the error and prepare an error response
        logging.exception(f"Something went wrong and error is: {e}")
        message = "Something went wrong while getting New Bulk change popups"
        # Log error to the database
        error_data = {
            "service_name": "get_assign_customer_bulk_change_data",
            "created_date": request_received_at,
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Inventory",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")

        # Return the error response
        return {"flag": False, "message": message}
