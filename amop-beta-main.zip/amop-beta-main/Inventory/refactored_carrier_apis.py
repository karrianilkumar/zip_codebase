"""
@Author1 : Ajay
Created Date: 12-09-2025
"""

import json
from common_utils.logging_utils import Logging
from inventory_utils import normalize_bulk_change_request,bulkchange_lambda_caller
from config.carrier_config_manager import CarrierConfigManager

logging = Logging(name="carrier_apis")
config_manager = CarrierConfigManager()


def send_carrier_rate_plan_update(
        data, tenant_database, changed_data, tenant_data, inventory_data,
        service_provider, service_provider_id, integration_id, rate_plan_name,
        effective_date, optimization_group, bulk_change_id, communication_plan,
        change_event_id,common_utils_database_config
        ):
    """
    Processes carrier rate plan updates by building carrier-specific requests.
    
    Creates bulk change request records for rate plan updates, handling different
    carrier configurations and request formats. Processes inventory data, builds
    carrier-specific payloads, and stores requests for asynchronous processing.
    
    Args:
        data (dict): Original request data
        tenant_database (DB): Database connection for tenant operations
        changed_data (list): List of device records to update
        tenant_data (DataFrame): Tenant information
        inventory_data (DataFrame): Device inventory data
        service_provider (str): Name of the service provider/carrier
        service_provider_id (int): Service provider identifier
        integration_id (int): Integration identifier
        rate_plan_name (str): Target rate plan name
        effective_date (str): Rate plan effective date
        optimization_group (str): Optimization group identifier
        bulk_change_id (int): ID of the bulk change operation
        communication_plan (str): Communication plan details
        change_event_id (int): Change event identifier
    
    Returns:
        dict: Response containing flag (bool) and message (str)
    """
    
    request_params = {
        "ServiceProviderId": service_provider_id,
        "IntegrationId": integration_id,
        "RatePlanName": rate_plan_name,
        "EffectiveDate": effective_date,
        "OptimizationGroup": optimization_group,
        "CommPlan": communication_plan,
        "ChangeType": change_event_id
    }

    # Build request config
    request_config = config_manager.build_request_config(
        service_provider, "change_carrier_rate_plan", **request_params
    )
    logging.info(f"### send_carrier_rate_plan_update request_config: {request_config}")

    if not request_config:
        return {
            "flag": False,
            "message": f"Failed to build request config for: {service_provider}"
        }
    
    try:
        # Normalize and prepare base request
        change_request_dict = {
            k: normalize_bulk_change_request(v)
            for k, v in request_config.get("change_request", {}).items()
        }
        base_change_request = json.dumps(change_request_dict)

        # Extract tenant metadata once
        created_by = changed_data[0].get("modified_by")
        tenant_name = tenant_data["tenant_name"].iloc[0]
        tenant_id = int(tenant_data["id"].iloc[0])

        # Process records efficiently
        bulk_requests = []
        processed_iccids, processed_msisdns = [], []
        
        for record in changed_data:
            rec_id = record.get("id")
            inv_row = inventory_data[inventory_data["id"] == rec_id]

            if inv_row.empty:
                continue

            iccid = inv_row["iccid"].iloc[0]
            msisdn = inv_row["msisdn"].iloc[0] if "msisdn" in inv_row.columns else None
            device_id = inv_row["device_id"].iloc[0] if "device_id" in inv_row.columns else None
            imei = inv_row["imei"].iloc[0] if "imei" in inv_row.columns else None

            processed_iccids.append(iccid)
            processed_msisdns.append(msisdn)

            # Customize request for this record
            personalized_request = base_change_request.replace(
                "{PhoneNumber}", msisdn if msisdn else ""
            ).replace("{ICCID}", iccid if iccid else "").replace(
                "{IMEI}", imei if imei else ""
            )

            
   
            bulk_requests.append({
                "iccid": iccid,
                "subscriber_number": msisdn,
                "bulk_change_id": str(bulk_change_id),
                "tenant_name": tenant_name,
                "created_by": created_by,
                "processed_by": created_by,
                "status": "NEW",
                "device_id": int(device_id) if device_id else None,
                "tenant_id": tenant_id,
                "is_active": True,
                "is_deleted": False,
                "change_request": personalized_request
            })

        # Batch insert to database
        if bulk_requests:
            tenant_database.insert_data(bulk_requests, "sim_management_bulk_change_request")
            logging.info(f"### send_carrier_rate_plan_update: Inserted {len(bulk_requests)} requests")

        # Prepare lambda request payload
        lambda_request = {
            "CarrierRatePlanUpdate": {
                "CarrierRatePlan": rate_plan_name,
                "EffectiveDate": effective_date,
                "OptimizationGroup": optimization_group,
                "ServiceProviderId": service_provider_id
            }
        }

        # Call bulkchange lambda handler
        response = bulkchange_lambda_caller(
            data, processed_msisdns, processed_iccids, bulk_change_id, lambda_request,common_utils_database_config=common_utils_database_config
        )
        return {"flag": True, "message": response}

    except Exception as e:
        logging.exception(f"### send_carrier_rate_plan_update error: {e}")
        return {"flag": False, "message": f"Unexpected error: {e}"}
    


def send_device_update_status_bulk(
    data,
    tenant_database,
    service_provider,
    device_status,
    changed_data,
    bulk_change_id,
    status_id,
    tenant_data,
    inventory_data,
    mode,
    reason_code,
    common_utils_database_config
):
    """
    Processes bulk device status updates by building carrier-specific requests.
    
    This function creates bulk change request records for device status updates,
    handling different carrier configurations and request formats. It processes
    inventory data, builds carrier-specific payloads, and stores requests for
    asynchronous processing.
    
    Args:
        data (dict): Original request data
        tenant_database (DB): Database connection for tenant-specific operations
        service_provider (str): Name of the service provider/carrier
        device_status (str): Target device status (e.g., 'active', 'suspended')
        changed_data (list): List of device records to update
        bulk_change_id (int): ID of the bulk change operation
        status_id (int): Device status ID
        tenant_data (DataFrame): Tenant information
        inventory_data (DataFrame): Device inventory data
        mode (str): Update mode
        reason_code (str): Reason code for status change
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - processed_count (int, optional): Number of records processed
    
    Raises:
        Exception: Any errors during request building or database operations
    """
    
    # Build base request parameters
    request_params = {
        "device_status": device_status,
        "Request": {},
        "IsIgnoreFlag": False,
        "IntegrationId": 0,
        "PostUpdateStatusId": status_id,
        "mode": mode,
        "reasonCode": reason_code,
        "activation_profile": changed_data[0].get("activation_profile", ""),
    }

    # Build request config
    request_config = config_manager.build_request_config(
        service_provider, "bulk_status_update", **request_params
    )
    logging.info(f"### send_device_update_status_bulk request_config: {request_config}")

    if not request_config:
        return {
            "flag": False,
            "message": f"Failed to build request config for: {service_provider}",
        }
    
    try:
        # Normalize request values
        change_request_dict = {
            k: normalize_bulk_change_request(v)
            for k, v in request_config.get("change_request", {}).items()
        }

        CaseUpdateHandler = change_request_dict.pop("CaseUpdateHandler", None)
        if CaseUpdateHandler:
            change_request_dict["UpdateStatus"] = device_status.upper()

        thingsspace_template = change_request_dict.pop("ThingsSpaceHandler", None)
        base_change_request = json.dumps(change_request_dict)

        # Extract tenant metadata
        created_by = changed_data[0].get("modified_by")
        tenant_name = tenant_data["tenant_name"].iloc[0]
        tenant_id = int(tenant_data["id"].iloc[0])

        sim_management_bulk_change_request = []
        processed_iccids, processed_msisdns = [], []

        for record in changed_data:
            rec_id = record.get("id")
            inv_row = inventory_data[inventory_data["id"] == rec_id]

            if inv_row.empty:
                continue

            iccid = inv_row["iccid"].iloc[0]
            msisdn = inv_row["msisdn"].iloc[0] if "msisdn" in inv_row.columns else None
            device_id = inv_row["device_id"].iloc[0] if "device_id" in inv_row.columns else None

            processed_iccids.append(iccid)
            processed_msisdns.append(msisdn)

            # Build request JSON for ThingsSpace
            change_request = base_change_request
            try:
                if thingsspace_template:
                    # Rate Plan
                    rate_plan_code = record.get("rate_plan_code", "")
                    rate_plan_code = rate_plan_code.split("--")[0].strip() if "--" in rate_plan_code else rate_plan_code
                    change_request = change_request.replace("{RatePlanCode}", rate_plan_code)

                    # Telegence details
                    telegence_additional_details = record.get("telegence_additional_details", [])
                    # thingSpacePPU = telegence_additional_details[0] if telegence_additional_details else {}
                    # thingSpacePPU = telegence_additional_details if telegence_additional_details else {}
                    thingSpacePPU = telegence_additional_details if isinstance(telegence_additional_details, dict) else (telegence_additional_details[0] if isinstance(telegence_additional_details, list) and telegence_additional_details else {})

                    replacements = {
                        "{MdnZipCode}": str(thingSpacePPU.get("ZipCode", "")),
                        "{ipAddress}": str(thingSpacePPU.get("IPAddress", "")),
                        "{IMEI}": str(thingSpacePPU.get("IMEI", "")),
                        "{ICCID}": iccid or "",
                    }

                    for placeholder, value in replacements.items():
                        change_request = change_request.replace(placeholder, value)

                    # Proper JSON object for nested thingSpacePPU
                    thingSpacePPU_json = json.dumps(thingSpacePPU)
                    change_request = change_request.replace("\"{thingSpacePPU}\"", thingSpacePPU_json)

            except Exception as e:
                logging.error(f"### send_device_update_status_bulk error while building change_request: {e}")

            # Append request record
            sim_management_bulk_change_request.append({
                "iccid": iccid,
                "subscriber_number": msisdn,
                "bulk_change_id": str(bulk_change_id),
                "tenant_name": tenant_name,
                "created_by": created_by,
                "processed_by": created_by,
                "status": "NEW",
                "device_id": int(device_id) if device_id else None,
                "tenant_id": tenant_id,
                "is_active": True,
                "is_deleted": False,
                "change_request": change_request,
            })

        # Insert to DB
        if sim_management_bulk_change_request:
            tenant_database.insert_data(
                sim_management_bulk_change_request,
                "sim_management_bulk_change_request",
            )

        logging.info(f"### send_device_update_status_bulk change_request: {change_request}")

        # Call bulkchange lambda handler
        response = bulkchange_lambda_caller(
            data,
            processed_msisdns,
            processed_iccids,
            bulk_change_id,
            change_request_dict,
            device_status_id=status_id,
            common_utils_database_config = common_utils_database_config
        )

        logging.info(f"### send_device_update_status_bulk bulkchange_lambda_caller response: {response}")
        return {"flag": True, "message": response}
    except Exception as e:
        logging.error(f"### send_device_update_status_bulk error: {e}")
        return {"flag": False, "message": f"An error occurred during bulk update"}


