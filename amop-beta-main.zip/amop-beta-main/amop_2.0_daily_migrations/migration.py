"""
Author : Vyshnavi.K, Bhavani.Ganta
Created Date : 09-12-2024
main fn: main_migration_func
"""

# 1. Standard Library Imports
import os
import json
import re
import time
import math
import threading
from datetime import datetime, timedelta,timezone
import copy
import uuid
# import boto3
import traceback

# 2. Third-Party Imports
import pandas as pd
from pandas import Timestamp
from sqlalchemy import create_engine, exc, text
import pytds
import psycopg2
from psycopg2.extras import execute_values
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv

# 3. Local Application Imports
from common_utils.logging_utils import Logging
from common_utils.email_trigger import send_email
# # from optimization_migration import optimization_sync_comm_group
import requests
import random

# logging = Logging(name="migration_api_opt")


# logging.basicConfig(filename='db_migration.log', level=logging.info,
                    # format='%(asctime)s %(levelname)s:%(message)s')

onepoint_o_database=os.getenv("ONEPOINTODATABASE","AltaworxCentral")
class MigrationScheduler:



    def create_postgres_connection(self,postgres_db_name):
        logging.info(f"In create_postgres_connection {postgres_db_name}")

        load_dotenv()
        hostname = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        try:
            connection=self.create_connection(db_type,hostname,postgres_db_name,user,password,port)
            logging.info(f"in create postgres connection {connection}")
        except Exception as e:
            logging.error(f"Error while establishing connection {e}")
        return connection

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(self,db_type='',host='', db_name='',username='', password='',port='',driver='',max_retry=3):
        """
        Establishes a database connection to PostgreSQL or MSSQL based on the provided parameters.

        Retries the connection up to a specified number of times in case of failure.

        Args:
            db_type (str): Type of the database ('postgresql' or 'mssql').
            host (str): Hostname or IP address of the database server.
            db_name (str): Name of the database.
            username (str): Username for authentication.
            password (str): Password for authentication.
            port (str): Port number for the database connection.
            driver (str): Driver details (used for MSSQL if required).
            max_retry (int): Maximum number of retry attempts (default: 3).

        Returns:
            connection: A database connection object or None if the connection fails.
        """
        connection = None

        retry = 1
        logging.info(f"db_type:{db_type}, host--{host}-db_name-{db_name}, username-{username},password-{password},port-{port},driver-{driver}")
        db_type = db_type.strip()
        host = host.strip()
        db_name = db_name.strip()
        username = username.strip()
        password = password.strip()
        port = port.strip()
        driver = driver.strip()
        if db_type=='postgresql':
            try:
                logging.info(f"creating postgresql connection")

                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.error(f"Failed to connect to PostgreSQL DB: {e}")
        elif db_type=='mssql':
            logging.info(f"Creating MSSQL connection")
            try:
                connection = pytds.connect(
                    server=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )

                logging.info("Connection to MSSQL successful!")
            except Exception as e:
                logging.error(f"Failed to connect to MSSQL DB: {e}")
        return connection
    

    def execute_query(self,connection,query):
        """
        Executes a SQL query using the given database connection and returns the result as a DataFrame.

        Args:
            connection: The database connection object to execute the query.
            query (str): The SQL query to be executed.

        Returns:
            pd.DataFrame: The result of the query as a pandas DataFrame, or None if an error occurs.
        """
        try:
            result_df=pd.read_sql_query(query,connection)
            return result_df
        except Exception as e:
            logging.error(f"Error executing query: {e}")
            return None
    def insert_dict(self, conn, table_name, data_dict,return_flag=False,return_col=None):
        """
        Insert a row into a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to insert into
        :param data_dict: Dictionary containing column-value pairs to insert
        """
        try:
            # Convert dictionary values to JSON strings if necessary
            for key, value in data_dict.items():
                if isinstance(value, dict):
                    data_dict[key] = json.dumps(value)

            # Generate the column names and placeholders for the SQL query
            columns = ', '.join(data_dict.keys())
            placeholders = ', '.join(['%s'] * len(data_dict))

            # Create the SQL query
            if return_flag:
                sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders}) RETURNING {return_col}"
            else:
                sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            values = list(data_dict.values())

            # logging.info(f"SQL Query: {sql_query}")
            # logging.info(f"Values: {values}")

            # Execute the query
            with conn.cursor() as cursor:
                cursor.execute(sql_query, values)
                if return_col:
                    return_val= cursor.fetchone()[0]
                conn.commit()
                # conn.commit()
            logging.info("Insert successful")
            if return_flag:
                return return_val
            else:
                return True
        except Exception as e:
            conn.rollback()
            logging.error(f"Error inserting into table: {e}")
            return False
    def get_migration_details(self, job_name, conn,migrations_table):
        """
        Fetch migration details for a specific job from the migrations table.

        This method queries the database to retrieve migration details for a given job name.
        It executes the query, fetches the result as a pandas DataFrame, and converts it
        to a dictionary format.

        Args:
            job_name (str): The name of the migration job to fetch details for.
            conn (object): The database connection object to execute the query.
            migrations_table (str): The name of the migrations table in the database.

        Returns:
            dict: A dictionary containing the details of the migration job.
                If no details are found or an error occurs, an empty dictionary is returned.
        """
        try:
            query = f"SELECT * FROM {migrations_table} WHERE migration_name = '{job_name}'"
            query_result = self.execute_query(conn, query)
            return query_result.to_dict(orient='records')[0]
        except Exception as e:
            logging.error(f"Error while fetching the {job_name} details - {e}")
            return {}
    def update_table(self,conn, table_name, data_dict, condition_dict):
        """
        Update a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to update
        :param data_dict: Dictionary containing column-value pairs to update
        :param condition_dict: Dictionary containing column-value pairs for the WHERE condition
        """
        try:
            # Generate the SET part of the SQL query
            set_clause = ', '.join([f"{col} = %s" for col in data_dict.keys()])

            if condition_dict:

            # Generate the WHERE part of the SQL query
                where_clause = ' AND '.join([f"{col} = %s" for col in condition_dict.keys()])


            if condition_dict:
            # Complete SQL query
                sql_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
                values = list(data_dict.values()) + list(condition_dict.values())

            else:
                sql_query = f"UPDATE {table_name} SET {set_clause}"
                values = list(data_dict.values())

            # Combine the values for the SET and WHERE parts


            logging.info(f"SQL Quey {sql_query} and values are {values}")

            ## Execute the query
            with conn.cursor() as cursor:
                cursor.execute(sql_query, values)
                conn.commit()
            logging.info("################################## Update successful")
        except Exception as e:
            conn.rollback()
            logging.error(f"Error updating table: {e}")
    def recognize_format(self,s):
        pattern1 = r'^[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)+$'
        pattern2 = r'^\[[a-zA-Z0-9]+\](\.\[[a-zA-Z0-9]+\])+$'
        pattern3 = r'^[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)+$'          # No brackets format
        pattern4 = r'^\[[a-zA-Z0-9_]+\](\.\[[a-zA-Z0-9_]+\])+$'
        pattern5= r'^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)+$'

        if re.match(pattern1, s):
            return True
        elif re.match(pattern2, s):
            return True
        elif re.match(pattern3, s):
            return True
        elif re.match(pattern4, s):
            return True
        elif re.match(pattern5, s):
            return True
        else:
            return False
    def generate_batch_queries(self, count_query, from_query, db_conn, df_size, time_column_check):
        """
        Generate batch SQL queries for pagination from a SQL Server database.

        Parameters:
        - count_query (str): SQL query to get the count of records.
        - from_query (str): SQL query to fetch the records.
        - df_size (int): Number of records per batch.

        Returns:
        - List[str]: List of SQL queries for each batch.
        """
        try:
            logging.info(f"primary id col is {time_column_check}")
            # List to hold the batch queries
            batch_queries = []
            logging.info(f"count query is {count_query}")
            try:
                with db_conn.cursor() as cursor:
                    # Execute the count query
                    # db_conn.timeout = 180000
                    # cursor.timeout=180000
                    #logging.info("Cursor timeout:", cursor.timeout)

                    cursor.execute(count_query)
                    total_count = cursor.fetchone()[0]
            except Exception as e:
                tb = traceback.format_exc()
                logging.error(f"Exception in executing count query {e},{tb}")
                return False,False


            logging.info(f"TOTAL COUNT {total_count} type {type(total_count)}")
            if total_count == 0:
                return False,0
                # raise ValueError("No Updated Records in DB")

            # Split the query into words to extract the last 5 words
            # last_five_words = from_query.split()[-5:]  # Get the last 5 words
            last_five_words =  [word.lower() for word in from_query.split()[-4:]]
            # logging.info(f"Last five words of the query: {last_five_words}")

            # Check if 'order by' is in the last 5 words
            if 'order' in last_five_words and 'by' in last_five_words:
                # logging.info(f"'ORDER BY' clause present")
                # Use the existing ORDER BY clause
                from_query = from_query.rstrip(';')
                base_query = from_query
            else:
                # logging.info(f"Adding 'ORDER BY'")
                # logging.info(f"time_column_check col is {time_column_check}")
                # Add a placeholder ORDER BY clause
                base_query = f"{from_query} ORDER BY {time_column_check}"

            # Calculate the total number of batches needed
            num_batches = (total_count + df_size - 1) // df_size

            # Generate batch queries
            for batch_number in range(num_batches):
                # Calculate the offset
                offset = batch_number * df_size

                # Construct the batch query with OFFSET and FETCH NEXT
                batch_query = (
                    f"{base_query} "
                    f"OFFSET {offset} ROWS "
                    f"FETCH NEXT {df_size} ROWS ONLY"
                )
                # logging.info(f"batch_query : {batch_query}")

                # Append the batch query to the list
                batch_queries.append(batch_query)

            return batch_queries,total_count
        except Exception as e:
            logging.error(f"Exception in count checking {e}")
            return False,False
    def pg_safe_col(self, col):
        """
        Quote PostgreSQL reserved keywords.
        """
        if col.lower() in {"group", "type", "user", "order", "value", "limit"}:
            return f'"{col}"'
        return col
    def modify_uuid_cols(self,df):
        # Regular expression pattern for UUID
        uuid_pattern = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')

        # Step 1: Identify columns that contain UUIDs
        uuid_columns = []
        for col in df.columns:
            if df[col].apply(lambda x: bool(uuid_pattern.match(str(x)))).any():
                uuid_columns.append(col)

        # Step 2: Convert identified UUID columns to strings
        for col in uuid_columns:
            # df[col] = df[col].astype(str)
            # Apply conversion only where value is a valid UUID
            df[col] = df[col].apply(lambda x: str(x) if pd.notna(x) and uuid_pattern.match(str(x)) else x)
        # logging.info the columns identified as containing UUIDs
        logging.info(f"Columns identified as containing UUIDs: {uuid_columns}")
        return df
    def convert_dict_to_json(self, value):
        """
        Convert dict or list values to JSON strings for PostgreSQL insertion.
        """
        if isinstance(value, (dict, list)):
            return json.dumps(value)
        return value
    def execute_update_queries(self, queries, postgres_conn):
        errors = []  # Capture query execution errors

        try:
            with postgres_conn.cursor() as cursor:
                logging.info(f"Starting execution of {len(queries)} update queries")

                # queries format: { "query_name": "SQL query" }
                for query_name, query_text in queries.items():
                    logging.info(f"Executing query: {query_name}")
                    logging.info(f"Query text: {query_text}")

                    start_time = time.time()

                    try:
                        cursor.execute(query_text)
                        postgres_conn.commit()

                        duration = time.time() - start_time
                        logging.info(
                            f"Query '{query_name}' executed successfully "
                            f"in {duration:.2f} seconds"
                        )

                    except Exception as e:
                        postgres_conn.rollback()

                        logging.error(
                            f"Failed to execute query '{query_name}'. "
                            f"Error: {str(e)}"
                        )

                        errors.append({
                            "error_query": query_name,
                            "trigger_name": "error updating inventory data from 1.0",
                            "error_msg": str(e),
                            "error_timestamp": datetime.now(timezone.utc).replace(tzinfo=None)
                        })

        except Exception as e:
            logging.error(
                f"Unexpected error in execute_update_queries: {str(e)}",
                exc_info=True
            )

        logging.info(
            f"Finished executing queries. "
            f"Success: {len(queries) - len(errors)}, "
            f"Failed: {len(errors)}"
        )

        return errors
    def update_last_id_list(self, insert_table_name, primary_id_columns, psql_connection):
        """
        Fetches the latest row values based on primary ID or timestamp columns.
        """

        try:
            last_id_time = []

            with psql_connection.cursor() as cursor:
                # Build select column list
                select_cols = primary_id_columns

                # Use the first column for ordering
                order_col = primary_id_columns

                query = f"""
                    SELECT {select_cols}
                    FROM {insert_table_name}
                    ORDER BY {order_col} DESC
                    LIMIT 1
                """

                cursor.execute(query)
                result = cursor.fetchone()

                if result:
                    for value in result:
                        if isinstance(value, datetime):
                            last_id_time.append(value.isoformat())
                        else:
                            last_id_time.append(value)
                else:
                    last_id_time = None

        except Exception as fetch_error:
            last_id_time = None
            logging.error(f"{insert_table_name} Error fetching last inserted record: {fetch_error}")

        return last_id_time
    def get_from_clause_index(self,query):
        """
        Identifies the starting index of the "FROM" clause in a SQL query.

        This method uses a regular expression to locate the standalone "FROM" keyword
        in the provided SQL query, ignoring case sensitivity. It raises an exception
        if the "FROM" clause is not found in the query.

        Args:
            query (str): The SQL query string.

        Returns:
            int: The starting index of the "FROM" keyword in the query.

        Raises:
            ValueError: If the query does not contain a "FROM" clause.
        """
    # This regex will match the standalone "FROM" keyword
        match = re.search(r"\bFROM\b", query, re.IGNORECASE)
        if match:
            return match.start()  # Return the starting index of "FROM"
        else:
            raise ValueError("Invalid query: Missing FROM clause.")
    def clean_query(self, original_query):
    # Split the query by 'ORDER BY' into parts
        parts = original_query.rsplit('ORDER BY')
        #return None
    # Count the number of ORDER BY clauses
        order_by_count = len(parts) - 1  # Each 'ORDER BY' splits the query into parts

    # Check if there are multiple ORDER BY clauses
        if order_by_count > 1:
        # Rebuild the query without the second ORDER BY clause
            query_without_second_order_by = parts[0] + 'ORDER BY' + ''.join(parts[1:2])  # Keep the first ORDER BY and everything after the first
        elif order_by_count == 1:
        # Only one ORDER BY found, return the part before it
            query_without_second_order_by = parts[0]
        else:
            # No ORDER BY found
            query_without_second_order_by = original_query

    # Remove trailing semicolon and whitespace
        query_cleaned = query_without_second_order_by.rstrip(';').strip()

        return query_cleaned  # Return both cleaned query
    def get_count_query(self,original_query):
        # Clean the original query
        cleaned_query = self.clean_query(original_query)

        # Construct the count query
        count_query = f"""
        SELECT COUNT(*) AS total_count
        FROM (
            {cleaned_query}
        ) AS subquery;
        """
        logging.info(f"count_query {count_query}")
        return count_query
    def get_updated_records_query(self, columns, last_id, full_from_table, query, error_id_list):
        """
        Generate a query to fetch updated records based on dynamic conditions.

        This method constructs a SQL query dynamically to fetch records that are updated
        (based on `id`, `modifieddate`, and `deleteddate`) after the provided values.
        It supports handling table aliases and building WHERE clauses intelligently.

        Args:
            columns (list): List of column names to use in the WHERE clause.
            last_id (list): List of values corresponding to the columns for filtering.
            full_from_table (str): Fully qualified table name if provided.
            query (str): The base query string to enhance with dynamic WHERE conditions.
            error_id_list (list): List of error IDs to include in the query.

        Returns:
            str: A dynamically constructed query string.
            None: If an error occurs during query generation.

        Raises:
            ValueError: If the base query is invalid (e.g., missing a FROM clause).
        """
        try:
            # Initialize the WHERE clause
            where_conditions = []
            modified_date_condition = None
            deleted_date_condition = None

            # Parse the FROM clause to extract table aliases
            from_clause_start = self.get_from_clause_index(query)
            if from_clause_start == -1:
                raise ValueError("Invalid query: Missing FROM clause.")

            # Extract the part of the query after FROM
            from_clause = query[from_clause_start + 4:].strip()

            # Split on JOIN, comma, or WHERE to isolate the FROM section
            from_clause = from_clause.split(" WHERE")[0].split(" JOIN")[0].split(",")[0].strip()
            from_clause_split = from_clause.split()

            table_aliases = {}
            for idx, word in enumerate(from_clause_split):
                if self.recognize_format(word):
                    # Check if there is an alias available
                    if idx + 1 < len(from_clause_split):
                        alias = from_clause_split[idx + 1]
                        table_aliases[alias] = word

            # Check if ModifiedDate, DeletedDate, or ID exists in the query to determine alias
            date_column_alias = None
            for alias in table_aliases:
                alias_modifieddate = f"{alias}.modifieddate"
                alias_deleteddate = f"{alias}.deleteddate"
                alias_id = f"{alias}.id"

                # Check if any of these columns with alias exist in the query
                if (alias_modifieddate in query.lower() or
                    alias_deleteddate in query.lower() or
                    alias_id in query.lower()):
                    date_column_alias = alias
                    break

            # Constructing the WHERE clause dynamically
            for col, val in zip(columns, last_id):
                col_lower = col.lower()

                if col_lower == 'id' and date_column_alias:
                    col_with_alias = f"{date_column_alias}.{col}"
                    if isinstance(val, str):
                        where_conditions.append(f"{col_with_alias} > '{val}'")
                    else:
                        where_conditions.append(f"{col_with_alias} > {val}")

                elif col_lower == "modifieddate":
                    if date_column_alias:
                        col_with_alias = f"{date_column_alias}.{col}"
                        if isinstance(val, str):
                            modified_date_condition = f"{col_with_alias} > '{val}'"
                        else:
                            modified_date_condition = f"{col_with_alias} > {val}"
                    elif col_lower in query.lower():
                        # Handle case where no alias but column exists in query
                        if isinstance(val, str):
                            modified_date_condition = f"{col} > '{val}'"
                        else:
                            modified_date_condition = f"{col} > {val}"

                elif col_lower == "deleteddate":
                    if date_column_alias:
                        col_with_alias = f"{date_column_alias}.{col}"
                        if isinstance(val, str):
                            deleted_date_condition = f"{col_with_alias} > '{val}'"
                        else:
                            deleted_date_condition = f"{col_with_alias} > {val}"
                    elif col_lower in query.lower():
                        # Handle case where no alias but column exists in query
                        if isinstance(val, str):
                            deleted_date_condition = f"{col} > '{val}'"
                        else:
                            deleted_date_condition = f"{col} > {val}"

                else:
                    # Handle other columns
                    if isinstance(val, str):
                        where_conditions.append(f"{col} > '{val}'")
                    else:
                        where_conditions.append(f"{col} > {val}")

            # Handle error_id_list
            if error_id_list:
                if date_column_alias:
                    col_with_alias = f"{date_column_alias}.id"
                    error_id_list_str = ', '.join([str(i) for i in error_id_list])
                    error_id_condition = f"{col_with_alias} IN ({error_id_list_str})"
                    where_conditions.append(error_id_condition)
                else:
                    error_id_list_str = ', '.join([str(i) for i in error_id_list])
                    error_id_condition = f"id IN ({error_id_list_str})"
                    where_conditions.append(error_id_condition)

            # Combine the conditions
            where_clause = ""
            if where_conditions:
                where_clause = " WHERE " + " OR ".join(where_conditions)

            # Add modified date condition
            if modified_date_condition:
                if where_clause:
                    where_clause += f" OR {modified_date_condition}"
                else:
                    where_clause = f" WHERE {modified_date_condition}"

            # Add deleted date condition
            if deleted_date_condition:
                if where_clause:
                    where_clause += f" OR {deleted_date_condition}"
                else:
                    where_clause = f" WHERE {deleted_date_condition}"

            # Construct the final query
            if full_from_table:
                migrate_records = f"SELECT * FROM {full_from_table}{where_clause} ORDER BY id ASC"
            elif query:
                if "ORDER BY" in query.upper():
                    parts = query.rsplit("ORDER BY", 1)
                    # Add the WHERE clause before the last "ORDER BY"
                    query = parts[0] + where_clause + " ORDER BY" + parts[1]
                else:
                    query += where_clause
                migrate_records = query

        except Exception as e:
            logging.error(f"Error in generating query to select records: {e}")
            migrate_records = None

        return migrate_records
    def last_id_migration_psql(
            self,
            to_connection,
            postgres_conn,
            migration_details_dict,
            migration_table,
            job_name,
            trace_id
    ):
        try:
            # --------------------------------------
            # Environment & table setup
            # --------------------------------------
            history_table = os.getenv('MIGRATIONS_HISTORY_TABLE')
            to_table = migration_details_dict.get('table_name')
            conflict_cols = migration_details_dict.get('conflict_cols')
            time_columns = migration_details_dict.get('primary_id_column')
            df_size = int(os.getenv('DF_SIZE', 5000))  # default batch size

            logging.info(f"{trace_id} {job_name} → Time column(s): {time_columns}")

            last_id = migration_details_dict.get('last_id')
            success_count = 0

            # --------------------------------------
            # Helper function to fetch last_id from DB
            # --------------------------------------
            def fetch_last_id():
                try:
                    return self.update_last_id_list(to_table, migration_details_dict['primary_id_column'], to_connection)
                except Exception as e:
                    logging.error(f"{trace_id} {job_name} → Failed to fetch last_id from DB: {e}")
                    return None

            # --------------------------------------
            # Process last_id safely
            # --------------------------------------
            if last_id:
                try:
                    if last_id in ['[null]', 'null', '[]']:
                        logging.info(f"{trace_id} {job_name} → last_id is null-like, fetching from DB")
                        last_id = fetch_last_id()
                    elif isinstance(last_id, str) and last_id.startswith('{') and last_id.endswith('}'):
                        last_id = [int(last_id[1:-1])]
                        logging.info(f"{trace_id} {job_name} → Parsed curly-brace last_id: {last_id}")
                    elif isinstance(last_id, str):
                        last_id = json.loads(last_id)
                        logging.info(f"{trace_id} {job_name} → Loaded JSON last_id: {last_id}")
                    elif isinstance(last_id, int):
                        last_id = [last_id]
                        logging.info(f"{trace_id} {job_name} → Converted int last_id to list: {last_id}")
                except Exception as e:
                    logging.error(f"{trace_id} {job_name} → Error parsing last_id: {e}")
                    last_id = fetch_last_id()
            else:
                logging.info(f"{trace_id} {job_name} → last_id missing, fetching from DB")
                last_id = fetch_last_id()

            logging.info(f"{trace_id} {job_name} → Final last_id to use: {last_id}")

            # --------------------------------------
            # Fetch previous error IDs
            # --------------------------------------
            error_ids_query = f"""
                SELECT error_id_list, job_end_time
                FROM {history_table}
                WHERE job_name = '{job_name}' AND trace_id <> '{trace_id}'
                ORDER BY job_end_time DESC
                LIMIT 1
            """
            error_ids_df = self.execute_query(postgres_conn, error_ids_query)
            error_id_list = []
            last_migrated_time_prev = None
            if error_ids_df is not None and not error_ids_df.empty:
                error_id_list = error_ids_df['error_id_list'][0]
                last_migrated_time_prev = error_ids_df['job_end_time'][0]
            logging.info(f"{trace_id} {job_name} → Previous error IDs:")

            # --------------------------------------
            # Fetch last successful migration time
            # --------------------------------------
            last_migrated_time_query = f"""
                SELECT job_end_time
                FROM {history_table}
                WHERE job_name='{job_name}' AND trace_id<>'{trace_id}' AND job_status_msg='SUCCESS'
                ORDER BY id DESC LIMIT 1
            """
            last_migrated_df = self.execute_query(postgres_conn, last_migrated_time_query)
            if last_migrated_df is not None and not last_migrated_df.empty:
                last_migrated_time_job = last_migrated_df['job_end_time'][0]
            else:
                last_migrated_time_job = None
                logging.info(f"{trace_id} {job_name} → No previous successful migration found.")

            last_migrated_time = last_migrated_time_job or migration_details_dict.get('last_migrated_time')
            logging.info(f"{trace_id} {job_name} → Using last migrated time: {last_migrated_time}")

            # --------------------------------------
            # Construct the from_query dynamically
            # --------------------------------------
            from_query_ = migration_details_dict.get('data_query')
            if not from_query_:
                raise ValueError(f"{trace_id} {job_name} → data_query is missing in migration_details_dict")

            from_query_ = ' '.join(from_query_.split()).rstrip(';')

            if "modified_date" in from_query_.lower() and "created_date" in from_query_.lower() and isinstance(last_id[0], str):
                time_columns_dup = copy.deepcopy(time_columns)
                time_columns_dup.append("ModifiedDate")
                last_id_dup = [last_migrated_time, last_migrated_time]
                from_query = self.get_updated_records_query(time_columns_dup, last_id_dup, None, from_query_, error_id_list)
            elif "modified_date" in from_query_.lower() and isinstance(last_id[0], int):
                where_condition_cols = ['modified_date'] + time_columns if isinstance(time_columns, list) else ['modified_date', time_columns]
                last_migrated_time_str = str(last_migrated_time)
                last_migrated_time_str = self.to_psql_timestamp(last_migrated_time_str)
                where_condition_vals = [last_migrated_time_str, last_id[0]]
                from_query = self.get_updated_records_query(where_condition_cols, where_condition_vals, None, from_query_, error_id_list)
            else:
                from_query = from_query_

            logging.info(f"{trace_id} {job_name} → Final query for migration: {from_query}")

            # --------------------------------------
            # Count and batch queries
            # --------------------------------------
            count_query = self.get_count_query(from_query)
            logging.info(f"{trace_id} {job_name} → Count query: {count_query}")

            try:
                batch_queries, total_count = self.generate_batch_queries(count_query, from_query, to_connection, df_size, time_columns)
                if not batch_queries or total_count is False:
                    error_msg = "No batch queries generated or total_count invalid"
                    logging.info(f"{trace_id} {job_name} → {error_msg}")
                    update_dict = {'error_msg': error_msg, 'job_end_time': datetime.now(timezone.utc).replace(tzinfo=None)}
                    self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
                    return False
            except Exception as e:
                tb = traceback.format_exc()
                logging.error(f"{trace_id} {job_name} → Error generating batch queries: {e}\n{tb}")
                update_dict = {'error_msg': str(e), 'job_end_time': datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
                return False

            if total_count == 0:
                logging.info(f"{trace_id} {job_name} → No records found for migration")
                update_dict = {
                    'error_msg': "No records found",
                    'job_end_time': datetime.now(timezone.utc).replace(tzinfo=None),
                    'total_count': total_count,
                    'success': 0,
                    'failed': 0,
                    'job_status_msg': 'SUCCESS'
                }
                self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
                return True

            update_dict = {'total_count': total_count}
            self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
            logging.info(f"{trace_id} {job_name} → Total records to migrate: {total_count}")

            # --------------------------------------
            # Execute batch queries
            # --------------------------------------
            max_retries = 3
            for query in batch_queries:
                attempt = 1
                while attempt <= max_retries:
                    try:
                        df = self.execute_query(to_connection, query)
                        if df is not None:
                            df = df.astype(object).mask(df.isna(), None)
                            df = self.modify_uuid_cols(df)
                            logging.info(f"{trace_id} {job_name} → Batch executed, rows: {len(df)}")
                            break
                        else:
                            logging.info(f"{trace_id} {job_name} → Batch query returned None, retrying...")
                            attempt += 1
                            time.sleep(5)
                    except Exception as e:
                        logging.error(f"{trace_id} {job_name} → Error executing batch query: {e}")
                        attempt += 1
                        time.sleep(5)

                # --------------------------------------
                # Start migration for this batch
                # --------------------------------------
                success_count = self.initate_complete_migration_psql(
                    df,
                    to_connection,
                    postgres_conn,
                    migration_table,
                    conflict_cols,
                    job_name,
                    migration_details_dict,
                    to_table,
                    trace_id,
                    total_count,
                    success_count
                )
                logging.info(f"{trace_id} {job_name} → Success count so far: {success_count}")

            return success_count

        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"{trace_id} {job_name} → Unexpected error during last_id_migration_psql: {e}\n{tb}")
            update_dict = {'error_msg': str(e), 'job_end_time': datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
            return False

    def insert_records_postgresql_batch_5_psql(
        self,
        postgres_connection,
        df,
        insert_table_name,
        conflict_cols,
        trace_id
    ):
        try:
            logging.info(f"[{trace_id}] [START] insert_records_postgresql_batch_5_psql")
            logging.info(f"[{trace_id}] Target table: {insert_table_name}")
            logging.info(f"[{trace_id}] Total records received: {len(df)}")

            inserted_records = 0
            failed_records = 0
            insert_flag = True
            batch_size = 5000
            failed_log = []
            last_id_value = None
            error_msg = "SUCCESS"
            error_id_list = []

            num_batches = math.ceil(len(df) / batch_size)
            logging.info(f"[{trace_id}] Batch size: {batch_size}")
            logging.info(f"[{trace_id}] Total batches to process: {num_batches}")

            # Column handling
            # columns = ', '.join(df.columns)
            safe_columns = [self.pg_safe_col(col) for col in df.columns]
            columns = ', '.join(safe_columns)

            conflict_cols = json.loads(conflict_cols)
            time_column_snake_case = conflict_cols

            logging.info(f"[{trace_id}] Conflict columns: {conflict_cols}")

            # update_clause = ', '.join([
            #     f"{col} = EXCLUDED.{col}"
            #     for col in df.columns
            #     if col not in time_column_snake_case
            # ])
            update_clause = ', '.join(
                f"{self.pg_safe_col(col)} = EXCLUDED.{self.pg_safe_col(col)}"
                for col in df.columns
                if col not in time_column_snake_case
            )

            conflict_cols_str = ", ".join(conflict_cols)

            total_start_time = time.time()

            # ----------------------------------------------------------
            # Batch insertion logic
            # ----------------------------------------------------------
            def insert_block_operation():
                nonlocal inserted_records, failed_records, last_id_value, insert_flag, error_msg, error_id_list

                for batch_index in range(num_batches):
                    start_index = batch_index * batch_size
                    end_index = min((batch_index + 1) * batch_size, len(df))
                    batch_df = df.iloc[start_index:end_index]

                    # rows = [tuple(row) for row in batch_df.to_numpy()]

                    rows = [
                        tuple(self.convert_dict_to_json(v) for v in row)
                        for row in batch_df.to_numpy()
                    ]

                    insert_query = f"""
                        INSERT INTO {insert_table_name} ({columns})
                        VALUES %s
                        ON CONFLICT ({conflict_cols_str}) DO UPDATE
                        SET {update_clause}
                    """

                    logging.info(
                        f"[{trace_id}] Processing batch "
                        f"{batch_index + 1}/{num_batches} | "
                        f"Rows: {start_index} - {end_index}"
                    )

                    batch_start_time = time.time()

                    try:
                        with postgres_connection.cursor() as cur:
                            execute_values(cur, insert_query, rows)

                        postgres_connection.commit()
                        inserted_records += len(rows)

                        last_id_value = [
                            rows[-1][batch_df.columns.get_loc(col)]
                            for col in time_column_snake_case
                        ]

                        logging.info(
                            f"[{trace_id}] Batch {batch_index + 1} SUCCESS | "
                            f"Inserted: {len(rows)} | "
                            f"Total Inserted: {inserted_records}"
                        )

                    except psycopg2.Error as batch_error:
                        logging.info(
                            f"[{trace_id}] Batch {batch_index + 1} FAILED | "
                            f"Error: {batch_error}"
                        )
                        postgres_connection.rollback()

                        # Row-level fallback
                        for row_index, row in batch_df.iterrows():
                            try:
                                row_tuple = tuple(row.to_numpy())

                                with postgres_connection.cursor() as cur:
                                    cur.execute(insert_query, (row_tuple,))

                                postgres_connection.commit()
                                inserted_records += 1
                                last_id_value = [row[col] for col in time_column_snake_case]

                            except psycopg2.Error as row_error:
                                postgres_connection.rollback()
                                failed_records += 1
                                insert_flag = False
                                error_msg = str(row_error)

                                error_id_list.append(row["id"])

                                failed_log.append({
                                    "batch": batch_index + 1,
                                    "row_index": row_index + start_index,
                                    "error": str(row_error),
                                    "failed_id": row["id"]
                                })

                                logging.info(
                                    f"[{trace_id}] Row insert FAILED | "
                                    f"Batch: {batch_index + 1} | "
                                    f"Row ID: {row['id']} | "
                                    f"Error: {row_error}"
                                )

                    batch_end_time = time.time()
                    logging.info(
                        f"[{trace_id}] Batch {batch_index + 1} completed in "
                        f"{batch_end_time - batch_start_time:.2f}s"
                    )

            try:
                insert_block_operation()
            except Exception as e:
                last_id_value = None
                error_msg = str(e)
                logging.error(f"[{trace_id}] Fatal error during insert operation: {e}")

            total_end_time = time.time()
            logging.info(
                f"[{trace_id}] Insert completed | "
                f"Total Time: {total_end_time - total_start_time:.2f}s | "
                f"Inserted: {inserted_records} | "
                f"Failed: {failed_records}"
            )

            if failed_records > 0:
                last_id_value = None

        except Exception as e:
            tb = traceback.format_exc()
            error_msg = f"Error in inserting records: {e}"
            logging.error(f"[{trace_id}] CRITICAL ERROR: {error_msg}\n{tb}")
            return False, 0, 0, None, error_msg, error_id_list

        logging.info(f"[{trace_id}] [END] insert_records_postgresql_batch_5_psql")
        return insert_flag, inserted_records, failed_records, last_id_value, error_msg, error_id_list

    def get_updated_records_query_psql(self, columns, last_id, full_from_table, query, error_id_list):
        """
        Generate a SQL query to fetch updated records based on dynamic conditions.

        Args:
            columns (list): Column names for filtering.
            last_id (list): Values corresponding to the columns.
            full_from_table (str): Fully qualified table name, if provided.
            query (str): Base SQL query to enhance.
            error_id_list (list): List of error IDs to include in query.

        Returns:
            str: Dynamically constructed SQL query.
            None: If error occurs.
        """
        try:
            if not query and not full_from_table:
                raise ValueError("Either 'query' or 'full_from_table' must be provided.")

            # Parse FROM clause to find table aliases
            from_clause_start = self.get_from_clause_index(query) if query else -1
            table_alias = None
            if from_clause_start != -1:
                from_clause = query[from_clause_start + 4:].strip()
                from_clause = from_clause.split(" WHERE")[0].split(" JOIN")[0].split(",")[0].strip()
                from_words = from_clause.split()
                if len(from_words) > 1 and self.recognize_format(from_words[0]):
                    table_alias = from_words[1]

            # Build conditions
            where_conditions = []
            modified_condition = None
            deleted_condition = None

            for col, val in zip(columns, last_id):
                col_lower = col.lower()
                col_name = f"{table_alias}.{col}" if table_alias else col

                if col_lower == "id":
                    where_conditions.append(f"{col_name} > {val}" if isinstance(val, (int, float)) else f"{col_name} > '{val}'")
                elif col_lower == "modifieddate":
                    modified_condition = f"{col_name} > '{val}'" if isinstance(val, str) else f"{col_name} > {val}"
                elif col_lower == "deleteddate":
                    deleted_condition = f"{col_name} > '{val}'" if isinstance(val, str) else f"{col_name} > {val}"
                else:
                    where_conditions.append(f"{col_name} > '{val}'" if isinstance(val, str) else f"{col_name} > {val}")

            # Include error_id_list
            if error_id_list:
                error_col = f"{table_alias}.id" if table_alias else "id"
                ids_str = ', '.join([str(i) for i in error_id_list])
                where_conditions.append(f"{error_col} IN ({ids_str})")

            # Combine conditions
            all_conditions = []
            if where_conditions:
                all_conditions.append("(" + " OR ".join(where_conditions) + ")")
            if modified_condition:
                all_conditions.append(modified_condition)
            if deleted_condition:
                all_conditions.append(deleted_condition)

            where_clause = ""
            if all_conditions:
                where_clause = " WHERE " + " OR ".join(all_conditions)

            # Construct final query
            if full_from_table:
                final_query = f"SELECT * FROM {full_from_table}{where_clause} ORDER BY id ASC"
            else:
                query = query.rstrip(';')
                if "ORDER BY" in query.upper():
                    parts = query.rsplit("ORDER BY", 1)
                    final_query = parts[0] + where_clause + " ORDER BY" + parts[1]
                else:
                    final_query = query + where_clause

            return final_query

        except Exception as e:
            logging.error(f"[ERROR] {e} - Failed to generate updated records query")
            return None
    def update_migration_details_dict(self,status,success,failures,last_id_value,error_msg):
        try:
            migration_details_updated_dict={}
            migration_details_updated_dict['status']=status
            migration_update_list=[]
            migration_update_dict={'Success_Records':success,'failed_records':failures}
            migration_details_updated_dict['last_id']=str(last_id_value)
            migration_update_list.append(migration_update_dict)
            migration_details_updated_dict['migration_update']=json.dumps(migration_update_list)
            migrated_time=datetime.utcnow()
            migration_details_updated_dict['last_migrated_time']=migrated_time
            migration_details_updated_dict['error_message']=error_msg
            logging.info(f"migration_details_updated_dict is {migration_details_updated_dict}")

        except Exception as e:
            logging.error(f"Error while updating migration details dict : {e}")
        return migration_details_updated_dict

    def initate_complete_migration_psql(
        self,
        df,
        to_connection,
        postgres_conn,
        migration_table,
        conflict_cols,
        job_name,
        migration_details_dict,
        to_table,
        trace_id,
        total_count,
        success_count=0,
    ):
        """
        Inserts a batch of records into PostgreSQL and updates migration state.
        """
        history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")

        # Defaults to avoid UnboundLocalError in except block
        error_id_list = []
        error_msg = None
        failures = 0
        job_status_msg = "FAILED"

        try:
            logging.info(f"[{trace_id}] Starting batch migration for table: {to_table}")
            logging.info(f"[{trace_id}] Conflict columns: {conflict_cols}")

            # --------------------------------------------------
            # Insert records
            # --------------------------------------------------
            (
                insert_records,
                success,
                failures,
                last_id_value,
                error_msg,
                error_id_list,
            ) = self.insert_records_postgresql_batch_5_psql(
                to_connection, df, to_table, conflict_cols, trace_id
            )

            success_count += success

            logging.info(
                f"[{trace_id}] Batch result → "
                f"Inserted: {success}, Failed: {failures}, "
                f"Total Success: {success_count}, Last ID: {last_id_value}"
            )

            # --------------------------------------------------
            # Determine job status
            # --------------------------------------------------
            if total_count and (success_count + failures == total_count):
                job_status_msg = "SUCCESS"

            # --------------------------------------------------
            # Update last_id if missing
            # --------------------------------------------------
            if last_id_value is None:
                logging.info(f"[{trace_id}] Last ID missing, recalculating...")
                last_id_value = self.update_last_id_list(
                    to_table,migration_details_dict['primary_id_column'], to_connection
                )
                logging.info(f"[{trace_id}] Last ID after, recalculating... {last_id_value}")
            

            # --------------------------------------------------
            # Update migration tracking table
            # --------------------------------------------------
            migration_update_payload = self.update_migration_details_dict(
                insert_records,
                success,
                failures,
                last_id_value,
                error_msg,
            )

            logging.info(
                f"[{trace_id}] Updating migration table → "
                f"Status: {migration_update_payload.get('status')}, "
                f"Last ID: {migration_update_payload.get('last_id')}"
            )

            self.update_table(
                postgres_conn,
                migration_table,
                migration_update_payload,
                {"migration_name": job_name},
            )

            # --------------------------------------------------
            # Execute post-migration update queries (if any)
            # --------------------------------------------------
            if migration_details_dict.get("is_update"):
                queries = migration_details_dict.get("update_queries", [])
                if queries:
                    logging.info(f"[{trace_id}] Executing post-migration update queries")
                    self.execute_update_queries(queries, to_connection)

            # --------------------------------------------------
            # Update history table
            # --------------------------------------------------
            history_update = {
                "error_id_list": json.dumps(error_id_list),
                "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                "error_msg": error_msg,
                "success": success_count,
                "failed": failures,
                "job_status_msg": job_status_msg,
            }

            self.update_table(
                postgres_conn,
                history_table,
                history_update,
                {"trace_id": trace_id},
            )

            logging.info(f"[{trace_id}] Batch migration completed → {job_status_msg}")
            return success_count

        except Exception as e:
            tb = traceback.format_exc()
            error_message = f"Error during migration: {e}\n{tb}"

            logging.error(f"[{trace_id}]  Migration error: {e}")

            # Safe history update on failure
            self.update_table(
                postgres_conn,
                history_table,
                {
                    "error_id_list": json.dumps(error_id_list),
                    "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    "error_msg": error_message,
                    "job_status_msg": "FAILED",
                },
                {"trace_id": trace_id},
            )

            return False

    def first_migration_psql(
        self,
        to_connection,
        from_connection,
        postgres_conn,
        migration_details_dict,
        migration_table,
        job_name,
        trace_id,
    ):
        """
        Perform the first migration process for moving data from source DB
        to target PostgreSQL database.
        """

        try:
            logging.info(f"[{trace_id}] Starting FIRST migration process")

            history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")
            from_query = migration_details_dict["data_query"]
            conflict_cols = migration_details_dict["conflict_cols"]
            primary_id_col = migration_details_dict["primary_id_column"]
            to_table = migration_details_dict["table_name"]

            df_size = int(os.getenv("DF_SIZE", 10000))
            max_retries = 3
            success_count = 0

            # --------------------------------------------------
            # Clean & prepare queries
            # --------------------------------------------------
            from_query = " ".join(from_query.split()).rstrip(";")
            count_query = " ".join(self.get_count_query(from_query).split())

            logging.info(f"[{trace_id}] FROM QUERY  : {from_query}")
            logging.info(f"[{trace_id}] COUNT QUERY : {count_query}")

            # --------------------------------------------------
            # Generate batch queries
            # --------------------------------------------------
            try:
                batch_queries, total_count = self.generate_batch_queries(
                    count_query,
                    from_query,
                    from_connection,
                    df_size,
                    primary_id_col,
                )
            except Exception as e:
                tb = traceback.format_exc()
                self.update_table(
                    postgres_conn,
                    history_table,
                    {
                        "error_msg": f"Error generating batch queries: {e}\n{tb}",
                        "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    },
                    {"trace_id": trace_id},
                )
                return False

            if total_count == 0:
                logging.info(f"[{trace_id}] No records found for migration")

                self.update_table(
                    postgres_conn,
                    history_table,
                    {
                        "total_count": 0,
                        "success": 0,
                        "failed": 0,
                        "job_status_msg": "SUCCESS",
                        "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    },
                    {"trace_id": trace_id},
                )
                return True

            # --------------------------------------------------
            # Update total count
            # --------------------------------------------------
            self.update_table(
                postgres_conn,
                history_table,
                {"total_count": total_count},
                {"trace_id": trace_id},
            )

            logging.info(f"[{trace_id}] Total records to migrate: {total_count}")

            # --------------------------------------------------
            # Execute batch queries
            # --------------------------------------------------
            for query in batch_queries:
                logging.info(f"[{trace_id}] Executing batch query")

                df = None
                attempt = 1

                while attempt <= max_retries:
                    try:
                        df = self.execute_query(from_connection, query)

                        if df is not None and not df.empty:
                            df = df.astype(object).mask(df.isna(), None)
                            df = self.modify_uuid_cols(df)

                            logging.info(
                                f"[{trace_id}] Batch fetched | rows={df.shape[0]}"
                            )
                            break

                        logging.info(
                            f"[{trace_id}] Empty DataFrame, retrying (attempt {attempt})"
                        )
                    except Exception as e:
                        logging.error(
                            f"[{trace_id}] Batch query error (attempt {attempt}): {e}"
                        )

                    attempt += 1
                    time.sleep(5)

                if df is None or df.empty:
                    raise Exception("Failed to fetch batch data after retries")

                # --------------------------------------------------
                # Start migration for this batch
                # --------------------------------------------------
                success_count = self.initate_complete_migration_psql(
                    df,
                    to_connection,
                    postgres_conn,
                    migration_table,
                    conflict_cols,
                    job_name,
                    migration_details_dict,
                    to_table,
                    trace_id,
                    total_count,
                    success_count,
                )

                logging.info(f"[{trace_id}] Success count so far: {success_count}")

            # --------------------------------------------------
            # Final success update
            # --------------------------------------------------
            self.update_table(
                postgres_conn,
                history_table,
                {
                    "success": success_count,
                    "failed": total_count - success_count,
                    "job_status_msg": "SUCCESS",
                    "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                },
                {"trace_id": trace_id},
            )

            logging.info(f"[{trace_id}] FIRST migration completed successfully")
            return True

        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"[{trace_id}] FIRST migration failed: {e}")

            self.update_table(
                postgres_conn,
                history_table,
                {
                    "error_msg": f"{e}\n{tb}",
                    "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                },
                {"trace_id": trace_id},
            )
            return False

    def get_to_db_config_psql(self, migration_details_dict):
        """
        Extract and process database configuration from migration details.

        This method retrieves the database configuration from the given migration details dictionary.
        If the configuration is a JSON string, it converts it into a Python dictionary.
        If the configuration is not present or invalid, it falls back to a default configuration.

        Args:
            migration_details_dict (dict): A dictionary containing migration details,
                                        including the database configuration under 'from_db_config'.

        Returns:
            dict: A dictionary containing database configuration details, either from the input
        """
        db_config = migration_details_dict.get('to_db_config')
        if db_config and not isinstance(db_config, dict):
            db_config = json.loads(db_config)
        return db_config 
    def from_db_config_psql(self, migration_details_dict):
        """
        Extract and process database configuration from migration details.

        This method retrieves the database configuration from the given migration details dictionary.
        If the configuration is a JSON string, it converts it into a Python dictionary.
        If the configuration is not present or invalid, it falls back to a default configuration.

        Args:
            migration_details_dict (dict): A dictionary containing migration details,
                                        including the database configuration under 'from_db_config'.

        Returns:
            dict: A dictionary containing database configuration details, either from the input
        """
        db_config = migration_details_dict.get('from_db_config')
        if db_config and not isinstance(db_config, dict):
            db_config = json.loads(db_config)
        return db_config
    def to_psql_timestamp(self,ts_str: str) -> str:
        """
        Convert a timestamp like '2025-11-24 14:23:55.260032+00:00'
        into PostgreSQL compatible format '2025-11-24 14:23:55.260032+00'.
        """
        dt = datetime.fromisoformat(ts_str)
        return dt.strftime("%Y-%m-%d %H:%M:%S.%f%z")
    def start_migration_sync_psql(self, job_name, key_name=None):
        """
        Starts PostgreSQL migration job for 2.0+ tables.
        Handles first-time and last-id-based migrations.
        """
        postgres_conn = None
        trace_id = None

        try:
            logging.info(f"[INFO] Starting migration sync for job: {job_name}")

            # --------------------------------------------------
            # Load environment variables
            # --------------------------------------------------
            load_dotenv()

            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            db_name = os.getenv("PSQL_DB_NAME")
            history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")

            # --------------------------------------------------
            # Connect to Metadata DB
            # --------------------------------------------------
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info("[INFO] Connected to PostgreSQL metadata DB")

            # --------------------------------------------------
            # Insert Job Start History
            # --------------------------------------------------
            job_start_time = datetime.now(timezone.utc).replace(tzinfo=None)

            hist_insert_data = {
                "key_name": key_name,
                "job_name": job_name,
                "job_start_time": job_start_time,
                "request_triggered_by": "optimization_sync_lambda",
            }

            trace_id = self.insert_dict(
                postgres_conn,
                history_table,
                hist_insert_data,
                True,
                "trace_id",
            )

            logging.info(f"[INFO] Job started | trace_id={trace_id}")

            # --------------------------------------------------
            # Fetch migration details
            # --------------------------------------------------
            migration_table = "data_sync_mappings_for_inv_20"
            migration_details = self.get_migration_details(
                job_name, postgres_conn, migration_table
            )

            # --------------------------------------------------
            # Load DB configurations
            # --------------------------------------------------
            to_db_config = self.get_to_db_config_psql(migration_details)
            from_db_config = self.from_db_config_psql(migration_details)

            if not to_db_config or not from_db_config:
                msg = f"Missing DB configuration for migration '{job_name}'"
                logging.info(f"[ERROR] {msg}")

                self.update_table(
                    postgres_conn,
                    history_table,
                    {
                        "error_msg": msg,
                        "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    },
                    {"trace_id": trace_id},
                )
                return False

            logging.info("[INFO] Source and Target DB configs loaded successfully")

            # --------------------------------------------------
            # Create DB connections
            # --------------------------------------------------
            to_connection = self.create_connection(
                to_db_config["to_db_type"],
                to_db_config["hostname"],
                to_db_config["to_database"],
                to_db_config["user"],
                to_db_config["password"],
                to_db_config["port"],
            )

            from_connection = self.create_connection(
                from_db_config["to_db_type"],
                from_db_config["hostname"],
                from_db_config["to_database"],
                from_db_config["user"],
                from_db_config["password"],
                from_db_config["port"],
            )

            table_name = migration_details["table_name"]
            logging.info(f"[INFO] Starting migration for table: {table_name}")

            # --------------------------------------------------
            # Execute Migration
            # --------------------------------------------------
            migration_status = migration_details.get("status")
            
            if migration_status == "first":
                logging.info(f"[INFO] First-time migration | trace_id={trace_id}")

                self.first_migration_psql(
                    to_connection,
                    from_connection,
                    postgres_conn,
                    migration_details,
                    migration_table,
                    job_name,
                    trace_id,
                )
            else:
                logging.info(f"[INFO] Last-ID based migration | trace_id={trace_id}")

                self.last_id_migration_psql(
                    to_connection,
                    postgres_conn,
                    migration_details,
                    migration_table,
                    job_name,
                    trace_id,
                )

            # --------------------------------------------------
            # Update Success Status
            # --------------------------------------------------
            self.update_table(
                postgres_conn,
                history_table,
                {
                    "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                },
                {"trace_id": trace_id},
            )

            logging.info(f"[SUCCESS] Migration completed | trace_id={trace_id}")
            return True

        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"[CRITICAL] Migration failed | job={job_name} | error={e}")

            if postgres_conn and trace_id:
                self.update_table(
                    postgres_conn,
                    history_table,
                    {
                        "error_msg": f"{e}\n{tb}",
                        "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    },
                    {"trace_id": trace_id},
                )
            raise
    def lambda_sync_jobs_(self, data, comm_group_flag=False):
        start_time = time.time()
        logging.info(f"===== Lambda Sync Job Started =====")
        logging.info(f"Input Data: {data}")

        try:
            key_name_received = data.get("key_name")
            tenant_name = data.get("tenant_name")
            tenant_id = data.get("tenant_id")

            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            common_utils_db = os.getenv("COMMON_UTILS_DB_NAME")
            mode = os.getenv("MODE")

            logging.info("Initializing DB Connections...")
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
            comm_postgres_con = self.create_connection(db_type, hostname, common_utils_db, user, password, port)

            logging.info(f"Tenant Info => Name: {tenant_name}, ID: {tenant_id}")
            # Normalize tenant DB name
            try:
                query = f"SELECT db_name FROM tenant WHERE tenant_name='{tenant_name}'"
                df = self.execute_query(comm_postgres_con, query)
                tenant_name_lcase = df['db_name'].iloc[0].lower()
            except Exception:
                tenant_name_lcase = tenant_name.lower()

            key_name = f"{key_name_received}_{tenant_name_lcase}" if key_name_received else None
            logging.info(f"Final Key Name: {key_name}")

            if not key_name:
                logging.info(" Key name not found")
                return {"flag": False, "message": "Key name missing"}

            logging.info("Fetching Jobs List...")
            migration_table = "lambda_sync_jobs"
            query = f"SELECT migration_names_list FROM {migration_table} WHERE key_name='{key_name}'"
            rows = self.execute_query(postgres_conn, query)

            if rows.empty:
                logging.info(f" No jobs found for key: {key_name}")
                return {"flag": False, "message": f"No records found for key {key_name}"}

            job_names_list = rows["migration_names_list"][0]
            logging.info(f"Jobs to process: {job_names_list}")

            jobs_status_dict = {"Success": [], "Failed": []}

            # Execute jobs one by one
            for job in job_names_list:
                try:
                    job_start = time.time()
                    logging.info(f" Starting job: {job}")

                    status = self.start_migration_sync(job, key_name)
                    duration = time.time() - job_start

                    if status:
                        jobs_status_dict["Success"].append(job)
                        logging.info(f" Job {job} SUCCESS ({duration:.2f}s)")
                    else:
                        jobs_status_dict["Failed"].append(job)
                        logging.info(f" Job {job} FAILED ({duration:.2f}s)")

                except Exception as ex:
                    logging.info(f" Error executing job '{job}': {ex}", exc_info=True)
                    jobs_status_dict["Failed"].append(job)

            total_time = time.time() - start_time
            logging.info(f"===== All Jobs Completed for {key_name} in {total_time:.2f}s =====")
            logging.info(f"Final Status: {jobs_status_dict}")

            return {"flag": True, "key": key_name, "jobs_status": jobs_status_dict}

        except Exception as e:
            logging.error(f" Unexpected Error: {e}", exc_info=True)
            return {"flag": False, "message": str(e)}
    def lambda_sync_jobs_(self, data, comm_group_flag=False):
        start_time = time.time()
        logging.info(f"===== Lambda Sync Job Started =====")
        logging.info(f"Input Data: {data}")

        try:
            key_name_received = data.get("key_name")
            tenant_name = data.get("tenant_name")
            tenant_id = data.get("tenant_id")

            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            common_utils_db = os.getenv("COMMON_UTILS_DB_NAME")
            mode = os.getenv("MODE")

            logging.info("Initializing DB Connections...")
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
            comm_postgres_con = self.create_connection(db_type, hostname, common_utils_db, user, password, port)

            logging.info(f"Tenant Info => Name: {tenant_name}, ID: {tenant_id}")
            # Normalize tenant DB name
            try:
                query = f"SELECT db_name FROM tenant WHERE tenant_name='{tenant_name}'"
                df = self.execute_query(comm_postgres_con, query)
                tenant_name_lcase = df['db_name'].iloc[0].lower()
            except Exception:
                tenant_name_lcase = tenant_name.lower()

            key_name = f"{key_name_received}_{tenant_name_lcase}" if key_name_received else None
            logging.info(f"Final Key Name: {key_name}")

            if not key_name:
                logging.info(" Key name not found")
                return {"flag": False, "message": "Key name missing"}

            logging.info("Fetching Jobs List...")
            migration_table = "lambda_sync_jobs"
            query = f"SELECT migration_names_list FROM {migration_table} WHERE key_name='{key_name}'"
            rows = self.execute_query(postgres_conn, query)

            if rows.empty:
                logging.info(f" No jobs found for key: {key_name}")
                return {"flag": False, "message": f"No records found for key {key_name}"}

            job_names_list = rows["migration_names_list"][0]
            logging.info(f"Jobs to process: {job_names_list}")

            jobs_status_dict = {"Success": [], "Failed": []}

            # Execute jobs one by one
            for job in job_names_list:
                try:
                    job_start = time.time()
                    logging.info(f" Starting job: {job}")

                    status = self.start_migration_sync(job, key_name)
                    duration = time.time() - job_start

                    if status:
                        jobs_status_dict["Success"].append(job)
                        logging.info(f" Job {job} SUCCESS ({duration:.2f}s)")
                    else:
                        jobs_status_dict["Failed"].append(job)
                        logging.info(f" Job {job} FAILED ({duration:.2f}s)")

                except Exception as ex:
                    logging.error(f" Error executing job '{job}': {ex}", exc_info=True)
                    jobs_status_dict["Failed"].append(job)

            total_time = time.time() - start_time
            logging.info(f"===== All Jobs Completed for {key_name} in {total_time:.2f}s =====")
            logging.info(f"Final Status: {jobs_status_dict}")

            return {"flag": True, "key": key_name, "jobs_status": jobs_status_dict}

        except Exception as e:
            logging.error(f" Unexpected Error: {e}", exc_info=True)
            return {"flag": False, "message": str(e)}