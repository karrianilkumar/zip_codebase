"""
@Author1 : Srikanth R
Created Date: 27-12-2024
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os

# from bp_email_trigger import send_email_without_template
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta, date
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
from common_utils.timezone_conversion import fetch_tenant_timezone
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict

# download template dependencies
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
from io import StringIO
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
import pandas as pd
import psycopg2
import random
import string
from datetime import datetime
from dateutil import parser

# Dictionary to store database configuration settings retrieved from environment variables.
common_utils_database_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="bp_reports")


def clean_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        print(f"Exception while converting")
        return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name,readme_flag):
    """
    Creates a database configuration dictionary with user-specific filters based on tenant and role.

    Args:
        user (str): Username to look up permissions for
        db_config_making (dict): Base database configuration to extend
        tenant_database (str): Name of the tenant database
        tenant_name (str): Name of the tenant
        role_name (str): User's role (e.g., 'Super Admin')
        readme_flag (bool): Flag to determine query format (client_id vs user_name)

    Returns:
        dict: Modified database configuration with user-specific filters
    """
    logging.info(f"db_config_maker is in progress {role_name}")
    # Connect to common_utils database to get tenant info
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"],**common_utils_database_config)
    # Get tenant ID and parent tenant ID
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    # Bypass filtering for Super Admin users
    if role_name in ('Super Admin','Partner Admin') and not parent_tenant_id:
        logging.info(f"Getting access filters for  in tenant: {tenant_name} with role: {role_name} in if condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name in ('Super Admin','Partner Admin') and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in else condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name =="Agent Partner Admin" and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in elif second condition")
        pass
    else:
        logging.info(f"Getting access filin tenant: {tenant_name} with role: {role_name} in else condition")
        pass
    if tenant_id:
        tenant_id=int(tenant_id)
    #Get user permissions from mapping table
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)
        if filters.empty:
            query = f"""
                SELECT customers, service_provider, customer_group
                FROM user_module_tenant_mapping
                WHERE user_name = '{user}' AND tenant_id = {tenant_id}
            """
            filters = common_utils_database.execute_query(query, True)
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

        filters = common_utils_database.execute_query(query, True)
    # Connect to tenant database
    database = DB(tenant_database, **db_config)
    # Extract customer group if exists
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    # If user has a customer group, get additional filters from it
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            # Extract rate plan names
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
            # Extract customer names
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
                customer_names=None
            # Extract billing account number
            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception("Error extracting billing_account_number:", e)
                billing_account_number=None
            # Extract feature codes
            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception("Error extracting feature_codes:", e)
    # Set customer filter - use customer group names if available, otherwise use direct mapping
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    #customer=clean_tuple(customer)
    # Get service provider info and convert names to IDs
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    # Get additional customers created by this user
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer_list = [customer]
                elif isinstance(customer, tuple):
                    customer_list = list(customer)
                else:
                    customer_list = customer  # Already a list

                fixed_customer_list = customer_list.copy()

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info('customer_list before extend:', customer_list)

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info('customer_list after extend:', fixed_customer_list)

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info('final customer tuple:', customer)
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Get additional rate plans created by this user
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas
                logging.info('customer_ rate plan list before extend:', fixed_customer_rate_plan_list)

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info('customer rate plan_list after extend:', fixed_customer_rate_plan_list)

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info('final customer rate plan tuple:', customer_rate_plan_name)

    except Exception as e:
        logging.exception(f"Error while fetching the customers  for the user {user} in tenant {tenant_name}: {e}")
    # Update configuration with all filters
    logging.info(f"{user} user is service_provider is {service_provider} and service_provider_id is {service_provider_id} and ")
    if role_name =="Agent Partner Admin" and parent_tenant_id:
        db_config_making["customers"] = None
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = None
        db_config_making["feature_codes"] = None
        db_config_making["billing_account_number"] = None
        return db_config_making
    else:
        db_config_making["customers"] = customer
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
        db_config_making["feature_codes"] = feature_codes
        db_config_making["billing_account_number"] = billing_account_number
        return db_config_making

def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    try:
        current_time = datetime.now()
        logging.info(f"###{path},time started : {current_time}, data received is : {data}")
    except Exception as e:
        logging.error(f"Error in function_caller: {e}")
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    logging.info(f"### db_config created is : {db_config}")
    access_token = data.get("z_access_token",None)
    tenant_database = data.get("db_name")
    if not access_token:
        role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        readme_flag=False
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
        logging.info(f"db_config is created {path}")
    else:
        ##API Call
        logging.info(f"db_config will be created for service accountss")
        logging.info(f"path gotten is {path}")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        user = data.get("client_id", "")
        service_data = common_utils_database.get_data(
            "service_accounts", {"client_id": user,"is_active":"True"}
        )

        if service_data.empty:
            logging.info(f"Invalid client ID: {user}")
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}
        )
        tenant_database = tenant_data["db_name"].to_list()[0]
        data['tenant_name']=tenant_name
        data['db_name']=tenant_database
        readme_flag=True
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
    # Map API paths to corresponding handler functions
    path_function_map = {
    "/get_export_status": get_export_status,
    "/transcation_analysis_report_list_view": transcation_analysis_report_list_view,
    "/altaworx_billing_report_list_view": altaworx_billing_report_list_view,
    "/export_transcation_analysis_report": export_transcation_analysis_report,
    "/export_altaworx_billing_report": export_altaworx_billing_report,
    "/unposted_items_report_list_view": unposted_items_report_list_view,
    "/payment_details_report_list_view": payment_details_report_list_view,
    "/export_ar_aging_report": export_ar_aging_report,
    "/ar_aging_report_list_view": ar_aging_report_list_view,
    "/export_unposted_items_report": export_unposted_items_report,
    "/export_payment_details_report": export_payment_details_report,
    "/collections_steps_list_view": collections_steps_list_view,
    "/export_cycle_date_list_view": export_cycle_date_list_view,
    "/billed_through_date_report_list_view": billed_through_date_report_list_view,
    "/billed_through_date_report_export": billed_through_date_report_export,
    "/export_export_cycle_date": export_export_cycle_date,
    "/export_variance_billing_list_view": export_variance_billing_list_view,
    "/export_export_variance_billing": export_export_variance_billing,
    "/altaworx_billing_report_by_day_report_list_view": altaworx_billing_report_by_day_report_list_view,
    "/altaworx_billing_report_by_day_report_export": altaworx_billing_report_by_day_report_export,
    "/total_mrc_bill_profiles_list_view": total_mrc_bill_profiles_list_view,
    "/export_total_mrc_bill_profiles": export_total_mrc_bill_profiles,
    "/fcc_report_list_view": fcc_report_list_view,
    "/export_fcc_report": export_fcc_report,
    "/product_level_tax_mapping_report_list_view": product_level_tax_mapping_report_list_view,
    "/product_level_tax_mapping_report_export": product_level_tax_mapping_report_export
    }
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

def db_config_maker_2_1_2026(user,db_config_making):
    """
    Creates and returns an updated database configuration by adding customer 
    and service provider details for the given user.

    This function:
    - Connects to the COMMON_UTILS_DATABASE
    - Fetches the customers and service providers assigned to the user
    - Updates the db_config_making dictionary with these details

    Args:
        user (str): The username for which to fetch customer and service provider data.
        db_config_making (dict): Basic DB connection config (host, port, user, password)

    Returns:
        dict: Updated db_config with 'customers' and 'service_providers' keys added.
    """

    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config_making)

    query=f"select customers,service_provider from users where username ='{user}'"
    filters=common_utils_database.execute_query(query,True)
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting customer: {str(e)}")
      customer= None     

    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting service_provider: {str(e)}")
      service_provider=None   

    db_config_making["customers"]= customer
    db_config_making["service_providers"]=service_provider

    return db_config_making

def function_caller_2_1_2026(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    try:
        current_time = datetime.now()
        logging.info(f"###{path},time started : {current_time}, data received is : {data}")
    except Exception as e:
        logging.error(f"Error in function_caller: {e}")
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    db_config_making = db_config_maker(user, db_config)
    db_config = db_config_making
    logging.info(f"### db_config created is : {db_config}")

    # Map API paths to corresponding handler functions
    path_function_map = {
    "/get_export_status": get_export_status,
    "/transcation_analysis_report_list_view": transcation_analysis_report_list_view,
    "/altaworx_billing_report_list_view": altaworx_billing_report_list_view,
    "/export_transcation_analysis_report": export_transcation_analysis_report,
    "/export_altaworx_billing_report": export_altaworx_billing_report,
    "/unposted_items_report_list_view": unposted_items_report_list_view,
    "/payment_details_report_list_view": payment_details_report_list_view,
    "/export_ar_aging_report": export_ar_aging_report,
    "/ar_aging_report_list_view": ar_aging_report_list_view,
    "/export_unposted_items_report": export_unposted_items_report,
    "/export_payment_details_report": export_payment_details_report,
    "/collections_steps_list_view": collections_steps_list_view,
    "/export_cycle_date_list_view": export_cycle_date_list_view,
    "/billed_through_date_report_list_view": billed_through_date_report_list_view,
    "/billed_through_date_report_export": billed_through_date_report_export,
    "/export_export_cycle_date": export_export_cycle_date,
    "/export_variance_billing_list_view": export_variance_billing_list_view,
    "/export_export_variance_billing": export_export_variance_billing,
    "/altaworx_billing_report_by_day_report_list_view": altaworx_billing_report_by_day_report_list_view,
    "/altaworx_billing_report_by_day_report_export": altaworx_billing_report_by_day_report_export,
    "/total_mrc_bill_profiles_list_view": total_mrc_bill_profiles_list_view,
    "/export_total_mrc_bill_profiles": export_total_mrc_bill_profiles,
    "/fcc_report_list_view": fcc_report_list_view,
    "/export_fcc_report": export_fcc_report,
    }

    # Route to the correct function based on the path
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_platform_database = DB(
        os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config
    )

    # Extract relevant details from the input data dictionary
    main_module_name = data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")

    try:
        tenant_id_query = database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )
        tenant_id = tenant_id_query["id"].to_list()[0]
    except Exception as e:
        logging.warning(f"Getting exception at fetching tenant id {e}")

    ret_out = {}

    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x["id"])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name,
                    tenant_id,
                    main_module_name,
                    database,
                    parent_module_name,
                    role,
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier", "Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out

def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query = f"""select module_features from role_module where role='{role}'
            """
            user_features_raw = common_utils_database.execute_query(query, True)[
                "module_features"
            ].to_list()  # Convert the result to a list

        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(user_features_raw[0])

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(features[feature_name])

        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print("Retrieved features: %s", features_list)

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data, unique_id, table_name, db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v for k, v in changed_data.items() if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = [
        "created_date",
        "modified_date",
        "last_email_triggered_at",
        "billed_through_date",
        "activation_date",
        "closed_date",
        "bill_due_date",
        "payment_date",
        "received_date",
        "date",
        "statement_date",
        "bill_cycle_start_date",
    ]  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors="coerce")
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize("UTC")
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime(
                    "%m-%d-%Y"
                )  # Ensure it's a string
    return df_dict

def serialize_data(data):
    """Recursively convert pandas and datetime objects to JSON serializable types."""

    # Ensure the type check is valid
    if isinstance(data, list):
        return [serialize_data(item) for item in data]

    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}

    # Handle both pandas and native Python timestamps
    elif isinstance(data, (pd.Timestamp, datetime)):
        return data.strftime("%m-%d-%Y %H:%M:%S")

    elif isinstance(data, date):
        return data.strftime("%m-%d-%Y %H:%M:%S")

    # Return other types as they are
    else:
        return data

def get_export_status(data):
    """
    The get_export_status function retrieves the export status of a specific module from a database.
    It queries the export_status table based on the given module name and returns the corresponding status data.
    """
    try:
        # DB Connections
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # UI Parameter's
        module_name = data.get("module_name")
        if module_name=='Billing Report w/_City_County_Country':
            module_name='Billing Report w_City_County_Country'

        username=data.get("username",None)
        tenant_id=data.get("tenant_id",None)
        # Export data fetch query
        export_status_data = common_utils_database.get_data('export_status',{"module_name":module_name,"user_name":username,"tenant_id":tenant_id},None).to_dict(orient="records")
        logging.info(f"###export_status_data  {export_status_data}")
        message='Sucessfully Exported.'
        for record in export_status_data:
            if not record.get("url"):
                message='No Data Found for export'           
        # updating the report status
        return {"flag": True, "export_status_data": export_status_data[0],"message":message}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        error_data = {
            "service_name": "get_export_status",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": f"Failed! While checking export status {module_name}",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "export_status_data": []}

def export_to_s3_bucket_(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    logging.info(f"###export_to_s3_bucket_ Exporting to S3 bucket... {data}")
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("username", "")
    session_id = data.get("session_id", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}
    tenant_id = data.get("tenant_id", "")
    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

    
    file_name = f"exports/uat/{module_name_snake_case}/{module_name}_{tenant_id}_{user_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

    # Update export status to 'Waiting'
    updated_flag=db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
    )
    if not updated_flag:
        db.insert_data({"status_flag": "Waiting", "url": "","module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},"export_status")
    try:
        if not data_frames:
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            for sheet_name, df in data_frames.items():
                logging.info(f"Columns: {list(df.columns)}")
                if df.empty:
                    df = pd.DataFrame(columns=df.columns)

                # Format column names
                acronyms = {
                    "SMS",
                    "IMEI",
                    "IP",
                    "BAN",
                    "URL",
                    "UID",
                    "MAC",
                    "EID",
                    "MSISDN",
                    "MB",
                    "CCID",
                    "ICCID",
                    "SIM",
                    "ID",
                    "MRC",
                    "NRC",
                }
                special_replacements = {
                    "Att": "AT&T",
                    "And": "and",
                    "Gl": "G/L",
                    "Isparent": "IsParent",
                    "Ischild": "IsChild",
                    "Prevmrc": "PrevMRC",
                    "Currmrc": "CurrMRC",
                    "Netmrc": "NetMRC",
                    "Prevnrcusage": "PrevNRC-Usage",
                    "Currnrcusage": "CurrNRC-Usage",
                    "Netnrcusage": "NetNRC-Usage",
                    "Prevnrc": "PrevNRC",
                    "Currnrc": "CurrNRC",
                    "Netnrc": "NetNRC",
                }

                df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                    for col in df.columns
                ]
                df.columns = [
                    " ".join(
                        [
                            special_replacements.get(word, word)
                            for word in col.split(" ")
                        ]
                    )
                    for col in df.columns
                ]
                logging.info(f"df-----------{df}")
                logging.info(f"Columns: {list(df.columns)}")
                if module_name == "Billed Through Date Report":
                    df.rename(columns={"Tn": "TN"}, inplace=True)
                df.to_excel(writer, index=False, sheet_name=sheet_name)

                # Apply styles
                workbook = writer.book
                sheet = workbook[sheet_name]

                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )
                    cell.font = header_font

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )



        db.update_dict(
        "export_status",
        {"status_flag": "Success", "url": download_url},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name})
            
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name}
        )
        db.log_error_to_db(
            {
                "service_name": "export_to_s3_bucket_",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"Failed while exporting excel {module_name}",
                "module_name": module_name,
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}

def get_customer_names_by_user(
    role_name,
    username,
    common_utils_database,
    tenant_db
):
    """
    Returns customer names accessible to the given user based on role and mappings.

    Rules:
    - Super Admin & Partner Admin → returns None (unrestricted access)
    - User has 'customers' field → returns parsed customer list
    - User has 'customer_group' → returns customers from group mapping
    - No mapping found or errors → returns empty list []

    Args:
        role_name (str): User's role name for admin bypass check
        username (str): Username to lookup customer permissions
        common_utils_database: Database connection for users table
        tenant_db: Tenant-specific database for customergroups table

    Returns:
        Optional[List[str]]: List of allowed customer names, None for admins, or []

    Raises:
        None: All errors handled gracefully, returns []
    """
    logging.info("## get_customer_names_by_user function called")

    try:
        # Admin bypass → no restriction
        if not role_name or str(role_name).lower() in ["super admin", "partner admin"]:
            logging.info("## get_customer_names_by_user admin role → unrestricted")
            return None

        # **FIX: Add null check before calling get_data**
        user_data = common_utils_database.get_data(
            table_name="users",
            condition={
                "username": username,
                "is_active": True
            },
            columns=["customers", "customer_group"]
        )

        # **FIX: Check for None or non-DataFrame response**
        if user_data is None or not hasattr(user_data, 'empty') or user_data.empty:
            logging.info("## get_customer_names_by_user user mapping not found")
            return []

        def normalize_value(value):
            """Normalize string/JSON/comma-separated values to list or None."""
            if value is None:
                return None

            if isinstance(value, str):
                cleaned = value.strip()
                if cleaned.lower() in ["", "null", "none"]:
                    return None

                try:
                    parsed = json.loads(cleaned)
                    return parsed
                except json.JSONDecodeError:
                    if "," in cleaned:
                        return [v.strip() for v in cleaned.split(",") if v.strip()]
                    return cleaned

            return value

        customers = normalize_value(user_data.iloc[0].get("customers"))
        customer_group = normalize_value(user_data.iloc[0].get("customer_group"))

        logging.info(
            f"## get_customer_names_by_user customers={customers}, customer_group={customer_group}"
        )

        # Case 1: Direct customers (highest priority)
        if customers:
            if isinstance(customers, str):
                customers = [customers]
            return customers

        # Case 2: Customer group lookup
        if customer_group:
            logging.info(f"## get_customer_names_by_user customer_group exist as {customer_group}")
            group_data = tenant_db.get_data(
                table_name="customergroups",
                condition={"name": customer_group},
                columns=["customer_names"]
            )

            # **FIX: Consistent null/empty check**
            # if group_data is None or not hasattr(group_data, 'empty') or group_data.empty:
            if group_data is None or group_data.empty:
                logging.info("## get_customer_names_by_user group not found or empty")
                return []

            customer_names = normalize_value(group_data.iloc[0].get("customer_names"))

            if isinstance(customer_names, str):
                customer_names = [customer_names]

            return customer_names or []

        # No customers or groups mapped
        logging.info("## get_customer_names_by_user no customers and no group")
        return []

    except Exception as e:
        logging.exception(f"## get_customer_names_by_user error: {e}")
        return []

def format_amount(value):
    try:
        return "{:,.2f}".format(float(value))
    except (TypeError, ValueError):
        return value

def transcation_analysis_report_list_view_30_12_2025(data):
    """
    Retrieves transaction report data for display with filtering, sorting, pagination, and dropdown options.

    Args:
        data (dict): A dictionary containing request parameters:
            - db_name (str, optional): Tenant database name. Default: 'altaworx_central'.
            - role_name (str): Role name for header mapping and permission checks.
            - tenant_name (str): Tenant identifier used to determine timezone.
            - mod_pages (dict): Pagination control with keys 'start' and 'end'.
            - col_sort (dict, optional): Sorting preferences with column and direction.
            - start_date (str, optional): Start of date range filter (YYYY-MM-DD).
            - end_date (str, optional): End of date range filter (YYYY-MM-DD).
            - table_name (str, optional): Table name for dropdown population. Default: 'customer_charges'.

    Returns:
        dict: API response containing:
            - flag (bool): Indicates success or failure.
            - message (str): Descriptive message of the operation result.
            - data (dict): Serialized transaction report data.
            - header_map (dict): Header mapping for UI table rendering.
            - dropdown (dict): Dropdown values for filters including product, service types, GL codes, and locations.
            - pages (dict): Pagination metadata including start, end, and total record count.
    """
    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)

    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)
    logging.info(f"data after readme-----{data}")

    start_time = time.time()
    # Extract relevant details from the input data dictionary
    table_name = data.get("table_name", "customer_charges")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    if end_date:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")

    # user selected data

    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    limit = end - start
    offset = start

    # Get tenant's timezone
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(
        tenant_timezone_query, params=[tenant_name]
    )

    # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(
            " ", ""
        )  # Ensure it's formatted correctly

    # Get total customer charges count
    try:
        if start_date and end_date:
            base_query = """
                select amount
                from transaction_analysis_view
                where tenant_id = %s
                and is_active = false
                and is_deleted = false
                and to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s
                and to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s
            """
            params = [tenant_id, start_date, end_date]
        else:
            base_query = """
                select amount
                from transaction_analysis_view
                where tenant_id = %s
                and is_active = false
                and is_deleted = false
            """
            params = [tenant_id]
        total_count_result = killbill_database.execute_query(
            base_query, params=params
        )  # Get the DataFrame directly
        total_count_result = total_count_result.to_dict(orient="records")
        total_count = len(total_count_result)
        if total_count_result:
            total_amount = sum(
                float(d["amount"])
                for d in total_count_result
                if d["amount"] not in ("", None)
            )
        else:
            total_amount = 0.0

        # Pagination information
        pages_data = {"start": start, "end": end, "total": total_count}
        if start_date and end_date:
            base_query = """select account_number, customer_name, description, gl_code, product_id,quantity, bill_range, category, amount, mrc, nrc, calculated_cost, sms_cost, tax_name, modified_date from transaction_analysis_view where tenant_id = %s AND to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s AND to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s"""
            params = [tenant_id, start_date, end_date]
        else:
            base_query = "select account_number, customer_name, description, gl_code, product_id,quantity, bill_range, category, amount, mrc, nrc, calculated_cost, sms_cost, tax_name, modified_date from transaction_analysis_view where tenant_id = %s and is_active=false and is_deleted=false"
            params = [tenant_id]

        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY bill_id desc"  # Default sorting

        base_query += " LIMIT %s OFFSET %s"
        params.append(limit)
        params.append(offset)
        logging.info(f"transaction_analysis_report_list_view--query-{base_query}")
        df = killbill_database.execute_query(
            base_query, params=params
        )  # Get the DataFrame directly
        if "iccid" in df.columns:
            df["iccid"] = df["iccid"].apply(
                lambda x: (
                    str(int(x))
                    if pd.notnull(x) and str(x).replace(".", "", 1).isdigit()
                    else str(x)
                )
            )
        df_dict = df.to_dict(orient="records")

        final_df_dict = convert_timestamp(df_dict, tenant_time_zone)

        header_map = get_headers_mapping(
            killbill_database, ["Transaction Report"], role_name, "", "", "", "", data
        )

        columns_to_sum = ["amount", "mrc", "nrc", "calculated_cost", "sms_cost"]
        for row in final_df_dict:
            for col in columns_to_sum:
                if col in row:
                    value = row[col]
                    if isinstance(value, (int, float)):
                        row[col] = f"{value:.2f}"
                    else:
                        # if it's None or garbage, default to 0.00
                        row[col] = "0.00"

        data_dict_all = {"transaction_report": serialize_data(final_df_dict)}

        # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown": {},
            "pages": pages_data,
            "summary": {"amount": round(total_amount, 2)},
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "transcation_analysis_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched Transaction Report",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.info(f"Exception occurred: {e}")
        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reports list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "transcation_analysis_report_list_view",
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "Reports",
                "request_received_at": data.get("request_received_at", None),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass
        return response

def transcation_analysis_report_list_view(data):
    """
    Retrieves transaction report data for display with filtering, sorting, pagination, and dropdown options.

    Args:
        data (dict): A dictionary containing request parameters:
            - db_name (str, optional): Tenant database name. Default: 'altaworx_central'.
            - role_name (str): Role name for header mapping and permission checks.
            - tenant_name (str): Tenant identifier used to determine timezone.
            - mod_pages (dict): Pagination control with keys 'start' and 'end'.
            - col_sort (dict, optional): Sorting preferences with column and direction.
            - start_date (str, optional): Start of date range filter (YYYY-MM-DD).
            - end_date (str, optional): End of date range filter (YYYY-MM-DD).
            - table_name (str, optional): Table name for dropdown population. Default: 'customer_charges'.

    Returns:
        dict: API response containing:
            - flag (bool): Indicates success or failure.
            - message (str): Descriptive message of the operation result.
            - data (dict): Serialized transaction report data.
            - header_map (dict): Header mapping for UI table rendering.
            - dropdown (dict): Dropdown values for filters including product, service types, GL codes, and locations.
            - pages (dict): Pagination metadata including start, end, and total record count.
    """
    # UI Keys
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name = data.get("db_name", "")

    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    killbill_database = DB(billing_db_name, **db_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)
    logging.info(f"data after readme-----{data}")

    start_time = time.time()
    # Extract relevant details from the input data dictionary
    table_name = data.get("table_name", "customer_charges")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    if end_date:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")

    # user selected data

    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    limit = end - start
    offset = start


    # Get tenant's timezone
    tenant_timezone=common_utils_database.get_data("tenant",{"tenant_name":tenant_name},["time_zone"])

    # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(
            " ", ""
        )  # Ensure it's formatted correctly

    # Get total customer charges count
    try:
        if start_date and end_date:
            base_query = """
                select amount
                from transaction_analysis_view
                where tenant_id = %s
                and is_active = true
                and to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s
                and to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s
            """
            params = [tenant_id, start_date, end_date]
        else:
            base_query = """
                select amount
                from transaction_analysis_view
                where tenant_id = %s
                and is_active = true
            """
            params = [tenant_id]

        total_count_result = killbill_database.execute_query(
            base_query, params=params
        )  # Get the DataFrame directly
        total_count_result = total_count_result.to_dict(orient="records")
        total_count = len(total_count_result)
        if total_count_result:
            total_amount = sum(
                float(d["amount"])
                for d in total_count_result
                if d["amount"] not in ("", None)
            )
        else:
            total_amount = 0.0

        # Pagination information
        pages_data = {"start": start, "end": end, "total": total_count}
        if start_date and end_date:
            base_query = """select account_number, customer_name, description, gl_code, product_id,quantity, bill_range, category, amount, mrc, nrc, calculated_cost, sms_cost, tax_name, modified_date from transaction_analysis_view where tenant_id = %s AND to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s AND to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s and is_active=true"""
            params = [tenant_id, start_date, end_date]
        else:
            base_query = "select account_number, customer_name, description, gl_code, product_id,quantity, bill_range, category, amount, mrc, nrc, calculated_cost, sms_cost, tax_name, modified_date from transaction_analysis_view where tenant_id = %s and is_active=true"
            params = [tenant_id]
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY bill_id desc"  # Default sorting

        base_query += " LIMIT %s OFFSET %s"
        params.append(limit)
        params.append(offset)
        logging.info(f"transaction_analysis_report_list_view--query-{base_query}")
        df = killbill_database.execute_query(
            base_query, params=params
        )  # Get the DataFrame directly
        if "iccid" in df.columns:
            df["iccid"] = df["iccid"].apply(
                lambda x: (
                    str(int(x))
                    if pd.notnull(x) and str(x).replace(".", "", 1).isdigit()
                    else str(x)
                )
            )
        df_dict = df.to_dict(orient="records")

        final_df_dict = convert_timestamp(df_dict, tenant_time_zone)

        header_map = get_headers_mapping(
            killbill_database, ["Transaction Report"], role_name, "", "", "", "", data
        )

        columns_to_sum = ["amount", "mrc", "nrc", "calculated_cost", "sms_cost"]
        # for row in final_df_dict:
        #     for col in columns_to_sum:
        #         if col in row:
        #             value = row[col]
        #             if isinstance(value, (int, float)):
        #                 row[col] = f"{value:.2f}"
        #             else:
        #                 # if it's None or garbage, default to 0.00
        #                 row[col] = "0.00"
        for row in final_df_dict:
            for col in columns_to_sum:
                if col in row:
                    row[col] = format_amount(row.get(col, 0))
            # Special handling for taxes (example: "Tax$3.39")
            taxes_value = row.get("tax_name")
            if taxes_value:
                try:
                    # Extract numeric part from string
                    match = re.search(r"([\d.]+)", str(taxes_value))
                    if match:
                        formatted_tax = format_amount(match.group(1))
                        row["tax_name"] = f"Tax${formatted_tax}"
                except Exception:
                    pass
        data_dict_all = {"transaction_report": serialize_data(final_df_dict)}

        # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown": {},
            "pages": pages_data,
            "summary": {"amount": round(total_amount, 2)},
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "transcation_analysis_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched Transaction Report",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.info(f"Exception occurred: {e}")
        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reports list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "transcation_analysis_report_list_view",
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "Reports",
                "request_received_at": data.get("request_received_at", None),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass
        return response



def altaworx_billing_report_list_view_30_12_2025(data):
    """
    Retrieves Billing Report w/_City_County_Country data with pagination, date-range filtering,
    timezone conversion, sorting, and dynamic header mapping.
    """

    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)
    start_time = time.time()

    table_name = data.get("table_name", "billing_report_view")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    report_flag = data.get("report_flag", "")
    changed_data = data.get("changed_data", {})
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")

    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    # Pagination
    start = data.get("mod_pages", {}).get("start", 0)
    end = data.get("mod_pages", {}).get("end", 10)
    limit = end - start
    offset = start

    # Date range
    date_flag = bool(start_date and end_date)
    if date_flag:
        try:
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error parsing end_date: {e}")

    # Timezone lookup
    tenant_timezone_query = "SELECT time_zone FROM tenant WHERE tenant_name = %s"
    tenant_timezone = common_utils_database.execute_query(
        tenant_timezone_query, params=[tenant_name]
    )

    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        # --- Count query ---
        columns_to_sum = [
            "amount_due",
            "mrc",
            "nrc",
            "network_access_fee",
            "cost_recovery_fee",
            "taxes",
            "total",
            "payments",
            "account_balance",
        ]
        # count_query = f"SELECT COUNT(id) AS total FROM {table_name} WHERE tenant_id = %s"
        sum_expressions = ", ".join(
            [f"COALESCE(SUM({col}), 0) AS {col}" for col in columns_to_sum]
        )
        count_query = f"""
            SELECT 
                COUNT(id) AS total_records, 
                {sum_expressions}
            FROM {table_name}
            WHERE tenant_id = %s
        """
        params = [tenant_id]
        if date_flag:
            count_query += " AND bill_cycle_start_date BETWEEN %s AND %s"
            params += [start_date, end_date]

        total_count_df = killbill_database.execute_query(count_query, params=params)
        # total_count = int(total_count_df.iloc[0]['total']) if not total_count_df.empty else 0

        if not total_count_df.empty:
            row = total_count_df.iloc[0].to_dict()
            total_count = int(row.get("total_records") or 0)
            summary = {col: round(row.get(col, 0) or 0, 2) for col in columns_to_sum}
        else:
            total_count = 0
            summary = {col: 0.00 for col in columns_to_sum}

        pages_data = {"start": start, "end": end, "total": total_count}

        # --- Data query ---
        query = f"""
            SELECT account_number, account_type, customer_name, bill_id, sales_person,
                   secondary_sales_person, bill_cycle_start_date, amount_due, mrc, nrc,
                   network_access_fee, cost_recovery_fee, taxes, total, payments,
                   bill_due_date, account_balance, timezone, city, state, country
            FROM {table_name}
            WHERE tenant_id = %s
        """
        params = [tenant_id]
        if date_flag:
            query += " AND bill_cycle_start_date BETWEEN %s AND %s"
            params += [start_date, end_date]

        # Sorting
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            direction = order[order_by].upper()
            query += f" ORDER BY {order_by} {direction}"
        else:
            query += " ORDER BY bill_cycle_start_date DESC"

        # Pagination
        query += " LIMIT %s OFFSET %s"
        params += [limit, offset]

        df_dict = killbill_database.execute_query(query, params=params)
        df_dict = df_dict.to_dict(orient="records")

        # --- Transform and prepare data ---
        final_df_dict = []
        for item in df_dict:
            final_df_dict.append(
                {
                    "account_number": item.get("account_number"),
                    "account_type": item.get("account_type"),
                    "customer_name": item.get("customer_name"),
                    "bill_id": item.get("bill_id"),
                    "sales_person": item.get("sales_person"),
                    "secondary_sales_person": item.get("secondary_sales_person")
                    or "No",
                    "bill_cycle_start_date": item.get("bill_cycle_start_date"),
                    "amount_due": item.get("amount_due"),
                    "mrc": item.get("mrc"),
                    "nrc": item.get("nrc"),
                    "network_access_fee": item.get("network_access_fee"),
                    "cost_recovery_fee": item.get("cost_recovery_fee"),
                    "taxes": item.get("taxes"),
                    "total": item.get("total"),
                    "payments": item.get("payments"),
                    "bill_due_date": item.get("bill_due_date"),
                    "account_balance": item.get("account_balance"),
                    "state": item.get("state"),
                    "timezone": tenant_time_zone,
                    "city": item.get("city"),
                    "country": item.get("country"),
                }
            )

        final_df_dict = convert_timestamp(final_df_dict, tenant_time_zone)

        # --- Header mapping ---
        header_map = get_headers_mapping(
            killbill_database,
            ["Billing Report w/_City_County_Country"],
            role_name,
            "",
            "",
            "",
            "",
            data,
        )

        for row in final_df_dict:
            for col in columns_to_sum:
                if col in row:
                    value = row[col]
                    if isinstance(value, (int, float)):
                        row[col] = f"{value:.2f}"
                    else:
                        # if it's None or garbage, default to 0.00
                        row[col] = "0.00"

        data_dict_all = {"altaworx_billing_report": serialize_data(final_df_dict)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": summary,
        }

        # --- Audit logging ---
        end_time = time.time()
        audit_data_user_actions = {
            "service_name": "altaworx_billing_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": int(end_time - start_time),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched Billing Report w/_City_County_Country",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        return response

    except Exception as e:
        logging.error(f"Exception occurred in altaworx_billing_report_list_view: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reports list",
            "data": {},
        }

        error_data = {
            "service_name": "altaworx_billing_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def altaworx_billing_report_list_view(data):
    """
    Retrieves Billing Report w/_City_County_Country data with pagination, date-range filtering,
    timezone conversion, sorting, and dynamic header mapping.
    """
    #UI params
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name=data.get("db_name", "")

    # DB Connectinos
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)

    data = get_tenant_details_from_token(common_utils_database, data)
    start_time = time.time()

    table_name = data.get("table_name", "billing_report_view")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    report_flag = data.get("report_flag", "")
    changed_data = data.get("changed_data", {})
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")

    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    # Pagination
    start = data.get("mod_pages", {}).get("start", 0)
    end = data.get("mod_pages", {}).get("end", 10)
    limit = end - start
    offset = start


    # Date range
    date_flag = bool(start_date and end_date)
    if date_flag:
        try:
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error parsing end_date: {e}")

    # Timezone lookup
    tenant_timezone=common_utils_database.get_data("tenant",{"tenant_name":tenant_name},["time_zone"])

    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        # --- Count query ---
        columns_to_sum = [
            "amount_due",
            "mrc",
            "nrc",
            "network_access_fee",
            "cost_recovery_fee",
            "taxes",
            "total",
            "payments",
            "account_balance",
        ]
        # count_query = f"SELECT COUNT(id) AS total FROM {table_name} WHERE tenant_id = %s"
        sum_expressions = ", ".join(
            [f"COALESCE(SUM({col}), 0) AS {col}" for col in columns_to_sum]
        )
        count_query = f"""
            SELECT 
                COUNT(id) AS total_records, 
                {sum_expressions}
            FROM {table_name}
            WHERE tenant_id = %s AND (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date) <> date_trunc('month', bill_reversed_date)
            ) 
        """
        params = [tenant_id]
        if date_flag:
            count_query += " AND bill_cycle_start_date BETWEEN %s AND %s"
            params += [start_date, end_date]

        total_count_df = killbill_database.execute_query(count_query, params=params)
        # total_count = int(total_count_df.iloc[0]['total']) if not total_count_df.empty else 0

        if not total_count_df.empty:
            row = total_count_df.iloc[0].to_dict()
            total_count = int(row.get("total_records") or 0)
            summary = {col: round(row.get(col, 0) or 0, 2) for col in columns_to_sum}
        else:
            total_count = 0
            summary = {col: 0.00 for col in columns_to_sum}

        pages_data = {"start": start, "end": end, "total": total_count}

        # --- Data query ---
        query = f"""
            SELECT account_number, account_type, customer_name, bill_id, sales_person,
                   secondary_sales_person, bill_cycle_start_date, amount_due, mrc, nrc,
                   network_access_fee, cost_recovery_fee, taxes, total, payments,
                   bill_due_date, account_balance, timezone, city, state, country
            FROM {table_name}
            WHERE tenant_id = %s AND (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date) <> date_trunc('month', bill_reversed_date)
            ) 
        """
        params = [tenant_id]
        if date_flag:
            query += " AND bill_cycle_start_date BETWEEN %s AND %s"
            params += [start_date, end_date]

        # Sorting
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            direction = order[order_by].upper()
            query += f" ORDER BY {order_by} {direction}"
        else:
            query += " ORDER BY bill_cycle_start_date DESC"

        # Pagination
        query += " LIMIT %s OFFSET %s"
        params += [limit, offset]

        df_dict = killbill_database.execute_query(query, params=params)
        df_dict = df_dict.to_dict(orient="records")

        # --- Transform and prepare data ---
        final_df_dict = []
        for item in df_dict:
            final_df_dict.append(
                {
                    "account_number": item.get("account_number"),
                    "account_type": item.get("account_type"),
                    "customer_name": item.get("customer_name"),
                    "bill_id": item.get("bill_id"),
                    "sales_person": item.get("sales_person"),
                    "secondary_sales_person": item.get("secondary_sales_person")
                    or "No",
                    "bill_cycle_start_date": item.get("bill_cycle_start_date"),
                    "amount_due": item.get("amount_due"),
                    "mrc": item.get("mrc"),
                    "nrc": item.get("nrc"),
                    "network_access_fee": item.get("network_access_fee"),
                    "cost_recovery_fee": item.get("cost_recovery_fee"),
                    "taxes": item.get("taxes"),
                    "total": item.get("total"),
                    "payments": item.get("payments"),
                    "bill_due_date": item.get("bill_due_date"),
                    "account_balance": item.get("account_balance"),
                    "state": item.get("state"),
                    "timezone": tenant_time_zone,
                    "city": item.get("city"),
                    "country": item.get("country"),
                }
            )

        final_df_dict = convert_timestamp(final_df_dict, tenant_time_zone)

        # --- Header mapping ---
        header_map = get_headers_mapping(
            killbill_database,
            ["Billing Report w/_City_County_Country"],
            role_name,
            "",
            "",
            "",
            "",
            data,
        )

        # for row in final_df_dict:
        #     for col in columns_to_sum:
        #         if col in row:
        #             value = row[col]
        #             if isinstance(value, (int, float)):
        #                 row[col] = f"{value:.2f}"
        #             else:
        #                 # if it's None or garbage, default to 0.00
        #                 row[col] = "0.00"
        for row in final_df_dict:
            for col in columns_to_sum:
                if col in row:
                    row[col] = format_amount(row.get(col, 0))


        data_dict_all = {"altaworx_billing_report": serialize_data(final_df_dict)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": summary,
        }

        # --- Audit logging ---
        end_time = time.time()
        audit_data_user_actions = {
            "service_name": "altaworx_billing_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": int(end_time - start_time),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched Billing Report w/_City_County_Country",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        return response

    except Exception as e:
        logging.error(f"Exception occurred in altaworx_billing_report_list_view: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reports list",
            "data": {},
        }

        error_data = {
            "service_name": "altaworx_billing_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response



def unposted_items_report_list_view(data):
    """
    Retrieves a list of Reports for display, including pagination, filtering, and dropdown options.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Tenant database name (default: 'altaworx_central').
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name for fetching timezone.
            - mod_pages (dict): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Customer profiles with pagination.
            - header_map (dict): Mapped headers for UI display.
            - dropdown (dict): Dropdown values for filters.
            - pages (dict): Pagination details.
    """
    # Database connections
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    # Extract relevant details from the input data dictionary
    # table_name = data.get('unposted_items_view','unposted_items_view')
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1

    # Set default pagination if not provided
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)

    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None

    # Get tenant's timezone
    tenant_timezone=common_utils_database.get_data("tenant",{"tenant_name":tenant_name},["time_zone"])

    # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(
            " ", ""
        )  # Ensure it's formatted correctly

    # Get total customer charges count
    try:
        base_query = "select customer_id from unposted_items_view where is_active = %s and tenant_id = %s"
        total_count_result = killbill_database.execute_query(
            base_query, params=[True, tenant_id]
        )  # Get the DataFrame directly
        total_count_result = total_count_result.to_dict(orient="records")
        total_count = len(total_count_result)

        # Pagination information
        pages_data = {"start": start, "end": end, "total": total_count}

        # Sort order handling (ensure valid keys)
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
        else:
            order = {"id": "desc"}

        base_query = f"select customer_id, description, amount, mrc, start_date, end_date, created_date, tn, line_id, product_id, product_type_id,calculated_cost, sms_cost, tax_name  from unposted_items_view where  tenant_id = {tenant_id}"

        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY created_date desc"  # Default sorting

        base_query += " LIMIT %s OFFSET %s"

        df = killbill_database.execute_query(
            base_query, params=[limit, offset]
        )  # Get the DataFrame directly
        df["start_date"] = pd.to_datetime(df["start_date"]).dt.strftime("%m-%d-%Y")
        df["end_date"] = pd.to_datetime(df["end_date"]).dt.strftime("%m-%d-%Y")
        df_dict = df.to_dict(orient="records")

        # Convert timestamps to the tenant's timezone
        final_df_dict = convert_timestamp(df_dict, tenant_time_zone)
        df = pd.DataFrame(final_df_dict)
        df["created_date"] = pd.to_datetime(df["created_date"]).dt.strftime("%m-%d-%Y")
        final_df_dict = df.to_dict(orient="records")
        # Fetch mapped headers
        header_map = get_headers_mapping(
            killbill_database, ["Unposted Items"], role_name, "", "", "", "", data
        )

        # Serialize customer profiles
        data_dict_all = {"unposted_items": serialize_data(final_df_dict)}

        # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "unposted_items_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched Unposted Items Report",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")

        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reports list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "unposted_items_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def payment_details_report_list_view(data):
    """
    Retrieves a paginated and filtered list of payment history records along with dropdown options
    and header mapping for frontend display.

    Args:
        data (dict): Input parameters including:
            - db_name (str, optional): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): Role used to fetch permitted headers.
            - tenant_name (str): Used to determine tenant's timezone.
            - mod_pages (dict): Pagination details with 'start' and 'end' indices.
            - col_sort (dict, optional): Sorting configuration as {column: direction}.
            - report_flag (str, optional): If set to 'download', disables pagination.
            - changed_data (dict, optional): Filtering criteria such as:
    Returns:
        dict: API response with:
            - flag (bool): True on success, False on failure.
            - message (str): Status message.
            - data (dict): Contains 'reports_data', a serialized list of payments.
            - header_map (dict): UI table header mapping.
            - dropdown (dict): Dropdown filter values (e.g., 'method', 'created_by').
            - pages (dict): Pagination metadata with 'start', 'end', and 'total'.
    """
    # UI Params
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name = data.get("db_name", "")

    # DB Connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # z_access token validation check
    data = get_tenant_details_from_token(common_utils_database, data)

    start_time = time.time()
    # Extract relevant details from the input data dictionary
    table_name = data.get("table_name", "vw_payment_history")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    report_flag = data.get("report_flag", "")
    changed_data = data.get("changed_data", {})
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    date_flag = True
    if not start_date or not end_date:
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")
    # Set default pagination if not provided
    start = data.get("mod_pages", {}).get("start", 0)
    end = data.get("mod_pages", {}).get("end", 100)
    limit = end - start
    offset = start


    tenant_time_zone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )["time_zone"].to_list()[0]

    if tenant_time_zone is None:
        raise ValueError("No valid timezone found for tenant.")
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(
            " ", ""
        )  # Ensure it's formatted correctly

    try:
        base_query = f"""
            SELECT customer_id, customer_name, agent, amount, method, category,
                date, created_date, ref, created_by, name_on_card
            FROM {table_name}
            WHERE tenant_id = %s
        """
        params = [tenant_id]

        changed_data = {
            k: (None if v in ["null", None] else v) for k, v in changed_data.items()
        }
        logging.info(f"## payment_details_report_list_view changed_data {changed_data}")

        # Handle date_range separately (check if both start and end dates are null)
        if "date_range" in changed_data:
            start_date, end_date = changed_data["date_range"]
            if start_date in ["null", None] and end_date in ["null", None]:
                changed_data.pop("date_range")  # Remove if both are null

        changed_data = {
            k: v for k, v in changed_data.items() if v not in [None, "", [], {}, False]
        }
        if "evaluate_using" in changed_data:
            if (
                changed_data.get("evaluate_using") == "Created Date"
                and "date_range" in changed_data
            ):
                base_query += " AND created_date BETWEEN %s AND %s"
                params.extend(changed_data["date_range"])
            elif (
                changed_data.get("evaluate_using") == "Received Date"
                and "date_range" in changed_data
            ):
                base_query += " AND date BETWEEN %s AND %s"
                params.extend(changed_data["date_range"])
            else:
                pass
        if start_date and end_date and date_flag:
            base_query += " AND date BETWEEN %s AND %s"
            params.extend([start_date, end_date])

        if "method" in changed_data:
            base_query += " AND method = %s"
            params.append(changed_data["method"])

        if "name_on_card" in changed_data:
            base_query += " AND name_on_card = %s"
            params.append(changed_data["name_on_card"])

        if "created_by" in changed_data:
            base_query += " AND created_by = %s"
            params.append(changed_data["created_by"])

        if "category" in changed_data:
            base_query += " AND category = %s"
            params.append(changed_data["category"])

        if "last_4" in changed_data:
            base_query += " AND RIGHT(method, 4) = %s"
            params.append(changed_data["last_4"])

        if "min_amount" in changed_data:
            base_query += " AND amount >= %s"
            params.append(int(changed_data["min_amount"]))  # Convert to integer

        if "created_by" in changed_data:
            base_query += " AND created_by = %s"
            params.append(changed_data["created_by"])

        if "agent" in changed_data:
            base_query += " AND agent = %s"
            params.append(changed_data["agent"])

        # Handle sorting if order is provided
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY date desc"  # Default sorting

        total_count_result = killbill_database.execute_query(
            base_query, params=params, flag=True
        )
        count_dict = total_count_result.to_dict(orient="records")
        total_count = len(count_dict)
        if count_dict:
            amount_list = total_count_result["amount"].to_list()
            total_amount = sum(float(i) for i in amount_list if i not in ("", None))
        else:
            total_amount = 0.0
        # Pagination information
        pages_data = {"start": start, "end": end, "total": total_count}
        # Add LIMIT and OFFSET
        if report_flag != "download":
            base_query += " LIMIT %s OFFSET %s"

        params.append(limit)
        params.append(offset)
        df = killbill_database.execute_query(
            base_query, params=params
        )  # Get the DataFrame directly
        df_dict = df.to_dict(orient="records")  # Convert to dictionary for processing

        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        # to view in ui

        try:
            method_df = killbill_database.get_data("payment_history", {}, ["method"])
            method = (
                list(set(method_df["method"].tolist())) if not method_df.empty else []
            )
        except Exception as db_error:
            logging.info(f"Database Error: {db_error}")  # Logging the error
            method = []

        created_by = []  # Initialize before try block
        try:
            created_by_df = killbill_database.get_data(
                "customer_bills", {}, ["created_by"]
            )
            created_by = list(
                set(created_by_df["created_by"].tolist())
            )  # Remove duplicates
        except Exception as db_error:
            logging.info(f"Database error: {db_error}")  # Optional logging

        dropdown = {"method": method, "created_by": created_by}
        header_map = get_headers_mapping(
            killbill_database,
            ["Payment History Report"],
            role_name,
            "",
            "",
            "",
            "",
            data,
        )
        columns_to_sum = ["amount"]
        # for row in df_dict:
        #     for col in columns_to_sum:
        #         if col in row:
        #             value = row[col]
        #             if isinstance(value, (int, float)):
        #                 row[col] = f"{value:.2f}"
        #             else:
        #                 # if it's None or garbage, default to 0.00
        #                 row[col] = "0.00"
        for row in df_dict:
            for col in columns_to_sum:
                if col in row:
                    row[col] = format_amount(row.get(col, 0))

        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "dropdown": dropdown,
            "summary": {"amount": round(total_amount, 2)},
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "payment_details_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched Payment History Report",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reoprts list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "payment_details_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response



def payment_details_report_list_view_30_12_2025(data):
    """
    Retrieves a paginated and filtered list of payment history records along with dropdown options
    and header mapping for frontend display.

    Args:
        data (dict): Input parameters including:
            - db_name (str, optional): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): Role used to fetch permitted headers.
            - tenant_name (str): Used to determine tenant's timezone.
            - mod_pages (dict): Pagination details with 'start' and 'end' indices.
            - col_sort (dict, optional): Sorting configuration as {column: direction}.
            - report_flag (str, optional): If set to 'download', disables pagination.
            - changed_data (dict, optional): Filtering criteria such as:
    Returns:
        dict: API response with:
            - flag (bool): True on success, False on failure.
            - message (str): Status message.
            - data (dict): Contains 'reports_data', a serialized list of payments.
            - header_map (dict): UI table header mapping.
            - dropdown (dict): Dropdown filter values (e.g., 'method', 'created_by').
            - pages (dict): Pagination metadata with 'start', 'end', and 'total'.
    """
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # z_access token validation check
    data = get_tenant_details_from_token(common_utils_database, data)

    start_time = time.time()
    # Extract relevant details from the input data dictionary
    table_name = data.get("table_name", "vw_payment_history")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    report_flag = data.get("report_flag", "")
    changed_data = data.get("changed_data", {})
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    date_flag = True
    if not start_date or not end_date:
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")
    # Set default pagination if not provided
    start = data.get("mod_pages", {}).get("start", 0)
    end = data.get("mod_pages", {}).get("end", 100)
    limit = end - start
    offset = start
    tenant_time_zone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )["time_zone"].to_list()[0]

    if tenant_time_zone is None:
        raise ValueError("No valid timezone found for tenant.")
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(
            " ", ""
        )  # Ensure it's formatted correctly

    try:
        base_query = f"""
            SELECT customer_id, customer_name, agent, amount, method,category, date, created_date, ref,created_by,name_on_card
            FROM {table_name}
            WHERE 1=1 AND tenant_id = {tenant_id}
        """
        changed_data = {
            k: (None if v in ["null", None] else v) for k, v in changed_data.items()
        }
        logging.info(f"## payment_details_report_list_view changed_data {changed_data}")

        # Handle date_range separately (check if both start and end dates are null)
        if "date_range" in changed_data:
            start_date, end_date = changed_data["date_range"]
            if start_date in ["null", None] and end_date in ["null", None]:
                changed_data.pop("date_range")  # Remove if both are null

        changed_data = {
            k: v for k, v in changed_data.items() if v not in [None, "", [], {}, False]
        }
        params = []
        if "evaluate_using" in changed_data:
            if (
                changed_data.get("evaluate_using") == "Created Date"
                and "date_range" in changed_data
            ):
                base_query += " AND created_date BETWEEN %s AND %s"
                params.extend(changed_data["date_range"])
            elif (
                changed_data.get("evaluate_using") == "Received Date"
                and "date_range" in changed_data
            ):
                base_query += " AND date BETWEEN %s AND %s"
                params.extend(changed_data["date_range"])
            else:
                pass
        if start_date and end_date and date_flag:
            base_query += " AND date BETWEEN %s AND %s"
            params.extend([start_date, end_date])

        if "method" in changed_data:
            base_query += " AND method = %s"
            params.append(changed_data["method"])

        if "name_on_card" in changed_data:
            base_query += " AND name_on_card = %s"
            params.append(changed_data["name_on_card"])

        if "created_by" in changed_data:
            base_query += " AND created_by = %s"
            params.append(changed_data["created_by"])

        if "category" in changed_data:
            base_query += " AND category = %s"
            params.append(changed_data["category"])
        # if "category" in changed_data:
        #     category_val = changed_data["category"]
        #     if isinstance(category_val, str):
        #         category_val_lower = category_val.lower().strip()
        #         if category_val_lower == "credit":
        #             category_val = "Credit"
        #         elif category_val_lower == "ach":
        #             category_val = "ACH"
        #     base_query += " AND category = %s"
        #     params.append(category_val)
        if "last_4" in changed_data:
            base_query += " AND RIGHT(method, 4) = %s"
            params.append(changed_data["last_4"])

        if "min_amount" in changed_data:
            base_query += " AND amount >= %s"
            params.append(int(changed_data["min_amount"]))  # Convert to integer

        if "created_by" in changed_data:
            base_query += " AND created_by = %s"
            params.append(changed_data["created_by"])

        if "agent" in changed_data:
            base_query += " AND agent = %s"
            params.append(changed_data["agent"])

        # Handle sorting if order is provided
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]  # Extract column name
            order_direction = order[order_by].lower()  # Convert to lowercase
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY date desc"  # Default sorting

        total_count_result = killbill_database.execute_query(
            base_query, params=params, flag=True
        )
        count_dict = total_count_result.to_dict(orient="records")
        total_count = len(count_dict)
        if count_dict:
            amount_list = total_count_result["amount"].to_list()
            total_amount = sum(float(i) for i in amount_list if i not in ("", None))
        else:
            total_amount = 0.0
        # Pagination information
        pages_data = {"start": start, "end": end, "total": total_count}
        # Add LIMIT and OFFSET
        if report_flag != "download":
            base_query += " LIMIT %s OFFSET %s"

        params.append(limit)
        params.append(offset)
        df = killbill_database.execute_query(
            base_query, params=params
        )  # Get the DataFrame directly
        df_dict = df.to_dict(orient="records")  # Convert to dictionary for processing
        # Normalize category values in the result
        # for record in df_dict:
        #     category_val = record.get("category", "")
        #     if isinstance(category_val, str):
        #         category_val_lower = category_val.lower().strip()
        #         if category_val_lower == "credit":
        #             record["category"] = "Credit"
        #         elif category_val_lower == "ach":
        #             record["category"] = "ACH"
        #         else:
        #             record["category"] = category_val

        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        # to view in ui

        try:
            method_df = killbill_database.get_data("payment_history", {}, ["method"])
            method = (
                list(set(method_df["method"].tolist())) if not method_df.empty else []
            )
        except Exception as db_error:
            logging.info(f"Database Error: {db_error}")  # Logging the error
            method = []

        created_by = []  # Initialize before try block
        try:
            created_by_df = killbill_database.get_data(
                "customer_bills", {}, ["created_by"]
            )
            created_by = list(
                set(created_by_df["created_by"].tolist())
            )  # Remove duplicates
        except Exception as db_error:
            logging.info(f"Database error: {db_error}")  # Optional logging

        dropdown = {"method": method, "created_by": created_by}
        header_map = get_headers_mapping(
            killbill_database,
            ["Payment History Report"],
            role_name,
            "",
            "",
            "",
            "",
            data,
        )
        columns_to_sum = ["amount"]
        for row in df_dict:
            for col in columns_to_sum:
                if col in row:
                    value = row[col]
                    if isinstance(value, (int, float)):
                        row[col] = f"{value:.2f}"
                    else:
                        # if it's None or garbage, default to 0.00
                        row[col] = "0.00"
        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "dropdown": dropdown,
            "summary": {"amount": round(total_amount, 2)},
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "payment_details_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched Payment History Report",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching Reoprts list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "payment_details_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response


def ar_aging_report_list_view_30_12_2025(data):
    """
    Retrieves AR Aging Report data with optional date filtering, sorting, pagination, timezone conversion,
    header mapping, and dropdown metadata for UI filtering.

    Args:
        data (dict): Input parameters including:
            - table_name (str, optional): The name of the database view or table. Default: 'ar_aging_view'.
            - col_sort (dict, optional): Sorting configuration in the format {column_name: direction}.
            - module_name (str, optional): Module name for header mapping. Default: 'AR Aging Report'.
            - tenant_name (str): Tenant name used to retrieve timezone.
            - role_name (str): Role name for header mapping.
            - start_date (str, optional): Start of due date filter in 'YYYY-MM-DD' format.
            - end_date (str, optional): End of due date filter in 'YYYY-MM-DD' format.
            - mod_pages (dict): Pagination info containing 'start' and 'end' indices.

    Returns:
        dict: API response with the following keys:
            - flag (bool): Indicates success (True) or failure (False).
            - message (str): Status message for the operation.
            - data (dict): Dictionary containing:
                - 'reports_data': Serialized records of AR aging data.
            - header_map (dict): Header mapping for frontend table generation.
            - pages (dict): Contains pagination metadata ('start', 'end', 'total').
            - dropdown (dict): Dropdown filter options for frontend filtering, including:
                - agent (list): List of sales agents.
                - customer_status (list): List of customer statuses.
                - format (list): Available report formats.
                - charge_date, credit_date, payment_date (list): Date filtering options.
    """
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    start_time = time.time()
    table_name = data.get("table_name", "ar_aging_view")
    if not table_name:
        table_name = "ar_aging_view"
    col_sort = data.get("col_sort", "")
    module_name = data.get("module_name", "AR Aging Report")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    date_flag = True
    if not start_date or not end_date:
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")
    # user selected data
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None

    tenant_time_zone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )["time_zone"].to_list()[0]

    if not tenant_time_zone:
        raise ValueError("No valid timezone found for tenant.")

    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        base_query = f"""
            SELECT * FROM {table_name}
            WHERE 1=1 and tenant_id = {tenant_id}
        """
        params = []
        # Sort order handling (ensure valid keys)
        if start_date and end_date and date_flag:
            base_query += " AND due_date_of_this_bill BETWEEN %s AND %s"
            params.extend([start_date, end_date])
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            order_direction = order[order_by].lower()
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY due_date_of_this_bill DESC"
        count_df = killbill_database.execute_query(base_query, params=params)
        count_df_dict = count_df.to_dict(orient="records")
        total_pages_count = len(count_df_dict)
        columns_to_sum = [
            "current",
            "0-30",
            "31-60",
            "61-90",
            "91-120",
            "120+",
            "total",
        ]

        summary_totals = {
            col: sum(row.get(col, 0) or 0 for row in count_df_dict)
            for col in columns_to_sum
        }
        pages_data = {"start": start, "end": end, "total": total_pages_count}
        base_query += " LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        df = killbill_database.execute_query(base_query, params=params)
        df_dict = df.to_dict(orient="records")
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        dropdown = {}
        agent_list = []
        try:
            agent_list_df = killbill_database.get_data(
                table_name="customer_profiles", condition=None, columns=["sales_person"]
            )["sales_person"].to_list()
            agent_list = list(set(agent_list_df))
        except Exception as e:
            logging.info(f"exception------{e}")
            agent_list = []
        customer_status = ["Open"]
        format = [
            "Detailed",
            "Summary by Agent",
            "Summary by Bill Profile",
            "Summary by Collection Assignee",
            "Summary by Cycle Day",
            "Summary by Status",
        ]
        charge_date = [
            "Charge Created Date",
            "Bill Created Date",
            "Bill Due Date",
            "Cycle Date",
        ]
        credit_date = [
            "Credit Created Date",
            "Bill Created Date",
            "Bill Due Date",
            "Cycle Date",
        ]
        payment_date = [
            "Payment Created Date",
            "Bill Created Date",
            "Bill Due Date",
            "Cycle Date",
            "Recevied Date",
        ]
        dropdown["agent"] = agent_list
        dropdown["customer_status"] = customer_status
        dropdown["format"] = format
        dropdown["charge_date"] = charge_date
        dropdown["credit_date"] = credit_date
        dropdown["payment_date"] = payment_date

        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )
        for row in df_dict:
            for col in columns_to_sum:
                if col in row:
                    value = row[col]
                    if isinstance(value, (int, float)):
                        row[col] = f"{value:.2f}"
                    else:
                        # if it's None or garbage, default to 0.00
                        row[col] = "0.00"
        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "dropdown": dropdown,
            "summary": {
                "current": round(summary_totals["current"], 2),
                "0-30": round(summary_totals["0-30"], 2),
                "31-60": round(summary_totals["31-60"], 2),
                "61-90": round(summary_totals["61-90"], 2),
                "91-120": round(summary_totals["91-120"], 2),
                "120+": round(summary_totals["120+"], 2),
                "total": round(summary_totals["total"], 2),
            },
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "ar_aging_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched AR Aging Report",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching reports list",
            "data": {},
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "ar_aging_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def normalize_customers_from_config(customers):
    if not customers:
        return None

    # Already tuple/list
    if isinstance(customers, (list, tuple)):
        return sorted(set(c.strip() for c in customers if c and str(c).strip()))

    # Tuple-like string → convert safely
    if isinstance(customers, str):
        cleaned = customers.strip()

        try:
            parsed = ast.literal_eval(cleaned)

            if isinstance(parsed, (list, tuple)):
                return sorted(
                    set(str(c).strip() for c in parsed if c and str(c).strip())
                )
        except Exception:
            pass

        # Fallback: CSV-style
        cleaned = cleaned.strip("()")
        return sorted(
            set(
                c.strip().strip("'").strip('"')
                for c in cleaned.split(",")
                if c.strip()
            )
        )

    return None



def ar_aging_report_list_view(data):
    """
    Retrieves AR Aging Report data with optional date filtering, sorting, pagination, timezone conversion,
    header mapping, and dropdown metadata for UI filtering.

    Args:
        data (dict): Input parameters including:
            - table_name (str, optional): The name of the database view or table. Default: 'ar_aging_view'.
            - col_sort (dict, optional): Sorting configuration in the format {column_name: direction}.
            - module_name (str, optional): Module name for header mapping. Default: 'AR Aging Report'.
            - tenant_name (str): Tenant name used to retrieve timezone.
            - role_name (str): Role name for header mapping.
            - start_date (str, optional): Start of due date filter in 'YYYY-MM-DD' format.
            - end_date (str, optional): End of due date filter in 'YYYY-MM-DD' format.
            - mod_pages (dict): Pagination info containing 'start' and 'end' indices.

    Returns:
        dict: API response with the following keys:
            - flag (bool): Indicates success (True) or failure (False).
            - message (str): Status message for the operation.
            - data (dict): Dictionary containing:
                - 'reports_data': Serialized records of AR aging data.
            - header_map (dict): Header mapping for frontend table generation.
            - pages (dict): Contains pagination metadata ('start', 'end', 'total').
            - dropdown (dict): Dropdown filter options for frontend filtering, including:
                - agent (list): List of sales agents.
                - customer_status (list): List of customer statuses.
                - format (list): Available report formats.
                - charge_date, credit_date, payment_date (list): Date filtering options.
    """
    # UI Keys
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name = data.get("db_name", "")

    # DB Connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)
    logging.info(f'### ar_aging_report_list_view db_config {db_config}')
    data = get_tenant_details_from_token(common_utils_database, data)

    start_time = time.time()
    table_name = data.get("table_name", "ar_aging_view")
    if not table_name:
        table_name = "ar_aging_view"
    col_sort = data.get("col_sort", "")
    module_name = data.get("module_name", "AR Aging Report")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    


    date_flag = True
    if not start_date or not end_date:
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")
    # user selected data
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None

    tenant_time_zone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )["time_zone"].to_list()[0]

    if not tenant_time_zone:
        raise ValueError("No valid timezone found for tenant.")

    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        base_query = f"""
                        SELECT * FROM {table_name}
                        WHERE tenant_id = %s AND (
                        bill_reversed_date IS NULL
                        OR date_trunc('month', created_date) <> date_trunc('month', bill_reversed_date)
                    ) 
                    """
        params = [tenant_id]
        # Sort order handling (ensure valid keys)
        if start_date and end_date and date_flag:
            base_query += " AND due_date_of_this_bill BETWEEN %s AND %s"
            params.extend([start_date, end_date])
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            order_direction = order[order_by].lower()
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY due_date_of_this_bill DESC"
        count_df = killbill_database.execute_query(base_query, params=params)
        count_df_dict = count_df.to_dict(orient="records")
        total_pages_count = len(count_df_dict)
        columns_to_sum = [
            "current",
            "0-30",
            "31-60",
            "61-90",
            "91-120",
            "120+",
            "total",
        ]

        summary_totals = {
            col: sum(row.get(col, 0) or 0 for row in count_df_dict)
            for col in columns_to_sum
        }
        pages_data = {"start": start, "end": end, "total": total_pages_count}
        base_query += " LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        df = killbill_database.execute_query(base_query, params=params)
        df_dict = df.to_dict(orient="records")
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        dropdown = {}
        agent_list = []
        try:
            agent_list_df = killbill_database.get_data(
                table_name="customer_profiles", condition=None, columns=["sales_person"]
            )["sales_person"].to_list()
            agent_list = list(set(agent_list_df))
        except Exception as e:
            logging.info(f"exception------{e}")
            agent_list = []
        customer_status = ["Open"]
        format = [
            "Detailed",
            "Summary by Agent",
            "Summary by Bill Profile",
            "Summary by Collection Assignee",
            "Summary by Cycle Day",
            "Summary by Status",
        ]
        charge_date = [
            "Charge Created Date",
            "Bill Created Date",
            "Bill Due Date",
            "Cycle Date",
        ]
        credit_date = [
            "Credit Created Date",
            "Bill Created Date",
            "Bill Due Date",
            "Cycle Date",
        ]
        payment_date = [
            "Payment Created Date",
            "Bill Created Date",
            "Bill Due Date",
            "Cycle Date",
            "Recevied Date",
        ]
        dropdown["agent"] = agent_list
        dropdown["customer_status"] = customer_status
        dropdown["format"] = format
        dropdown["charge_date"] = charge_date
        dropdown["credit_date"] = credit_date
        dropdown["payment_date"] = payment_date

        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )
        # for row in df_dict:
        #     for col in columns_to_sum:
        #         if col in row:
        #             value = row[col]
        #             if isinstance(value, (int, float)):
        #                 row[col] = f"{value:.2f}"
        #             else:
        #                 # if it's None or garbage, default to 0.00
        #                 row[col] = "0.00"
        for row in df_dict:
            for col in columns_to_sum:
                if col in row:
                    row[col] = format_amount(row.get(col, 0))

        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "dropdown": dropdown,
            "summary": {
                "current": round(summary_totals["current"], 2),
                "0-30": round(summary_totals["0-30"], 2),
                "31-60": round(summary_totals["31-60"], 2),
                "61-90": round(summary_totals["61-90"], 2),
                "91-120": round(summary_totals["91-120"], 2),
                "120+": round(summary_totals["120+"], 2),
                "total": round(summary_totals["total"], 2),
            },
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "ar_aging_report_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully fetched AR Aging Report",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching reports list",
            "data": {},
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "ar_aging_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response



def export_ar_aging_report(data):
    start_time = time.time()

    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    logging.info(f'### export_ar_aging_report db_config {db_config}')

    table_name = data.get("table_name") or "ar_aging_view"
    col_sort = data.get("col_sort", {})
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    changed_data = data.get("changed_data", {})
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    tenant_id = data.get("tenant_id")
    mode = os.getenv("ENV", "UAT")

    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    tenant_database = data.get("db_name", "")
    tenant_database_conn = DB(tenant_database, **db_config)

    # ---------- Date Handling ----------
    date_flag = True
    if start_date == "Invalid Date" or end_date == "Invalid Date":
        date_flag = False

    if end_date and date_flag:
        end_date = (
            datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        ).strftime("%Y-%m-%d")

    # ---------- Base Query ----------
    base_query = f"""SELECT * FROM {table_name} WHERE tenant_id = %s 
                AND (
                    bill_reversed_date IS NULL
                    OR date_trunc('month', created_date) <> date_trunc('month', bill_reversed_date)
                ) 
                """
    params = [tenant_id]

    # ---------- Timezone ----------
    tenant_time_zone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )["time_zone"].iloc[0]

    if not tenant_time_zone:
        raise ValueError("No valid timezone found for tenant")

    if "Asia" in tenant_time_zone:
        tenant_time_zone = tenant_time_zone.split()[-1]

    # ---------- Clean Filters ----------
    changed_data = {
        k: v for k, v in changed_data.items()
        if v not in ("", None, [], {}, "null", False)
    }

    if start_date and end_date and date_flag:
        base_query += " AND due_date_of_this_bill BETWEEN %s AND %s"
        params.extend([start_date, end_date])

    if "customer_status" in changed_data:
        base_query += " AND status = %s"
        params.append(changed_data["customer_status"])

    if "minimum_balance" in changed_data:
        base_query += " AND total >= %s"
        params.append(float(changed_data["minimum_balance"]))

    if "agent" in changed_data:
        base_query += " AND agent = %s"
        params.append(changed_data["agent"])

    # ---------- Sorting (whitelisted) ----------
    allowed_sort_columns = {
        "due_date_of_this_bill",
        "customer_name",
        "total",
        "status",
    }

    if col_sort:
        col, direction = list(col_sort.items())[0]
        if col in allowed_sort_columns and direction.lower() in ("asc", "desc"):
            base_query += f" ORDER BY {col} {direction.upper()}"
        else:
            base_query += " ORDER BY due_date_of_this_bill DESC"
    else:
        base_query += " ORDER BY due_date_of_this_bill DESC"

    # ---------- Execute ----------
    df = killbill_database.execute_query(base_query, params=params)
    df_dict = df.to_dict(orient="records")

    for d in df_dict:
        for k in ("id", "customer_profile_id", "modified_date", "account_number"):
            d.pop(k, None)

    if not df_dict:
        df = pd.DataFrame(columns=[
            "customer_id", "customer_name", "email", "current", "0-30", "31-60",
            "61-90", "91-120", "120+", "total", "agent", "contact",
            "closed_date", "status", "parent_account_number", "parent_name",
            "template_description", "step_description", "day",
        ])
    else:
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        df = pd.DataFrame(df_dict).fillna("")
        df = df.drop(columns=["tenant_id", "collection_step", "due_date_of_this_bill"], errors="ignore")
        df.rename(
            columns={
                "template_description": "Collection Template",
                "step_description": "Collection Step",
            },
            inplace=True,
        )

        numeric_cols = ["current", "0-30", "31-60", "61-90", "91-120", "120+", "total"]
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).apply(format_amount)

    data["dfs"] = {"AR Aging": df}
    data["module_name"] = "AR Aging Report"

    response = export_to_s3_bucket_(data)

    database.update_audit(
        {
            "service_name": "export_ar_aging_report",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": int(time.time() - start_time),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully Exported AR Aging",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at"),
        },
        "audit_user_actions",
    )

    return response

def export_payment_details_report(data):
    start_time = time.time()

    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    table_name = data.get("table_name") or "vw_payment_history"
    tenant_name = data.get("tenant_name", "")
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    tenant_id = data.get("tenant_id")
    role_name = data.get("role_name", "")
    mode = os.getenv("ENV", "UAT")

    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1


    # ---------- Date Handling ----------
    date_flag = True
    if start_date == "Invalid Date" or end_date == "Invalid Date":
        date_flag = False

    if end_date and date_flag:
        end_date = (
            datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        ).strftime("%Y-%m-%d")

    # ---------- Timezone ----------
    tz_df = common_utils_database.execute_query(
        "SELECT time_zone FROM tenant WHERE tenant_name = %s",
        params=[tenant_name],
    )

    if tz_df.empty or not tz_df.iloc[0]["time_zone"]:
        raise ValueError("No valid timezone found for tenant")

    tenant_time_zone = tz_df.iloc[0]["time_zone"]
    if "Asia" in tenant_time_zone:
        tenant_time_zone = tenant_time_zone.split()[-1]

    try:
        # ---------- Base Query ----------
        query = f"""
            SELECT
                customer_id,
                customer_name,
                agent,
                amount,
                category,
                date AS payment_date,
                created_date AS bill_date,
                ref,
                created_by
            FROM {table_name}
            WHERE tenant_id = %s
        """
        params = [tenant_id]

        # ---------- Date Filter ----------
        if start_date and end_date and date_flag:
            query += " AND date BETWEEN %s AND %s"
            params.extend([start_date, end_date])

        query += " ORDER BY date DESC"

        # ---------- Execute ----------
        df = killbill_database.execute_query(query, params=params)
        records = df.to_dict(orient="records")
        records = convert_timestamp(records, tenant_time_zone)

        if not records:
            df = pd.DataFrame(columns=[
                "customer_id",
                "customer_name",
                "agent",
                "amount",
                "method",
                "payment_date",
                "bill_date",
                "ref",
                "created_by"
                # "name_on_card",
            ])
        else:
            df = pd.DataFrame(records).fillna("")
            df.rename(columns={"category": "method"}, inplace=True)

            if "amount" in df.columns:
                df["amount"] = (
                    pd.to_numeric(df["amount"], errors="coerce")
                    .fillna(0)
                    .apply(format_amount)
                )

        data["dfs"] = {"Payment Details": df}
        data["module_name"] = "Payment History Report"

        response = export_to_s3_bucket_(data)

        database.update_audit(
            {
                "service_name": "export_payment_details_report",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": "Successfully Exported Payment Details",
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "audit_user_actions",
        )

        return response

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")

        database.log_error_to_db(
            {
                "service_name": "export_payment_details_report",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "error_log_table",
        )

        return {
            "flag": False,
            "message": "Something went wrong exporting Payment Details",
            "data": {},
        }

def export_unposted_items_report(data):
    """
    Retrieves a list of Reports for display, including pagination, filtering, and dropdown options.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Tenant database name (default: 'altaworx_central').
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name for fetching timezone.
            - mod_pages (dict): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Customer profiles with pagination.
            - header_map (dict): Mapped headers for UI display.
            - dropdown (dict): Dropdown values for filters.
            - pages (dict): Pagination details.
    """
    start_time = time.time()
    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # Extract relevant details from the input data dictionary
    table_name = data.get("table_name", "reports")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    # report_flag=data.get('report_flag', '')
    changed_data = data.get("changed_data", {})
    account_number = changed_data.get("column_value", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    # Get tenant's timezone
    tenant_name = data.get("tenant_name", "")
    tenant_timezone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )

    # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(
            " ", ""
        )  # Ensure it's formatted correctly

    try:
        # query to get the data
        base_query = "select customer_id, description, amount, mrc,calculated_cost, sms_cost, tax_name, start_date, end_date, created_date, tn, line_id, product_id from unposted_items_view where is_active = %s and tenant_id = %s ORDER BY created_date desc"
        df = killbill_database.execute_query(
            base_query, params=[True, tenant_id]
        )  # Get the DataFrame directly
        df = df.rename(
            columns={
                "customer_id": "customer_ID",
                "mrc": "MRC",
                "calculated_cost": "usage",
                "sms_cost": "SMS",
                "tax_name": "tax",
                "line_id": "line_ID",
                "product_id": "product_ID",
            }
        )
        df_dict = df.to_dict(orient="records")

        # Convert timestamps to the tenant's timezone
        final_df_dict = convert_timestamp(df_dict, tenant_time_zone)
        # Fetch mapped headers
        header_map = get_headers_mapping(
            killbill_database, ["Unposted Items"], role_name, "", "", "", "", data
        )
        in_header_map = header_map["Unposted Items"]["header_map"]

        if not final_df_dict:
            columns = []
            for key in in_header_map:
                columns.append(key)
            df = pd.DataFrame(columns=columns)
        else:
            df = pd.DataFrame(final_df_dict)
            df = df.fillna("")
        data["dfs"] = {"Unposted Items by Customer": df}
        data["module_name"] = "Unposted Items"
        response = export_to_s3_bucket_(data)
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "export_unposted_items_report",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully Exported Unposted Items",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong Exporting Unposted Items",
            "data": {},
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_unposted_items_report",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def export_transcation_analysis_report(data):
    start_time = time.time()

    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    tenant_id = data.get("tenant_id")
    mode = os.getenv("ENV", "UAT")

    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1


    # ---------- Date Handling ----------
    if end_date:
        end_date = (
            datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        ).strftime("%Y-%m-%d")

    # ---------- Timezone ----------
    tz_df = common_utils_database.execute_query(
        "SELECT time_zone FROM tenant WHERE tenant_name = %s",
        params=[tenant_name],
    )

    if tz_df.empty or not tz_df.iloc[0]["time_zone"]:
        raise ValueError("No valid timezone found for tenant")

    tenant_time_zone = tz_df.iloc[0]["time_zone"]
    if "Asia" in tenant_time_zone:
        tenant_time_zone = tenant_time_zone.split()[-1]

    try:
        # ---------- Base Query ----------
        query = """
            SELECT
                account_number,
                customer_name,
                description,
                gl_code,
                product_id,
                quantity,
                bill_range,
                category AS type,
                amount,
                nrc,
                mrc,
                calculated_cost AS usage,
                tax_name AS tax,
                modified_date
            FROM transaction_analysis_view
            WHERE tenant_id = %s
            AND is_active = true
        """
        params = [tenant_id]


        # ---------- Date Filter ----------
        if start_date and end_date:
            query += """
                AND to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s
                AND to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s
            """
            params.extend([start_date, end_date])

        query += " ORDER BY bill_id DESC"

        # ---------- Execute ----------
        df = killbill_database.execute_query(query, params=params)
        records = df.to_dict(orient="records")

        # ---------- Column Ordering ----------
        df = pd.DataFrame(records)
        if not df.empty and "description" in df.columns and "gl_code" in df.columns:
            cols = list(df.columns)
            cols.remove("gl_code")
            cols.insert(cols.index("description") + 1, "gl_code")
            df = df[cols]

        records = convert_timestamp(df.to_dict(orient="records"), tenant_time_zone)

        # ---------- Header Mapping ----------
        header_map = get_headers_mapping(
            killbill_database,
            ["Transaction Report"],
            role_name,
            "",
            "",
            "",
            "",
            data,
        )
        mapped_headers = header_map["Transaction Report"]["header_map"]

        if not records:
            df = pd.DataFrame(columns=list(mapped_headers.keys()))
        else:
            df = pd.DataFrame(records).fillna("")

            numeric_cols = ["amount", "mrc", "nrc", "usage"]
            for col in numeric_cols:
                if col in df.columns:
                    df[col] = (
                        pd.to_numeric(df[col], errors="coerce")
                        .fillna(0)
                        .apply(format_amount)
                    )

        data["dfs"] = {"Transaction Report": df}
        data["module_name"] = "Transaction Report"

        response = export_to_s3_bucket_(data)

        database.update_audit(
            {
                "service_name": "export_transcation_analysis_report",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": "Successfully Exported Transaction Analysis",
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "audit_user_actions",
        )

        return response

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")

        database.log_error_to_db(
            {
                "service_name": "export_transcation_analysis_report",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "error_log_table",
        )

        return {
            "flag": False,
            "message": "Something went wrong exporting Transaction Analysis",
            "data": {},
        }


def export_altaworx_billing_report_10_08(data):
    """
    Generates and exports the Billing Report w/_City_County_Country for a given tenant,
    including pagination, date filtering, role-based header mapping, and timezone localization.

    Args:
        data (dict): Input configuration with the following optional and required keys:
            - table_name (str, optional): Name of the database view/table. Defaults to 'billing_report_view'.
            - tenant_name (str): Name of the tenant for resolving timezone and data scope.
            - role_name (str): User role for permission-based header mapping.
            - report_flag (str, optional): Optional flag to indicate export behavior.
            - changed_data (dict, optional): Filtering details. Expects 'date_range' as [start_date, end_date].
            - col_sort (dict, optional): Dictionary indicating sort order (e.g., {"id": "desc"}).
            - mod_pages (dict, optional): Pagination details. Contains:
                - start (int): Start index for records.
                - end (int): End index for records.

    Returns:
        dict: A dictionary containing the result of the export operation with keys:
            - flag (bool): Indicates if export was successful.
            - message (str): Success or error message.
            - data (dict): Metadata about the exported report and file.
            - Other keys depending on the response from `export_to_s3_bucket_`.
    """
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    table_name = data.get("table_name", "billing_report_view")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    report_flag = data.get("report_flag", "")
    changed_data = data.get("changed_data", {})
    date_range = changed_data.get("date_range", {})
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    if len(date_range) >= 2:  # Ensure date_range has at least two values
        start_date = date_range[0].replace("Z", "")  # Remove 'Z'
        end_date = date_range[1].replace("Z", "")
    else:
        start_date = None
        end_date = None

    # user selected data

    start = data.get("mod_pages", {}).get("start", 0)
    end = data.get("mod_pages", {}).get("end", 100)
    limit = end - start
    offset = start

    tenant_name = data.get("tenant_name", "")
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(
        tenant_timezone_query, params=[tenant_name]
    )

    # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")
    try:
        if start_date and end_date:
            total_count_result_query = f"Select count(id) from billing_report_view where bill_cycle_start_date between '{start_date}' and '{end_date}'"
        else:
            total_count_result_query = "Select count(id) from billing_report_view"
        total_count_df = killbill_database.execute_query(total_count_result_query, True)
        total_count = total_count_df.iloc[0, 0]
        # Pagination information
        pages_data = {"start": start, "end": end, "total": int(total_count)}

        # Sort order handling (ensure valid keys)
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
        else:
            order = {"bill_id": "desc"}

        if start_date and end_date:
            query = f"Select * from billing_report_view where between '{start_date}' and '{end_date}' and tenant_id = {tenant_id} order by bill_id desc"
        else:
            query = f"Select * from {table_name} where tenant_id = {tenant_id} order by bill_id desc"
        df_dict = killbill_database.execute_query(query, True)
        df_dict = df_dict.to_dict(orient="records")

        final_df_dict = df_dict
        for i in range(len(final_df_dict)):
            item = final_df_dict[i]
            final_df_dict[i] = {
                "account_number": item["account_number"],
                "account_type": item["account_type"],
                "customer_name": item["customer_name"],
                "bill_id": item["bill_id"],
                "agent": item["sales_person"],
                "secondary_agent": "No",
                "statement_date": item["bill_cycle_start_date"],
                "balance_forward": item["amount_due"],
                "mrc": item["mrc"],
                "nrc": item["nrc"],
                "network_access_fee": item["network_access_fee"],
                "admin_recovery_tax": item["cost_recovery_fee"],
                "other_taxes": item["taxes"],
                "total": item["total"],
                "payments": item["payments"],
                "payment_date": item["bill_due_date"],
                "balance": item["account_balance"],
                "timezone": tenant_time_zone,
                "state": item["state"],
                "city": item["city"],
                "country": item["country"],
            }

        final_df_dict = convert_timestamp(final_df_dict, tenant_time_zone)
        if not final_df_dict:
            columns = [
                "account_number",
                "account_type",
                "customer_name",
                "address",
                "bill_id",
                "statement_date",
                "sales_person",
                "secondary_sales_person",
                "bill_cycle_start_date",
                "balance_forward",
                "mrc",
                "nrc",
                "network_access_fee",
                "admin_recovery_tax",
                "other_taxes",
                "total",
                "payments",
                "bill_due_date",
                "account_balance",
                "state",
                "timezone",
            ]
            df = pd.DataFrame(columns=columns)  # Create empty DataFrame with columns
        else:
            df = pd.DataFrame(final_df_dict)
        # df = pd.DataFrame(final_df_dict)

        df = df.fillna("")
        # data["dfs"]={
        #     "Billing Report w/_City_County_Country":df
        # }
        data["dfs"] = {
            "Billing Report w_City_County_Country": df  # Convert to list of dictionaries
        }
        data["module_name"] = "Billing Report w/_City_County_Country"
        response = export_to_s3_bucket_(data)
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "export_altaworx_billing_report",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully Exported Altaworx Billing",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong Exporting Unposted Items",
            "data": {},
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_altaworx_billing_report",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def export_altaworx_billing_report(data):
    start_time = time.time()

    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    table_name = data.get("table_name") or "billing_report_view"
    col_sort = data.get("col_sort", {})
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    changed_data = data.get("changed_data", {})
    tenant_id = data.get("tenant_id")
    mode = os.getenv("ENV", "UAT")

    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    tenant_database = data.get("db_name", "")
    tenant_database_conn = DB(tenant_database, **db_config)


    # ---------- Date Handling ----------
    start_date = data.get("start_date")
    end_date = data.get("end_date")

    if end_date:
        end_date = (
            datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        ).strftime("%Y-%m-%d")

    # ---------- Timezone ----------
    tz_df = common_utils_database.execute_query(
        "SELECT time_zone FROM tenant WHERE tenant_name = %s",
        params=[tenant_name],
    )

    if tz_df.empty or not tz_df.iloc[0]["time_zone"]:
        raise ValueError("No valid timezone found for tenant")

    tenant_time_zone = tz_df.iloc[0]["time_zone"]
    if "Asia" in tenant_time_zone:
        tenant_time_zone = tenant_time_zone.split()[-1]

    # ---------- Base Query ----------
    query = f"""SELECT * FROM {table_name} WHERE tenant_id = %s (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date) <> date_trunc('month', bill_reversed_date)
            ) """
    params = [tenant_id]

    if start_date and end_date:
        query += " AND bill_cycle_start_date BETWEEN %s AND %s"
        params.extend([start_date, end_date])

    # ---------- Sorting ----------
    allowed_sort_columns = {
        "bill_id",
        "bill_cycle_start_date",
        "customer_name",
        "total",
    }

    if col_sort:
        col, direction = list(col_sort.items())[0]
        if col in allowed_sort_columns and direction.lower() in ("asc", "desc"):
            query += f" ORDER BY {col} {direction.upper()}"
        else:
            query += " ORDER BY bill_cycle_start_date DESC"
    else:
        query += " ORDER BY bill_cycle_start_date DESC"

    # ---------- Execute ----------
    df = killbill_database.execute_query(query, params=params)
    records = df.to_dict(orient="records")

    final_records = []
    for item in records:
        final_records.append({
            "account_number": item.get("account_number"),
            "account_type": item.get("account_type"),
            "customer_name": item.get("customer_name"),
            "bill_id": item.get("bill_id"),
            "agent": item.get("sales_person"),
            "secondary_agent": "No",
            "statement_date": item.get("bill_cycle_start_date"),
            "balance_forward": item.get("amount_due"),
            "mrc": item.get("mrc"),
            "nrc": item.get("nrc"),
            "network_access_fee": item.get("network_access_fee"),
            "admin_recovery_tax": item.get("cost_recovery_fee"),
            "other_taxes": item.get("taxes"),
            "total": item.get("total"),
            "payments": item.get("payments"),
            "payment_date": item.get("bill_due_date"),
            "balance": item.get("account_balance"),
            "timezone": tenant_time_zone,
            "state": item.get("state"),
            "city": item.get("city"),
            "country": item.get("country"),
        })

    final_records = convert_timestamp(final_records, tenant_time_zone)

    df = pd.DataFrame(final_records).fillna("")

    # ---------- Numeric Formatting ----------
    numeric_cols = [
        "balance_forward",
        "mrc",
        "nrc",
        "network_access_fee",
        "admin_recovery_tax",
        "other_taxes",
        "total",
        "payments",
        "balance",
    ]

    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).apply(format_amount)

    data["dfs"] = {"Billing Report w_City_County_Country": df}
    data["module_name"] = "Billing Report w_City_County_Country"

    response = export_to_s3_bucket_(data)

    database.update_audit(
        {
            "service_name": "export_altaworx_billing_report",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": int(time.time() - start_time),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully Exported Altaworx Billing",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at"),
        },
        "audit_user_actions",
    )

    return response

def collections_steps_list_view(data):
    """
    Fetches applicable collection steps for a bill based on its due date and template.

    Calculates days overdue, retrieves matching steps from the database, highlights the
    latest applicable step, and returns step data with header mappings for UI display.
    """
    start_time = time.time()
    # Database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)

    # Extract relevant details from input data
    table_name = data.get("table_name", "customer_profiles")
    role_name = data.get("role_name", "")
    tenant_name = data.get("tenant_name", "")
    module_name = data.get("module_name", "")
    changed_data = data.get("changed_data", {})
    template_id = changed_data.get("collection_step", "")
    bill_due_date = changed_data.get("due_date_of_this_bill", "")
    logging.info(f"###bill_due_date {bill_due_date}")

    if isinstance(bill_due_date, str):
        bill_due_date = bill_due_date.strip()
        if not bill_due_date:
            return {
                "flag": False,
                "message": "Bill due date is mandatory",
            }  # No valid date provided
        bill_due_date = parser.parse(bill_due_date).date()
    else:
        bill_due_date = (
            bill_due_date.date()
            if isinstance(bill_due_date, datetime)
            else bill_due_date
        )

    # Calculate days overdue (like in SQL)
    days_overdue = (datetime.now().date() - bill_due_date).days

    if days_overdue < 0:
        # Bill is not yet due
        return None

    if template_id:
        # get collection_steps data from collection_steps data
        collection_steps_data = killbill_database.get_data(
            "collection_steps",
            {"template_id": template_id},
            ["id", "step_type", "step_description", "grace_period", "day"],
        ).to_dict(orient="records")
        logging.info(f"###collection_steps_data {collection_steps_data}")
        valid_steps = [
            step
            for step in collection_steps_data
            if int(step.get("day", 0)) <= days_overdue
        ]

        if not valid_steps:
            return None

        # Pick the step with the highest day (latest applicable step)
        highlighted_row_id = max(valid_steps, key=lambda s: int(s.get("day", 0)))
    else:
        collection_steps_data = []
    try:
        # Fetch mapped headers
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )
        steps_data = {"collection_steps": serialize_data(collection_steps_data)}

        # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": steps_data,
            "header_map": header_map,
            "highlighted_row_id": highlighted_row_id,
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "collections_steps_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "Successfully Collection Steps Data",
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return response

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Collections list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "collections_steps_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")

    return response


def export_cycle_date_list_view(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Export Cycle Date")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    col_sort = data.get("col_sort", "")

    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    try:
        total_count_query = """
            SELECT COUNT(id) AS total_count 
            FROM vw_export_cycle_date 
            WHERE tenant_id = %s
        """
        total_count_result = killbill_database.execute_query(
            total_count_query, params=[tenant_id]
        )
        total_count = int(total_count_result["total_count"].iloc[0])

        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"bill_cycle_start_date": "desc"}
        )
        order_by_clause = ", ".join(
            [f"{col} {direction}" for col, direction in order.items()]
        )

        account_details_query = f"""
            SELECT sales_person, account_number, customer_id, customer_name, cycle_day, bill_cycle_start_date, status, parent_account, child_account, time_zone
            FROM vw_export_cycle_date 
            WHERE tenant_id = %s 
            ORDER BY {order_by_clause}
            LIMIT %s OFFSET %s
        """
        account_details = killbill_database.execute_query(
            account_details_query, params=[tenant_id, limit, offset]
        ).to_dict(orient="records")

        pages_data = {"start": start, "end": end, "total": total_count}

        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        data_dict_all = {"reports_data": serialize_data(account_details)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
        }
        end_time = time.time()
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Export Cycle Date list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_cycle_date_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response


def export_export_cycle_date(data):
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    table_name = data.get("table_name", "billing_report_view")
    col_sort = data.get("col_sort", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id", "")
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    tenant_name = data.get("tenant_name", "")
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(
        tenant_timezone_query, params=[tenant_name]
    )

    # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        account_details_query = f"""
                SELECT sales_person as agent_name, account_number as account_number,
                customer_id as customer_id,customer_name, cycle_day, bill_cycle_start_date as current_cycle_date,
                status, parent_account as isparent_account, child_account as ischild_account, time_zone
                FROM vw_export_cycle_date 
                WHERE tenant_id = %s 
            """
        account_details = killbill_database.execute_query(
            account_details_query, params=[tenant_id]
        ).to_dict(orient="records")
        account_details = convert_timestamp(account_details, tenant_time_zone)
        df = pd.DataFrame(account_details)
        df = df.fillna("")
        columns_to_sum = [
            "prev_mrc",
            "mrc",
            "diff_mrc",
            "prev_nrc_usage",
            "nrc_usage",
            "diff_nrc_usage",
            "prev_nrc",
            "nrc",
            "diff_nrc",
        ]
        for col in columns_to_sum:
            if col in df.columns:
                df[col] = df[col].apply(
                    lambda x: (
                        f"{float(x):.2f}"
                        if str(x).replace(".", "", 1).isdigit()
                        else "0.00"
                    )
                )
        data["dfs"] = {"Export Cycle Date": df}
        data["module_name"] = "Export Cycle Date"
        return export_to_s3_bucket_(data)

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Export Cycle Date list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_export_cycle_date",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def billed_through_date_report_list_view(data):
    """
    Retrieves and formats billed through date report data with pagination support.
    """
    logging.info(f"###billed_through_date_report_list_view data:{data}")
    # UI Params
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name = data.get("db_name", "")

    # Initialize DBs
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    killbill_database = DB(billing_db_name, **db_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Billed Through Date Report")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")

    pagination = data.get("mod_pages", {})
    start = pagination.get("start", None)
    end = pagination.get("end", None)
    limit = (end - start) if start or end else None
    offset = start 
    

    date_flag = bool(start_date and end_date)
    if end_date and date_flag:
        try:
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error parsing end_date: {e}")

    col_sort = data.get("col_sort", "")

    # Tenant adjustments
    environment_mode = os.getenv("ENV", "UAT")
    if environment_mode == "UAT" and tenant_id in [212, "212"]:
        tenant_id = 1
        tenant_name = "Altaworx"
    else:
        tenant_name = data.get("tenant_name", "")

    # Get Tenant Timezone
    tenant_timezone = common_utils_database.get_data("tenant",{"tenant_name":tenant_name},["time_zone"])

    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        # --- COUNT QUERY ---
        total_count_query = """
            SELECT COUNT(*) FROM billed_through_date_view
            WHERE tenant_id = %s AND is_active = TRUE
        """
        params = [tenant_id]

        if date_flag:
            total_count_query += " AND billed_through_date BETWEEN %s AND %s"
            params.extend([start_date, end_date])

        total_count_df = killbill_database.execute_query(
            total_count_query, params=params
        )
        total_count = int(total_count_df.iloc[0, 0])

        pages_data = {"start": start, "end": end, "total": total_count}

        # --- BASE QUERY ---
        base_query = """
            SELECT customer_id, line_id, tn, product_id, description,
                activation_date, billed_through_date, time_zone
            FROM billed_through_date_view
            WHERE tenant_id = %s AND is_active = TRUE
        """
        params = [tenant_id]

        if date_flag:
            base_query += " AND billed_through_date BETWEEN %s AND %s"
            params.extend([start_date, end_date])

        base_query += " ORDER BY tn DESC"

        if limit is not None and offset is not None:
            base_query += " LIMIT %s OFFSET %s"
            params.extend([limit, offset])

        report_data_df = killbill_database.execute_query(
            base_query, params=params
        )

        # --- FORMAT DATA ---
        report_records = report_data_df.to_dict(orient="records")
        report_records = convert_timestamp(report_records, tenant_time_zone)

        # for record in report_records:
        #     record["activation_date"] = (
        #         datetime.strptime(record["activation_date"], "%m-%d-%Y").strftime(
        #             "%m-%d-%Y"
        #         )
        #         if record["activation_date"]
        #         else None
        #     )
        #     record["billed_through_date"] = (
        #         datetime.strptime(record["billed_through_date"], "%m-%d-%Y").strftime(
        #             "%m-%d-%Y"
        #         )
        #         if record["billed_through_date"]
        #         else None
        #     )
        for record in report_records:
            for field in ["activation_date", "billed_through_date"]:
                try:
                    # Try both formats
                    record[field] = datetime.strptime(record[field], "%m-%d-%Y %H:%M:%S").strftime("%m-%d-%Y")
                except ValueError:
                    try:
                        record[field] = datetime.strptime(record[field], "%m-%d-%Y").strftime("%m-%d-%Y")
                    except Exception:
                        record[field] = record[field]
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        response_data = {"reports_data": serialize_data(report_records)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": response_data,
            "header_map": header_map,
            "pages": pages_data,
        }

        return {"data": response_data} if data.get("z_access_token", "") else response

    except Exception as e:
        logging.error(f"###billed_through_date_report_list_view Exception: {e}")
        error_data = {
            "service_name": "billed_through_date_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "message": "Error fetching Billed Through Date report",
            "data": {},
        }



def billed_through_date_report_list_view_30_12_2025(data):
    """
    Retrieves and formats billed through date report data with pagination support.
    """
    logging.info(f"###billed_through_date_report_list_view data:{data}")
    # Initialize DBs
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Billed Through Date Report")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")

    pagination = data.get("mod_pages", {})
    start = pagination.get("start", None)
    end = pagination.get("end", None)
    limit = (end - start) if start or end else None
    offset = start 

    date_flag = bool(start_date and end_date)
    if end_date and date_flag:
        try:
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error parsing end_date: {e}")

    col_sort = data.get("col_sort", "")

    # Tenant adjustments
    environment_mode = os.getenv("ENV", "UAT")
    if environment_mode == "UAT" and tenant_id in [212, "212"]:
        tenant_id = 1
        tenant_name = "Altaworx"
    else:
        tenant_name = data.get("tenant_name", "")

    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = common_utils_database.execute_query(
        tenant_timezone_query, params=[tenant_name]
    )

    if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
        raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        # --- COUNT QUERY ---
        # total_count_query = f"""
        #     SELECT COUNT(*) FROM billed_through_date_view
        #     WHERE tenant_id = %s and billed_flag = %s and is_active = %s
        # """
        total_count_query = f"""
            SELECT COUNT(*) FROM billed_through_date_view 
            WHERE tenant_id = %s AND is_active = TRUE
        """
        if date_flag:
            total_count_query += (
                f" AND billed_through_date BETWEEN '{start_date}' AND '{end_date}'"
            )
        # total_count_df = killbill_database.execute_query(total_count_query, params=[tenant_id,False,True])
        total_count_df = killbill_database.execute_query(
            total_count_query, params=[tenant_id]
        )
        total_count = int(total_count_df.iloc[0, 0])

        pages_data = {"start": start, "end": end, "total": total_count}

        # --- BASE QUERY ---
        base_query = f"""
            SELECT customer_id, line_id, tn, product_id, description, activation_date, billed_through_date, time_zone 
            FROM billed_through_date_view 
            WHERE tenant_id = %s AND is_active = TRUE
        """
        if date_flag:
            base_query += (
                f" AND billed_through_date BETWEEN '{start_date}' AND '{end_date}'"
            )
        base_query += " ORDER BY tn DESC"
        if limit is not None and offset is not None:
            base_query += f" LIMIT {limit} OFFSET {offset}"
        
        logging.info(f"###billed_through_date_report_list_view base_query:{base_query}---{limit}---{offset}")
        report_data_df = killbill_database.execute_query(base_query, params=[tenant_id])

        # --- FORMAT DATA ---
        report_records = report_data_df.to_dict(orient="records")
        report_records = convert_timestamp(report_records, tenant_time_zone)

        # for record in report_records:
        #     record["activation_date"] = (
        #         datetime.strptime(record["activation_date"], "%m-%d-%Y").strftime(
        #             "%m-%d-%Y"
        #         )
        #         if record["activation_date"]
        #         else None
        #     )
        #     record["billed_through_date"] = (
        #         datetime.strptime(record["billed_through_date"], "%m-%d-%Y").strftime(
        #             "%m-%d-%Y"
        #         )
        #         if record["billed_through_date"]
        #         else None
        #     )
        for record in report_records:
            for field in ["activation_date", "billed_through_date"]:
                try:
                    # Try both formats
                    record[field] = datetime.strptime(record[field], "%m-%d-%Y %H:%M:%S").strftime("%m-%d-%Y")
                except ValueError:
                    try:
                        record[field] = datetime.strptime(record[field], "%m-%d-%Y").strftime("%m-%d-%Y")
                    except Exception:
                        record[field] = record[field]
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        response_data = {"reports_data": serialize_data(report_records)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": response_data,
            "header_map": header_map,
            "pages": pages_data,
        }

        return {"data": response_data} if data.get("z_access_token", "") else response

    except Exception as e:
        logging.error(f"###billed_through_date_report_list_view Exception: {e}")
        error_data = {
            "service_name": "billed_through_date_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "message": "Error fetching Billed Through Date report",
            "data": {},
        }


def billed_through_date_report_export_10_08(data):
    """
    Exports billed through date report data to S3 bucket in Excel format.

    Args:
        data (dict): Request data containing tenant information and export parameters

    Returns:
        dict: Response from S3 export function or error response
    """

    try:
        # Initialize database connections
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)

        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "")
        # Handle environment-specific tenant mapping
        environment_mode = os.getenv("ENV", "UAT")
        if environment_mode == "UAT":
            # Map test tenant to production tenant for UAT environment
            if tenant_name == "Altaworx Test":
                tenant_name = "Altaworx"
                tenant_id = 1

        # Extract tenant information from request
        tenant_timezone_query = (
            """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        )
        tenant_timezone = common_utils_database.execute_query(
            tenant_timezone_query, params=[tenant_name]
        )

        # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
            raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
        match = re.search(
            r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
        )
        if match:
            tenant_time_zone = match.group(1).replace(" ", "")

        # Query to retrieve billed through date report data
        # Ordered by modified_date descending to get latest records first
        export_data_query = """
            SELECT customer_id, line_id, tn, product_id, description, 
                   activation_date, billed_through_date, time_zone 
            FROM billed_through_date_view 
            WHERE tenant_id = %s 
            ORDER BY tn DESC
        """

        # Execute query and get DataFrame
        report_dataframe = killbill_database.execute_query(
            export_data_query, params=[tenant_id]
        )

        # Convert DataFrame to dictionary format for processing
        report_records = report_dataframe.to_dict(orient="records")
        report_records = convert_timestamp(report_records, tenant_time_zone)
        for record in report_records:
            record["activation_date"] = datetime.strptime(
                record["activation_date"], "%m-%d-%Y %H:%M:%S"
            ).strftime("%m-%d-%Y")
            record["billed_through_date"] = datetime.strptime(
                record["billed_through_date"], "%m-%d-%Y %H:%M:%S"
            ).strftime("%m-%d-%Y")

        # Create DataFrame from records and handle null values
        processed_dataframe = pd.DataFrame(report_records)
        processed_dataframe = processed_dataframe.fillna("")

        # Prepare data structure for S3 export
        # The key will be used as the sheet name in the Excel file
        data["dfs"] = {"Billed Through Date": processed_dataframe}
        # Export processed data to S3 bucket
        return export_to_s3_bucket_(data)

    except Exception as e:
        # Log the exception for debugging purposes
        logging.error(
            f"###billed_through_date_report_export Exception in billed_through_date_report_export: {e}"
        )

        # Prepare error response for client
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billed Through Date Report",
            "data": {},
        }

        # Prepare error details for database logging
        error_details = {
            "service_name": "billed_through_date_report_export",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }

        # Log error to database for monitoring and troubleshooting
        database.log_error_to_db(error_details, "error_log_table")

        return error_response


def billed_through_date_report_export(data):
    """
    Exports billed through date report data to S3 bucket in Excel format.

    Args:
        data (dict): Request data containing tenant information and export parameters

    Returns:
        dict: Response from S3 export function or error response
    """

    try:
        # Initialize database connections
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # date range handling
        start_date = data.get("start_date", "")
        end_date = data.get("end_date", "")
        if end_date:
            try:
                end_date = (
                    datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
                ).strftime("%Y-%m-%d")
            except Exception as e:
                logging.warning(f"Error parsing end_date: {e}")

        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "")
        # Handle environment-specific tenant mapping
        environment_mode = os.getenv("ENV", "UAT")
        if environment_mode == "UAT":
            # Map test tenant to production tenant for UAT environment
            if tenant_name == "Altaworx Test":
                tenant_name = "Altaworx"
                tenant_id = 1

        # Extract tenant information from request
        tenant_timezone_query = (
            """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        )
        tenant_timezone = common_utils_database.execute_query(
            tenant_timezone_query, params=[tenant_name]
        )

        # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]["time_zone"] is None:
            raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]["time_zone"]
        match = re.search(
            r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
        )
        if match:
            tenant_time_zone = match.group(1).replace(" ", "")

        # Query to retrieve billed through date report data
        # Ordered by modified_date descending to get latest records first
        params = [tenant_id]

        if start_date and end_date:
            export_data_query = f"""
                SELECT customer_id, line_id, tn, product_id, description, 
                       activation_date, billed_through_date, time_zone 
                FROM billed_through_date_view 
                WHERE tenant_id = %s 
                    AND is_active = TRUE
                    AND billed_through_date BETWEEN '{start_date}' AND '{end_date}'
                ORDER BY tn DESC
            """
        else:
            export_data_query = f"""
                SELECT customer_id, line_id, tn, product_id, description, 
                       activation_date, billed_through_date, time_zone 
                FROM billed_through_date_view 
                WHERE tenant_id = %s
                    AND is_active = TRUE
                ORDER BY tn DESC
            """

        # Execute query and get DataFrame
        report_dataframe = killbill_database.execute_query(
            export_data_query, params=params
        )

        # Convert DataFrame to dictionary format for processing
        report_records = report_dataframe.to_dict(orient="records")
        report_records = convert_timestamp(report_records, tenant_time_zone)
        # for record in report_records:
        #     record["activation_date"] = datetime.strptime(
        #         record["activation_date"], "%m-%d-%Y %H:%M:%S"
        #     ).strftime("%m-%d-%Y")
        #     record["billed_through_date"] = datetime.strptime(
        #         record["billed_through_date"], "%m-%d-%Y %H:%M:%S"
        #     ).strftime("%m-%d-%Y")

        for record in report_records:
            for field in ["activation_date", "billed_through_date"]:
                try:
                    # Try parsing with time first
                    record[field] = datetime.strptime(record[field], "%m-%d-%Y %H:%M:%S").strftime("%m-%d-%Y")
                except ValueError:
                    try:
                        # Fallback: parse date-only format
                        record[field] = datetime.strptime(record[field], "%m-%d-%Y").strftime("%m-%d-%Y")
                    except Exception as e:
                        logging.warning(f"Failed to parse {field}='{record[field]}': {e}")
                        record[field] = record[field]  # leave as-is if parsing fails


        if not report_records:
            # Create empty DataFrame with expected columns if no data
            columns = [
                "customer_id",
                "line_id",
                "tn",
                "product_id",
                "description",
                "activation_date",
                "billed_through_date",
                "time_zone",
            ]
            processed_dataframe = pd.DataFrame(columns=columns)
        else:
            # Create DataFrame from records and handle null values
            processed_dataframe = pd.DataFrame(report_records)
            processed_dataframe = processed_dataframe.fillna("")

        # Prepare data structure for S3 export
        # The key will be used as the sheet name in the Excel file
        data["dfs"] = {"Billed Through Date": processed_dataframe}
        # Export processed data to S3 bucket
        return export_to_s3_bucket_(data)

    except Exception as e:
        # Log the exception for debugging purposes
        logging.error(
            f"###billed_through_date_report_export Exception in billed_through_date_report_export: {e}"
        )

        # Prepare error response for client
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billed Through Date Report",
            "data": {},
        }

        # Prepare error details for database logging
        error_details = {
            "service_name": "billed_through_date_report_export",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }

        # Log error to database for monitoring and troubleshooting
        database.log_error_to_db(error_details, "error_log_table")

        return error_response


def export_variance_billing_list_view(data):
    # UI Params
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name = data.get("db_name", "")

    # Initialize DBs
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    killbill_database = DB(billing_db_name, **db_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)
    logging.info(f'## export_variance_billing_list_view db_config {db_config}')
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Export Variance Billing")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    col_sort = data.get("col_sort", "")
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None


    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    try:
        columns_to_sum = [
            "prev_mrc",
            "mrc",
            "diff_mrc",
            "prev_nrc_usage",
            "nrc_usage",
            "diff_nrc_usage",
            "prev_nrc",
            "nrc",
            "diff_nrc",
        ]
        sum_clauses = ", ".join([f"SUM({col}) AS {col}" for col in columns_to_sum])
        total_count_query = f"""
            SELECT COUNT(id) AS total_count,
            {sum_clauses}
            FROM vw_export_variance_billing_report
            WHERE tenant_id = %s 
            AND (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date)
                <> date_trunc('month', bill_reversed_date)
            ) 
        """
        params = [tenant_id]

        total_count_df = killbill_database.execute_query(
            total_count_query, params=params
        )
        logging.info(f"total_count_df------{total_count_df}")
        # total_count = int(total_count_result["total_count"].iloc[0])

        if not total_count_df.empty:
            row = total_count_df.iloc[0].to_dict()
            total_count = int(row.get("total_count") or 0)
            summary = {col: round(row.get(col, 0) or 0, 2) for col in columns_to_sum}
        else:
            total_count = 0
            summary = {col: 0.00 for col in columns_to_sum}
        logging.info(f"summary------{summary}")
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"modified_date": "desc"}
        )
        order_by_clause = ", ".join(
            [f"{col} {direction}" for col, direction in order.items()]
        )

        account_details_query = f"""
            SELECT account_number, customer_name, status, prev_mrc, mrc, diff_mrc,
                prev_nrc_usage, nrc_usage, diff_nrc_usage, nrc, prev_nrc, diff_nrc
            FROM vw_export_variance_billing_report
            WHERE tenant_id = %s AND (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date)
                <> date_trunc('month', bill_reversed_date)
            ) 
        """
        params = [tenant_id]

        account_details_query += f"""
            ORDER BY {order_by_clause}
            LIMIT %s OFFSET %s
        """
        params.extend([limit, offset])

        account_details = killbill_database.execute_query(
            account_details_query, params=params
        ).to_dict(orient="records")

        pages_data = {"start": start, "end": end, "total": total_count}

        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        # for row in account_details:
        #     for col in columns_to_sum:
        #         if col in row:
        #             value = row[col]
        #             if isinstance(value, (int, float)):
        #                 row[col] = f"{value:.2f}"
        #             else:
        #                 # if it's None or garbage, default to 0.00
        #                 row[col] = "0.00"
        for row in account_details:
            for col in columns_to_sum:
                if col in row:
                    row[col] = format_amount(row.get(col, 0))
        data_dict_all = {"reports_data": serialize_data(account_details)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": summary,
        }
        end_time = time.time()
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Export Cycle Date list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_variance_billing_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response



def export_variance_billing_list_view_30_12_2025(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Export Variance Billing")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    col_sort = data.get("col_sort", "")
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    try:
        columns_to_sum = [
            "prev_mrc",
            "mrc",
            "diff_mrc",
            "prev_nrc_usage",
            "nrc_usage",
            "diff_nrc_usage",
            "prev_nrc",
            "nrc",
            "diff_nrc",
        ]
        sum_clauses = ", ".join([f"SUM({col}) AS {col}" for col in columns_to_sum])
        total_count_query = f"""
            SELECT COUNT(id) AS total_count,
            {sum_clauses}
            FROM vw_export_variance_billing_report 
            WHERE tenant_id = %s
        """
        total_count_df = killbill_database.execute_query(
            total_count_query, params=[tenant_id]
        )
        logging.info(f"total_count_df------{total_count_df}")
        # total_count = int(total_count_result["total_count"].iloc[0])

        if not total_count_df.empty:
            row = total_count_df.iloc[0].to_dict()
            total_count = int(row.get("total_count") or 0)
            summary = {col: round(row.get(col, 0) or 0, 2) for col in columns_to_sum}
        else:
            total_count = 0
            summary = {col: 0.00 for col in columns_to_sum}
        logging.info(f"summary------{summary}")
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"modified_date": "desc"}
        )
        order_by_clause = ", ".join(
            [f"{col} {direction}" for col, direction in order.items()]
        )

        account_details_query = f"""
            SELECT account_number, customer_name, status, prev_mrc, mrc, diff_mrc, prev_nrc_usage, nrc_usage, diff_nrc_usage, nrc,prev_nrc,diff_nrc 
            FROM vw_export_variance_billing_report 
            WHERE tenant_id = %s 
            ORDER BY {order_by_clause}
            LIMIT %s OFFSET %s
        """
        account_details = killbill_database.execute_query(
            account_details_query, params=[tenant_id, limit, offset]
        ).to_dict(orient="records")

        pages_data = {"start": start, "end": end, "total": total_count}

        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        for row in account_details:
            for col in columns_to_sum:
                if col in row:
                    value = row[col]
                    if isinstance(value, (int, float)):
                        row[col] = f"{value:.2f}"
                    else:
                        # if it's None or garbage, default to 0.00
                        row[col] = "0.00"

        data_dict_all = {"reports_data": serialize_data(account_details)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": summary,
        }
        end_time = time.time()
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Export Cycle Date list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "export_variance_billing_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response

def export_export_variance_billing(data):
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id")
    role_name = data.get("role_name", "")
    mode = os.getenv("ENV", "UAT")

    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1


    # ---------- Timezone ----------
    tz_df = common_utils_database.execute_query(
        "SELECT time_zone FROM tenant WHERE tenant_name = %s",
        params=[tenant_name],
    )

    if tz_df.empty or not tz_df.iloc[0]["time_zone"]:
        raise ValueError("No valid timezone found for tenant")

    tenant_time_zone = tz_df.iloc[0]["time_zone"]
    if "Asia" in tenant_time_zone:
        tenant_time_zone = tenant_time_zone.split()[-1]

    try:
        # ---------- Query ----------
        query = """
            SELECT
                account_number AS customer_id,
                customer_name,
                status,
                prev_mrc AS prevmrc,
                mrc AS currmrc,
                diff_mrc AS netmrc,
                prev_nrc_usage AS prevnrcusage,
                nrc_usage AS currnrcusage,
                diff_nrc_usage AS netnrcusage,
                prev_nrc AS prevnrc,
                nrc AS currnrc,
                diff_nrc AS netnrc
            FROM vw_export_variance_billing_report
            WHERE tenant_id = %s AND (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date)
                <> date_trunc('month', bill_reversed_date)
            )
        """
        params = [tenant_id]

        df = killbill_database.execute_query(query, params=params)
        records = df.to_dict(orient="records")
        records = convert_timestamp(records, tenant_time_zone)

        df = pd.DataFrame(records).fillna("")

        # ---------- Numeric Formatting ----------
        numeric_cols = [
            "prevmrc",
            "currmrc",
            "netmrc",
            "prevnrcusage",
            "currnrcusage",
            "netnrcusage",
            "prevnrc",
            "currnrc",
            "netnrc",
        ]

        for col in numeric_cols:
            if col in df.columns:
                df[col] = (
                    pd.to_numeric(df[col], errors="coerce")
                    .fillna(0)
                    .apply(format_amount)
                )

        data["dfs"] = {"Export Variance Billing": df}
        data["module_name"] = "Export Variance Billing"

        return export_to_s3_bucket_(data)

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")

        database.log_error_to_db(
            {
                "service_name": "export_export_variance_billing",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "error_log_table",
        )

        return {
            "flag": False,
            "message": "Something went wrong fetching Export Variance Billing",
            "data": {},
        }


def altaworx_billing_report_by_day_report_list_view_back_08_09(data):
    """
    Retrieves and formats billed through date report data with pagination support.

    Args:
        data (dict): Request data containing pagination, sorting, and filter parameters

    Returns:
        dict: Response containing report data, headers, pagination info, and status
    """

    # Initialize database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # Extract request parameters with defaults
    module_name = data.get("module_name", "Altaworx Billing Report By Day")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    date_range = data.get("date_range", {})
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")

    # Extract pagination parameters
    pagination = data.get("mod_pages", {})
    start = pagination.get("start", 0)
    end = pagination.get("end", 100)
    limit = end - start
    offset = start

    # Extract sorting parameters
    col_sort = data.get("col_sort", "")

    # Handle tenant ID validation - default to 1 if empty or 212
    environment_mode = os.getenv("ENV", "UAT")
    if environment_mode == "UAT":
        if tenant_id in [212, "212"]:
            tenant_id = 1
            tenant_name = "Altaworx"

    tenant_name = data.get("tenant_name", "")
    try:
        # Get total count for pagination
        total_count_query = (
            "SELECT count(*) FROM altaworx_billing_report_by_day WHERE tenant_id = %s"
        )
        if start_date:
            total_count_query += f" and date BETWEEN '{start_date}' AND '{start_date}';"
        total_count_df = killbill_database.execute_query(
            total_count_query, params=[tenant_id]
        )
        total_count = int(total_count_df.iloc[0, 0])

        # Prepare pagination metadata
        pages_data = {"start": start, "end": end, "total": total_count}

        # Process sorting parameters - convert to lowercase for consistency
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"raw_date": "desc"}
        )

        # Fetch paginated report data
        # Note: ORDER BY clause should be added based on the order dictionary
        report_data_query = """
            SELECT * FROM altaworx_billing_report_by_day 
            WHERE tenant_id = %s"""
        if start_date:
            report_data_query += (
                f" AND raw_date BETWEEN '{start_date}' AND '{end_date}' "
            )
        if order:
            order_clause = ", ".join(
                [f"{col} {direction.upper()}" for col, direction in order.items()]
            )
            report_data_query += f" ORDER BY {order_clause} "
        report_data_query += " LIMIT %s OFFSET %s;"

        report_data_df = killbill_database.execute_query(
            report_data_query, params=[tenant_id, limit, offset]
        )

        # Convert DataFrame to list of dictionaries for JSON serialization
        report_records = report_data_df.to_dict(orient="records")

        # Get header mappings for the report display
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        # Prepare response data structure
        response_data = {"reports_data": serialize_data(report_records)}

        print(
            f"###altaworx_billing_report_by_day_report_list_view Response data prepared: {response_data}"
        )

        # Build success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": response_data,
            "header_map": header_map,
            "pages": pages_data,
        }

        return response

    except Exception as e:
        # Log the exception for debugging
        logging.error(
            f"###altaworx_billing_report_by_day_report_list_view Exception in altaworx_billing_report_by_day_report_list_view: {e}"
        )

        # Prepare error response
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Altaworx Billing Report By Day",
            "data": {},
        }

        # Log error details to database for monitoring
        error_data = {
            "service_name": "altaworx_billing_report_by_day_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }

        database.log_error_to_db(error_data, "error_log_table")

        return error_response


def altaworx_billing_report_by_day_report_export_5_1_2026(data):
    """
    Exports billed through date report data to S3 bucket in Excel format.

    Args:
        data (dict): Request data containing tenant information and export parameters

    Returns:
        dict: Response from S3 export function or error response
    """

    try:
        # Initialize database connections
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        start_date = data.get("start_date", "")
        end_date = data.get("end_date", "")
        col_sort = data.get("col_sort", "")
        tenant_db_name = data.get("db_name", "")
        tenant_db_conn = DB(tenant_db_name, **db_config)

        role_name = data.get("role_name", "")
        username = data.get("username", "")


        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "")
        # Handle environment-specific tenant mapping
        environment_mode = os.getenv("ENV", "UAT")
        if environment_mode == "UAT":
            # Map test tenant to production tenant for UAT environment
            if tenant_name == "Altaworx Test":
                tenant_name = "Altaworx"
                tenant_id = 1


        # Query to retrieve billed through date report data
        # Ordered by modified_date descending to get latest records first
        if role_name in ("Super Admin", "Partner Admin"):
            export_data_query = """
                SELECT total_mrc_billed,total_nrc_billed,total_network_access_tax_billed,
                    total_admin_recovery_tax_billed,total_other_tax_billed,
                    total_payments,total_billed_amount,date
                FROM altaworx_billing_report_by_day
                WHERE tenant_id = %s
            """
            query_params = [tenant_id]
        else:
            export_data_query = """
                SELECT total_mrc_billed,total_nrc_billed,total_network_access_tax_billed,
                    total_admin_recovery_tax_billed,total_other_tax_billed,
                    total_payments,total_billed_amount,date
                FROM altaworx_billing_report_by_day_fn(%s)
            """
            query_params = [customer_profile_ids]
        if start_date and end_date:
            export_data_query += " AND raw_date BETWEEN %s AND %s"
            query_params.extend([start_date, end_date])
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            direction = order[order_by].upper()
            export_data_query += f" ORDER BY {order_by} {direction}"
        else:
            export_data_query += " ORDER BY raw_date DESC"

        # Execute query and get DataFrame
        report_dataframe = killbill_database.execute_query(
            export_data_query, params=query_params
        )

        # Convert DataFrame to dictionary format for processing
        report_records = report_dataframe.to_dict(orient="records")

        # Create DataFrame from records and handle null values
        processed_dataframe = pd.DataFrame(report_records)
        processed_dataframe = processed_dataframe.fillna("")

        # Prepare data structure for S3 export
        # The key will be used as the sheet name in the Excel file
        columns_to_format = [
            "total_mrc_billed",
            "total_nrc_billed",
            "total_network_access_tax_billed",
            "total_admin_recovery_tax_billed",
            "total_other_tax_billed",
            "total_payments",
            "total_billed_amount",
        ]
        for col in columns_to_format:
            if col in processed_dataframe.columns:
                processed_dataframe[col] = processed_dataframe[col].apply(
                    lambda x: (
                        f"{float(x):.2f}"
                        if str(x).replace(".", "", 1).isdigit()
                        else "0.00"
                    )
                )
        data["dfs"] = {"Billing report by day with OCC": processed_dataframe}
        # Export processed data to S3 bucket
        return export_to_s3_bucket_(data)

    except Exception as e:
        # Log the exception for debugging purposes
        logging.error(
            f"###altaworx_billing_report_by_day_report_export Exception in altaworx_billing_report_by_day_report_export: {e}"
        )

        # Prepare error response for client
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billing report by day with OCC",
            "data": {},
        }

        # Prepare error details for database logging
        error_details = {
            "service_name": "altaworx_billing_report_by_day_report_export",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }

        # Log error to database for monitoring and troubleshooting
        database.log_error_to_db(error_details, "error_log_table")

        return error_response


def altaworx_billing_report_by_day_report_export(data):
    """
    Exports billed through date report data to S3 bucket in Excel format.

    Args:
        data (dict): Request data containing tenant information and export parameters

    Returns:
        dict: Response from S3 export function or error response
    """

    try:
        # Initialize database connections
        database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        billing_db_name = data.get("billing_db_name", "")
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        start_date = data.get("start_date", "")
        end_date = data.get("end_date", "")
        col_sort = data.get("col_sort", "")
        tenant_db_name = data.get("db_name", "")
        tenant_db_conn = DB(tenant_db_name, **db_config)

        role_name = data.get("role_name", "")
        username = data.get("username", "")


        tenant_name = data.get("tenant_name", "")
        tenant_id = data.get("tenant_id", "")
        # Handle environment-specific tenant mapping
        environment_mode = os.getenv("ENV", "UAT")
        if environment_mode == "UAT":
            # Map test tenant to production tenant for UAT environment
            if tenant_name == "Altaworx Test":
                tenant_name = "Altaworx"
                tenant_id = 1

        # ----------------------------------------
        # Customer restriction (NON-ADMIN USERS)
        # ----------------------------------------
        customer_profile_ids = None

        if role_name not in ("Super Admin", "Partner Admin"):

            customer_names = None

            # Read customers from db_config
            config_customers = db_config.get("customers")
            if config_customers:
                customer_names = normalize_customers_from_config(config_customers)

            # If no customers → export empty file
            if not customer_names:
                data["dfs"] = {
                    "Billing report by day with OCC": pd.DataFrame()
                }
                return export_to_s3_bucket_(data)

            # Fetch customer_profile_ids
            customer_profiles = killbill_database.get_data(
                "customer_profiles",
                {
                    "tenant_id": tenant_id,
                    "customer_name": customer_names
                },
                ["id"]
            )["id"].to_list()

            customer_profile_ids = list(set(customer_profiles))

            # If no profile IDs → export empty file
            if not customer_profile_ids:
                data["dfs"] = {
                    "Billing report by day with OCC": pd.DataFrame()
                }
                return export_to_s3_bucket_(data)

        # Query to retrieve billed through date report data
        # Ordered by modified_date descending to get latest records first
        if role_name in ("Super Admin", "Partner Admin"):
            export_data_query = """
                SELECT total_mrc_billed,total_nrc_billed,total_network_access_tax_billed,
                    total_admin_recovery_tax_billed,total_other_tax_billed,
                    total_payments,total_billed_amount,date
                FROM altaworx_billing_report_by_day
                WHERE tenant_id = %s AND (
                    bill_reversed_date IS NULL
                    OR date_trunc('month', created_date)
                    <> date_trunc('month', bill_reversed_date)
                )
            """
            query_params = [tenant_id]
        else:
            export_data_query = """
                SELECT total_mrc_billed,total_nrc_billed,total_network_access_tax_billed,
                    total_admin_recovery_tax_billed,total_other_tax_billed,
                    total_payments,total_billed_amount,date
                FROM altaworx_billing_report_by_day_fn(%s) where (
                    bill_reversed_date IS NULL
                    OR date_trunc('month', created_date)
                    <> date_trunc('month', bill_reversed_date)
                ) 
            """
            query_params = [customer_profile_ids]
        if start_date and end_date:
            export_data_query += " AND raw_date BETWEEN %s AND %s"
            query_params.extend([start_date, end_date])
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            direction = order[order_by].upper()
            export_data_query += f" ORDER BY {order_by} {direction}"
        else:
            export_data_query += " ORDER BY raw_date DESC"

        # Execute query and get DataFrame
        report_dataframe = killbill_database.execute_query(
            export_data_query, params=query_params
        )

        # Convert DataFrame to dictionary format for processing
        report_records = report_dataframe.to_dict(orient="records")

        # Create DataFrame from records and handle null values
        processed_dataframe = pd.DataFrame(report_records)
        processed_dataframe = processed_dataframe.fillna("")

        # Prepare data structure for S3 export
        # The key will be used as the sheet name in the Excel file
        columns_to_format = [
            "total_mrc_billed",
            "total_nrc_billed",
            "total_network_access_tax_billed",
            "total_admin_recovery_tax_billed",
            "total_other_tax_billed",
            "total_payments",
            "total_billed_amount",
        ]
        for col in columns_to_format:
            if col in processed_dataframe.columns:
                processed_dataframe[col] = processed_dataframe[col].apply(format_amount)
        data["dfs"] = {"Billing report by day with OCC": processed_dataframe}
        # Export processed data to S3 bucket
        return export_to_s3_bucket_(data)

    except Exception as e:
        # Log the exception for debugging purposes
        logging.error(
            f"###altaworx_billing_report_by_day_report_export Exception in altaworx_billing_report_by_day_report_export: {e}"
        )

        # Prepare error response for client
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billing report by day with OCC",
            "data": {},
        }

        # Prepare error details for database logging
        error_details = {
            "service_name": "altaworx_billing_report_by_day_report_export",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }

        # Log error to database for monitoring and troubleshooting
        database.log_error_to_db(error_details, "error_log_table")

        return error_response


def total_mrc_bill_profiles_list_view_back_09_09(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    module_name = data.get("module_name", "Total MRC For Bill Profiles")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    start = data.get("mod_pages", {}).get("start", 0)
    end = data.get("mod_pages", {}).get("end", 100)
    col_sort = data.get("col_sort", "")
    limit = end - start
    offset = start
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    try:
        # get sub_tenant_ids from tenant table
        sub_tenant_ids = common_utils_database.get_data(
            "tenant", {"parent_tenant_id": tenant_id}, ["id"]
        )["id"].to_list()
        logging.info(f"sub_tenant_ids------{sub_tenant_ids}")

        tenant_ids = sub_tenant_ids if sub_tenant_ids else [tenant_id]
        placeholders = ", ".join(["%s"] * len(tenant_ids))

        total_count_query = f"""
            SELECT COUNT(bill_id) AS total_count 
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id IN ({placeholders})
        """
        total_count_result = killbill_database.execute_query(
            total_count_query, params=[tenant_ids]
        )
        total_count = int(total_count_result["total_count"].iloc[0])

        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"modified_date": "desc"}
        )
        order_by_clause = ", ".join(
            [f"{col} {direction}" for col, direction in order.items()]
        )

        account_details_query = f"""
            SELECT * 
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id IN ({placeholders})
            ORDER BY {order_by_clause}
            LIMIT %s OFFSET %s
        """
        params = tenant_ids + [limit, offset]
        account_details = killbill_database.execute_query(
            account_details_query, params=params
        ).to_dict(orient="records")

        pages_data = {"start": start, "end": end, "total": total_count}

        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        data_dict_all = {"reports_data": serialize_data(account_details)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
        }
        end_time = time.time()
        return response
    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Total MRC for Bill Profiles list",
            "data": {},  # Return empty dictionary on error
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "total_mrc_bill_profiles_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": message,
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return response


def altaworx_billing_report_by_day_report_list_view_back(data):
    """
    Retrieves and formats billed through date report data with pagination support.

    Args:
        data (dict): Request data containing pagination, sorting, and filter parameters

    Returns:
        dict: Response containing report data, headers, pagination info, and status
    """

    # Initialize database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    # Extract request parameters with defaults
    module_name = data.get("module_name", "Billing report by day with OCC")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    date_range = data.get("date_range", {})
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")

    # Extract pagination parameters
    pagination = data.get("mod_pages", {})
    # start = pagination.get('start', 0)
    # end = pagination.get('end', 100)
    start = pagination.get("start", None)
    end = pagination.get("end", None)
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None

    # Extract sorting parameters
    col_sort = data.get("col_sort", "")

    # Handle tenant ID validation - default to 1 if empty or 212
    environment_mode = os.getenv("ENV", "UAT")
    if environment_mode == "UAT":
        if tenant_id in [212, "212"]:
            tenant_id = 1
            tenant_name = "Altaworx"

    tenant_name = data.get("tenant_name", "")
    try:
        # Get total count for pagination
        total_count_query = (
            "SELECT count(*) FROM altaworx_billing_report_by_day WHERE tenant_id = %s"
        )
        if start_date and end_date:
            total_count_query += (
                f" and raw_date BETWEEN '{start_date}' AND '{end_date}';"
            )
        total_count_df = killbill_database.execute_query(
            total_count_query, params=[tenant_id]
        )
        total_count = int(total_count_df.iloc[0, 0])

        # Prepare pagination metadata
        pages_data = {"start": start, "end": end, "total": total_count}

        # Process sorting parameters - convert to lowercase for consistency
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"raw_date": "desc"}
        )

        # Fetch paginated report data
        # Note: ORDER BY clause should be added based on the order dictionary
        report_data_query = """
            SELECT total_mrc_billed, total_nrc_billed, total_network_access_tax_billed, total_admin_recovery_tax_billed, total_other_tax_billed, total_payments, total_billed_amount, date FROM altaworx_billing_report_by_day 
            WHERE tenant_id = %s"""
        if start_date and end_date:
            report_data_query += (
                f" AND raw_date BETWEEN '{start_date}' AND '{end_date}' "
            )
        if order:
            order_clause = ", ".join(
                [f"{col} {direction.upper()}" for col, direction in order.items()]
            )
            report_data_query += f" ORDER BY {order_clause} "
        report_data_query += " LIMIT %s OFFSET %s;"

        report_data_df = killbill_database.execute_query(
            report_data_query, params=[tenant_id, limit, offset]
        )

        # Convert DataFrame to list of dictionaries for JSON serialization
        report_records = report_data_df.to_dict(orient="records")

        # Get header mappings for the report display
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        # Prepare response data structure
        response_data = {"reports_data": serialize_data(report_records)}

        print(
            f"###altaworx_billing_report_by_day_report_list_view Response data prepared: {response_data}"
        )

        # Build success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": response_data,
            "header_map": header_map,
            "pages": pages_data,
        }

        if data.get("z_access_token", ""):
            return {"data": response_data}
        else:
            return response

    except Exception as e:
        # Log the exception for debugging
        logging.error(
            f"###altaworx_billing_report_by_day_report_list_view Exception in altaworx_billing_report_by_day_report_list_view: {e}"
        )

        # Prepare error response
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billing report by day with OCC",
            "data": {},
        }

        # Log error details to database for monitoring
        error_data = {
            "service_name": "altaworx_billing_report_by_day_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }

        database.log_error_to_db(error_data, "error_log_table")

        return error_response


def altaworx_billing_report_by_day_report_list_view_31_12_2025(data):
    """
    Retrieves and formats billed through date report data with pagination support.

    Args:
        data (dict): Request data containing pagination, sorting, and filter parameters

    Returns:
        dict: Response containing report data, headers, pagination info, and status
    """

    # Initialize database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    # Extract request parameters with defaults
    module_name = data.get("module_name", "Billing report by day with OCC")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    date_range = data.get("date_range", {})
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")

    # Extract pagination parameters
    pagination = data.get("mod_pages", {})
    # start = pagination.get('start', 0)
    # end = pagination.get('end', 100)
    start = pagination.get("start", None)
    end = pagination.get("end", None)
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None

    # Extract sorting parameters
    col_sort = data.get("col_sort", "")

    # Handle tenant ID validation - default to 1 if empty or 212
    environment_mode = os.getenv("ENV", "UAT")
    if environment_mode == "UAT":
        if tenant_id in [212, "212"]:
            tenant_id = 1
            tenant_name = "Altaworx"

    tenant_name = data.get("tenant_name", "")
    try:
        # Get total count for pagination
        total_count_query = (
            "SELECT * FROM altaworx_billing_report_by_day WHERE tenant_id = %s"
        )
        if start_date and end_date:
            total_count_query += (
                f" and raw_date BETWEEN '{start_date}' AND '{end_date}';"
            )
        total_count_df = killbill_database.execute_query(
            total_count_query, params=[tenant_id]
        )
        total_count_df = total_count_df.to_dict(orient="records")
        total_count = len(total_count_df)
        sum_total_mrc_billed = 0
        sum_total_nrc_billed = 0
        sum_total_network_access_tax_billed = 0
        sum_total_admin_recovery_tax_billed = 0
        sum_total_other_tax_billed = 0
        sum_total_payments = 0
        sum_total_billed_amount = 0
        for record in total_count_df:
            sum_total_mrc_billed += float(record.get("total_mrc_billed", 0) or 0)
            sum_total_nrc_billed += float(record.get("total_nrc_billed", 0) or 0)
            sum_total_network_access_tax_billed += float(
                record.get("total_network_access_tax_billed", 0) or 0
            )
            sum_total_admin_recovery_tax_billed += float(
                record.get("total_admin_recovery_tax_billed", 0) or 0
            )
            sum_total_other_tax_billed += float(
                record.get("total_other_tax_billed", 0) or 0
            )
            sum_total_payments += float(record.get("total_payments", 0) or 0)
            sum_total_billed_amount += float(record.get("total_billed_amount", 0) or 0)

        # Prepare pagination metadata
        pages_data = {"start": start, "end": end, "total": total_count}

        # Process sorting parameters - convert to lowercase for consistency
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"raw_date": "desc"}
        )

        # Fetch paginated report data
        # Note: ORDER BY clause should be added based on the order dictionary
        report_data_query = """
            SELECT total_mrc_billed, total_nrc_billed, total_network_access_tax_billed, total_admin_recovery_tax_billed, total_other_tax_billed, total_payments, total_billed_amount, date FROM altaworx_billing_report_by_day 
            WHERE tenant_id = %s"""
        if start_date and end_date:
            report_data_query += (
                f" AND raw_date BETWEEN '{start_date}' AND '{end_date}' "
            )
        if order:
            order_clause = ", ".join(
                [f"{col} {direction.upper()}" for col, direction in order.items()]
            )
            report_data_query += f" ORDER BY {order_clause} "
        report_data_query += " LIMIT %s OFFSET %s;"

        report_data_df = killbill_database.execute_query(
            report_data_query, params=[tenant_id, limit, offset]
        )

        # Convert DataFrame to list of dictionaries for JSON serialization
        report_records = report_data_df.to_dict(orient="records")

        columns_to_format = [
            "total_mrc_billed",
            "total_nrc_billed",
            "total_network_access_tax_billed",
            "total_admin_recovery_tax_billed",
            "total_other_tax_billed",
            "total_payments",
            "total_billed_amount",
        ]
        for row in report_records:
            for col in columns_to_format:
                if col in row:
                    value = row[col]
                    if isinstance(value, (int, float)):
                        row[col] = f"{value:.2f}"
                    else:
                        # if it's None or garbage, default to 0.00
                        row[col] = "0.00"

        # Get header mappings for the report display
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        # Prepare response data structure
        response_data = {"reports_data": serialize_data(report_records)}

        print(
            f"###altaworx_billing_report_by_day_report_list_view Response data prepared: {response_data}"
        )

        # Build success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": response_data,
            "header_map": header_map,
            "pages": pages_data,
            "summary": {
                "total_mrc_billed": round(sum_total_mrc_billed, 2),
                "total_nrc_billed": round(sum_total_nrc_billed, 2),
                "total_network_access_tax_billed": round(
                    sum_total_network_access_tax_billed, 2
                ),
                "total_admin_recovery_tax_billed": round(
                    sum_total_admin_recovery_tax_billed, 2
                ),
                "total_other_tax_billed": round(sum_total_other_tax_billed, 2),
                "total_payments": round(sum_total_payments, 2),
                "total_billed_amount": round(sum_total_billed_amount, 2),
            },
        }

        if data.get("z_access_token", ""):
            return {"data": response_data}
        else:
            return response

    except Exception as e:
        # Log the exception for debugging
        logging.error(
            f"###altaworx_billing_report_by_day_report_list_view Exception in altaworx_billing_report_by_day_report_list_view: {e}"
        )

        # Prepare error response
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billing report by day with OCC",
            "data": {},
        }

        # Log error details to database for monitoring
        error_data = {
            "service_name": "altaworx_billing_report_by_day_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }

        database.log_error_to_db(error_data, "error_log_table")

        return error_response

def altaworx_billing_report_by_day_report_list_view(data):
    """
    Retrieves and formats billed through date report data with pagination support.

    Args:
        data (dict): Request data containing pagination, sorting, and filter parameters

    Returns:
        dict: Response containing report data, headers, pagination info, and status
    """
    logging.info(f'## altaworx_billing_report_by_day_report_list_view fucntino called')
    # Initialize database connections
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name = data.get("db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)
    data = get_tenant_details_from_token(common_utils_database, data)

    # Extract request parameters with defaults
    module_name = data.get("module_name", "Billing report by day with OCC")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    date_range = data.get("date_range", {})
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")

    # Extract pagination parameters
    pagination = data.get("mod_pages", {})
    # start = pagination.get('start', 0)
    # end = pagination.get('end', 100)
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None
    
    # ----------------------------------------
    # Customer restriction (USING db_config)
    # ----------------------------------------
    customer_profile_ids = None

    if role_name not in ("Super Admin", "Partner Admin"):

        customer_names = None

        # Read customers from db_config
        config_customers = db_config.get("customers")
        if config_customers:
            customer_names = normalize_customers_from_config(config_customers)

        # If NO customers → return empty data
        if not customer_names:
            header_map = get_headers_mapping(
                killbill_database, [module_name], role_name, "", "", "", "", data
            )
            return {
                "flag": True,
                "message": "No billing report data found",
                "data": {"altaworx_billing_report": []},
                "header_map": header_map,
                "pages": {"start": start, "end": end, "total": 0},
                "summary": {},
            }

        # Fetch customer_profile_ids
        logging.info(
            f"## altaworx_billing_report_by_day_report_list_view customer_names {customer_names}"
        )

        customer_profiles = killbill_database.get_data(
            "customer_profiles",
            {
                "tenant_id": tenant_id,
                "customer_name": customer_names
            },
            ["id"]
        )["id"].to_list()

        customer_profile_ids = list(set(customer_profiles))

        # If NO profile IDs → return empty
        if not customer_profile_ids:
            header_map = get_headers_mapping(
                killbill_database, [module_name], role_name, "", "", "", "", data
            )
            return {
                "flag": True,
                "message": "No billing report data found",
                "data": {"altaworx_billing_report": []},
                "header_map": header_map,
                "pages": {"start": start, "end": end, "total": 0},
                "summary": {},
            }

    # Extract sorting parameters
    col_sort = data.get("col_sort", "")

    # Handle tenant ID validation - default to 1 if empty or 212
    environment_mode = os.getenv("ENV", "UAT")
    if environment_mode == "UAT":
        if tenant_id in [212, "212"]:
            tenant_id = 1
            tenant_name = "Altaworx"

    tenant_name = data.get("tenant_name", "")
    try:
        # Get total count for pagination
        if role_name in ("Super Admin", "Partner Admin"):
            total_count_query = """
                SELECT *
                FROM altaworx_billing_report_by_day
                WHERE tenant_id = %s AND (
                    bill_reversed_date IS NULL
                    OR date_trunc('month', created_date)
                    <> date_trunc('month', bill_reversed_date)
                )
            """
            total_count_params = [tenant_id]
        else:
            total_count_query = """
                SELECT *
                FROM altaworx_billing_report_by_day_fn(%s) where (
                    bill_reversed_date IS NULL
                    OR date_trunc('month', created_date)
                    <> date_trunc('month', bill_reversed_date)
                )
            """
            total_count_params = [customer_profile_ids]
        logging.info(f'## altaworx_billing_report_by_day_report_list_view total_count_params {total_count_params}')
        if start_date and end_date:
            total_count_query += (
                f" AND raw_date BETWEEN '{start_date}' AND '{end_date}'"
            )

        total_count_df = killbill_database.execute_query(
            total_count_query,
            params=total_count_params
        )
        total_count_df = total_count_df.to_dict(orient="records")
        total_count = len(total_count_df)
        logging.info(f'## altaworx_billing_report_by_day_report_list_view total_count {total_count}')
        sum_total_mrc_billed = 0
        sum_total_nrc_billed = 0
        sum_total_network_access_tax_billed = 0
        sum_total_admin_recovery_tax_billed = 0
        sum_total_other_tax_billed = 0
        sum_total_payments = 0
        sum_total_billed_amount = 0
        for record in total_count_df:
            sum_total_mrc_billed += float(record.get("total_mrc_billed", 0) or 0)
            sum_total_nrc_billed += float(record.get("total_nrc_billed", 0) or 0)
            sum_total_network_access_tax_billed += float(
                record.get("total_network_access_tax_billed", 0) or 0
            )
            sum_total_admin_recovery_tax_billed += float(
                record.get("total_admin_recovery_tax_billed", 0) or 0
            )
            sum_total_other_tax_billed += float(
                record.get("total_other_tax_billed", 0) or 0
            )
            sum_total_payments += float(record.get("total_payments", 0) or 0)
            sum_total_billed_amount += float(record.get("total_billed_amount", 0) or 0)

        # Prepare pagination metadata
        pages_data = {"start": start, "end": end, "total": total_count}

        # Process sorting parameters - convert to lowercase for consistency
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"raw_date": "desc"}
        )

        # Fetch paginated report data
        # Note: ORDER BY clause should be added based on the order dictionary
        if role_name in ("Super Admin", "Partner Admin"):
            report_data_query = """
                SELECT total_mrc_billed, total_nrc_billed,
                    total_network_access_tax_billed,
                    total_admin_recovery_tax_billed,
                    total_other_tax_billed,
                    total_payments,
                    total_billed_amount,
                    date
                FROM altaworx_billing_report_by_day
                WHERE tenant_id = %s  AND (
                    bill_reversed_date IS NULL
                    OR date_trunc('month', created_date)
                    <> date_trunc('month', bill_reversed_date)
                ) 
            """
            report_params = [tenant_id]
        else:
            report_data_query = """
                SELECT total_mrc_billed, total_nrc_billed,
                    total_network_access_tax_billed,
                    total_admin_recovery_tax_billed,
                    total_other_tax_billed,
                    total_payments,
                    total_billed_amount,
                    date
                FROM altaworx_billing_report_by_day_fn(%s) where (
                    bill_reversed_date IS NULL
                    OR date_trunc('month', created_date)
                    <> date_trunc('month', bill_reversed_date)
                ) 
            """
            report_params = [customer_profile_ids]
        
        if start_date and end_date:
            report_data_query += (
                f" AND raw_date BETWEEN '{start_date}' AND '{end_date}' "
            )
        if order:
            order_clause = ", ".join(
                [f"{col} {direction.upper()}" for col, direction in order.items()]
            )
            report_data_query += f" ORDER BY {order_clause} "

        report_data_query += " LIMIT %s OFFSET %s"
        report_params.extend([limit, offset])
        logging.info(f'## altaworx_billing_report_by_day_report_list_view report_data_query {report_data_query} report_params {report_params}')
        report_data_df = killbill_database.execute_query(
            report_data_query,
            params=report_params
        )

        # Convert DataFrame to list of dictionaries for JSON serialization
        report_records = report_data_df.to_dict(orient="records")

        columns_to_format = [
            "total_mrc_billed",
            "total_nrc_billed",
            "total_network_access_tax_billed",
            "total_admin_recovery_tax_billed",
            "total_other_tax_billed",
            "total_payments",
            "total_billed_amount",
        ]
        # for row in report_records:
        #     for col in columns_to_format:
        #         if col in row:
        #             value = row[col]
        #             if isinstance(value, (int, float)):
        #                 row[col] = f"{value:.2f}"
        #             else:
        #                 # if it's None or garbage, default to 0.00
        #                 row[col] = "0.00"
        for row in report_records:
            for col in columns_to_format:
                if col in row:
                    row[col] = format_amount(row.get(col, 0))
        # Get header mappings for the report display
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        # Prepare response data structure
        response_data = {"reports_data": serialize_data(report_records)}

        print(
            f"###altaworx_billing_report_by_day_report_list_view Response data prepared: {response_data}"
        )

        # Build success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": response_data,
            "header_map": header_map,
            "pages": pages_data,
            "summary": {
                "total_mrc_billed": round(sum_total_mrc_billed, 2),
                "total_nrc_billed": round(sum_total_nrc_billed, 2),
                "total_network_access_tax_billed": round(
                    sum_total_network_access_tax_billed, 2
                ),
                "total_admin_recovery_tax_billed": round(
                    sum_total_admin_recovery_tax_billed, 2
                ),
                "total_other_tax_billed": round(sum_total_other_tax_billed, 2),
                "total_payments": round(sum_total_payments, 2),
                "total_billed_amount": round(sum_total_billed_amount, 2),
            },
        }

        if data.get("z_access_token", ""):
            return {"data": response_data}
        else:
            return response

    except Exception as e:
        # Log the exception for debugging
        logging.error(
            f"###altaworx_billing_report_by_day_report_list_view Exception in altaworx_billing_report_by_day_report_list_view: {e}"
        )

        # Prepare error response
        error_response = {
            "flag": False,
            "message": "Something went wrong fetching Billing report by day with OCC",
            "data": {},
        }

        # Log error details to database for monitoring
        error_data = {
            "service_name": "altaworx_billing_report_by_day_report_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }

        database.log_error_to_db(error_data, "error_log_table")

        return error_response



def export_total_mrc_bill_profiles(data):
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id")
    role_name = data.get("role_name", "")
    mode = os.getenv("ENV", "UAT")

    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    start_date = data.get("start_date")
    end_date = data.get("end_date")
    date_flag = not (start_date == "Invalid Date" or end_date == "Invalid Date")

    if end_date and date_flag:
        end_date = (
            datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        ).strftime("%Y-%m-%d")

    # ---------- Customer Access ----------
    tenant_database = data.get("db_name", "")
    tenant_database_conn = DB(tenant_database, **db_config)

    # ---------- Timezone ----------
    tz_df = common_utils_database.execute_query(
        "SELECT time_zone FROM tenant WHERE tenant_name = %s",
        params=[tenant_name],
    )

    if tz_df.empty or not tz_df.iloc[0]["time_zone"]:
        raise ValueError("No valid timezone found for tenant")

    tenant_time_zone = tz_df.iloc[0]["time_zone"]
    if "Asia" in tenant_time_zone:
        tenant_time_zone = tenant_time_zone.split()[-1]

    try:
        # ---------- Base Query ----------
        query = """
            SELECT
                account_number AS customer_id,
                customer_name,
                sales_person,
                contract_start_date AS contract_signed_date,
                customer_creation_date AS customer_created_date,
                customer_activation_date AS customer_activation_date,
                bill_id AS statement_id,
                bill_generation_date AS statement_created_date,
                due_date_of_this_bill AS due_date,
                mrc,
                usage,
                time_zone
            FROM vw_total_mrc_for_bill_proile_report
            WHERE tenant_id = %s AND (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date)
                <> date_trunc('month', bill_reversed_date)
            )
            AND is_active = TRUE
        """
        params = [tenant_id]


        # ---------- Date Filter ----------
        if start_date and end_date and date_flag:
            query += " AND bill_generation_date BETWEEN %s AND %s"
            params.extend([start_date, end_date])

        query += " ORDER BY bill_generation_date DESC, bill_id DESC"

        df = killbill_database.execute_query(query, params=params)
        records = df.to_dict(orient="records")

        # ---------- Statement ID Formatting ----------
        for row in records:
            # Format MRC
            if row.get("mrc") is not None:
                row["mrc"] = format_amount(row["mrc"])
            # Format Usage
            if row.get("usage") is not None:
                row["usage"] = format_amount(row["usage"])
            if row.get("statement_id") is not None:
                try:
                    row["statement_id"] = f"INV{int(row['statement_id']):04d}"
                except Exception:
                    pass

        records = convert_timestamp(records, tenant_time_zone)
        df = pd.DataFrame(records).fillna("")

        data["dfs"] = {"Total MRC for Sales Person Catapult": df}
        data["module_name"] = "Total MRC for Sales Person: Catapult"

        return export_to_s3_bucket_(data)

    except Exception as e:
        logging.error(f"Exception occurred while preparing response: {e}")

        database.log_error_to_db(
            {
                "service_name": "export_total_mrc_bill_profiles",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "error_log_table",
        )

        return {
            "flag": False,
            "message": "Something went wrong fetching Total MRC For Bill Profiles",
            "data": {},
        }

def total_mrc_bill_profiles_list_view_back(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Total MRC for Sales Person: Catapult")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    col_sort = data.get("col_sort", "")

    # Pagination
    pagination = data.get("mod_pages", {})
    start = pagination.get("start", None)
    end = pagination.get("end", None)
    limit = (end - start) if start or end else None
    offset = start 

    # Handle tenant adjustments for UAT
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    # Date filters
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    date_flag = bool(start_date and end_date)

    if date_flag:
        try:
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error parsing end_date: {e}")

    try:
        # --- COUNT QUERY ---
        total_count_query = """
            SELECT COUNT(bill_id) AS total_count 
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id = %s
        """
        if date_flag:
            total_count_query += f" AND to_date(bill_generation_date, 'MM-DD-YYYY') BETWEEN '{start_date}' AND '{end_date}'"

        total_count_result = killbill_database.execute_query(
            total_count_query, params=(tenant_id,)
        )
        total_count = (
            int(total_count_result["total_count"].iloc[0])
            if not total_count_result.empty
            else 0
        )

        # --- SORTING ---
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"bill_generation_date": "desc"}
        )
        order_by_clause = ", ".join(
            [f"{col} {direction}" for col, direction in order.items()]
        )

        # --- MAIN QUERY ---
        base_query = f"""
            SELECT account_number, customer_name, sales_person, contract_start_date, 
                   customer_creation_date, customer_activation_date, bill_id, 
                   bill_generation_date, due_date_of_this_bill, mrc, usage, time_zone 
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id = %s
        """
        if date_flag:
            base_query += f" AND to_date(bill_generation_date, 'MM-DD-YYYY') BETWEEN '{start_date}' AND '{end_date}'"
        base_query += f" ORDER BY {order_by_clause}"
        if limit is not None and offset is not None:
            base_query += f" LIMIT {limit} OFFSET {offset}"

        account_details = killbill_database.execute_query(
            base_query, params=[tenant_id]
        ).to_dict(orient="records")

        # --- PAGINATION INFO ---
        pages_data = {"start": start, "end": end, "total": total_count}

        # --- HEADERS ---
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        # --- RESPONSE ---
        data_dict_all = {"reports_data": serialize_data(account_details)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
        }

        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.error(f"Exception in total_mrc_bill_profiles_list_view: {e}")
        error_data = {
            "service_name": "total_mrc_bill_profiles_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "message": "Something went wrong fetching Total MRC for Bill Profiles list",
            "data": {},
        }

def total_mrc_bill_profiles_list_view(data):
    # UI Params
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name = data.get("db_name", "")
    start_time = time.time()

    # DB Connection
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    killbill_database = DB(billing_db_name, **db_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Total MRC for Sales Person: Catapult")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    col_sort = data.get("col_sort", "")

    # Pagination
    pagination = data.get("mod_pages", {})
    start = pagination.get("start", None)
    end = pagination.get("end", None)
    limit = (end - start) if start or end else None
    offset = start 

    # Handle tenant adjustments for UAT
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    # Date filters
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    date_flag = bool(start_date and end_date)

    if date_flag:
        try:
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error parsing end_date: {e}")

    try:
        # --- COUNT QUERY ---
        total_count_query = """
            SELECT mrc, usage
            FROM vw_total_mrc_for_bill_proile_report
            WHERE tenant_id = %s AND (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date)
                <> date_trunc('month', bill_reversed_date)
            )
            AND is_active = true
        """
        params = [tenant_id]
        if date_flag:
            total_count_query += f" AND to_date(bill_generation_date, 'MM-DD-YYYY') BETWEEN '{start_date}' AND '{end_date}'"
        total_count_result = killbill_database.execute_query(
            total_count_query, params=params
        )
        if not total_count_result.empty:
            mrc_list = total_count_result["mrc"].to_list()
            usage_list = total_count_result["usage"].to_list()
            total_count = len(mrc_list)
            total_mrc = sum(float(i) for i in mrc_list if i not in ("", None))
            total_usage = sum(float(i) for i in usage_list if i not in ("", None))
        else:
            total_count = 0
            total_mrc = 0.0
            total_usage = 0.0

        # --- SORTING ---
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"bill_generation_date": "desc", "bill_id": "desc"}
        )
        order_by_clause = ", ".join(
            [f"{col} {direction}" for col, direction in order.items()]
        )

        # --- MAIN QUERY ---
        base_query = """
            SELECT account_number, customer_name, sales_person, contract_start_date, 
                customer_creation_date, customer_activation_date, bill_id, 
                bill_generation_date, due_date_of_this_bill, mrc, usage, time_zone 
            FROM vw_total_mrc_for_bill_proile_report
            WHERE tenant_id = %s AND (
                bill_reversed_date IS NULL
                OR date_trunc('month', created_date)
                <> date_trunc('month', bill_reversed_date)
            )
            AND is_active = true
        """
        params = [tenant_id]
        if date_flag:
            base_query += f" AND to_date(bill_generation_date, 'MM-DD-YYYY') BETWEEN '{start_date}' AND '{end_date}'"
        base_query += f" ORDER BY {order_by_clause}"
        if limit is not None and offset is not None:
            base_query += f" LIMIT {limit} OFFSET {offset}"

        account_details = killbill_database.execute_query(
            base_query, params=params
        ).to_dict(orient="records")

        # --- PAGINATION INFO ---
        pages_data = {"start": start, "end": end, "total": total_count}

        # --- HEADERS ---
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        columns_to_format = ["mrc", "usage"]
        for row in account_details:
            # FORMAT BILL ID
            if "bill_id" in row and row["bill_id"] is not None:
                try:
                    row["bill_id"] = f"INV{int(row['bill_id']):04d}"
                except ValueError:
                    pass

            # FORMAT MRC & USAGE SAFELY
            for col in columns_to_format:
                if col in row:
                    # try:
                    #     num_value = float(row[col])
                    #     row[col] = f"{num_value:.2f}"
                    # except (TypeError, ValueError):
                    #     row[col] = "0.00"
                    row[col] = format_amount(row.get(col, 0))

        # --- RESPONSE ---
        data_dict_all = {"reports_data": serialize_data(account_details)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": {"mrc": round(total_mrc, 2), "usage": round(total_usage, 2)},
        }

        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.error(f"Exception in total_mrc_bill_profiles_list_view: {e}")
        error_data = {
            "service_name": "total_mrc_bill_profiles_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "message": "Something went wrong fetching Total MRC for Bill Profiles list",
            "data": {},
        }


def total_mrc_bill_profiles_list_view_30_12_2025(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Total MRC for Sales Person: Catapult")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    col_sort = data.get("col_sort", "")

    # Pagination
    pagination = data.get("mod_pages", {})
    start = pagination.get("start", None)
    end = pagination.get("end", None)
    limit = (end - start) if start or end else None
    offset = start 

    # Handle tenant adjustments for UAT
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    # Date filters
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    date_flag = bool(start_date and end_date)

    if date_flag:
        try:
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error parsing end_date: {e}")

    try:
        # --- COUNT QUERY ---
        total_count_query = """
            SELECT mrc,usage
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id = %s
        """
        if date_flag:
            total_count_query += f" AND to_date(bill_generation_date, 'MM-DD-YYYY') BETWEEN '{start_date}' AND '{end_date}'"

        total_count_result = killbill_database.execute_query(
            total_count_query, params=(tenant_id,)
        )
        if not total_count_result.empty:
            mrc_list = total_count_result["mrc"].to_list()
            usage_list = total_count_result["usage"].to_list()
            total_count = len(mrc_list)
            total_mrc = sum(float(i) for i in mrc_list if i not in ("", None))
            total_usage = sum(float(i) for i in usage_list if i not in ("", None))
        else:
            total_count = 0
            total_mrc = 0.0
            total_usage = 0.0

        # --- SORTING ---
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"bill_generation_date": "desc", "bill_id": "desc"}
        )
        order_by_clause = ", ".join(
            [f"{col} {direction}" for col, direction in order.items()]
        )

        # --- MAIN QUERY ---
        base_query = f"""
            SELECT account_number, customer_name, sales_person, contract_start_date, 
                   customer_creation_date, customer_activation_date, bill_id, 
                   bill_generation_date, due_date_of_this_bill, mrc, usage, time_zone 
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id = %s
        """
        if date_flag:
            base_query += f" AND to_date(bill_generation_date, 'MM-DD-YYYY') BETWEEN '{start_date}' AND '{end_date}'"
        base_query += f" ORDER BY {order_by_clause}"
        if limit is not None and offset is not None:
            base_query += f" LIMIT {limit} OFFSET {offset}"

        account_details = killbill_database.execute_query(
            base_query, params=[tenant_id]
        ).to_dict(orient="records")

        # --- PAGINATION INFO ---
        pages_data = {"start": start, "end": end, "total": total_count}

        # --- HEADERS ---
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        columns_to_format = ["mrc", "usage"]
        for row in account_details:
            # FORMAT BILL ID
            if "bill_id" in row and row["bill_id"] is not None:
                try:
                    row["bill_id"] = f"INV{int(row['bill_id']):04d}"
                except ValueError:
                    pass

            # FORMAT MRC & USAGE SAFELY
            for col in columns_to_format:
                if col in row:
                    try:
                        num_value = float(row[col])
                        row[col] = f"{num_value:.2f}"
                    except (TypeError, ValueError):
                        row[col] = "0.00"

        # --- RESPONSE ---
        data_dict_all = {"reports_data": serialize_data(account_details)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": {"mrc": round(total_mrc, 2), "usage": round(total_usage, 2)},
        }

        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.error(f"Exception in total_mrc_bill_profiles_list_view: {e}")
        error_data = {
            "service_name": "total_mrc_bill_profiles_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "message": "Something went wrong fetching Total MRC for Bill Profiles list",
            "data": {},
        }

def total_mrc_bill_profiles_list_view_24_11_2025(data):
    start_time = time.time()
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    module_name = data.get("module_name", "Total MRC for Sales Person: Catapult")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    col_sort = data.get("col_sort", "")

    # Pagination
    pagination = data.get("mod_pages", {})
    start = pagination.get("start", None)
    end = pagination.get("end", None)
    limit = (end - start) if start or end else None
    offset = start 

    # Handle tenant adjustments for UAT
    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    # Date filters
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    date_flag = bool(start_date and end_date)

    if date_flag:
        try:
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error parsing end_date: {e}")

    try:
        # --- COUNT QUERY ---
        total_count_query = """
            SELECT mrc,usage
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id = %s
        """
        if date_flag:
            total_count_query += f" AND to_date(bill_generation_date, 'MM-DD-YYYY') BETWEEN '{start_date}' AND '{end_date}'"

        total_count_result = killbill_database.execute_query(
            total_count_query, params=(tenant_id,)
        )
        if not total_count_result.empty:
            mrc_list = total_count_result["mrc"].to_list()
            usage_list = total_count_result["usage"].to_list()
            total_count = len(mrc_list)
            total_mrc = sum(float(i) for i in mrc_list if i not in ("", None))
            total_usage = sum(float(i) for i in usage_list if i not in ("", None))
        else:
            total_count = 0
            total_mrc = 0.0
            total_usage = 0.0

        # --- SORTING ---
        order = (
            {k: v.lower() for k, v in col_sort.items()}
            if col_sort
            else {"bill_generation_date": "desc"}
        )
        order_by_clause = ", ".join(
            [f"{col} {direction}" for col, direction in order.items()]
        )

        # --- MAIN QUERY ---
        base_query = f"""
            SELECT account_number, customer_name, sales_person, contract_start_date, 
                   customer_creation_date, customer_activation_date, bill_id, 
                   bill_generation_date, due_date_of_this_bill, mrc, usage, time_zone 
            FROM vw_total_mrc_for_bill_proile_report 
            WHERE tenant_id = %s
        """
        if date_flag:
            base_query += f" AND to_date(bill_generation_date, 'MM-DD-YYYY') BETWEEN '{start_date}' AND '{end_date}'"
        base_query += f" ORDER BY {order_by_clause}"
        if limit is not None and offset is not None:
            base_query += f" LIMIT {limit} OFFSET {offset}"

        account_details = killbill_database.execute_query(
            base_query, params=[tenant_id]
        ).to_dict(orient="records")

        # --- PAGINATION INFO ---
        pages_data = {"start": start, "end": end, "total": total_count}

        # --- HEADERS ---
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )

        columns_to_format = ["mrc", "usage"]
        for row in account_details:
            for col in columns_to_format:
                if col in row:
                    value = row[col]
                    if isinstance(value, (int, float)):
                        row[col] = f"{value:.2f}"
                    else:
                        # if it's None or garbage, default to 0.00
                        row[col] = "0.00"

        # --- RESPONSE ---
        data_dict_all = {"reports_data": serialize_data(account_details)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": {"mrc": round(total_mrc, 2), "usage": round(total_usage, 2)},
        }

        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.error(f"Exception in total_mrc_bill_profiles_list_view: {e}")
        error_data = {
            "service_name": "total_mrc_bill_profiles_list_view",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(e),
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {
            "flag": False,
            "message": "Something went wrong fetching Total MRC for Bill Profiles list",
            "data": {},
        }


def get_tenant_details_from_token(common_utils_database, data):
    """
    Fetches tenant_name based on the provided access token and client_id.
    Args:
        z_access_token (str): The access token for authentication.
        data (dict): A dictionary containing the following
            - client_id (str): The client ID to fetch the tenant name.
    Returns:
        dict: Updated data dictionary with tenant_name if found.
    """
    logging.info(f"## readme_api_data function called with data {data}")
    try:
        mode = os.getenv("ENV", "")
        z_access_token = data.get("z_access_token", "")
        # Fetch tenant_name using access token and client_id
        if z_access_token:
            username = data.get("client_id", "")
            page = data.get("page", 1)
            if page:
                data["mod_pages"] = {"start": (page - 1) * 100, "end": page * 100}

            # Fetch service account details
            service_account = common_utils_database.get_data(
                "service_accounts", {"client_id": username}
            ).to_dict(orient="records")[0]

            # Update data dictionary with tenant and role information
            data["role_name"] = service_account["role"]
            tenant = service_account["tenant"]

            # Handle special case for UAT environment
            if mode == "UAT" and tenant == "Altaworx Test":
                tenant_id = "1"
                tenant = "Altaworx"

            # Fetch tenant details
            data["tenant_name"] = tenant

            # Fetch tenant database details
            tenant_database_df = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant}, ["db_name", "id"]
            )

            # Update data dictionary with tenant_id and db_name
            data["tenant_id"] = tenant_database_df["id"].to_list()[0]
            data["db_name"] = tenant_database_df["db_name"].to_list()[0]
            data["session_id"] = data.get("session_id", "client_call")
        return data
    except Exception as e:
        logging.info(f"## readme_api_data Exception occured as: {e}")
        return False

def fcc_report_list_view(data):
    """
    Retrieves FCC Report data with optional date filtering, sorting, pagination, timezone conversion,
    header mapping, and dropdown metadata for UI filtering.

    Args:
        data (dict): Input parameters including:
            - table_name (str, optional): The name of the database view or table. Default: 'ar_aging_view'.
            - col_sort (dict, optional): Sorting configuration in the format {column_name: direction}.
            - module_name (str, optional): Module name for header mapping. Default: 'AR Aging Report'.
            - tenant_name (str): Tenant name used to retrieve timezone.
            - role_name (str): Role name for header mapping.
            - start_date (str, optional): Start of due date filter in 'YYYY-MM-DD' format.
            - end_date (str, optional): End of due date filter in 'YYYY-MM-DD' format.
            - mod_pages (dict): Pagination info containing 'start' and 'end' indices.

    Returns:
        dict: API response with the following keys:
            - flag (bool): Indicates success (True) or failure (False).
            - message (str): Status message for the operation.
            - data (dict): Dictionary containing:
                - 'reports_data': Serialized records of AR aging data.
            - header_map (dict): Header mapping for frontend table generation.
            - pages (dict): Contains pagination metadata ('start', 'end', 'total').
            - dropdown (dict): Dropdown filter options for frontend filtering, including:
                - agent (list): List of sales agents.
                - customer_status (list): List of customer statuses.
                - format (list): Available report formats.
                - charge_date, credit_date, payment_date (list): Date filtering options.
    """
    # UI Params
    billing_db_name = data.get("billing_db_name", "")
    tenant_db_name = data.get("db_name", "")

    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    killbill_database = DB(billing_db_name, **db_config)
    tenant_db_conn = DB(tenant_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    start_time = time.time()
    table_name = data.get("table_name", "vw_fcc_report")
    if not table_name:
        table_name = "vw_fcc_report"
    col_sort = data.get("col_sort", "")
    module_name = data.get("module_name", "FCC Report")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")

    mode = os.getenv("ENV", "")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    date_flag = True
    if not start_date or not end_date:
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")
    # user selected data
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None

    # ----------------------------------------
    # Customer access restriction (USING db_config)
    # ----------------------------------------
    customer_names = None

    if role_name not in ("Super Admin", "Partner Admin"):

        # 1️⃣ Read customers from db_config
        config_customers = db_config.get("customers")
        if config_customers:
            customer_names = normalize_customers_from_config(config_customers)

        logging.info(
            f"## fcc_report_list_view customer_names from db_config {customer_names}"
        )

        # 2️⃣ If no customers → return empty response
        if not customer_names:
            header_map = get_headers_mapping(
                killbill_database, [module_name], role_name, "", "", "", "", data
            )
            return {
                "flag": True,
                "message": "No FCC report data found",
                "data": {"reports_data": []},
                "header_map": header_map,
                "pages": {"start": start, "end": end, "total": 0},
                "summary": {},
            }

        
    tenant_time_zone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )["time_zone"].to_list()[0]

    if not tenant_time_zone:
        raise ValueError("No valid timezone found for tenant.")

    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        base_query = f"""
            SELECT * FROM {table_name}
            WHERE tenant_id = %s
        """
        params = [tenant_id]
        if customer_names:
            placeholders = ",".join(["%s"] * len(customer_names))
            base_query += f" AND company_name IN ({placeholders})"
            params.extend(customer_names)
        # Sort order handling (ensure valid keys)
        if start_date and end_date and date_flag:
            base_query += " AND created_date BETWEEN %s AND %s"
            params.extend([start_date, end_date])
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            order_direction = order[order_by].lower()
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY created_date DESC"
        count_df = killbill_database.execute_query(base_query, params=params)
        count_df_dict = count_df.to_dict(orient="records")
        total_pages_count = len(count_df_dict)
        total_subscriptions = sum(
            d.get("subscription_count") or 0 for d in count_df_dict
        )
        pages_data = {"start": start, "end": end, "total": total_pages_count}
        base_query += " LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        df = killbill_database.execute_query(base_query, params=params)
        df_dict = df.to_dict(orient="records")
        df_dict = convert_timestamp(df_dict, tenant_time_zone)


        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )
        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": {"subscription_count": total_subscriptions},
        }
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.exception(f"###fcc_report_list_view Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching reports list",
            "data": {},
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "fcc_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response



def fcc_report_list_view_30_12_2025(data):
    """
    Retrieves FCC Report data with optional date filtering, sorting, pagination, timezone conversion,
    header mapping, and dropdown metadata for UI filtering.

    Args:
        data (dict): Input parameters including:
            - table_name (str, optional): The name of the database view or table. Default: 'ar_aging_view'.
            - col_sort (dict, optional): Sorting configuration in the format {column_name: direction}.
            - module_name (str, optional): Module name for header mapping. Default: 'AR Aging Report'.
            - tenant_name (str): Tenant name used to retrieve timezone.
            - role_name (str): Role name for header mapping.
            - start_date (str, optional): Start of due date filter in 'YYYY-MM-DD' format.
            - end_date (str, optional): End of due date filter in 'YYYY-MM-DD' format.
            - mod_pages (dict): Pagination info containing 'start' and 'end' indices.

    Returns:
        dict: API response with the following keys:
            - flag (bool): Indicates success (True) or failure (False).
            - message (str): Status message for the operation.
            - data (dict): Dictionary containing:
                - 'reports_data': Serialized records of AR aging data.
            - header_map (dict): Header mapping for frontend table generation.
            - pages (dict): Contains pagination metadata ('start', 'end', 'total').
            - dropdown (dict): Dropdown filter options for frontend filtering, including:
                - agent (list): List of sales agents.
                - customer_status (list): List of customer statuses.
                - format (list): Available report formats.
                - charge_date, credit_date, payment_date (list): Date filtering options.
    """
    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    data = get_tenant_details_from_token(common_utils_database, data)

    start_time = time.time()
    table_name = data.get("table_name", "vw_fcc_report")
    if not table_name:
        table_name = "vw_fcc_report"
    col_sort = data.get("col_sort", "")
    module_name = data.get("module_name", "FCC Report")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    tenant_id = data.get("tenant_id", "")

    mode = os.getenv("ENV", "UAT")
    if mode == "UAT":
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
            tenant_id = 1
    date_flag = True
    if not start_date or not end_date:
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")
    # user selected data
    start = data.get("mod_pages", {}).get("start", None)
    end = data.get("mod_pages", {}).get("end", None)
    if start or end:
        limit = end - start
        offset = start
    else:
        limit = None
        offset = None

    tenant_time_zone = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["time_zone"]
    )["time_zone"].to_list()[0]

    if not tenant_time_zone:
        raise ValueError("No valid timezone found for tenant.")

    match = re.search(
        r"\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)", tenant_time_zone
    )
    if match:
        tenant_time_zone = match.group(1).replace(" ", "")

    try:
        base_query = f"""
            SELECT * FROM {table_name}
            WHERE 1=1 and tenant_id = {tenant_id}
        """
        params = []
        # Sort order handling (ensure valid keys)
        if start_date and end_date and date_flag:
            base_query += " AND created_date BETWEEN %s AND %s"
            params.extend([start_date, end_date])
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            order_direction = order[order_by].lower()
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY created_date DESC"
        count_df = killbill_database.execute_query(base_query, params=params)
        count_df_dict = count_df.to_dict(orient="records")
        total_pages_count = len(count_df_dict)
        total_subscriptions = sum(
            d.get("subscription_count") or 0 for d in count_df_dict
        )
        pages_data = {"start": start, "end": end, "total": total_pages_count}
        base_query += " LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        df = killbill_database.execute_query(base_query, params=params)
        df_dict = df.to_dict(orient="records")
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        # package_list=[]
        # try:
        #     package_list_df= killbill_database.get_data(table_name="packages",condition=None,columns=["package_type", "subscription_count", "customer_name", "customer_address", "city", "state", "postal_code"])
        #     package_list=list(set(package_list))
        # except Exception as e:
        #     logging.info(f'exception------{e}')
        #     package_list=[]

        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )
        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": {"subscription_count": total_subscriptions},
        }
        # end_time = time.time()
        # time_consumed = f"{end_time - start_time:.4f}"
        # time_consumed = int(float(time_consumed))
        # audit_data_user_actions = {
        #     "service_name": "ar_aging_report_list_view",
        #     "created_by": data.get("username", ""),
        #     "status": str(response["flag"]),
        #     "time_consumed_secs": time_consumed,
        #     "session_id": data.get("session_id", ""),
        #     "tenant_name": data.get("Partner", ""),
        #     "comments": 'Successfully fetched AR Aging Report',
        #     "module_name": "Reports",
        #     "request_received_at": data.get("request_received_at", None)
        # }
        # database.update_audit(audit_data_user_actions, "audit_user_actions")
        if data.get("z_access_token", ""):
            return {"data": data_dict_all}
        else:
            return response

    except Exception as e:
        logging.exception(f"###fcc_report_list_view Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching reports list",
            "data": {},
        }
        message = str(e)
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "fcc_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": "",
            "module_name": "Reports",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def export_fcc_report(data):
    start_time = time.time()

    database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    billing_db_name = data.get("billing_db_name", "")
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    table_name = data.get("table_name", "vw_fcc_report")

    mode = os.getenv("ENV", "UAT")
    if mode == "UAT" and tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
        tenant_id = 1

    # ---------- Date Validation ----------
    date_flag = bool(start_date and end_date)

    if end_date and date_flag:
        end_date = (
            datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
        ).strftime("%Y-%m-%d")

    # ---------- Customer Access ----------
    tenant_database = data.get("db_name", "")
    tenant_database_conn = DB(tenant_database, **db_config)


    # ---------- Customer Access ----------
    customer_names = None  # Default → no restriction

    if role_name not in ("Super Admin", "Partner Admin"):
        config_customers = db_config.get("customers")
 
        if config_customers:
            customer_names = normalize_customers_from_config(config_customers)

        # If no customers → return empty immediately
        if not customer_names:
            return {
                "flag": True,
                "message": "No data available for the user.",
                "data": {},
            }

    # ---------- Timezone ----------
    tz_df = common_utils_database.execute_query(
        "SELECT time_zone FROM tenant WHERE tenant_name = %s",
        params=[tenant_name],
    )

    if tz_df.empty or not tz_df.iloc[0]["time_zone"]:
        raise ValueError("No valid timezone found for tenant")

    tenant_time_zone = tz_df.iloc[0]["time_zone"]
    if "Asia" in tenant_time_zone:
        tenant_time_zone = tenant_time_zone.split()[-1]

    try:
        # ---------- Base Query ----------
        query = f"""
            SELECT
                package_type,
                subscription_count,
                company_name,
                company_address,
                company_city,
                company_state,
                company_zip,
                created_date
            FROM {table_name}
            WHERE tenant_id = %s
        """
        params = [tenant_id]
        
        # ---------- Customer Filter ----------
        if customer_names:
            placeholders = ",".join(["%s"] * len(customer_names))
            query += f" AND company_name IN ({placeholders})"
            params.extend(customer_names)

        # ---------- Date Filter ----------
        if start_date and end_date and date_flag:
            query += " AND created_date BETWEEN %s AND %s"
            params.extend([start_date, end_date])

        query += " ORDER BY created_date DESC"

        df = killbill_database.execute_query(query, params=params)
        records = df.to_dict(orient="records")
        records = convert_timestamp(records, tenant_time_zone)

        if not records:
            df = pd.DataFrame(
                columns=[
                    "package_type",
                    "subscription_count",
                    "company_name",
                    "company_address",
                    "company_city",
                    "company_state",
                    "company_zip",
                ]
            )
        else:
            df = pd.DataFrame(records).fillna("")

        data["dfs"] = {"FCC Report": df}
        data["module_name"] = "Export FCC"

        response = export_to_s3_bucket_(data)

        # ---------- Audit ----------
        time_consumed = int(time.time() - start_time)
        database.update_audit(
            {
                "service_name": "export_fcc_report",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": "Successfully Exported FCC Report",
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "audit_user_actions",
        )

        return response

    except Exception as e:
        logging.error(f"Exception occurred while exporting FCC report: {e}")

        database.log_error_to_db(
            {
                "service_name": "export_fcc_report",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "error_log_table",
        )

        return {
            "flag": False,
            "message": "Something went wrong Exporting FCC Report",
            "data": {},
        }


def product_level_tax_mapping_report_list_view(data):
    """
    Ticket - 5087
    Fetches Product Level Tax Mapping report data with filtering and pagination.

    Retrieves records from the `vw_product_level_tax_mapping` view based on
    tenant, active status, and optional billing date range. Supports column
    sorting and pagination, formats numeric values, converts timestamps to the
    tenant’s timezone, and calculates summary totals for product rate, tax,
    and total amount. Audit and error logs are recorded accordingly.

    Args:
        data (dict): Request payload containing tenant details, date filters,
            pagination information, sorting options, and user/session metadata.

    Returns:
        dict: Response containing report data, header mapping, pagination
            details, summary totals, and execution status.
    """
    logging.info(f"### product_level_tax_mapping_report_list_view function called with data: {data}")
    start_time = time.time()
    try:
        # Initialize database connections using environment variables and configurations
        billing_platform_common_utils = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database = DB(data.get("billing_db_name", ""),**db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }
    
    try:
        data = get_tenant_details_from_token(common_utils_database, data)
        table_name = data.get("table_name", "vw_product_level_tax_mapping")
        col_sort = data.get("col_sort", "")
        module_name = data.get("module_name", "Product Level Tax Mapping")
        tenant_name = data.get("tenant_name", "")
        role_name = data.get("role_name", "")
        start_date = data.get("start_date", "")
        end_date = data.get("end_date", "")
        tenant_id = data.get("tenant_id", "")
        user_name = data.get("username", "")
        session_id = data.get("sessionID", "")
        request_received_at = data.get("request_received_at", None)

        date_flag = True
        if not start_date or not end_date:
            date_flag = False
        if end_date and date_flag:
            try:
                # Parse string to datetime, add one day, and convert back to string
                end_date = (
                    datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
                ).strftime("%Y-%m-%d")
            except Exception as e:
                logging.warning(f"Error {e}")

        #pagination
        start = data.get("mod_pages", {}).get("start", None)
        end = data.get("mod_pages", {}).get("end", None)
        if start or end:
            limit = end - start
            offset = start
        
        # Fetch tenant time zone
        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)

        # Build base query
        if start_date and end_date and date_flag:
            base_query = f"""
                SELECT * FROM {table_name}
                WHERE tenant_id = %s 
                and is_active = true 
                and to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s 
                and to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s
            """
            params = [tenant_id, start_date, end_date]
        else:
            base_query = f"""
                SELECT * FROM {table_name} 
                WHERE tenant_id = %s 
                and is_active = true
            """
            params = [tenant_id]

        # total count for pagination
        count_df = killbill_database.execute_query(base_query, params=params)
        count_df_dict = count_df.to_dict(orient="records")
        total_pages_count = len(count_df_dict)

        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]
            order_direction = order[order_by].lower()
            base_query += f" ORDER BY {order_by} {order_direction}"
        else:
            base_query += " ORDER BY bill_id DESC"

        pages_data = {"start": start, "end": end, "total": total_pages_count}
        if start is not None and end is not None:
            base_query += " LIMIT %s OFFSET %s"
            params.extend([limit, offset])
        df = killbill_database.execute_query(base_query, params=params)
        
        numeric_cols = ["product_rate", "products_tax", "total_amount"]
        for col in numeric_cols:
            if col in df.columns:
                df[col] = df[col].astype(float).fillna(0).map(format_amount)

        df_dict = df.to_dict(orient="records")
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        # Calculate summary totals
        columns_to_sum = ["product_rate", "products_tax", "total_amount"]
        if total_pages_count > 0:
            summary_totals = {
                col: format_amount(
                    sum(float(row.get(col, 0) or 0) for row in count_df_dict)
                )
                for col in columns_to_sum
            }
        else:
            summary_totals = {col: 0.00 for col in columns_to_sum}

        #header mapping
        header_map = get_headers_mapping(
            killbill_database, [module_name], role_name, "", "", "", "", data
        )
        data_dict_all = {"reports_data": serialize_data(df_dict)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "summary": {
                "mrc": summary_totals["product_rate"],
                "taxes": summary_totals["products_tax"],
                "total": summary_totals["total_amount"],
            }
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))

        audit_data_user_actions = {
            "service_name": "product_level_tax_mapping_report_list_view",
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": response["message"],
            "module_name": module_name,
            "request_received_at":request_received_at,
        }
        billing_platform_common_utils.update_audit(audit_data_user_actions, "audit_user_actions")
        return response

    except Exception as e:
        logging.exception(f"product_level_tax_mapping_report_list_view function : Exception occurred: {e}")
        message = str(e)
        response = {"flag": False, "message": message,"data": {} }
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "product_level_tax_mapping_report_list_view",
            "error_message": message,
            "error_type": error_type,
            "users": user_name,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        billing_platform_common_utils.log_error_to_db(error_data, "error_log_table")
        return response

def product_level_tax_mapping_report_export(data):
    """
    Ticket - 5087
    Exports the Product Level Tax Mapping report.

    Retrieves Product Level Tax Mapping data from the
    `vw_product_level_tax_mapping` view based on tenant and optional
    billing date range, formats numeric fields, converts timestamps to
    tenant timezone, and prepares the data for export. The generated
    report is uploaded to S3 and an audit entry is recorded.

    Args:
        data (dict): Request payload containing tenant details, optional
            date filters, database configuration, and user/session metadata.

    Returns:
        dict: Export response containing status flag, message, and
            export file details from the S3 upload.
    """
    logging.info(f"### product_level_tax_mapping_report_export called with data: {data}")
    start_time = time.time()
    try:
        # Initialize database connections using environment variables and configurations
        billing_platform_common_utils = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database = DB(data.get("billing_db_name", ""),**db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }

    table_name = data.get("table_name", "vw_product_level_tax_mapping")
    col_sort = data.get("col_sort", {})
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    tenant_id = data.get("tenant_id")
    #date handling
    date_flag = True
    if not start_date or not end_date:
        date_flag = False
    if end_date and date_flag:
        try:
            # Parse string to datetime, add one day, and convert back to string
            end_date = (
                datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            ).strftime("%Y-%m-%d")
        except Exception as e:
            logging.warning(f"Error {e}")
    
    # Fetch tenant time zone
    tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)

    try:
        # Build base query
        if start_date and end_date and date_flag:
            base_query = f"""
                SELECT account_number as account_id, bill_id, primary_identifier, product_description, tax_code, bill_range, product_rate, products_tax, total_amount FROM {table_name} 
                WHERE tenant_id = %s 
                and is_active = true 
                and to_date(split_part(bill_range, ' - ', 1), 'MM-DD-YYYY') <= %s 
                and to_date(split_part(bill_range, ' - ', 2), 'MM-DD-YYYY') >= %s
            """
            params = [tenant_id, start_date, end_date]
        else:
            base_query = f"""
                SELECT account_number as account_id, bill_id, primary_identifier, product_description, tax_code, bill_range, product_rate, products_tax, total_amount FROM {table_name} 
                WHERE tenant_id = %s 
                and is_active = true
            """
            params = [tenant_id]

        base_query += " ORDER BY bill_id DESC"
        df = killbill_database.execute_query(base_query, params=params)
        df_dict = df.to_dict(orient="records")
        # for d in df_dict:
        #     for k in ("id", "customer_profile_id", "modified_date", "account_number"):
        #         d.pop(k, None)
        if not df_dict:
            df = pd.DataFrame(columns=[ "account_id", "bill_id", "primary_identifier", "product_description", "tax_code", "bill_range", "product_rate", "products_tax", "total_amount"])
        else:
            df_dict = convert_timestamp(df_dict, tenant_time_zone)
            df = pd.DataFrame(df_dict).fillna("")
            # df = df.drop(columns=["charge_id", "category", "product_id", "id", "is_active", "modified_date", "tenant_id", "customer_name"], errors="ignore")
            numeric_cols = ["product_rate", "products_tax", "total_amount"]
            for col in numeric_cols:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).apply(format_amount)
            df.rename(
                columns={
                    "product_rate": "MRC",
                    "products_tax": "Taxes",
                    "total_amount": "Total",
                },
                inplace=True,
            )
        data["dfs"] = {"Product Level Tax Mapping": df}
        data["module_name"] = "Product Level Tax Mapping Report"
        response = export_to_s3_bucket_(data)
        billing_platform_common_utils.update_audit(
            {
                "service_name": "product_level_tax_mapping_report_export",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": data.get("session_id", ""),
                "tenant_name": tenant_name,
                "comments": "Successfully Exported Product Level Tax Mapping Report",
                "module_name": "BP Reports",
                "request_received_at": data.get("request_received_at"),
            },
            "audit_user_actions",
        )
        return response
    except Exception as e:
        logging.exception(f"product_level_tax_mapping_report_export function : Exception occurred: {e}")
        message = str(e)
        response = {"flag": False, "message": message,"data": {} }
        error_type = str(type(e).__name__)
        error_data = {
            "service_name": "product_level_tax_mapping_report_export",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": tenant_name,
            "module_name": "BP Reports",
            "request_received_at": data.get("request_received_at"),
        }
        billing_platform_common_utils.log_error_to_db(error_data, "error_log_table")
        return response
    
