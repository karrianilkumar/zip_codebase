"""
@Author1 : Ratna B
Created Date: 27-12-2024
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os 
import io
# from bp_email_trigger import send_email_without_template
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta,date
from dateutil.relativedelta import relativedelta
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict
#download template dependencies
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from datetime import datetime, timedelta
import pandas as pd
from io import BytesIO
import base64
from io import StringIO
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
import pandas as pd
import psycopg2
import random
import string

# Dictionary to store database configuration settings retrieved from environment variables.
common_utils_database_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="bp_dashboards")

def clean_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        print(f"Exception while converting")
        return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name,readme_flag):
    """
    Creates a database configuration dictionary with user-specific filters based on tenant and role.

    Args:
        user (str): Username to look up permissions for
        db_config_making (dict): Base database configuration to extend
        tenant_database (str): Name of the tenant database
        tenant_name (str): Name of the tenant
        role_name (str): User's role (e.g., 'Super Admin')
        readme_flag (bool): Flag to determine query format (client_id vs user_name)

    Returns:
        dict: Modified database configuration with user-specific filters
    """
    logging.info(f"db_config_maker is in progress {role_name}")
    # Connect to common_utils database to get tenant info
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"],**common_utils_database_config)
    # Get tenant ID and parent tenant ID
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    # Bypass filtering for Super Admin users
    if role_name in ('Super Admin','Partner Admin') and not parent_tenant_id:
        logging.info(f"Getting access filters for  in tenant: {tenant_name} with role: {role_name} in if condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name in ('Super Admin','Partner Admin') and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in else condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name =="Agent Partner Admin" and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in elif second condition")
        pass
    else:
        logging.info(f"Getting access filin tenant: {tenant_name} with role: {role_name} in else condition")
        pass
    if tenant_id:
        tenant_id=int(tenant_id)
    #Get user permissions from mapping table
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)
        if filters.empty:
            query = f"""
                SELECT customers, service_provider, customer_group
                FROM user_module_tenant_mapping
                WHERE user_name = '{user}' AND tenant_id = {tenant_id}
            """
            filters = common_utils_database.execute_query(query, True)
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

        filters = common_utils_database.execute_query(query, True)
    # Connect to tenant database
    database = DB(tenant_database, **db_config)
    # Extract customer group if exists
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    # If user has a customer group, get additional filters from it
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            # Extract rate plan names
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
            # Extract customer names
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
                customer_names=None
            # Extract billing account number
            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception("Error extracting billing_account_number:", e)
                billing_account_number=None
            # Extract feature codes
            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception("Error extracting feature_codes:", e)
    # Set customer filter - use customer group names if available, otherwise use direct mapping
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    #customer=clean_tuple(customer)
    # Get service provider info and convert names to IDs
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    # Get additional customers created by this user
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer_list = [customer]
                elif isinstance(customer, tuple):
                    customer_list = list(customer)
                else:
                    customer_list = customer  # Already a list

                fixed_customer_list = customer_list.copy()

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info('customer_list before extend:', customer_list)

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info('customer_list after extend:', fixed_customer_list)

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info('final customer tuple:', customer)
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Get additional rate plans created by this user
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas
                logging.info('customer_ rate plan list before extend:', fixed_customer_rate_plan_list)

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info('customer rate plan_list after extend:', fixed_customer_rate_plan_list)

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info('final customer rate plan tuple:', customer_rate_plan_name)

    except Exception as e:
        logging.exception(f"Error while fetching the customers  for the user {user} in tenant {tenant_name}: {e}")
    # Update configuration with all filters
    logging.info(f"{user} user is service_provider is {service_provider} and service_provider_id is {service_provider_id} and ")
    if role_name =="Agent Partner Admin" and parent_tenant_id:
        db_config_making["customers"] = None
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = None
        db_config_making["feature_codes"] = None
        db_config_making["billing_account_number"] = None
        return db_config_making
    else:
        db_config_making["customers"] = customer
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
        db_config_making["feature_codes"] = feature_codes
        db_config_making["billing_account_number"] = billing_account_number
        return db_config_making

def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    try:
        current_time = datetime.now()
        logging.info(f"###{path},time started : {current_time}, data received is : {data}")
    except Exception as e:
        logging.error(f"Error in function_caller: {e}")
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    logging.info(f"### db_config created is : {db_config}")
    access_token = data.get("z_access_token",None)
    tenant_database = data.get("db_name")
    if not access_token:
        role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        readme_flag=False
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
        logging.info(f"db_config is created {path}")
    else:
        ##API Call
        logging.info(f"db_config will be created for service accountss")
        logging.info(f"path gotten is {path}")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        user = data.get("client_id", "")
        service_data = common_utils_database.get_data(
            "service_accounts", {"client_id": user,"is_active":"True"}
        )

        if service_data.empty:
            logging.info(f"Invalid client ID: {user}")
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}
        )
        tenant_database = tenant_data["db_name"].to_list()[0]
        data['tenant_name']=tenant_name
        data['db_name']=tenant_database
        readme_flag=True
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
    # Map API paths to corresponding handler functions
    path_function_map = {
    "/total_payments": total_payments,
    "/ar_aging_pie": ar_aging_pie,
    "/outstanding_table": outstanding_table,
    "/total_bill_line_graph": total_bill_line_graph,
    "/total_bill_by_ledger_bar": total_bill_by_ledger_bar,
    "/bp_dashboards": bp_dashboards,
    "/collections_summary": collections_summary,
    }
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")
    print(f'tenant_name-----{tenant_name}')

    tenant_id_query = database.get_data(
        "tenant", {"tenant_name": tenant_name},["id"]
    )
    tenant_id = tenant_id_query["id"].to_list()[0]
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name, "parent_module_name":parent_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database,parent_module_name,role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out



def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        logging.info(f'INchanged_data---------{changed_data}---{unique_id}------{table_name}')

        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            logging.info("***update_data",update_data)
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict

def serialize_data(data):
    """Recursively convert pandas and datetime objects to JSON serializable types."""
    
    # Ensure the type check is valid
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    
    # Handle both pandas and native Python timestamps
    elif isinstance(data, (pd.Timestamp, datetime)):  
        return data.strftime('%m-%d-%Y %H:%M:%S')  
    
    elif isinstance(data,date):  
        return data.strftime('%m-%d-%Y %H:%M:%S')  

    # Return other types as they are
    else:
        return data

def get_customer_names_by_user(
    role_name,
    username,
    common_utils_database,
    tenant_db
):
    """
    Returns customer names accessible to the given user based on role and mappings.

    Rules:
    - Super Admin & Partner Admin → returns None (unrestricted access)
    - User has 'customers' field → returns parsed customer list
    - User has 'customer_group' → returns customers from group mapping
    - No mapping found or errors → returns empty list []

    Args:
        role_name (str): User's role name for admin bypass check
        username (str): Username to lookup customer permissions
        common_utils_database: Database connection for users table
        tenant_db: Tenant-specific database for customergroups table

    Returns:
        Optional[List[str]]: List of allowed customer names, None for admins, or []

    Raises:
        None: All errors handled gracefully, returns []
    """
    logging.info("## get_customer_names_by_user function called")

    try:
        # Admin bypass → no restriction
        if not role_name or str(role_name).lower() in ["super admin", "partner admin"]:
            logging.info("## get_customer_names_by_user admin role → unrestricted")
            return None

        # **FIX: Add null check before calling get_data**
        user_data = common_utils_database.get_data(
            table_name="users",
            condition={
                "username": username,
                "is_active": True
            },
            columns=["customers", "customer_group"]
        )

        # **FIX: Check for None or non-DataFrame response**
        if user_data is None or not hasattr(user_data, 'empty') or user_data.empty:
            logging.info("## get_customer_names_by_user user mapping not found")
            return []

        def normalize_value(value):
            """Normalize string/JSON/comma-separated values to list or None."""
            if value is None:
                return None

            if isinstance(value, str):
                cleaned = value.strip()
                if cleaned.lower() in ["", "null", "none"]:
                    return None

                try:
                    parsed = json.loads(cleaned)
                    return parsed
                except json.JSONDecodeError:
                    if "," in cleaned:
                        return [v.strip() for v in cleaned.split(",") if v.strip()]
                    return cleaned

            return value

        customers = normalize_value(user_data.iloc[0].get("customers"))
        customer_group = normalize_value(user_data.iloc[0].get("customer_group"))

        logging.info(
            f"## get_customer_names_by_user customers={customers}, customer_group={customer_group}"
        )

        # Case 1: Direct customers (highest priority)
        if customers:
            if isinstance(customers, str):
                customers = [customers]
            return customers

        # Case 2: Customer group lookup
        if customer_group:
            logging.info(f"## get_customer_names_by_user customer_group exist as {customer_group}")
            group_data = tenant_db.get_data(
                table_name="customergroups",
                condition={"name": customer_group},
                columns=["customer_names"]
            )

            # **FIX: Consistent null/empty check**
            # if group_data is None or not hasattr(group_data, 'empty') or group_data.empty:
            if group_data is None or group_data.empty:
                logging.info("## get_customer_names_by_user group not found or empty")
                return []

            customer_names = normalize_value(group_data.iloc[0].get("customer_names"))

            if isinstance(customer_names, str):
                customer_names = [customer_names]

            return customer_names or []

        # No customers or groups mapped
        logging.info("## get_customer_names_by_user no customers and no group")
        return []

    except Exception as e:
        logging.exception(f"## get_customer_names_by_user error: {e}")
        return []

def get_export_status(data):
    """
    The get_export_status function retrieves the export status of a specific module from a database.
    It queries the export_status table based on the given module name and returns the corresponding status data.
    """
    try:
        # DB Connections
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        killbill_database = data.get("billing_db_name", "")
        database = DB(killbill_database, **db_config)
        report_id=data.get("report_id","")
        request_received_at = data.get("request_received_at", None)
        module_name = data.get("module_name",None) 
        username=data.get("username",None)
        tenant_id=data.get("tenant_id",None)   
        export_status_data=common_utils_database.get_data('export_status',{"module_name":module_name,"user_name":username,"tenant_id":tenant_id},None).to_dict(orient="records")
        # updating the report status
        try:
            if report_id:
                reports_data={
                    "generated_date":request_received_at,
                    "status":"Generated"
                }
                update_report=database.update_dict("reports",reports_data, {"id": report_id})
        except Exception:
            pass
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        error_data = {
            "service_name": "get_export_status",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": f"Failed! While checking export status {module_name}",
            "module_name": "Dashboards",
            "request_received_at": data.get("request_received_at"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "export_status_data": []}

def export_to_s3_bucket_(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    logging.info(f"###export_to_s3_bucket_ Exporting to S3 bucket... {data}")
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    logging.info(f'module_name---------{module_name}')
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("username", "")
    session_id = data.get("session_id", "")
    tenant_id = data.get("tenant_id", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}
    logging.info(f'data_frames---------{data_frames}')
    report_name=data.get("report_name","")
    username=data.get("username","")
    killbill_database = data.get("billing_db_name", "")
    database = DB(killbill_database, **db_config)
    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
    start_time = time.time()


    # insert into reports table
    reports_dict={
        "report_name":report_name,
        "requested_by":username,
        "requested_date":request_received_at,
        "status":"Pending"
    }
    try:
        inserted_id=database.insert_data(reports_dict,"reports")
        if inserted_id:
            response = {
                    "flag": True,
                    "message": "Successfully Generated Report"
                }
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": module_name,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f'Successfully Generated {report_name}',
                "module_name": module_name,
                "request_received_at": request_received_at
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        else:
            response = {
                    "flag": False,
                    "message": "Error Inserting Report data to Reports table"
                }
            return response
    except Exception:
        inserted_id=''

    
    file_name = f"exports/uat/{module_name_snake_case}/{module_name}_{tenant_id}_{user_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"


    # Update export status to 'Waiting'
    updated_flag=db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
    )
    if not updated_flag:
        db.insert_data({"status_flag": "Waiting", "url": "","tenant_id": tenant_id,"user_name": user_name,"module_name":module_name},"export_status")

    try:
        if not data_frames :
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                if df.empty:
                    df = pd.DataFrame(columns=df.columns)

                # Format column names
                acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "SIM"}
                special_replacements = {"Att": "AT&T", "And": "and"}

                df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                    for col in df.columns
                ]
                df.columns = [
                    " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
                ]

                df.to_excel(writer, index=False, sheet_name=sheet_name)

                # Apply styles
                workbook = writer.book
                sheet = workbook[sheet_name]

                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = header_font

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )



        db.update_dict(
        "export_status",
        {"status_flag": "Success", "url": download_url},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name})
            
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name}
        )   
        db.log_error_to_db(
            {
                "service_name": "export_to_s3_bucket_",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"Failed! While exporting excel {module_name}",
                "module_name": module_name,
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}


def generate_empty_excel():
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sheet1"

    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)

    # ✅ Convert Excel bytes → Base64
    return base64.b64encode(buffer.read())
  
def generate_empty_excel_61125():
    """
    Generates an empty Excel file with a placeholder sheet using openpyxl.
    """
    # Create a workbook and an empty worksheet
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sheet1"  # Set the sheet name

    # Save the workbook to a BytesIO bufferr
    buffer = io.BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()

def dataframe_to_blob(data_frame):
    """
    Description:
        Converts a Pandas DataFrame into a Base64-encoded Excel blob with
        properly formatted headers, readable column widths, and consistent styling.
    """

    # Create an in-memory binary stream
    bio = BytesIO()

    def style_and_adjust_columns(sheet):
        """
        Apply header styles and adjust column widths for the given sheet.
        """
        # Apply header styles
        for cell in sheet[1]:
            cell.alignment = Alignment(horizontal="center", vertical="center")  # Center align
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")  # Grey background
        # Adjust column widths based on content
        for col_idx, col_cells in enumerate(sheet.columns, 1):
            max_length = max(len(str(cell.value or "")) for cell in col_cells)
            sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 1

    # Write DataFrame to Excel in-memory
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        data_frame.to_excel(writer, index=False, sheet_name="Data")

        # Access workbook and sheet to apply formatting
        workbook = writer.book
        sheet = workbook["Data"]
        style_and_adjust_columns(sheet)

    # Move to beginning of buffer and encode as Base64
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    return blob_data


def total_payments(data):
    """
    Fetches the total payment amount per day, month, or year in the specified date range.

    Args:
        data (dict): A dictionary containing the following keys:
            - start_date (str): The start date for filtering payments (format: YYYY-MM-DD).
            - end_date (str): The end date for filtering payments (format: YYYY-MM-DD).

    Returns:
        dict: A dictionary containing the status and the bar chart data of daily, monthly, or yearly payment totals.
    """
    logging.info("total_payments function called with data: %s", data)
    start_time = time.time()
    modified_date=data.get('request_received_at','')
    role_name = data.get("role_name", "")
    Partner = data.get("partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    flag = data.get('flag', 'today')
    action = data.get('action', '')
    today = datetime.now().date()
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("partner", "")
    tenant_db_name = data.get("db_name", "")
    try:
        # Initialize database connections using environment variables and configurations
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database = DB(data.get("billing_db_name", ""),**db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_conn = DB(tenant_db_name, **db_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }

    # Default range for weekly and daily
    start_of_week = today - timedelta(days=today.weekday())
    end_of_week = start_of_week + timedelta(days=6)
    
    # Set default date range based on the flag
    if flag.lower() in ['weekly']:
        data["start_date"] = data.get("start_date", start_of_week.strftime("%Y-%m-%d"))
        data["end_date"] = data.get("end_date", end_of_week.strftime("%Y-%m-%d"))
    elif flag.lower() == 'today':
        # For today, set the range to today only
        data["start_date"] = today.strftime("%Y-%m-%d")
        data["end_date"] = (today + timedelta(days=1)).strftime("%Y-%m-%d")
    elif flag.lower() in ['monthly', 'yearly']:
        # For monthly or yearly, get the range from 12 months ago to today
        start_date = today.replace(day=1)  # Set to the first of the current month
        start_date = start_date - timedelta(days=365)  # Go back one year
        data["start_date"] = start_date.strftime("%Y-%m-%d")
        data["end_date"] = today.strftime("%Y-%m-%d")
    
    # ----------------------------------------
    # Customer access restriction (handled inline)
    # ----------------------------------------
    customer_names = None  # Default → no restriction

    if role_name not in ("Super Admin", "Partner Admin"):
        # Try using db_config customers if exists
        config_customers = db_config.get("customers")
        logging.info(f"## total_payments Applying customer filter from db_config config_customers={config_customers}")
        if config_customers:
            customer_names = normalize_customers_from_config(config_customers)
            if customer_names:
                logging.info(
                    f"## total_payments Applying customer filter from db_config customers={customer_names}"
                )
        if not customer_names:  # covers None or empty list
            if action == "download":
                empty_df = pd.DataFrame(columns=["Day", "Value"])
                blob_data = dataframe_to_blob(empty_df)
                return {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                    "filename": "Total_Payments.xlsx",
                }

            return {
                "flag": True,
                "data": {
                    "title": f"Total Payment Amount ({flag.capitalize()})",
                    "chart_type": "bar",
                    "data": [],
                    "xField": "day",
                    "yField": "value",
                    "smooth": True,
                    "height": 300,
                    "width": 500,
                }
            }
    try:
        account_numbers = []
        if customer_names:
            placeholders = ",".join(["%s"] * len(customer_names))
            profile_query = f"""
                SELECT account_number
                FROM customer_profiles
                WHERE tenant_id = %s
                  AND customer_name IN ({placeholders})
            """
            profile_params = [tenant_id] + customer_names

            profile_df = killbill_database.execute_query(
                profile_query,
                True,
                params=profile_params
            )
            account_numbers = profile_df["account_number"].tolist()
        query = """
            SELECT DATE(date) AS date, SUM(amount) AS total_amount
            FROM payment_history
            WHERE tenant_id = %s and date BETWEEN %s AND %s AND status = 'Successful'
        """
        params = [tenant_id, data["start_date"], data["end_date"]]
        if account_numbers:
            placeholders = ",".join(["%s"] * len(account_numbers))
            query += f" AND account_number IN ({placeholders})"
            params.extend(account_numbers)  
        query += " GROUP BY DATE(date) ORDER BY DATE(date)"

        # Execute query
        res = killbill_database.execute_query(query, params=params)
        print(f'results: {res}')
        
        # Process result
        if isinstance(res, pd.DataFrame):
            daily_amounts = res.set_index("date")["total_amount"].to_dict()
        else:
            daily_amounts = dict(res.fetchall()) if res else {}
        
        # Format result dates
        daily_amounts = {
        date.strftime("%Y-%m-%d"): round(float(amount), 2) for date, amount in daily_amounts.items()
        }
        print(f'formatted daily_amounts: {daily_amounts}')

        data_card = []

        if flag.lower() in ['today', 'weekly']:
            # Weekly or Daily Processing
            days_of_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            for i in range(7):
                day = start_of_week + timedelta(days=i)
                date_str = day.strftime("%Y-%m-%d")
                amount = round(daily_amounts.get(date_str, 0.0), 2)
                data_card.append({"day": days_of_week[i], "value": amount})

        elif flag.lower() in ['monthly', 'yearly']:
            # Monthly or Yearly Processing (over the past 12 months)
            months_of_year = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            month_totals = {month: 0.0 for month in months_of_year}

            year_totals = {}

            for date_str, amount in daily_amounts.items():
                # Get the month and year from the date
                date_obj = datetime.strptime(date_str, "%Y-%m-%d")
                month_name = date_obj.strftime("%b")
                year = date_obj.year

                # Update month totals
                if month_name in months_of_year:
                    month_totals[month_name] += round(amount, 2)
                
                # Update year totals
                if year not in year_totals:
                    year_totals[year] = 0.0
                year_totals[year] += round(amount, 2)

            # Preparing the data_card for monthly or yearly payments
            for month in months_of_year:
                data_card.append({"day": month, "value": round(month_totals[month], 2)})

            if flag.lower() == 'yearly':
                # Preparing the data_card for yearly payments (sorted by year)
                for year, total in sorted(year_totals.items()):
                    data_card.append({"day": str(year), "value": round(total, 2)})

        if action == "download":
            df_output = pd.DataFrame(data_card)
            df_output.replace(to_replace="None", value="", inplace=True)
            df_output["value"] = (
                pd.to_numeric(df_output["value"], errors="coerce")
                .fillna(0)
                .apply(format_amount)
            )
            df_output = df_output.astype(str)
            df_output.columns = [col.replace("_", " ").title() for col in df_output.columns]
            blob_data = dataframe_to_blob(df_output)

            return {
                "flag": True,
                "blob": blob_data.decode("utf-8"),
                "filename": "Total_Payments.xlsx"
            }

        response = {
            "flag": True,
            "data": {
                "title": f"Total Payment Amount ({flag.capitalize()})",
                "chart_type": "bar",
                "data": data_card,
                "xField": "day",
                "yField": "value",
                "smooth": True,
                "height": 300,
                "width": 500,
            },
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "total_payments",
            "created_by": username,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": 'Successfully fetched payment data',
            "module_name": "BP Dashboards",
            "request_received_at": modified_date
            }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        print(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching payment data",
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "total_payments",
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "BP Dashboards",
                "request_received_at": modified_date,
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass

    return response

def ar_aging_pie(data):
    """
    Fetches the aging summary including total and current A/R values.
    Args:
        data (dict): Should contain 'partner', 'start_date', and 'end_date'.
    Returns:
        dict: Status flag and chart data for aging buckets.
    """
    logging.info("ar_aging_pie function called with data: %s", data)
    start_time = time.time()
    modified_date=data.get('request_received_at','')
    Partner = data.get("partner", "")
    username = data.get("username", "")
    session_id = data.get("session_id", "")
    partner_name = data.get("partner")
    action = data.get("action", "")
    start_date = data.get("start_date")
    role_name = data.get("role_name", "")
    end_date = (datetime.strptime(data.get("end_date"), "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("partner", "")
    tenant_db_name = data.get("db_name", "")
    try:
        # Initialize database connections using environment variables and configurations
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database = DB(data.get("billing_db_name", ""),**db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_conn = DB(tenant_db_name, **db_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }

    # ----------------------------------------
    # Customer access restriction (handled inline)
    # ----------------------------------------
    customer_names = None  # Default → no restriction

    if role_name not in ("Super Admin", "Partner Admin"):
        # Try using db_config customers if exists
        config_customers = db_config.get("customers")
        logging.info(f"## ar_aging_pie Applying customer filter from db_config config_customers={config_customers}")
        if config_customers:
            customer_names = normalize_customers_from_config(config_customers)
            if customer_names:
                logging.info(
                    f"## ar_aging_pie Applying customer filter from db_config customers={customer_names}"
                )
        if not customer_names:  # covers None or empty list
            data_card = [
                {"status": "0-30", "count": 0},
                {"status": "31-60", "count": 0},
                {"status": "61-90", "count": 0},
                {"status": "91-120", "count": 0},
                {"status": "120+", "count": 0},
            ]
            if action == "download":
                df = pd.DataFrame(data_card)
                df.replace(to_replace="None", value="", inplace=True)
                df = df.astype(str)
                df.columns = ["Status", "Count"]
                blob_data = dataframe_to_blob(df)
                return {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                    "filename": "A_R_Aging_Pie.xlsx"
                }

            return {
                "flag": True,
                "data": {
                    "title": "Total A/ R: $0    Current A/ R: $0",
                    "chart_type": "pie",
                    "data": data_card,
                    "angleField": "count",
                    "colorField": "status",
                    "color": ["#1890FF", "#13C2C2", "#2FC25B", "#FACC14", "#F04864"],
                    "radius": 0.8,
                    "innerRadius": 0.6,
                    "height": 300,
                    "width": 500,
                },
            }
    try:
        query = """
            SELECT * FROM ar_aging_view
            WHERE tenant_id = %s and modified_date >= %s AND modified_date < %s
        """
        params = [tenant_id,start_date, end_date]
        if customer_names:
            placeholders = ",".join(["%s"] * len(customer_names))
            query += f" AND customer_name IN ({placeholders})"
            params.extend(customer_names)
        res = killbill_database.execute_query(query, params=params)
        columns = res.columns.tolist()
        # Assigning the values of each column to separate variables
        # Extracting values as lists for all rows
        current = res['current'].tolist()
        column_0_30 = res['0-30'].tolist()
        column_31_60 = res['31-60'].tolist()
        column_61_90 = res['61-90'].tolist()
        column_91_120 = res['91-120'].tolist()
        column_120_plus = res['120+'].tolist()

        total_0_30 = round(sum(column_0_30), 2)
        total_31_60 = round(sum(column_31_60), 2)
        total_61_90 = round(sum(column_61_90), 2)
        total_91_120 = round(sum(column_91_120), 2)
        total_120_plus = round(sum(column_120_plus), 2)
                               
        total_current = round(sum(current), 2)

        total_value = 0
        for i in range(len(res)):
            total_value += res['0-30'][i] + res['31-60'][i] + res['61-90'][i] + res['91-120'][i] + res['120+'][i]
        
        total_value_ = round(total_value + total_current, 2)
        logging.debug(f"ar_aging_pie total_value: {total_value}")
        labels = ["0-30", "31-60", "61-90", "91-120", "120+"]

        data_card = [
            {"status": "0-30", "count": total_0_30},
            {"status": "31-60", "count": total_31_60},
            {"status": "61-90", "count": total_61_90},
            {"status": "91-120", "count": total_91_120},
            {"status": "120+", "count": total_120_plus},
        ]
        if action == "download":
            data_card.append({"status": "Current", "count": total_current})  # Example for adding current value
            data_card.append({"status": "Total", "count": total_value_})
            df = pd.DataFrame(data_card)
            if df.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),  # If you need a decoded version
                    "message": "No data available. Empty Excel generated.",
                }
            logging.info("Download action requested.")
            df.replace(to_replace="None", value="", inplace=True)
            df = df.astype(str)
            df["count"] = (
                pd.to_numeric(df["count"], errors="coerce")
                .fillna(0)
                .apply(format_amount)
            )

            df.columns = [
                col.replace("_", " ").title() for col in df.columns
            ]

            blob_data = dataframe_to_blob(df)
            logging.info("Blob data prepared for download.")
            response = {"flag": True, "blob": blob_data.decode("utf-8"), "filename": "A_R_Aging_Pie.xlsx"}
            #return response
    
        if action == 'view':
            response = {
                "flag": True,
                "data": {
                    "title": f"Total A/ R: ${total_value_:,.0f}    Current A/ R: ${total_current:,.0f}",
                    "chart_type": "pie",
                    "data": data_card,
                    "angleField": "count",
                    "colorField": "status",
                    "color": ["#1890FF", "#13C2C2", "#2FC25B", "#FACC14", "#F04864"],
                    "radius": 0.8,
                    "innerRadius": 0.6,
                    "height": 300,
                    "width": 500,
                },
            }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "ar_aging_pie",
            "created_by": username,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": 'Successfully fetched A/R aging data',
            "module_name": "BP Dashboards",
            "request_received_at": modified_date
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        logging.error("Error occurred while fetching A/R aging data", exc_info=True)
        response = {
            "flag": False,
            "message": "Error occurred while fetching A/R aging data."
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "ar_aging_pie",
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "BP Dashboards",
                "request_received_at": modified_date,
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass

    return response

def outstanding_table(data):
    """
    Fetches the Outstanding Customers table for the tenant with role-based customer filtering.
    Supports both list view and downloading the data as an Excel file.

    Parameters:
        data (dict): A dictionary containing:
            - 'action' (str): 'view' or 'download'
            - 'tenant_name' (str): Tenant name
            - 'tenant_id' (int): Tenant identifier
            - 'role_name' (str): User role
            - 'db_name' (str): Tenant database name
            - 'billing_db_name' (str): Billing database name
            - 'username' (str): Logged-in user
            - 'session_id' (str): User session ID
            - 'request_received_at' (str): Request timestamp

    Returns:
        dict: A structured response containing:
            - 'flag' (bool): Indicates success or failure.
            - 'data' (list): List of outstanding customer records (when action = "view").
            - 'columns' (list): Table column configuration for UI.
            - 'height' (int): Table height for UI display.
            - 'width' (int): Table width for UI display.
            - 'blob' (str, optional): Base64-encoded Excel file (when action = "download").
            - 'message' (str, optional): Descriptive message when no data is available or an error occurs.
    """
    logging.info("## outstanding_table Function called with data: %s", data)
    action = data.get("action", "")
    start_time = time.time()
    tenant_name = data.get("tenant_name", "")
    tenant_id = data.get("tenant_id", "")
    role_name = data.get("role_name", "")
    columns = [
        {"title": "S. No", "dataIndex": "no", "key": "no", "width": "10%"},
        {
            "title": "Customer ID",
            "dataIndex": "account_number",
            "key": "account_number",
            "width": "10%"
        },
        {
            "title": "Name",
            "dataIndex": "customer_name",
            "key": "customer_name",
            "width": "25%"
        },
        {
            "title": "Email",
            "dataIndex": "email",
            "key": "email",
            "width": "25%"
        },
        {
            "title": "Outstanding",
            "dataIndex": "amount_due",
            "key": "amount_due",
            "width": "20%"
        },
        {
            "title": "Contact",
            "dataIndex": "telephone_number",
            "key": "telephone_number",
            "width": "20%"
        },
        {
            "title": "Agent",
            "dataIndex": "sales_person",
            "key": "sales_person",
            "width": "20%"
        },
        {
            "title": "Account Type",
            "dataIndex": "account_type",
            "key": "account_type",
            "width": "20%"
        }
    ]
    tenant_db_name = data.get("db_name", "")
    try:
        # Initialize database connections using environment variables and configurations
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database = DB(data.get("billing_db_name", ""),**db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_conn = DB(tenant_db_name, **db_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }

    # ----------------------------------------
    # Customer access restriction (handled inline)
    # ----------------------------------------
    customer_names = None  # Default → no restriction

    if role_name not in ("Super Admin", "Partner Admin"):
        # Try using db_config customers if exists
        config_customers = db_config.get("customers")
        logging.info(f"## outstanding_table Applying customer filter from db_config config_customers={config_customers}")
        if config_customers:
            customer_names = normalize_customers_from_config(config_customers)
            if customer_names:
                logging.info(
                    f"## outstanding_table Applying customer filter from db_config customers={customer_names}"
                )
        if not customer_names:  # covers None or empty list
            if action == "view":
                return {
                    "flag": True,
                    "data": [],
                    "columns": columns,
                    "height": 400,
                    "width": 800,
                }

            if action == "download":
                headers = [col["title"] for col in columns]
                empty_df = pd.DataFrame(columns=headers)
                blob_data = dataframe_to_blob(empty_df)
                return {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                    "message": "No data available. Empty Excel generated."
                    }

    try: 
        query = f"""SELECT account_number,customer_name,email,amount_due,telephone_number,sales_person,account_type FROM customer_profiles where tenant_id = %s and amount_due is not null"""
        params = [tenant_id, ]
        if customer_names:
            placeholders = ",".join(["%s"] * len(customer_names))
            query += f" AND customer_name IN ({placeholders})"
            params.extend(customer_names)  
        query += " order by amount_due desc limit 5"
        customer_profiles = killbill_database.execute_query(query, True, params = params)
        contains_float = customer_profiles["telephone_number"].apply(lambda x: isinstance(x, float)).any()
        print("Float exists:", contains_float)
        print(f'customer_profiles------{customer_profiles}')
        customer_profiles.columns = customer_profiles.columns.str.strip()
        
        if action == "download":
            if customer_profiles.empty:
                blob_data = generate_empty_excel()
                # Return JSON response for empty Excel
                response = {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),  # If you need a decoded version
                    "message": "No data available. Empty Excel generated.",
                }
            logging.info("Download action requested.")
            if "amount_due" in customer_profiles.columns:
                customer_profiles["amount_due"] = (
                    pd.to_numeric(customer_profiles["amount_due"], errors="coerce")
                    .fillna(0)
                    .apply(lambda x: "{:,.2f}".format(x))
                )


            customer_profiles.replace(to_replace=[None, "None", "nan", "NaN"], value="", inplace=True)
            customer_profiles = customer_profiles.astype(str)
            # Build mapping dynamically from the columns list
            header_mapping = {
                col["dataIndex"]: col["title"]
                for col in columns
                if col["dataIndex"] != "no"  
            }

            # Apply mapping
            customer_profiles.rename(columns=header_mapping, inplace=True)

            # Add Serial Number column to match the UI table
            customer_profiles.insert(0, "S. No", range(1, len(customer_profiles) + 1))

            blob_data = dataframe_to_blob(customer_profiles)
            logging.info("Blob data prepared for download.")
            response = {"flag": True, "blob": blob_data.decode("utf-8")}


        if action == 'view':
            formatted_data = []
            i = 0
            for idx, row in customer_profiles.iterrows():
                print(f'idx------{idx}')
                print(f'row------{row}')
                formatted_row = {
                    "no": str(i + 1),  # Add index as serial number
                    "key": str(i + 1),  # Use index as key for each row
                    "account_number": row["account_number"],
                    "customer_name": row["customer_name"],  # Column names should match the query result
                    "email": row["email"],
                    "amount_due": "{:,.2f}".format(float(row["amount_due"] or 0)),
                    "telephone_number": row["telephone_number"],
                    "sales_person": row["sales_person"], 
                    "account_type": row["account_type"]
                }
                formatted_data.append(formatted_row)
                i += 1
            response = {
                "flag": True,
                "data": formatted_data,
                "columns": columns,
                "height": 400,
                "width": 800,
            }
       
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "outstanding_table",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched outstanding data',
            "module_name": "BP Dashboards",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")

    except Exception as e:
        print(f"Error occurred while fetching outstanding data: {e}")
        response = {
            "flag": False,
            "message": "Error occurred while fetching outstanding data."
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "outstanding_table",
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "BP Dashboards",
                "request_received_at": data.get("request_received_at", None),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass
    return response

def total_bill_line_graph(data):
    """
        Generates a 12-month line graph of total billed amounts for a tenant.
        Supports both list view and Excel download, with role-based customer filtering.

        Parameters:
            data (dict): Request payload containing:
                - action (str): "view" or "download"
                - tenant_id (int): Tenant identifier
                - partner (str): Tenant name
                - role_name (str): User role (Super Admin, Partner Admin, or restricted user)
                - db_name (str): Tenant database name
                - billing_db_name (str): Billing database name
                - username (str): Logged-in user
                - session_id (str): User session ID
                - request_received_at (str): Request timestamp

        Returns:
            dict: A structured response containing:
                        - 'flag' (bool): Indicates success or failure.
                        - 'data' (dict): Contains total bill line graph data with monthly breakup.
                            - 'title' (str): Chart title.
                            - 'chart_type' (str): Type of chart (line).
                            - 'total_bill_line_graph' (list): Monthly billing values.
                        - 'blob' (str, optional): Base64-encoded Excel file (only when action = "download").
                        - 'filename' (str, optional): Name of the downloaded file.
                        - 'message' (str, optional): Descriptive message when an error occurs.
    """
    start_time = time.time()
    logging.info("### total_bill_line_graph called with data: %s", data)
    action = data.get("action", "")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("partner", "")
    role_name = data.get("role_name", "")
    # Generate list of last 12 months (e.g., Apr 2024 to Mar 2025)
    today = date.today()
    months_list = [
        (today.replace(day=1) - relativedelta(months=i)) for i in reversed(range(12))
    ]
    month_labels = [month.strftime("%b %Y") for month in months_list]
    tenant_db_name = data.get("db_name", "")
    try:
        # Initialize database connections using environment variables and configurations
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database = DB(data.get("billing_db_name", ""),**db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_conn = DB(tenant_db_name, **db_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }

    # ----------------------------------------
    # Customer access restriction (handled inline)
    # ----------------------------------------
    customer_names = None  # Default → no restriction

    if role_name not in ("Super Admin", "Partner Admin"):
        # Try using db_config customers if exists
        config_customers = db_config.get("customers")
        logging.info(f"## total_bill_line_graph Applying customer filter from db_config config_customers={config_customers}")
        if config_customers:
            customer_names = normalize_customers_from_config(config_customers)
            if customer_names:
                logging.info(
                    f"## total_bill_line_graph Applying customer filter from db_config customers={customer_names}"
                )
        if not customer_names:  # covers None or empty list
            if action == "download":
                empty_df = pd.DataFrame(columns=[
                    "Month", "MRC", "NRC", "Taxes", "NA", "CR", "Total"
                ])
                blob_data = dataframe_to_blob(empty_df)
                return {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                    "filename": "Total_Bill_Line_Graph.xlsx"
                }

            return {
                "flag": True,
                "data": {
                    "title": "Total Bill Line Graph",
                    "chart_type": "line",
                    "total_bill_line_graph": []
                }
            }
    try:
        customer_profile_ids = []
        if customer_names:
            placeholders = ",".join(["%s"] * len(customer_names))
            profile_query = f"""
                SELECT id
                FROM customer_profiles
                WHERE tenant_id = %s
                AND customer_name IN ({placeholders})
            """
            profile_params = [tenant_id] + customer_names

            profile_df = killbill_database.execute_query(
                profile_query,
                True,
                params=profile_params
            )
            customer_profile_ids = profile_df["id"].tolist()

        query = f"""
            SELECT mrc, nrc, taxes, applied_services, created_date AS created_at
            FROM customer_bills
            where tenant_id = %s
        """
        bill_params = [tenant_id]

        if customer_profile_ids:
            placeholders = ",".join(["%s"] * len(customer_profile_ids))
            query += f" AND customer_profile_id IN ({placeholders})"
        bill_params.extend(customer_profile_ids)

        df = killbill_database.execute_query(
            query,
            True,
            params=bill_params
        )

        if df.empty:
            if action == "download":
                blob_data = generate_empty_excel()
                response = {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                    "filename": "Total_Bill_Line_Graph.xlsx"
                }
            final_output={
                "title":"Total Bill Line Graph",
                "chart_type":"line",
                "total_bill_line_graph":[]
            }
            response = {"flag": True, "data": final_output}

        # Ensure created_at is datetime
        df["created_at"] = pd.to_datetime(df["created_at"])

        # Pre-fill result structure
        result_data = {
            label: {"month": label,"MRC": 0, "NRC": 0, "Taxes": 0, "NA": 0, "CR": 0, "Total": 0}
            for label in month_labels
        }

        for _, row in df.iterrows():
            created_at = row["created_at"]
            month_label = created_at.strftime("%b %Y")

            if month_label not in result_data:
                continue  # Ignore records outside 12-month range

            result_data[month_label]["MRC"] += row.get("mrc", 0)
            result_data[month_label]["NRC"] += row.get("nrc", 0)
            result_data[month_label]["Taxes"] += row.get("taxes", 0)

            applied_services = row.get("applied_services")
            if applied_services:
                try:
                    applied_services_ids = tuple(ast.literal_eval(applied_services))
                    logging.info(f"###total_bill_line_graph applied_services_ids:{applied_services_ids}")
                    for service_id in applied_services_ids:
                        service_data = killbill_database.get_data(
                            "customer_services",
                            {"id": service_id},
                            ["netwrok_access_fee", "recovery_fee"]
                        )
                        if not service_data.empty:
                            result_data[month_label]["NA"] += service_data["netwrok_access_fee"].iloc[0]
                            result_data[month_label]["CR"] += service_data["recovery_fee"].iloc[0]
                except Exception as e:
                    print(f"Error parsing applied_services: {e}")

        # Calculate Total
        for item in result_data.values():
            for key in ["MRC", "NRC", "Taxes", "NA", "CR"]:
                item[key] = round(float(item[key]), 2)
            item["Total"] = item["MRC"] + item["NRC"] + item["Taxes"] + item["NA"] + item["CR"]

        # Return results sorted by the generated month list
        output = [result_data[label] for label in month_labels]

        if action == "download":
            df_output = pd.DataFrame(output)
            df_output.replace(to_replace="None", value="", inplace=True)
            for col in ["MRC", "NRC", "Taxes", "NA", "CR", "Total"]:
                if col in df_output.columns:
                    df_output[col] = df_output[col].astype(float).round(2)

            df_output.replace(to_replace=[None, "None", "nan", "NaN"], value="", inplace=True)
            for col in ["MRC", "NRC", "Taxes", "NA", "CR", "Total"]:
                if col in df_output.columns:
                    df_output[col] = (
                        pd.to_numeric(df_output[col], errors="coerce")
                        .fillna(0)
                        .apply(format_amount)
                    )
            # Rename columns explicitly to maintain capitalization
            df_output.rename(columns={
                "month": "Month",
                "MRC": "MRC",
                "NRC": "NRC",
                "Taxes": "Taxes",
                "NA": "NA",
                "CR": "CR",
                "Total": "Total"
            }, inplace=True)

            df_output = df_output.astype(str)
            blob_data = dataframe_to_blob(df_output)
            response = {
                "flag": True,
                "blob": blob_data.decode("utf-8"),
                "filename": "Total_Bill_Line_Graph.xlsx"
            }
        
        elif action == "view":
            final_output={
                "title":"Total Bill Line Graph",
                "chart_type":"line",
                "total_bill_line_graph":output
            }
            response = {
                "flag": True,
                "data": final_output
            }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "total_bill_line_graph",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("partner", ""),
            "comments": 'Successfully fetched bill data',
            "module_name": "BP Dashboards",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
    except Exception as e:
        logging.info(f'Error occurred while fetching bill data: {e}')
        response = {
            "flag": False,
            "message": "Error occurred while fetching bill data."
        }
        message = str(e)
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "total_bill_line_graph",
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": message,
                "module_name": "BP Dashboards",
                "request_received_at": data.get("request_received_at", None),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except:
            pass
    return response

def total_bill_by_ledger_bar(data):
    pass

def bp_dashboards(data):
    killbill_database = DB(data.get("billing_db_name", ""), **db_config)
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    table_name = data.get('table_name','customer_profiles')
    role_name = data.get('role_name', '')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')
    tenant_id=data.get('tenant_id',None)
    mode=os.getenv('ENV','')
    if mode=='UAT':
        if tenant_name == 'Altaworx Test':
            tenant_name = 'Altaworx'
            tenant_id = 1

    db_name=data.get('db_name', "altaworx_test")
    if not db_name or db_name=="null":
        db_name="altaworx_test"
    try:
        # Fetch user-specific header mappings for UI display
        header_map = get_headers_mapping(killbill_database,["Billing Customer Profiles"],role_name, '', '', '', '',data)

        # Serialize customer data for API response
        data_dict_all = {}
        # print(f'###data_dict_all {data_dict_all}')

        # Construct and return the success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map
        }
        return response

    except Exception as e:
        # Log the exception and return a failure response
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}
        }
        return response


def format_amount(value):
    try:
        return "{:,.2f}".format(float(value))
    except (TypeError, ValueError):
        return value

def collections_summary(data):
    """
    Retrieves the Collections Summary for a tenant with pagination, sorting, and role-based customer filtering.
    Supports both list view and Excel download.

    Parameters:
        data (dict): Request payload containing:
            - action (str): "view" or "download"
            - role_name (str): User role (Super Admin, Partner Admin, or restricted user)
            - tenant_id (int): Tenant identifier
            - tenant_name (str): Tenant name
            - db_name (str): Tenant database name

    Returns:
        dict: When action="view"
            - flag (bool): Success or failure
            - message (str): Status message
            - data (dict): Collections summary records
            - header_map (dict): UI header mapping
            - pages (dict): Pagination info (start, end, total)
        OR
        dict: When action="download"
            - flag (bool)
            - blob (str): Base64 encoded Excel file
    """
    start_time = time.time()
    logging.info(f"## collections_summary function started with data: {data}")
    action = data.get("action", "")
    role_name = data.get("role_name", "")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    mode=os.getenv('ENV', '')
    col_sort = data.get("col_sort", "")
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    limit = end - start
    offset = start
    tenant_db_name = data.get("db_name", "")
    try:
        # Initialize database connections using environment variables and configurations
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database = DB(data.get("billing_db_name", ""),**db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_conn = DB(tenant_db_name, **db_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }

    header_map = get_headers_mapping(killbill_database,["Collections Summary"], role_name, '', '', '', '', data)

    # ----------------------------------------
    # Customer access restriction (handled inline)
    # ----------------------------------------
    customer_names = None  # Default → no restriction

    if role_name not in ("Super Admin", "Partner Admin"):
        # Try using db_config customers if exists
        config_customers = db_config.get("customers")
        logging.info(f"## collections_summary Applying customer filter from db_config config_customers={config_customers}")
        if config_customers:
            customer_names = normalize_customers_from_config(config_customers)
            if customer_names:
                logging.info(
                    f"## collections_summary Applying customer filter from db_config customers={customer_names}"
                )
        if not customer_names:  # covers None or empty list
            if action == "download":
                empty_df = pd.DataFrame(columns=[
                    "Customer Name", "Account Number", "Bill Due Date",
                    "Amount Due", "Collection Name", "Current Step",
                    "Step Details", "Days Late", "Collection Status"
                ])
                blob_data = dataframe_to_blob(empty_df)
                return {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                }
    
            return {
                "flag": True,
                "message": "No data available",
                "data": {"collections_summary": []},
                "header_map": header_map,
                "pages": {
                    "start": start,
                    "end": end,
                    "total": 0
                }
            }
    try:
        #fetch total_count
        total_count_query = f"""
        select count(*) as total_count
        from vw_collection_history where is_active = true and tenant_id = %s"""
        params = [tenant_id]
        if customer_names:
            placeholders = ",".join(["%s"] * len(customer_names))
            total_count_query += f" AND customer_name IN ({placeholders})"
            params.extend(customer_names)
        total_count_df = killbill_database.execute_query(total_count_query, True, params = params)
        total_count = total_count_df['total_count'].iloc[0]

        pages_data = {
                "start": start,
                "end": end,
                "total": int(total_count)
            }

        # Fetch collections history data
        collection_history_query = f"""
            select customer_name, account_number, due_date_of_this_bill, amount_due,
                template_description, day, step_description, days_left, collection_status
            from vw_collection_history
            where is_active = true and tenant_id = %s"""
        params = [tenant_id]
        if customer_names:
            placeholders = ",".join(["%s"] * len(customer_names))
            collection_history_query += f" AND customer_name IN ({placeholders})"
            params.extend(customer_names)
        if col_sort:
            order = {k: v.lower() for k, v in col_sort.items()}
            order_by = list(order.keys())[0]          # Extract column name
            order_direction = order[order_by]         # Already lowercase
            collection_history_query += f" ORDER BY {order_by} {order_direction}"
        collection_history_query += " LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        collection_history_df = killbill_database.execute_query(collection_history_query, True, params = params )
        collection_history_df["amount_due"] = collection_history_df["amount_due"].apply(format_amount)
        column_mapping = {
            "customer_name": "Customer Name",
            "account_number": "Account Number",
            "due_date_of_this_bill": "Bill Due Date",
            "amount_due": "Amount Due",
            "template_description": "Collection Name",
            "day": "Current Step",
            "step_description":"Step Details",
            "days_left": "Days Late",
            "collection_status": "Collection Status"
        }
        if action == "download":
            collection_history_df = pd.DataFrame(collection_history_df)
            logging.info("Preparing Excel download for Collections Summary.")
            if collection_history_df.empty:
                logging.info("No data available. Empty Excel generating.")
                collection_history_df = pd.DataFrame(columns=column_mapping.values())
                blob_data = dataframe_to_blob(collection_history_df)
                response = {
                    "flag": True,
                    "blob": blob_data.decode("utf-8"),
                    "message": "No data available. Empty Excel generated."
                }
                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                time_consumed = int(float(time_consumed))
                audit_data_user_actions = {
                    "service_name": "collections_summary",
                    "created_by": data.get("username", ""),
                    "status": str(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "session_id": data.get("session_id", ""),
                    "tenant_name": data.get("Partner", ""),
                    "comments": 'No data available. Empty Excel generated.',
                    "module_name": "BP Dashboards",
                    "request_received_at": data.get("request_received_at", None)
                }
                database.update_audit(audit_data_user_actions, "audit_user_actions")
                return response
            collection_history_df.replace(to_replace="None", value="", inplace=True)
            collection_history_df["day"] = collection_history_df["day"].fillna(0).astype(int)
            collection_history_df["days_left"] = collection_history_df["days_left"].fillna(0).astype(int)
            # Format Bill Due Date column cleanly before export
            if "due_date_of_this_bill" in collection_history_df.columns:
                collection_history_df["due_date_of_this_bill"] = collection_history_df["due_date_of_this_bill"].apply(
                    lambda x: x.strftime("%m-%d-%y") if isinstance(x, (datetime, pd.Timestamp)) 
                    else (str(x)[:10] if isinstance(x, str) and re.match(r"\d{4}-\d{2}-\d{2}", x) else "")
                )
            collection_history_df.rename(columns=column_mapping, inplace=True)

            collection_history_df = collection_history_df.astype(str)

            blob_data = dataframe_to_blob(collection_history_df)
            logging.info("Blob data prepared for download.")
            response = {"flag": True, "blob": blob_data.decode("utf-8")}
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "collections_summary",
                "created_by": data.get("username", ""),
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": 'Successfully downloaded Collections History data',
                "module_name": "BP Dashboards",
                "request_received_at": data.get("request_received_at", None)
            }
            database.update_audit(audit_data_user_actions, "audit_user_actions")
            return response
        
        formatted_data = []
        for i, row in collection_history_df.iterrows():
            formatted_row = {
                "key": str(i + 1),
                "customer_name": row["customer_name"],
                "account_number": row["account_number"],
                "due_date_of_this_bill": row["due_date_of_this_bill"].strftime("%m-%d-%y") if row["due_date_of_this_bill"] else None,
                "amount_due": row["amount_due"],
                "template_description": row["template_description"],
                "day": row["day"],
                "step_description": row["step_description"],
                "collection_status": row["collection_status"],
                "days_left": row["days_left"]
            }
            formatted_data.append(formatted_row)

        # response = {
        #     "flag": True,
        #     "data": formatted_data,
        #     "columns": columns,
        #     "height": 400,
        #     "width": 800,
        # }
        data_dict_all = {"collections_summary": serialize_data(formatted_data)}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "collections_summary",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": 'Successfully fetched Collections History data',
            "module_name": "BP Dashboards",
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
    except Exception as e:
        logging.info(f'Error occurred while fetching collection summary data: {e}')
        response = {
            "flag": False,
            "message": "Error occurred while fetching collection summary data."
        }
        message = str(e)
        error_type = str(type(e).__name__)
        # Log error to database
        error_data = {
            "service_name": "collections_summary",
            "error_message": message,
            "error_type": error_type,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("Partner", ""),
            "comments": str(response["message"]),
            "module_name": "BP Dashboards",
            "request_received_at": data.get("request_received_at", None),
        }
        database.log_error_to_db(error_data, "error_log_table")
    return response

def normalize_customers_from_config(customers):
    if not customers:
        return None

    # Already tuple/list
    if isinstance(customers, (list, tuple)):
        return sorted(set(c.strip() for c in customers if c and str(c).strip()))

    # Tuple-like string → convert safely
    if isinstance(customers, str):
        cleaned = customers.strip()

        try:
            parsed = ast.literal_eval(cleaned)

            if isinstance(parsed, (list, tuple)):
                return sorted(
                    set(str(c).strip() for c in parsed if c and str(c).strip())
                )
        except Exception:
            pass

        # Fallback: CSV-style
        cleaned = cleaned.strip("()")
        return sorted(
            set(
                c.strip().strip("'").strip('"')
                for c in cleaned.split(",")
                if c.strip()
            )
        )

    return None
