"""
@Author1 : Srikanth R
Created Date: 27-12-2024
"""

# Importing the necessary Libraries
import ast
import boto3
import os
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
import datetime
from datetime import time
from datetime import datetime, timedelta
import time
from io import BytesIO
from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
import pytds
from pytz import timezone
import numpy as np
from collections import defaultdict
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import xml.etree.ElementTree as ET
from io import StringIO
import xml.etree.ElementTree as ET
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
import pandas as pd



# Dictionary to store database configuration settings retrieved from environment variables.
common_utils_database_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="billing_payments")


def clean_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        print(f"Exception while converting")
        return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name,readme_flag):
    """
    Creates a database configuration dictionary with user-specific filters based on tenant and role.

    Args:
        user (str): Username to look up permissions for
        db_config_making (dict): Base database configuration to extend
        tenant_database (str): Name of the tenant database
        tenant_name (str): Name of the tenant
        role_name (str): User's role (e.g., 'Super Admin')
        readme_flag (bool): Flag to determine query format (client_id vs user_name)

    Returns:
        dict: Modified database configuration with user-specific filters
    """
    logging.info(f"db_config_maker is in progress {role_name}")
    # Connect to common_utils database to get tenant info
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"],**common_utils_database_config)
    # Get tenant ID and parent tenant ID
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    # Bypass filtering for Super Admin users
    if role_name in ('Super Admin','Partner Admin') and not parent_tenant_id:
        logging.info(f"Getting access filters for  in tenant: {tenant_name} with role: {role_name} in if condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name in ('Super Admin','Partner Admin') and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in else condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name =="Agent Partner Admin" and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in elif second condition")
        pass
    else:
        logging.info(f"Getting access filin tenant: {tenant_name} with role: {role_name} in else condition")
        pass
    if tenant_id:
        tenant_id=int(tenant_id)
    #Get user permissions from mapping table
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)
        if filters.empty:
            query = f"""
                SELECT customers, service_provider, customer_group
                FROM user_module_tenant_mapping
                WHERE user_name = '{user}' AND tenant_id = {tenant_id}
            """
            filters = common_utils_database.execute_query(query, True)
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

        filters = common_utils_database.execute_query(query, True)
    # Connect to tenant database
    database = DB(tenant_database, **db_config)
    # Extract customer group if exists
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    # If user has a customer group, get additional filters from it
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            # Extract rate plan names
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
            # Extract customer names
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
                customer_names=None
            # Extract billing account number
            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception("Error extracting billing_account_number:", e)
                billing_account_number=None
            # Extract feature codes
            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception("Error extracting feature_codes:", e)
    # Set customer filter - use customer group names if available, otherwise use direct mapping
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    #customer=clean_tuple(customer)
    # Get service provider info and convert names to IDs
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    # Get additional customers created by this user
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer_list = [customer]
                elif isinstance(customer, tuple):
                    customer_list = list(customer)
                else:
                    customer_list = customer  # Already a list

                fixed_customer_list = customer_list.copy()

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info('customer_list before extend:', customer_list)

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info('customer_list after extend:', fixed_customer_list)

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info('final customer tuple:', customer)
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Get additional rate plans created by this user
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas
                logging.info('customer_ rate plan list before extend:', fixed_customer_rate_plan_list)

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info('customer rate plan_list after extend:', fixed_customer_rate_plan_list)

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info('final customer rate plan tuple:', customer_rate_plan_name)

    except Exception as e:
        logging.exception(f"Error while fetching the customers  for the user {user} in tenant {tenant_name}: {e}")
    # Update configuration with all filters
    logging.info(f"{user} user is service_provider is {service_provider} and service_provider_id is {service_provider_id} and ")
    if role_name =="Agent Partner Admin" and parent_tenant_id:
        db_config_making["customers"] = None
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = None
        db_config_making["feature_codes"] = None
        db_config_making["billing_account_number"] = None
        return db_config_making
    else:
        db_config_making["customers"] = customer
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
        db_config_making["feature_codes"] = feature_codes
        db_config_making["billing_account_number"] = billing_account_number
        return db_config_making

def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    try:
        current_time = datetime.now()
        logging.info(f"###{path},time started : {current_time}, data received is : {data}")
    except Exception as e:
        logging.error(f"Error in function_caller: {e}")
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    logging.info(f"### db_config created is : {db_config}")
    access_token = data.get("z_access_token",None)
    tenant_database = data.get("db_name")
    if not access_token:
        role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        readme_flag=False
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
        logging.info(f"db_config is created {path}")
    else:
        ##API Call
        logging.info(f"db_config will be created for service accountss")
        logging.info(f"path gotten is {path}")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        user = data.get("client_id", "")
        service_data = common_utils_database.get_data(
            "service_accounts", {"client_id": user,"is_active":"True"}
        )

        if service_data.empty:
            logging.info(f"Invalid client ID: {user}")
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}
        )
        tenant_database = tenant_data["db_name"].to_list()[0]
        data['tenant_name']=tenant_name
        data['db_name']=tenant_database
        readme_flag=True
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
    # Map API paths to corresponding handler functions
    path_function_map = {
        "/billing_payments_bills_list_view": billing_payments_bills_list_view,
        "/all_payment_history_list_view": all_payment_history_list_view,
        "/charge_by_service_list_view": charge_by_service_list_view,
        "/charge_overview_list_view": charge_overview_list_view,
        "/get_export_status": get_export_status,
        "/export_to_s3_bucket_": export_to_s3_bucket_,
        "/charge_overview_export": charge_overview_export,
        "/charge_by_service_export": charge_by_service_export,
        "/bills_export": bills_export,
        "/payments_history_export": payments_history_export,
    }    # Route to the correct function based on the path
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


def db_config_maker_2_1_2026(user,db_config_making):
    """
    Creates and returns an updated database configuration by adding customer 
    and service provider details for the given user.

    This function:
    - Connects to the COMMON_UTILS_DATABASE
    - Fetches the customers and service providers assigned to the user
    - Updates the db_config_making dictionary with these details

    Args:
        user (str): The username for which to fetch customer and service provider data.
        db_config_making (dict): Basic DB connection config (host, port, user, password)

    Returns:
        dict: Updated db_config with 'customers' and 'service_providers' keys added.
    """

    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config_making)

    query=f"select customers,service_provider from users where username ='{user}'"
    filters=common_utils_database.execute_query(query,True)
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting customer: {str(e)}")
      customer= None     

    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting service_provider: {str(e)}")
      service_provider=None   

    db_config_making["customers"]= customer
    db_config_making["service_providers"]=service_provider

    return db_config_making

def function_caller_2_1_2026(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    try:
        current_time = datetime.now()
        logging.info(f"###{path},time started : {current_time}, data received is : {data}")
    except Exception as e:
        logging.error(f"Error in function_caller: {e}")
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    db_config_making = db_config_maker(user, db_config)
    db_config = db_config_making
    logging.info(f"### db_config created is : {db_config}")

    # Map API paths to corresponding handler functions
    path_function_map = {
        "/billing_payments_bills_list_view": billing_payments_bills_list_view,
        "/all_payment_history_list_view": all_payment_history_list_view,
        "/charge_by_service_list_view": charge_by_service_list_view,
        "/charge_overview_list_view": charge_overview_list_view,
        "/get_export_status": get_export_status,
        "/export_to_s3_bucket_": export_to_s3_bucket_,
        "/charge_overview_export": charge_overview_export,
        "/charge_by_service_export": charge_by_service_export,
        "/bills_export": bills_export,
        "/payments_history_export": payments_history_export,
    }
    # Route to the correct function based on the path
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")

    try:
        logging.info("tenant_name is",tenant_name)
        # Retrieve tenant ID based on tenant name
        tenant_id = database.get_data(
            "tenant", {"tenant_name": tenant_name},["id"]
        )["id"].to_list()[0]
    except Exception as e:
        logging.warning(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database, parent_module_name, role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out




def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        logging.info(f'INchanged_data---------{changed_data}---{unique_id}------{table_name}')

        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            logging.info("***update_data",update_data)
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """Convert timestamp columns in the provided dictionary list to the tenant's timezone."""
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at','date','due_date_of_this_bill']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y')  # Ensure it's a string
    return df_dict

def data_update_db_account_number(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            logging.info("***update_data",update_data)
            # Perform the update operation
            db.update_dict(table_name, update_data, {"account_number": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object

def apply_cc_fee(payment_method, fee_setting, payment_type):
    """
    Determines if a credit card (CC) fee should be applied for a given payment attempt.

    The logic considers:
    - The user's payment method (must be credit card/card payment).
    - The system or tenant's fee configuration (applies to all, only manual, or only auto-debit CC payments).
    - The context of the payment (manual or auto-debit).

    Returns:
    - True if a CC fee is applicable based on conditions.
    - False if fee should not be applied or in case of any exception.

    Parameters:
    - payment_method (str): The payment method used (e.g., "Card Payment", "Credit Card").
    - fee_setting (str): Tenant's fee setting ("all cc payments", "only manual payments", "only auto-debit payments").
    - payment_type (str): Payment context ("manual", "auto-debit").
    """
    try:
        logging.info(f'## apply_cc_fee fucntion called with payment_method {payment_method} fee_setting {fee_setting} payment_type {payment_type}')
        # Normalize input for consistent case comparison and handling empty/null
        payment_method = (payment_method or "").strip().lower()
        fee_setting = (fee_setting or "").strip().lower()
        payment_type = (payment_type or "").strip().lower()

        # Apply fee only if the payment method is a credit card
        if payment_method != "card payment" and payment_method != "credit card":
            return False
        # Fee applies to all credit card payments
        if fee_setting == "all cc payments":
            return True
        # Fee applies only to manual CC payments
        elif fee_setting == "only manual payments" and payment_type == "manual":
            return True
        # Fee applies only to auto-debit CC payments
        elif fee_setting == "only auto-debit payments" and payment_type == "auto-debit":
            return True
        # For any other condition, do not apply fee
        return False
    except Exception as e:
        logging.info(f'## apply_cc_fee exception occured as e {e}')
        return False


def credit_card_fee_accounts_by_tenant(data):
    """
    Fetches the credit card fee for each account under a given tenant.

    Input:
        data = {
            "tenant_id": "TENANT123"
        }

    Output:
        {
            "account_number_1": credit_card_fee_value,
            "account_number_2": credit_card_fee_value,
            ...
        }

    Logic:
        1. Fetch account_number, credit_card_fee from customer_profiles where tenant_id matches.
        2. Fetch default_settings for all tenants (includes enable_credit_card_fee_type and credit_card_fee).
        3. For each account:
           - Decide if fee applies using apply_cc_fee()
           - Use customer-specific fee if exists, otherwise tenant default.
           - Return the computed mapping as a dict.
    """

    try:
        tenant_id = data.get("tenant_id")
        if not tenant_id:
            return {"status": "error", "message": "tenant_id is required"}
        mode = os.environ.get("ENV", "")
        if mode == "UAT" and str(tenant_id) == '212':
            tenant_id = 1
            tenant_name = 'Altaworx'
        logging.info(f"## credit_card_fee_accounts_by_tenant called for tenant_id: {tenant_id}")
        billing_db_name = data.get('billing_db_name',None)
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        killbill_database = DB(billing_db_name, **db_config)

        # Step 1: Fetch account_number and credit_card_fee for the tenant
        customer_profiles_df = killbill_database.get_data(
            "customer_profiles",
            {"tenant_id": tenant_id},
            ["account_number", "credit_card_fee"]
        )

        if customer_profiles_df.empty:
            logging.info(f"## credit_card_fee_accounts_by_tenant No customer profiles found for tenant_id {tenant_id}")
            return {}

        profiles = customer_profiles_df.to_dict(orient="records")

        # Step 2: Fetch default_settings for all tenants
        default_settings_map = {}
        try:
            default_settings_df = killbill_database.get_data(
                "default_settings",
                {},
                ["sub_tenant_id", "enable_credit_card_fee_type", "credit_card_fee"]
            )

            default_settings_map = {
                str(row["sub_tenant_id"]): {
                    "fee_setting": row["enable_credit_card_fee_type"],
                    "default_fee": float(row.get("credit_card_fee") or 0)
                }
                for row in default_settings_df.to_dict(orient="records")
            }

        except Exception as e:
            default_settings_map = {}
            logging.info(f"## credit_card_fee_accounts_by_tenant Exception fetching default_settings: {e}")

        logging.info(f"## credit_card_fee_accounts_by_tenant fetched default_settings_map: {default_settings_map}")

        # Step 3: Build account_number -> credit_card_fee_value map
        account_number_credit_card_fee_map = {}

        for profile in profiles:
            acc_no = profile.get("account_number")
            if not acc_no:
                continue

            tenant_defaults = default_settings_map.get(str(tenant_id), {})
            default_fee_percentage = tenant_defaults.get("default_fee", 0)
            fee_setting = tenant_defaults.get("fee_setting", "")

            should_apply_fee = apply_cc_fee(
                payment_method="card payment",
                fee_setting=fee_setting,
                payment_type="auto-debit"
            )

            fee_percentage = float(profile.get("credit_card_fee") or default_fee_percentage)

            if should_apply_fee and fee_percentage > 0:
                # Since this API is not tied to a specific transaction, we can just return % value
                credit_card_fee_value = round(fee_percentage, 2)
            else:
                credit_card_fee_value = 0.0

            account_number_credit_card_fee_map[acc_no] = credit_card_fee_value

        logging.info(f"## Final credit_card_fee_accounts_by_tenant result: {account_number_credit_card_fee_map}")

        return account_number_credit_card_fee_map

    except Exception as e:
        logging.error(f"## credit_card_fee_accounts_by_tenant Exception: {e}")
        return {}

def due_bills_data_for_multiple_accounts(killbill_database, active_default_payment_accounts, active_default_payment_accounts_ids,  profile_map):
    try:
        logging.info(f"## due_bills_data_for_multiple_accounts called for accounts: {active_default_payment_accounts}, IDs: {active_default_payment_accounts_ids}, profile_map: {profile_map}")
 
        bills_df = killbill_database.get_data_bp(
            table_name="customer_bills",
            condition={
                "customer_profile_id": active_default_payment_accounts_ids,
                "amount_due": [">", 0],
                "is_active": True
            },
            columns=["id", "amount_due", "customer_profile_id"],
        )
        if bills_df is None or bills_df.empty:
            return {}
       
        bills = bills_df.to_dict(orient="records")
       
        from collections import defaultdict # for default dict - auto-creates default values
        result_dict = defaultdict(lambda: {"bill_list": [], "bill_total": 0})
       
        for row in bills:
            acc_num = profile_map[row["customer_profile_id"]]  # map customer_profile_id → account number
            result_dict[acc_num]["bill_list"].append(str(row["id"]))
            result_dict[acc_num]["bill_total"] += float(row["amount_due"])
       
        # Round values
        for acc in result_dict:
            result_dict[acc]["bill_total"] = round(result_dict[acc]["bill_total"], 2)
       
        return dict(result_dict)
 
    except Exception as e:
        logging.info(f"## Exception in due_bills_data_for_multiple_accounts => {e}")
        return [],0.0

def normalize_customers_from_config(customers):
    if not customers:
        return None

    # Already tuple/list
    if isinstance(customers, (list, tuple)):
        return sorted(set(c.strip() for c in customers if c and str(c).strip()))

    # Tuple-like string → convert safely
    if isinstance(customers, str):
        cleaned = customers.strip()

        try:
            parsed = ast.literal_eval(cleaned)

            if isinstance(parsed, (list, tuple)):
                return sorted(
                    set(str(c).strip() for c in parsed if c and str(c).strip())
                )
        except Exception:
            pass

        # Fallback: CSV-style
        cleaned = cleaned.strip("()")
        return sorted(
            set(
                c.strip().strip("'").strip('"')
                for c in cleaned.split(",")
                if c.strip()
            )
        )

    return None

def billing_payments_bills_list_view_2_1_2026(data):
    """
    Retrieves a list of billing and collections bills from the database, including pagination details and tenant-specific
    timezone handling. The function fetches the total count of records, applies pagination using the provided start and
    end indices, and formats the results for display. It also handles timezone conversion for timestamps and prepares
    the response with necessary data, including pagination and header information.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name, used for permissions and access control.
            - tenant_name (str): The tenant name, used for tenant-specific operations.
            - mod_pages (dict): Pagination details, including 'start' (starting index) and 'end' (ending index).

    Returns:
        dict: A dictionary containing the following:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message indicating the result of fetching the billing and collections bills.
            - data (dict): Data for the billing and collections bills, including the paginated list of records.
            - header_map (dict): Mapping for headers based on user role.
            - pages (dict): Pagination details (start, end, total).
    """
    try:
        # DB Parameter Validation
        billing_db_name = data.get('billing_db_name',None)
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        
        # DB Connections
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database =  DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # UI Parameter's
        tenant_database=data.get('db_name','')
        role_name = data.get('role_name', '')
        tenant_name =data.get('tenant_name','')
        col_sort = data.get("col_sort", "")
        tenant_id = data.get('tenant_id', '')
        mode=os.getenv('ENV','')

        username = data.get("username", "")
        tenant_database_conn = DB(tenant_database, **db_config)
        
        # ---------------- CUSTOMER NAME FILTER (db_config only) ----------------
        customer_filter = ""
        customer_params = []

        if role_name not in ("Super Admin", "Partner Admin"):

            config_customers = db_config.get("customers")
            customers = normalize_customers_from_config(config_customers)

            if customers:
                logging.info(
                    f"## billing_payments_bills_list_view Applying customer filter from db_config customers={customers}"
                )
                placeholders = ",".join(["%s"] * len(customers))
                customer_filter = f" AND customer_name IN ({placeholders})"
                customer_params = customers
            else:
                logging.info(
                    "## billing_payments_bills_list_view No customers in db_config → no customer filter applied"
                )

        # Mode Validation
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        
        # Set default pagination if not provided
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)

        limit = end - start
        offset = start

        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')
        # Get tenant's timezone
        tenant_name = data.get('tenant_name', '')
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

            # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly
        # total number of records
        try:
            if start_date:
                total_count_query = f"""
                    SELECT id
                    FROM billing_list_view
                    WHERE created_date BETWEEN %s AND %s
                    AND tenant_id = %s
                    AND is_active = 'true'
                    AND COALESCE(amount_due, 0) > 0
                    {customer_filter}
                """
                params = [start_date, end_date, tenant_id] + customer_params
            else:
                total_count_query = f"""
                    SELECT id
                    FROM billing_list_view
                    WHERE tenant_id = %s
                    AND is_active = 'true'
                    AND COALESCE(amount_due, 0) > 0
                    {customer_filter}
                """
                params = [tenant_id] + customer_params
            total_count_result=killbill_database.execute_query(total_count_query, params=params)
        except Exception as e:
            total_count_result=[]
            print(f"ERROR:{e}")
        total_count=len(total_count_result['id'].to_list())
        
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        
        # for sorting
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY modified_date desc"

        # fetching list view data
        if start_date:
            query = f"""
                SELECT *
                FROM billing_list_view
                WHERE created_date BETWEEN %s AND %s
                AND tenant_id = %s
                AND is_active = 'true'
                AND COALESCE(amount_due, 0) > 0
                {customer_filter}
                {order_clause}
                LIMIT %s OFFSET %s
            """
            params = (
                [start_date, end_date, tenant_id]
                + customer_params
                + [limit, offset]
            )
        else:
            query = f"""
                SELECT *
                FROM billing_list_view
                WHERE tenant_id = %s
                AND is_active = 'true'
                AND COALESCE(amount_due, 0) > 0
                {customer_filter}
                {order_clause}
                LIMIT %s OFFSET %s
            """
            params = [tenant_id] + customer_params + [limit, offset]

        logging.info(f"###billing_payments_bills_list_view query:{query}")
        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")
        
        logging.info(f"###billing_payments_bills_list_view df_dict:{df_dict}")
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        # header maps
        header_map = get_headers_mapping(tenant_database,["Billing and Payments Billing"],role_name, '', '', '', '',data)
        logging.info(f"### billing_payments_bills_list_view header_map:{header_map}")
        data_dict_all = {"billing_and_payments_billing": serialize_data(df_dict)}
        logging.info(f"###billing_payments_bills_list_view data_dict_all:{data_dict_all}")
        # Fetch active default payment accounts using get_data ---
        try:
            # Step 1: Get accounts with default payment
            default_payment_df = killbill_database.get_data(
                "payment_methods",
                {"default_payment": True},
                ["account_number"]
            )
            default_payment_accounts = (
                default_payment_df["account_number"].dropna().astype(str).tolist()
                if default_payment_df is not None and not default_payment_df.empty else []
            )

            if default_payment_accounts:
                # Step 2: Get only active accounts from customer_profiles
                active_accounts_df = killbill_database.get_data(
                    "customer_profiles",
                    {"account_number": default_payment_accounts, "is_active": True},
                    ["id", "account_number"]
                )
                active_default_payment_accounts = (
                    active_accounts_df["account_number"].dropna().astype(str).tolist()
                    if active_accounts_df is not None and not active_accounts_df.empty else []
                )
                active_default_payment_accounts_ids = (
                    active_accounts_df["id"].dropna().astype(str).tolist()
                    if active_accounts_df is not None and not active_accounts_df.empty else []
                )
                profile_map = active_accounts_df.set_index("id")["account_number"].to_dict()
            else:
                active_default_payment_accounts = []
                active_default_payment_accounts_ids = []
                profile_map = {}
 
            logging.info(f"## Active default payment accounts: {active_default_payment_accounts}")
 
        except Exception as e:
            logging.info(f"## Error fetching active default payment accounts: {e}")
            active_default_payment_accounts = []
        try:
            account_due_summary = due_bills_data_for_multiple_accounts(
                killbill_database,
                active_default_payment_accounts,
                active_default_payment_accounts_ids,
                profile_map,
            )
        except Exception as e:
            logging.info(f"billing_collections_bills_list_view function : Exception occurred: {e}")
            account_due_summary = {}
        # Include in response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "eligible_accounts": active_default_payment_accounts,
            "credit_card_fee": credit_card_fee_accounts_by_tenant(data),
            "changed_data": account_due_summary
        }
        return response

    except Exception as e:
        logging.exception(f"###billing_payments_bills_list_view :Exception occurred: {e}")
        error_data = {
            "service_name": "billing_payments_bills_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Bills list",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Payments  list",
            "data": {}  # Return empty dictionary on error
        }
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response

def billing_payments_bills_list_view(data):
    """
    Retrieves a list of billing and collections bills from the database, including pagination details and tenant-specific
    timezone handling. The function fetches the total count of records, applies pagination using the provided start and
    end indices, and formats the results for display. It also handles timezone conversion for timestamps and prepares
    the response with necessary data, including pagination and header information.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name, used for permissions and access control.
            - tenant_name (str): The tenant name, used for tenant-specific operations.
            - mod_pages (dict): Pagination details, including 'start' (starting index) and 'end' (ending index).

    Returns:
        dict: A dictionary containing the following:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message indicating the result of fetching the billing and collections bills.
            - data (dict): Data for the billing and collections bills, including the paginated list of records.
            - header_map (dict): Mapping for headers based on user role.
            - pages (dict): Pagination details (start, end, total).
    """
    logging.info("###billing_payments_bills_list_view called with data: %s", data)
    start_time = time.time()
    try:
        # DB Parameter Validation
        billing_db_name = data.get('billing_db_name',None)
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        
        # DB Connections
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        killbill_database =  DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }
    try:
        # UI Parameter's
        tenant_database=data.get('db_name','')
        role_name = data.get('role_name', '')
        tenant_name =data.get('tenant_name','')
        col_sort = data.get("col_sort", "")
        tenant_id = data.get('tenant_id', '')
        
        # Set default pagination if not provided
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)

        limit = end - start
        offset = start

        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')
        # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)

        # total number of records
        try:
            if start_date:
                total_count_query = f"""
                    SELECT id
                    FROM billing_list_view
                    WHERE created_date BETWEEN %s AND %s
                    AND tenant_id = %s
                    AND is_active = 'true'
                    AND COALESCE(amount_due, 0) > 0
                """
                params = [start_date, end_date, tenant_id]
            else:
                total_count_query = f"""
                    SELECT id
                    FROM billing_list_view
                    WHERE tenant_id = %s
                    AND is_active = 'true'
                    AND COALESCE(amount_due, 0) > 0
                """
                params = [tenant_id]
            total_count_result=killbill_database.execute_query(total_count_query, params=params)
        except Exception as e:
            total_count_result=[]
            print(f"ERROR:{e}")
        total_count=len(total_count_result['id'].to_list())
        
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }
        
        # for sorting
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY modified_date desc"

        # fetching list view data
        if start_date:
            query = f"""
                SELECT *
                FROM billing_list_view
                WHERE created_date BETWEEN %s AND %s
                AND tenant_id = %s
                AND is_active = 'true'
                AND COALESCE(amount_due, 0) > 0
                {order_clause}
                LIMIT %s OFFSET %s
            """
            params = (
                [start_date, end_date, tenant_id]
                + [limit, offset]
            )
        else:
            query = f"""
                SELECT *
                FROM billing_list_view
                WHERE tenant_id = %s
                AND is_active = 'true'
                AND COALESCE(amount_due, 0) > 0
                {order_clause}
                LIMIT %s OFFSET %s
            """
            params = [tenant_id]  + [limit, offset]

        logging.info(f"###billing_payments_bills_list_view query:{query}")
        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        amount_fields = [
            "charges",
            "credits",
            "payments",
            "total",
            "amount_due",
            "remaining",
        ]

        for record in df_dict:
            # Format numeric monetary fields
            for field in amount_fields:
                if field in record:
                    record[field] = format_amount(record.get(field, 0))

            # Special handling for taxes (example: "Tax$3.39")
            taxes_value = record.get("taxes")
            if taxes_value:
                try:
                    # Extract numeric part from string
                    match = re.search(r"([\d.]+)", str(taxes_value))
                    if match:
                        formatted_tax = format_amount(match.group(1))
                        record["taxes"] = f"Tax${formatted_tax}"
                except Exception:
                    pass

        # header maps
        header_map = get_headers_mapping(tenant_database,["Billing and Payments Billing"],role_name, '', '', '', '',data)
        data_dict_all = {"billing_and_payments_billing": serialize_data(df_dict)}
        # Fetch active default payment accounts using get_data ---
        try:
            # Step 1: Get accounts with default payment
            default_payment_df = killbill_database.get_data(
                "payment_methods",
                {"default_payment": True},
                ["account_number"]
            )
            default_payment_accounts = (
                default_payment_df["account_number"].dropna().astype(str).tolist()
                if default_payment_df is not None and not default_payment_df.empty else []
            )

            if default_payment_accounts:
                # Step 2: Get only active accounts from customer_profiles
                active_accounts_df = killbill_database.get_data(
                    "customer_profiles",
                    {"account_number": default_payment_accounts, "is_active": True},
                    ["id", "account_number"]
                )
                active_default_payment_accounts = (
                    active_accounts_df["account_number"].dropna().astype(str).tolist()
                    if active_accounts_df is not None and not active_accounts_df.empty else []
                )
                active_default_payment_accounts_ids = (
                    active_accounts_df["id"].dropna().astype(str).tolist()
                    if active_accounts_df is not None and not active_accounts_df.empty else []
                )
                profile_map = active_accounts_df.set_index("id")["account_number"].to_dict()
            else:
                active_default_payment_accounts = []
                active_default_payment_accounts_ids = []
                profile_map = {}
 
            logging.info(f"## Active default payment accounts: {active_default_payment_accounts}")
 
        except Exception as e:
            logging.info(f"## Error fetching active default payment accounts: {e}")
            active_default_payment_accounts = []
        try:
            account_due_summary = due_bills_data_for_multiple_accounts(
                killbill_database,
                active_default_payment_accounts,
                active_default_payment_accounts_ids,
                profile_map,
            )
        except Exception as e:
            logging.info(f"billing_collections_bills_list_view function : Exception occurred: {e}")
            account_due_summary = {}
        # Include in response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data,
            "eligible_accounts": active_default_payment_accounts,
            "credit_card_fee": credit_card_fee_accounts_by_tenant(data),
            "changed_data": account_due_summary
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "billing_payments_bills_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": response["message"],
            "module_name": data.get("module_name", "Customer Profiles"),
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return response

    except Exception as e:
        logging.exception(f"###billing_payments_bills_list_view :Exception occurred: {e}")
        error_data = {
            "service_name": "billing_payments_bills_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Bills list",
            "module_name": "Billing Services",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching Payments  list",
            "data": {}  # Return empty dictionary on error
        }
        return response




def get_customer_names_by_user(
    role_name,
    username,
    common_utils_database,
    tenant_db
):
    """
    Returns customer names accessible to the given user based on role and mappings.

    Rules:
    - Super Admin & Partner Admin → returns None (unrestricted access)
    - User has 'customers' field → returns parsed customer list
    - User has 'customer_group' → returns customers from group mapping
    - No mapping found or errors → returns empty list []

    Args:
        role_name (str): User's role name for admin bypass check
        username (str): Username to lookup customer permissions
        common_utils_database: Database connection for users table
        tenant_db: Tenant-specific database for customergroups table

    Returns:
        Optional[List[str]]: List of allowed customer names, None for admins, or []

    Raises:
        None: All errors handled gracefully, returns []
    """
    logging.info("## get_customer_names_by_user function called")

    try:
        # Admin bypass → no restriction
        if not role_name or str(role_name).lower() in ["super admin", "partner admin"]:
            logging.info("## get_customer_names_by_user admin role → unrestricted")
            return None

        # **FIX: Add null check before calling get_data**
        user_data = common_utils_database.get_data(
            table_name="users",
            condition={
                "username": username,
                "is_active": True
            },
            columns=["customers", "customer_group"]
        )

        # **FIX: Check for None or non-DataFrame response**
        if user_data is None or not hasattr(user_data, 'empty') or user_data.empty:
            logging.info("## get_customer_names_by_user user mapping not found")
            return []

        def normalize_value(value):
            """Normalize string/JSON/comma-separated values to list or None."""
            if value is None:
                return None

            if isinstance(value, str):
                cleaned = value.strip()
                if cleaned.lower() in ["", "null", "none"]:
                    return None

                try:
                    parsed = json.loads(cleaned)
                    return parsed
                except json.JSONDecodeError:
                    if "," in cleaned:
                        return [v.strip() for v in cleaned.split(",") if v.strip()]
                    return cleaned

            return value

        customers = normalize_value(user_data.iloc[0].get("customers"))
        customer_group = normalize_value(user_data.iloc[0].get("customer_group"))

        logging.info(
            f"## get_customer_names_by_user customers={customers}, customer_group={customer_group}"
        )

        # Case 1: Direct customers (highest priority)
        if customers:
            if isinstance(customers, str):
                customers = [customers]
            return customers

        # Case 2: Customer group lookup
        if customer_group:
            logging.info(f"## get_customer_names_by_user customer_group exist as {customer_group}")
            group_data = tenant_db.get_data(
                table_name="customergroups",
                condition={"name": customer_group},
                columns=["customer_names"]
            )

            # **FIX: Consistent null/empty check**
            # if group_data is None or not hasattr(group_data, 'empty') or group_data.empty:
            if group_data is None or group_data.empty:
                logging.info("## get_customer_names_by_user group not found or empty")
                return []

            customer_names = normalize_value(group_data.iloc[0].get("customer_names"))

            if isinstance(customer_names, str):
                customer_names = [customer_names]

            return customer_names or []

        # No customers or groups mapped
        logging.info("## get_customer_names_by_user no customers and no group")
        return []

    except Exception as e:
        logging.exception(f"## get_customer_names_by_user error: {e}")
        return []
def all_payment_history_list_view_2_1_2026(data):
    """
    Fetches and returns the payment history for a tenant with pagination, 
    applies timezone adjustments, and structures the response with headers.
    Filters results by customer access permissions for non-admin users.

    Parameters:
        data (dict): A dictionary containing the request details, including:
            - 'db_name' (str, optional): The name of the tenant database (default: 'altaworx_central').
            - 'role_name' (str, optional): The role name of the requesting user.
            - 'tenant_name' (str): The name of the tenant requesting the data.
            - 'username' (str): Username of the requesting user (required for access control).
            - 'mod_pages' (dict, optional): Pagination parameters:
                - 'start' (int, optional): The starting index of records (default: 0).
                - 'end' (int, optional): The ending index of records (default: 100).
    """
    try:
        # DB name Validation
        billing_db_name = data.get('billing_db_name', None)
        if not billing_db_name:
            return {"flag": False, "message": "Billing DB Name is required"}
        tenant_database=data.get('db_name','')

        # DB Connections
        killbill_database = DB(billing_db_name, **db_config)
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_database_conn = DB(tenant_database, **db_config)

        # UI Parameters
        role_name = data.get('role_name', '')
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        username = data.get('username', '')  # Required for customer access control
        mode = os.getenv('ENV', '')

        # ENV Validation
        if mode == 'UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        customer_filter = ""
        customer_params = []

        if role_name not in ("Super Admin", "Partner Admin"):
            config_customers = db_config.get("customers")
            customers = normalize_customers_from_config(config_customers)

            if customers:
                logging.info(f"## all_payment_history_list_view Applying customer filter from db_config | count={len(customers)}")
                placeholders = ",".join(["%s"] * len(customers))
                customer_filter = f" AND customer_name IN ({placeholders})"
                customer_params = customers
            else:
                logging.info("## all_payment_history_list_view No customers in db_config → no customer filter applied")


        # Set default pagination if not provided
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)
        col_sort = data.get("col_sort", "")
        limit = end - start
        offset = start

        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')

        # Get tenant's timezone
        tenant_time_zone = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["time_zone"]
        )["time_zone"].to_list()[0]
        logging.info("**tenant_time_zone", tenant_time_zone)

        if tenant_time_zone is None:
            raise ValueError("No valid timezone found for tenant.")

        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')


        # Total count query with customer filter
        if start_date:
            total_count_query = f"""SELECT id 
                                  FROM payments_list_view 
                                  WHERE tenant_id = %s AND date BETWEEN %s AND %s{customer_filter}"""
            params = [tenant_id, start_date, end_date] + customer_params
        else:
            total_count_query = f"""SELECT id 
                                  FROM payments_list_view 
                                  WHERE tenant_id = %s{customer_filter}"""
            params = [tenant_id] + customer_params
            
        total_count_result = killbill_database.execute_query(total_count_query, params=params)
        total_count = len(total_count_result['id'].to_list())

        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }

        # Main query with sorting and customer filter
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause = "ORDER BY date DESC, id DESC"

        if start_date:
            query = f'SELECT * FROM payments_list_view WHERE tenant_id = %s AND date BETWEEN %s AND %s{customer_filter} {order_clause} LIMIT %s OFFSET %s'
            params = [tenant_id, start_date, end_date] + customer_params + [limit, offset]
        else:
            query = f'SELECT * FROM payments_list_view WHERE tenant_id = %s{customer_filter} {order_clause} LIMIT %s OFFSET %s'
            params = [tenant_id] + customer_params + [limit, offset]

        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")
        
        # Category normalization
        for record in df_dict:
            category = record.get("category", "")
            if isinstance(category, str):
                if category.lower() == "credit":
                    record["category"] = "Credit"
                elif category.lower() == "ach":
                    record["category"] = "ACH"

        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        # Prepare response data
        header_map = get_headers_mapping(tenant_database, ["Billing and Payments-Payment History"], role_name, '', '', '', '', data)
        data_dict_all = {"payment_history": serialize_data(df_dict)}
        logging.info('###header_map', header_map)
        
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        return response

    except Exception as e:
        logging.exception(f"###all_payment_history_list_view Exception occurred: {e}")
        error_data = {
            "service_name": "all_payment_history_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Payments list",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching payment history",
            "data": {}
        }
        return response

def all_payment_history_list_view(data):
    """
    Fetches and returns the payment history for a tenant with pagination, 
    applies timezone adjustments, and structures the response with headers.
    Filters results by customer access permissions for non-admin users.

    Parameters:
        data (dict): A dictionary containing the request details, including:
            - 'db_name' (str, optional): The name of the tenant database (default: 'altaworx_central').
            - 'role_name' (str, optional): The role name of the requesting user.
            - 'tenant_name' (str): The name of the tenant requesting the data.
            - 'username' (str): Username of the requesting user (required for access control).
            - 'mod_pages' (dict, optional): Pagination parameters:
                - 'start' (int, optional): The starting index of records (default: 0).
                - 'end' (int, optional): The ending index of records (default: 100).
    """
    start_time = time.time()
    logging.info("###all_payment_history_list_view called with data: %s", data)
    try:
        # DB name Validation
        billing_db_name = data.get('billing_db_name', None)
        if not billing_db_name:
            return {"flag": False, "message": "Billing DB Name is required"}
        tenant_database=data.get('db_name','')

        # DB Connections
        killbill_database = DB(billing_db_name, **db_config)
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_database_conn = DB(tenant_database, **db_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {
            "flag": False,
            "message": "Error occurred while connecting to database"
        }
    try:
        # UI Parameters
        role_name = data.get('role_name', '')
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        username = data.get('username', '')  # Required for customer access control
        mode = os.getenv('ENV', '')

        # Set default pagination if not provided
        start = data.get('mod_pages', {}).get('start', 0)
        end = data.get('mod_pages', {}).get('end', 100)
        col_sort = data.get("col_sort", "")
        limit = end - start
        offset = start

        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')

        # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)

        # Total count query with customer filter
        if start_date:
            total_count_query = f"""SELECT id 
                                  FROM payments_list_view 
                                  WHERE tenant_id = %s AND date BETWEEN %s AND %s"""
            params = [tenant_id, start_date, end_date] 
        else:
            total_count_query = f"""SELECT id 
                                  FROM payments_list_view 
                                  WHERE tenant_id = %s"""
            params = [tenant_id] 
            
        total_count_result = killbill_database.execute_query(total_count_query, params=params)
        total_count = len(total_count_result['id'].to_list())

        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }

        # Main query with sorting and customer filter
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause = "ORDER BY date DESC, id DESC"

        if start_date:
            query = f'SELECT * FROM payments_list_view WHERE tenant_id = %s AND date BETWEEN %s AND %s {order_clause} LIMIT %s OFFSET %s'
            params = [tenant_id, start_date, end_date]  + [limit, offset]
        else:
            query = f'SELECT * FROM payments_list_view WHERE tenant_id = %s {order_clause} LIMIT %s OFFSET %s'
            params = [tenant_id]  + [limit, offset]

        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")
        amount_fields = [
            "amount",
        ]
        # Category normalization
        for record in df_dict:
            # Format numeric monetary fields
            for field in amount_fields:
                if field in record:
                    record[field] = format_amount(record.get(field, 0))
            category = record.get("category", "")
            if isinstance(category, str):
                if category.lower() == "credit":
                    record["category"] = "Credit"
                elif category.lower() == "ach":
                    record["category"] = "ACH"

        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        # Prepare response data
        header_map = get_headers_mapping(tenant_database, ["Billing and Payments-Payment History"], role_name, '', '', '', '', data)
        data_dict_all = {"payment_history": serialize_data(df_dict)}        
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "all_payment_history_list_view",
            "created_by": data.get("username", ""),
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": response["message"],
            "module_name": data.get("module_name", "Customer Profiles"),
            "request_received_at": data.get("request_received_at", None)
        }
        database.update_audit(audit_data_user_actions, "audit_user_actions")
        return response
    except Exception as e:
        logging.exception(f"###all_payment_history_list_view Exception occurred: {e}")
        error_data = {
            "service_name": "all_payment_history_list_view",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Payments list",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        response = {
            "flag": False,
            "message": "Something went wrong fetching payment history",
            "data": {}
        }
        return response


def charge_by_service_list_view(data):
    """
    Retrieves a paginated list of customer services based on tenant details and filters.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str, optional): The tenant database name. Defaults to 'altaworx_central'.
            - role_name (str, optional): The user's role name for header mapping.
            - tenant_name (str, optional): The tenant name for fetching timezone and metadata.
            - mod_pages (dict, optional): Pagination details:
                - start (int, optional): Start index for records. Defaults to 0.
                - end (int, optional): End index for records. Defaults to 100.
            - col_sort (dict, optional): Sorting details in the format {column_name: "asc"/"desc"}.
            - account_number (str, optional): The customer account number.
            - bill_id (str, optional): The billing ID for fetching cycle details.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation.
            - message (str): Success or error message.
            - data (dict): Processed customer service data.
            - header_map (dict): Mapped headers for response.
            - pages (dict): Pagination details including total records.
    """
    # DB Varibles Validation
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    # DB Connections
    killbill_database =  DB(billing_db_name, **db_config)
    tenant_database=data.get('db_name','')

    role_name = data.get('role_name', '')
    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    col_sort = data.get("col_sort", "")
    account_number=data.get("account_number","")
    bill_id=data.get("bill_id","")
    
    # Fetch billing cycle end date if a bill ID is provided
    if bill_id:
        customer_bills_=killbill_database.get_data('customer_bills',{"id":bill_id},["created_date","account_number","customer_profile_id","applied_services"])
        account_number=customer_bills_["account_number"].to_list()[0]
        customer_profile_id=customer_bills_["customer_profile_id"].to_list()[0]

        applied_services=customer_bills_["applied_services"].to_list()[0]
        if applied_services:
            applied_services=tuple(ast.literal_eval(applied_services))
        else:
            applied_services=tuple([0])

        # Query to get the total number of matching records
        total_count_query="""SELECT id 
                            FROM customer_services 
                            WHERE customer_profile_id = %s 
                            AND id in %s"""
        total_count_result=killbill_database.execute_query(total_count_query, params=[customer_profile_id,applied_services])
        if not total_count_result.empty:
            total_count_result=total_count_result['id'].tolist()
            total_count=len(total_count_result)
            logging.info("**totalquery",total_count_result)
        else:
            total_count=0
        # logging.info(f"total_count_result: {type(total_count)} - {total_count}")
        
        # Pagination information
        pages_data = {
            "start": start,
            "end": end,
            "total": total_count
        }   


        # Query to retrieve paginated customer service data
        query="""SELECT id,packages,customer_profile_id,charges
                FROM customer_services 
                WHERE customer_profile_id = %s 
                AND id in %s"""

        order_clause = ""
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        query=query+order_clause

        df = killbill_database.execute_query(query,params=[customer_profile_id,applied_services])  # Get the DataFrame directly
        logging.info('###df {df}')
        df_dict = df.to_dict(orient="records")

        try:
            # Prepare response data
            header_map = get_headers_mapping(tenant_database,["Billing Charge By Service"],role_name, '', '', '', '',data)
            final_data_dict=serialize_data(df_dict)
            
            # Process retrieved data
            if final_data_dict: 
                for record in final_data_dict:
                    # if record["customer_profile_id"]:
                    #     if record["customer_profile_id"] in customer_ids_acc_dict:
                    record["account_number"]=account_number
                    # Convert package list to a comma-separated string
                    if record["packages"]:
                        packages_list=ast.literal_eval(record["packages"])
                        package_str=", ".join(packages_list)
                        record["packages"]=package_str
                    record['total']=record.pop('charges', None)
            else:
                final_data_dict=[]
                
            # Construct response dictionary           
            data_dict_all = {"billing_charge_by_service": final_data_dict}
            response = {
                "flag": True,
                "message": "Data fetched successfully",
                "data": data_dict_all,
                "header_map": header_map,
                "pages": pages_data
            }
            return response

        except Exception as e:
            logging.exception(f"Exception occurred: {e}")
            response = {
                "flag": False,
                "message": "Something went wrong fetching Charge by Service List View",
                "data": {}  # Return empty dictionary on error
            }
            return response
    else:
        response = {
                "flag": False,
                "message": "Bill ID Invalid",
                "data": {}  # Return empty dictionary on error
            }
        return response


def charge_overview_list_view(data):
    """
    Retrieves a paginated list of customer services based on tenant details and filters.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str, optional): The tenant database name. Defaults to 'altaworx_central'.
            - role_name (str, optional): The user's role name for header mapping.
            - tenant_name (str, optional): The tenant name for fetching timezone and metadata.
            - bill_id (str, optional): The specific billing ID to fetch charge details.
            - mod_pages (dict, optional): Pagination details:
                - start (int, optional): Start index for records. Defaults to 0.
                - end (int, optional): End index for records. Defaults to 100.
            - col_sort (dict, optional): Sorting details in the format {column_name: "asc"/"desc"}.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation.
            - message (str): Success or error message.
            - data (dict): Processed customer service data.
            - header_map (dict): Mapped headers for response.
            - pages (dict): Pagination details including total records.

    Raises:
        ValueError: If no valid timezone is found for the given tenant.
    """
    # DB Name Validation
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    
    # DB Connections
    killbill_database =  DB(billing_db_name, **db_config)

    # UI Parameter's
    tenant_database=data.get('db_name','')
    role_name = data.get('role_name', '')
    bill_id=data.get("bill_id",'')
    
    # Fetch billing details if a bill_id is provided
    if bill_id:
        customers_bills=killbill_database.get_data("customer_bills",{"id":bill_id},["bill_details","usage_info", "applied_services","recurring_charges_audit"])
        bill_details=customers_bills["bill_details"].to_list()
        usage_info=customers_bills["usage_info"].to_list()
        applied_services=customers_bills["applied_services"].to_list()[0]
        recurring_charges_audit=customers_bills["recurring_charges_audit"].to_list()[0]
        logging.info(f'applied_services------{applied_services}')

        if recurring_charges_audit and recurring_charges_audit != '{}':
            if isinstance(recurring_charges_audit, str):
                try:
                    recurring_charges_audit = ast.literal_eval(recurring_charges_audit)
                except (ValueError, SyntaxError):
                    try:
                        recurring_charges_audit = json.loads(recurring_charges_audit)
                    except json.JSONDecodeError:
                        recurring_charges_audit = {}
            elif not isinstance(recurring_charges_audit, dict):
                recurring_charges_audit = {}
            if recurring_charges_audit:
                total_charges_by_services=sum(record.get('total_charge', 0) for record in recurring_charges_audit.values())
            else:
                total_charges_by_services=0
        else:
            total_charges_by_services=0
                

        
    final_bill_details={}
    if bill_details:
        bill_details=bill_details[0]
        if bill_details:
            final_bill_details=bill_details[0]
            
            # Define allowed charge types
            # Recalculate Total Charges only from allowed charges
            allowed_charge_types = ["Network Access Fee", "Cost Recovery Fee", "Late Fee"]

            if "charge_details" in final_bill_details and isinstance(final_bill_details["charge_details"], list):
                filtered_charges = [
                    charge for charge in final_bill_details["charge_details"]
                    # if charge.get("charge_type") in allowed_charge_types
                ]
                final_bill_details["charge_details"] = filtered_charges

                # Calculate total from filtered charge_details
                total_allowed_charge = sum(charge.get("charge_amount", 0) for charge in filtered_charges)

                # Update Total Charges correctly
                final_bill_details["Total Charges"] = total_allowed_charge
            else:
                # If charge_details not present, just assign service charges
                final_bill_details["charge_details"] = []
                final_bill_details["Total Charges"] = total_charges_by_services
    final_result={}
    if usage_info:
        usage_info=usage_info[0]
        if usage_info:
            try:
                usage_info=json.loads(usage_info)
                print(f"usage_info-----{usage_info}")
                final_result = {
                    "total_usage": 0,
                    "usage_info": []
                }

                for service_id, services in usage_info.items():
                    print(f"services-----{services}")
                    if "usage" in services:
                        usage_cost = services["usage"].get("total_usage", 0) or 0
                        if usage_cost:
                            serv_id=service_id.split("--")[0]
                            bill_range=service_id.split("--")[1]

                            final_result["usage_info"].append({
                                "service_id": int(float(serv_id)) if service_id else None,
                                "type": "Usage",
                                "cost": usage_cost,
                                "bill_range":bill_range
                            })
                            final_result["total_usage"] += usage_cost
                    
                    if "SMS" in services:
                        sms_cost = services["SMS"].get("total_cost", 0) or 0
                        if sms_cost:
                            serv_id=service_id.split("--")[0]
                            bill_range=service_id.split("--")[1]
                            final_result["usage_info"].append({
                                "service_id": int(float(serv_id)) if service_id else None,
                                "type": "SMS",
                                "cost": sms_cost,
                                "bill_range":bill_range
                            })
                            final_result["total_usage"] += sms_cost
            except Exception as e:
                logging.exception(f"Exception occurred while trying to fecth usage_info: {e}")
                final_result = {
                    "total_usage": 0,
                    "usage_info": []
                }
    else:
        final_result = {
                    "total_usage": 0,
                    "usage_info": []
                }
    df_dict={
        "bill_details":final_bill_details,
        "usage_details":final_result
    }

    try:
        # Map headers based on tenant database and role
        header_map = get_headers_mapping(tenant_database,["Charge Overview"],role_name, '', '', '', '',data)
        final_data_dict=serialize_data(df_dict)
        # Structure response dictionary
        data_dict_all = {"charge_overview": final_data_dict}
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": {}
        }
        return response

    except Exception as e:
        logging.exception(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching charge overview",
            "data": {}  # Return empty dictionary on error
        }
        return response


def get_export_status(data):
    """
    The get_export_status function retrieves the export status of a specific module from a database.
    It queries the export_status table based on the given module name and returns the corresponding status data.
    """
    try:
        # DB Connections
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # UI Parameter's
        module_name = data.get("module_name",None)
        username=data.get("username",None)
        tenant_id=data.get("tenant_id",None)
        export_status_data=common_utils_database.get_data('export_status',{"module_name":module_name,"user_name":username,"tenant_id":tenant_id},None).to_dict(orient="records")
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        error_data = {
            "service_name": "get_export_status",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": f"Failed! While checking export status {module_name}",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "export_status_data": []}

def export_to_s3_bucket_(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    logging.info(f"###export_to_s3_bucket_ Exporting to S3 bucket... {data}")
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("username", "")
    session_id = data.get("session_id", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}
    tenant_id = data.get("tenant_id", "")

    
    file_name = f"exports/uat/{module_name_snake_case}/{module_name}_{tenant_id}_{user_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # Update export status to 'Waiting'
    updated_flag=db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
    )
    if not updated_flag:
        db.insert_data({"status_flag": "Waiting", "url": "","tenant_id": tenant_id,"user_name": user_name,"module_name":module_name},"export_status")


    try:
        if not data_frames :
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                if df.empty:
                    # df = pd.DataFrame(columns=["No Data"])
                    pass

                # Format column names
                acronyms = {"SMS", "IMEI", "ID", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "SIM"}
                special_replacements = {"Att": "AT&T", "And": "and", "bill_id": "Bill ID"}

                df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                    for col in df.columns
                ]
                df.columns = [
                    " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
                ]

                df.to_excel(writer, index=False, sheet_name=sheet_name)

                # Apply styles
                workbook = writer.book
                sheet = workbook[sheet_name]

                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = header_font

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )


        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name})
            
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name}
        )
        db.log_error_to_db(
            {
                "service_name": "export_to_s3_bucket_",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"Failed while Exporting Excel {module_name}",
                "module_name": module_name,
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}

def export_to_s3_bucket_charge_overview(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}

    
    file_name = f"exports/uat/{module_name_snake_case}/{module_name}_{tenant_id}_{user_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # Update export status to 'Waiting'
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )

    try:
        if not data_frames :
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                start_row = 0  # Start from the first row
                # Process each dictionary in the list
                if not df:
                    df = pd.DataFrame(columns=["No Data"])
                else:
                    for data_ in df:
                        for key, sub_dict in data_.items():  # Loop through 'credits' and 'charge'
                            # Write Section Header (e.g., "Credits" or "Charge")
                            pd.DataFrame({key.capitalize(): [""]}).to_excel(writer, sheet_name=sheet_name, 
                                                                            index=False, startrow=start_row)
                            start_row += 1  # Move to the next row
                            final_key_list=[]
                            final_value_list=[]
                            for i in sub_dict:
                                for k,v in i.items():
                                    final_key_list.append(k)
                                    final_value_list.append(v)
                            # Convert dictionary into vertical formatkjhg
                            vertical_data = {
                                "Description": [" ".join(word.capitalize() for word in key.split("_")) for key in final_key_list],  
                                "Value": final_value_list
                            }
                            vertical_df = pd.DataFrame(vertical_data)
                            vertical_df.to_excel(writer, sheet_name=sheet_name, index=False, startrow=start_row)

                            # Move start_row to avoid overlapping (add space after each block)
                            start_row += len(vertical_df) + 2  # Space for next section

                    # Get workbook and sheet for formatting
                    workbook = writer.book
                    sheet = workbook[sheet_name]

                # Apply bold formatting to section headers
                for row in range(1, start_row, len(vertical_df) + 2):  # Headers are spaced out
                    for cell in sheet[row]:
                        cell.font = Font(bold=True)

                # Auto-adjust column widths
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name},
        )
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name}
        )
        db.log_error_to_db(
            {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": str(e),
                "module_name": "export",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}

    


def charge_overview_export(data):
    """
    Retrieves charge overview details, including bill details and usage details, from 
    the billing database using a provided bill ID. The function processes the data 
    and exports it to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing the following key:
                 - "bill_id" (str, optional): The billing ID to fetch the charge overview details.

    Returns:
    dict: The response from the export function after storing the processed data.
    """
    # DB Name Validation
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    
    # DB Connections
    killbill_database =  DB(billing_db_name, **db_config)

    bill_id=data.get("bill_id","")
    # Fetch bill details and usage details if a bill ID is provided
    if bill_id:
        customers_bills=killbill_database.get_data("customer_bills",{"id":bill_id},["bill_details","usage_details", "applied_services"])
        # Extract bill details and usage details from the database response
        bill_details=customers_bills["bill_details"].to_list()
        usage_details=customers_bills["usage_details"].to_list()
        applied_services=customers_bills["applied_services"].to_list()[0]

    if applied_services:
            applied_services=tuple(ast.literal_eval(applied_services))
            total_charges_by_services = 0
            for i in applied_services:
                customer_services=killbill_database.get_data("customer_services",{"id":i},["charges"])
                charges =customer_services["charges"].to_list()[0]
                total_charges_by_services += charges
            print(f'total_charges_by_services------{total_charges_by_services}')
    else:
        total_charges_by_services = 0
        
    if usage_details:
        usage_details=usage_details[0]
        if not usage_details:
            usage_details=[]
    else:
        usage_details=[]

    credits = []
    charges = []
    if bill_details:
        bill_details=bill_details[0]
        if bill_details:
            bill_data = bill_details[0] if isinstance(bill_details, list) and bill_details else {}

            if isinstance(bill_data, dict):
                for key, value in bill_data.items():

                    if isinstance(value, list):
                        if key=='credit_details':
                            for item in value:
                                credits.append({item.get('charge_type'): item.get("charge_amount", "")})
                        elif key=="charge_details":
                            for item in value:
                                charges.append({item.get('charge_type'): item.get("charge_amount", "")})
                    else:
                        if key == "Total Charges":
                            charges.append({"Total Charges":value})
                        elif key == "Total Credits":
                            credits.append({"Total Credits":value})
    
    charges.append({"Charges by Service": total_charges_by_services})
    # to bring total at end
    total_creditss = [item for item in credits if "Total Credits" in item]
    total_chargess = [item for item in charges if "Total Charges" in item]

    # Filter out total entries from the original lists
    credits = [item for item in credits if "Total Credits" not in item] + total_creditss
    charges = [item for item in charges if "Total Charges" not in item] + total_chargess

    
    for charge in charges:
        if "Total Charges" in charge:
            charge["Total Charges"] += total_charges_by_services
        
    usage_details_df = [{"usage_details":usage_details}]
    bill_details_df = [{"credits": credits}, {"charges": charges}]
    # Store the processed data as DataFrames in the "dfs" dictionary
    logging.info(f"billllllllll {bill_details_df}")
    logging.info(f"usage_details_df {usage_details_df}")
    data["dfs"]={
            "Bill Details":bill_details_df,
            "Usage Details":usage_details_df
        }

    return export_to_s3_bucket_charge_overview(data)


def charge_by_service_export(data):
    """
    Retrieves charge-by-service details from the billing database based on a given 
    bill ID or account number. The function processes customer profile data, fetches 
    active services, formats the data, and exports the result to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing request parameters such as:
                 - "bill_id" (str, optional): The billing ID to filter the data.
                 - "account_number" (str, optional): The account number to filter the data.

    Returns:
    dict: The response from the export function after storing the processed data.
    """
    # DB Name Validation
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}

    # DB Connections
    killbill_database =  DB(billing_db_name, **db_config)

    # UI aparameter's
    bill_id=data.get("bill_id","")
    
    if bill_id:
        customer_bills_=killbill_database.get_data('customer_bills',{"id":bill_id},["created_date","account_number","customer_profile_id","applied_services"])
        account_number=customer_bills_["account_number"].to_list()[0]
        customer_profile_id=customer_bills_["customer_profile_id"].to_list()[0]
        applied_services=customer_bills_["applied_services"].to_list()[0]
        if applied_services:
            applied_services = ast.literal_eval(applied_services)
            applied_services_tuple=tuple(applied_services)
        else:
            applied_services_tuple=tuple([0])

    # Query to fetch active customer services based on customer profile ID and bill cycle date
    query="""SELECT id,packages,charges
                FROM customer_services 
                WHERE customer_profile_id = %s 
                AND id  in %s;"""
    df = killbill_database.execute_query(query,params=[customer_profile_id,applied_services_tuple])  # Get the DataFrame directly
    logging.info('###df {df}')
    df_dict = df.to_dict(orient="records")
    
    # Process each record
    for record in df_dict:
        # if record["customer_profile_id"]:
        #     if record["customer_profile_id"] in customer_ids_acc_dict:
        record["service_id"]=record.pop("id")
        # Convert package list to a comma-separated string
        if record["packages"]:
            packages_list=ast.literal_eval(record["packages"])
            package_str=", ".join(packages_list)
            record["packages"]=package_str
        record["packages"]=record.pop('packages','')
        record["taxes"]=''
        record["account_number"]=account_number

    logging.info(f"***data {df_dict}")
    # Convert to DataFrame
    df = pd.DataFrame(df_dict)

    df = df.fillna('')
    data["dfs"]={
        "Charge By Service":df
    }
    # Export the processed data to an S3 bucket and return the response
    return export_to_s3_bucket_(data)

def bills_export_2_1_2026(data):
    """
    Retrieves bill list details from the billing database based on a provided
    account number. The function processes the data and exports it to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing the following key:
                 - "account_number" (str): The account number to fetch the bill list details.

    Returns:
    dict: The response from the export function after storing the processed data.
    """
    try:
        logging.info(f"## bills_export Function Called with data {data}")

        # Fetch UI Parameter's
        col_sort=data.get('col_sort', '')
        start_date=data.get('start_date','')
        end_date=data.get('end_date','')
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        role = data.get("role_name", "")
        username = data.get("username", "")
        module_name = data.get("module_name", "")


        # DB Name Validation
        billing_db_name = data.get('billing_db_name',None)
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        
        # DB Connections
        killbill_database =  DB(billing_db_name, **db_config)
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # ENV mode Check
        mode=os.getenv('ENV','')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        # Fetch tenant timezone
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        # Order clause
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY modified_date desc"

        # fetching list view data
        # if start_date:
        #     query = f"SELECT * FROM billing_list_view where tenant_id = {tenant_id} and is_active = 'true'and  COALESCE(amount_due, 0) > 0  and created_date between '{start_date}' and '{end_date}' {order_clause}"
        # else:
        #     query = f"SELECT * FROM billing_list_view where tenant_id = {tenant_id} and is_active = 'true' {order_clause} and  COALESCE(amount_due, 0) > 0 "
        
        # ---------- Customer Access ----------
        customer_names = None  # Default → no restriction

        if role not in ("Super Admin", "Partner Admin"):
            config_customers = db_config.get("customers")  # Fetch from db_config if defined

            if config_customers:
                customer_names = normalize_customers_from_config(config_customers)

            # If no customers → return empty immediately
            if not customer_names:
                return {
                    "flag": True,
                    "message": "No bill data available for the user",
                    "data": {}
                }

        # Apply customer filter if customers are restricted
        customer_filter_clause = ""
        if customer_names is not None:
            placeholders = ",".join(f"'{c}'" for c in customer_names)
            customer_filter_clause = f" AND customer_name IN ({placeholders})"


        # Fetching list view data
        if start_date:
            query = (
                f"SELECT * FROM billing_list_view "
                f"WHERE tenant_id = {tenant_id} "
                f"AND is_active = 'true' "
                f"AND COALESCE(amount_due, 0) > 0 "
                f"{customer_filter_clause} "
                f"AND created_date BETWEEN '{start_date}' AND '{end_date}' "
                f"{order_clause}"
            )
        else:
            query = (
                f"SELECT * FROM billing_list_view "
                f"WHERE tenant_id = {tenant_id} "
                f"AND is_active = 'true' "
                f"AND COALESCE(amount_due, 0) > 0 "
                f"{customer_filter_clause} "
                f"{order_clause}"
            )

        df_dict = killbill_database.execute_query(query, params=[]).to_dict(orient="records")

        
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        
        df = pd.DataFrame(df_dict)

        df = df.rename(columns={
            'due_date_of_this_bill': 'due_date',
            'email_status': 'flags'
        })
        df = df.drop(columns=['tenant_id', 'is_active',"id"], errors='ignore')

        df = df.fillna('')
        # data["dfs"]={
        #     "Bills":df
        # }
        if not df.empty:
            data["dfs"]={
                "Bills":df
            }
        else:
            data["dfs"]={}
        # Export the processed data to an S3 bucket and return the response
        return export_to_s3_bucket_(data)
    except Exception as e:
        logging.info(f"###bills_export Error in bills_export: {e}")
        error_data = {
            "service_name": "bills_export",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Bill Export",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Bill Export Failed"}

def bills_export(data):
    """
    Retrieves bill list details from the billing database based on a provided
    account number. The function processes the data and exports it to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing the following key:
                 - "account_number" (str): The account number to fetch the bill list details.

    Returns:
    dict: The response from the export function after storing the processed data.
    """
    try:
        logging.info(f"## bills_export Function Called with data {data}")

        # Fetch UI Parameter's
        col_sort=data.get('col_sort', '')
        start_date=data.get('start_date','')
        end_date=data.get('end_date','')
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        role = data.get("role_name", "")
        username = data.get("username", "")
        module_name = data.get("module_name", "")


        # DB Name Validation
        billing_db_name = data.get('billing_db_name',None)
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        
        # DB Connections
        killbill_database =  DB(billing_db_name, **db_config)
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # ENV mode Check
        mode=os.getenv('ENV','')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        # Fetch tenant timezone
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        # Order clause
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY modified_date desc"

        # Fetching list view data
        if start_date:
            query = (
                f"SELECT * FROM billing_list_view "
                f"WHERE tenant_id = {tenant_id} "
                f"AND is_active = 'true' "
                f"AND COALESCE(amount_due, 0) > 0 "
                f"AND created_date BETWEEN '{start_date}' AND '{end_date}' "
                f"{order_clause}"
            )
        else:
            query = (
                f"SELECT * FROM billing_list_view "
                f"WHERE tenant_id = {tenant_id} "
                f"AND is_active = 'true' "
                f"AND COALESCE(amount_due, 0) > 0 "
                f"{order_clause}"
            )

        df_dict = killbill_database.execute_query(query, params=[]).to_dict(orient="records")

        
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)
        
        df = pd.DataFrame(df_dict)

        df = df.rename(columns={
            'due_date_of_this_bill': 'due_date',
            'email_status': 'flags'
        })
        df = df.drop(columns=['tenant_id', 'is_active',"id"], errors='ignore')

        df = df.fillna('')
        # data["dfs"]={
        #     "Bills":df
        # }
        if not df.empty:
            data["dfs"]={
                "Bills":df
            }
        else:
            data["dfs"]={}
        # Export the processed data to an S3 bucket and return the response
        return export_to_s3_bucket_(data)
    except Exception as e:
        logging.info(f"###bills_export Error in bills_export: {e}")
        error_data = {
            "service_name": "bills_export",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Bill Export",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Bill Export Failed"}


def payments_history_export_2_1_2026(data):
    """
    Retrieves bill list details from the billing database based on a provided
    account number. The function processes the data and exports it to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing the following key:
                 - "account_number" (str): The account number to fetch the bill list details.

    Returns:
    dict: The response from the export function after storing the processed data.
    """
    try:
        # Fetch UI Parameter's
        start_date=data.get('start_date','')
        end_date=data.get('end_date','')
        col_sort=data.get('col_sort', '')
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        role = data.get("role_name", "")
        username = data.get("username", "")

        # DB Name Validation
        billing_db_name = data.get('billing_db_name',None)
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        
        # DB Connections
        killbill_database =  DB(billing_db_name, **db_config)
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # ENV Mode check
        mode=os.getenv('ENV','')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        # Tenant TimeZone
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        # Order Clause
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY date desc"

        # ---------- Customer Access ----------
        customer_names = None  # Default → no restriction

        if role not in ("Super Admin", "Partner Admin"):
            config_customers = db_config.get("customers")  # From global DB config

            if config_customers:
                customer_names = normalize_customers_from_config(config_customers)

            # If no customers → return empty immediately
            if not customer_names:
                return {
                    "flag": True,
                    "message": "No payment history data available for the user",
                    "data": {}
                }

        # Apply customer filter if customers are restricted
        customer_filter_clause = ""
        if customer_names is not None:
            placeholders = ",".join(f"'{c}'" for c in customer_names)
            customer_filter_clause = f" AND customer_name IN ({placeholders})"


        # fetching list view data
        if start_date:
            # query = f'SELECT * FROM payments_list_view where tenant_id = %s and date between %s and %s {order_clause}'
            query = (
                "SELECT account_number, customer_name, id, bill_id_inv AS bill_id, "
                "ref, category, source, date, agent, amount, status "
                "FROM payments_list_view "
                "WHERE tenant_id = %s "
                f"{customer_filter_clause} "
                "AND date BETWEEN %s AND %s "
                f"{order_clause}"
            )
            params = [tenant_id, start_date, end_date]
        else:
            
            # query = f'SELECT * FROM payments_list_view where tenant_id = %s {order_clause}'
            query = (
                "SELECT account_number, customer_name, id, bill_id_inv AS bill_id, "
                "ref, category, source, date, agent, amount, status "
                "FROM payments_list_view "
                "WHERE tenant_id = %s "
                f"{customer_filter_clause} "
                f"{order_clause}"
            )
            params = [tenant_id]
        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")

        for record in df_dict:
            category = record.get("category", "")
            if isinstance(category, str):
                if category.lower() == "credit":
                    record["category"] = "Credit"
                elif category.lower() == "ach":
                    record["category"] = "ACH"
                # keep any other categories as-is
                else:
                    pass
            # Replace bill_id with bill_id_inv
            # record["bill_id"] = record.get("bill_id_inv", "")
            # record.pop("bill_id_inv", None)  # Remove bill_id_inv
            # record.pop("bill_id", None) if record.get("bill_id") == '' else None
        
        
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        df = pd.DataFrame(df_dict)
        if df.empty:
            expected_columns = [
                'account_number', 'customer_name', 'payment_id', 'bill_id', 'transaction_id',
                'method', 'source', 'date', 'agent', 'amount', 'status'
            ]
            # Ensure empty DataFrame with expected columns
            df = pd.DataFrame(columns=expected_columns)
        else:
            df = df.rename(columns={
                'id': 'payment_id',
                'ref': 'transaction_id',
                'category': 'method'
            })
            df = df.drop(columns=['tenant_id', 'modified_date', 'auth_code'], errors='ignore')
            df = df.fillna('')

        data["dfs"]={
            "Payment History":df
        }
        # Export the processed data to an S3 bucket and return the response
        return export_to_s3_bucket_(data)
    except Exception as e:
        logging.info(f"###payments_history_export Error in payments_history_export: {e}")
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        error_data = {
            "service_name": "payments_history_export",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Payment History Export",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Payment History Export Failed"}

def payments_history_export(data):
    """
    Retrieves bill list details from the billing database based on a provided
    account number. The function processes the data and exports it to an S3 bucket.

    Parameters:
    data (dict): A dictionary containing the following key:
                 - "account_number" (str): The account number to fetch the bill list details.

    Returns:
    dict: The response from the export function after storing the processed data.
    """
    try:
        # Fetch UI Parameter's
        start_date=data.get('start_date','')
        end_date=data.get('end_date','')
        col_sort=data.get('col_sort', '')
        tenant_name = data.get('tenant_name', '')
        tenant_id = data.get('tenant_id', '')
        role = data.get("role_name", "")
        username = data.get("username", "")

        # DB Name Validation
        billing_db_name = data.get('billing_db_name',None)
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        
        # DB Connections
        killbill_database =  DB(billing_db_name, **db_config)
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # ENV Mode check
        mode=os.getenv('ENV','')
        if mode=='UAT':
            if tenant_name == 'Altaworx Test':
                tenant_name = 'Altaworx'
                tenant_id = 1
        # Tenant TimeZone
        tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
        tenant_timezone = common_utils_database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
        if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
                raise ValueError("No valid timezone found for tenant.")

        tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        # Order Clause
        if col_sort:
            order_clause = " ORDER BY " + ", ".join(f"{col} {order}" for col, order in col_sort.items())
        else:
            order_clause="ORDER BY date desc"



        # fetching list view data
        if start_date:
            # query = f'SELECT * FROM payments_list_view where tenant_id = %s and date between %s and %s {order_clause}'
            query = (
                "SELECT account_number, customer_name, id, bill_id_inv AS bill_id, "
                "ref, category, source, date, agent, amount, status "
                "FROM payments_list_view "
                "WHERE tenant_id = %s "
                "AND date BETWEEN %s AND %s "
                f"{order_clause}"
            )
            params = [tenant_id, start_date, end_date]
        else:
            
            # query = f'SELECT * FROM payments_list_view where tenant_id = %s {order_clause}'
            query = (
                "SELECT account_number, customer_name, id, bill_id_inv AS bill_id, "
                "ref, category, source, date, agent, amount, status "
                "FROM payments_list_view "
                "WHERE tenant_id = %s "
                f"{order_clause}"
            )
            params = [tenant_id]
        df_dict = killbill_database.execute_query(query, params=params).to_dict(orient="records")

        for record in df_dict:
            category = record.get("category", "")
            if isinstance(category, str):
                if category.lower() == "credit":
                    record["category"] = "Credit"
                elif category.lower() == "ach":
                    record["category"] = "ACH"
                # keep any other categories as-is
                else:
                    pass
            # Replace bill_id with bill_id_inv
            # record["bill_id"] = record.get("bill_id_inv", "")
            # record.pop("bill_id_inv", None)  # Remove bill_id_inv
            # record.pop("bill_id", None) if record.get("bill_id") == '' else None
        
        
        # converting the time based on the time_zone
        df_dict = convert_timestamp(df_dict, tenant_time_zone)

        df = pd.DataFrame(df_dict)
        if df.empty:
            expected_columns = [
                'account_number', 'customer_name', 'payment_id', 'bill_id', 'transaction_id',
                'method', 'source', 'date', 'agent', 'amount', 'status'
            ]
            # Ensure empty DataFrame with expected columns
            df = pd.DataFrame(columns=expected_columns)
        else:
            df = df.rename(columns={
                'id': 'payment_id',
                'ref': 'transaction_id',
                'category': 'method'
            })
            df = df.drop(columns=['tenant_id', 'modified_date', 'auth_code'], errors='ignore')
            df = df.fillna('')

        data["dfs"]={
            "Payment History":df
        }
        # Export the processed data to an S3 bucket and return the response
        return export_to_s3_bucket_(data)
    except Exception as e:
        logging.info(f"###payments_history_export Error in payments_history_export: {e}")
        database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        error_data = {
            "service_name": "payments_history_export",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": "Unhandled exception during Payment History Export",
            "module_name": "Billing Payments",
            "request_received_at": data.get("request_received_at"),
        }
        database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": "Payment History Export Failed"}
