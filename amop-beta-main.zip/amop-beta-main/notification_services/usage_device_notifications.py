import ast
import json
import math
import os
import re
import time
import uuid
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from dotenv import load_dotenv
from tenacity import retry, stop_after_attempt, wait_fixed

import psycopg2
from psycopg2.extras import execute_values
import pytds
from sqlalchemy import create_engine, exc, text

# Importing project-specific modules
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *

# Load environment variables

logging = Logging(name="notification_services")
load_dotenv()


##TO CONNECT TO DATABASE

onepoint_o_database=os.getenv("ONEPOINTODATABASE","AltaworxCentral_Test")

class UsageNotifications:


    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(
        self,
        db_type="",
        host="",
        db_name="",
        username="",
        password="",
        port="",
        driver="",
        max_retry=3,
    ):
        connection = None
        logging.info(f"db_type--------{db_type}")
        logging.info(f"host--------------{host}")

        if db_type == "postgresql":
            try:
                logging.info(f"Creating PostgreSQL connection")
                connection = psycopg2.connect(
                    host=os.environ["HOST"],
                    database=db_name,
                    user=os.environ["USER"],
                    password=os.environ["PASSWORD"],
                    port=os.environ["PORT"],
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.info(f"Failed to connect to PostgreSQL DB: {e}")
        elif db_type == "mssql":
            logging.info(
                f"conn : {db_type},{host},{db_name},{username},{password},{driver},{port}"
            )
            logging.info("Creating MSSQL connection")
            logging.info(f"Creating MSSQL connection using pytds")
            try:
                connection = pytds.connect(
                    server=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=os.environ["ONEPOINTOPORT"],

                    # server = os.environ["ONEPOINTOSERVER"] ,
                    # database = os.environ["ONEPOINTODATABASE"],
                    # user = os.environ["ONEPOINTOUSERNAME"],
                    # password = os.environ["ONEPOINTOPASSWORD"],
                    # port = os.environ["ONEPOINTOPORT"],


                    # server="altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com",
                    # database="{onepoint_o_database}",
                    # user="ALGONOX-Vyshnavi",
                    # password="cs!Vtqe49gM32FDi",
                    # port="1433",
                    # server="altaworx-test.cd98i7zb3ml3.us-east-1.rds.amazonaws.com",
                    # database="{onepoint_o_database}",
                    # user="ALGONOX-Vyshnavi",
                    # password="cs!Vtqe49gM32FDi",
                    # port="1433",
                )
                # connection = pymssql.connect(
                #     server=host,
                #     user=username,
                #     password=password,
                #     database=db_name,
                #     port=port,
                #     timeout=5
                # )
                # connection = pymssql.connect(host=host,user=username,password=password,db_name=db_name,connect_timeout=5)
                logging.info("Connection to MSSQL successful!")
            except Exception as e:
                logging.info(f"Failed to connect to MSSQL DB: {e}")
                logging.error(f"Failed to connect to MSSQL DB: {e}")

        return connection

    def execute_query(self, connection, query, params=None):

        try:
            # Check if params are provided
            if params:
                # Execute the query with parameters
                logging.info(f"params--------{params}")
                result_df = pd.read_sql_query(query, connection, params=params)
            else:
                # Execute the query without parameters
                result_df = pd.read_sql_query(query, connection)

            return result_df
        except Exception as e:
            logging.info(f"Error executing query: {e}")
            return None

    def load_env_pgsql(self):
        load_dotenv()
        hostname = os.getenv("LOCAL_DB_HOST")
        port = os.getenv("LOCAL_DB_PORT")
        user = os.getenv("LOCAL_DB_USER")
        password = os.getenv("LOCAL_DB_PASSWORD")
        db_type = os.getenv("LOCAL_DB_TYPE")
        db_name = os.getenv("LOCAL_DB_NAME")
        return hostname, port, user, password, db_type, db_name

    def load_env_mssql(self):
        from_host = os.getenv("FROM_DB_HOST")
        from_port = os.getenv("FROM_DB_PORT")
        from_db = os.getenv("FROM_DB_NAME")
        from_user = os.getenv("FROM_DB_USER")
        from_pwd = os.getenv("FROM_DB_PASSWORD")
        from_db_type = os.getenv("FROM_DB_TYPE")
        from_driver = os.getenv("FROM_DB_DRIVER")
        return (
            from_host,
            from_port,
            from_db,
            from_user,
            from_pwd,
            from_db_type,
            from_driver,
        )

    def usage_notification(self, data):
        logging.info(f"Received data for usage_notification is {data}")
        load_dotenv()
        flag = data["action"]
        tenant_database=data.get('db_name',None)
        if tenant_database is None:
            logging.info("tenant_database is None, please provide a valid database name.")
            return
        logging.info(f"tenant_database------------{tenant_database}")
        logging.info(f"flag----------{flag}")
        rule_id_2_0 = data["rule_def_id"]
        logging.info(f"rule_id_2_0-----------{rule_id_2_0}")
        # expression_type_id = '33e9b000-a43f-4649-92af-ec3d7925a8a2'
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        # logging.info(f'db_type---------{db_type}')
        hostname, port, user, password, db_type, db_name = self.load_env_pgsql()
        # logging.info(f'hostname------------{hostname}')
        mapping_db=os.getenv("LOCAL_DB_NAME")
        mapping_table = os.getenv("MAPPING_TABLE")
        mapping_conn=self.create_connection(
            "postgresql", hostname, mapping_db, user, password, port)
        trasfer_name=f"notification_services_{tenant_database}"
        tenant_db_details=f"select db_name_10,db_config from {mapping_table} where transfer_name = '{trasfer_name}'"
        tenant_db_details_df = self.execute_query(mapping_conn, tenant_db_details)
        logging.info(f'tenant_db_details_df--- {trasfer_name}---------{tenant_db_details_df}')
        tenant_db_details_dict = tenant_db_details_df.to_dict(orient="records")

        logging.info(f"tenant_db_details_df --- {trasfer_name} --- {tenant_db_details_dict}")
        if tenant_db_details_df.empty:
            logging.info(f"No database details found for transfer_name: {trasfer_name}")
            return


        def to_camel_case(snake_str):
            components = snake_str.split("_")
            return components[0].capitalize() + "".join(
                x.capitalize() for x in components[1:]
            )

        postgres_conn_start = time.time()
        postgres_conn = self.create_connection(
            "postgresql", hostname, tenant_database, user, password, port
        )
        # (
        #     from_host,
        #     from_port,
        #     ssms_db_name,
        #     from_user,
        #     from_pwd,
        #     from_db_type,
        #     from_driver,
        # ) = self.load_env_mssql()
        mssql_conn_start = time.time()
        ssms_db_name = tenant_db_details_df["db_name_10"].iloc[0]
        from_db_config= tenant_db_details_df["db_config"].iloc[0]
        logging.info(f"ssms_db_name 11 {ssms_db_name}")
        logging.info(f"from_db_config here is {from_db_config} type is {type(from_db_config)}")
        from_host = from_db_config.get("hostname")
        from_port = from_db_config.get("port")
        from_user = from_db_config.get("user")
        from_pwd  = from_db_config.get("password")
        from_db_type = from_db_config.get("db_type", "mssql")
        from_driver=os.getenv("FROM_DB_DRIVER", "ODBC Driver 17 for SQL Server")
        logging.info(f"from_host------------{from_host}")
        logging.info(f"from_port------------{from_port}")
        logging.info(f"ssms_db_name------------{ssms_db_name}")
        logging.info(f"from_user------------{from_user}")
        logging.info(f"MSSQL DB Details Host: {from_host}, Port: {from_port}, User: {from_user}, DB Type: {from_db_type}")


        mssql_conn = self.create_connection(
            "mssql",
            from_host,
            ssms_db_name,
            from_user,
            from_pwd,
            from_port,
            from_driver,
        )
        # logging.info(f"mssql_conn {mssql_conn}")
        # logging.info(f"MSSQL connection time: {time.time() - mssql_conn_start:.4f} seconds")
        # logging.info(f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds")
        # logging.info(f"Postgres connection time: {time.time() - postgres_conn_start:.4f} seconds")
        ##getting all the details for a particular transfer
        query_start = time.time()
        # fetching data from 2.0 rule_rule_definition table based on id column
        if flag == "create":
            rule_rule_defintiton_details_query = f"select id,object_type_id,rule_id,name,priority,subject_line,display_message,notes,order_of_execution,created_date,created_by,modified_by,modified_date,is_active,is_deleted,send_to_carrier,send_to_customer,should_show_projected_usage_cost,should_send_single_email_to_customer_group,aggregated_customer_email_recipient,should_exclude_pooled_device from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}'"
            rule_rule_definition_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_details_query
            )
            logging.info(f'rule_rule_definition_details----------------{rule_rule_definition_details}')

            # insert the details  fetched from 2.0 rule_rule_definition table to 1.0 rule_rule_definition without id(that will generate automatically)

            if not rule_rule_definition_details.empty:
                # logging.info(f'in if condition')
                rule_rule_definition_details = rule_rule_definition_details.drop(
                    columns=["id"]
                )
                all_columns = rule_rule_definition_details.columns
                columns_to_insert = all_columns  # Exclude last 5 columns and rule_id column
                columns_to_insert_camel_case = [
                    to_camel_case(col) for col in columns_to_insert
                ]
                logging.info(f'columns_to_insert-----------{columns_to_insert_camel_case}')
                column_names = ", ".join(columns_to_insert_camel_case)
                logging.info(f'column_names------------{column_names}')
                placeholders = ", ".join(
                    ["%s"] * len(columns_to_insert)
                )  # Get column names
                insert_query = f""" INSERT INTO {onepoint_o_database}.dbo.RULE_RuleDefinition ({column_names}) OUTPUT INSERTED.id VALUES ({placeholders});"""  # fetch the id from 1.0 database and store it in a new column

                logging.info(f'insert_query RULE_RuleDefinition {insert_query}')
                logging.info(f'placeholders RULE_RuleDefinition {placeholders}')
                def convert_value(x):
                    if pd.isna(x):  # Handle NaT or NaN
                        return None
                    elif isinstance(x, np.int64):
                        return int(x)
                    elif isinstance(x, np.float64):
                        return float(x)
                    elif isinstance(x, np.bool_):
                        return bool(x)
                    elif isinstance(x, pd.Timestamp):
                        return x.to_pydatetime()
                    else:
                        return x

                data_to_insert = tuple(
                    rule_rule_definition_details.iloc[0][
                        columns_to_insert
                    ]  # Exclude rule_id
                    .apply(convert_value)
                    .tolist()
                )
                logging.info(f'data_to_insert----------{data_to_insert}')
                with mssql_conn.cursor() as cursor:
                    cursor.execute(insert_query, data_to_insert)
                    # cursor.execute("SELECT LASTVAL()")  # Fetch the last inserted ID
                    new_id = cursor.fetchone()[0]
                    logging.info(f"New ID inserted:RULE_RuleDefinition {new_id}")
                    mssql_conn.commit()
                    # def_id = '0050535b-e2c3-4f98-9b63-cb3fc28fe6ca'

                # Now update the `1_0_rule_id` column in the `rule_rule_definition` table
                new_id = str(new_id)
                with postgres_conn.cursor() as cursor:
                    update_query = """UPDATE public.rule_rule_definition
                                        SET "rule_id_1_0" = %s
                                        WHERE rule_def_id = %s"""
                    # logging.info(f'update_query----------{update_query}')
                    cursor.execute(update_query, (new_id, rule_id_2_0))
                    postgres_conn.commit()
                    logging.info(f"Updated 1_0_rule_id in rule_rule_definition table")

            else:
                logging.info("No data found to insert into backup table.")
            # with that id insert into rules version table

            rule_rule_defintiton_bak_details_query = f"select * from {onepoint_o_database}.dbo.RULE_RuleDefinition where id = '{new_id}'"
            rule_rule_defintiton_bak_details = self.execute_query(
                mssql_conn, rule_rule_defintiton_bak_details_query
            )

            logging.info(
                f"rule_rule_defintiton_bak_details---------------{rule_rule_defintiton_bak_details}"
            )
            # logging.info(f'rule_rule_defintiton_bak_details.columns-------{rule_rule_defintiton_bak_details.columns}')

            if not rule_rule_defintiton_bak_details.empty:
                rule_rule_defintiton_bak_details = (
                    rule_rule_defintiton_bak_details.drop(columns=["RuleId"])
                )
                rule_rule_defintiton_bak_details = (
                    rule_rule_defintiton_bak_details.drop(columns=["VersionId"])
                )
                rule_rule_defintiton_bak_details = (
                    rule_rule_defintiton_bak_details.rename(columns={"id": "RuleId"})
                )
                # logging.info(f'rule_rule_defintiton_bak_details.columns-------{rule_rule_defintiton_bak_details.columns}')
                all_columns = rule_rule_defintiton_bak_details.columns
                column_names = ", ".join(all_columns)
                logging.info(f'column_names------------{column_names}')
                placeholders = ", ".join(["%s"] * len(all_columns))
                insert_query = f"""
                    INSERT INTO {onepoint_o_database}.dbo.RULE_Version ({column_names}) OUTPUT INSERTED.id
                    VALUES ({placeholders})
                    """
                logging.info(f'insert_query RULE_Version {insert_query}')

                # Build the INSERT query dynamically
                def convert_value(x):
                    if isinstance(x, np.int64):
                        return int(x)
                    elif isinstance(x, np.float64):
                        return float(x)
                    elif isinstance(x, np.bool_):
                        return bool(x)
                    elif isinstance(x, uuid.UUID):  # Handle UUIDs
                        return str(x)
                    elif isinstance(x, pd.Timestamp):
                        return x.to_pydatetime()
                    else:
                        return x

                data_to_insert = tuple(
                    rule_rule_defintiton_bak_details.iloc[0][
                        all_columns
                    ]  # Exclude rule_id
                    .apply(convert_value)
                    .tolist()
                )
                logging.info(f'data_to_insert----------{data_to_insert}')
                with mssql_conn.cursor() as cursor:
                    cursor.execute(insert_query, data_to_insert)
                    version_id = cursor.fetchone()[0]
                    logging.info(f"New version ID inserted: {version_id}")
                    mssql_conn.commit()
                logging.info("Data inserted successfully.")

                # now get the version_id and update back in rule_definition table

                update_query = f"""
                    UPDATE {onepoint_o_database}.dbo.RULE_RuleDefinition
                    SET VersionId = %s
                    WHERE id = %s
                """

                # Get the new version_id (this was fetched earlier after the insert)
                # 'version_id' is the ID of the newly inserted row in the RULE_Version table
                logging.info(
                    f"Updating RULE_RuleDefinition with version_id {version_id} for id {new_id}"
                )

                # Execute the UPDATE query
                with mssql_conn.cursor() as cursor:
                    cursor.execute(update_query, (version_id, new_id))
                    mssql_conn.commit()

                logging.info("RULE_RuleDefinition table updated successfully.")

            rule_rule_defintiton_customer_details_query = f"select rule_id_1_0, customers_list, created_date, created_by from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}'"
            rule_rule_definition_customer_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_customer_details_query
            )

            logging.info(f'rule_rule_definition_customer_details-------------{rule_rule_definition_customer_details}')
            customers_list = rule_rule_definition_customer_details.get("customers_list")
            # logging.info(f'customers_list-----------{customers_list}')
            rule_id_1_0_value = rule_rule_definition_customer_details.get("rule_id_1_0")
            created_date_value = rule_rule_definition_customer_details.get(
                "created_date"
            )
            # logging.info(f'created_date_value----------{created_date_value}')
            created_by_value = rule_rule_definition_customer_details.get("created_by")

            rule_id_1_0 = (
                rule_id_1_0_value.iloc[0] if not rule_id_1_0_value.empty else None
            )
            created_date = (
                created_date_value.iloc[0]
                if not created_date_value.empty
                else datetime.utcnow()
            )
            created_date = created_date.strftime("%Y-%m-%d %H:%M:%S")
            logging.info(f'created_date-----------{created_date}')
            created_by = (
                created_by_value.iloc[0] if not created_by_value.empty else None
            )
            # logging.info(f'customers_list---{customers_list}')
            customers_list = customers_list.iloc[
                0
            ]  # Accessing the first (and probably only) element in the series
            # logging.info(f'customers_list---{customers_list}')
            # customers_data = ast.literal_eval(customers_list)
            customers_data = json.loads(customers_list)
            # logging.info(f'customers_data----------{customers_data}')

            # Now you can access 'customer_names' and 'customer_groups'
            customer_names_id = [
                customer_id
                for customer in customers_data.get("customer_names") or []
                for _, customer_id in customer.items()
            ]
            # customer_groups_id = [group_id for group in customers_data.get("customer_groups") or [] for _, group_id in group.items()]
            customer_groups_id = [
                group_id
                for group in customers_data.get("customer_groups") or []
                for _, group_id in group.items()
            ]
            logging.info(f"in_edit_flag Customer Groups IDs: {customer_groups_id}")
            
            if len(customer_names_id) > 200:
                logging.info(f"Large list detected: {len(customer_names_id)} customers — using batch processing.")

                try:
                    # Validate inputs
                    if not rule_id_1_0:
                        logging.error("RuleId is undefined or None.")
                        raise ValueError("RuleId is required")
                    if not customer_names_id:
                        logging.error("customer_names_id is empty. No records to insert.")
                        raise ValueError("customer_names_id is empty")

                    # Convert RuleId to UUID
                    try:
                        rule_id = uuid.UUID(rule_id_1_0) if isinstance(rule_id_1_0, str) else rule_id_1_0
                    except ValueError as e:
                        logging.error(f"Invalid RuleId format: {e}")
                        raise ValueError(f"RuleId '{rule_id_1_0}' is not a valid UUID")

                    logging.info(f"Converted RuleId: {rule_id}, Type: {type(rule_id)}")

                    # Prepare records for TVP (single-column CustomerId for dbo.CustomerIdList)
                    records = [(int(customer_id),) for customer_id in customer_names_id if customer_id is not None]
                    if not records:
                        logging.error("No valid records prepared after filtering.")
                        raise ValueError("No valid records to insert")

                    logging.info(f"Prepared {len(records)} records for TVP insertion")
                    logging.info(f"Sample record: {records[0] if records else 'None'}")

                    with mssql_conn.cursor() as cursor:
                        # Bulk insert via TVP if SP supports it
                        cursor.fast_executemany = True
                        start_time = time.time()
                        logging.info(f"TVP insertion started | Records: {rule_id}")
                        sql = f"EXEC dbo.InsertNotificationRuleRecipientFromSites '{rule_id}'"
                        cursor.execute(sql)
                        # Example: execute SP that expects TVP and RuleId
                        #cursor.execute("{CALL dbo.InsertNotificationRuleRecipientFromSites (?)}", (str(rule_id),))
                        mssql_conn.commit()

                        elapsed = time.time() - start_time
                        logging.info(f"TVP insertion completed | Time taken: {elapsed:.2f} seconds")

                except Exception as e:
                    logging.error(f"General error occurred while inserting NotificationRuleRecipient records: {e}", exc_info=True)
                    mssql_conn.rollback()
                
            else:
                logging.info(f"Small list detected: {len(customer_names_id)} customers — processing directly.")
                logging.info(f"in_edit_flag Customer Names IDs: {customer_names_id}")
                logging.info(f"in_edit_flag Customer Groups IDs: {customer_groups_id}")
                column_names = "RuleId, CustomerId, CustomerGroupId, CreatedDate, CreatedBy"
                placeholders = "%s, %s, %s, %s, %s"

                logging.info(f"in_edit_flag customer_names_id---------- notifications sync started {type(customer_names_id)}")
                batch_size = 1000 
                try:
                    # Prepare all records first
                    records = [
                        (rule_id_1_0, customer_id, None, created_date, created_by)
                        for customer_id in customer_names_id
                    ]

                    insert_query = f"""
                    INSERT INTO {onepoint_o_database}.dbo.NotificationRuleRecipient ({column_names})
                    VALUES ({placeholders})
                    """
                    logging.info(f"Prepared batch insert query: {insert_query}")

                    with mssql_conn.cursor() as cursor:
                        # Process in batches
                        for i in range(0, len(records), batch_size):
                            batch = records[i : i + batch_size]

                            logging.info(f"Batch {i // batch_size + 1} insertion started into NotificationRuleRecipient table Records: {len(batch)}")

                            start_time = time.time()  # Start timer
                            cursor.executemany(insert_query, batch)
                            mssql_conn.commit()
                            end_time = time.time()  # End timer

                            elapsed = end_time - start_time  #  calculate first
                            logging.info(f"Batch {i // batch_size + 1} insertion completed into NotificationRuleRecipient table  Records: {len(batch)} | Time taken: {elapsed:.2f} seconds")

                except Exception as e:
                    logging.info(f"Error occurred while inserting NotificationRuleRecipient records: {e}")
                    mssql_conn.rollback()
            
            '''try:
                column_names = "RuleId, CustomerId, CustomerGroupId, CreatedDate, CreatedBy"
                placeholders = "%s, %s, %s, %s, %s"

                # Define batch size
                batch_size = 5000  # Adjust as needed

                try:
                    # Prepare all records (CustomerGroupId populated, CustomerId = None)
                    records = [
                        (rule_id_1_0, None, customer_group_id, created_date, created_by)
                        for customer_group_id in customer_groups_id
                    ]

                    insert_query = f"""
                    INSERT INTO {onepoint_o_database}.dbo.NotificationRuleRecipient_Testing ({column_names})
                    VALUES ({placeholders})
                    """
                    logging.info(f"Prepared batch insert query for NotificationRuleRecipient: FOR CUSTOMERGROUPID {insert_query}")

                    with mssql_conn.cursor() as cursor:
                        total_records = len(records)
                        start_all = time.time()

                        # Process in batches
                        for i in range(0, total_records, batch_size):
                            batch = records[i : i + batch_size]

                            logging.info(
                                f"Batch {i // batch_size + 1} insertion started into NotificationRuleRecipient table CUSTOMERGROUPID | Records: {len(batch)}"
                            )

                            start_time = time.time()
                            cursor.fast_executemany = True
                            cursor.executemany(insert_query, batch)
                            mssql_conn.commit()
                            end_time = time.time()

                            elapsed = end_time - start_time
                            logging.info(
                                f"Batch {i // batch_size + 1} insertion completed into NotificationRuleRecipient table CUSTOMERGROUPID | Records: {len(batch)} | Time taken: {elapsed:.2f} seconds"
                            )

                        end_all = time.time()
                        logging.info(
                            f"All batches completed CUSTOMERGROUPID | Total Records: {total_records} | Total Time: {end_all - start_all:.2f} seconds"
                        )

                except Exception as e:
                    logging.error(f"Error occurred while inserting NotificationRuleRecipient (CustomerGroupId records): {e}")
                    mssql_conn.rollback()
            except Exception as e:
                logging.info(f"Error in insert customer_list notifications: 5 {e}")
                pass'''

            logging.info("Data inserted into notifiaction table successfully.")

            # fetching the data of expression list from 2.0 based on rule_id

            expression_details_query = (
                f"select * from rule_rule_definition where id = '{rule_id_2_0}'"
            )
            expression_details_df = self.execute_query(
                postgres_conn, expression_details_query
            )
            # expression_ids = expression_details_df.get('expression_ids')
            expression_details_str = expression_details_df["expression_ids"].iloc[0]
            created_date = expression_details_df["created_date"].iloc[0]
            created_by = expression_details_df["created_by"].iloc[0]
            # created_date= created_date_value.iloc[0] if not created_date_value.empty else datetime.utcnow()
            created_date = created_date.strftime("%Y-%m-%d %H:%M:%S")
            # logging.info(f'created_date------------{created_date}')
            expression_details = json.loads(expression_details_str)
            logging.info(f'expression_details---------{expression_details}')

            def get_type(value):
                if isinstance(value, bool):
                    return "Boolean"
                if isinstance(value, int) and value > 10**9:
                    return "BigInteger"
                elif isinstance(value, int):
                    return "Integer"
                elif isinstance(value, float):
                    return "Decimal"
                elif isinstance(value, str):
                    try:
                        int(value)
                        return "Integer"
                    except ValueError:
                        pass
                    try:
                        float(value)
                        return "Decimal"
                    except ValueError:
                        pass
                    return "String"
                elif isinstance(value, str) and ("-" in value or ":" in value):
                    return "DateTime"
                try:
                    import uuid

                    uuid.UUID(value)
                    return "Guid"
                except (ValueError, TypeError):
                    pass
                if isinstance(value, str) and value.startswith("$"):
                    return "Money"
                return "Unknown"
            

            def inserting_bak_29_10_2025(expression_details, ordinal_counter):
                field_1_id = None
                const_one_id = None
                field_2_id = None
                const_two_id = None
                logging.info("inserting of an expression")
                logging.info(f"expression_details----------{expression_details}")
                condtion_value = list(expression_details["cond"].values())[0]
                if (
                    "const_one" in expression_details
                    or "field_one" in expression_details
                ):
                    if "field_one" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            # field_one_value = list(expression_details['field_one'].values())[0]
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Constant';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            constant_value = expression_details["field_one"]
                            logging.info(f"constant_value-----{constant_value}")
                            constant_type = get_type(constant_value)
                            logging.info(f"constant_type-----{constant_type}")
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            constant_type_id_query = f""" select id from {onepoint_o_database}.dbo.DataType where DataTypeName = '{constant_type}';"""
                            query_result = self.execute_query(
                                mssql_conn, constant_type_id_query
                            )
                            logging.info(f"query_result---------{query_result}")
                            change_type_id = query_result.iloc[0]["id"]
                            logging.info(f"change_type_id---------{change_type_id}")
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                expression_details["field_one"],
                                change_type_id,
                                created_by,
                                created_date,
                                ordinal_counter,
                                version_id,
                            )
                            logging.info(f"data_to_insert-----------{data_to_insert}")
                            try:
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                                """
                                logging.info(f"insert_query RULE_Expression {insert_query}")
                                cursor.execute(insert_query, data_to_insert)
                                field_1_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted:RULE_Expression {field_1_id}")
                                logging.info(f'{expression_details["field_one"]} inserted field_one')
                                mssql_conn.commit()
                            except Exception as e:
                                logging.error(f"Error inserting field_one: {e}")
                                logging.info(f"Error inserting field_one: {e}")
                                mssql_conn.rollback()
                                return None
                    elif "const_one" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Field';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            const_one_value = list(
                                expression_details["const_one"].values()
                            )[0]
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                const_one_value,
                                created_by,
                                created_date,
                                ordinal_counter,
                                version_id,
                            )
                            insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s);
                            """
                            cursor.execute(insert_query, data_to_insert)
                            const_one_id = cursor.fetchone()[0]
                            logging.info(f"New ID inserted RULE_Expression {const_one_id}")
                            logging.info(f'{expression_details["const_one"]} inserted const_one')
                            mssql_conn.commit()
                if (
                    "field_two" in expression_details
                    or "const_two" in expression_details
                ):
                    # if condtion_value == 'HAS vALUE' or 'HAS NO VALUE':
                    if "field_two" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Constant';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            field_two_value = expression_details.get("field_two")
                            logging.info(f"field_two_value------------{field_two_value}")
                            if not field_two_value:  # Handle empty const_two
                                logging.info("field_two is empty; skipping insertion.")
                            else:
                                unit = expression_details.get("unit", "").lower()
                                logging.info(f"unit-----------{unit}")
                                # Default to an empty string if 'unit' is missing
                                if unit:
                                    logging.info(f"if unit condition")
                                    try:
                                        field_two_numeric = float(
                                            field_two_value
                                        )  # Ensure it's numeric for conversion
                                        logging.info(
                                            f"field_two_numeric----------{field_two_numeric}"
                                        )
                                        if unit == "mb":
                                            field_two_value = (
                                                field_two_numeric * 1024**2
                                            )
                                            field_two_value = int(field_two_value)

                                        elif unit == "gb":
                                            field_two_value = (
                                                field_two_numeric * 1024**3
                                            )
                                            field_two_value = int(field_two_value)
                                        else:
                                            logging.info(
                                                f"Unit '{unit}' is not recognized; assuming value is already in bytes."
                                            )
                                        logging.info(
                                            f"field_two_value---------------{field_two_value}"
                                        )
                                    except ValueError:
                                        logging.info(
                                            f"Error: field_two value '{field_two_value}' is not numeric."
                                        )
                                else:
                                    logging.info(
                                        "No unit provided; assuming field_two is in bytes."
                                    )

                                constant_type = get_type(field_two_value)
                                logging.info(f"constant_type-----{constant_type}")
                                logging.info(
                                    f"expression_type_id-----------{expression_type_id}"
                                )
                                constant_type_id_query = f""" select id from {onepoint_o_database}.dbo.DataType where DataTypeName = '{constant_type}';"""
                                logging.info(
                                    f"constant_type_id_query------------{constant_type_id_query}"
                                )
                                query_result = self.execute_query(
                                    mssql_conn, constant_type_id_query
                                )
                                logging.info(f"query_result---------{query_result}")
                                change_type_id = query_result.iloc[0]["id"]
                                logging.info(f"change_type_id---------{change_type_id}")

                                # field_two_value = list(expression_details['field_two'].values())[0]
                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    field_two_value,
                                    int(change_type_id),
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    version_id,
                                )
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                                """
                                logging.info(f"insert_query-------{insert_query}")
                                logging.info(f"data_to_insert--------{data_to_insert}")
                                cursor.execute(insert_query, data_to_insert)
                                field_2_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted RULE_Expression {field_2_id}")
                                logging.info(f'{expression_details["field_two"]} inserted field_two')
                                mssql_conn.commit()
                    elif "const_two" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Field';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            const_two_details = expression_details.get("const_two", {})
                            if not const_two_details:  # Handle empty const_two
                                logging.info("const_two_value is empty; skipping insertion.")
                            else:
                                const_two_value = list(
                                    expression_details["const_two"].values()
                                )[0]
                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    const_two_value,
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    version_id,
                                )
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s);
                                """
                                cursor.execute(insert_query, data_to_insert)
                                const_two_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted RULE_Expression {const_two_id}")
                                logging.info(f' {expression_details["const_two"]} inserted const_two')
                                mssql_conn.commit()
                left_hand_expression_id = field_1_id or const_one_id
                right_hand_expression_id = field_2_id or const_two_id
                condtion_value = list(expression_details["cond"].values())[0]
                logging.info(f"left_hand_expression_id------------{left_hand_expression_id}")
                logging.info(
                    f"right_hand_expression_id--------------{right_hand_expression_id}"
                )
                logging.info(f"condtion_value-----------{condtion_value}")
                logging.info(
                    f"before inserting left_hand_expression_id and right_hand_expression_id -----------{ordinal_counter}"
                )
                # if left_hand_expression_id and right_hand_expression_id and condtion_value:
                if condtion_value:
                    expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Simple';"""
                    query_result = self.execute_query(
                        mssql_conn, expression_type_id_query
                    )
                    expression_type_id = query_result.iloc[0]["id"]
                    logging.info(f"expression_type_id-----------{expression_type_id}")
                    right_hand_expression_id = right_hand_expression_id or "NULL"
                    with mssql_conn.cursor() as cursor:
                        final_insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, Ordinal, VersionId)  OUTPUT INSERTED.id
                        VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', {right_hand_expression_id if right_hand_expression_id == 'NULL' else f"'{right_hand_expression_id}'"}, '{condtion_value}', '{created_by}', '{created_date}', {ordinal_counter}, '{version_id}') ;
                        """
                        cursor.execute(final_insert_query)
                        final_query_id = cursor.fetchone()[0]
                        logging.info(f"final_query_id--------------{final_query_id}")
                        logging.info("Final rule_expression inserted")
                        mssql_conn.commit()
                        # with mssql_conn.cursor() as cursor:
                        #     update_ordinal_query = f"""
                        #     UPDATE {onepoint_o_database}.dbo.RULE_Expression
                        #     SET Ordinal = {ordinal_counter}
                        #     WHERE id IN ('{left_hand_expression_id}', '{right_hand_expression_id}', '{final_query_id}')
                        #     """
                        #     cursor.execute(update_ordinal_query)
                        #     mssql_conn.commit()
                logging.info(f'{expression_details["cond"]} inserted cond')

                return final_query_id

            def expresion_builder_bak_29_10_2025(expression_details, ordinal_counter):
                logging.info(f"in create function")
                if len(expression_details) > 1:
                    logging.info(f"exp got is", expression_details)
                    logging.info(f"\n")
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    exp_3_id, ordinal_counter = expresion_builder(
                        expression_details[2:], ordinal_counter
                    )
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    logging.info(f"exp_3_id--------{exp_3_id}")
                    if ordinal_counter % 2 == 0:
                        ordinal_counter = ordinal_counter - 1
                    exp_1_id = inserting(expression_details[0], ordinal_counter)
                    ordinal_counter = ordinal_counter + 1
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    logging.info(f"exp_1_id--------{exp_1_id}")
                    cond = list(expression_details[1].values())[0]
                    logging.info(f"cond------{cond}")
                    left_hand_expression_id = (
                        exp_1_id  # The first expression part (field_1 or const_one)
                    )
                    right_hand_expression_id = exp_3_id
                    logging.info(
                        f"left_hand_expression_id--------------{left_hand_expression_id}"
                    )
                    logging.info(
                        f"right_hand_expression_id------------{right_hand_expression_id}"
                    )
                    logging.info(exp_1_id, cond, exp_3_id)
                    if cond == "OR":
                        operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                        operator_type = self.execute_query(
                            postgres_conn, operator_type_query
                        )
                        operator_type = operator_type["id"].iloc[0]
                        logging.info(f"operator_type----------{operator_type}")
                        expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                        query_result = self.execute_query(
                            mssql_conn, expression_type_id_query
                        )
                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"expression_type_id-----------{expression_type_id}")
                        with mssql_conn.cursor() as cursor:
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                            VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                            """
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            logging.info(f"final_query_id--------------{final_query_id}")
                            logging.info("Final rule_expression inserted")
                            mssql_conn.commit()
                            with mssql_conn.cursor() as cursor:
                                update_ordinal_query = f"""
                                UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                SET Ordinal = {ordinal_counter}
                                WHERE id IN ('{final_query_id}')
                                """
                                cursor.execute(update_ordinal_query)
                                mssql_conn.commit()
                            return final_query_id, ordinal_counter - 2

                    elif cond == "AND":
                        expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                        query_result = self.execute_query(
                            mssql_conn, expression_type_id_query
                        )
                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"expression_type_id-----------{expression_type_id}")
                        operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                        operator_type = self.execute_query(
                            postgres_conn, operator_type_query
                        )
                        operator_type = operator_type["id"].iloc[0]
                        with mssql_conn.cursor() as cursor:
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                            VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                            """
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            logging.info(f"final_query_id--------------{final_query_id}")
                            logging.info("Final rule_expression inserted")
                            mssql_conn.commit()
                            with mssql_conn.cursor() as cursor:
                                update_ordinal_query = f"""
                                UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                SET Ordinal = {ordinal_counter}
                                WHERE id IN ('{final_query_id}')
                                """
                                cursor.execute(update_ordinal_query)
                                mssql_conn.commit()
                            return final_query_id, ordinal_counter - 2
                else:
                    logging.info(f"exp got is in else {expression_details}")
                    logging.info(f"\n")
                    expression_details = expression_details[0]
                    logging.info(f"ordinal_counter-----------{ordinal_counter}")
                    return (
                        inserting(expression_details, ordinal_counter),
                        ordinal_counter - 2,
                    )

            # ordinal_counter = len(expression_details)
            # # ordinal_counter = 1
            # expresion_builder(expression_details, ordinal_counter)
            try:
                logging.info(f"Expressions syncing")
                def inserting(expression_details, ordinal_counter):
                    field_1_id = const_one_id = field_2_id = const_two_id = None
                    logging.info(" Inserting an expression")
                    logging.info(f"expression_details → {expression_details}")

                    try:
                        condtion_value = list(expression_details["cond"].values())[0]
                    except Exception as e:
                        logging.info(f" Missing condition in expression_details: {e}")
                        return None

                    # ------------------- FIELD ONE or CONST ONE -------------------
                    try:
                        if "field_one" in expression_details:
                            logging.info("🟦 Processing field_one...")
                            expression_type_id_query = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Constant';"
                            query_result = self.execute_query(mssql_conn, expression_type_id_query)
                            expression_type_id = query_result.iloc[0]["id"]

                            constant_value = expression_details["field_one"]
                            constant_type = get_type(constant_value)
                            constant_type_id_query = f"SELECT id FROM {onepoint_o_database}.dbo.DataType WHERE DataTypeName = '{constant_type}';"
                            query_result = self.execute_query(mssql_conn, constant_type_id_query)
                            change_type_id = query_result.iloc[0]["id"]

                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                constant_value,
                                change_type_id,
                                created_by,
                                created_date,
                                ordinal_counter,
                                version_id,
                            )

                            insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression 
                                (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                            """

                            with mssql_conn.cursor() as cursor:
                                cursor.execute(insert_query, data_to_insert)
                                field_1_id = cursor.fetchone()[0]
                                mssql_conn.commit()

                            logging.info(f" field_one inserted successfully: {field_1_id}")

                        elif "const_one" in expression_details:
                            logging.info(" Processing const_one...")
                            expression_type_id_query = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Field';"
                            query_result = self.execute_query(mssql_conn, expression_type_id_query)
                            expression_type_id = query_result.iloc[0]["id"]

                            const_one_value = list(expression_details["const_one"].values())[0]
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                const_one_value,
                                created_by,
                                created_date,
                                ordinal_counter,
                                version_id,
                            )

                            insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                                (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s);
                            """

                            with mssql_conn.cursor() as cursor:
                                cursor.execute(insert_query, data_to_insert)
                                const_one_id = cursor.fetchone()[0]
                                mssql_conn.commit()

                            logging.info(f" const_one inserted successfully: {const_one_id}")

                    except Exception as e:
                        logging.info(f"❌ Error inserting field_one/const_one: {e}")
                        traceback.logging.info_exc()
                        mssql_conn.rollback()

                    # ------------------- FIELD TWO or CONST TWO -------------------
                    try:
                        if "field_two" in expression_details:
                            logging.info(" Processing field_two...")
                            expression_type_id_query = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Constant';"
                            query_result = self.execute_query(mssql_conn, expression_type_id_query)
                            expression_type_id = query_result.iloc[0]["id"]

                            field_two_value = expression_details.get("field_two")
                            if not field_two_value:
                                logging.info(" field_two is empty; skipping insertion.")
                            else:
                                unit = expression_details.get("unit", "").lower()
                                if unit:
                                    try:
                                        field_two_numeric = float(field_two_value)
                                        if unit == "mb":
                                            field_two_value = int(field_two_numeric * 1024**2)
                                        elif unit == "gb":
                                            field_two_value = int(field_two_numeric * 1024**3)
                                    except ValueError:
                                        logging.info(f"⚠️ Invalid numeric value for field_two: {field_two_value}")

                                constant_type = get_type(field_two_value)
                                constant_type_id_query = f"SELECT id FROM {onepoint_o_database}.dbo.DataType WHERE DataTypeName = '{constant_type}';"
                                query_result = self.execute_query(mssql_conn, constant_type_id_query)
                                change_type_id = query_result.iloc[0]["id"]

                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    field_two_value,
                                    int(change_type_id),
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    version_id,
                                )

                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                                    (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                                """

                                with mssql_conn.cursor() as cursor:
                                    cursor.execute(insert_query, data_to_insert)
                                    field_2_id = cursor.fetchone()[0]
                                    mssql_conn.commit()

                                logging.info(f" field_two inserted successfully: {field_2_id}")

                        elif "const_two" in expression_details:
                            logging.info(" Processing const_two...")
                            expression_type_id_query = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Field';"
                            query_result = self.execute_query(mssql_conn, expression_type_id_query)
                            expression_type_id = query_result.iloc[0]["id"]

                            const_two_value = list(expression_details["const_two"].values())[0]
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                const_two_value,
                                created_by,
                                created_date,
                                ordinal_counter,
                                version_id,
                            )

                            insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                                (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s);
                            """

                            with mssql_conn.cursor() as cursor:
                                cursor.execute(insert_query, data_to_insert)
                                const_two_id = cursor.fetchone()[0]
                                mssql_conn.commit()

                            logging.info(f"const_two inserted successfully: {const_two_id}")

                    except Exception as e:
                        logging.info(f"Error inserting field_two/const_two: {e}")
                        traceback.logging.info_exc()
                        mssql_conn.rollback()

                    # ------------------- FINAL EXPRESSION -------------------
                    try:
                        left_hand_expression_id = field_1_id or const_one_id
                        right_hand_expression_id = field_2_id or const_two_id
                        logging.info(f"Left: {left_hand_expression_id}, Right: {right_hand_expression_id}, Condition: {condtion_value}")

                        if condtion_value:
                            expression_type_id_query = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Simple';"
                            query_result = self.execute_query(mssql_conn, expression_type_id_query)
                            expression_type_id = query_result.iloc[0]["id"]

                            right_expr_val = (
                                "NULL" if not right_hand_expression_id else f"'{right_hand_expression_id}'"
                            )

                            final_insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                                (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', {right_expr_val}, '{condtion_value}', '{created_by}', '{created_date}', {ordinal_counter}, '{version_id}');
                            """

                            with mssql_conn.cursor() as cursor:
                                cursor.execute(final_insert_query)
                                final_query_id = cursor.fetchone()[0]
                                mssql_conn.commit()

                            logging.info(f"Final RULE_Expression inserted: {final_query_id}")
                            return final_query_id

                    except Exception as e:
                        logging.info(f"Error inserting final expression: {e}")
                        traceback.logging.info_exc()
                        mssql_conn.rollback()

                    return None

                def expresion_builder(expression_details, ordinal_counter):
                    logging.info(f"in create function")
                    if len(expression_details) > 1:
                        logging.info(f"exp got is", expression_details)
                        logging.info(f"ordinal_counter----------{ordinal_counter}")
                        exp_3_id, ordinal_counter = expresion_builder(
                            expression_details[2:], ordinal_counter
                        )
                        logging.info(f"ordinal_counter----------{ordinal_counter}")
                        logging.info(f"exp_3_id--------{exp_3_id}")
                        if ordinal_counter % 2 == 0:
                            ordinal_counter = ordinal_counter - 1
                        exp_1_id = inserting(expression_details[0], ordinal_counter)
                        ordinal_counter = ordinal_counter + 1
                        logging.info(f"ordinal_counter----------{ordinal_counter}")
                        logging.info(f"exp_1_id--------{exp_1_id}")
                        cond = list(expression_details[1].values())[0]
                        logging.info(f"cond------{cond}")
                        left_hand_expression_id = (
                            exp_1_id  # The first expression part (field_1 or const_one)
                        )
                        right_hand_expression_id = exp_3_id
                        logging.info(
                            f"left_hand_expression_id--------------{left_hand_expression_id}"
                        )
                        logging.info(
                            f"right_hand_expression_id------------{right_hand_expression_id}"
                        )
                        logging.info(exp_1_id, cond, exp_3_id)
                        if cond == "OR":
                            operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                            operator_type = self.execute_query(
                                postgres_conn, operator_type_query
                            )
                            operator_type = operator_type["id"].iloc[0]
                            logging.info(f"operator_type----------{operator_type}")
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            with mssql_conn.cursor() as cursor:
                                final_insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                                VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                                """
                                cursor.execute(final_insert_query)
                                final_query_id = cursor.fetchone()[0]
                                logging.info(f"final_query_id--------------{final_query_id}")
                                logging.info("Final rule_expression inserted")
                                mssql_conn.commit()
                                with mssql_conn.cursor() as cursor:
                                    update_ordinal_query = f"""
                                    UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                    SET Ordinal = {ordinal_counter}
                                    WHERE id IN ('{final_query_id}')
                                    """
                                    cursor.execute(update_ordinal_query)
                                    mssql_conn.commit()
                                return final_query_id, ordinal_counter - 2

                        elif cond == "AND":
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                            operator_type = self.execute_query(
                                postgres_conn, operator_type_query
                            )
                            operator_type = operator_type["id"].iloc[0]
                            with mssql_conn.cursor() as cursor:
                                final_insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                                VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                                """
                                cursor.execute(final_insert_query)
                                final_query_id = cursor.fetchone()[0]
                                logging.info(f"final_query_id--------------{final_query_id}")
                                logging.info("Final rule_expression inserted")
                                mssql_conn.commit()
                                with mssql_conn.cursor() as cursor:
                                    update_ordinal_query = f"""
                                    UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                    SET Ordinal = {ordinal_counter}
                                    WHERE id IN ('{final_query_id}')
                                    """
                                    cursor.execute(update_ordinal_query)
                                    mssql_conn.commit()
                                return final_query_id, ordinal_counter - 2
                    else:
                        logging.info(f"exp got is in else {expression_details}")
                        expression_details = expression_details[0]
                        logging.info(f"ordinal_counter-----------{ordinal_counter}")
                        return (
                            inserting(expression_details, ordinal_counter),
                            ordinal_counter - 2,
                        )

                ordinal_counter = len(expression_details)
                # ordinal_counter = 1
                expresion_builder(expression_details, ordinal_counter)
            except Exception as e: 
                logging.info(f"An error occured {e}")

        elif flag == "delete":
            rule_rule_defintiton_details_query = f"select rule_id_1_0, deleted_date, deleted_by from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}'"
            rule_rule_definition_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_details_query
            )
            logging.info(f"rule_rule_definition_details--------{rule_rule_definition_details}")
            rule_id_1_0 = rule_rule_definition_details.get("rule_id_1_0")
            logging.info(f"rule_id_1_0--------{rule_id_1_0}")
            deleted_date = rule_rule_definition_details.get("deleted_date")
            deleted_by = rule_rule_definition_details.get("deleted_by")
            deleted_date = deleted_date.iloc[0]
            if pd.isna(deleted_date):
                deleted_date = "NULL"
            else:
                deleted_date = f"'{deleted_date.strftime('%Y-%m-%d %H:%M:%S')}'"
            deleted_by = deleted_by.iloc[0]
            rule_id_1_0 = rule_id_1_0.iloc[0]

            delete_query = f"update {onepoint_o_database}.dbo.RULE_RuleDefinition set IsActive = '0', IsDeleted = '1', DeletedDate = {deleted_date}, DeletedBy = '{deleted_by}' where id = '{rule_id_1_0}'"
            logging.info(f"delete_query----------{delete_query}")
            with mssql_conn.cursor() as cursor:
                cursor.execute(delete_query)
                mssql_conn.commit()

        elif flag == "edit":

            # fetch the details from 2.0 rule_rule_definition table

            rule_rule_defintiton_rule_id_1_0_query = f"select rule_id_1_0 from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}' and rule_id_1_0 is not null order by created_date desc"
            rule_rule_defintiton_rule_id_1_0 = self.execute_query(
                postgres_conn, rule_rule_defintiton_rule_id_1_0_query
            )
            rule_id_1_0 = rule_rule_defintiton_rule_id_1_0.loc[0, "rule_id_1_0"]
            logging.info(f"rule_id_1_0 in edit ---------{rule_id_1_0}")

            with postgres_conn.cursor() as cursor:
                update_query = f"""
                    UPDATE public.rule_rule_definition
                    SET rule_id_1_0 = '{rule_id_1_0}'
                    WHERE rule_def_id = '{rule_id_2_0}' AND is_active = true
                    """
                logging.info(f"update_query in edit----------{update_query}")
                cursor.execute(update_query)
                postgres_conn.commit()
                logging.info(f"in_edit_flag Updated 1_0_rule_id in rule_rule_definition table")

            rule_rule_defintiton_details_query = f"select id,object_type_id,rule_id,name,priority,subject_line,display_message,notes,order_of_execution,created_date,created_by,modified_by,modified_date,is_active,is_deleted,send_to_carrier,send_to_customer,should_show_projected_usage_cost,should_send_single_email_to_customer_group,aggregated_customer_email_recipient,should_exclude_pooled_device,rule_id_1_0  from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}' and is_active = true"
            rule_rule_definition_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_details_query
            )
            logging.info(
                f"in_edit_flag rule_rule_definition_details-----------{rule_rule_definition_details}"
            )

            # fetch rule_id_1_0 column to take that as id column to update in 1.0 rule_defintion table
            # rule_id_1_0 = rule_rule_definition_details.loc[0, "rule_id_1_0"]
            # logging.info(f"in_edit_flag rule_id_1_0-----{rule_id_1_0}")
            try: 
                rule_id_1_0 = rule_rule_definition_details.loc[0, "rule_id_1_0"]
                print(f"in_edit_flag rule_id_1_0-----{rule_id_1_0}")
            except Exception as e: 
                print(f"An error occured exception rule_id_10 not found {e}")
                return True

            # dropping id details
            #rule_rule_definition_details = rule_rule_definition_details.drop(columns=["id"])
            rule_rule_definition_details = rule_rule_definition_details.drop(columns=["id","rule_id_1_0"])


            # updating the details in rule_definition tables with the latest data
            all_columns = rule_rule_definition_details.columns
            columns_to_insert_camel_case = [to_camel_case(col) for col in all_columns]
            logging.info(f'in_edit_flag columns_to_insert-----------{columns_to_insert_camel_case}')
            # update_set_statements = ", ".join(columns_to_insert_camel_case)
            # logging.info(f'update_set_statements-------------{update_set_statements}')

            update_set_statements = ", ".join(
                [f"{col} = %s" for col in columns_to_insert_camel_case]
            )
            # logging.info(f'update_set_statements-----------{update_set_statements}')
            update_query = f"UPDATE {onepoint_o_database}.dbo.RULE_RuleDefinition SET {update_set_statements} WHERE id = '{rule_id_1_0}'"
            logging.info(f"in_edit_flag Update query: {update_query}")

            def convert_value(value):
                if isinstance(
                    value, pd.Timestamp
                ):  # Convert pandas.Timestamp to Python datetime
                    return value.to_pydatetime()
                if isinstance(value, bool):  # Ensure booleans are Python native
                    return bool(value)
                if isinstance(value, np.bool_):  # Convert numpy.bool_ to Python bool
                    return bool(value)
                if isinstance(
                    value, np.int64
                ):  # Explicitly handle numpy.int64 conversion to int
                    return int(value)
                if pd.isna(value):  # Convert NaT (pandas missing time) to None for SQL
                    return None
                if value is None:  # Handle None (SQL NULL)
                    return None
                return value  # Leave other types as they are

            # logging.info(len(all_columns))
            # logging.info(len(rule_rule_definition_details.columns))
            update_values = [
                convert_value(value)
                for value in rule_rule_definition_details.iloc[0].tolist()
            ]
            update_values = [
                value if value is not None else None for value in update_values
            ]
            update_values = tuple(update_values)
            logging.info(f"in_edit_flag values -----------{update_values}")
            with mssql_conn.cursor() as cursor:
                cursor.execute(update_query, update_values)
                mssql_conn.commit()

            logging.info(f"in_edit_flag query is executed to edit the rule_rule_definition")

            # insert the details as a new row in rules_verison table

            rule_rule_definition_updated_details_query = f"select * from {onepoint_o_database}.dbo.RULE_RuleDefinition where id = '{rule_id_1_0}'"
            rule_rule_definition_updated_details = self.execute_query(
                mssql_conn, rule_rule_definition_updated_details_query
            )

            logging.info(
                f"in_edit_flag rule_rule_definition_updated_details------------{rule_rule_definition_updated_details.columns}"
            )

            if not rule_rule_definition_updated_details.empty:
                rule_rule_definition_updated_details = (
                    rule_rule_definition_updated_details.drop(columns=["RuleId"])
                )
                rule_rule_definition_updated_details = (
                    rule_rule_definition_updated_details.drop(columns=["VersionId"])
                )
                rule_rule_definition_updated_details = (
                    rule_rule_definition_updated_details.rename(
                        columns={"id": "RuleId"}
                    )
                )
                columns_to_insert = rule_rule_definition_updated_details.columns
                # columns_to_insert = all_columns[:-8]  # Exclude last 5 columns and rule_id column
                logging.info(f"in_edit_flag columns_to_insert-----------{columns_to_insert}")
                column_names = ", ".join(columns_to_insert)
                placeholders = ", ".join(["%s"] * len(columns_to_insert))

                insert_query = f"""
                    INSERT INTO {onepoint_o_database}.dbo.RULE_Version ({column_names}) OUTPUT INSERTED.id
                    VALUES ({placeholders})
                    """
                logging.info(f"in_edit_flag insert_query-----------{insert_query}")

                # Build the INSERT query dynamically
                def convert_value(x):
                    if isinstance(x, np.int64):
                        return int(x)
                    elif isinstance(x, np.float64):
                        return float(x)
                    elif isinstance(x, np.bool_):
                        return bool(x)
                    elif isinstance(x, pd.Timestamp):
                        return x.to_pydatetime()
                    else:
                        return x

                data_to_insert = (
                    rule_rule_definition_updated_details.iloc[0][
                        columns_to_insert
                    ]  # Exclude rule_id
                    .apply(convert_value)
                    .tolist()
                )
                logging.info(f"in_edit_flag data_to_insert----------{data_to_insert}")
                with mssql_conn.cursor() as cursor:
                    cursor.execute(insert_query, tuple(data_to_insert))
                    new_id = cursor.fetchone()[0]
                    logging.info(f"in_edit_flag New ID inserted: {new_id}")
                    cursor.execute(
                        f"SELECT VersionNumber FROM {onepoint_o_database}.dbo.RULE_Version WHERE RuleId = %s order by VersionNumber desc",
                        (rule_id_1_0,),
                    )
                    current_version_number = cursor.fetchone()
                    logging.info(
                        f"in_edit_flag Current VersionNumber before update: {current_version_number}"
                    )
                    updated_version_number = int(current_version_number[0]) + 1
                    mssql_conn.commit()
                    update_query = f"""UPDATE {onepoint_o_database}.dbo.RULE_Version
                                    SET "VersionNumber" = %s
                                    WHERE id = %s"""
                    logging.info(f"in_edit_flag update_query----------{update_query}")
                    cursor.execute(update_query, (updated_version_number, new_id))
                    mssql_conn.commit()
                    logging.info(f"in_edit_flag Updated version_number in rule version table table")
                # fetched the id from updated_rule version and update it back to rule_defintion

                update_query = f"""
                    UPDATE {onepoint_o_database}.dbo.RULE_RuleDefinition
                    SET VersionId = %s
                    WHERE id = %s
                """

                # Get the new version_id (this was fetched earlier after the insert)
                # 'version_id' is the ID of the newly inserted row in the RULE_Version table
                logging.info(
                    f"in_edit_flag Updating RULE_RuleDefinition with version_id {new_id} for id {rule_id_1_0}"
                )

                # Execute the UPDATE query
                with mssql_conn.cursor() as cursor:
                    cursor.execute(update_query, (new_id, rule_id_1_0))
                    mssql_conn.commit()

                logging.info("in_edit_flag Data inserted successfully.")

            # edit customer_list based on changes
            customer_list_edited_details_query = f"select * from {onepoint_o_database}.dbo.NotificationRuleRecipient where RuleId = '{rule_id_1_0}'"
            customer_list_edited_details = self.execute_query(
                mssql_conn, customer_list_edited_details_query
            )
            try:
                logging.info("###Started debugginh")

                if not customer_list_edited_details.empty:
                    delete_query = f"DELETE FROM {onepoint_o_database}.dbo.NotificationRuleRecipient WHERE RuleId = '{rule_id_1_0}'"
                    with mssql_conn.cursor() as cursor:
                        cursor.execute(delete_query)
                        mssql_conn.commit()
                rule_rule_defintiton_customer_details_query = f"select rule_id_1_0, customers_list, created_date, created_by from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}' and is_active = true"
                rule_rule_definition_customer_details = self.execute_query(
                    postgres_conn, rule_rule_defintiton_customer_details_query
                )

                logging.info(
                    f"in_edit_flag rule_rule_definition_customer_details-------------{rule_rule_definition_customer_details.to_dict()}"
                )
                rule_rule_definition_customer_details = rule_rule_definition_customer_details.to_dict()
                customers_list = rule_rule_definition_customer_details.get("customers_list")
                logging.info(f"in_edit_flag customers_list--------{customers_list}")
                rule_id_1_0_value = rule_rule_definition_customer_details.get("rule_id_1_0")
                created_date_value = rule_rule_definition_customer_details.get(
                    "created_date"
                )
            except Exception as e:
                logging.info(f"Error in edit customer_list notifications: 2{e}")
            created_by_value = rule_rule_definition_customer_details.get("created_by")
            logging.info(f"44444444 created_by_value {created_by_value}")
            try:
                logging.info(f"3333333333 rule_id_1_0 {rule_id_1_0} {rule_id_1_0_value} {type(rule_id_1_0_value)}")

                if isinstance(rule_id_1_0_value, dict):
                    # Extract the first value from the dict
                    rule_id_1_0 = list(rule_id_1_0_value.values())[0]
                elif hasattr(rule_id_1_0_value, "iloc"):  
                    # If it's a DataFrame/Series
                    rule_id_1_0 = rule_id_1_0_value.iloc[0] if not rule_id_1_0_value.empty else None
                else:
                    rule_id_1_0 = rule_id_1_0_value  # already a raw value

                if isinstance(created_date_value, dict):
                    created_date = list(created_date_value.values())[0]
                elif hasattr(created_date_value, "iloc"):
                    created_date = created_date_value.iloc[0] if not created_date_value.empty else None
                else:
                    created_date = created_date_value

                if isinstance(created_by_value, dict):
                    created_by = list(created_by_value.values())[0]
                elif hasattr(created_by_value, "iloc"):
                    created_by = created_by_value.iloc[0] if not created_by_value.empty else None
                else:
                    created_by = created_by_value

                logging.info(f"[DEBUG] Parsed -> rule_id_1_0={rule_id_1_0}, created_date={created_date}, created_by={created_by}")

            except Exception as e:
                logging.info(f"Error in edit customer_list notifications: 3 {e}")
            logging.info(f'22222222222222222in_edit_flag customers_list---{customers_list}')
            # if created_date is not None: 
            #     created_date = created_date.strftime("%Y-%m-%d %H:%M:%S")
            #customers_list = customers_list.iloc[0]
            # Accessing the first (and probably only) element in the series
            logging.info(f"111 in_edit_flag customers_list-----")
            try:
                created_date=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
                try:
                    customers_data = ast.literal_eval(customers_list[0])
                except Exception as e:
                    logging.info(f"Error in edit customer_list notifications: 4 {e}")
                    customers_data = json.loads(customers_list[0])
            except Exception as ex:
                logging.info(f"Error in edit customer_list notifications: 1 {ex}")
            logging.info(f"in_edit_flag customers_data----------{customers_data}")

            # Now you can access 'customer_names' and 'customer_groups'
            customer_names_id = [
                customer_id
                for customer in customers_data.get("customer_names") or []
                for _, customer_id in customer.items()
            ]
            # customer_groups_id = [group_id for group in customers_data.get("customer_groups") or [] for _, group_id in group.items()]
            customer_groups_id = [
                group_id
                for group in customers_data.get("customer_groups") or []
                for _, group_id in group.items()
            ]

            logging.info(f"in_edit_flag Customer Names IDs: {customer_names_id}")
            logging.info(f"in_edit_flag Customer Groups IDs: {customer_groups_id}")
            logging.info(f"in_edit_flag Customer Groups IDs: {customer_groups_id}")
            
            if len(customer_names_id) > 200:
                logging.info(f"Large list detected: {len(customer_names_id)} customers — using batch processing.")

                try:
                    # Validate inputs
                    if not rule_id_1_0:
                        logging.error("RuleId is undefined or None.")
                        raise ValueError("RuleId is required")
                    if not customer_names_id:
                        logging.error("customer_names_id is empty. No records to insert.")
                        raise ValueError("customer_names_id is empty")

                    # Convert RuleId to UUID
                    try:
                        rule_id = uuid.UUID(rule_id_1_0) if isinstance(rule_id_1_0, str) else rule_id_1_0
                    except ValueError as e:
                        logging.error(f"Invalid RuleId format: {e}")
                        raise ValueError(f"RuleId '{rule_id_1_0}' is not a valid UUID")

                    logging.info(f"Converted RuleId: {rule_id}, Type: {type(rule_id)}")

                    # Prepare records for TVP (single-column CustomerId for dbo.CustomerIdList)
                    records = [(int(customer_id),) for customer_id in customer_names_id if customer_id is not None]
                    if not records:
                        logging.error("No valid records prepared after filtering.")
                        raise ValueError("No valid records to insert")

                    logging.info(f"Prepared {len(records)} records for TVP insertion")
                    logging.info(f"Sample record: {records[0] if records else 'None'}")

                    with mssql_conn.cursor() as cursor:
                        # Bulk insert via TVP if SP supports it
                        cursor.fast_executemany = True
                        start_time = time.time()
                        logging.info(f"TVP insertion started | Records: {rule_id}")
                        sql = f"EXEC dbo.InsertNotificationRuleRecipientFromSites '{rule_id}'"
                        cursor.execute(sql)
                        # Example: execute SP that expects TVP and RuleId
                        #cursor.execute("{CALL dbo.InsertNotificationRuleRecipientFromSites (?)}", (str(rule_id),))
                        mssql_conn.commit()

                        elapsed = time.time() - start_time
                        logging.info(f"TVP insertion completed | Time taken: {elapsed:.2f} seconds")

                except Exception as e:
                    logging.error(f"General error occurred while inserting NotificationRuleRecipient records: {e}", exc_info=True)
                    mssql_conn.rollback()
                
            else:
                logging.info(f"Small list detected: {len(customer_names_id)} customers — processing directly.")
                logging.info(f"in_edit_flag Customer Names IDs: {customer_names_id}")
                logging.info(f"in_edit_flag Customer Groups IDs: {customer_groups_id}")
                column_names = "RuleId, CustomerId, CustomerGroupId, CreatedDate, CreatedBy"
                placeholders = "%s, %s, %s, %s, %s"

                logging.info(f"in_edit_flag customer_names_id---------- notifications sync started {type(customer_names_id)}")
                batch_size = 1000 
                try:
                    # Prepare all records first
                    records = [
                        (rule_id_1_0, customer_id, None, created_date, created_by)
                        for customer_id in customer_names_id
                    ]

                    insert_query = f"""
                    INSERT INTO {onepoint_o_database}.dbo.NotificationRuleRecipient ({column_names})
                    VALUES ({placeholders})
                    """
                    logging.info(f"Prepared batch insert query: {insert_query}")

                    with mssql_conn.cursor() as cursor:
                        # Process in batches
                        for i in range(0, len(records), batch_size):
                            batch = records[i : i + batch_size]

                            logging.info(f"Batch {i // batch_size + 1} insertion started into NotificationRuleRecipient table Records: {len(batch)}")

                            start_time = time.time()  # Start timer
                            cursor.executemany(insert_query, batch)
                            mssql_conn.commit()
                            end_time = time.time()  # End timer

                            elapsed = end_time - start_time  # ✅ calculate first
                            logging.info(f"Batch {i // batch_size + 1} insertion completed into NotificationRuleRecipient table  Records: {len(batch)} | Time taken: {elapsed:.2f} seconds")

                except Exception as e:
                    logging.info(f"Error occurred while inserting NotificationRuleRecipient records: {e}")
                    mssql_conn.rollback()

            logging.info("in_edit_flag Data inserted successfully. notifications sync completeed")
            

            # update is_active false for already existed expressions
            logging.info(f"in_edit_flag rule_id_2_0----------{rule_id_2_0}")
            rule_rule_defintiton_details_query = f"select * from public.rule_rule_definition where rule_def_id = '{rule_id_2_0}' and is_active = true"
            rule_rule_definition_details = self.execute_query(
                postgres_conn, rule_rule_defintiton_details_query
            )
            logging.info(
                f"in_edit_flag rule_rule_definition_details------------{rule_rule_definition_details}"
            )
            expression_details_str = rule_rule_definition_details[
                "expression_ids"
            ].iloc[0]
            logging.info(f"in_edit_flag expression_details_str-------{expression_details_str}")
            rule_id_1_0 = rule_rule_definition_details.get("rule_id_1_0")
            deleted_date = rule_rule_definition_details.get("deleted_date")
            deleted_by = rule_rule_definition_details.get("deleted_by")
            deleted_date = deleted_date.iloc[0]
            if pd.isna(deleted_date):
                deleted_date = "NULL"
            else:
                deleted_date = f"'{deleted_date.strftime('%Y-%m-%d %H:%M:%S')}'"
            deleted_by = deleted_by.iloc[0]
            rule_id_1_0 = rule_id_1_0.iloc[0]

            delete_query = f"update {onepoint_o_database}.dbo.RULE_Expression set IsActive = '0', IsDeleted = '1', DeletedDate = {deleted_date}, DeletedBy = '{deleted_by}' where RuleDefinitionId = '{rule_id_1_0}'"
            logging.info(f"in_edit_flag delete_query----------{delete_query}")
            with mssql_conn.cursor() as cursor:
                cursor.execute(delete_query)
                mssql_conn.commit()

            # fetching the data of expression list from 2.0 based on rule_id
            created_date = rule_rule_definition_details["created_date"].iloc[0]
            created_date = created_date.strftime("%Y-%m-%d %H:%M:%S")
            created_by = rule_rule_definition_details["created_by"].iloc[0]
            expression_details = json.loads(expression_details_str)
            logging.info(f"in_edit_flag expression_details---------{expression_details}")

            def get_type(value):
                if isinstance(value, bool):
                    return "Boolean"
                if isinstance(value, int) and value > 10**9:
                    return "BigInteger"
                elif isinstance(value, int):
                    return "Integer"
                elif isinstance(value, float):
                    return "Decimal"
                elif isinstance(value, str):
                    try:
                        int(value)
                        return "Integer"
                    except ValueError:
                        pass
                    try:
                        float(value)
                        return "Decimal"
                    except ValueError:
                        pass
                    return "String"
                elif isinstance(value, str) and ("-" in value or ":" in value):
                    return "DateTime"
                try:
                    import uuid

                    uuid.UUID(value)
                    return "Guid"
                except (ValueError, TypeError):
                    pass
                if isinstance(value, str) and value.startswith("$"):
                    return "Money"

                return "Unknown"

            def inserting_bak_25_09_2025(expression_details, ordinal_counter):
                field_1_id = None
                const_one_id = None
                field_2_id = None
                const_two_id = None
                logging.info("in_edit_flag inserting of an expression")
                logging.info(f"in_edit_flag expression_details----------{expression_details}")
                condtion_value = list(expression_details["cond"].values())[0]
                if (
                    "const_one" in expression_details
                    or "field_one" in expression_details
                ):
                    if "field_one" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            # field_one_value = list(expression_details['field_one'].values())[0]
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Constant';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            constant_value = expression_details["field_one"]
                            logging.info(f"in_edit_flag constant_value-----{constant_value}")
                            constant_type = get_type(constant_value)
                            logging.info(f"in_edit_flag constant_type-----{constant_type}")
                            logging.info(f"in_edit_flag expression_type_id-----------{expression_type_id}")
                            constant_type_id_query = f""" select id from {onepoint_o_database}.dbo.DataType where DataTypeName = '{constant_type}';"""
                            query_result = self.execute_query(
                                mssql_conn, constant_type_id_query
                            )
                            logging.info(f"in_edit_flag query_result---------{query_result}")
                            change_type_id = query_result.iloc[0]["id"]
                            logging.info(f"in_edit_flag change_type_id---------{change_type_id}")
                            logging.info(f"in_edit_flag expression_type_id-----------{expression_type_id}")
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                expression_details["field_one"],
                                change_type_id,
                                created_by,
                                created_date,
                                ordinal_counter,
                                new_id,
                            )
                            logging.info(f"in_edit_flag data_to_insert-----------{data_to_insert}")
                            insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                            """
                            logging.info(f"in_edit_flag insert_query------{insert_query}")
                            cursor.execute(insert_query, data_to_insert)
                            field_1_id = cursor.fetchone()[0]
                            logging.info(f"in_edit_flag New ID inserted: {field_1_id}")
                            logging.info(
                                expression_details["field_one"], "inserted", "field_one"
                            )
                            mssql_conn.commit()
                    elif "const_one" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Field';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"in_edit_flag expression_type_id-----------{expression_type_id}")
                            const_one_value = list(
                                expression_details["const_one"].values()
                            )[0]
                            data_to_insert = (
                                rule_id_1_0,
                                expression_type_id,
                                const_one_value,
                                created_by,
                                created_date,
                                ordinal_counter,
                                new_id,
                            )
                            insert_query =f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (%s, %s, %s, %s, %s, %s, %s);
                            """
                            cursor.execute(insert_query, data_to_insert)
                            const_one_id = cursor.fetchone()[0]
                            logging.info(f"in_edit_flag New ID inserted:RULE_Expression {const_one_id}")
                            logging.info(expression_details["const_one"], "inserted const_one")
                            mssql_conn.commit()
                if (
                    "field_two" in expression_details
                    or "const_two" in expression_details
                ):
                    # if condtion_value == 'HAS vALUE' or 'HAS NO VALUE':
                    if "field_two" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Constant';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"in_edit_flag expression_type_id-----------{expression_type_id}")
                            field_two_value = expression_details.get("field_two")
                            logging.info(f"in_edit_flag field_two_value------------{field_two_value}")
                            if not field_two_value:  # Handle empty const_two
                                logging.info("in_edit_flag field_two is empty; skipping insertion.")
                            else:
                                unit = expression_details.get("unit", "").lower()
                                logging.info(f"unit-----------{unit}")
                                # Default to an empty string if 'unit' is missing
                                if unit:
                                    logging.info(f"if unit condition")
                                    try:
                                        field_two_numeric = float(
                                            field_two_value
                                        )  # Ensure it's numeric for conversion
                                        logging.info(
                                            f"field_two_numeric----------{field_two_numeric}"
                                        )
                                        if unit == "mb":
                                            field_two_value = (
                                                field_two_numeric * 1024**2
                                            )
                                            field_two_value = int(field_two_value)

                                        elif unit == "gb":
                                            field_two_value = (
                                                field_two_numeric * 1024**3
                                            )
                                            field_two_value = int(field_two_value)
                                        else:
                                            logging.info(
                                                f"Unit '{unit}' is not recognized; assuming value is already in bytes."
                                            )
                                        logging.info(
                                            f"field_two_value---------------{field_two_value}"
                                        )
                                    except ValueError:
                                        logging.info(
                                            f"Error: field_two value '{field_two_value}' is not numeric."
                                        )
                                else:
                                    logging.info(
                                        "No unit provided; assuming field_two is in bytes."
                                    )

                                constant_type = get_type(field_two_value)
                                logging.info(f"constant_type-----{constant_type}")
                                logging.info(
                                    f"expression_type_id-----------{expression_type_id}"
                                )
                                constant_type_id_query = f""" select id from {onepoint_o_database}.dbo.DataType where DataTypeName = '{constant_type}';"""
                                logging.info(
                                    f"constant_type_id_query------------{constant_type_id_query}"
                                )
                                query_result = self.execute_query(
                                    mssql_conn, constant_type_id_query
                                )
                                logging.info(f"query_result---------{query_result}")
                                change_type_id = query_result.iloc[0]["id"]
                                logging.info(f"change_type_id---------{change_type_id}")

                                # field_two_value = list(expression_details['field_two'].values())[0]
                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    field_two_value,
                                    int(change_type_id),
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    new_id,
                                )
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                                """
                                logging.info(f"insert_query RULE_Expression-------{insert_query}")
                                logging.info(f"data_to_insert RULE_Expression--------{data_to_insert}")
                                cursor.execute(insert_query, data_to_insert)
                                field_2_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted: {field_2_id}")
                                logging.info(
                                    expression_details["field_two"],
                                    "inserted",
                                    "field_two",
                                )
                                mssql_conn.commit()
                    elif "const_two" in expression_details:
                        with mssql_conn.cursor() as cursor:
                            expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Field';"""
                            query_result = self.execute_query(
                                mssql_conn, expression_type_id_query
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"expression_type_id-----------{expression_type_id}")
                            const_two_details = expression_details.get("const_two", {})
                            if not const_two_details:  # Handle empty const_two
                                logging.info("const_two_value is empty; skipping insertion.")
                            else:
                                const_two_value = list(
                                    expression_details["const_two"].values()
                                )[0]
                                data_to_insert = (
                                    rule_id_1_0,
                                    expression_type_id,
                                    const_two_value,
                                    created_by,
                                    created_date,
                                    ordinal_counter,
                                    new_id,
                                )
                                insert_query = f"""
                                    INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                                    OUTPUT INSERTED.id
                                    VALUES (%s, %s, %s, %s, %s, %s, %s);
                                """
                                cursor.execute(insert_query, data_to_insert)
                                const_two_id = cursor.fetchone()[0]
                                logging.info(f"New ID inserted: {const_two_id}")
                                logging.info(
                                    expression_details["const_two"],
                                    "inserted const_two",
                                )
                                mssql_conn.commit()
                left_hand_expression_id = field_1_id or const_one_id
                right_hand_expression_id = field_2_id or const_two_id
                condtion_value = list(expression_details["cond"].values())[0]
                logging.info(f"left_hand_expression_id------------{left_hand_expression_id}")
                logging.info(
                    f"right_hand_expression_id--------------{right_hand_expression_id}"
                )
                logging.info(f"condtion_value-----------{condtion_value}")
                logging.info(
                    f"before inserting left_hand_expression_id and right_hand_expression_id -----------{ordinal_counter}"
                )
                # if left_hand_expression_id and right_hand_expression_id and condtion_value:
                if condtion_value:
                    expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Simple';"""
                    query_result = self.execute_query(
                        mssql_conn, expression_type_id_query
                    )
                    expression_type_id = query_result.iloc[0]["id"]
                    logging.info(f"expression_type_id-----------{expression_type_id}")
                    right_hand_expression_id = right_hand_expression_id or "NULL"
                    with mssql_conn.cursor() as cursor:
                        final_insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, Ordinal, VersionId)  OUTPUT INSERTED.id
                        VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', {right_hand_expression_id if right_hand_expression_id == 'NULL' else f"'{right_hand_expression_id}'"}, '{condtion_value}', '{created_by}', '{created_date}', {ordinal_counter}, '{new_id}') ;
                        """
                        cursor.execute(final_insert_query)
                        final_query_id = cursor.fetchone()[0]
                        logging.info(f"final_query_id--------------{final_query_id}")
                        logging.info("Final rule_expression inserted")
                        mssql_conn.commit()
                        # with mssql_conn.cursor() as cursor:
                        #     update_ordinal_query = f"""
                        #     UPDATE {onepoint_o_database}.dbo.RULE_Expression
                        #     SET Ordinal = {ordinal_counter}
                        #     WHERE id IN ('{left_hand_expression_id}', '{right_hand_expression_id}', '{final_query_id}')
                        #     """
                        #     cursor.execute(update_ordinal_query)
                        #     mssql_conn.commit()
                logging.info(expression_details["cond"], "inserted cond")

                return final_query_id

            # def expresion_builder(expression_details, ordinal_counter):
            #     logging.info('in create function')
            #     if len(expression_details)>1:
            #         logging.info(F"exp got is",expression_details)
            #         logging.info(F"\n")
            #         logging.info(f'ordinal_counter----------{ordinal_counter}')
            #         exp_3_id,ordinal_counter = expresion_builder(expression_details[2:], ordinal_counter)
            #         logging.info(f'ordinal_counter----------{ordinal_counter}')
            #         logging.info(f'exp_3_id--------{exp_3_id}')
            #         exp_1_id=inserting(expression_details[0], ordinal_counter)
            #         ordinal_counter=ordinal_counter-1
            #         logging.info(f'ordinal_counter----------{ordinal_counter}')
            #         logging.info(f'exp_1_id--------{exp_1_id}')
            #         cond=list(expression_details[1].values())[0]
            #         logging.info(f'cond------{cond}')
            #         left_hand_expression_id = exp_1_id  # The first expression part (field_1 or const_one)
            #         right_hand_expression_id = exp_3_id
            def inserting(expression_details, ordinal_counter):
                """
                Insert RULE_Expression records into MSSQL.
                Handles const_one/field_one and const_two/field_two properly.
                Always returns (final_query_id, ordinal_counter).
                """

                field_1_id = None
                const_one_id = None
                field_2_id = None
                const_two_id = None
                final_query_id = None

                logging.info("[telegence_device_sync][inserting][START]")
                logging.info(f"[telegence_device_sync][inserting] expression_details: {expression_details!r}")
                logging.info(f"[telegence_device_sync][inserting] initial ordinal_counter: {ordinal_counter}")

                try:
                    condtion_value = list(expression_details["cond"].values())[0]
                    logging.info(f"[telegence_device_sync][inserting] extracted condtion_value: {condtion_value!r}")

                    # ----------------- Handle field_one / const_one -----------------
                    if "field_one" in expression_details:
                        logging.info("[telegence_device_sync][inserting] branch: field_one present")
                        query_str = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Constant';"
                        logging.info(f"[telegence_device_sync][inserting] executing: {query_str}")
                        query_result = self.execute_query(mssql_conn, query_str)
                        logging.info(f"[telegence_device_sync][inserting] result for expression type query: {query_result}")

                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"[telegence_device_sync][inserting] expression_type_id: {expression_type_id}")

                        constant_value = expression_details["field_one"]
                        logging.info(f"[telegence_device_sync][inserting] constant_value: {constant_value!r}")

                        constant_type = get_type(constant_value)
                        logging.info(f"[telegence_device_sync][inserting] constant_type determined by get_type: {constant_type!r}")

                        query_str = f"SELECT id FROM {onepoint_o_database}.dbo.DataType WHERE DataTypeName = '{constant_type}';"
                        logging.info(f"[telegence_device_sync][inserting] executing: {query_str}")
                        query_result = self.execute_query(mssql_conn, query_str)
                        logging.info(f"[telegence_device_sync][inserting] result for data type query: {query_result}")

                        change_type_id = query_result.iloc[0]["id"]
                        logging.info(f"[telegence_device_sync][inserting] change_type_id: {change_type_id}")
                        # Ensure all values are strings where needed
                        const_one_value_str = str(const_one_value)
                        rule_id_str = str(rule_id_1_0)
                        expression_type_id_str = str(expression_type_id)
                        new_id_str = str(new_id)
                        created_date_str = created_date.strftime("%Y-%m-%d %H:%M:%S") if hasattr(created_date, 'strftime') else str(created_date)
                        ordinal_counter_int = int(ordinal_counter)  # ensure ordinal is integer

                        # Construct the SQL query as a string
                        insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                        (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, Ordinal, VersionId, CreatedDate)
                        OUTPUT INSERTED.id
                        VALUES ('{rule_id_str}', '{expression_type_id_str}', '{const_one_value_str}', '{created_by}', {ordinal_counter_int}, '{new_id_str}', '{created_date_str}');
                        """

                        logging.info(f"[DEBUG] insert_query (const_one) prepared:\n{insert_query}")

                        # Execute the query
                        with mssql_conn.cursor() as cursor:
                            cursor.execute(insert_query)
                            const_one_id = cursor.fetchone()[0]
                            mssql_conn.commit()

                        logging.info(f"[DEBUG] const_one inserted RULE_Expression id={const_one_id}")


                        '''insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                            (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId,
                            CreatedBy, CreatedDate, Ordinal, VersionId)
                            OUTPUT INSERTED.id
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                        """
                        data_to_insert = (
                            rule_id_1_0, expression_type_id, constant_value, change_type_id,
                            created_by, created_date, ordinal_counter, new_id
                        )
                        logging.info(f"[telegence_device_sync][inserting] insert_query (field_one) prepared")
                        logging.info(f"[telegence_device_sync][inserting] data_to_insert (field_one): {data_to_insert!r}")

                        with mssql_conn.cursor() as cursor:
                            cursor.execute(insert_query, data_to_insert)
                            field_1_id = cursor.fetchone()[0]
                            mssql_conn.commit()'''

                        logging.info(f"[telegence_device_sync][inserting] [field_one] Inserted RULE_Expression id = {field_1_id!r}")

                    elif "const_one" in expression_details:
                        logging.info("[telegence_device_sync][inserting] branch: const_one present")
                        query_str = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Field';"
                        logging.info(f"[telegence_device_sync][inserting] executing: {query_str}")
                        query_result = self.execute_query(mssql_conn, query_str)
                        logging.info(f"[telegence_device_sync][inserting] result for expression type (const_one): {query_result}")

                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"[telegence_device_sync][inserting] expression_type_id (const_one): {expression_type_id}")

                        const_one_value = list(expression_details["const_one"].values())[0]
                        logging.info(f"[telegence_device_sync][inserting] const_one_value: {const_one_value!r}")
                        const_one_value_str = str(const_one_value)  # Ensure it's a string
                        rule_id_str = str(rule_id_1_0)
                        expression_type_id_str = str(expression_type_id)
                        new_id_str = str(new_id)
                        created_date_str = created_date.strftime("%Y-%m-%d %H:%M:%S") if hasattr(created_date, 'strftime') else str(created_date)

                        insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                        (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, Ordinal, VersionId)
                        OUTPUT INSERTED.id
                        VALUES ('{rule_id_str}', '{expression_type_id_str}', '{const_one_value_str}', '{created_by}', {ordinal_counter}, '{new_id_str}');
                        """

                        logging.info(f"[DEBUG] insert_query (const_one) prepared:\n{insert_query}")

                        with mssql_conn.cursor() as cursor:
                            cursor.execute(insert_query)
                            const_one_id = cursor.fetchone()[0]
                            mssql_conn.commit()

                        logging.info(f"[DEBUG] const_one inserted RULE_Expression id={const_one_id}")


                        '''insert_query = f"""
                            INSERT INTO AltaworxCentral_Test.dbo.RULE_Expression
                            (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, VersionId)
                            OUTPUT INSERTED.id
                            VALUES (?, ?, ?, ?, ?);

                        """

                        data_to_insert = (
                            str(rule_id_1_0),
                            str(expression_type_id),
                            str(const_one_value),
                            str(created_by),
                            str(new_id)
                        )

                        logging.info(f"[telegence_device_sync][inserting] insert_query (const_one) prepared")
                        logging.info(f"[telegence_device_sync][inserting] data_to_insert (const_one): {insert_query} {data_to_insert!r}")

                        with mssql_conn.cursor() as cursor:
                            cursor.execute(insert_query, data_to_insert)
                            const_one_id = cursor.fetchone()[0]
                            mssql_conn.commit()'''
                        

                        logging.info(f"[telegence_device_sync][inserting] [const_one] Inserted RULE_Expression id = {const_one_id!r}")

                    # ----------------- Handle field_two / const_two -----------------
                    if "field_two" in expression_details:
                        logging.info("[telegence_device_sync][inserting] branch: field_two present")
                        query_str = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Constant';"
                        logging.info(f"[telegence_device_sync][inserting] executing: {query_str}")
                        query_result = self.execute_query(mssql_conn, query_str)
                        logging.info(f"[telegence_device_sync][inserting] result for expression type (field_two): {query_result}")

                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"[telegence_device_sync][inserting] expression_type_id (field_two): {expression_type_id}")

                        field_two_value = expression_details.get("field_two")
                        logging.info(f"[telegence_device_sync][inserting] raw field_two_value: {field_two_value!r}")

                        if not field_two_value:
                            logging.info("[telegence_device_sync][inserting] field_two empty or falsy; skipping field_two insertion")
                        else:
                            unit = expression_details.get("unit", "").lower()
                            logging.info(f"[telegence_device_sync][inserting] detected unit: {unit!r}")

                            if unit:
                                try:
                                    field_two_numeric = float(field_two_value)
                                    logging.info(f"[telegence_device_sync][inserting] field_two_numeric parsed: {field_two_numeric}")
                                    if unit == "mb":
                                        field_two_value = int(field_two_numeric * 1024**2)
                                        logging.info(f"[telegence_device_sync][inserting] converted field_two_value (mb -> bytes): {field_two_value}")
                                    elif unit == "gb":
                                        field_two_value = int(field_two_numeric * 1024**3)
                                        logging.info(f"[telegence_device_sync][inserting] converted field_two_value (gb -> bytes): {field_two_value}")
                                    else:
                                        logging.info(f"[telegence_device_sync][inserting] unrecognized unit '{unit}', assuming bytes: {field_two_value!r}")
                                except ValueError:
                                    logging.info(f"[telegence_device_sync][inserting][WARN] field_two '{field_two_value}' is not numeric; skipping numeric conversion")

                            constant_type = get_type(field_two_value)
                            logging.info(f"[telegence_device_sync][inserting] constant_type for field_two: {constant_type!r}")

                            query_str = f"SELECT id FROM {onepoint_o_database}.dbo.DataType WHERE DataTypeName = '{constant_type}';"
                            logging.info(f"[telegence_device_sync][inserting] executing: {query_str}")
                            query_result = self.execute_query(mssql_conn, query_str)
                            logging.info(f"[telegence_device_sync][inserting] result for data type (field_two): {query_result}")

                            change_type_id = query_result.iloc[0]["id"]
                            logging.info(f"[telegence_device_sync][inserting] change_type_id (field_two): {change_type_id}")

                            '''insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                                (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId,
                                CreatedBy,  Ordinal, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                            """
                            data_to_insert = (
                                rule_id_1_0, expression_type_id, field_two_value, change_type_id,
                                created_by, created_date, ordinal_counter, new_id
                            )
                            logging.info(f"[telegence_device_sync][inserting] insert_query (field_two) prepared")
                            logging.info(f"[telegence_device_sync][inserting] data_to_insert (field_two): {data_to_insert!r}")

                            with mssql_conn.cursor() as cursor:
                                cursor.execute(insert_query, data_to_insert)
                                field_2_id = cursor.fetchone()[0]
                                mssql_conn.commit()'''
                            # Ensure all values are properly converted
                            field_two_value_str = str(field_two_value)
                            rule_id_str = str(rule_id_1_0)
                            expression_type_id_str = str(expression_type_id)
                            change_type_id_str = str(change_type_id)
                            new_id_str = str(new_id)
                            created_date_str = created_date.strftime("%Y-%m-%d %H:%M:%S") if hasattr(created_date, 'strftime') else str(created_date)
                            ordinal_counter_int = int(ordinal_counter)  # keep ordinal as integer

                            # Construct the insert query
                            insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                            (RuleDefinitionId, ExpressionTypeId, ConstantValue, ConstantDataTypeId,
                            CreatedBy, Ordinal, VersionId, CreatedDate)
                            OUTPUT INSERTED.id
                            VALUES ('{rule_id_str}', '{expression_type_id_str}', '{field_two_value_str}', '{change_type_id_str}',
                            '{created_by}', {ordinal_counter_int}, '{new_id_str}', '{created_date_str}');
                            """

                            logging.info(f"[DEBUG] insert_query (field_two) prepared:\n{insert_query}")

                            # Execute the query
                            with mssql_conn.cursor() as cursor:
                                cursor.execute(insert_query)
                                field_2_id = cursor.fetchone()[0]
                                mssql_conn.commit()

                            logging.info(f"[DEBUG] field_two inserted RULE_Expression id={field_2_id}")


                            logging.info(f"[telegence_device_sync][inserting] [field_two] Inserted RULE_Expression id = {field_2_id!r}")

                    elif "const_two" in expression_details:
                        logging.info("[telegence_device_sync][inserting] branch: const_two present")
                        query_str = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Field';"
                        logging.info(f"[telegence_device_sync][inserting] executing: {query_str}")
                        query_result = self.execute_query(mssql_conn, query_str)
                        logging.info(f"[telegence_device_sync][inserting] result for expression type (const_two): {query_result}")

                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"[telegence_device_sync][inserting] expression_type_id (const_two): {expression_type_id}")

                        const_two_value = list(expression_details["const_two"].values())[0]
                        logging.info(f"[telegence_device_sync][inserting] const_two_value: {const_two_value!r}")
                        # Convert values to strings
                        rule_id_str = str(rule_id_1_0)
                        expression_type_id_str = str(expression_type_id)
                        const_two_value_str = str(const_two_value)
                        new_id_str = str(new_id)
                        created_date_str = created_date.strftime("%Y-%m-%d %H:%M:%S") if hasattr(created_date, 'strftime') else str(created_date)
                        ordinal_counter_int = int(ordinal_counter)

                        # Construct the insert query
                        insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                        (RuleDefinitionId, ExpressionTypeId, FieldId, CreatedBy, CreatedDate, Ordinal, VersionId)
                        OUTPUT INSERTED.id
                        VALUES ('{rule_id_str}', '{expression_type_id_str}', '{const_two_value_str}', '{created_by}', '{created_date_str}', {ordinal_counter_int}, '{new_id_str}');
                        """

                        logging.info(f"[DEBUG] insert_query (const_two) prepared:\n{insert_query}")

                        # Execute the query
                        with mssql_conn.cursor() as cursor:
                            cursor.execute(insert_query)
                            const_two_id = cursor.fetchone()[0]
                            mssql_conn.commit()

                        logging.info(f"[DEBUG] const_two inserted RULE_Expression id={const_two_id}")


                        '''insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                            (RuleDefinitionId, ExpressionTypeId, FieldId,
                            CreatedBy, CreatedDate, Ordinal, VersionId)
                            OUTPUT INSERTED.id
                            VALUES (?, ?, ?, ?, ?, ?, ?);
                        """
                        data_to_insert = (
                            rule_id_1_0, expression_type_id, const_two_value,
                            created_by, created_date, ordinal_counter, new_id
                        )
                        logging.info(f"[telegence_device_sync][inserting] insert_query (const_two) prepared")
                        logging.info(f"[telegence_device_sync][inserting] data_to_insert (const_two): {data_to_insert!r}")

                        with mssql_conn.cursor() as cursor:
                            cursor.execute(insert_query, data_to_insert)
                            const_two_id = cursor.fetchone()[0]
                            mssql_conn.commit()'''

                        logging.info(f"[telegence_device_sync][inserting] [const_two] Inserted RULE_Expression id = {const_two_id!r}")

                    # ----------------- Final Simple Expression -----------------
                    left_hand_expression_id = field_1_id or const_one_id
                    right_hand_expression_id = field_2_id or const_two_id
                    logging.info(f"[telegence_device_sync][inserting] left_hand_expression_id: {left_hand_expression_id!r}")
                    logging.info(f"[telegence_device_sync][inserting] right_hand_expression_id: {right_hand_expression_id!r}")

                    if condtion_value:
                        logging.info(f"[telegence_device_sync][inserting] preparing final simple expression insert for cond: {condtion_value!r}")
                        query_str = f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Simple';"
                        logging.info(f"[telegence_device_sync][inserting] executing: {query_str}")
                        query_result = self.execute_query(mssql_conn, query_str)
                        logging.info(f"[telegence_device_sync][inserting] result for expression type (Simple): {query_result}")

                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"[telegence_device_sync][inserting] expression_type_id (Simple): {expression_type_id}")

                        '''final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                            (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId,
                            OperatorId, CreatedBy, CreatedDate, Ordinal, VersionId)
                            OUTPUT INSERTED.id
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
                        """
                        data_to_insert = (
                            rule_id_1_0, expression_type_id, left_hand_expression_id, right_hand_expression_id,
                            condtion_value, created_by, created_date, ordinal_counter, new_id
                        )
                        logging.info(f"[telegence_device_sync][inserting] final_insert_query prepared")
                        logging.info(f"[telegence_device_sync][inserting] data_to_insert (final): {data_to_insert!r}")

                        with mssql_conn.cursor() as cursor:
                            cursor.execute(final_insert_query, data_to_insert)
                            final_query_id = cursor.fetchone()[0]
                            mssql_conn.commit()'''
                        # Convert all values to proper string/int formats
                        rule_id_str = str(rule_id_1_0)
                        expression_type_id_str = str(expression_type_id)
                        left_hand_expression_id_str = str(left_hand_expression_id)
                        right_hand_expression_id_str = str(right_hand_expression_id)
                        operator_id_str = str(condtion_value)  # assuming condtion_value is UUID or string
                        new_id_str = str(new_id)
                        created_date_str = created_date.strftime("%Y-%m-%d %H:%M:%S") if hasattr(created_date, 'strftime') else str(created_date)
                        ordinal_counter_int = int(ordinal_counter)

                        # Construct the insert query
                        final_insert_query = f"""
                        INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                        (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId,
                        OperatorId, CreatedBy, CreatedDate, Ordinal, VersionId)
                        OUTPUT INSERTED.id
                        VALUES ('{rule_id_str}', '{expression_type_id_str}', '{left_hand_expression_id_str}', '{right_hand_expression_id_str}',
                        '{operator_id_str}', '{created_by}', '{created_date_str}', {ordinal_counter_int}, '{new_id_str}');
                        """

                        logging.info(f"[DEBUG] final_insert_query prepared:\n{final_insert_query}")

                        # Execute the query
                        with mssql_conn.cursor() as cursor:
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            mssql_conn.commit()

                        logging.info(f"[DEBUG] final simple expression inserted RULE_Expression id={final_query_id}")


                        logging.info(f"[telegence_device_sync][inserting] [Simple Expression] Inserted RULE_Expression id = {final_query_id!r}")

                    logging.info(f"[telegence_device_sync][inserting][END] returning final_query_id: {final_query_id!r}, ordinal_counter: {ordinal_counter}")
                    return final_query_id, ordinal_counter

                except Exception as e:
                    logging.info(f"[telegence_device_sync][ERROR inserting] {e!r}")
                    return None, ordinal_counter
            def expresion_builder_bak_25_09(expression_details, ordinal_counter):
                logging.info("in create function")
                if len(expression_details) > 1:
                    logging.info(f"exp got is", expression_details)
                    logging.info(f"\n")
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    exp_3_id, ordinal_counter = expresion_builder(
                        expression_details[2:], ordinal_counter
                    )
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    logging.info(f"exp_3_id--------{exp_3_id}")
                    if ordinal_counter % 2 == 0:
                        ordinal_counter = ordinal_counter - 1
                    exp_1_id = inserting(expression_details[0], ordinal_counter)
                    ordinal_counter = ordinal_counter + 1
                    logging.info(f"ordinal_counter----------{ordinal_counter}")
                    logging.info(f"exp_1_id--------{exp_1_id}")
                    cond = list(expression_details[1].values())[0]
                    logging.info(f"cond------{cond}")
                    left_hand_expression_id = (
                        exp_1_id  # The first expression part (field_1 or const_one)
                    )
                    right_hand_expression_id = exp_3_id
                    logging.info(
                        f"left_hand_expression_id--------------{left_hand_expression_id}"
                    )
                    logging.info(
                        f"right_hand_expression_id------------{right_hand_expression_id}"
                    )
                    logging.info(exp_1_id, cond, exp_3_id)
                    if cond == "OR":
                        operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                        operator_type = self.execute_query(
                            postgres_conn, operator_type_query
                        )
                        operator_type = operator_type["id"].iloc[0]
                        logging.info(f"operator_type----------{operator_type}")
                        expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                        query_result = self.execute_query(
                            mssql_conn, expression_type_id_query
                        )
                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"expression_type_id-----------{expression_type_id}")
                        with mssql_conn.cursor() as cursor:
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                            VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                            """
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            logging.info(f"final_query_id--------------{final_query_id}")
                            logging.info("Final rule_expression inserted")
                            mssql_conn.commit()
                            with mssql_conn.cursor() as cursor:
                                update_ordinal_query = f"""
                                UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                SET Ordinal = {ordinal_counter}
                                WHERE id IN ('{final_query_id}')
                                """
                                cursor.execute(update_ordinal_query)
                                mssql_conn.commit()
                            return final_query_id, ordinal_counter - 2

                    elif cond == "AND":
                        expression_type_id_query = f""" select id from {onepoint_o_database}.dbo.RULE_ExpressionType where Name = 'Complex';"""
                        query_result = self.execute_query(
                            mssql_conn, expression_type_id_query
                        )
                        expression_type_id = query_result.iloc[0]["id"]
                        logging.info(f"expression_type_id-----------{expression_type_id}")
                        operator_type_query = f"""select id from public.rule_operator_type where name = '{cond}' """
                        operator_type = self.execute_query(
                            postgres_conn, operator_type_query
                        )
                        operator_type = operator_type["id"].iloc[0]
                        with mssql_conn.cursor() as cursor:
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId, OperatorId, CreatedBy, CreatedDate, VersionId)  OUTPUT INSERTED.id
                            VALUES ('{rule_id_1_0}', '{expression_type_id}', '{left_hand_expression_id}', '{right_hand_expression_id}', '{operator_type}', '{created_by}', '{created_date}', '{version_id}') ;
                            """
                            cursor.execute(final_insert_query)
                            final_query_id = cursor.fetchone()[0]
                            logging.info(f"final_query_id--------------{final_query_id}")
                            logging.info("Final rule_expression inserted")
                            mssql_conn.commit()
                            with mssql_conn.cursor() as cursor:
                                update_ordinal_query = f"""
                                UPDATE {onepoint_o_database}.dbo.RULE_Expression
                                SET Ordinal = {ordinal_counter}
                                WHERE id IN ('{final_query_id}')
                                """
                                cursor.execute(update_ordinal_query)
                                mssql_conn.commit()
                            return final_query_id, ordinal_counter - 2
                else:
                    logging.info(f"exp got is in else", expression_details)
                    logging.info(f"\n")
                    expression_details = expression_details[0]
                    logging.info(f"ordinal_counter-----------{ordinal_counter}")
                    return (
                        inserting(expression_details, ordinal_counter),
                        ordinal_counter - 2,
                    )
            def expresion_builder(expression_details, ordinal_counter):
                """
                Build nested expressions recursively.
                Returns (final_query_id, updated_ordinal_counter).
                """
                try:
                    logging.info("\n[START expresion_builder]")
                    logging.info(f"[DEBUG] expression_details: {expression_details}")
                    logging.info(f"[DEBUG] ordinal_counter: {ordinal_counter}")

                    if len(expression_details) > 1:
                        logging.info("[DEBUG] Recursive case: More than one expression in the list")
                        
                        # Recursive call for the tail expressions
                        result = expresion_builder(expression_details[2:], ordinal_counter)
                        logging.info(f"[DEBUG] Recursive call result: {result}")
                        
                        if not result or result[0] is None:
                            logging.info("[STOP] Nested expression failed at recursive step.")
                            return None, ordinal_counter
                        
                        exp_3_id, ordinal_counter = result
                        logging.info(f"[DEBUG] exp_3_id: {exp_3_id}, updated ordinal_counter: {ordinal_counter}")

                        # Insert first expression
                        exp_1_id, ordinal_counter = inserting(expression_details[0], ordinal_counter)
                        logging.info(f"[DEBUG] exp_1_id: {exp_1_id}, updated ordinal_counter: {ordinal_counter}")

                        # Get condition
                        cond = list(expression_details[1].values())[0]
                        logging.info(f"[DEBUG] Operator condition: {cond}")

                        if cond in ("AND", "OR"):
                            # Get expression type id
                            query_result = self.execute_query(
                                mssql_conn,
                                f"SELECT id FROM {onepoint_o_database}.dbo.RULE_ExpressionType WHERE Name = 'Complex';"
                            )
                            expression_type_id = query_result.iloc[0]["id"]
                            logging.info(f"[DEBUG] expression_type_id for Complex: {expression_type_id}")

                            # Get operator type id
                            operator_type = self.execute_query(
                                postgres_conn,
                                f"SELECT id FROM public.rule_operator_type WHERE name = '{cond}'"
                            )["id"].iloc[0]
                            logging.info(f"[DEBUG] operator_type_id for {cond}: {operator_type}")

                            # Prepare insert query
                            # Ensure all values are strings where necessary
                            rule_id_str = str(rule_id_1_0)
                            expression_type_id_str = str(expression_type_id)
                            exp_1_id_str = str(exp_1_id)
                            exp_3_id_str = str(exp_3_id)
                            operator_type_str = str(operator_type)
                            #created_date_str = created_date.strftime("%Y-%m-%d %H:%M:%S") if hasattr(created_date, 'strftime') else str(created_date)
                            new_id_str = str(new_id)

                            # Construct the direct insert query
                            final_insert_query = f"""
                            INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                            (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId,
                            OperatorId, CreatedBy,  VersionId)
                            OUTPUT INSERTED.id
                            VALUES ('{rule_id_str}', '{expression_type_id_str}', '{exp_1_id_str}', '{exp_3_id_str}',
                            '{operator_type_str}', '{created_by}','{new_id_str}');
                            """

                            logging.info(f"[DEBUG] final_insert_query prepared:\n{final_insert_query}")

                            # Execute the query
                            with mssql_conn.cursor() as cursor:
                                cursor.execute(final_insert_query)
                                final_query_id = cursor.fetchone()[0]
                                mssql_conn.commit()

                            logging.info(f"[DEBUG] Inserted RULE_Expression id={final_query_id}")

                            '''final_insert_query = f"""
                                INSERT INTO {onepoint_o_database}.dbo.RULE_Expression
                                (RuleDefinitionId, ExpressionTypeId, LeftHandExpressionId, RightHandExpressionId,
                                OperatorId, CreatedBy, CreatedDate, VersionId)
                                OUTPUT INSERTED.id
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                            """
                            data_to_insert = (
                                rule_id_1_0, expression_type_id, exp_1_id, exp_3_id,
                                operator_type, created_by, created_date, str(new_id)
                            )
                            logging.info(f"[DEBUG] final_insert_query prepared:\n{final_insert_query}")
                            logging.info(f"[DEBUG] data_to_insert: {data_to_insert!r}")

                            # Execute insert
                            with mssql_conn.cursor() as cursor:
                                cursor.execute(final_insert_query, data_to_insert)
                                final_query_id = cursor.fetchone()[0]
                                mssql_conn.commit()'''
                            logging.info(f"[{cond}] Inserted RULE_Expression id={final_query_id}")

                            return final_query_id, ordinal_counter - 2

                    else:
                        # Base case
                        logging.info("[DEBUG] Base case: Only one expression in the list")
                        expression_details = expression_details[0]
                        logging.info(f"[DEBUG] expression_details for inserting: {expression_details}")
                        
                        final_query_id, ordinal_counter = inserting(expression_details, ordinal_counter)
                        logging.info(f"[DEBUG] Base case inserted RULE_Expression id={final_query_id}, updated ordinal_counter={ordinal_counter}")
                        
                        return final_query_id, ordinal_counter - 2

                except Exception as e:
                    logging.info(f"[ERROR expresion_builder] {e}")
                    return None, ordinal_counter

            ordinal_counter = len(expression_details)
            # ordinal_counter = 1
            expresion_builder(expression_details, ordinal_counter)

        else:
            pass