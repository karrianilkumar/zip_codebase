#Lambda
"""
@Author1 : Srikanth Rekkala
Created Date: 19-02-2026
"""

# Importing the necessary Libraries
import os
import pandas as pd
from common_utils.billing_platform_email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import fetch_tenant_timezone
import datetime
from datetime import time,date
from datetime import datetime, timedelta
import time
import json
import re
import pytz
from pytz import timezone
#download template dependencies
import base64
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
# import paramiko



# Dictionary to store database configuration settings retrieved from environment variables.
common_utils_database_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="payment_integration")

def clean_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        print(f"Exception while converting")
        return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name,readme_flag):
    """
    Creates a database configuration dictionary with user-specific filters based on tenant and role.

    Args:
        user (str): Username to look up permissions for
        db_config_making (dict): Base database configuration to extend
        tenant_database (str): Name of the tenant database
        tenant_name (str): Name of the tenant
        role_name (str): User's role (e.g., 'Super Admin')
        readme_flag (bool): Flag to determine query format (client_id vs user_name)

    Returns:
        dict: Modified database configuration with user-specific filters
    """
    logging.info(f"db_config_maker is in progress {role_name}")
    # Connect to common_utils database to get tenant info
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"],**common_utils_database_config)
    # Get tenant ID and parent tenant ID
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    # Bypass filtering for Super Admin users
    if role_name in ('Super Admin','Partner Admin') and not parent_tenant_id:
        logging.info(f"Getting access filters for  in tenant: {tenant_name} with role: {role_name} in if condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name in ('Super Admin','Partner Admin') and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in else condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name =="Agent Partner Admin" and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in elif second condition")
        pass
    else:
        logging.info(f"Getting access filin tenant: {tenant_name} with role: {role_name} in else condition")
        pass
    if tenant_id:
        tenant_id=int(tenant_id)
    #Get user permissions from mapping table
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)
        if filters.empty:
            query = f"""
                SELECT customers, service_provider, customer_group
                FROM user_module_tenant_mapping
                WHERE user_name = '{user}' AND tenant_id = {tenant_id}
            """
            filters = common_utils_database.execute_query(query, True)
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

        filters = common_utils_database.execute_query(query, True)
    # Connect to tenant database
    database = DB(tenant_database, **db_config)
    # Extract customer group if exists
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    # If user has a customer group, get additional filters from it
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            # Extract rate plan names
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
            # Extract customer names
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
                customer_names=None
            # Extract billing account number
            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception("Error extracting billing_account_number:", e)
                billing_account_number=None
            # Extract feature codes
            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception("Error extracting feature_codes:", e)
    # Set customer filter - use customer group names if available, otherwise use direct mapping
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    #customer=clean_tuple(customer)
    # Get service provider info and convert names to IDs
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    # Get additional customers created by this user
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer_list = [customer]
                elif isinstance(customer, tuple):
                    customer_list = list(customer)
                else:
                    customer_list = customer  # Already a list

                fixed_customer_list = customer_list.copy()

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info('customer_list before extend:', customer_list)

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info('customer_list after extend:', fixed_customer_list)

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info('final customer tuple:', customer)
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Get additional rate plans created by this user
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas
                logging.info('customer_ rate plan list before extend:', fixed_customer_rate_plan_list)

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info('customer rate plan_list after extend:', fixed_customer_rate_plan_list)

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info('final customer rate plan tuple:', customer_rate_plan_name)

    except Exception as e:
        logging.exception(f"Error while fetching the customers  for the user {user} in tenant {tenant_name}: {e}")
    # Update configuration with all filters
    logging.info(f"{user} user is service_provider is {service_provider} and service_provider_id is {service_provider_id} and ")
    if role_name =="Agent Partner Admin" and parent_tenant_id:
        db_config_making["customers"] = None
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = None
        db_config_making["feature_codes"] = None
        db_config_making["billing_account_number"] = None
        return db_config_making
    else:
        db_config_making["customers"] = customer
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
        db_config_making["feature_codes"] = feature_codes
        db_config_making["billing_account_number"] = billing_account_number
        return db_config_making

def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    try:
        current_time = datetime.now()
        logging.info(f"###{path},time started : {current_time}, data received is : {data}")
    except Exception as e:
        logging.error(f"Error in function_caller: {e}")
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    logging.info(f"### db_config created is : {db_config}")
    access_token = data.get("z_access_token",None)
    tenant_database = data.get("db_name")
    if not access_token:
        role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        readme_flag=False
        # db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        # db_config = db_config_making
        logging.info(f"db_config is created {path}")
    else:
        ##API Call
        logging.info(f"db_config will be created for service accountss")
        logging.info(f"path gotten is {path}")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        user = data.get("client_id", "")
        service_data = common_utils_database.get_data(
            "service_accounts", {"client_id": user,"is_active":"True"}
        )

        if service_data.empty:
            logging.info(f"Invalid client ID: {user}")
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}
        )
        tenant_database = tenant_data["db_name"].to_list()[0]
        data['tenant_name']=tenant_name
        data['db_name']=tenant_database
        readme_flag=True
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
    # Map API paths to corresponding handler functions
    path_function_map = {
        "/process_sftp_file_placements": lambda data: process_sftp_file_placements()
    }
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at','date']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict


def process_sftp_file_placements():
    """
    Process active SFTP file placement configurations.

    This function:
    1. Fetches active SFTP configuration records from the database.
    2. Triggers an external EC2 API endpoint for each active record.
    3. Executes API calls in parallel using ThreadPoolExecutor.
    4. Returns aggregated results of all processed records.

    Returns:
        dict: {
            "flag": bool,         # Indicates success or failure
            "message": str,       # Status message
            "results": list       # API responses (if successful)
        }
    """
    try:
        logging.info("### process_sftp_file_placements START")

        # Start time to tract the action
        start_time = time.time()

        # Fetch trigger URL from environment variables
        trigger_url = os.environ.get("SFTP_TRIGGER_URL")
        if not trigger_url:
            return {"flag": False, "message": "SFTP_TRIGGER_URL not configured"}

        # Initialize database connection
        common_utils_database = DB(
            os.environ['COMMON_UTILS_DATABASE'],
            **common_utils_database_config
        )

        # Retrieve active SFTP file placement configurations
        sftp_data_df = common_utils_database.get_data(
            table_name="sftp_file_placements",
            condition={"status": "Active"},
        )

        # Handle case when no active records are found
        if sftp_data_df is None or sftp_data_df.empty:
            logging.info("No active SFTP configurations found")
            return {"flag": True, "message": "No active records found"}

        # Convert dataframe records to dictionary format
        sftp_data_records = sftp_data_df.to_dict(orient="records")
        results = []

        headers = {
            "Content-Type": "application/json"
        }

        def run_sftp_file_placement_job(record):
            """
            Trigger EC2 API to process a single SFTP file placement record.

            Args:
                record (dict): Single SFTP configuration record.

            Returns:
                dict: API JSON response.
            """
            record["path"] = "/process_single_sftp_file"
            payload = serialize_data(record)
            logging.info(f'## process_sftp_file_placements payload{payload}')
            response = requests.post(
                trigger_url,
                json=payload,
                headers=headers,
                timeout=900  # adjust if needed
            )

            return response.json()

        # Execute API calls in parallel (max 5 concurrent threads)
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [
                executor.submit(run_sftp_file_placement_job, record)
                for record in sftp_data_records
            ]
            # Collect results as tasks complete
            for future in as_completed(futures):
                results.append(future.result())
        
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "process_sftp_file_placements",
            "created_by": "System",
            "status": True,
            "time_consumed_secs": time_consumed,
            "comments": "Processing completed",
            "module_name": "SFTP File Placements"
        }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        return {
            "flag": True,
            "message": "Processing completed",
            "results": results
        }

    except Exception as e:
        logging.error("### process_sftp_file_placements ERROR")
        logging.error(str(e))
        error_data = {
            "service_name": "process_sftp_file_placements",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": "System",
            "comments": f"Failed to run SFTP File Placement Action",
            "module_name": "SFTP File Placements"
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": str(e)}