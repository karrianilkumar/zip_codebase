"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
import json
import logging
import os
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
import psycopg2
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
from pandas import Timestamp
from datetime import datetime
from dateutil.relativedelta import relativedelta
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random

logging = Logging(name="carrier_api_syncs")

# Database configuration
common_utils_database_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema": False
}

# Function registry for carrier syncs
function_registry = {
    "AT&T - POD19": {
        "actions": [
            {
                "sync_type": "Daily Sync",
                "function_name": "run_pod19_sync"
            },
        ]
    },
"Verizon-Kore Wireless" : {
        "actions": [
            {
                "sync_type": "Daily Sync",
                "function_name": "run_kore_sync"
            }
        ]
    },
"Multi-Carrier SIM" :{
        "actions": [
            {
                "sync_type": "Daily Sync",
                "function_name": "run_webbing_sync"
            }
        ]
    },
"AT&T - Cisco Jasper": {
        "actions": [
            {
                "sync_type": "Daily Sync",
                "function_name": "run_cisco_jasper_sync"
            },
        ]
    },
    
    }

container_mapping = {
    "AT&T - Telegence - UAT ONLY": "Telegence",
    "AT&T - Telegence": "Telegence",
    "Verizon - ThingSpace IoT":"Verizon",
    "Verizon - ThingSpace PN":"Verizon",
    "VZN 5G/FWA 4740948":"Verizon",
    "Verizon Wireless":"Verizon",
    "VZWCR 1256-cyberree":"Verizon",
    "VZWCR 8280-CRBEAST":"Verizon",
    "VZWCR 6242-CRMBBFWA5G":"Verizon",
    "VZWCR 2215-SO01":"Verizon",
    "VZWCR 1628-LFW":"Verizon",
    "VZWCR 5488-CRFWAFED5G":"Verizon",
    "VZWCR 8593-cybersol":"Verizon",
    "VZWCR 1481-CYBEREN":"Verizon",
    "VZWCR 3433-CRSKRAKN":"Verizon",
    "Webbing":"Webbing",
    "Multi-Carrier SIM":"Webbing",
    "AT&T - POD19":"POD19",
    "POND IoT":"PondIOT",
    "AT&T - Cisco Jasper":"CiscoJasper",
    "Teal":"Teal",
    "Kore":"Kore",
    "Verizon-Kore Wireless":"Kore",
    "T-Mobile Jasper":"TMobileJasper",
    "T-Mobile":"TMobileJasper",
    "Rogers Sandbox":"rogers",
    "Pond IoT":"PondIOT",
    "Rogers":"rogers",
    "AT&T - POD19 - BBOW":"POD19",
    "AT&T - POD19 - ENT":"POD19",
    "Pond Mobile":"PondIOT"

}

port_mapping = {
    "AT&T - Telegence - UAT ONLY": 5000,
    "AT&T - Telegence": 5000,
    "Verizon - ThingSpace IoT":5002,
    "Verizon - ThingSpace PN":5002,
    "VZN 5G/FWA 4740948":5002,
    "Verizon Wireless":5002,
    "VZWCR 1256-cyberree":5002,
    "VZWCR 8280-CRBEAST":5002,
    "VZWCR 6242-CRMBBFWA5G":5002,
    "VZWCR 2215-SO01":5002,
    "VZWCR 1628-LFW":5002,
    "VZWCR 5488-CRFWAFED5G":5002,
    "VZWCR 8593-cybersol":5002,
    "VZWCR 1481-CYBEREN":5002,
    "VZWCR 3433-CRSKRAKN":5002,
    "Webbing":5003,
    "Multi-Carrier SIM":5003,
    "AT&T - POD19":5004,
    "POND IoT":5005,
    "Pond IoT":5005,
    "Pond Mobile":5005,
    "AT&T - Cisco Jasper":5011,
    "Teal":5007,
    "Kore":5007,
    "Verizon-Kore Wireless":5007,
    "T-Mobile Jasper":5009,
    "T-Mobile":5009,
    "Rogers Sandbox":5010,
    "Rogers":5010
}

def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        
    Returns:
        Result of the called endpoint function or error response
    """
    username='carrier_sync'
    data['username']=username
    tenant_name = data.get('tenant_name','') or data.get('tenant','')
    if not tenant_name:
        logging.error("Tenant name or tenant ID are required in the request data.")
        return {"flag": False, "message": "Tenant name and tenant ID are required."}
    tenant_condition = {"tenant_name": tenant_name, "is_active": True}
    # Fetch tenant details from common utils database
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error("Error connecting to common utils database: %s", e)
        return {"flag": False, "message": "Failed to connect to common utils database", "details": str(e)}
    tenant_data = common_utils_database.get_data(
        "tenant", tenant_condition, ["db_config","id","db_name","parent_tenant_id"]
    )
    # Access global db_config variable
    if tenant_data is None or tenant_data is False or tenant_data.empty :
        logging.warning(f"### Tenant '{tenant_name}' not found or inactive.")
        return {"flag": False, "error": f"Tenant '{tenant_name}' not found."}

    tenant_record = tenant_data.to_dict("records")[0]

    # Extract required fields safely
    db_config_json = tenant_record.get("db_config")
    tenant_id = tenant_record.get("id")
    tenant_database = tenant_record.get("db_name")
    parent_tenant_id = tenant_record.get("parent_tenant_id")

    data["db_name"] = tenant_database
    data["tenant_id"] = tenant_id
    data["parent_tenant_id"] = parent_tenant_id
    if isinstance(db_config_json, str):
        db_config_json = json.loads(db_config_json)
    global db_config
    # Build the configuration dictionary
    db_config = {
        "host": db_config_json.get("hostname"),
        "port": db_config_json.get("port"),
        "user": db_config_json.get("user"),
        "password": db_config_json.get("password"),
        "multi_schema": False
    }
    data["tenant_db_config"] = db_config   
    # Route to appropriate endpoint handler    
    path_function_map={
        "/carrier_sync_processor": carrier_sync_processor,
    }
    # Route request
    handler = path_function_map.get(path)
    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

def carrier_sync_processor(data):
    """
    Function to process carrier sync requests.
    Similar to bulk_change_processor but for carrier API syncs.
    
    Args:
        data (dict): Request data containing user/tenant information
        
    Returns:
        dict: Result of the sync operation
    """
    logging.info(f"Received data for carrier sync processor: {data}")
    start_time = time.time()
    # Validate required fields
    service_provider_name = data.get("service_provider_name", "")
    tenant_name = data.get("tenant_name", "") or data.get("tenant","")
    parent_tenant_id=data.get("parent_tenant_id","")
    db_name = data.get("db_name", "")
    username = f"{service_provider_name}_carrier_sync"
    sync_type = data.get("sync_type", "")
    integration_authentication_id=None
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # DB connections
    try:
        tenant_database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error("DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    # Check if required fields are present or else error logging
    if not service_provider_name and not tenant_name:
        logging.error("Missing required fields: service_provider_name and tenant_name")
        error_message = f"Error during carrier sync processing: Missing required field: service_provider_name or tenant_name"
        error_type = "MissingRequiredField service provider name or tenant name"
        try:
            error_data = {
                "service_name": "carrier_sync_processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": f"{service_provider_name}_{tenant_name}_{username}",
                "tenant_name": tenant_name,
                "comments": f"Error during carrier sync processing for service provider: {service_provider_name} and issue is missing required field service provider name",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_error:
            logging.exception(f"Logging error to DB failed: {log_error}")
        return {"flag": False, "message": "service_provider_name is required field"}
    progress_tracker_id = None
    # result = update_progress_tracker(common_utils_database,"insert",f"{service_provider_name} Sync Initiated","In Progress",data,now,progress_tracker_id,5)
    result = update_progress_tracker(
        common_utils_database=common_utils_database,
        action="insert",
        current_status=f"{service_provider_name} Sync Initiated",
        status="In Progress",
        data=data,
        now=now,
        progress=5
    )
    if not result.get("flag"):
        logging.error("Failed to create progress tracker: %s", result.get("message"))
        return {"flag": False, "message": "Failed to create progress tracker", "details": result.get("message")}
    else:
        progress_tracker_id = result.get("progress_tracker_id")
        data["progress_tracker_id"] = progress_tracker_id
    # Find the function name from registry
    actions = function_registry.get(service_provider_name, {}).get("actions", [])
    matching_action = next(
        filter(lambda a: a["sync_type"] == sync_type, actions),
        None
    )
    function_name = matching_action["function_name"] if matching_action else None
    if not function_name:
        logging.error(f"No function found for service provider: {service_provider_name} and sync type: {sync_type}")
        return {"flag": False, "message": f"No function found for service provider '{service_provider_name}' and sync type '{sync_type}'."}
    
    logging.info("Function to call: %s", function_name)
    service_provider_data=tenant_database.get_data(
        "serviceprovider", {"service_provider_name": service_provider_name,"is_active":True}, ["id","integration_id","write_is_enabled"])
    if not service_provider_data.empty:
        service_provider_id = int(service_provider_data.iloc[0]['id'])
        integration_id = int(service_provider_data.iloc[0]['integration_id'])
        carrier_enabled=service_provider_data.iloc[0]["write_is_enabled"]
        if isinstance(carrier_enabled, (bool, np.bool_, np.bool)):
            data["carrier_write_enabled"] = bool(carrier_enabled)
        else : 
            data["carrier_write_enabled"] = False  # or None, depending on your needs

        # data["carrier_write_enabled"]=if carrier_enabled
        data["service_provider_id"] = service_provider_id
        data["integration_id"] = integration_id
    else:
        logging.error("Service provider ID not found for service provider: %s", service_provider_name)
        ##error logging
        return {"flag":False,"message": "Service provider ID not found."}
        
    # Get carrier sync details
    carrier_details_dict = get_carrier_sync_details(data, common_utils_database)

    # Extract only what you need
    api_details_map = {
        "api_limit": carrier_details_dict.get("api_limit"),
        "retries": carrier_details_dict.get("retries"),
        "page_limit": carrier_details_dict.get("page_limit"),
        "bill_period": carrier_details_dict.get("bill_period"),
        "usage_unit": carrier_details_dict.get("usage_unit")
    }
    # Update data dictionary directly from the dict
    data.update({
        "path": f"/{function_name}",
        "api_details_map": api_details_map,
        "get_devices_url_method": carrier_details_dict.get("get_devices_url_method"),
        "get_device_usage_url": carrier_details_dict.get("get_device_usage_url"),
        "custom_url1": carrier_details_dict.get("custom_url1"),
        "custom_url2": carrier_details_dict.get("custom_url2"),
        "custom_url3": carrier_details_dict.get("custom_url3"),
        "delayed_days": carrier_details_dict.get("delayed_days"),
        "email_template": carrier_details_dict.get("email_template"),
        "carrier_write_enabled": data.get("carrier_write_enabled", False)
    })
    integration_authentication_json_data = load_integration_authentication_json()
    integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
    if not integration_authentication_id and parent_tenant_id:
        if parent_tenant_id:
            parent_tenant_id=int(parent_tenant_id)
            parent_tenant_data = common_utils_database.get_data(
            "tenant", {"id": parent_tenant_id},
            ["tenant_name"]
            )
            parent_tenant_name = parent_tenant_data["tenant_name"].to_list()[0]
            integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)
    elif not integration_authentication_id and not parent_tenant_id:
        integration_authentication_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, 'Altaworx')
    data["integration_authentication_id"] = integration_authentication_id
    # Get the container name and port based on service provider
    container_name = container_mapping.get(service_provider_name, None)
    data["username"] = f"{container_name}_{tenant_name}"
    port = port_mapping.get(service_provider_name, None)
    if not container_name:
        logging.error(f"Container name not found for service provider: {service_provider_name}")
        return {"flag": False, "message": f"Container name not found for service provider: {service_provider_name}"}
    if not port:
        logging.error(f"Port not found for service provider: {service_provider_name}")
        return {"flag": False, "message": f"Port not found for service provider: {service_provider_name}"}
    # Prepare the data to be sent to the container
    data["path"] = f"/{function_name}"
    logging.info("Data to be sent to the container: %s", data)
    # URL for the container
    url = f"http://{os.environ['Carrier_EC2_HOST']}:{port}/{container_name}_Carrier"
    logging.info(f"Forwarding request to EC2 endpoint: {url}")
    # Call the container
    try:
        logging.info(f"Calling container with data: {data}")
        result = post_with_retries(url, data, retries=1)
        if result:
            response = {"flag": True, "message": "Carrier sync request forwarded to EC2 successfully", "details": result}
        else:
            response = {"flag": False, "error": "Failed to get response from container"}
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            ## Audit logging
            audit_data_user_actions = {
                "service_name": "carrier_sync_processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": f"{service_provider_name}_{tenant_name}_{username}",
                "time_consumed_secs": time_consumed,
                "status": "Success - Request forwarded to EC2 route",
                "tenant_name": tenant_name,
                "module_name": "Carrier Sync",
                "comments": f"Carrier sync request forwarded to EC2 route for service provider: {service_provider_name} and sync type: {sync_type}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")
        return response
    except Exception as e:
        logging.exception(f"HTTP forward failed: {e}")
        error_message = f"Error during carrier sync processing: {str(e)}"
        error_type = str(type(e).__name__)
        try:
            error_data = {
                "service_name": "carrier_sync_processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": f"{service_provider_name}_{tenant_name}_{username}",
                "tenant_name": tenant_name,
                "comments": f"Error during carrier sync processing for service provider: {service_provider_name} and sync type: {sync_type}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_error:
            logging.exception(f"Logging error to DB failed: {log_error}")
        return {"flag": False, "error": "Forward to EC2 route failed", "details": str(e)}
 
## Function to get Carrier API details
def get_carrier_sync_details(data, common_utils_database):
    '''
    Function to get the Carrier API details for a given service provider.
    Returns a dictionary with all required fields.
    '''
    logging.info(f"### get_carrier_sync_details data: {data}")
    # Default values dictionary
    default_values = {
        "api_limit": None,
        "retries": None,
        "page_limit": None,
        "bill_period": None,
        "get_devices_url_method": None,
        "get_device_usage_url": None,
        "custom_url1": None,
        "custom_url2": None,
        "custom_url3":None,
        "usage_unit": None,
        "email_template": None,
        "delayed_days": None
    }
    # Extract input fields
    service_provider = data.get("service_provider_name")
    tenant_name = data.get("tenant_name")
    # Query database
    carrier_details = common_utils_database.get_data(
        "carrier_syncs_detail_mappings", 
        {"service_provider_name": service_provider, "tenant_name": tenant_name}
    )
    logging.info(f"### carrier_details: {carrier_details}")
    if carrier_details.empty:
        return default_values
    # Get the first row
    row = carrier_details.to_dict("records")[0]
    # Create result dictionary from row
    result = {}
    for key in default_values.keys():
        value = row.get(key)
        # Convert numeric fields to int if they have value
        if key in ["api_limit", "retries", "page_limit","delayed_days"] and value is not None:
            try:
                value = int(value)
            except (ValueError, TypeError):
                value = None
        result[key] = value
    return result

def update_progress_tracker(
    common_utils_database,
    action="insert",
    progress_tracker_id=None,current_status=None,status=None,
    data=None,now=None,progress=None
):
    """
    Insert or update carrier sync audit records.

    Args:
        common_utils_database (DB): Common utils DB connection
        action (str): "insert" or "update"
        audit_id (int): Required for update
        data (dict): Audit data payload

    Returns:
        int | bool
            - insert → returns audit_id
            - update → returns True
    """
    try:
        # INSERT (Sync Start)
        if action == "insert":
            insert_data = {
                "tenant_name": data.get("tenant_name"),
                "service_provider_name": data.get("service_provider_name"),
                "sync_start_time": now,
                "sync_end_time": None,
                "estimated_time": data.get("estimated_time"),
                "execution_duration": None,
                "total_records_synced": 0,
                "current_status": current_status or data.get("current_status", "Sync started"),
                "status": status or data.get("status", "In Progress"),
                "error_code": None,
                "error_message": None,
                "attempt_count": data.get("attempt_count", 0),
                "triggered_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "sync_type": data.get("sync_type"),
                "created_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "modified_by": data.get("modified_by", "system"),
                "sync_run_count": data.get("sync_run_count", 1),
                "progress":progress or 0
            }
            progress_tracker_id = common_utils_database.insert_data(insert_data,"carrier_sync_audit_logs")
            logging.info(
                f"Carrier sync audit inserted | id={progress_tracker_id} | status={insert_data['current_status']}"
            )
            return {"flag": True, "message": "Progress tracker inserted successfully", "progress_tracker_id": progress_tracker_id}
        # UPDATE (Progress / Completion / Failure)
        elif action == "update":
            update_data = {
                "current_status": data.get("current_status"),
                "status": data.get("status"),
                "total_records_synced": data.get("total_records_synced"),
                "attempt_count": data.get("attempt_count"),
                "error_code": data.get("error_code"),
                "error_message": data.get("error_message"),
                "sync_end_time": data.get("sync_end_time"),
                "execution_duration": data.get("execution_duration"),
                "modified_by": data.get("modified_by", "system"),
                "progress": data.get("progress") or 0
            }
            # remove None values (VERY important)
            update_data = {k: v for k, v in update_data.items() if v is not None}
            common_utils_database.update_dict(
                "carrier_sync_audit_logs",
                update_data,
                and_conditions={"id": progress_tracker_id}
            )
            logging.info(
                f"Carrier sync audit updated | id={progress_tracker_id} | status={update_data.get('current_status')}"
            )
            return {"flag": True, "message": "Progress tracker updated successfully"}
    except Exception as e:
        logging.exception("Error in update_progress_tracker")
        return {"flag": False, "message": "Error in update_progress_tracker", "details": str(e)}
        

def post_with_retries(url, json_data, retries=1):
    '''
    Main container caller function
    Args:
        url (str): The URL to send the POST request to.
        json_data (dict): The JSON data to include in the POST request.
        retries (int): Number of retry attempts in case of failure.
    '''
    delay = 1
    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(url, json=json_data, timeout=300)  # 5 minute timeout for sync operations
            if resp.status_code < 400:
                return resp.json()
        except requests.RequestException:
            pass  # ignore and retry

        logging.warning("Attempt %d failed; retrying in %ds", attempt, delay)
        time.sleep(delay + random.uniform(0, 0.5))
        delay *= 2
    
    logging.error("All %d attempts failed", retries)
    return None



def load_integration_authentication_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_integration_authentication_id.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"### load_integration_authentication_json Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"### load_integration_authentication_json Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"### load_integration_authentication_json Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs


def get_integration_authentication_id_by_unique_name(json_data, tenant_name):
    """
    Fetches the integration authentication ID for a given tenant from JSON data.
    
    Args:
        json_data (dict): JSON data containing tenant integration authentication information
        tenant_name (str): Name of the tenant to look up
        
    Returns:
        int or None: The integration authentication ID if found, None otherwise
    """
    logging.info(f"### get_integration_authentication_id_by_unique_name Tenant Name: {tenant_name}")
    return json_data.get(tenant_name, {}).get("INTEGRATION_AUTHENTICATION_ID", None)
