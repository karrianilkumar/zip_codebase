"""
main.py

Module for handling API requests and routing them to the appropriate function.

Functions:
- lambda_handler(event,context=None)
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24

"""
##importing necessary libraries
import json
import time
import os
import boto3
import pytz
import datetime
from datetime import datetime
from common_utils.email_trigger import get_memory_usage, memory_sns
from carrier_api_syncs import function_caller
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email
from common_utils.logging_utils import Logging


# Dictionary to store database configuration settings retrieved from environment variables.
db_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
}
logging = Logging(name="main")

# Initialize the SNS client
sns = boto3.client("sns")
cloudwatch = boto3.client("cloudwatch")
sqs_client=boto3.client("sqs")

def delete_message_from_sqs(receipt_handle, data):
    try:
        queue_url = os.getenv("SIM_MANAGEMENT_TRIGGER_QUEUE")
        response = sqs_client.delete_message(
            QueueUrl=queue_url,  # Added missing comma
            ReceiptHandle=receipt_handle
        )

        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logging.info(f"Message deleted from SQS successfully. Message: {data}")
        else:
            logging.warning(f"Failed to delete message: {response}")

    except Exception as e:
        logging.error(f"Error deleting message from SQS: {e}")
        raise


def lambda_handler(event, context):
    """
    Handles incoming API requests and routes them to the appropriate function.

    Args:
        event (dict): The incoming API request event.

    Returns:
        dict: A dictionary containing the response status code and body.

    Example:
        >>> event = {'data': {'path': '/get_modules'}}
        >>> lambda_handler(event)
        {'statusCode': 200, 'body': '{"flag": True, "modules": [...]}'}
    """
    function_name = context.function_name if context else "sim_management"
    logging.info("Lambda function started: %s", function_name)
    value=None
    result=None
    # Record the start time of the function
    performance_matrix = {}
    start_time = time.time()
    performance_matrix["start_time"] = (
        f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}."
        f"{int((start_time % 1) * 1000):03d}"
    )

    # print(f"Validating the request in main file: {event}")
    if "Records" in event:
        # Extract the SQS message body
        sqs_message = event["Records"][-1]
        # logging.info(f"sqs_message: {sqs_message}")
        receipt_handle = sqs_message.get("receiptHandle")
        print("receipt--------------", receipt_handle)
        print(sqs_message,'bodyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy')
        body = sqs_message.get("body")
        print(sqs_message,'bodyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy')
        if body:
            try:
                data = json.loads(body)  # Parse the JSON message body
            except:
                data = body
            print("datadataaaaaaaaa", data)
            path = data.get("path", "")
            # Check if the message has the sqs_flag set to True
            if data.get("sqs_flag"):
                print("Processing SQS message with sqs_flag set to True")
                
                logging.info(f"Path is 1 {path}")
                # data=data.get()
                if receipt_handle:
                    try:
                        # Call your delete function here (make sure to pass the receipt_handle)
                        delete_message_from_sqs(receipt_handle,data)
                        print("Message deleted successfully after processing.")
                    except Exception as e:
                        print(f"Error deleting message from SQS: {e}")
            # data=data.get("data",{})
            # logging.info(f"111 Data is {data}")
            access_token=data.get("access_token",None)
            logging.info(f"In Main accesss token is {access_token}")
            logging.info(f"Path is {path}")
            result=function_caller(data,path,access_token)
            value = result
            status_code=200
            return {
            "statusCode": status_code,
            "body": json.dumps(result)
            # "performance_matrix": json.dumps(performance_matrix),
            # "started": hit_time_formatted,
            # "time_taken": time_taken,
            # "request_completed_time_formatted": request_completed_time_formatted,
        }
    else:
        data = event.get("data")
        if not data:
            return {"message": "No details provided or Invalid details", "status_code": 400}

        if data:
            try:
                data = data
            except json.JSONDecodeError:
                return {
                    "statusCode": 400,
                    "body": json.dumps({"error": "Invalid JSON in body"}),
                }
        else:
            data = {}

        if "data" in data:
            data = data.get("data")

        service_path = event.get("path")
        if service_path:
            data["path"] = service_path

        path = data.get("path")

        result = {}
        # token validation
        verified_request = True
        access_token = data.get("z_access_token", "")
        ui_token = data.get("access_token", "")
        # Capture the hit time when the request is received (same as before)
        hit_time = time.time()
        hit_time_formatted = datetime.now(pytz.timezone("Asia/Kolkata")).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        logging.info(
            f"Hit Time: {hit_time_formatted}, Request Received at: {hit_time_formatted}"
        )

        request_received_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logging.info("Routing request for path: %s", path)
        # Route based on the path and method
        if verified_request:
            result=function_caller(data,path)
            value = result.get('flag') if result is not None else False
        # database Connection
        if value == False:
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            status_code = 400  # You can change this to an appropriate error code
            logging.error("Error in result: %s", result)
            # Sending email
            try:
                result_response = send_email("Exception Mail")
                if isinstance(result, dict) and result.get("flag") is False:
                    logging.info(result)
                else:
                    to_emails, cc_emails, subject, body, from_email, partner_name = (
                        result_response
                    )
                    common_utils_database.update_dict(
                        "email_templates",
                        {"last_email_triggered_at": request_received_at},
                        {"template_name": "Exception Mail"},
                    )
                    query = """
                        SELECT parents_module_name, sub_module_name, child_module_name, partner_name
                        FROM email_templates
                        WHERE template_name = 'Exception Mail'
                    """
                    # Execute the query and fetch the result
                    email_template_data = common_utils_database.execute_query(query, True)
                    if not email_template_data.empty:
                        # Unpack the results
                        (
                            parents_module_name,
                            sub_module_name,
                            child_module_name,
                            partner_name,
                        ) = email_template_data.iloc[0]
                    else:
                        # If no data is found, assign default values or log an error
                        parents_module_name = ""
                        sub_module_name = ""
                        child_module_name = ""
                        partner_name = ""

                    # Email audit logging
                    error_message = result.get(
                        "error", "Unknown error occurred"
                    )  # Extracting the error message
                    email_audit_data = {
                        "template_name": "Exception Mail",
                        "email_type": "Application",
                        "partner_name": partner_name,
                        "email_status": "success",
                        "from_email": from_email,
                        "to_email": to_emails,
                        "cc_email": cc_emails,
                        "comments": f"{path} - Error: {error_message}",  # Adding error message to comments
                        "subject": subject,
                        "body": body,
                        "action": "Email triggered",
                        "parents_module_name": parents_module_name,
                        "sub_module_name": sub_module_name,
                        "child_module_name": child_module_name,
                    }
                    common_utils_database.update_audit(email_audit_data, "email_audit")
            except:
                pass

        elif value == True:
            status_code = 200
        else:
            status_code = 500
            result = {"message": "Something went wrong, while processing the request!"}

        # Capture the request completion time in IST
        request_completed_time = time.time()
        request_completed_time_formatted = datetime.now(
            pytz.timezone("Asia/Kolkata")
        ).strftime("%Y-%m-%d %H:%M:%S")

        # Calculate the time difference between hit time and request completed time
        time_taken = round(
            request_completed_time - hit_time, 4
        )  # Round to 4 decimal places
        logging.info(
            f"Request Completed: {request_completed_time_formatted}, Time Taken: {time_taken} seconds"
        )

        # Record the end time of the function
        end_time = time.time()
        performance_matrix["end_time"] = (
            f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
        )
        performance_matrix["execution_time"] = f"{end_time - start_time:.4f}"
        logging.info(
            f"Request processed at {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}.{int((end_time % 1) * 1000):03d}"
        )

        performance_matrix["execution_time"] = f"{end_time - start_time:.4f} seconds"
        logging.info(f"Function performance_matrix: {performance_matrix} seconds")
        logging.info(
            "Lambda function execution completed in %.4f seconds", end_time - start_time
        )

        memory_limit = int(context.memory_limit_in_mb)
        memory_used = int(get_memory_usage()) + 100
        final_memory_used = get_memory_usage()
        logging.info(
            f"$$$$$$$$$$$$$$$$$$$$$$$Final Memory Used: {final_memory_used:.2f} MB"
        )
        memory_sns(memory_limit, memory_used, context)

        if access_token or (not access_token and not ui_token):
            if 'flag' in result:
                result.pop('flag')
            if "status_code" in result:
                return result
            else:
                return result
        else:
            return {
                "statusCode": status_code,
                "body": json.dumps(result),
                "performance_matrix": json.dumps(performance_matrix),
                "started": hit_time_formatted,
                "time_taken": time_taken,
                "request_completed_time_formatted": request_completed_time_formatted,
            }
