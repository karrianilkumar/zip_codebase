-- billing_period
ALTER TABLE billing_period
ADD CONSTRAINT unique_billing_period_source UNIQUE (source_db, source_id);

-- revcustomer
ALTER TABLE revcustomer
ADD CONSTRAINT unique_revcustomer_source UNIQUE (source_db, source_id);

-- device_status
ALTER TABLE device_status
ADD CONSTRAINT unique_device_status_source UNIQUE (source_db, source_id);

-- customerrateplan
ALTER TABLE customerrateplan
ADD CONSTRAINT unique_customerrateplan_source UNIQUE (source_db, source_id, tenant_id);

-- customers
ALTER TABLE customers
ADD CONSTRAINT unique_customers_source UNIQUE (source_db, source_id, tenant_id);

-- mobility_device
ALTER TABLE mobility_device
ADD CONSTRAINT unique_mobility_device_source UNIQUE (source_db, source_id, inv_source_id);

-- mobility_device_tenant
ALTER TABLE mobility_device_tenant
ADD CONSTRAINT unique_mobility_device_tenant_source UNIQUE (source_db, source_id, tenant_id);

ALTER TABLE device
ADD CONSTRAINT unique_device_source UNIQUE (source_db, source_id, inv_source_id);

-- mobility_device_tenant
ALTER TABLE device_tenant
ADD CONSTRAINT unique_device_tenant_source UNIQUE (source_db, source_id, tenant_id);






CREATE OR REPLACE FUNCTION public.insert_into_inventory_if_not_exists_mob_device_tenant()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
DECLARE
update_flag_insert text;
BEGIN
update_flag_insert := current_setting('myvars.insert_in_progress', true);
IF update_flag_insert IS NOT NULL AND update_flag_insert = 'true' THEN
        RETURN NEW;
    END IF;

	 -- Set the session variable to indicate update is in progress
PERFORM set_config('myvars.insert_in_progress', 'true', true);
INSERT INTO sim_management_inventory (
        mobility_device_id, 
        mdt_id,
        tenant_id,
        service_provider_id,
        service_provider_display_name,
        integration_id,
        billing_account_number,
        foundation_account_number,
        iccid,
        imsi,
        msisdn,
        imei,
        customer_id,
        customer_name,
        parent_customer_id,
        rev_customer_id,
        rev_customer_name,
        rev_parent_customer_id,
        device_status_id,
        sim_status,
        carrier_cycle_usage_bytes,
        carrier_cycle_usage_mb,
        date_added,
        date_activated,
        account_number,
        carrier_rate_plan_id,
        carrier_rate_plan_name,
       customer_cycle_usage_mb,
        customer_rate_pool_id,
        customer_rate_pool_name,
        customer_rate_plan_id,
        customer_rate_plan_name,
        customer_rate_plan_code,
        sms_count,
        minutes_used,
        username,
        is_active_status,
        ip_address,
        service_zip_code,
        rate_plan_soc,
        rate_plan_soc_description,
        data_group_id,
        pool_id,
        next_bill_cycle_date,
        device_make,
        device_model,
        contract_status,
        ban_status,
        imei_type_id,
        plan_limit_mb,
        customer_data_allocation_mb,
        billing_cycle_start_date,
        billing_cycle_end_date,
        customer_rate_plan_mb,
        customer_rate_plan_allows_sim_pooling,
        carrier_rate_plan_mb,
        telegence_features,
        ebonding_features,
        last_usage_date,
        created_by,
        created_date,
        modified_by,
        modified_date,
        last_activated_date,
        deleted_by,
        deleted_date,
        is_active,
        is_deleted,
        cost_center,
        soc,
		billing_period_id,
		ctd_sms_usage,
		ctd_session_count,
		ctd_voice_usage,
		rev_service_id,
		account_number_integration_authentication_id,
		delta_ctd_data_usage,
		technology_type,
		optimization_group_id,
		tenant_is_active,
		 tenant_is_deleted,
		 sub_tenant_customer_rate_plan_name,
	sub_tenant_carrier_rate_plan_name,
	source_db,
	source_id

    )
SELECT
        md.id as mobility_device_id, 
        mdt.id as mdt_id,
        mdt.tenant_id,
        md.service_provider_id,
        sp.display_name as service_provider_display_name,
        sp.integration_id,
        md.billing_account_number,
        md.foundation_account_number,
        md.iccid,
        md.imsi,
        md.msisdn,
        md.imei,
        mdt.customer_id,
        c.customer_name,
        c.parent_customer_id,
        rc.rev_customer_id,
        rc.customer_name,
        rc.rev_parent_customer_id,
        md.device_status_id,
        ds.display_name as sim_status,
        md.carrier_cycle_usage as carrier_cycle_usage_bytes,
        CASE
            WHEN i.id = 12 THEN round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1000.0 / 1000.0, 3)
            ELSE round(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS carrier_cycle_usage_mb,
        md.date_added,
        md.date_activated,
        mdt.account_number,
        md.carrier_rate_plan_id,
        COALESCE(crp.friendly_name, md.carrier_rate_plan) AS carrier_rate_plan_name,
        CASE
            WHEN c.customer_bill_period_end_day IS NOT NULL AND c.customer_bill_period_end_hour IS NOT NULL THEN 
                ROUND(get_current_cycle_usage_bytes(md.id, mdt.tenant_id) / 1024.0 / 1024.0, 3)
            ELSE 
                ROUND(COALESCE(md.carrier_cycle_usage::numeric, 0.0) / 1024.0 / 1024.0, 3)
        END AS customer_cycle_usage_mb,
        mdt.customer_rate_pool_id,
        cpool.name as customer_rate_pool_name,
        mdt.customer_rate_plan_id,
        custrp.rate_plan_name as customer_rate_plan_name,
        custrp.rate_plan_code as customer_rate_plan_code,
        md.sms_count,
        md.minutes_used,
        md.username,
        ds.is_active_status,
        md.ip_address,
        md.service_zip_code,
        md.Single_User_Code AS rate_plan_soc,
        md.single_user_code_description as rate_plan_soc_description,
        md.data_group_id,
        md.pool_id,
        md.next_bill_cycle_date,
        md.device_make,
        md.device_model,
        md.contract_status,
        md.ban_status,
        md.imei_type_id,
        md.plan_limit_mb,
        mdt.customer_data_allocation_mb,
        bp.billing_cycle_start_date,
        bp.billing_cycle_end_date,
        custrp.plan_mb as customer_rate_plan_mb,
        custrp.allows_sim_pooling as customer_rate_plan_allows_sim_pooling,
        crp.plan_mb as carrier_rate_plan_mb,
        (SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
            FROM telegence_device_mobility_feature tdmf
            JOIN mobility_feature mf ON mf.id = tdmf.mobility_feature_id
            WHERE td.id IS NOT NULL AND tdmf.is_deleted = false AND tdmf.is_active = true AND tdmf.telegence_device_id = td.id AND mf.is_deleted = false AND mf.is_active = true AND mf.is_retired = false
        ) AS telegence_feature,
        (SELECT string_agg(mf.soc_code::text, ','::text) AS string_agg
            FROM e_bonding_device_mobility_feature ebdmf
            JOIN mobility_feature mf ON mf.id = ebdmf.mobility_feature_id
            WHERE e_bonding_device.id IS NOT NULL AND ebdmf.is_deleted = false AND ebdmf.is_active = true AND ebdmf.e_bonding_device_id = e_bonding_device.id AND mf.is_deleted = false AND mf.is_active = true AND mf.is_retired = false
        ) AS e_bonding_feature,
        md.last_usage_date,
        md.created_by,
        md.created_date,
        md.modified_by,
        md.modified_date,
        md.last_activated_date,
        md.deleted_by,
        md.deleted_date,
        md.is_active,
        md.is_deleted,
        md.cost_center_1 as cost_center1,
        md.soc,
		md.billing_period_id,
		md.ctd_sms_usage,
		md.ctd_session_count,
		md.ctd_voice_usage,
		mdt.rev_service_id,
		mdt.account_number_integration_authentication_id,
		md.delta_ctd_data_usage,
		md.technology_type,
		md.optimization_group_id,
		mdt.is_active as tenant_is_active,
		mdt.is_deleted as tenant_is_deleted,
		COALESCE(crp.friendly_name, md.carrier_rate_plan) AS sub_tenant_customer_rate_plan_name,
		custrp.rate_plan_name as sub_tenant_carrier_rate_plan_name,
		source_db,
		inv_source_id
    FROM mobility_device md
    JOIN mobility_device_tenant mdt ON mdt.mobility_device_id = md.id 
    JOIN  serviceprovider sp ON md.service_provider_id = sp.id
    LEFT JOIN  device_status ds ON ds.id = md.device_status_id
    LEFT JOIN customers c ON c.id = mdt.customer_id AND c.is_active = true AND c.is_deleted = false
    LEFT JOIN 
   revcustomer rc ON c.rev_customer_id = rc.id AND rc.is_active = true AND rc.is_deleted = false
	LEFT JOIN 
   integration i ON i.id = sp.integration_id AND i.is_active = true AND i.is_deleted = false 
	LEFT JOIN 
   carrier_rate_plan crp ON crp.id = md.carrier_rate_plan_id
	LEFT JOIN customerrateplan custrp ON custrp.id=mdt.customer_rate_plan_id 
	LEFT JOIN customer_rate_pool cpool ON cpool.id = mdt.customer_rate_pool_id 
	LEFT JOIN billing_period bp ON bp.id = md.billing_period_id 
	LEFT JOIN telegence_device td ON td.subscriber_number = md.msisdn AND td.service_provider_id = md.service_provider_id
	LEFT JOIN e_bonding_device ON e_bonding_device.subscriber_number = md.msisdn AND e_bonding_device.service_provider_id = md.service_provider_id
	--LEFT JOIN vw_mobility_customer_current_cycle_device_usage ON vw_mobility_customer_current_cycle_device_usage.mobility_device_id = md.id AND vw_mobility_customer_current_cycle_device_usage.tenant_id = mdt.tenant_id
	left join public.sim_management_inventory sm on sm.mdt_id=mdt.id
	where new.mobility_device_id=md.id and md.is_active=True and md.is_deleted=false 
	AND NOT EXISTS (
        SELECT 1 FROM sim_management_inventory s WHERE s.mdt_id = mdt.id
    )
    AND mdt.id IS NOT NULL;
  
	 PERFORM set_config('myvars.insert_in_progress', 'false', true);
  RETURN NEW;
END;
$BODY$;
