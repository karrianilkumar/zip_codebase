"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 :
Created Date: 05-09-2025
"""

# Importing the necessary Libraries
import os
from random import random
import requests
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import fetch_tenant_timezone , convert_timestamp_data , serialize_data
from datetime import datetime ,time
import json
import base64
#DB IMPORTS
# 1. Standard Library Imports
from datetime import datetime, timedelta,timezone
import copy
import uuid
#import boto3
import traceback
import concurrent.futures

# 2. Third-Party Imports
import pandas as pd
from pandas import Timestamp
from sqlalchemy import create_engine, exc, text
import pytds
import psycopg2
from psycopg2.extras import execute_values
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv
from psycopg2 import sql
import numpy as np
from inital_sync_main import MigrationScheduler
from collections import defaultdict

logging = Logging(name="Partnerbecoming")
# Database configuration

common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }



def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes requests.

    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler

    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts

    Returns:
        Result of the called endpoint function or error response
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config

    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    # Route to appropriate endpoint handler
    if path == "/get_partner_to_provider_list_view_data":
        result = get_partner_to_provider_list_view_data(data)
    elif path == "/partner_to_provider_actions" :
        result = partner_to_provider_actions(data)
    elif path == "/get_target_partner_details" :
        result = get_target_partner_details(data)
    elif path == "/assign_partner_to_provider" :
        result = assign_partner_to_provider(data)
    elif path=='/service_provider_setup':
        result=service_provider_setup(data)
   # elif path=='/inventory_data_update_for_partner_to_provider':
        #result=inventory_data_update_for_partner_to_provider(data)
    elif path=='/pbp_initial_sync':
        initial_sync=MigrationScheduler()
        result=initial_sync.perform_intial_sync(data)
    else:
        result = {"flag": False, "error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result

####DB CODE Starts here-------------------------
def create_connection(db_type='',host='', db_name='',username='', password='',port='',driver='',max_retry=3):
    connection = None
    retry = 1
    print(f"db_type:{db_type}, host--{host}-db_name-{db_name}, username-{username},password-{password},port-{port},driver-{driver}")
    db_type = db_type.strip()
    host = host.strip()
    db_name = db_name.strip()
    username = username.strip()
    password = password.strip()
    port = port.strip()
    driver = driver.strip()
    if db_type=='postgresql':
        try:
            logging.info(f"creating postgresql connection")

            connection = psycopg2.connect(
                host=host,
                database=db_name,
                user=username,
                password=password,
                port=port
            )
            logging.info("Connection to PostgreSQL DB successful")
        except Exception as e:
            logging.info(f"Failed to connect to PostgreSQL DB: {e}")
    elif db_type=='mssql':
        logging.info(f"Creating MSSQL connection")
        try:
            connection = pytds.connect(
                server=host,
                database=db_name,
                user=username,
                password=password,
                port=port
            )

            logging.info("Connection to MSSQL successful!")
        except Exception as e:
            logging.info(f"Failed to connect to MSSQL DB: {e}")
    return connection

def execute_query_db(connection, query, params=None):
    try:
        if params:
            with connection.cursor() as cur:
                sql_preview = cur.mogrify(query, params).decode("utf-8")
                logging.info(f"Final SQL to execute: {sql_preview}")
            result_df = pd.read_sql_query(query, connection, params=params)
        else:
            logging.info(f"Final SQL to execute: {query}")
            result_df = pd.read_sql_query(query, connection)
        return result_df
    except Exception as e:
        logging.info(f"Error executing query: {e}")
        return None

def add_mapping_cols_to_source_target(source_db, main_tenant_db):
    """
    Objective:
        - Add <source_id>(same type as PK), <source_db>(varchar) columns to target_db tables
        - Add <target_details> JSON column to source_db tables

    Logic:
        1. Connect to the common utils database and fetch rows from
        partner_provider_initial_sync_mappings where:
                - main_tenant_db = main_tenant_db OR target_db = main_tenant_db
                - partner_name = source_db
                - add_source_mapping_cols = TRUE
                - add_target_mapping_cols = TRUE
        2. For each table from step 1:
            - Connect to source_db and target_db
            - In target_db: add source_id (same type as PK) + source_db (varchar)
            - In source_db: add target_details (json)
    """
    try:
        load_dotenv()
        logging.info(f"Starting add_mapping_cols_to_source_target fn")
        common_utils_db = os.getenv('COMMON_UTILS_DB')
        host = os.getenv('PSQL_DB_HOST')
        db_type = os.getenv('PSQL_DB_TYPE')
        username = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        port = os.getenv('PSQL_DB_PORT')

        logging.info(f"Connect to {common_utils_db} with details {host},{db_type}")
        common_utils_conn = create_connection(db_type, host, common_utils_db, username, password, port)
        if common_utils_conn is None:
            logging.info(f"Connection to common utils db failed")
            e = f"Connection to common utils db failed"
            return False, e

        with common_utils_conn.cursor() as cursor:
            tables_query = sql.SQL("""
                SELECT table_name
                FROM partner_provider_initial_sync_mappings
                WHERE (main_tenant_db = %s OR target_db = %s)
                AND partner_name = %s
                AND add_source_mapping_cols = TRUE
                AND add_target_mapping_cols = TRUE
                ORDER BY id ASC
            """)
            cursor.execute(tables_query, (main_tenant_db, main_tenant_db, source_db))
            tables = cursor.fetchall()

        if not tables:
            logging.info("No tables found to update")
            e = "No tables found to update"
            return False, e

        logging.info(f"Fetched tables {tables}")

        # Connect to source_db and target_db
        source_conn = create_connection(db_type, host, source_db, username, password, port)
        target_conn = create_connection(db_type, host, main_tenant_db, username, password, port)

        if source_conn is None or target_conn is None:
            logging.info("Failed to connect to source or target db")
            e = "Failed to connect to source or target db"
            return False, e

        for table in tables:
            table_name = table[0]

            # 1 Get primary key column and type from target DB
            with target_conn.cursor() as cur:
                cur.execute("""
                    SELECT kcu.column_name, c.data_type
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.key_column_usage kcu
                    ON tc.constraint_name = kcu.constraint_name
                    AND tc.table_schema = kcu.table_schema
                    JOIN information_schema.columns c
                    ON c.table_name = kcu.table_name
                    AND c.column_name = kcu.column_name
                    WHERE tc.constraint_type = 'PRIMARY KEY'
                    AND tc.table_name = %s
                    AND tc.table_schema = 'public'
                    LIMIT 1;
                """, (table_name,))
                pk_info = cur.fetchone()

            if not pk_info:
                logging.info(f" No primary key found for {table_name}, skipping...")
                continue

            pk_col, pk_type = pk_info
            logging.info(f"Primary key for {table_name}: {pk_col} ({pk_type})")

            # 2 Add source_id with same type as PK + source_db in target DB
            with target_conn.cursor() as target_cursor:
                target_cursor.execute(sql.SQL("""
                    ALTER TABLE {}
                    ADD COLUMN IF NOT EXISTS source_id {}
                """).format(sql.Identifier(table_name), sql.SQL(pk_type)))
                target_cursor.execute(sql.SQL("""
                    ALTER TABLE {}
                    ADD COLUMN IF NOT EXISTS source_db VARCHAR
                """).format(sql.Identifier(table_name)))
                target_conn.commit()

            # 3 Add target_details column to source DB
            with source_conn.cursor() as source_cursor:
                source_cursor.execute(sql.SQL("""
                    ALTER TABLE {}
                    ADD COLUMN IF NOT EXISTS target_details JSON
                """).format(sql.Identifier(table_name)))
                source_conn.commit()

            logging.info(f"Updated table {table_name} with mapping cols")

        # Close connections
        common_utils_conn.close()
        source_conn.close()
        target_conn.close()
        return True, None

    except Exception as e:
        logging.info(f"Error in add_mapping_cols_to_source_target: {e}")
        return False, e

'''def create_table_mappings_for_new_provider(source_db,partner_db_tenant_id, target_db, target_name, target_db_tenant_id,main_tenant_db,main_tenant_db_tenant_id):
    """
    Duplicate existing table mappings but insert with new source_db, target_db,
    partner_db_tenant_id, and target_db_tenant_id.
    """
    try:
        load_dotenv()
        logging.info(f"Starting create_table_mappings_for_new_provider fn")
        common_utils_db = os.getenv('COMMON_UTILS_DB')
        host = os.getenv('PSQL_DB_HOST')
        db_type = os.getenv('PSQL_DB_TYPE')
        username = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        port = os.getenv('PSQL_DB_PORT')

        logging.info(f"Connect to {common_utils_db} with details {host},{db_type}")
        conn = create_connection(db_type, host, common_utils_db, username, password, port)
        if conn is None:
            logging.info(f"Connection to common utils db failed")
            e=f'Connection to common utils db failed'
            return False,e

        with conn.cursor() as cur:
            insert_query = """
                INSERT INTO public.partner_provider_initial_sync_mappings (
                    table_name,
                    partial_flag,
                    create_flag,
                    created_date,
                    created_by,
                    fk_columns,
                    fk_col_target_mapping,
                    add_source_mapping_cols,
                    add_target_mapping_cols,
                    where_cond,
                    select_query,
                    partner_name,
                    partner_db_tenant_id,
                    target_db,
                    target_db_tenant_id,
                    return_mapped_ids,
                    migration_order,
                    main_tenant_db,
                    main_tenant_db_tenant_id,
                    target_name,
                    service_provider_mapping_flag
                )
                SELECT DISTINCT
                    table_name,
                    partial_flag,
                    create_flag,
                    NOW() AS created_date,        -- reset created_date
                    created_by,
                    fk_columns,
                    fk_col_target_mapping,
                    add_source_mapping_cols,
                    add_target_mapping_cols,
                    where_cond,
                    select_query,
                    %s as partner_name,
                    %s::int AS partner_db_tenant_id,
                    %s AS target_db,
                    %s::int AS target_db_tenant_id,
                    return_mapped_ids,
                    migration_order,
                    %s as main_tenant_db,
                    %s::int AS main_tenant_db_tenant_id,
                    %s AS target_name,
                    service_provider_mapping_flag
                FROM public.partner_provider_initial_sync_mappings
                ORDER BY migration_order ASC;
            """

            cur.execute(
                insert_query,
                (
                    source_db,
                    int(partner_db_tenant_id),
                    target_db,
                    int(target_db_tenant_id),
                    main_tenant_db,
                    main_tenant_db_tenant_id,
                    target_name
                )
            )

            conn.commit()
            logging.info("Table mappings duplicated successfully.")
            return True,None

    except Exception as e:
        if conn:
            conn.rollback()
        logging.info(f"Error creating mappings: {e}")
        return False,e'''

# Prepare queries to extract db_config from the tenant table
def get_db_host_for_tenant(conn, tenant_id):
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT db_config
            FROM tenant
            WHERE id = %s
            """,
            (tenant_id,)
        )
        row = cur.fetchone()
        if not row or not row[0]:
            return None
        db_config = row[0]
        # db_config is a dict (jsonb), extract 'host'
        return db_config.get('hostname')

def create_table_mappings_for_new_provider(
    source_db,
    partner_db_tenant_id,
    target_db,
    target_name,
    target_db_tenant_id,
    main_tenant_db,
    main_tenant_db_tenant_id
):
    """
    Duplicate reference table mappings from partner_provider_reference_sync_mappings
    and insert into partner_provider_initial_sync_mappings with overrides for
    source_db, target_db, partner_db_tenant_id, target_db_tenant_id.
    """
    try:
        load_dotenv()
        logging.info("Starting create_table_mappings_for_new_provider fn")
        common_utils_db = os.getenv("COMMON_UTILS_DB")
        host = os.getenv("PSQL_DB_HOST")
        db_type = os.getenv("PSQL_DB_TYPE")
        username = os.getenv("PSQL_DB_USER")
        password = os.getenv("PSQL_DB_PASSWORD")
        port = os.getenv("PSQL_DB_PORT")

        logging.info(f"Connect to {common_utils_db} with details {host},{db_type}")
        conn = create_connection(db_type, host, common_utils_db, username, password, port)
        if conn is None:
            logging.info("Connection to common utils db failed")
            e = "Connection to common utils db failed"
            return False, e
        
        # Retrieve source_db host and target_db host
        partner_db_host = get_db_host_for_tenant(conn, partner_db_tenant_id)
        target_db_host = get_db_host_for_tenant(conn, target_db_tenant_id)
        logging.info(f"[INFO] the partner_db_host and target_db_host {partner_db_host} and {target_db_host}")
        
        with conn.cursor() as cur:
            insert_query = """
                INSERT INTO public.partner_provider_initial_sync_mappings (
                    table_name,
                    partial_flag,
                    create_flag,
                    created_date,
                    created_by,
                    fk_columns,
                    fk_col_target_mapping,
                    add_source_mapping_cols,
                    add_target_mapping_cols,
                    where_cond,
                    select_query,
                    partner_name,
                    partner_db_tenant_id,
                    target_db,
                    target_db_tenant_id,
                    target_name,
                    return_mapped_ids,
                    migration_order,
                    main_tenant_db,
                    main_tenant_db_tenant_id,
                    service_provider_mapping_flag,
                    fk_flag,
                    tenant_id_flag,
                    tenant_based_mappings_flag,
                    fetch_based_ids,
                    is_active,
                    inv_flag,
                    inv_depen,
                    tenant_based_foreign_keyswapping,
                    dependent_table_mappings,
                    partner_db_host,
                    target_db_host
                )
                SELECT 
                    r.table_name,
                    r.partial_flag,
                    r.create_flag,
                    NOW() AS created_date,     -- override created_date
                    r.created_by,
                    r.fk_columns,
                    r.fk_col_target_mapping,
                    r.add_source_mapping_cols,
                    r.add_target_mapping_cols,
                    r.where_cond,
                    r.select_query,
                    %s AS partner_name,        -- override
                    %s::int AS partner_db_tenant_id,
                    %s AS target_db,
                    %s::int AS target_db_tenant_id,
                    %s AS target_name,                    
                    r.return_mapped_ids,
                    r.migration_order,
                    %s AS main_tenant_db,      -- override
                    %s::int AS main_tenant_db_tenant_id,
                    r.service_provider_mapping_flag,
                    r.fk_flag,
                    r.tenant_id_flag,
                    r.tenant_based_mappings_flag,
                    r.fetch_based_ids,
                    r.is_active,
                    r.inv_flag,
                    r.inv_depen,
                    r.tenant_based_foreign_keyswapping,
                    r.dependent_table_mappings,
                    %s,
                    %s
                FROM public.partner_provider_reference_sync_mappings r
                ORDER BY r.migration_order ASC
            """

            cur.execute(
                insert_query,
                (
                    source_db,
                    int(partner_db_tenant_id),
                    target_db,
                    int(target_db_tenant_id),
                    target_name,
                    main_tenant_db,
                    main_tenant_db_tenant_id,
                    partner_db_host,
                    target_db_host
                    
                ),
            )

            conn.commit()
            logging.info("Table mappings inserted from reference successfully.")
            return True, None, partner_db_host, target_db_host
    except Exception as e:
        if conn:
            conn.rollback()
        logging.error(f"Error creating mappings: {e}")
        return False, e, None, None

# def valid_service_providers(source_db, target_db):
#     """
#     Validate and update tagged service providers in the common_utils DB
#     based on actual service providers present in the source DB.

#     Steps:
#     1. Connect to the common_utils DB.
#     2. Connect to source and target DBs (if provided).
#     3. Fetch partner-provider mapping details from `partner_provider_detail_mappings`.
#     4. For each mapping:
#         a. Extract customer names, BANs, FANs, and tagged service providers.
#         b. Query the source DB (`sim_management_inventory`) to get distinct service providers
#            that actually exist for those customers/BANs/FANs.
#         c. Filter the tagged service providers, keeping only the valid ones found in source DB.
#         d. Update the mapping row in common_utils with the filtered valid service providers.
#     """

#     try:
#         # 1. Load DB credentials from environment
#         load_dotenv()
#         host = os.getenv('PSQL_DB_HOST')
#         port = os.getenv('PSQL_DB_PORT')
#         user = os.getenv('PSQL_DB_USER')
#         password = os.getenv('PSQL_DB_PASSWORD')
#         common_utils_db = os.getenv('COMMON_UTILS_DB')
#         db_type = os.getenv('PSQL_DB_TYPE')

#         # 2. Connect to common_utils DB
#         common_utils_conn = create_connection(db_type, host, common_utils_db, user, password, port)
#         logging.info(f"common_utils conn is {common_utils_conn}")
#         if not common_utils_conn:
#             raise Exception(f"Connection to common_utils_db {common_utils_db} failed")

#         # 3. Connect to source DB (if provided)
#         if source_db:
#             source_conn = create_connection(db_type, host, source_db, user, password, port)
#             logging.info(f"source conn is {source_conn}")
#             if not source_conn:
#                 raise Exception(f"Connection to source db {source_db} failed")

#         # 4. Connect to target DB (if provided)
#         if target_db:
#             target_db_conn = create_connection(db_type, host, target_db, user, password, port)
#             logging.info(f"target_db conn is {target_db_conn}")
#             if not target_db_conn:
#                 raise Exception(f"Connection to target db {target_db} failed")

#         # 5. Fetch partner-provider mappings from common_utils DB
#         select_query = f"""
#             select id, customer_names, tagged_ban, tagged_fan, tagged_service_providers
#             from partner_provider_detail_mappings
#             where partner_db=%s and
#                   (target_name=%s or target_db=%s)
#         """
#         selected_details = execute_query_db(common_utils_conn, select_query, (source_db, target_db, target_db))
#         logging.info(f"selected_details: {selected_details}")

#         # 6. Loop over each row of mappings
#         for idx, row in selected_details.iterrows():
#             id = row['id']

#             # Parse JSON fields from DB
#             customer_names = json.loads(row['customer_names'])
#             tagged_ban = json.loads(row['tagged_ban'])
#             tagged_fan = json.loads(row['tagged_fan'])
#             tagged_service_providers = json.loads(row['tagged_service_providers'])

#             # Convert customer_names dict values to tuple
#             customer_names_tuple = tuple(customer_names.values())
#             tagged_ban_tuple = tuple(tagged_ban)
#             tagged_fan_tuple = tuple(tagged_fan)

#             logging.info(f"Processing row {id}:")
#             logging.info(f"  customer_names={customer_names_tuple}, tagged_ban={tagged_ban_tuple}, tagged_fan={tagged_fan_tuple}, tagged_service_providers={tagged_service_providers}")

#             # 7. Get distinct service providers from source DB based on FAN, BAN, and customer_name
#             distinct_service_providers_query = """
#                 select distinct service_provider_display_name
#                 from sim_management_inventory
#                 where foundation_account_number in %s
#                   and billing_account_number in %s
#                   or customer_name in %s
#             """
#             distinct_service_providers = execute_query_db(source_conn, distinct_service_providers_query, (tagged_fan_tuple, tagged_ban_tuple, customer_names_tuple))
#             logging.info(f"distinct service providers are {distinct_service_providers}")

#             # Convert result to list
#             service_providers_list = distinct_service_providers['service_provider_display_name'].tolist()
#             logging.info(f"service_providers_list is {service_providers_list}")

#             # 8. Keep only those tagged providers that actually exist in source DB
#             valid_service_providers_dict = {key: value for key, value in tagged_service_providers.items() if key in service_providers_list}
#             logging.info(f"valid service providers dict is {valid_service_providers_dict}")

#             # 9. Update the mapping in common_utils with filtered service providers
#             update_query = """
#                 update partner_provider_detail_mappings
#                 set tagged_service_providers=%s
#                 where id=%s
#             """
#             with common_utils_conn.cursor() as cur:
#                 # Log the final SQL before executing
#                 sql_preview = cur.mogrify(update_query, (json.dumps(valid_service_providers_dict), id)).decode("utf-8")
#                 logging.info(f"Final SQL to execute:\n{sql_preview}")


#                 cur.execute(update_query, (json.dumps(valid_service_providers_dict), id))
#                 common_utils_conn.commit()
#         return True,None

#     except Exception as e:
#         logging.info(f"Error in valid_service_providers: {e}")
#         return False,e

def safe_json_load(value):
    if value in (None, 'None', '', 'null'):
        return None
    try:
        return json.loads(value)
    except Exception:
        return None

def valid_service_providers(source_db, target_db,target_name,partner_db_tenant_id,target_db_tenant_id,
            main_tenant_db_tenant_id,source_host,target_db_host):
    """
    Validate and update tagged service providers in the common_utils DB
    based on actual service providers present in the source DB.

    Steps:
    1. Connect to the common_utils DB.
    2. Connect to source and target DBs (if provided).
    3. Fetch partner-provider mapping details from `partner_provider_detail_mappings`.
    4. For each mapping:
        a. Extract customer names, BANs, FANs, and tagged service providers.
        b. Query the source DB (`sim_management_inventory`) to get distinct service providers
           that actually exist for those customers/BANs/FANs.
        c. Filter the tagged service providers, keeping only the valid ones found in source DB.
        d. Update the mapping row in common_utils with the filtered valid service providers.
    """

    try:
        # 1. Load DB credentials from environment
        logging.info(f"Starting valid_service_providers for source_db, target_db {source_db}, {target_db}")
        load_dotenv()
        host = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        common_utils_db = os.getenv('COMMON_UTILS_DB')
        db_type = os.getenv('PSQL_DB_TYPE')

        # 2. Connect to common_utils DB
        common_utils_conn = create_connection(db_type, host, common_utils_db, user, password, port)
        logging.info(f"valid_service_providers common_utils conn is {common_utils_conn}")
        if not common_utils_conn:
            raise Exception(f"valid_service_providers Connection to common_utils_db {common_utils_db} failed")

        # 3. Connect to source DB (if provided)
        if source_db and source_host:
            source_conn = create_connection(db_type, source_host, source_db, user, password, port)
            logging.info(f"valid_service_providers source conn is {source_conn}")
            if not source_conn:
                raise Exception(f"valid_service_providers Connection to source db {source_db} failed")

        # 4. Connect to target DB (if provided)
        if target_db and target_db_host:
            target_db_conn = create_connection(db_type, target_db_host, target_db, user, password, port)
            logging.info(f"valid_service_providers target_db conn is {target_db_conn}")
            if not target_db_conn:
                raise Exception(f"valid_service_providers Connection to target db {target_db} failed")

        # 5. Fetch partner-provider mappings from common_utils DB
        select_query = f"""
            SELECT id, customer_names, tagged_ban, tagged_fan, tagged_service_providers
            FROM partner_provider_detail_mappings
            WHERE partner_db=%s
              AND target_name=%s and target_db=%s 
              and partner_db_tenant_id=%s and target_db_tenant_id=%s 
              and mediator_db_tenant_id=%s              
               order by id desc
        """
        selected_details = execute_query_db(common_utils_conn, select_query, (source_db,target_name, target_db ,int(partner_db_tenant_id),int(target_db_tenant_id),str(main_tenant_db_tenant_id)))
        logging.info(f"valid_service_providers selected_details: {selected_details}")

        # 6. Loop over each row of mappings
        for idx, row in selected_details.iterrows():
            id = row['id']

            # Parse JSON fields from DB
            customer_names = safe_json_load(row['customer_names'])
            tagged_ban = safe_json_load(row['tagged_ban'])
            tagged_fan = safe_json_load(row['tagged_fan'])
            tagged_service_providers = safe_json_load(row['tagged_service_providers'])

            # Convert customer_names dict values to tuple
            customer_names_tuple = tuple(customer_names.values()) if customer_names else ()
            tagged_ban_tuple = tuple(tagged_ban) if tagged_ban else ()
            tagged_fan_tuple = tuple(tagged_fan) if tagged_fan else ()

            logging.info(f"valid_service_providers Processing row {id}:")
            logging.info(f"valid_service_providers customer_names={customer_names_tuple}, tagged_ban={tagged_ban_tuple}, tagged_fan={tagged_fan_tuple}, tagged_service_providers={tagged_service_providers}")

            # 7. Build dynamic WHERE clause for distinct service providers query
            where_clauses = []
            params = []

            if tagged_fan_tuple:
                where_clauses.append("foundation_account_number IN %s")
                params.append(tagged_fan_tuple)

            if tagged_ban_tuple:
                where_clauses.append("billing_account_number IN %s")
                params.append(tagged_ban_tuple)

            if customer_names_tuple:
                where_clauses.append("customer_name IN %s")
                params.append(customer_names_tuple)

            if not where_clauses:
                logging.info(f"valid_service_providers No FAN, BAN, or customer_name provided for row {id}, skipping...")
                continue  # nothing to filter, skip this row

            distinct_service_providers_query = f"""
                SELECT DISTINCT service_provider_display_name
                FROM sim_management_inventory
                WHERE {" OR ".join(where_clauses)}
            """
            distinct_service_providers = execute_query_db(source_conn, distinct_service_providers_query, tuple(params))
            logging.info(f"valid_service_providers distinct service providers are {distinct_service_providers}")

            # Convert result to list
            service_providers_list = distinct_service_providers['service_provider_display_name'].tolist()
            logging.info(f"valid_service_providers service_providers_list is {service_providers_list}")

            # 8. Keep only those tagged providers that actually exist in source DB
            valid_service_providers_dict = {
                key: value for key, value in tagged_service_providers.items()
                if key in service_providers_list
            }
            logging.info(f"valid_service_providers valid service providers dict is {valid_service_providers_dict}")

            # 9. Update the mapping in common_utils with filtered service providers
            update_query = """
                UPDATE partner_provider_detail_mappings
                SET tagged_service_providers=%s
                WHERE id=%s
            """
            with common_utils_conn.cursor() as cur:
                # Log the final SQL before executing
                sql_preview = cur.mogrify(update_query, (json.dumps(valid_service_providers_dict), id)).decode("utf-8")
                logging.info(f"valid_service_providers Final SQL to execute:\n{sql_preview}")

                cur.execute(update_query, (json.dumps(valid_service_providers_dict), id))
                common_utils_conn.commit()

        return True, None

    except Exception as e:
        logging.info(f"valid_service_providers Error in valid_service_providers: {e}")
        return False, e

def insert_dataframe_with_mapping(
    df, target_conn, target_table, source_db, target_db_name, target_name, source_id_col="source_id"
):
    """
    Uses execute_batch for performance, then queries back to get the mapping
    Enhanced with NaN and integer overflow detection
    """
    mapping = {}

    if df is None or df.empty:
        logging.info(" DataFrame is empty, nothing to insert")
        return mapping, df

    try:
        df = df.copy()
        # Add source_db column to track provenance
        df["source_db"] = source_db
        df["target_name"]=target_name

        # CHECK FOR NaN VALUES AND INTEGER ISSUES BEFORE INSERTION
        logging.info(f"Checking for NaN values and integer issues before insertion...")

        # Handle float columns that should be integers (like optimization hours)
        float_columns = df.select_dtypes(include=['float64', 'float32']).columns
        for col in float_columns:
            logging.info(f"Processing float column: {col}")
            # Convert NaN to None, and finite floats to integers
            df[col] = df[col].apply(lambda x: None if pd.isna(x) else int(x) if pd.notna(x) else None)
            logging.info(f"  Converted {col} NaN values to None")

        # Check integer columns for overflow
        integer_columns = df.select_dtypes(include=['int64', 'Int64']).columns
        for col in integer_columns:
            for idx, val in df[col].items():
                if pd.notna(val):
                    try:
                        int_val = int(val)
                        if int_val < -2147483648 or int_val > 2147483647:
                            logging.info(f"INTEGER OVERFLOW in {col}[{idx}]: {int_val}")
                            logging.info(f"   Setting to NULL to prevent insertion error")
                            df.loc[idx, col] = None
                    except (ValueError, TypeError):
                        logging.info(f"Invalid integer in {col}[{idx}]: {val}")
                        df.loc[idx, col] = None

        # First, do the batch insert (without RETURNING)
        columns = list(df.columns)
        placeholders = ", ".join([f"%({col})s" for col in columns])
        col_names = ", ".join(columns)
        insert_query = f"""
            INSERT INTO {target_table} ({col_names})
            VALUES ({placeholders})
        """

        # Get the source IDs we're about to insert
        source_ids = df[source_id_col].tolist()

        with target_conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            records = df.to_dict(orient="records")

            # DEBUG: Print a sample record to check data
            if records:
                logging.info(f"Sample record to insert: {records[0]}")

            psycopg2.extras.execute_batch(cur, insert_query, records)

            # Now query back to get the mapping
            source_ids_str = "', '".join(map(str, source_ids))
            mapping_query = f"""
                SELECT {source_id_col}, id
                FROM {target_table}
                WHERE {source_id_col} IN ('{source_ids_str}')
                AND source_db = %s AND target_name= %s
            """

            cur.execute(mapping_query, (source_db,target_name,))
            results = cur.fetchall()

            logging.info(f"mapping query results:{results}")

            mapping = {str(row[source_id_col]): row["id"] for row in results}
            logging.info(f"Complete mapping for {target_table}: {mapping}")

            # Build target_details
            target_details_list = []
            for _, row in df.iterrows():
                src_id = str(row[source_id_col])
                tgt_id = mapping.get(src_id)
                target_details_list.append({target_db_name: tgt_id})

            df["target_details"] = target_details_list

        target_conn.commit()

    except Exception as e:
        target_conn.rollback()
        logging.info(f"Error inserting into {target_table}: {e}")
        logging.info(f"Error details: {traceback.format_exc()}")
        raise

    return mapping, df

# Alternative: Use SQLAlchemy to avoid pandas warnings
def execute_query_db_sqlalchemy(connection, query, params=None):
    """
    Alternative version using SQLAlchemy to avoid pandas warnings
    """
    try:
        # Convert psycopg2 connection to SQLAlchemy engine if needed
        if hasattr(connection, 'cursor'):  # It's a psycopg2 connection
            # For now, keep the original implementation but with better error handling
            if params:
                with connection.cursor() as cur:
                    if hasattr(cur, 'mogrify'):
                        sql_preview = cur.mogrify(query, params).decode("utf-8")
                        print(f"Final SQL to execute: {sql_preview}")
                result_df = pd.read_sql_query(query, connection, params=params)
            else:
                print(f"Final SQL to execute: {query}")
                result_df = pd.read_sql_query(query, connection)
            return result_df
        else:
            # It's already a SQLAlchemy connection
            return pd.read_sql_query(query, connection, params=params)

    except Exception as e:
        print(f"Error executing query: {e}")
        print(f"Query was: {query}")
        if params:
            print(f"Params were: {params}")
        return None

def clean_dataframe_for_insertion(df, target_conn, target_table):
    """
    Dynamically clean DataFrame based on target table schema
    - Converts NaN values to None for all columns
    - Handles float-to-integer conversion for columns that should be integers
    - Uses actual database schema to determine proper data types
    """
    if df is None or df.empty:
        return df

    df = df.copy()
    logging.info(f"DYNAMIC FIX: Cleaning DataFrame for table '{target_table}'...")

    try:
        # Get the target table schema from PostgreSQL
        schema_query = """
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns
        WHERE table_name = %s
        AND table_schema = 'public'
        """

        with target_conn.cursor() as cur:
            cur.execute(schema_query, (target_table,))
            schema_info = cur.fetchall()

        # Create a mapping of column_name -> data_type
        column_types = {row[0]: row[1] for row in schema_info}
        logging.info(f"Found {len(column_types)} columns in target table schema")

    except Exception as e:
        logging.info(f"Warning: Could not fetch table schema: {e}")
        logging.info("Proceeding with generic NaN cleaning...")
        column_types = {}

    # Process each column in the DataFrame
    for col in df.columns:
        if col not in df.columns:
            continue

        # Count NaN values
        nan_count = df[col].isna().sum()
        if nan_count == 0:
            continue

        logging.info(f"  Processing column '{col}': {nan_count} NaN values found")

        # Get the target column type if available
        target_type = column_types.get(col, 'unknown')
        current_dtype = str(df[col].dtype)

        # Handle different scenarios
        if 'float' in current_dtype:
            if target_type in ['integer', 'int4', 'int8', 'smallint', 'bigint']:
                # Float column going to integer column
                logging.info(f"    Converting float->int: {col} ({current_dtype} -> {target_type})")
                # Convert NaN to None, finite floats to integers
                df[col] = df[col].apply(
                    lambda x: None if pd.isna(x) or (isinstance(x, float) and not pd.notna(x)) else int(x)
                )
                # Ensure the column dtype is changed
                df[col] = df[col].astype('Int64')  # nullable integer
            else:
                # Float column staying float or going to text
                logging.info(f"Converting float NaN->None: {col}")
                df[col] = df[col].where(pd.notna(df[col]), None)

        elif 'int' in current_dtype:
            # Integer column - just convert NaN to None
            logging.info(f"Converting int NaN->None: {col}")
            df[col] = df[col].where(pd.notna(df[col]), None)

        else:
            # Object/string column - convert NaN to None
            logging.info(f"Converting object NaN->None: {col}")
            df[col] = df[col].where(pd.notna(df[col]), None)

    # Final check: convert any remaining NaN values to None
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = df[col].where(pd.notna(df[col]), None)

    logging.info("Dynamic NaN cleanup complete")
    return df


# Alternative simpler version if schema lookup fails
def simple_clean_dataframe_for_insertion(df):
    """
    Simple version that doesn't require schema lookup
    """
    if df is None or df.empty:
        return df

    df = df.copy()
    logging.info(f"SIMPLE FIX: Cleaning DataFrame...")

    total_nans = 0

    # Process each column
    for col in df.columns:
        nan_count = df[col].isna().sum()
        if nan_count == 0:
            continue

        total_nans += nan_count
        current_dtype = str(df[col].dtype)

        logging.info(f"Column '{col}': {nan_count} NaN values ({current_dtype})")

        if 'float' in current_dtype:
            # For float columns, convert NaN to None, and finite values to int if they're whole numbers
            def convert_float(x):
                if pd.isna(x):
                    return None
                elif float(x).is_integer():
                    return int(x)
                else:
                    return x

            df[col] = df[col].apply(convert_float)

        else:
            # For other types, just convert NaN to None
            df[col] = df[col].where(pd.notna(df[col]), None)

    logging.info(f"Cleaned {total_nans} NaN values across {len(df.columns)} columns")
    return df

def update_source_with_target_details(
    df,
    source_conn,
    source_table,
    df_source_id_col="source_id",
    table_id_col="id",
    target_details_col="target_details"
):
    """
    Updates the source_db table with target_details JSON for each row in df.

    Args:
        df (pd.DataFrame): DataFrame containing at least df_source_id_col and target_details_col
        source_conn: psycopg2 connection to source_db
        source_table (str): name of the table in source_db
        df_source_id_col (str): column in DataFrame containing source IDs (default "source_id")
        table_id_col (str): column name in the source table (default "id")
        target_details_col (str): column name where target_details should be stored (default "target_details")
    """
    if df is None or df.empty:
        logging.info("DataFrame is empty, nothing to update")
        return

    update_query = f"""
        UPDATE {source_table}
        SET {target_details_col} = %s
        WHERE {table_id_col} = %s;
    """

    try:
        with source_conn.cursor() as cur:
            for _, row in df.iterrows():
                target_details = row[target_details_col]
                source_id = row[df_source_id_col]  # take source_id from df
                cur.execute(update_query, (json.dumps(target_details), source_id))

            source_conn.commit()

        logging.info(f"Updated {len(df)} rows in {source_table} with target_details")

    except Exception as e:
        source_conn.rollback()
        logging.info(f"Error updating {source_table}: {e}")
        # raise  # uncomment if you want to propagate error
    # finally:
    #     return

def apply_fk_mapping(df, fk_col_target_mapping, mapped_ids):
    """
    Replaces foreign key values in df according to fk_col_target_mapping and mapped_ids.
    Only applies to integer/float columns (FKs), skips string/text columns.

    Args:
        df (pd.DataFrame): dataframe with source data
        fk_col_target_mapping (dict): config describing which columns to map
        mapped_ids (dict | str): dict {source_id: target_id} or JSON string

    Returns:
        pd.DataFrame: updated dataframe with mapped FKs
    """
    if not fk_col_target_mapping or not mapped_ids:
        return df

    # Work on a copy to avoid modifying the original
    df = df.copy()

    # Normalize mapped_ids into a dict
    if isinstance(mapped_ids, str):
        try:
            mapped_ids = json.loads(mapped_ids)
        except json.JSONDecodeError:
            logging.info("mapped_ids is not valid JSON string, ignoring")
            mapped_ids = {}
    elif not isinstance(mapped_ids, dict):
        logging.info(f"Unexpected type for mapped_ids: {type(mapped_ids)}")
        mapped_ids = {}

    for fk_col, mapping_conf in fk_col_target_mapping.items():
        if fk_col not in df.columns:
            logging.info(f"Column {fk_col} not found in DataFrame, skipping")
            continue

        col_dtype = str(df[fk_col].dtype)

        # Handle service_provider_name specially (string mapping)
        if fk_col == 'service_provider_name':
            if isinstance(mapped_ids, dict):
                logging.info(f"Applying string mapping on column: {fk_col}")
                logging.info(f"Mapping: {mapped_ids}")

                # Show what will be replaced
                for val in df[fk_col].dropna().unique():
                    if str(val) in mapped_ids:
                        logging.info(f"{fk_col}: {val} → {mapped_ids[str(val)]}")

                # Apply string mapping
                df[fk_col] = df[fk_col].map(mapped_ids).fillna(df[fk_col])
            continue

        # Only apply numeric mapping to integer/float columns
        if not any(x in col_dtype for x in ["int", "float", "Int64"]):
            logging.info(f"Skipping mapping on column: {fk_col} (dtype={col_dtype})")
            continue

        logging.info(f"Applying FK mapping on column: {fk_col}")

        # Normalize mapping keys to str for numeric columns
        mapped_ids_norm = {str(k): v for k, v in mapped_ids.items()}
        logging.info(f"MAPPED IDS NORM {mapped_ids_norm}")

        # Show what will be replaced
        for val in df[fk_col].dropna().unique():
            str_val = str(int(val)) if pd.notna(val) and str(val).replace('.', '').isdigit() else str(val)
            if str_val in mapped_ids_norm:
                logging.info(f"{fk_col}: {val} → {mapped_ids_norm[str_val]}")

        # Apply mapping with proper error handling and INTEGER RANGE CHECK
        try:
            # Convert to series for easier manipulation
            series = df[fk_col].copy()

            # Apply mapping
            mapped_series = (
                series
                .astype("Int64")  # keep nullable integers
                .astype(str)
                .map(mapped_ids_norm)
                .fillna(series.astype(str))
            )

            # CHECK FOR INTEGER OVERFLOW BEFORE CONVERSION
            for idx, val in mapped_series.items():
                if pd.notna(val) and val != '':
                    try:
                        int_val = int(val)
                        # PostgreSQL INTEGER range: -2,147,483,648 to 2,147,483,647
                        if int_val < -2147483648 or int_val > 2147483647:
                            logging.info(f"INTEGER OVERFLOW WARNING: {fk_col}[{idx}] = {int_val}")
                            logging.info(f"This value exceeds PostgreSQL INTEGER limits!")
                            logging.info(f"Consider changing the target column to BIGINT")
                            # You can either:
                            # 1. Set to None/NULL
                            mapped_series.iloc[idx] = None
                            # 2. Or raise an error to stop execution
                            # raise ValueError(f"Integer overflow in {fk_col}: {int_val}")
                    except (ValueError, TypeError):
                        logging.info(f"Invalid integer value in {fk_col}[{idx}]: {val}")
                        mapped_series.iloc[idx] = None

            # Final conversion with overflow protection
            df[fk_col] = mapped_series.astype("Int64")

        except Exception as mapping_error:
            logging.info(f"Error applying mapping to {fk_col}: {mapping_error}")
            # Continue with original values if mapping fails
            continue

    return df

def insert_service_providers(source_db, target_db,source_host,target_db_host,target_name,target_db_tenant_id,main_tenant_db_tenant_id):
    """
    Inserts service providers from source DB into target DB based on mappings
    defined in partner_provider_initial_sync_mappings.

    Process:
    1. Connect to common_utils, source, and target databases.
    2. Fetch mappings from partner_provider_initial_sync_mappings for this partner.
    3. For each mapping:
        a. Resolve where conditions (dynamic filters).
        b. Query common_utils to determine which rows from source DB should be considered.
        c. If inner join conditions exist, resolve those as well.
        d. Execute the final select query on the source DB.
        e. Insert results into the target DB.
        f. Capture the mapping of source_id → inserted_id and update source DB
           with target_details column.
        g. Persist mapping dictionary back into partner_provider_initial_sync_mappings.
    """
    logging.info(f"insert_service_providers source_db={source_db}, target_db={target_db} target name {target_name}")
    common_utils_conn = None
    source_conn = None
    target_db_conn = None
    partner_db = source_db
    partner_name = source_db
    target_name=target_name
    if target_db_tenant_id and main_tenant_db_tenant_id:
        if target_db_tenant_id==main_tenant_db_tenant_id:
            sp_tenant_id=main_tenant_db_tenant_id
        else:
            sp_tenant_id=target_db_tenant_id
    else:
        sp_tenant_id=None

    try:
        context_vars = {
            "source_db": source_db,
            "target_db": target_db,
            "partner_db": partner_db,
            "partner_name": partner_name,
            "target_name":target_name
        }

        # Load DB connection details
        load_dotenv()
        host = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        common_utils_db = os.getenv('COMMON_UTILS_DB')
        db_type = os.getenv('PSQL_DB_TYPE')

        # ---------------- Connection Handling ----------------
        try:
            common_utils_conn = create_connection(db_type, host, common_utils_db, user, password, port)
            if not common_utils_conn:
                raise ConnectionError(f"insert_service_providers Connection to common_utils_db {common_utils_db} failed")
            logging.info(f"insert_service_providers Connected to common_utils DB: {common_utils_conn}")
        except Exception as e:
            logging.error(f"insert_service_providers Failed to connect to common_utils DB: {e}")
            return False, e

        try:
            if source_db and source_host:
                source_conn = create_connection(db_type, source_host, source_db, user, password, port)
                if not source_conn:
                    raise ConnectionError(f"insert_service_providers Connection to source db {source_db} failed")
                logging.info(f"insert_service_providers Connected to source DB: {source_conn}")
        except Exception as e:
            logging.error(f"insert_service_providers Failed to connect to source DB {source_db}: {e}")
            return False, e

        try:
            if target_db and target_db_host:
                target_db_conn = create_connection(db_type, target_db_host, target_db, user, password, port)
                if not target_db_conn:
                    raise ConnectionError(f"insert_service_providers Connection to target db {target_db} failed")
                logging.info(f"insert_service_providers Connected to target DB: {target_db_conn}")
        except Exception as e:
            logging.error(f"insert_service_providers Failed to connect to target DB {target_db}: {e}")
            return False, e

        # ---------------- Fetch Mappings ----------------
        try:
            mappings_query = """
                select id, table_name, fk_col_target_mapping, where_cond,
                       select_query, mapped_ids
                from partner_provider_initial_sync_mappings
                where partner_name=%s and (target_db=%s or main_tenant_db=%s) and target_name=%s
                  and service_provider_mapping_flag=true
                order by migration_order asc
            """
            mappings_df = execute_query_db(common_utils_conn, mappings_query, (source_db, target_db, target_db,target_name))
            logging.info(f"insert_service_providers Fetched {len(mappings_df)} mapping rows")
        except Exception as e:
            logging.error(f"insert_service_providers Error fetching mappings: {e}")
            return False, e
        logging.info(f"insert_service_providers source_db={source_db}, target_db={target_db} context_vars {context_vars}")
        # partner_db = source_db
        # partner_name = source_db
        # ---------------- Process Mappings ----------------
        for idx, row in mappings_df.iterrows():
            try:
                id = row['id']
                table_name = row['table_name']
                where_cond = row['where_cond']
                fk_col_target_mapping = row['fk_col_target_mapping']
                select_query = row['select_query']

                if not table_name or not where_cond:
                    logging.warning(f"insert_service_providers Skipping mapping {id}: missing table_name or where_cond")
                    continue

                logging.info(f"insert_service_providers Processing mapping {id} for table {table_name}")

                for details in where_cond:
                    try:
                        # ---- Extract WHERE condition details ----
                        where_table = details['where_table']
                        where_col = details['where_col']
                        filter_cols = details.get('<where_condition>', [])
                        inner_where_table = details.get('inner_where_table', None)
                        inner_where_col = details.get('inner_where_col', None)
                        inner_where_cond_col = details.get('inner_where_cond_col', None)
                        where_col_in_table = details.get('where_col_in_table', None)
                        row_name = details.get('row_name', None)
                        row_val = details.get('row_val', None)
                        logging.info(f"insert_service_providers filter_cols are {filter_cols}")
                        logging.info(f"insert_service_providers locals: {locals().keys()}")

                        # ---- Build and Execute Base Query ----
                        if row_name and row_val:
                            base_query = (
                                f"SELECT {where_col} FROM {where_table} WHERE "
                                + " AND ".join([f"{col}=%s" for col in filter_cols])
                                + f" and {row_name} = '{row_val}'"
                            )
                        else:
                            base_query = (
                                f"SELECT {where_col} FROM {where_table} WHERE "
                                + " AND ".join([f"{col}=%s" for col in filter_cols])
                            )
                        logging.info(f"{table_name} BASE QUERY {base_query}")

                        filter_values = tuple(context_vars.get(c) for c in filter_cols)
                        logging.info(f"insert_service_providers filter values for base query {filter_values}")
                        # filter_values = tuple([locals().get(c) for c in filter_cols])
                        # logging.info(f"filter values for base query {filter_values}")

                        where_results = execute_query_db(common_utils_conn, base_query, filter_values)

                        if where_results is None or where_results.empty:
                            logging.info(f"insert_service_providers No results for {base_query} with {filter_values}")
                            continue

                        # ---- Parse WHERE results ----
                        try:
                            raw_value = where_results.to_dict(orient='records')[0][where_col]
                            if isinstance(raw_value, dict):
                                where_results_dict = raw_value
                            elif isinstance(raw_value, str):
                                try:
                                    where_results_dict = json.loads(raw_value)
                                except json.JSONDecodeError:
                                    logging.warning("insert_service_providers Invalid JSON string, using empty dict")
                                    where_results_dict = {}
                            else:
                                where_results_dict = {}
                        except Exception as parse_err:
                            logging.error(f"insert_service_providers Error parsing where_results: {parse_err}")
                            continue

                        where_vals = tuple(where_results_dict.keys())
                        logging.info(f"insert_service_providers Resolved WHERE results: {where_vals}")

                        # ---- Handle INNER WHERE conditions ----
                        if inner_where_col and inner_where_table and inner_where_cond_col:
                            try:
                                selct_query_inner = f"""
                                    select {inner_where_col}
                                    from {inner_where_table}
                                    where {inner_where_cond_col} in %s
                                """
                                inner_where_results = execute_query_db(source_conn, selct_query_inner, (where_vals,))
                                if inner_where_results is None or inner_where_results.empty:
                                    logging.info(f"insert_service_providers No results for inner query {selct_query_inner}")
                                    continue
                                inner_where_results_list = tuple(inner_where_results[inner_where_col].tolist())
                            except Exception as e:
                                logging.error(f"insert_service_providers Error executing inner query: {e}")
                                continue

                            # Final SELECT
                            if "where" in select_query.lower():
                                if len(inner_where_results_list) == 1:
                                    final_select_query = select_query + f" ({inner_where_results_list[0]})"
                                else:
                                    final_select_query = select_query + f" {inner_where_results_list}"


                                try:
                                    final_select_query_result = execute_query_db(source_conn, final_select_query)
                                    if final_select_query_result is None or final_select_query_result.empty:
                                        logging.info(f"insert_service_providers No rows returned for {final_select_query}")
                                        continue
                                except Exception as e:
                                    logging.error(f"insert_service_providers Error executing final select query: {e}")
                                    continue

                                # Insert into target
                                try:
                                    logging.info(f"insert_service_providers DEBUG: DataFrame before insertion")
                                    logging.info(f"insert_service_providers Shape: {final_select_query_result.shape}")
                                    logging.info(f"insert_service_providers Columns: {list(final_select_query_result.columns)}")
                                    logging.info(f"insert_service_providers Data types: {final_select_query_result.dtypes}")
                                    logging.info(f"insert_service_providers Sample data:{final_select_query_result.head()}")
                                    mapping_dict, enriched_df = insert_dataframe_with_mapping(
                                        df=final_select_query_result,
                                        target_conn=target_db_conn,
                                        target_table=table_name,
                                        source_db=source_db,
                                        target_db_name=target_db,
                                        target_name=target_name,
                                        source_id_col="source_id"
                                    )
                                    logging.info(f"insert_service_providers Mapping: {mapping_dict}")
                                    logging.info(f"insert_service_providers Enriched DF with target_details: {enriched_df.to_dict(orient='records')}")

                                    # Update the source DB with target_details column
                                    update_source_with_target_details(
                                        df=enriched_df,
                                        source_conn=source_conn,
                                        source_table=table_name,
                                        df_source_id_col="source_id",
                                        table_id_col="id",
                                        target_details_col="target_details"
                                    )
                                    update_query = "update partner_provider_initial_sync_mappings set mapped_ids=%s where id=%s"
                                    with common_utils_conn.cursor() as cur:
                                        cur.execute(update_query, (json.dumps(mapping_dict), id))
                                        common_utils_conn.commit()
                                except Exception as e:
                                    logging.error(f"insert_service_providers Error inserting/updating for table {table_name}: {e}")
                                    logging.info(f"insert_service_providers Error inserting/updating for table {table_name}: {e}")
                                    continue

                        else:
                            # Direct select path (no inner query)
                            logging.info(f"insert_service_providers In ELSE ")
                            logging.info(f"insert_service_providers RUNNING FOR TABLE {table_name}")
                            logging.info(f"insert_service_providers AAA table name {table_name} {select_query}")
                            try:
                                if len(where_vals) == 1:
                                    final_select_query = select_query + f" WHERE {where_col_in_table} IN ('{where_vals[0]}')"
                                else:
                                    final_select_query = select_query + f" WHERE {where_col_in_table} IN {tuple(map(str, where_vals))}"
                                
                                final_select_query_result = execute_query_db(source_conn, final_select_query)

                                if final_select_query_result is None or final_select_query_result.empty:
                                    logging.info(f"insert_service_providers No rows returned for {final_select_query}")
                                    continue
                                logging.info(f"insert_service_providers FINAL SELECT QUERY result {final_select_query_result.to_dict(orient='records')}")
                            except Exception as e:
                                logging.error(f"insert_service_providers Error executing direct select query: {e}")
                                logging.info(f"insert_service_providers Error executing direct select query: {e}")
                                continue

                            if not fk_col_target_mapping:
                                logging.warning(f"insert_service_providers No FK mapping config for table {table_name}")
                                continue

                            # Apply FK mappings
                            try:
                                mapped_ids = {}
                                updated_df = final_select_query_result.copy()

                                # updated_df = final_select_query_result
                                for fk_col, mapping_conf in fk_col_target_mapping.items():
                                    logging.info(f"insert_service_providers Applying FK mapping for column {fk_col},{mapping_conf}")
                                    where_table = mapping_conf["where_table"]
                                    where_row = mapping_conf.get("where_row",None)
                                    where_row_name = mapping_conf.get("where_row_name",None)
                                    col_to_check = mapping_conf["col_to_check"]
                                    filter_cols_2 = mapping_conf.get('<where_cond>', [])
                                    # filter_vals_2 = tuple([locals().get(c) for c in filter_cols_2])
                                    # logging.info(f"FOR {table_name} WHERE TABLE IS {where_table} WHERE COND {filter_cols_2}")
                                    filter_vals_2 = tuple(context_vars.get(c) for c in filter_cols_2)
                                    logging.info(f"insert_service_providers FOR {table_name} WHERE TABLE IS {where_table} WHERE COND {filter_vals_2}")

                                    if where_row and where_row_name:
                                        query = f"SELECT {col_to_check} FROM {where_table} WHERE " + \
                                            " AND ".join([f"{col}=%s" for col in filter_cols_2]) + f" and {where_row_name} = '{where_row}'"
                                    else:
                                        query = f"SELECT {col_to_check} FROM {where_table} WHERE " + \
                                            " AND ".join([f"{col}=%s" for col in filter_cols_2])

                                    logging.info(f"insert_service_providers FK column {fk_col} query: {query}")
                                    filter_where_results = execute_query_db(common_utils_conn, query, filter_vals_2)
                                    logging.info(f"insert_service_providers {table_name} FK column {fk_col} results: {filter_where_results}")

                                    if filter_where_results is None or filter_where_results.empty:
                                        logging.info(f"insert_service_providers No mapping found for FK column {fk_col}")
                                        continue

                                    raw_mapped_ids = filter_where_results.to_dict(orient='records')[0][col_to_check]
                                    logging.info(f"insert_service_providers FK column {fk_col} raw mapped_ids: {raw_mapped_ids} (type: {type(raw_mapped_ids)})")

                                    # Handle both dict and JSON string cases
                                    if isinstance(raw_mapped_ids, dict):
                                        mapped_ids = raw_mapped_ids
                                    elif isinstance(raw_mapped_ids, str):
                                        try:
                                            mapped_ids = json.loads(raw_mapped_ids)
                                            logging.info(f"insert_service_providers Parsed JSON string to dict: {mapped_ids}")
                                        except json.JSONDecodeError:
                                            logging.info(f"insert_service_providers Failed to parse JSON string: {raw_mapped_ids}")
                                            continue
                                    else:
                                        logging.info(f"insert_service_providers Unsupported mapped_ids type: {type(raw_mapped_ids)}")
                                        continue

                                    logging.info(f"insert_service_providers FK column {fk_col} final mapped_ids: {mapped_ids} (type: {type(mapped_ids)})")

                                    # Apply the FK mapping ONLY to this specific column
                                    if isinstance(mapped_ids, dict) and fk_col in updated_df.columns:
                                        logging.info(f"insert_service_providers Applying mapping to ONLY column {fk_col}: {mapped_ids}")
                                        logging.info(f"insert_service_providers Before mapping - Column {fk_col} values: {updated_df[fk_col].tolist()}")
                                        logging.info(f"insert_service_providers Before mapping - Column {fk_col} dtype: {updated_df[fk_col].dtype}")

                                        # Handle null values separately - don't try to map them
                                        null_mask = updated_df[fk_col].isna()

                                        # Work with non-null values
                                        non_null_mask = ~null_mask
                                        if non_null_mask.any():
                                            # Determine if this is a numeric ID column or a string column
                                            is_numeric_id_column = fk_col.endswith('_id') or fk_col == 'id'

                                            # Track which rows got mapped successfully
                                            mapped_mask = pd.Series(False, index=updated_df.index)

                                            # Snapshot original values to prevent cascading remaps #integer_id-issue
                                            original_values = updated_df[fk_col].copy()
                                            
                                            for source_key, target_value in mapped_ids.items():
                                                if is_numeric_id_column:
                                                    # For ID columns, handle numeric mapping
                                                    try:
                                                        # Convert mapping key to numeric for comparison
                                                        source_id_numeric = int(source_key) if str(source_key).replace('.','').replace('-','').isdigit() else float(source_key)

                                                        # Create masks for both string and numeric matches
                                                        if updated_df[fk_col].dtype == 'object':
                                                            # For object columns, try both string and numeric matching
                                                            # string_mask = (updated_df[fk_col].astype(str) == str(source_key)) & non_null_mask #intregration_id-issue
                                                            string_mask = (original_values.astype(str) == str(source_key)) & non_null_mask
                                                            numeric_mask = pd.Series([False] * len(updated_df), index=updated_df.index)
                                                            try:
                                                                # numeric_values = pd.to_numeric(updated_df[fk_col], errors='coerce') #intregration_id-issue
                                                                numeric_values = pd.to_numeric(original_values, errors='coerce')
                                                                numeric_mask = (numeric_values == source_id_numeric) & non_null_mask
                                                            except:
                                                                pass
                                                            match_mask = string_mask | numeric_mask
                                                        else:
                                                            # For numeric columns
                                                            # match_mask = (updated_df[fk_col] == source_id_numeric) & non_null_mask #integration-id-issue
                                                            match_mask = (original_values == source_id_numeric) & non_null_mask

                                                        # Apply mapping where match is found
                                                        if match_mask.any():
                                                            logging.info(f"insert_service_providers Mapping {source_key} -> {target_value} for {match_mask.sum()} rows")
                                                            updated_df.loc[match_mask, fk_col] = target_value
                                                            mapped_mask |= match_mask #integration-id-issue

                                                    except (ValueError, TypeError) as e:
                                                        logging.info(f"insert_service_providers Warning: Could not process numeric mapping {source_key} -> {target_value}: {e}")
                                                        continue


                                                else:
                                                    # For string columns (like service_provider_name, display_name), handle string mapping
                                                    try:
                                                        # Direct string matching
                                                        if updated_df[fk_col].dtype == 'object':
                                                            # Match exact strings 
                                                            # string_match_mask = (updated_df[fk_col] == source_key) & non_null_mask
                                                            # # Also try matching after converting to string
                                                            # str_convert_mask = (updated_df[fk_col].astype(str) == str(source_key)) & non_null_mask
                                                            # match_mask = string_match_mask | str_convert_mask #integration-id issues 
                                                            string_match_mask = (original_values == source_key) & non_null_mask
                                                            str_convert_mask = (original_values.astype(str) == str(source_key)) & non_null_mask                                                            
                                                            match_mask = (original_values.astype(str) == str(source_key)) & non_null_mask

                                                        else:
                                                            # Convert both to string for comparison
                                                            match_mask = (original_values.astype(str) == str(source_key)) & non_null_mask 

                                                        # Apply mapping where match is found
                                                        if match_mask.any():
                                                            logging.info(f"insert_service_providers Mapping '{source_key}' -> '{target_value}' for {match_mask.sum()} rows")
                                                            updated_df.loc[match_mask, fk_col] = target_value
                                                            mapped_mask |= match_mask

                                                    except (ValueError, TypeError) as e:
                                                        logging.info(f"insert_service_providers Warning: Could not process string mapping {source_key} -> {target_value}: {e}")
                                                        continue

                                        # AFTER finishing all mappings #integration-id fix
                                        if fk_col == 'service_provider_id':
                                            unmapped_mask = non_null_mask & (~mapped_mask)
                                            if unmapped_mask.any():
                                                logging.info(
                                                    f"insert_service_providers Setting {unmapped_mask.sum()} "
                                                    f"unmapped '{fk_col}' values to NULL"
                                                )
                                                updated_df.loc[unmapped_mask, fk_col] = pd.NA

                                        # Final cleanup - ensure proper data type
                                        if is_numeric_id_column:
                                            try:
                                                # Convert to nullable integer if all non-null values are numeric
                                                non_null_values = updated_df.loc[~updated_df[fk_col].isna(), fk_col]
                                                if len(non_null_values) > 0:
                                                    # Try to convert to numeric
                                                    numeric_series = pd.to_numeric(non_null_values, errors='coerce')
                                                    if not numeric_series.isna().any():  # All converted successfully
                                                        updated_df[fk_col] = updated_df[fk_col].astype('Int64')  # Nullable integer
                                                    else:
                                                        logging.info(f"insert_service_providers Warning: Some values in {fk_col} could not be converted to numeric")
                                            except Exception as e:
                                                logging.info(f"insert_service_providers Warning: Could not finalize data type for {fk_col}: {e}")
                                        else:
                                            # For string columns, ensure they remain as object type
                                            try:
                                                updated_df[fk_col] = updated_df[fk_col].astype('object')
                                            except Exception as e:
                                                logging.info(f"insert_service_providers Warning: Could not ensure object type for {fk_col}: {e}")

                                        logging.info(f"insert_service_providers After mapping - Column {fk_col} values: {updated_df[fk_col].tolist()}")
                                        logging.info(f"insert_service_providers After mapping - Column {fk_col} dtype: {updated_df[fk_col].dtype}")

                                    else:
                                        if fk_col not in updated_df.columns:
                                            logging.info(f"insert_service_providers Warning: Column {fk_col} not found in DataFrame columns: {list(updated_df.columns)}")
                                        if not isinstance(mapped_ids, dict):
                                            logging.info(f"insert_service_providers Warning: mapped_ids for {fk_col} is not a dict: {type(mapped_ids)}")

                                logging.info(f"insert_service_providers Final DataFrame after all FK mappings:")
                                logging.info(f"insert_service_providers integration_id values: {updated_df['integration_id'].tolist() if 'integration_id' in updated_df.columns else 'Column not found'}")
                                logging.info(f"insert_service_providers service_provider_id values: {updated_df['service_provider_id'].tolist() if 'service_provider_id' in updated_df.columns else 'Column not found'}")

                                if table_name == 'serviceprovider':
                                    logging.info(f"Need to update the tenant_id in the df here with {sp_tenant_id}")
                                    if sp_tenant_id is not None:
                                        updated_df["tenant_id"] = sp_tenant_id
                                    else:
                                        updated_df["tenant_id"] = None
                                        logging.info(f"insert_service_providers tenant_id is None, so setting it to None")
                                    
                                # Clean and prepare DataFrame for insertion
                                updated_df = updated_df.replace([np.nan, pd.NaT], None)
                                updated_df = clean_dataframe_for_insertion(updated_df, target_db_conn, table_name)
                                logging.info(f"target name is {target_name}")
                                
                                updated_df["target_name"]= target_name

                                logging.info(f"insert_service_providers \n=== DEBUG: DataFrame before insertion ===")
                                logging.info(f"insert_service_providers Shape: {updated_df.shape}")
                                logging.info(f"insert_service_providers Columns: {list(updated_df.columns)}")
                                logging.info(f"insert_service_providers Data types:\n{updated_df.dtypes}")
                                logging.info(f"insert_service_providers Sample data:\n{updated_df.head().to_dict(orient='records')}")

                                # Insert with mapping
                                mapping_dict, enriched_df = insert_dataframe_with_mapping(
                                    df=updated_df,
                                    target_conn=target_db_conn,
                                    target_table=table_name,
                                    source_db=source_db,
                                    target_db_name=target_db,
                                    target_name=target_name,
                                    source_id_col="source_id"
                                )

                                logging.info(f"insert_service_providers Mapping: {mapping_dict}")
                                logging.info(f"insert_service_providers Enriched DF with target_details: {enriched_df.to_dict(orient='records')}")

                                # Update source DB with target details
                                update_source_with_target_details(
                                    df=enriched_df,
                                    source_conn=source_conn,
                                    source_table=table_name,
                                    df_source_id_col="source_id",
                                    table_id_col="id",
                                    target_details_col="target_details"
                                )

                                # Update mapped_ids in mappings table
                                update_query = f"update partner_provider_initial_sync_mappings set mapped_ids=%s where id=%s"
                                with common_utils_conn.cursor() as cur:
                                    cur.execute(update_query, (json.dumps(mapping_dict), id))
                                    common_utils_conn.commit()

                                   
                            except Exception as e:
                                logging.error(f"insert_service_providers Error in FK mapping or insert for table {table_name}: {e}")
                                continue

                    except Exception as e:
                        logging.error(f"insert_service_providers Error processing where condition for mapping {id}, table {table_name}: {e}")
                        continue

            except Exception as e:
                logging.error(f"insert_service_providers Error processing mapping row {idx}: {e}")
                continue

        return True, None

    except Exception as e:
        logging.error(f"insert_service_providers Fatal error in insert_service_providers: {e}")
        return False, e

    finally:
        # ---------------- Cleanup ----------------
        for conn_name, conn in {
            "common_utils": common_utils_conn,
            "source": source_conn,
            "target": target_db_conn
        }.items():
            try:
                if conn:
                    conn.close()
                    logging.info(f"insert_service_providers Closed {conn_name} connection")
            except Exception as e:
                logging.warning(f"insert_service_providers Error closing {conn_name} connection: {e}")


# def insert_service_providers(source_db, target_db):
#     """
#     Inserts service providers from source DB into target DB based on mappings
#     defined in partner_provider_initial_sync_mappings.

#     Process:
#     1. Connect to common_utils, source, and target databases.
#     2. Fetch mappings from partner_provider_initial_sync_mappings for this partner.
#     3. For each mapping:
#         a. Resolve where conditions (dynamic filters).
#         b. Query common_utils to determine which rows from source DB should be considered.
#         c. If inner join conditions exist, resolve those as well.
#         d. Execute the final select query on the source DB.
#         e. Insert results into the target DB.
#         f. Capture the mapping of source_id → inserted_id and update source DB
#            with target_details column.
#         g. Persist mapping dictionary back into partner_provider_initial_sync_mappings.
#     """
#     logging.info(f"source_db={source_db}, target_db={target_db}")
#     common_utils_conn = None
#     source_conn = None
#     target_db_conn = None
#     partner_db = source_db
#     partner_name = source_db

#     try:
#         context_vars = {
#             "source_db": source_db,
#             "target_db": target_db,
#             "partner_db": partner_db,
#             "partner_name": partner_name,
#         }

#         # Load DB connection details
#         load_dotenv()
#         host = os.getenv('PSQL_DB_HOST')
#         port = os.getenv('PSQL_DB_PORT')
#         user = os.getenv('PSQL_DB_USER')
#         password = os.getenv('PSQL_DB_PASSWORD')
#         common_utils_db = os.getenv('COMMON_UTILS_DB')
#         db_type = os.getenv('PSQL_DB_TYPE')

#         # ---------------- Connection Handling ----------------
#         try:
#             common_utils_conn = create_connection(db_type, host, common_utils_db, user, password, port)
#             if not common_utils_conn:
#                 raise ConnectionError(f"Connection to common_utils_db {common_utils_db} failed")
#             logging.info(f"Connected to common_utils DB: {common_utils_conn}")
#         except Exception as e:
#             logging.error(f"Failed to connect to common_utils DB: {e}")
#             return False, e

#         try:
#             if source_db:
#                 source_conn = create_connection(db_type, host, source_db, user, password, port)
#                 if not source_conn:
#                     raise ConnectionError(f"Connection to source db {source_db} failed")
#                 logging.info(f"Connected to source DB: {source_conn}")
#         except Exception as e:
#             logging.error(f"Failed to connect to source DB {source_db}: {e}")
#             return False, e

#         try:
#             if target_db:
#                 target_db_conn = create_connection(db_type, host, target_db, user, password, port)
#                 if not target_db_conn:
#                     raise ConnectionError(f"Connection to target db {target_db} failed")
#                 logging.info(f"Connected to target DB: {target_db_conn}")
#         except Exception as e:
#             logging.error(f"Failed to connect to target DB {target_db}: {e}")
#             return False, e

#         # ---------------- Fetch Mappings ----------------
#         try:
#             mappings_query = """
#                 select id, table_name, fk_col_target_mapping, where_cond,
#                        select_query, mapped_ids
#                 from partner_provider_initial_sync_mappings
#                 where partner_name=%s and (target_db=%s or main_tenant_db=%s)
#                   and service_provider_mapping_flag=true
#                 order by migration_order asc
#             """
#             mappings_df = execute_query_db(common_utils_conn, mappings_query, (source_db, target_db, target_db))
#             logging.info(f"Fetched {len(mappings_df)} mapping rows")
#         except Exception as e:
#             logging.error(f"Error fetching mappings: {e}")
#             return False, e
#         logging.info(f"source_db={source_db}, target_db={target_db} context_vars {context_vars}")
#         # partner_db = source_db
#         # partner_name = source_db
#         # ---------------- Process Mappings ----------------
#         for idx, row in mappings_df.iterrows():
#             try:
#                 id = row['id']
#                 table_name = row['table_name']
#                 where_cond = row['where_cond']
#                 fk_col_target_mapping = row['fk_col_target_mapping']
#                 select_query = row['select_query']

#                 if not table_name or not where_cond:
#                     logging.warning(f"Skipping mapping {id}: missing table_name or where_cond")
#                     continue

#                 logging.info(f"Processing mapping {id} for table {table_name}")

#                 for details in where_cond:
#                     try:
#                         # ---- Extract WHERE condition details ----
#                         where_table = details['where_table']
#                         where_col = details['where_col']
#                         filter_cols = details.get('<where_condition>', [])
#                         inner_where_table = details.get('inner_where_table', None)
#                         inner_where_col = details.get('inner_where_col', None)
#                         inner_where_cond_col = details.get('inner_where_cond_col', None)
#                         where_col_in_table = details.get('where_col_in_table', None)
#                         row_name = details.get('row_name', None)
#                         row_val = details.get('row_val', None)
#                         logging.info(f"filter_cols are {filter_cols}")
#                         logging.info(f"locals: {locals().keys()}")

#                         # ---- Build and Execute Base Query ----
#                         if row_name and row_val:
#                             base_query = (
#                                 f"SELECT {where_col} FROM {where_table} WHERE "
#                                 + " AND ".join([f"{col}=%s" for col in filter_cols])
#                                 + f" and {row_name} = '{row_val}'"
#                             )
#                         else:
#                             base_query = (
#                                 f"SELECT {where_col} FROM {where_table} WHERE "
#                                 + " AND ".join([f"{col}=%s" for col in filter_cols])
#                             )
#                         logging.info(f"{table_name} BASE QUERY {base_query}")

#                         filter_values = tuple(context_vars.get(c) for c in filter_cols)
#                         logging.info(f"filter values for base query {filter_values}")
#                         # filter_values = tuple([locals().get(c) for c in filter_cols])
#                         # logging.info(f"filter values for base query {filter_values}")

#                         where_results = execute_query_db(common_utils_conn, base_query, filter_values)

#                         if where_results is None or where_results.empty:
#                             logging.info(f"No results for {base_query} with {filter_values}")
#                             continue

#                         # ---- Parse WHERE results ----
#                         try:
#                             raw_value = where_results.to_dict(orient='records')[0][where_col]
#                             if isinstance(raw_value, dict):
#                                 where_results_dict = raw_value
#                             elif isinstance(raw_value, str):
#                                 try:
#                                     where_results_dict = json.loads(raw_value)
#                                 except json.JSONDecodeError:
#                                     logging.warning("Invalid JSON string, using empty dict")
#                                     where_results_dict = {}
#                             else:
#                                 where_results_dict = {}
#                         except Exception as parse_err:
#                             logging.error(f"Error parsing where_results: {parse_err}")
#                             continue

#                         where_vals = tuple(where_results_dict.keys())
#                         logging.info(f"Resolved WHERE results: {where_vals}")

#                         # ---- Handle INNER WHERE conditions ----
#                         if inner_where_col and inner_where_table and inner_where_cond_col:
#                             try:
#                                 selct_query_inner = f"""
#                                     select {inner_where_col}
#                                     from {inner_where_table}
#                                     where {inner_where_cond_col} in %s
#                                 """
#                                 inner_where_results = execute_query_db(source_conn, selct_query_inner, (where_vals,))
#                                 if inner_where_results is None or inner_where_results.empty:
#                                     logging.info(f"No results for inner query {selct_query_inner}")
#                                     continue
#                                 inner_where_results_list = tuple(inner_where_results[inner_where_col].tolist())
#                             except Exception as e:
#                                 logging.error(f"Error executing inner query: {e}")
#                                 continue

#                             # Final SELECT
#                             if "where" in select_query.lower():
#                                 if len(inner_where_results_list) == 1:
#                                     final_select_query = select_query + f" ({inner_where_results_list[0]})"
#                                 else:
#                                     final_select_query = select_query + f" {inner_where_results_list}"


#                                 try:
#                                     final_select_query_result = execute_query_db(source_conn, final_select_query)
#                                     if final_select_query_result is None or final_select_query_result.empty:
#                                         logging.info(f"No rows returned for {final_select_query}")
#                                         continue
#                                 except Exception as e:
#                                     logging.error(f"Error executing final select query: {e}")
#                                     continue

#                                 # Insert into target
#                                 try:
#                                     logging.info(f"DEBUG: DataFrame before insertion")
#                                     logging.info(f"Shape: {final_select_query_result.shape}")
#                                     logging.info(f"Columns: {list(final_select_query_result.columns)}")
#                                     logging.info(f"Data types:\n {final_select_query_result.dtypes}")
#                                     logging.info(f"Sample data:\n{final_select_query_result.head()}")
#                                     mapping_dict, enriched_df = insert_dataframe_with_mapping(
#                                         df=final_select_query_result,
#                                         target_conn=target_db_conn,
#                                         target_table=table_name,
#                                         source_db=source_db,
#                                         target_db_name=target_db,
#                                         source_id_col="source_id"
#                                     )
#                                     logging.info(f"Mapping: {mapping_dict}")
#                                     logging.info(f"Enriched DF with target_details: {enriched_df.to_dict(orient='records')}")
#                                     update_source_with_target_details(
#                                         df=enriched_df,
#                                         source_conn=source_conn,
#                                         source_table=table_name,
#                                         df_source_id_col="source_id",
#                                         table_id_col="id",
#                                         target_details_col="target_details"
#                                     )
#                                     update_query = "update partner_provider_initial_sync_mappings set mapped_ids=%s where id=%s"
#                                     with common_utils_conn.cursor() as cur:
#                                         cur.execute(update_query, (json.dumps(mapping_dict), id))
#                                         common_utils_conn.commit()
#                                 except Exception as e:
#                                     logging.error(f"Error inserting/updating for table {table_name}: {e}")
#                                     logging.info(f"Error inserting/updating for table {table_name}: {e}")
#                                     continue

#                         else:
#                             # Direct select path (no inner query)
#                             try:
#                                 if len(where_vals) == 1:
#                                     final_select_query = select_query + f" WHERE {where_col_in_table} IN ('{where_vals[0]}')"
#                                 else:
#                                     final_select_query = select_query + f" WHERE {where_col_in_table} IN {tuple(map(str, where_vals))}"
#                                 final_select_query_result = execute_query_db(source_conn, final_select_query)

#                                 if final_select_query_result is None or final_select_query_result.empty:
#                                     logging.info(f"No rows returned for {final_select_query}")
#                                     continue
#                                 print(f"FINAL SELECT QUERY result {final_select_query_result.to_dict(orient='records')}")
#                             except Exception as e:
#                                 logging.error(f"Error executing direct select query: {e}")
#                                 logging.info(f"Error executing direct select query: {e}")
#                                 continue

#                             if not fk_col_target_mapping:
#                                 logging.warning(f"No FK mapping config for table {table_name}")
#                                 continue

#                             # Apply FK mappings
#                             try:
#                                 updated_df = final_select_query_result
#                                 for fk_col, mapping_conf in fk_col_target_mapping.items():
#                                     logging.info(f"Applying FK mapping for column {fk_col},{mapping_conf}")
#                                     where_table = mapping_conf["where_table"]
#                                     where_row = mapping_conf.get("where_row",None)
#                                     where_row_name = mapping_conf.get("where_row_name",None)
#                                     col_to_check = mapping_conf["col_to_check"]
#                                     filter_cols_2 = mapping_conf.get('<where_cond>', [])
#                                     # filter_vals_2 = tuple([locals().get(c) for c in filter_cols_2])
#                                     # logging.info(f"FOR {table_name} WHERE TABLE IS {where_table} WHERE COND {filter_cols_2}")
#                                     filter_vals_2 = tuple(context_vars.get(c) for c in filter_cols_2)
#                                     logging.info(f"FOR {table_name} WHERE TABLE IS {where_table} WHERE COND {filter_vals_2}")

#                                     if where_row and where_row_name:
#                                         query = f"SELECT {col_to_check} FROM {where_table} WHERE " + \
#                                             " AND ".join([f"{col}=%s" for col in filter_cols_2]) + f" and {where_row_name} = '{where_row}'"
#                                         logging.info(f"{table_name} for FK COL :{fk_col} Executing: {query}")

#                                         filter_where_results = execute_query_db(common_utils_conn, query, filter_vals_2)
#                                         logging.info(F"{table_name} IN IF {filter_where_results}")


#                                         mapped_ids=filter_where_results.to_dict(orient='records')[0][col_to_check]
#                                         logging.info(f"{table_name}---{fk_col}---mapped_ids here {mapped_ids}")
#                                         updated_df=apply_fk_mapping(
#                                                 final_select_query_result,
#                                                 fk_col_target_mapping,
#                                                 mapped_ids
#                                             )
#                                     else:
#                                         query = f"SELECT {col_to_check} FROM {where_table} WHERE " + \
#                                             " AND ".join([f"{col}=%s" for col in filter_cols_2])
#                                         logging.info(f"for FK COL :{fk_col} Executing: {query}")

#                                         filter_where_results = execute_query_db(common_utils_conn, query, filter_vals_2)
#                                         logging.info(F"{table_name} IN ELSE {filter_where_results}")
#                                         logging.info(f"ELSE {final_select_query_result}")
#                                         mapped_ids=filter_where_results.to_dict(orient='records')[0][col_to_check]
#                                         logging.info(f"{table_name} {fk_col} mapped_ids here else {mapped_ids}")

#                                         updated_df=apply_fk_mapping(
#                                                 final_select_query_result,
#                                                 fk_col_target_mapping,
#                                                 mapped_ids
#                                             )

#                                 if final_select_query_result is None or final_select_query_result.empty:
#                                     logging.info(f"No results found for {final_select_query}")
#                                     continue

#                                 updated_df = updated_df.replace([np.nan, pd.NaT], None)
#                                 updated_df = clean_dataframe_for_insertion(updated_df, target_db_conn, table_name)
#                                 logging.info(f"\n=== DEBUG: DataFrame before insertion ===")
#                                 logging.info(f"Shape: {updated_df.shape}")
#                                 logging.info(f"Columns: {list(updated_df.columns)}")
#                                 logging.info(f"Data types:\n{updated_df.dtypes}")
#                                 logging.info(f"Sample data:\n{updated_df.head()}")
#                                 mapping_dict, enriched_df = insert_dataframe_with_mapping(
#                                     df=updated_df,
#                                     target_conn=target_db_conn,
#                                     target_table=table_name,
#                                     source_db=source_db,
#                                     target_db_name=target_db,
#                                     source_id_col="source_id"
#                                 )
#                                 logging.info(f"Mapping: {mapping_dict}")
#                                 logging.info(f"Enriched DF with target_details: {enriched_df}")

#                                 update_source_with_target_details(
#                                     df=enriched_df,
#                                     source_conn=source_conn,
#                                     source_table=table_name,
#                                     df_source_id_col="source_id",
#                                     table_id_col="id",
#                                     target_details_col="target_details"
#                                 )
#                                 update_query = "update partner_provider_initial_sync_mappings set mapped_ids=%s where id=%s"
#                                 with common_utils_conn.cursor() as cur:
#                                     cur.execute(update_query, (json.dumps(mapping_dict), id))
#                                     common_utils_conn.commit()
#                             except Exception as e:
#                                 logging.error(f"Error in FK mapping or insert for table {table_name}: {e}")
#                                 continue

#                     except Exception as e:
#                         logging.error(f"Error processing where condition for mapping {id}, table {table_name}: {e}")
#                         continue

#             except Exception as e:
#                 logging.error(f"Error processing mapping row {idx}: {e}")
#                 continue

#         return True, None

#     except Exception as e:
#         logging.error(f"Fatal error in insert_service_providers: {e}")
#         return False, e

#     finally:
#         # ---------------- Cleanup ----------------
#         for conn_name, conn in {
#             "common_utils": common_utils_conn,
#             "source": source_conn,
#             "target": target_db_conn
#         }.items():
#             try:
#                 if conn:
#                     conn.close()
#                     logging.info(f"Closed {conn_name} connection")
#             except Exception as e:
#                 logging.warning(f"Error closing {conn_name} connection: {e}")

def log_audit(conn, partner_name, source_db, target_db, main_tenant_db, step, status, details=None):
    query = """
    INSERT INTO pbp_migration_history
        (partner_name, source_db, target_db, main_tenant_db, step, status, details, started_at)
    VALUES (%s, %s, %s, %s, %s, %s, %s, now())
    RETURNING id
    """
    with conn.cursor() as cur:
        cur.execute(query, (partner_name, source_db, target_db, main_tenant_db, step, status, json.dumps(details)))
        audit_id = cur.fetchone()[0]
        conn.commit()
    return audit_id

def update_audit(conn, audit_id, status, details=None):
    query = """
    UPDATE pbp_migration_history
    SET status = %s,
        details = %s,
        completed_at = now()
    WHERE id = %s
    """
    with conn.cursor() as cur:
        cur.execute(query, (status, json.dumps(details), audit_id))
        conn.commit()
def run_sql_file(connection, sql_file_path):
    """
    Executes SQL statements from a .sql file using a given database connection.

    Args:
        connection: psycopg2 connection object
        sql_file_path: str, path to the .sql file
    """
    try:
        with connection.cursor() as cursor:
            with open(sql_file_path, 'r') as file:
                sql_content = file.read()

            # Split statements by semicolon in case there are multiple queries
            statements = [stmt.strip() for stmt in sql_content.split(';') if stmt.strip()]

            for stmt in statements:
                cursor.execute(stmt)

            connection.commit()
            logging.info(f"Successfully executed {sql_file_path}")

    except Exception as e:
        connection.rollback()
        logging.info(f"Error executing {sql_file_path}: {e}")

def update_bulk_change_tables(source_db, target_db, source_db_host, target_db_host, target_db_tenant_id):
    """
    Updates bulk change related tables (bulk_change_popup_screens, sim_management_bulk_change_type_service_provider)
    by syncing data from source to target, transforming IDs and display names using mappings.
    Includes debug logs for selected and transformed data.
    """
    try:
        logging.info(f"Updating bulk change tables for {source_db} to {target_db} all inputs {source_db_host}, {target_db_host},{target_db_tenant_id} ")
        load_dotenv()
        host = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        common_utils_db = os.getenv('COMMON_UTILS_DB')

        # DB connections
        common_utils_conn = create_connection(db_type=db_type, host=host, db_name=common_utils_db,
                                              username=user, password=password, port=port)
        if not common_utils_conn:
            logging.info(f"[ERROR] Failed to connect to common_utils DB")
            return False, f"[ERROR] Failed to connect to common_utils DB"

        source_conn = create_connection(db_type, source_db_host, source_db, user, password, port)
        if not source_conn:
            logging.info(f"[ERROR] Failed to connect to source DB: {source_db}")
            return False, f"[ERROR] Failed to connect to source DB: {source_db}"

        target_conn = create_connection(db_type, target_db_host, target_db, user, password, port)
        if not target_conn:
            logging.info(f"[ERROR] Failed to connect to target DB: {target_db}")
            return False, f"[ERROR] Failed to connect to target DB: {target_db}"

        # Step 1: Get reference sync mapping details
        mapping_query = """
            SELECT table_name, fk_col_target_mapping, where_cond, select_query
            FROM partner_provider_reference_sync_mappings 
            WHERE table_name IN ('bulk_change_popup_screens','sim_management_bulk_change_type_service_provider');
        """
        mappings_df = execute_query_db(common_utils_conn, mapping_query)
        if mappings_df is None or mappings_df.empty:
            logging.info(f"[ERROR] No table configuration found in partner_provider_reference_sync_mappings")
            return False, "[ERROR] No table configuration found in partner_provider_reference_sync_mappings"

        # Step 2: Get ID mappings between source and target
        initial_sync_query = f"""
            SELECT table_name, mapped_ids
            FROM partner_provider_initial_sync_mappings
            WHERE partner_name = '{source_db}'
            AND target_db = '{target_db}'
            AND target_db_tenant_id = {target_db_tenant_id};
        """
        initial_sync_df = execute_query_db(common_utils_conn, initial_sync_query)
        if initial_sync_df is None or initial_sync_df.empty:
            logging.info(f"[ERROR] No mapping records found for source={source_db}, target={target_db}, tenant_id={target_db_tenant_id}")
            return False, "No mapping found for the given source/target configuration"

        # Build dict of table → {source_id: target_id}
        id_mappings = {}
        for _, row in initial_sync_df.iterrows():
            if row["mapped_ids"]:
                if isinstance(row["mapped_ids"], str):
                    # string type → load JSON
                    id_mappings[row["table_name"]] = json.loads(row["mapped_ids"])
                else:
                    # already a dict/jsonb type
                    id_mappings[row["table_name"]] = row["mapped_ids"]

        # Step 3: Process each mapping table
        for m in mappings_df.to_dict(orient="records"):
            table_name = m["table_name"]
            fk_col_target_mapping = m["fk_col_target_mapping"]
            select_query = m["select_query"]
            where_cond = m["where_cond"]

            # Build WHERE condition
            where_parts = []
            for cond in where_cond:
                for fk, details in cond.items():
                    src_table = details["<where_condition>"]["table_name"]
                    src_ids = list(id_mappings.get(src_table, {}).keys())
                    if src_ids:
                        where_parts.append(f"{fk} IN ({','.join(map(str, src_ids))})")

            where_clause = " AND ".join(where_parts) if where_parts else "1=1"
            final_select_query = select_query.replace("<where_cond>", where_clause)
            logging.info(f"[INFO] Executing for table: {table_name}")
            logging.info(f"[INFO] Final Source Query: {final_select_query}")

            # Step 4: Fetch from source DB
            source_df = execute_query_db(source_conn, final_select_query)
            if source_df is None or source_df.empty:
                logging.info(f"[INFO] No data found in source for {table_name}")
                continue

            logging.info(f"[INFO] Fetched {len(source_df)} rows from source for table {table_name}")
            logging.info(f"[DEBUG] Sample source rows: {source_df.head(3).to_dict(orient='records')}")

            transformed_rows = []
            sp_cache = {}  # Cache display_name lookups

            # Step 5: Transform data
            for _, row in source_df.iterrows():
                transformed_row = row.to_dict()

                # Replace foreign keys
                for fk_col, map_info in fk_col_target_mapping.items():
                    map_table = map_info["where_row"]
                    fk_value = row[fk_col]
                    target_id = id_mappings.get(map_table, {}).get(str(fk_value)) or id_mappings.get(map_table, {}).get(fk_value)
                    if target_id:
                        transformed_row[fk_col] = target_id

                # Update service_provider name using target DB display_name
                if "service_provider" in transformed_row and transformed_row.get("service_provider_id"):
                    sp_id = transformed_row["service_provider_id"]
                    if sp_id not in sp_cache:
                        sp_query = f"SELECT display_name FROM serviceprovider WHERE id = {sp_id};"
                        sp_df = execute_query_db(target_conn, sp_query)
                        if sp_df is not None and not sp_df.empty:
                            sp_cache[sp_id] = sp_df["display_name"].iloc[0]
                    if sp_id in sp_cache:
                        transformed_row["service_provider"] = sp_cache[sp_id]

                transformed_rows.append(transformed_row)

            # Log transformed data before insert
            logging.info(f"[DEBUG] Transformed rows (sample): {transformed_rows[:3]}")
            logging.info(f"[INFO] Prepared {len(transformed_rows)} transformed rows for insertion into {table_name}")

            # Step 6: Insert into target DB

            if transformed_rows:
                # Remove 'id' column if present so DB will auto-generate
                for row in transformed_rows:
                    row.pop("id", None)

                cols = list(transformed_rows[0].keys())
                insert_query = sql.SQL("INSERT INTO {} ({}) VALUES %s").format(
                    sql.Identifier(table_name),
                    sql.SQL(", ").join(map(sql.Identifier, cols))
                )
                with target_conn.cursor() as cur:
                    execute_values(
                        cur,
                        insert_query.as_string(target_conn),
                        [tuple(row[c] for c in cols) for row in transformed_rows]
                    )
                    target_conn.commit()
                logging.info(f"[SUCCESS] Inserted {len(transformed_rows)} rows into {table_name}")

        return True, "Bulk change tables updated successfully."

    except Exception as e:
        logging.info(f"Error in update_bulk_change_tables {traceback.print_exc()}")
        error_msg=f"Error in update_bulk_change_tables {traceback.print_exc()}"
        return False, error_msg

# def service_provider_setup(source_db, partner_db_tenant_id, target_db, target_name, target_db_tenant_id, main_tenant_db, main_tenant_db_tenant_id):
def service_provider_setup(data):
    """
    High-level setup for service provider migration with audit logging.

    Steps:
    1. Create initial table mappings for new provider.
    2. Add source-target mapping columns.
    3. Clean and validate service providers in common_utils.
    4. Insert service providers into target DB.
    """

    audit_ids = {}  # keep track of audit records per step

    try:
        load_dotenv()
        logging.info(f"Service provider setup Input Data {data}")
        source_db = data.get("source_db")
        partner_db_tenant_id = data.get("partner_db_tenant_id")
        target_db = data.get("target_db")
        target_name = data.get("target_name")
        target_db_tenant_id = data.get("target_db_tenant_id")
        main_tenant_db = data.get("main_tenant_db")
        main_tenant_db_tenant_id = data.get("main_tenant_db_tenant_id")

        logging.info(
            f"Starting sync: source_db={source_db}, target_db={target_db}, target_name={target_name}"
        )

        host = os.getenv("PSQL_DB_HOST")
        port = os.getenv("PSQL_DB_PORT")
        user = os.getenv("PSQL_DB_USER")
        password = os.getenv("PSQL_DB_PASSWORD")
        common_utils_db = os.getenv("COMMON_UTILS_DB")
        db_type = os.getenv("PSQL_DB_TYPE")

        # Connect to common_utils DB (used for audit logging too)
        common_utils_conn = create_connection(
            db_type, host, common_utils_db, user, password, port
        )
        target_db_conn=create_connection(
            db_type, host, target_db, user, password, port
        )
        if not common_utils_conn:
            logging.error("Failed to connect to common_utils DB for audit logging")
            return False
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # ---------------- Step 1: Create mappings ----------------
        audit_ids["CREATE_MAPPINGS"] = log_audit(
            common_utils_conn,
            source_db,
            source_db,
            target_db,
            main_tenant_db,
            "CREATE_MAPPINGS",
            "STARTED",
        )

        mappings_status, error,source_db_host, target_db_host = create_table_mappings_for_new_provider(
            source_db,
            partner_db_tenant_id,
            target_db,
            target_name,
            target_db_tenant_id,
            main_tenant_db,
            main_tenant_db_tenant_id,
        )
        if not mappings_status:
            update_audit(
                common_utils_conn,
                audit_ids["CREATE_MAPPINGS"],
                "FAILED",
                {"error": str(error)},
            )
            return False
        update_audit(
            common_utils_conn,
            audit_ids["CREATE_MAPPINGS"],
            "SUCCESS",
            {"message": "Mappings created"},
        )
        if not source_db_host or not target_db_host:
            logging.error("Source or Target DB host information missing from mappings creation step")
            update_audit(
                common_utils_conn,
                audit_ids["CREATE_MAPPINGS"],
                "FAILED",
                {"error": "Source or Target DB host information missing from mappings creation step"},
            )
            return False

        # # ---------------- Step 2: Add mapping columns ----------------
        # audit_ids["ADD_COLUMNS"] = log_audit(
        #     common_utils_conn,
        #     source_db,
        #     source_db,
        #     target_db,
        #     main_tenant_db,
        #     "ADD_COLUMNS",
        #     "STARTED",
        # )

        # source_target_cols_status, error_cols = add_mapping_cols_to_source_target(
        #     source_db, main_tenant_db
        # )
        # if not source_target_cols_status:
        #     update_audit(
        #         common_utils_conn,
        #         audit_ids["ADD_COLUMNS"],
        #         "FAILED",
        #         {"error": str(error_cols)},
        #     )
        #     return False
        # update_audit(
        #     common_utils_conn,
        #     audit_ids["ADD_COLUMNS"],
        #     "SUCCESS",
        #     {"message": "Mapping columns added"},
        # )

        # ---------------- Step 3: Validate service providers ----------------
        audit_ids["VALIDATE_PROVIDERS"] = log_audit(
            common_utils_conn,
            source_db,
            source_db,
            target_db,
            main_tenant_db,
            "VALIDATE_PROVIDERS",
            "STARTED",
        )

        valid_serviceproviders_flag, sp_error = valid_service_providers(
            source_db, target_db,target_name,partner_db_tenant_id,target_db_tenant_id,
            main_tenant_db_tenant_id,source_db_host, target_db_host
        )
        if not valid_serviceproviders_flag:
            logging.info(f"valid valid_serviceproviders_flag is False, error is {sp_error}")
            update_audit(
                common_utils_conn,
                audit_ids["VALIDATE_PROVIDERS"],
                "FAILED",
                {"error": str(sp_error)},
            )
            return False
        update_audit(
            common_utils_conn,
            audit_ids["VALIDATE_PROVIDERS"],
            "SUCCESS",
            {"message": "Service providers validated"},
        )

        # ---------------- Step 4: Insert service providers ----------------
        audit_ids["INSERT_PROVIDERS"] = log_audit(
            common_utils_conn,
            source_db,
            source_db,
            target_db,
            main_tenant_db,
            "INSERT_PROVIDERS",
            "STARTED",
        )

        insert_providers_flag, insert_error = insert_service_providers(
            source_db, target_db,source_db_host, target_db_host,target_name,target_db_tenant_id,main_tenant_db_tenant_id
        )
        if not insert_providers_flag:
            update_audit(
                common_utils_conn,
                audit_ids["INSERT_PROVIDERS"],
                "FAILED",
                {"error": str(insert_error)},
            )
            return False
        update_audit(
            common_utils_conn,
            audit_ids["INSERT_PROVIDERS"],
            "SUCCESS",
            {"message": "Service providers inserted"},
        )
        ## running sql file
        # run_sql_file(target_db_conn,"addingconstraints.sql")
        #----------------------------------------------------------------
        logging.info(f"Updating bulk change tables with inputs source_db,target_db,source_db_host,target_db_host,target_db_tenant_id {source_db}, {target_db},{source_db_host},{target_db_host},{target_db_tenant_id}")
        audit_ids["UPDATE_BULK_CHANGE_TABLES"] = log_audit(
            common_utils_conn,
            source_db,
            source_db,
            target_db,
            main_tenant_db,
            "UPDATE_BULK_CHANGE_TABLES",
            "STARTED",
        )
        result_flag,message=update_bulk_change_tables(source_db,
                                                      target_db,
                                                      source_db_host,
                                                      target_db_host,
                                                      target_db_tenant_id
                                                    )
        if not result_flag:
            update_audit(
                common_utils_conn,
                audit_ids["UPDATE_BULK_CHANGE_TABLES"],
                "FAILED",
                {"error": str(message)},
            )
            return False
        update_audit(
            common_utils_conn,
            audit_ids["UPDATE_BULK_CHANGE_TABLES"],
            "SUCCESS",
            {"message": "Service providers inserted"},
        )
        perc_update={"progress":50}
        #here update provider_detail_mapping table 'progress' column with 50
        logging.info(f"update partner_provider_detail_mappings {perc_update} for target {target_name}, source {source_db}")
        
        # common_utils_database.update_dict("partner_provider_detail_mappings",perc_update,{'target_name':target_name,'partner_db':source_db,'partner_db_tenant_id':partner_db_tenant_id,'target_db_tenant_id':target_db_tenant_id})
        update_sql = """
                UPDATE partner_provider_detail_mappings
                SET progress = %s
                WHERE target_name = %s
                  AND partner_db = %s
                  AND partner_db_tenant_id = %s
                  AND target_db_tenant_id = %s;
            """

        params = (
                50,
                target_name,
                source_db,
                partner_db_tenant_id,
                target_db_tenant_id
            )

        with common_utils_conn.cursor() as cur:
            cur.execute(update_sql, params)
            common_utils_conn.commit()

        logging.info(
            f"Updated progress=50 in partner_provider_detail_mappings for target_name={target_name}, source_db={source_db}"
        )
        return True

    except Exception as e:
        logging.error(f"Error in service_provider_setup: {e}")
        # mark any open step as failed if possible
        for step, aid in audit_ids.items():
            update_audit(
                common_utils_conn,
                aid,
                "FAILED",
                {"error": str(e), "step": step},
            )
        return False

    finally:
        try:
            if common_utils_conn:
                common_utils_conn.close()
        except Exception as e:
            logging.warning(f"Error closing common_utils connection: {e}")

def get_tenant_host_by_db_name(conn, db_name):
    """
    Given a connection to common_utils and a db_name, get the associated hostname from tenant.db_config.
    Returns the hostname if found, else None.
    """
    try:
        with conn.cursor() as cur:
            query = """
                SELECT db_config
                FROM tenant
                WHERE db_name = %s
                LIMIT 1
            """
            cur.execute(query, (db_name,))
            row = cur.fetchone()
            if not row or not row[0]:
                return None
            db_config = row[0]
            return db_config.get('hostname')
    except Exception as e:
        print(f"Failed to fetch tenant host for db_name={db_name}: {e}")
        return None

def update_service_provider_name(service_provider_id, new_display_name, target_db):
    """
    Updates service provider display name across all mapped tables in target_db.
    Steps:
      1. Connect to common_utils DB
      2. Fetch mappings from serviceprovider_update_mapping
      3. Connect to target_db
      4. For each mapping:
         - Compare service_provider_id_col with given service_provider_id
         - Update all service_provider_name_col(s) with new_display_name
    """
    audit_id = None
    try:
        # Load env vars
        load_dotenv()
        host = os.getenv("PSQL_DB_HOST")
        port = os.getenv("PSQL_DB_PORT")
        user = os.getenv("PSQL_DB_USER")
        password = os.getenv("PSQL_DB_PASSWORD")
        common_utils_db = os.getenv("COMMON_UTILS_DB")
        db_type = os.getenv("PSQL_DB_TYPE")

        # Connect to common_utils
        logging.info(f"Connecting to common_utils DB: {common_utils_db}")
        common_utils_conn = create_connection(db_type, host, common_utils_db, user, password, port)
        if not common_utils_conn:
            raise Exception(f"Connection to common_utils_db {common_utils_db} failed")

        # Log audit start
        audit_id = log_audit(
            common_utils_conn,
            "SERVICE_PROVIDER_UPDATE",
            target_db,
            target_db,
            target_db,
            "UPDATE_SERVICE_PROVIDER_NAME",
            "STARTED",
            {
                "service_provider_id": service_provider_id,
                "new_display_name": new_display_name,
                "target_db": target_db
            }
        )

        # Fetch mappings
        select_query = """
            SELECT table_name, service_provider_id_col, service_provider_name_col
            FROM serviceprovider_update_mapping
            ORDER BY id ASC
        """
        provider_mappings = execute_query_db(common_utils_conn, select_query)
        logging.info(f"Fetched {len(provider_mappings)} mappings from serviceprovider_update_mapping")

        target_db_host=get_tenant_host_by_db_name(common_utils_conn,target_db)
        if target_db_host is None:
            print(f"[ERROR] Could not find host for target db {target_db}")
            error_msg=f"[ERROR] Could not find host for target db {target_db}"
            return False, error_msg

        # Connect to target DB
        logging.info(f"Connecting to target DB: {target_db}")
        target_db_conn = create_connection(db_type, target_db_host, target_db, user, password, port)
        if not target_db_conn:
            raise Exception(f"Connection to target_db {target_db} failed")

        updated_tables = []

        # Iterate over mappings
        with target_db_conn.cursor() as cur:
            for mapping in provider_mappings:
                table_name = mapping["table_name"]
                id_col = mapping["service_provider_id_col"]
                name_cols = mapping["service_provider_name_col"].split(",")

                # # Build SET clause dynamically
                # set_clauses = [sql.SQL("{} = %s").format(sql.Identifier(col.strip())) for col in name_cols]
                # update_sql = sql.SQL("UPDATE {table} SET {sets} WHERE {id_col} = %s").format(
                #     table=sql.Identifier(table_name),
                #     sets=sql.SQL(", ").join(set_clauses),
                #     id_col=sql.Identifier(id_col)
                # )

                # params = [new_display_name] * len(name_cols) + [service_provider_id]

                # Ensure name_cols is a list
                if isinstance(name_cols, str):
                    name_cols = [name_cols]

                set_clauses = [
                    sql.SQL("{} = %s").format(sql.Identifier(col.strip()))
                    for col in name_cols
                ]

                update_sql = sql.SQL("UPDATE {table} SET {sets} WHERE {id_col} = %s").format(
                    table=sql.Identifier(table_name),
                    sets=sql.SQL(", ").join(set_clauses),
                    id_col=sql.Identifier(id_col)
                )

                params = [new_display_name] * len(name_cols) + [service_provider_id]


                try:
                    cur.execute(update_sql, params)
                    if cur.rowcount > 0:
                        updated_tables.append(table_name)
                        logging.info(f"Updated {cur.rowcount} rows in {table_name}.{name_cols}")
                except Exception as e:
                    logging.info(f"Failed to update {table_name}: {e}")
                    target_db_conn.rollback()
                    continue  # go to next table

            target_db_conn.commit()

        logging.info(f"Update complete. Modified tables: {updated_tables}")
        
        update_audit(
            common_utils_conn, 
            audit_id, 
            "SUCCESS", 
            {
                "updated_tables": updated_tables,
                "total_tables_updated": len(updated_tables),
                "service_provider_id": service_provider_id,
                "new_display_name": new_display_name
            }
        )

        return True, updated_tables

    except Exception as e:
        logging.info(f"Error in update_service_provider_name: {e}")
        
        if audit_id and 'common_utils_conn' in locals() and common_utils_conn:
            update_audit(
                common_utils_conn, 
                audit_id, 
                "FAILED", 
                {"error": str(e), "service_provider_id": service_provider_id}
            )
        
        return False, str(e)

    finally:
        try:
            if common_utils_conn:
                common_utils_conn.close()
        except:
            pass
        try:
            if target_db_conn:
                target_db_conn.close()
        except:
            pass



#DB Code ends here-----------------


def get_partner_to_provider_list_view_data(data):
    """
    Fetches a paginated list of active customers from the tenant database with applied user-level filters.

    Args:
        data (dict): Dictionary containing request data including:
            - role_name (str): The role of the user.
            - tenant_name (str): Name of the tenant.
            - module_name (str): Name of the requesting module.
            - db_name (str): Database name to query from.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status.
            - message (str): Response message.
            - data (list): List of customer records.
            - tenant_name (dict): Parent tenant info.
            - sub_tenant (dict): Subtenant details.
            - headers_map (dict): Header mapping for the frontend.
            - pages (dict): Pagination metadata with total count.
    """
    logging.info(f"### Starting get_partner_to_provider_list_view_data function with data: {data}")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    module_name = data.get("module_name", "")
    target_tenant_name = data.get("target_tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    foundation_account_billing_account_mapping={}
    # Database Connection
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(tenant_database, **db_config)
    except Exception as e:
        logging.exception("###get_partner_to_provider_list_view_data Failed to connect to common utils database")
        return {
            "flag": False,
            "message": "Database connection error",
            "data": [],
            "tenant_name": [],
            "headers_map": {},
            "pages": {},
        }
    role_name = data.get("role_name", "")
    # Initialize data_list to hold customer data
    # total_resellers = 0
    return_json_data = {}
    try:
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)
        # limit = 100  # Set the limit to 100
        if tenant_name=='Altaworx Test':
            tenant_id=1
        else:
            # Fetch tenant ID
            tenant_id=common_utils_database.get_data('tenant',{'tenant_name':tenant_name},['id'])['id'].to_list()[0]
            logging.info(f"###get_partner_to_provider_list_view_data Tenant ID fetched: {tenant_id}")
        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(common_utils_database,data)
        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            # Construct the ORDER BY clause
            order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
        else:
            # If users is None or empty, we skip the WHERE clause entirely
            order_condition = f"ORDER BY id DESC LIMIT 100 OFFSET {start_page}"
        query = f"""
            SELECT * FROM public.partner_to_provider where source_tenant_name='{tenant_name}' and target_tenant_name='{target_tenant_name}'
                {order_condition}
        """
        count_query = f"""
            SELECT COUNT(*) as total_count
            FROM public.partner_to_provider
        """
        # Execute the query using the existing execute_query function
        result = common_utils_database.execute_query(query, True)
        total_count_result = common_utils_database.execute_query(count_query, True)
        total_count = (
            total_count_result["total_count"].iloc[0]
            if not total_count_result.empty
            else 0
        )
        pages = {"start": start_page, "end": end_page, "total": int(total_count)}
        ##tenant details
        tenant_details = common_utils_database.get_data(
            "tenant", {"is_active": True}, ["id", "tenant_name","db_name"])
        if not tenant_details.empty:
            tenant_details = tenant_details.to_dict(orient="records")
        else:
            tenant_details = []
        ##service_provider details
        service_provider_details = database.get_data('serviceprovider', {'is_active': True}, ['id', 'service_provider_name'],order={"service_provider_name":"asc"})
        if not service_provider_details.empty:
            service_provider_details = service_provider_details.to_dict(orient="records")
        else:
            service_provider_details = []
        customer_groups=database.get_data('customergroups', {'is_active': True,"tenant_name":tenant_name}, ['name'],order={"name":"asc"})
        if customer_groups.empty:
            customer_groups = []
        else:
            customer_groups=customer_groups['name'].to_list()
        logging.info("###get_partner_to_provider_list_view_data Fetched customer groups")
        ##foundation account and billing account mapping just to fetch the mappings instead of fetching the whole data
        foundation_account_billing_account_map_query = f'''
        SELECT distinct
        foundation_account_number,
        billing_account_number
        FROM sim_management_inventory 
        WHERE tenant_id={tenant_id} AND is_active=True
        ORDER BY foundation_account_number asc, billing_account_number asc;
        '''

        foundation_account_billing_account_dataframe = database.execute_query(foundation_account_billing_account_map_query, True)

        if not foundation_account_billing_account_dataframe.empty:
            foundation_account_billing_account_mapping = foundation_account_billing_account_dataframe.groupby('foundation_account_number')['billing_account_number'].apply(list).to_dict()
            # Sort the dictionary by keys (foundation_account_number)
            foundation_account_billing_account_mapping = dict(sorted(foundation_account_billing_account_mapping.items()))
        else:
            foundation_account_billing_account_mapping = {}
        ##source tenant mapping
        source_tenant_mapping=common_utils_database.get_data('partner_provider_detail_mappings', {'is_active': True,'target_name':tenant_name}, ['partner_name','target_name','customer_group','tagged_fan','tagged_ban'])
        if not source_tenant_mapping.empty:
            source_tenant_mapping=source_tenant_mapping.to_dict(orient="records")
        else:
            source_tenant_mapping=[]
        ##target tenant mapping
        target_tenant_mapping=common_utils_database.get_data('partner_provider_detail_mappings', {'is_active': True,'partner_name':tenant_name}, ['partner_name','target_name','customer_group','tagged_fan','tagged_ban'])
        if not target_tenant_mapping.empty:
            target_tenant_mapping=target_tenant_mapping.to_dict(orient="records")
        else:
            target_tenant_mapping=[]
        logging.info("###get_partner_to_provider_list_view_data Fetched source and target tenant mappings")

        # Get headers mapping
        headers_map = get_headers_mapping(
            database,
            ["Partners Becoming Provider"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            common_utils_database,
        )
        # Final result
        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)

            logging.info("###get_partner_to_provider_list_view_data Data fetched for partners becoming provider")

            # Prepare final response
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "tenant_details":tenant_details,
                    "service_provider_details":service_provider_details,
                    "foundation_account_billing_account_mapping":foundation_account_billing_account_mapping,
                    "headers_map": headers_map,
                    "pages": pages,
                    "customer_groups":customer_groups,
                    "source_tenant_mapping":source_tenant_mapping,
                    "target_tenant_mapping":target_tenant_mapping
                }
            )
            #return return_json_data
        else:
            return_json_data.update(
                {"flag": True, "data": [], "message": "No data found!",
                    "headers_map": headers_map}
            )
            logging.warning("###get_partner_to_provider_list_view_data No data found for  partners becoming provider")
            #return return_json_data
        logging.info("###get_partner_to_provider_list_view_data Returning data response")
        return_json_data.update(
            {
                "tenant_details":tenant_details,
                "service_provider_details":service_provider_details,
                "foundation_account_billing_account_mapping":foundation_account_billing_account_mapping,
                "headers_map": headers_map,
                "pages": pages,
                "customer_groups":customer_groups,
                "source_tenant_mapping":source_tenant_mapping,
                "target_tenant_mapping":target_tenant_mapping,
                "message":"fecthed successfully now"
            }
        )
        try:
            audit_data_user_actions = {
                "service_name": "get_partner_to_provider_list_view_data",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully retrieved Partner to Provider list view data",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return return_json_data

    except Exception as e:
        logging.exception("### An error occurred in get_partner_to_provider_list_view_data")
        message = f"Failed to fetch Partner becoming provider for module: {module_name}"
        error_type = str(type(e).__name__)
        # Error Management
        error_data = {
            "service_name": "get_partner_to_provider_list_view_data",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "Partner Becoming Provider",
        }
        headers_map = get_headers_mapping(
            database,
            ["Partners Becoming Provider"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            common_utils_database,
        )
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, ["Partner "], role_name, "", "", "", "", data, database
        )
        response={
                        "flag": True,
                        "data": [],
                        "message": "No data found for Partner to Provider Data!",
                        "tenant_name": [],
                        "headers_map": headers_map,
                    }
        return response



def partner_to_provider_actions(data):
    """
    Processes customer rate plan data by creating or updating rate plans in the database.
    Validates input, handles errors, and logs actions.

    Parameters:
        data (dict): A dictionary containing the rate plan data to process, including:
            - 'Partner' (str): The partner name.
            - 'session_id' (str): The session ID associated with the request.
            - 'username' (str): The username of the requester.
            - 'rate_plan_data' (dict): The rate plan data containing the fields to update.
            - 'action' (str): Action to perform, either 'create' or 'update'.
            - 'table_name' (str): The database table for storing rate plans.
            - 'db_name' (str): The tenant database name.

    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
    """
    logging.info(f"### starting partner_to_provider_actions function with data: {data}")
    ##fetching the parameters
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    session_id= data.get("sessionID", "")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    changed_data=data.get('changed_data',{})
    new_data=data.get('new_data',{})
    tenant_name = data.get("tenant_name", "")
    target_db_name=data.get("target_db_name","")
    target_tenant_name=data.get("target_tenant_name","")
    modified_by = data.get("firstLastName", "")
    source_tenant_name = data.get("source_tenant_name", "")
    created_by = data.get("username", "")
    tagged_service_providers=data.get("tagged_service_providers","")
    try:
        logging.info("### Processing partner_to_provider_actions")
        db_data=common_utils_database.get_data('tenant',{'tenant_name':target_tenant_name},['db_config']).to_dict(orient='records')
        db_data_config = db_data[0].get("db_config", {})

        db_config_data = {
        "host": db_data_config.get("hostname") or db_data_config.get("host"),
        "port": db_data_config.get("port"),
        "user": db_data_config.get("user"),
        "password": db_data_config.get("password"),
        "multi_schema":False
        }
        target_database = DB(target_db_name, **db_config_data)
        if changed_data:
            if isinstance(changed_data, dict):
                changed_data = [changed_data]

            # Validate each record
            to_update = []
            for record in changed_data:
                if "id" not in record:
                    response = {"flag": False, "message": "Each record must contain an 'id' field."}
                    logging.error("###partner_to_provider_actions bulk_update_role_data Missing 'id' in record.")
                    return response
                # Extract id and prepare update data
                record_id = record["id"]
                update_data = {k: v for k, v in record.items() if k != "id"}
                to_update.append({"id": record_id, **update_data})
             
            provider_names = [
                    item["service_provider_display_name"].strip()
                    for item in changed_data
                    if isinstance(item, dict) and item.get("service_provider_display_name")
                ]
            provider_records = target_database.get_data(
                "serviceprovider",
                {"is_active": True, "service_provider_name": provider_names},
                ["id", "service_provider_name"]
            )
            if isinstance(provider_records, pd.DataFrame):
                provider_records = provider_records.to_dict(orient="records")


            # Extract provider names that already exist
            existing_providers = {row["service_provider_name"] for row in provider_records}
            # Find duplicates
            duplicates = [name for name in provider_names if name in existing_providers]

            # If duplicates exist, return an error message
            if duplicates:
                return {
                    "flag": False,
                    "error_type": "Warning",
                    "message": f"These service providers already exist: {', '.join(duplicates)}"
                }


            # Call db_utils bulk_update_data
            response_flag = common_utils_database.bulk_update_data(
                table_name='partner_to_provider',
                data_list=to_update,
                search_column="id",
            )
            logging.info(f"response_flag : {response_flag} and updated data is length {len(to_update)}")
        if new_data:
            #cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            provider_names = [
                    item["service_provider_display_name"].strip()
                    for item in new_data
                    if isinstance(item, dict) and item.get("service_provider_display_name")
                ]
            provider_records = target_database.get_data(
                "serviceprovider",
                {"is_active": True, "service_provider_name": provider_names},
                ["id", "service_provider_name"]
            )
            if isinstance(provider_records, pd.DataFrame):
                provider_records = provider_records.to_dict(orient="records")

            # Extract provider names that already exist
            existing_providers = {row["service_provider_name"] for row in provider_records}
            # Find duplicates
            duplicates = [name for name in provider_names if name in existing_providers]

            # If duplicates exist, return an error message
            if duplicates:
                return {
                    "flag": False,
                    "error_type": "Warning",
                    "message": f"These service providers already exist: {', '.join(duplicates)}"
                }
            logging.info(f"###partner_to_provider_actions Partner to Provider data to be created: {new_data}")
            insert_id = common_utils_database.insert_data(new_data, "partner_to_provider")
            logging.info(f"###partner_to_provider_actions Partner to Provider data created successfully with ID: {insert_id}")
        if tagged_service_providers and not new_data and not changed_data:
            logging.info("###partner_to_provider_actions Processing tagged_service_providers")
            provider_names = [
                value.strip()
                for value in tagged_service_providers.values()
                if isinstance(value, str) and value.strip()
            ]
            #checking existing service providers
            provider_records = target_database.get_data(
                "serviceprovider",
                {
                    "is_active": True,
                    "service_provider_name": provider_names
                },
                ["id", "service_provider_name"]
            )

            # Normalize DB response
            if isinstance(provider_records, pd.DataFrame):
                provider_records = provider_records.to_dict(orient="records")
            elif not provider_records:
                provider_records = []

            existing_providers = {
                row["service_provider_name"].strip()
                for row in provider_records
                if isinstance(row, dict) and row.get("service_provider_name")
            }

            input_providers = set(provider_names)
            duplicates = sorted(existing_providers & input_providers)
            logging.info(f"###partner_to_provider_actions Existing service providers: {existing_providers} - duplicates {duplicates}")
            if duplicates:
                return {
                    "flag": False,
                    "error_type": "Warning",
                    "message": f"These service providers already exist: {', '.join(duplicates)}",
                }
            new_insert_data = []
            for key, value in tagged_service_providers.items():
                new_insert_data.append({
                    "target_tenant_name": target_tenant_name,
                    "service_provider_name": key,
                    "service_provider_display_name": value,
                    "modified_by": modified_by,
                    "source_tenant_name": source_tenant_name,
                    "created_by": created_by
                })
            logging.info(f"###partner_to_provider_actions Partner to Provider data to be created: {new_insert_data}")
            insert_id = common_utils_database.insert_data(new_insert_data, "partner_to_provider")
            logging.info(f"###partner_to_provider_actions Partner to Provider data created successfully with ID: {insert_id}")

        try:
            audit_data_user_actions = {
                "service_name": "partner_to_provider_actions",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully processed partner to provider action: edit and create data is {json.dumps(new_data)} and updated data is {json.dumps(changed_data)}",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        response={
            "flag": True,
            "message": f"Partner to Provider updated successfully",
            "status_code": 200,
        }
        return response

    except Exception as e:
        logging.error(f"###partner_to_provider_actions Exception in partner_to_provider_actions: {e}")
        message = "Failed to create or update customer in People module"

        common_utils_database.log_error_to_db(
            {
                "service_name": "partner_to_provider_actions",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"{message} for module: create data is {json.dumps(new_data)} and updated data is {json.dumps(changed_data)}",
                "module_name": "Partner Becoming Provider",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response= {
            "flag": True,
            "message": f"Error while updating the  partner provider actions : {e}",
        }
        return response

def get_target_partner_details(data):
    '''
    Fetches details of a target partner from the database based on the provided partner name.
    Parameters:
        data (dict): A dictionary containing the request data, including:
            - 'partner_name' (str): The name of the partner to fetch details for.
            - 'db_name' (str): The tenant database name.
    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
            - 'data' (dict): The details of the target partner if found, else empty.
    '''
    logging.info(f"### starting get_target_partner_details function with data: {data}")
    tenant_name = data.get("tenant_name", "")
    target_tenant_name=data.get("target_tenant_name", "")
    source_tenant_name=data.get("source_tenant_name", "")
    username = data.get("username", "")
    # Database Connection
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.exception("### Failed to connect to common utils database")
        return {
            "flag": False,
            "message": "Database connection error",
            "data": {},
        }
    logging.info(f"connected to database")
    try:
        target_partner_details_df=common_utils_database.get_data('partner_provider_detail_mappings',{"target_name":target_tenant_name,"partner_name":source_tenant_name},['customer_group','tagged_fan','tagged_ban','cg_tagged_ban','progress'])
        if not target_partner_details_df.empty:
            target_partner_details=target_partner_details_df.to_dict(orient="records")[0]
            response={
                "flag": True,
                "message": "Target partner details fetched successfully",
                "data": target_partner_details,
                "status_code": 200,
            }
        else:
            response={
                "flag": True,
                "message": "No details found for the target partner",
                "data": {},
            }
        ##auditing
        try:
            audit_data_user_actions = {
                "service_name": "get_target_partner_details",
                "created_by": username,
                "status": str(response['flag']),
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully fetched target partner details for: {target_tenant_name}",
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return response
    except Exception as e:
        logging.error(f"### Exception in get_target_partner_details: {e}")
        message = "Failed to fetch target partner details"
        common_utils_database.log_error_to_db(
            {
                "service_name": "get_target_partner_details",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"{message} for target partner: {target_tenant_name}",
                "module_name": "Partner Becoming Provider",
            },
            "error_log_table",
        )
        response= {
            "flag": False,
            "message": f"Error fetching target partner details: {e}",
            "data": {},
        }
        return response

def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Description:
        This function fetches and organizes the field mappings and features for a list of modules
        based on user role, tenant, and other context data. It separates fields into general fields,
        popup fields, and table headers, and includes feature permissions per module.

    Args:
        tenant_database (str): Name of the tenant-specific database.
        module_list (list): List of module names to fetch headers and features for.
        tenant_id (int): Tenant ID (may be overwritten by data fetched inside the function).
        sub_parent_module (str): Name of the sub-parent module (not used inside currently).
        data (dict): Request-related data containing keys like 'username', 'tenant_name', etc.
        common_utils_database (DB): DB connection object to the common_utils database.

    Returns:
        dict: A dictionary where each key is a module name, and the value is a dictionary containing:
            - general_fields: List of fields not categorized as pop-up or table fields
            - pop_up: List of fields marked as pop-up fields
            - header_map: Dictionary of table fields with display name and order
            - module_features: List of feature permissions for the module and user role
    """
    ##Database connection
    ret_out = {}
    try:
        logging.info(f"### Module name is :{module_list} and role is :{role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.debug(f"### tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"### Getting exception at fetching tenant id : {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info("### Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name
                    )

            except Exception as e:
                logging.warning(f"### there is some error: {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning(f"### there is some error : {e}")

    return ret_out




def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database,role,parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Parameters:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """
    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.debug(f"### Raw user features fetched: {user_features_raw}")
    if not user_features_raw or user_features_raw[0] is None:
        query=f'''select module_features from role_module where role='{role}'
        '''
        user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string

    except Exception as e:
      logging.error(f"Exception occurred while getting features: {str(e)}")
      features={}


    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(
            features[0]
        )


    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module,features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info(f"### Retrieved features: {features_list}")


    # Return the list of features associated with the specified feature name
    return features_list
def post_with_retries(url, json, retries=1):
    '''
    main container caller function
    Args:
        url (str): The URL to send the POST request to.
        json (dict): The JSON data to include in the POST request.
        retries (int): Number of retry attempts in case of failure.
    '''
    delay = 1
    for attempt in range(3, retries + 1):
        try:
            resp = requests.post(url, json=json, timeout=60)
            if resp.status_code < 400:
                return resp.json()
        except requests.RequestException:
            pass  # ignore and retry

        logging.warning("Attempt %d failed; retrying in %ds", attempt, delay)
        time.sleep(delay + random.uniform(0, 0.5))
        delay *= 2
    logging.error("All %d attempts failed", retries)
    return None  # After all retries fail

def assign_partner_to_provider(data):
    """
    Assigns a partner to a provider by inserting a mapping record into the database.

    Parameters:
        data (dict): A dictionary containing the following keys:
            - 'partner_name' (str): The name of the partner.
            - 'provider_name' (str): The name of the provider.
            - 'created_by' (str): The username of the person creating the mapping.
            - 'db_name' (str): The tenant database name.
            - 'tenant_name' (str): The name of the tenant.
            - 'session_id' (str): The session ID associated with the request.
            - 'request_received_at' (str): Timestamp when the request was received.
    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
    """
    logging.info(f"### starting assign_partner_to_provider function with data: {data}")
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    session_id= data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    partner_name=data.get('partner_name','')
    access_token=data.get('access_token','')

    provider_name=data.get('provider_name','')
    action=data.get('action','create')
    partner_to_provider_data=data.get('partner_to_provider_data',{})
    source_db = partner_to_provider_data.get("partner_db")
    partner_db_tenant_id = partner_to_provider_data.get("partner_db_tenant_id")
    target_db = partner_to_provider_data.get("target_db")
    target_name = partner_to_provider_data.get("target_name")
    target_db_tenant_id = partner_to_provider_data.get("target_db_tenant_id")

    partner_to_provider_db_dict = {
        "source_db": source_db,
        "partner_db_tenant_id": partner_db_tenant_id,
        "target_db": target_db,
        "target_name": target_name,
        "target_db_tenant_id": target_db_tenant_id,
    }
    # Database Connection
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(tenant_database, **db_config)
    except Exception as e:
        logging.exception("###assign_partner_to_provider Failed to connect to common utils database")
        return {
            "flag": False,
            "message": "Database connection error",
        }
    if tenant_name=='Altaworx Test':
        tenant_id=1
    else:
        tenant_id=common_utils_database.get_data('tenant', {'tenant_name': tenant_name}, ['id'])['id'].to_list()[0]
    try:
        partner_to_provider_data = {k: v for k, v in partner_to_provider_data.items() if v != ''}
        target_name=partner_to_provider_data.get("target_name",None)
        if action=='update':
            ##tenant database connection
            tenant_database = data.get("db_name", "")
            database = DB(tenant_database, **db_config)
            target_tenant_name=data.get('target_name','')
            source_partner_name=data.get('partner_name','')
            partner_to_provider_data["progress"] = 30
            logging.info(f"###assign_partner_to_provider Updating partner to provider mapping for target tenant: {target_tenant_name} and source partner: {source_partner_name} with data: {partner_to_provider_data}")
            for key, value in partner_to_provider_data.items():
                if isinstance(value, (list, dict)):
                    partner_to_provider_data[key] = json.dumps(value)
            logging.info(f"###assign_partner_to_provider Mapped customer group details to partner to provider data {partner_to_provider_data}")
            common_utils_database.update_dict("partner_provider_detail_mappings", partner_to_provider_data,{'target_name':target_tenant_name,"partner_name":source_partner_name})
            logging.info(f"###assign_partner_to_provider Partner to Provider mapping updated successfully for target tenant: {target_tenant_name} and source partner: {source_partner_name}")
            ##calling update sync function here
            logging.info(f"###assign_partner_to_provider Calling DB funtion here ---")
            service_provider_updates = data.get("updated_provider_display_names", {})
            target_database = data.get("target_db",None)
            update_service_providers_response=update_display_names_for_service_providers(service_provider_updates, target_database,database,common_utils_database,request_received_at,username,tenant_name)
            logging.info(f"###assign_partner_to_provider update_display_names_for_service_providers function executed with response: {update_service_providers_response}")
            response={
                "flag": True,"message": "Partner to Provider mapping updated successfully"}
        else:
            logging.info(f"###assign_partner_to_provider Creating new partner to provider mapping with data: {partner_to_provider_data}")
            partner_provider_detail_mappings_data=common_utils_database.get_data('partner_provider_detail_mappings',{'target_name':target_name,'partner_name':partner_name},['id'])
            if not partner_provider_detail_mappings_data.empty:
                response={
                    "flag": False,
                    "message": f"Mapping already exists for partner: {partner_name} and target: {target_name}",
                    "error_type":"Warning"
                }
                try:
                    audit_data_user_actions = {
                        "service_name": "assign_partner_to_provider",
                        "created_by": username,
                        "status": str(response['flag']),
                        "session_id": session_id,
                        "tenant_name": tenant_name,
                        "module_name": "Partner Becoming Provider",
                        "comments": f"Failed to create mapping as it already exists for partner: {partner_name} and target: {target_name}",
                        "request_received_at": request_received_at,
                    }

                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### Exception is {e}")
                return response
            if target_name:
                params=[target_name]
                target_id='''
                        SELECT
                        child.tenant_name      AS tenant_name,
                        parent.tenant_name     AS parent_tenant_name,
                        parent.db_name     AS parent_db_name,
                        parent.id as parent_tenant_id
                        FROM tenant AS child
                        LEFT JOIN tenant AS parent
                        ON child.parent_tenant_id = parent.id
                        WHERE child.tenant_name=%s  and child.parent_tenant_id is not null
                '''
                mediator_dataframe=common_utils_database.execute_query(target_id,params=params)
                if not mediator_dataframe.empty:
                    mediator_details=mediator_dataframe.to_dict(orient="records")[0]
                    partner_to_provider_data.update({
                        "mediator_db_tenant_id":mediator_details['parent_tenant_id'],
                        "mediator_name":mediator_details['parent_tenant_name'],
                        "mediator_db":mediator_details['parent_db_name'],
                    })
                    logging.info(f"###assign_partner_to_provider Mediator details fetched: {mediator_details}")
            customer_group=partner_to_provider_data.get('customer_group','')
            if customer_group:
                # 1. Get full record of the customer group
                customer_group_df = database.get_data(
                    'customergroups',
                    {'name': customer_group, 'tenant_name': tenant_name},
                    [
                        'id',
                        'billing_account_number',
                        'rate_plan_name',
                        'customer_names',
                        'feature_codes'
                    ]
                )

                if not customer_group_df.empty:
                    # Map the fields from the first matching group
                    row = customer_group_df.iloc[0]
                    logging.info(f"row data is {row}")
                    ##parsing the json fields
                    billing_account_number = row['billing_account_number']
                    rate_plan_name_str = row['rate_plan_name']
                    feature_codes_str = row['feature_codes']
                    customer_names_str = row['customer_names']
                    notification_rules_str=row.get('notification_rules','')
                    # Parse customer_names
                    try:
                        customer_names = json.loads(customer_names_str)
                    except Exception as e:
                        logging.exception(f"### Exception parsing customer_names: {e}")
                        customer_names = []   # or None

                    # Parse rate_plan_names
                    try:
                        rate_plan_names = json.loads(rate_plan_name_str)
                    except Exception as e:
                        logging.exception(f"### Exception parsing rate_plan_names: {e}")
                        rate_plan_names = []  # or None

                    # Parse feature_codes
                    try:
                        feature_codes = json.loads(feature_codes_str)
                    except Exception as e:
                        logging.exception(f"### Exception parsing feature_codes: {e}")
                        feature_codes = []    # or None
                    # Parse notification_rules
                    try:
                        notification_rules = json.loads(notification_rules_str)
                    except Exception as e:
                        logging.exception(f"### Exception parsing feature_codes: {e}")
                        notification_rules = []    # or None
                    
                    ##fetching the ids from the names
                    customer_name_map = {}
                    rate_plan_names_map={}
                    feature_codes_map={}
                    notification_rules_map={}
                    ##fetching the ids from the names
                    if customer_names:
                        customers_df = database.get_data(
                            'customers',
                            {'customer_name': customer_names, 'is_active': True,'tenant_id':tenant_id},
                            ['id', 'customer_name']
                        )
                        # Build mapping name -> id
                        customer_name_map = dict(zip(customers_df['id'], customers_df['customer_name']))
                    if rate_plan_names:
                        rate_plans_df = database.get_data(
                            'customerrateplan',
                            {'rate_plan_name': rate_plan_names, 'is_active': True,'tenant_id':tenant_id},
                            ['id', 'rate_plan_name']
                        )
                        # Build mapping name -> id
                        rate_plan_names_map = dict(zip(rate_plans_df['id'], rate_plans_df['rate_plan_name']))
                    if feature_codes:
                        feature_codes_df = database.get_data(
                            'mobility_feature',
                            {'soc_code': feature_codes, 'is_active': True},
                            ['id', 'soc_code']
                        )
                        # Build mapping name -> id
                        feature_codes_map = dict(zip(feature_codes_df['id'], feature_codes_df['soc_code']))
                    if notification_rules:
                        notification_rules_df = database.get_data(
                            'rule_rule_definition',
                            {'name': notification_rules, 'is_active': True,'tenant_id':tenant_id},
                            ['id', 'name']
                        )
                        # Build mapping name -> id
                        notification_rules_map = dict(zip(notification_rules_df['id'], notification_rules_df['name']))
                    tagged_ban=None
                    ui_selected_billing_account_number=partner_to_provider_data.get('tagged_ban',[])
                    logging.info(f"###assign_partner_to_provider ui_selected_billing_account_number is {ui_selected_billing_account_number} and partner_to_provider_data :{partner_to_provider_data} and billing_account_number {billing_account_number}")
                    ##checking if the selected ban is in the customer group ban
                    if ui_selected_billing_account_number and billing_account_number:
                        if str(billing_account_number) in ui_selected_billing_account_number:
                            tagged_ban = ui_selected_billing_account_number
                            tagged_ban = json.dumps(tagged_ban)
                            partner_to_provider_data['cg_tagged_ban']=False
                            logging.info(f"###assign_partner_to_provider tagged_ban is {tagged_ban}")
                        else:
                            tagged_ban = ui_selected_billing_account_number + [str(billing_account_number)]
                            logging.info(f"###assign_partner_to_provider tagged_ban before json is {tagged_ban}")
                            tagged_ban = json.dumps(tagged_ban)
                            partner_to_provider_data['cg_tagged_ban']=True
                            logging.info(f"###assign_partner_to_provider tagged_ban in else condition {tagged_ban}")
                    elif billing_account_number:
                        tagged_ban = [str(billing_account_number)]
                        tagged_ban = json.dumps(tagged_ban)
                        partner_to_provider_data['cg_tagged_ban']=True
                        logging.info(f"###assign_partner_to_provider tagged_ban is {tagged_ban}")
                    else:
                        pass
                    if tagged_ban is not None:
                        partner_to_provider_data["tagged_ban"] = tagged_ban
                    ##updating the mapped fields to the main data
                    partner_to_provider_data.update({
                        "customer_names":customer_name_map,
                        "rate_plans":rate_plan_names_map,
                        "feature_codes":feature_codes_map,
                        "notification_rules":notification_rules_map,
                        })
            # Fields you want to json‐dump
            partner_to_provider_data["progress"] = 30
            logging.info(f"###assign_partner_to_provider Mapped customer groups of the  details to partner to provider data {partner_to_provider_data}")
            for key, value in partner_to_provider_data.items():
                if isinstance(value, (list, dict)):
                    partner_to_provider_data[key] = json.dumps(value)
            partner_to_provider_data.pop("db_config_details", None)
            if 'mediator_db' not in partner_to_provider_data and 'mediator_name' not in partner_to_provider_data and 'mediator_db_tenant_id' not in partner_to_provider_data:
                partner_to_provider_data.update({
                    'mediator_db': partner_to_provider_data.get('target_db', ""),
                    'mediator_name': partner_to_provider_data.get('target_name', ""),
                    'mediator_db_tenant_id': partner_to_provider_data.get('target_db_tenant_id', "")
                })
            ##rate plans mapping according to the selected data
            try:
                rate_plan_names_map=fetch_customer_rate_plan_map(database, partner_to_provider_data)
                partner_to_provider_data['rate_plans']=json.dumps(rate_plan_names_map)
                logging.info(f"###assign_partner_to_provider partner to provider data is {partner_to_provider_data}")
            except Exception as e:
                logging.error(
                        f"### Unable to update the db selected filters plans"
                    )
            logging.info(f"###assign_partner_to_provider Mapped customer group details to partner to provider data {partner_to_provider_data}")
            insert_id = common_utils_database.insert_data(partner_to_provider_data, "partner_provider_detail_mappings")
            logging.info(f"###assign_partner_to_provider Partner to Provider mapping created successfully with ID: {insert_id}")
            #calling db funtion here to setup the service provider setup
            logging.info(f"###assign_partner_to_provider Calling DB funtion here ---")
            partner_to_provider_db_dict.update({
                "main_tenant_db": partner_to_provider_data.get("mediator_db", "") or partner_to_provider_data.get("target_db", ""),
                "main_tenant_db_tenant_id":  partner_to_provider_data.get("mediator_db_tenant_id", "") or partner_to_provider_data.get("target_db_tenant_id", ""),
            })
            logging.info(f"###assign_partner_to_provider partner_to_provider_db_dict is {partner_to_provider_db_dict}")
            db_flag=service_provider_setup(partner_to_provider_db_dict)
            logging.info(f"###assign_partner_to_provider service_provider_setup function executed with flag: {db_flag}")
            ##Data reflection in the provider modules
            #partner_becoming_provider_url = os.getenv("PARTNERBECOMINGPROVIDERURL", " ")
            partner_becoming_provider_url = f"http://54.152.69.196:5002/pbp_initial_sync"
            api_payload = {
                    
                        "data": {
                        "path": "/pbp_initial_sync",
                        "access_token":access_token,
                        "source_db": partner_to_provider_data.get("partner_db",""),
                        "partner_db_tenant_id": partner_to_provider_data.get("partner_db_tenant_id",""),
                        "target_db": partner_to_provider_data.get("target_db",""),
                        "target_name": partner_to_provider_data.get("target_name",""),
                        "target_db_tenant_id":partner_to_provider_data.get("target_db_tenant_id",""),
                        "main_tenant_db":partner_to_provider_data.get("mediator_db",""),
                        "main_tenant_db_tenant_id":partner_to_provider_data.get("mediator_db_tenant_id",""),
                        }
                    }
            try:
                logging.info(f"###assign_partner_to_provider API call payload: {api_payload}")
                logging.info(f"###assign_partner_to_provider API call url: {partner_becoming_provider_url}")
                
                response = requests.post(partner_becoming_provider_url, json=api_payload)
                if response.status_code == 200:
                    # Log the message with the timestamp
                    logging.info("###assign_partner_to_provider API call successful.response: %s", response.json())
                else:
                    logging.error(
                        f"### API call failed with status  code: {response.status_code} and response: {response.text}"
                    )
            except Exception as e:
                logging.error(f"### Error making API call: {e}")
            response={
                "flag": True,
                "message": "Partner to Provider mapping created successfully",
            }

        try:
            audit_data_user_actions = {
                "service_name": "assign_partner_to_provider",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully assigned partner {partner_name} to provider {provider_name} and data is {json.dumps(partner_to_provider_data)}",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return response
    except Exception as e:
        logging.error(f"### Exception in assign_partner_to_provider: {e}")
        message = "Failed to assign partner to provider"
        common_utils_database.log_error_to_db(
            {
                "service_name": "assign_partner_to_provider",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"{message} for partner: {partner_name} and provider: {provider_name}",
                "module_name": "Partner Becoming Provider",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response= {"flag": False,
            "message": f"Error assigning partner to provider: {e}",
        }
        return response


def fetch_customer_rate_plan_map(database, data):
    """
    Returns a map of:
    customer_rate_plan_id -> customer_rate_plan_name

    - Uses customer_names
    - Uses service_providers (keys)
    - M2M: filtered by dt_id + service providers
    - Mobility: filtered by mdt_id + billing_account_number / foundation_account_number (only if present)
    """

    logging.info(f"### fetch_customer_rate_plan_map: Started:{data}")
    try:
        # -------------------------------
        # 1. Parse inputs
        # -------------------------------
        customer_names_map = json.loads(data.get("customer_names", "[]"))
        tagged_ban = json.loads(data.get("tagged_ban", "[]"))
        foundation_accounts = json.loads(data.get("tagged_fan", "[]"))
        service_providers_map = json.loads(data.get("tagged_service_providers", "{}"))
        rate_plans = json.loads(data.get("rate_plans", "{}"))

        tenant_id = data.get("partner_db_tenant_id")

        if not customer_names_map:
            logging.info("### No customer names found")
            return {}

        customer_names = list(set(customer_names_map.values()))
        service_providers = list(set(service_providers_map.keys()))

        logging.info("###fetch_customer_rate_plan_map Customers: %s", customer_names)
        logging.info("###fetch_customer_rate_plan_map Service Providers: %s", service_providers)
        logging.info("###fetch_customer_rate_plan_map Billing Accounts: %s", tagged_ban)
        logging.info("###fetch_customer_rate_plan_map Foundation Accounts: %s", foundation_accounts)

        # -------------------------------
        # 2. Build SQL IN clauses
        # -------------------------------
        customer_names_sql = ", ".join(f"'{name}'" for name in customer_names)

        service_providers_sql = (
            ", ".join(f"'{sp}'" for sp in service_providers)
            if service_providers
            else None
        )

        billing_account_sql = (
            ", ".join(f"'{ban}'" for ban in tagged_ban) if tagged_ban else None
        )

        foundation_account_sql = (
            ", ".join(f"'{fan}'" for fan in foundation_accounts)
            if foundation_accounts
            else None
        )

        # -------------------------------
        # 3. M2M Query (dt_id)
        # -------------------------------
        m2m_where = [
            f"customer_name IN ({customer_names_sql})",
            f"tenant_id = {tenant_id}",
            "dt_id IS NOT NULL",
        ]

        if service_providers_sql:
            m2m_where.append(
                f"service_provider_display_name IN ({service_providers_sql})"
            )

        m2m_query = f"""
            SELECT DISTINCT
                customer_rate_plan_id,
                customer_rate_plan_name
            FROM public.sim_management_inventory
            WHERE {' AND '.join(m2m_where)}
        """

        logging.info("### Executing M2M query")
        m2m_df = database.execute_query(m2m_query, True)

        # -------------------------------
        # 4. Mobility Query (mdt_id)
        # -------------------------------
        mobility_df = pd.DataFrame()

        mobility_where = [
            f"customer_name IN ({customer_names_sql})",
            f"tenant_id = {tenant_id}",
            "mdt_id IS NOT NULL",
        ]

        if billing_account_sql:
            mobility_where.append(
                f"billing_account_number IN ({billing_account_sql})"
            )

        if foundation_account_sql:
            mobility_where.append(
                f"foundation_account_number IN ({foundation_account_sql})"
            )

        # Execute mobility query ONLY if BAN or FAN exists
        if billing_account_sql or foundation_account_sql:
            mobility_query = f"""
                SELECT DISTINCT
                    customer_rate_plan_id,
                    customer_rate_plan_name
                FROM public.sim_management_inventory
                WHERE {' AND '.join(mobility_where)}
            """

            logging.info("### Executing Mobility query")
            mobility_df = database.execute_query(mobility_query, True)
        else:
            logging.info("### Skipping Mobility query (no BAN/FAN provided)")

        # -------------------------------
        # 5. Combine results
        # -------------------------------
        frames = []

        if not m2m_df.empty:
            frames.append(m2m_df)

        if not mobility_df.empty:
            frames.append(mobility_df)

        if not frames:
            logging.info("### No rate plans found")
            return {}

        combined_df = pd.concat(frames).drop_duplicates()

        # -------------------------------
        # 6. Build final map
        # -------------------------------
        rate_plan_map = {
            int(row["customer_rate_plan_id"]): row["customer_rate_plan_name"]
            for _, row in combined_df.iterrows()
            if row["customer_rate_plan_id"] is not None
        }

        logging.info(
            "### Final customer_rate_plan map prepared. Count=%s",
            len(rate_plan_map),
        )

        logging.info("### fetch_customer_rate_plan_map: Completed")
        existing_rate_plans = {int(k): v for k, v in rate_plans.items()}
        inventory_rate_plans = {int(k): v for k, v in rate_plan_map.items()}
        combined_rate_plans = {
            **existing_rate_plans,
            **inventory_rate_plans
        }
        return combined_rate_plans
    except Exception as e:
        logging.exception(f"Exception while fetching the rate plans from db filters{e}")
        return {}


def update_display_names_for_service_providers(service_provider_data, db_name,database,common_utils_database,request_received_at,username,tenant_name):
    """
    service_provider_data: dict mapping old_provider_name -> new_display_name
    db_name: str, name of the target database
    """
    logging.info(f"### starting update_display_names_for_service_providers function with data: {service_provider_data} and db_name: {db_name}")
    if not service_provider_data:
        return {"flag": False, "message": "No service provider updates provided."}
    old_provider_names = list(service_provider_data.keys())
    # Fetch active service providers matching those names
    provider_records = database.get_data(
        "serviceprovider",
        {"is_active": True, "service_provider_name": old_provider_names},
        ["id", "service_provider_name"]
    )

    # Assuming provider_records is a DataFrame or can be converted to one
    providers_df = pd.DataFrame(provider_records.to_dict(orient="records"))

    if providers_df.empty:
        logging.warning(
            f"No active service providers found matching names: {old_provider_names}"
        )
        return {"flag": False, "message": "No matching active service providers found."}

    # Iterate rows using iterrows
    for _, provider_row in providers_df.iterrows():
        provider_id = provider_row["id"]
        old_name = provider_row["service_provider_name"]
        new_display_name = service_provider_data.get(old_name)

        if not new_display_name:
            logging.debug(f"No updated name provided for provider: '{old_name}'. Skipping.")
            continue

        try:
            update_service_provider_name(
                service_provider_id=provider_id,
                new_display_name=new_display_name,
                target_db=db_name
            )
            logging.info(
                f"Updated service provider (id={provider_id}) "
                f"from '{old_name}' to '{new_display_name}' in database '{db_name}'."
            )
            ##auditing for each provider update
            ##Audit log for user actions
            response={"flag": True, "message": "Service provider display names updated successfully."}
            try:
                audit_data_user_actions = {
                    "service_name": "update_display_names_for_service_providers",
                    "created_date": request_received_at,
                    "created_by": username,
                    "status": str(response["flag"]),
                    "tenant_name": tenant_name,
                    "module_name": "Partner Becoming Provider",
                    "comments": f"update_display_names_for_service_providers updated successfully and data is: {provider_id} and {old_name} to {new_display_name}",
                    "request_received_at": request_received_at,
                }

                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### update_display_names_for_service_providers Exception while updating audit {e}")
        except Exception as error:
            logging.error(
                f"Failed to update display name for provider "
                f"(id={provider_id}, name='{old_name}'): {error}"
            )
            response={"flag": False, "message": "Service provider display names updated Failed."}
            ##error logging
            message = "Failed to update service provider display names"
            common_utils_database.log_error_to_db(
                {
                    "service_name": "update_display_names_for_service_providers",
                    "error_message": str(error),
                    "error_type": str(type(error).__name__),
                    "users": username,
                    "tenant_name": tenant_name,
                    "comments": f"{message} for provider id: {provider_id} and name: {old_name}",
                    "module_name": "Partner Becoming Provider",
                    "request_received_at": request_received_at,
                },
                "error_log_table",
            )
    return response

##Data Update for Partner becoming Provider tenants
def update_for_partner_to_provider(data):
    """
    Updates inventory data for a partner becoming a provider.

    Parameters:
        data (dict): A dictionary containing the following
            - 'db_name' (str): The tenant database name.
            - 'target_db' (str): The target database name.
            - 'username' (str): The username of the person making the request.
            - 'tenant_name' (str): The name of the tenant.
            - 'session_id' (str): The session ID associated with the request.
            - 'request_received_at' (str): Timestamp when the request was received.
            - 'access_token' (str): Access token for authentication.
            - 'source_db' (str): The source database name.
            - 'partner_db_tenant_id' (int): The tenant ID of the partner database.
            - 'target_db_tenant_id' (int): The tenant ID of the target database.
            - 'main_tenant_db' (str): The main tenant database name.
            - 'main_tenant_db_tenant_id' (int): The tenant ID of the main tenant database.
    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
    """
    logging.info(f"### starting update_for_partner_to_provider function with data: {data}")
    ##fetching the params for the operations
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id= data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    source_db=data.get('source_db',None)
    changed_data=data.get('changed_data',[])
    change_type=data.get('change_event_type',None)
    provider_parent_name=data.get('provider_parent_name',None)
    target_details=data.get('target_details','')
    db_name=data.get('db_name','')
    ##column mapping 
    column_map = {
        "Update PPU address": ["user_address", "modified_by"],
        "Update Features": ["telegence_features", "modified_by"],
        "Change Phone Number": ["msisdn", "modified_by"],
        "Change Carrier Rate Plan": ["carrier_rate_plan_name", "modified_by"],
        "Update Device Status": ["sim_status", "modified_by"],
        "Archive":["is_active","is_deleted"]
    }
    # Database Connection
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_database=DB(db_name, **db_config)
    except Exception as e:
        logging.exception("###update_for_partner_to_provider Failed to connect to common utils database")
        return {
            "flag": False,
            "message": "Database connection error",
        }
    try:
        #calling db funtion here to setup the service provider setup
        if source_db and changed_data:
            source_database = DB(source_db, **db_config)
            if changed_data:
                if isinstance(changed_data, dict):
                    changed_data = [changed_data]
                changed_data=fetching_the_changed_data_with_ids(changed_data,source_database,column_map,change_type,provider_parent_name,tenant_database,'source_id')
                # Validate each record
                to_update = []
                for record in changed_data:
                    if "id" not in record:
                        response = {"flag": False, "message": "Each record must contain an 'id' field."}
                        logging.error("###partner_to_provider_actions bulk_update_role_data Missing 'id' in record.")
                        return response
                    # Extract id and prepare update data
                    record_id = record["id"]
                    update_data = {k: v for k, v in record.items() if k != "id"}
                    to_update.append({"id": record_id, **update_data})

                # Call db_utils bulk_update_data
                response_flag = source_database.bulk_update_data(
                    table_name='sim_management_inventory',
                    data_list=to_update,
                    search_column="id",
                )
                logging.info(f"response_flag : {response_flag} and updated data is length {len(to_update)}")
        if target_details:
            # Initialize defaultdict to collect data by target database
            per_db_changed = defaultdict(list)
            # Populate per_db_changed with source_id and target_id
            for source_id, target_map in target_details.items():
                for db_name, target_id in target_map.items():
                    per_db_changed[db_name].append({
                        'id': source_id,
                        'target_id': target_id
                    })
            # Convert defaultdict to a regular dictionary for better readability
            per_db_changed = dict(per_db_changed)
            # Print the result
            logging.info(f"###update_for_partner_to_provider tenant dict map is {per_db_changed}")
           
            # per_db_changed would be a dict: { target_db_name: [ { "id": target_id, ..., other fields } , ... ] }
            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures = {
                    executor.submit(
                        lambda db_name=db_name, changed_data=changed_data: (
                            logging.info(f"### update_for_partner_to_provider changed_data is {changed_data} and db_name is {db_name}"),
                            target_database := DB(db_name, **db_config),
                            changed_data := fetching_the_changed_data_with_ids(changed_data, tenant_database, column_map, change_type, provider_parent_name, target_database,'target_id'),
                            logging.info(f"### update_for_partner_to_provider Updating DB {db_name} with {len(changed_data)} rows"),
                            response_flag := target_database.bulk_update_data(
                                table_name="sim_management_inventory",
                                data_list=changed_data,
                                search_column="id",
                            ),
                            logging.info(f"update_for_partner_to_provider DB:{db_name} response_flag:{response_flag}, updated rows count:{len(changed_data)}")
                        )
                    )
                    for db_name, changed_data in per_db_changed.items()
                }
                for future in concurrent.futures.as_completed(futures):
                    future.result()

        response={
            "flag": True,"message": "Inventory data update for partner to provider executed successfully"}
        try:
            ##auditing operation
            audit_data_user_actions = {
                "service_name": "update_for_partner_to_provider",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully executed inventory data update for partner becoming provider and data is {json.dumps(data)}",
                "request_received_at": request_received_at,
            }
            ##auditing 
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception is {e}")
        return response
    except Exception as e:
        logging.error(f"### Exception in update_for_partner_to_provider: {e}")
        message = "Failed to execute inventory data update for partner to provider"
        ##error auditing
        common_utils_database.log_error_to_db(
            {
                "service_name": "update_for_partner_to_provider",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"{message} for data: {json.dumps(data)}",
                "module_name": "Partner Becoming Provider",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        response= {"flag": False,
            "message": f"Error executing inventory data update for partner to provider: {e}",
        }
        return response
    



def fetching_the_changed_data_with_ids(changed_data, source_database, change_column_map, change_type, parent_provider_name,target_database,base_map_id):
    """
    Fetches data from sim_management_inventory for given ids and
    rebuilds changed_data with source_id as id.
    - For 'Update PPU address' -> include user_address
    - For 'Update Features' -> include telegence_features
    - For 'Change Phone Number' -> include msisdn
    Always includes modified_by
    Also handles carrier_rate_plan and device_status_id mapping
    """
    logging.info(f"### fetching_the_changed_data_with_ids Request Received for changed_data: {changed_data}, change_type: {change_type}")
    rate_plan_map = {}
    device_status_map = {}
    try:
        if not changed_data:
            return changed_data
        # Fetch integration_id
        integration_dataframe = source_database.get_data(
            'serviceprovider',
            {'service_provider_name': parent_provider_name},['integration_id']
        )
        integration_id = integration_dataframe['integration_id'].to_list()[0] if not integration_dataframe.empty else None
        logging.info(f"### integration_id fetched: {integration_id}")

        # Collect inventory IDs
        inventory_ids = [entry["id"] for entry in changed_data if "id" in entry]
        if not inventory_ids:
            logging.warning("###fetching_the_changed_data_with_ids No valid IDs in changed_data")
            return changed_data
        # Determine required columns
        required_column = change_column_map.get(change_type, [])
        required_column = ["id"] + required_column  # always include 'id'
        # Fetch inventory rows
        inventory_df = target_database.get_data(
            "sim_management_inventory",
            {"id": inventory_ids},
            required_column + ["modified_by"]
        )

        # Fetch carrier rate plans if needed
        if change_type in ('Change Carrier Rate Plan', 'Refresh A Line'):
            carrier_rate_plan_df = source_database.get_data(
                "carrier_rate_plan",
                {"service_provider": parent_provider_name, "is_active": True},
                ["id", "rate_plan_short_name"]
            )
            rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()} if not carrier_rate_plan_df.empty else {}

        # Fetch device statuses if needed
        if change_type in ('Update Status', 'Refresh A Line','Update Device Status'):
            device_status_df = source_database.get_data(
                "device_status",
                {"integration_id": integration_id},
                ["id", "status", "description", "display_name"]
            )
            device_status_map = {}
            for _, row in device_status_df.iterrows():
                for col in ["status", "description", "display_name"]:
                    val = row[col]
                    if val:
                        device_status_map[val.lower()] = row["id"]

        # Transform changed_data
        updated_data = []
        for _, row in inventory_df.iterrows():
            inv_id = row["id"]
            entry = next((e for e in changed_data if int(e.get("id", 0)) == inv_id), None)
            if not entry:
                continue
            logging.info(f"###fetching_the_changed_data_with_ids entry is {entry} and base_id_map is {base_map_id}")
            if 'id' in required_column:
                required_column.remove('id')
            src_id = entry.get(base_map_id)
            new_entry = {"id": src_id}
            logging.info(f"###fetching_the_changed_data_with_ids new_entry is {new_entry} and src_id is {src_id} and required column is {required_column}")
            new_entry.update({
                col: row[col] for col in required_column if col in row
            })
            logging.info(f"###fetching_the_changed_data_with_ids new_entry is {new_entry}")
            # Carrier rate plan mapping
            plan_name = row.get("carrier_rate_plan_name")
            logging.info(f"###fetching_the_changed_data_with_ids plan_name is {plan_name}")
            if plan_name and plan_name in rate_plan_map:
                new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
                new_entry["carrier_rate_plan_name"]=plan_name
            elif plan_name:
                new_entry["carrier_rate_plan_name"]=plan_name
                logging.warning(f"###fetching_the_changed_data_with_ids No matching carrier_rate_plan found for {plan_name}")
            logging.info(f"###fetching_the_changed_data_with_ids new_entry {new_entry}")
            # Device status mapping
            if change_type in ('Update Status', 'Refresh A Line','Update Device Status') and "sim_status" in row:
                sim_status_val = str(row["sim_status"]).lower()
                logging.info(f"###fetching_the_changed_data_with_ids sim_status_val is {sim_status_val} and device_status_map {device_status_map}")
                if sim_status_val in device_status_map:
                    new_entry["device_status_id"] = device_status_map[sim_status_val]
                else:
                    logging.warning(f"###fetching_the_changed_data_with_ids No matching device_status_id found for sim_status={sim_status_val}")
            logging.info(f"###fetching_the_changed_data_with_ids new_entry {new_entry}")
            # Add modified_by
            if "modified_by" in row:
                new_entry["modified_by"] = row["modified_by"]

            updated_data.append(new_entry)

        logging.info(f"### fetching_the_changed_data_with_ids Final transformed data: {updated_data}")
        return updated_data

    except Exception as e:
        logging.exception(f"Exception in fetching_the_changed_data_with_ids: {e}")
        return changed_data

