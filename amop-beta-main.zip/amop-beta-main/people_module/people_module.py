"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 21-06-24
"""

# Importing the necessary Libraries
import ast
import boto3
import re
import requests
import os
import pandas as pd
from common_utils.email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.permission_manager import PermissionManager
from common_utils.timezone_conversion import *
import datetime
from datetime import time
from datetime import datetime, timedelta
import time
from io import BytesIO
import asyncio
from common_utils.data_transfer_main import DataTransfer
import json
from io import BytesIO
import base64
import zipfile
import io
import copy
import openpyxl
import pytds
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (
    Mail,
    Content,
    Attachment,
    FileContent,
    FileName,
    FileType,
    Disposition,
)
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import base64
import re
from pytz import timezone
import boto3
import logging
import os
import time
from io import BytesIO
from datetime import datetime
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
import threading  # For asynchronous execution

logging = Logging(name="module_api")


common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }



def db_config_maker(user,db_config_making,role_name):
    
    if role_name in ('Super Admin','Partner Admin','Agent Partner Admin'):
        return db_config_making

    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

    query=f"select customers,service_provider from user_module_tenant_mapping where user_name ='{user}'"
    filters=common_utils_database.execute_query(query,True)
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))
    except:
        customer=None
    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))
    except:
        service_provider=None

    db_config_making["customers"]= customer
    db_config_making["service_providers"]=service_provider

    return db_config_making

def funtion_caller(data,path):
    db_config_details = None
    # 1. Try to extract encoded config
    # Access global db_config variable
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
    user=data.get('username')
    if not user:
        user=data.get('user_name')

    db_config_making=db_config_maker(user,db_config,role_name)
    db_config=db_config_making
    logging.info(f"db_config created is : {db_config}")

    if path == "/export":
        result = export(data)
    elif path == "/people_revio_customers_list_view":
        result = people_revio_customers_list_view(data)
    elif path == "/download_people_bulk_upload_template":
        result = download_people_bulk_upload_template(data)
    elif path == "/add_people_revcustomer_dropdown_data":
        result = add_people_revcustomer_dropdown_data(data)
    elif path == "/people_bulk_import_data":
        result = people_bulk_import_data(data)
    elif path == "/submit_update_info_people_revcustomer":
        result = submit_update_info_people_revcustomer(data)
    elif path == "/people_list_view":
        result = people_list_view(data)
    elif path == "/update_people_data":
        result = update_people_data(data)
    elif path == "/get_customers_list_view_data":
        result = get_customers_list_view_data(data)
    elif path == "/create_customer":
        result = create_customer(data)
    elif path == "/create_billing_platform_customer":
        result = create_billing_platform_customer(data)
    elif path == "/get_billing_platform_customer_list_view_data":
        result = get_billing_platform_customer_list_view_data(data)
    else:
        result = {"flag": False, "error": "Invalid path or method"}
        logging.warning("Invalid path or method requested: %s", path)

    return result


def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Description: The  function retrieves and organizes field mappings,headers,and module features
    based on the provided module_list, role, user, and other parameters.
    It connects to a database, fetches relevant data, categorizes fields,and
    compiles features into a structured dictionary for each module.
    """
    ##Database connection
    ret_out = {}
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        logging.info(f"Module name is :{module_list} and role is {role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.debug(f"tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"Getting exception at fetching tenant id {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info(f"Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name
                    )

            except Exception as e:
                logging.warning(f"there is some error {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning("there is some error %s", e)

    return ret_out




def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database,role,parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Parameters:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.debug("Raw user features fetched: %s", user_features_raw)
    if not user_features_raw or user_features_raw[0] is None:
        query=f'''select module_features from role_module where role='{role}'
        '''
        user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string
    except:
        features={}

    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(
            features[0]
        )


    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module,features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info("Retrieved features: %s", features_list)

    # Return the list of features associated with the specified feature name
    return features_list



def form_modules_dict(data, sub_modules, tenant_modules, role_name):
    """
    Description:The form_modules_dict function constructs a nested dictionary that maps parent modules
    to their respective submodules and child modules. It filters and organizes modules based on the
    user's role, tenant permissions, and specified submodules.
    """
    logging.info("Starting to form modules dictionary.")
    # Initialize an empty dictionary to store the output
    out = {}
    # Iterate through the list of modules in the data
    for item in data:
        parent_module = item["parent_module_name"]
        logging.debug("Processing parent module: %s", parent_module)
        # Skip modules not assigned to the tenant unless the role is 'super admin'
        if (
            parent_module not in tenant_modules and parent_module
        ) and role_name.lower() != "super admin":
            continue
        # If there's no parent module, initialize an empty dictionary for the module
        if not parent_module:
            out[item["module_name"]] = {}
            continue
        else:
            out[item["parent_module_name"]] = {}
        # Iterate through the data again to find related modules and submodules
        for module in data:
            temp = {}
            # Skip modules not in the specified submodules unless the role is 'super admin'
            if (
                module["module_name"] not in sub_modules
                and module["submodule_name"] not in sub_modules
            ) and role_name.lower() != "super admin":
                logging.debug(
                    "Skipping parent module: %s (not in tenant modules)", parent_module
                )
                continue
            # Handle modules without submodules and create a list for them
            if (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and not module["submodule_name"]
            ):
                temp = {module["module_name"]: []}
            # Handle modules with submodules and map them accordingly
            elif (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and module["submodule_name"]
            ):
                temp = {module["submodule_name"]: [module["module_name"]]}
            # Update the output dictionary with the constructed module mapping
            if temp:
                for key, value in temp.items():
                    if key in out[item["parent_module_name"]]:
                        out[item["parent_module_name"]][key].append(value[0])
                    elif temp:
                        out[item["parent_module_name"]].update(temp)

    # Return the final dictionary containing the module mappings
    logging.info("Finished forming modules dictionary: %s", out)
    return out


def transform_structure(input_data):
    """
    Description:The transform_structure function transforms a nested dictionary
    of modules into a list of structured dictionaries,each with queue_order to
    maintain the order of parent modules, child modules, and sub-children
    """

    logging.info("Starting transformation of input data.")

    # Initialize an empty list to store the transformed data
    transformed_data = []
    # Initialize the queue order for parent modules
    queue_order = 1
    # Iterate over each parent module and its children in the input data
    for parent_module, children in input_data.items():
        transformed_children = []
        child_queue_order = 1
        # Iterate over each child module and its sub-children
        for child_module, sub_children in children.items():
            transformed_sub_children = []
            sub_child_queue_order = 1
            # Iterate over each sub-child module
            for sub_child in sub_children:
                transformed_sub_children.append(
                    {
                        "sub_child_module_name": sub_child,
                        "queue_order": sub_child_queue_order,
                        "sub_children": [],
                    }
                )
                sub_child_queue_order += 1
            # Append the transformed child module with its sub-children
            transformed_children.append(
                {
                    "child_module_name": child_module,
                    "queue_order": child_queue_order,
                    "sub_children": transformed_sub_children,
                }
            )
            child_queue_order += 1
        # Append the transformed parent module with its children
        transformed_data.append(
            {
                "parent_module_name": parent_module,
                "queue_order": queue_order,
                "children": transformed_children,
            }
        )
        queue_order += 1
    # Return the list of transformed data
    return transformed_data


def get_people_data(data_list, module_name, tenant_id, database):
    # database = DB('altaworx_central', **db_config)
    logging.info("Fetching data for module: %s", module_name)
    # logging.info(tenant_id,"tenant_id")

    if module_name == "Bandwidth Customers":
        band_id = []

        for data_item in data_list["customers"]:
            if data_item["bandwidth_customer_id"]:
                band_id.append(data_item["bandwidth_customer_id"])
        logging.info("Bandwidth Customer IDs collected: %s", band_id)

        if band_id:
            band_id_int = tuple(int(float(i)) for i in band_id)
            logging.info(
                "Executing query to fetch bandwidth customers with IDs: %s", band_id_int
            )

            query = f"""
            SELECT bws.id AS bandwidth_unique_col,
                   bws.bandwidth_account_id,
                   bws.bandwidth_customer_name,
                   c.bandwidth_customer_id
            FROM customers AS c
            JOIN bandwidth_customers AS bws
              ON bws.id = CAST(CAST(c.bandwidth_customer_id AS FLOAT) AS INTEGER)
            WHERE bws.id IN {band_id_int}
            ORDER BY c.modified_date DESC;
            """
            df = database.execute_query(query, True)
            total = len(df)
            logging.info("Number of bandwidth customers fetched: %d", total)
            bandwidth_account_id = df["bandwidth_account_id"].to_list()[0]
            logging.info("Fetched bandwidth account ID: %s", bandwidth_account_id)
            data_out = df.to_dict(orient="records")

            global_account_number_df = database.get_data(
                "bandwidthaccount",
                {"id": bandwidth_account_id},
                ["id", "global_account_number"],
            )
            global_account_number = global_account_number_df[
                "global_account_number"
            ].to_list()[0]
            bandwidthaccount_unique_col = global_account_number_df["id"].to_list()[0]
            logging.info(
                "Global account number: %s, Bandwidth account unique col: %s",
                global_account_number,
                bandwidthaccount_unique_col,
            )
            merged_list = []
            dict2 = {d["bandwidth_customer_id"]: d for d in data_list["customers"]}
            for dic_data_out in data_out:
                # Find the corresponding dictionary in dict2
                dic_data_list = dict2.get(dic_data_out["bandwidth_customer_id"], {})
                # Merge dictionaries
                merged_dict = {**dic_data_list, **dic_data_out}
                merged_dict.update({"global_account_number": global_account_number})
                merged_dict.update(
                    {"bandwidthaccount_unique_col": bandwidthaccount_unique_col}
                )
                merged_list.append(merged_dict)

            data_list["customers"] = merged_list
            logging.info("Successfully merged bandwidth customer data.")

        return data_list, total
    elif module_name == "E911 Customers":
        e911_customer_ids = tuple(int(float(i)) for i in data_list["e911_customer_id"])
        # e911_customer_ids=tuple(data_list['e911_customer_id'])
        if e911_customer_ids:
            df = database.get_data(
                "e911customers",
                {"id": e911_customer_ids},
                order={"modified_date": "desc"},
            )
            total = len(df)
            data_list["e911_customers"] = df.to_dict(orient="records")
            data_list.pop("e911_customer_id")
        return data_list, total

    elif module_name == "NetSapiens Customers":
        reseller_ids = database.get_data(
            "customers", {"netsapiens_customer_id": "not Null"}, ["id"]
        )["id"].to_list()
        total = len(reseller_ids)
        # logging.info(reseller_ids)
        for data_item in data_list["customers"]:
            if data_item["id"] in reseller_ids:
                data_item["netsapiens_type"] = "Reseller"
            else:
                data_item["netsapiens_type"] = "Domain"

        return data_list, total



def update_people_data(data):
    """
    updates module data for a specified module by checking user and tenant
    to get the features by querying the database for column mappings and view names.
    It constructs and executes a SQL query to fetch data from the appropriate view,
      handles errors, and logs relevant information.
    """
    # Start time  and date calculation
    start_time = time.time()
    # print(f"Request Data: {data}")
    Partner = data.get("Partner", "")
    ##Restriction Check for the Amop API's
    try:
        # Create an instance of the PermissionManager class
        permission_manager_instance = PermissionManager(db_config)
        logging.info("Checking user permissions.")

        # Call the permission_manager method with the data dictionary and validation=True
        result = permission_manager_instance.permission_manager(data, validation=True)

        # Check the result and handle accordingly
        if isinstance(result, dict) and result.get("flag") is False:
            logging.warning("User does not have permission: %s", result)
            return result
        else:
            # Continue with other logic if needed
            pass
    except Exception as e:
        logging.warning(f"got exception in the restriction")

    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    user_name = data.get("user_name", "")
    action = data.get("action", "")
    ui_changed_data = data.get("changed_data", {})
    module_name = data.get("module", {})
    ##Database connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    try:
        if Partner == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = dbs.get_data(
                "tenant", {"tenant_name": Partner}, ["id"]
            )["id"].to_list()[0]

        if module_name != "E911 Customers":
               ui_changed_data["tenant_id"] = tenant_id
            
        ui_changed_data.pop("deleted_date")
        ui_changed_data.pop("created_date")
        ui_changed_data.pop("modified_date")
        
            
        logging.info("Fetching column mappings for module: %s", module_name)
        df = dbs.get_data(
            "module_column_mappings",
            {"module_name": module_name},
            ["main_update_table", "sub_table_mapping", "unique_columns"],
        )
        main_update_table = df["main_update_table"].to_list()[0]
        try:
            sun_table_map = json.loads(df["sub_table_mapping"].to_list()[0])
        except:
            sun_table_map = {}
        try:
            unique_column = json.loads(df["unique_columns"].to_list()[0])
        except:
            unique_column = df["unique_columns"].to_list()

        changed_data = {}
        for key, value in ui_changed_data.items():
            if value and value != None and value != "None":
                changed_data[key] = value
            else:
                changed_data[key] = None

        update_dics = {}
        for table, cols in sun_table_map.items():
            if table not in update_dics:
                update_dics[table] = {}
            for col in cols:
                if col in changed_data and changed_data[col]:
                    update_dics[table][col] = changed_data[col]
                if col in changed_data:
                    changed_data.pop(col)
        if action == "delete":
            filtered_changed_data = {
                key: value for key, value in changed_data.items() if value is not None
            }
            logging.debug("Updating record in main table: %s", main_update_table)
            unique_column_val = filtered_changed_data.pop(
                unique_column[main_update_table]
            )
            logging.debug("Unique column value for update: %s", unique_column_val)
            logging.debug(
                main_update_table, "33333333333333333333333333333333333333333"
            )

            database.update_dict(
                main_update_table, filtered_changed_data, {"id": changed_data["id"]}
            )
            logging.debug("Record updated successfully in table: %s", main_update_table)
            # database.execute(delete_query_sub_table)
        elif action == "update":
            filtered_changed_data = {
                key: value for key, value in changed_data.items() if value is not None
            }
            logging.debug("Updating record in main table: %s", main_update_table)
            unique_column_val = filtered_changed_data.pop(
                unique_column[main_update_table]
            )
            logging.debug("Unique column value for update: %s", unique_column_val)

            database.update_dict(
                main_update_table, filtered_changed_data, {"id": changed_data["id"]}
            )
            logging.debug("Record updated successfully in table: %s", main_update_table)

        elif action == "create":
            logging.debug("Creating new record in main table: %s", main_update_table)

            # Check if module is "Bandwidth Customers" and fetch bandwidth_account_id
            if module_name == "Bandwidth Customers":
                # Fetch the id from bandwidth_customers where bandwidth_customer_name matches Partner
                result = database.get_data(
                    "bandwidth_customers", {"bandwidth_customer_name": changed_data["tenant_name"]}, ["id"]
                )
                print(result, '211111111')

                # If a matching record is found, use it as the bandwidth_account_id
                if not result.empty:
                    bandwidth_id = result["id"].iloc[0]
                    print(bandwidth_id, "3333333333333333")
                    changed_data["bandwidth_customer_id"] = int(bandwidth_id)
                    logging.debug(
                        f"Assigned bandwidth_account_id: {bandwidth_id} for Partner: {Partner}"
                    )

            # Check if module is "NetSapiens Customers" and fetch netsapiens_customer_id
            elif module_name == "NetSapiens Customers":
                # Fetch the territory_id from netsapiens_reseller where partner matches description
                territory_value = changed_data.get("tenant_name", None)
                query_filter = (
                    {"territory": territory_value}
                    if territory_value
                    else {"description": data.get("description", "")}
                )

                # Fetch the territory_id based on the selected filter
                result = database.get_data(
                    "netsapiens_reseller", query_filter, ["territory_id"]
                )
                logging.debug(
                    result, "3333333333333333332222222222222222222222222222222222222222"
                )

                if result.empty:
                    logging.debug(
                        "No matching record found for 'territory'. Attempting to query by 'description' instead."
                    )
                    description_value = changed_data.get("tenant_name", "")
                    query_filter = {"description": description_value}

                    # Run the query again using description as the filter
                    result = database.get_data(
                        "netsapiens_reseller", query_filter, ["territory_id"]
                    )

                # If a matching record is found, use it as the netsapiens_customer_id
                if not result.empty:
                    territory_id = result["territory_id"].iloc[0]
                    changed_data["netsapiens_customer_id"] = int(territory_id)
                    print(
                        f"Assigned netsapiens_customer_id: {territory_id} for description: {data.get('description', '')}"
                    )

            # Clean up changed_data to ensure it only contains relevant fields for the insert
            if "id" in changed_data:
                changed_data.pop(
                    "id"
                )  # Remove 'id' if present, as it may be auto-generated
            if "created_by" not in changed_data:
                changed_data["created_by"] = (
                    user_name  # Ensure created_by is set to the current user
                )
            if "created_date" not in changed_data:
                changed_data["created_date"] = (
                    request_received_at  # Set created_date to the request time
                )

            if "is_deleted" not in changed_data or changed_data["is_deleted"] in (
                None,
                "None",
                "",
            ):
                changed_data["is_deleted"] = False

            logging.debug("Inserting data: %s", changed_data)
            
            # Insert the new record into the main update table
            inster_id = database.insert_data(changed_data, main_update_table)

            message = f"Record created successfully"
            logging.debug("Create action completed successfully.")
            response = {"flag": True, "message": message}

        message = f"Updated sucessfully"
        response = {"flag": True, "message": message}
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "created_by": user_name,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": json.dumps(changed_data),
                "module_name": "update_people_data",
                "request_received_at": request_received_at,
            }
            dbs.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            print(f"Exception is {e}")
        return response
    except Exception as e:
        print(f"An error occurred: {e}")
        message = f"Unable to save the data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_people_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "People Module",
                "request_received_at": request_received_at,
            }
            dbs.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            print(f"Exception is {e}")
        return response



# Function to convert Timestamps to strings
# def convert_timestamps(obj):
#     logging.info("Converting timestamps in the object: %s", obj)
#     if isinstance(obj, dict):
#         logging.info("Processing a dictionary.")
#         return {k: convert_timestamps(v) for k, v in obj.items()}
#     elif isinstance(obj, list):
#         logging.info("Processing a list with %d elements.", len(obj))
#         return [convert_timestamps(elem) for elem in obj]
#     elif isinstance(obj, pd.Timestamp):
#         logging.info("Converting pandas Timestamp: %s", obj)
#         return obj.strftime("%m-%d-%Y %H:%M:%S")
#     logging.info("No conversion applied for object: %s", obj)
#     return obj


def dataframe_to_blob(data_frame):
    """
    Description:The Function is used to convert the dataframe to blob
    """
    logging.info("Converting DataFrame to blob.")
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        logging.info("Writing DataFrame to Excel.")
        data_frame.to_excel(writer, index=False)
        logging.info("DataFrame written to Excel successfully.")

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    logging.info("DataFrame converted to blob successfully.")

    return blob_data


def export(data, max_rows=500):
    """
    Description:Exports data into an Excel file. It retrieves data based on the module name from the database,
    processes it, and returns a blob representation of the data if within the allowed row limit.
    """
    # logging.info the request data for debugging
    # logging.info(f"Request Data: {data}")
    ### Extract parameters from the Request Data
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    tenant_database = data.get("db_name", "")
    ids = data.get("ids", "")
    ##database connection for common utilss
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    logging.info(f"Fetching export query for module: {module_name}")
    # Start time  and date calculation
    start_time = time.time()
    try:
        ##databse connenction
        database = DB(tenant_database, **db_config)
        # Fetch the query from the database based on the module name
        module_query_df = db.get_data("export_queries", {"module_name": module_name})
        # logging.info(module_query_df,'module_query_df')
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {
                "flag": False,
                "message": f"No query found for module name: {module_name}",
            }
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            logging.warning(f"Unknown module name: {module_name}")
            return {"flag": False, "message": f"Unknown module name: {module_name}"}
        ##params for the specific module
        if module_name in ("inventory status history", "bulkchange status history"):
            params = [ids]
        else:
            params = [start_date, end_date]
        if module_name == "Users":
            data_frame = db.execute_query(query, params=params)
        else:
            data_frame = database.execute_query(query, params=params)
        # Check the number of rows in the DataFrame
        row_count = data_frame.shape[0]
        # logging.info(row_count,'row_count')
        ##checking the max_rows count
        if row_count > max_rows:
            return {
                "flag": False,
                "message": f"Cannot export more than {max_rows} rows.",
            }
        if module_name == "NetSapiens Customers":
            data_frame["NetSapiensType"] = "Reseller"
        # Capitalize each word and add spaces
        data_frame.columns = [
            col.replace("_", " ").capitalize() for col in data_frame.columns
        ]
        data_frame["S.No"] = range(1, len(data_frame) + 1)
        # Reorder columns dynamically to put S.NO at the first position
        columns = ["S.No"] + [col for col in data_frame.columns if col != "S.No"]

        # Format specific columns with dollar symbol for "Rate Plan Socs" module

        if module_name == "Rate Plan Socs":
            if "Overage dollar mb" in data_frame.columns:
                data_frame["Overage dollar mb"] = data_frame["Overage dollar mb"].apply(
                    lambda x: f"${x}"
                )
            if "Base rate" in data_frame.columns:
                data_frame["Base rate"] = data_frame["Base rate"].apply(
                    lambda x: f"${x}"
                )

        if module_name == "Customer Rate Plan":

            # Check if "Id" column exists in data_frame
            if "Id" in data_frame.columns:
                try:
                    # Convert all "Id" values into a list for a single query
                    ids_list = data_frame["Id"].tolist()

                    # Use a single SQL query to get the counts for each ID at once
                    count_query = """
                        SELECT customer_rate_plan_id, COUNT(*) AS count
                        FROM sim_management_inventory
                        WHERE customer_rate_plan_id IN %s
                        GROUP BY customer_rate_plan_id
                    """

                    # Execute the single query with the list of IDs
                    count_results = database.execute_query(
                        count_query, params=(tuple(ids_list),)
                    )

                    # Convert the count results to a dictionary for quick lookup
                    tn_counts_dict = {
                        int(row["customer_rate_plan_id"]): row["count"]
                        for _, row in count_results.iterrows()
                    }

                    # Map counts back to the DataFrame
                    data_frame["# of TNs"] = (
                        data_frame["Id"]
                        .map(tn_counts_dict)
                        .fillna(0)
                        .astype(int)
                        .astype(str)
                    )
                    columns.append("# of TNs")
                    columns.remove("Id")

                except Exception as e:
                    logging.exception(
                        f"Failed to retrieve count for Customer Rate Plan: {e}"
                    )
                    return {
                        "flag": False,
                        "message": f"An error occurred while fetching count for Customer Rate Plan: {e}",
                    }

        data_frame = data_frame[columns]
        # Proceed with the export if row count is within the allowed limit
        data_frame = data_frame.astype(str)
        data_frame.replace(to_replace="None", value="", inplace=True)
        logging.info("Converting DataFrame to blob.")

        blob_data = dataframe_to_blob(data_frame)
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))

        # Return JSON response
        response = {"flag": True, "blob": blob_data.decode("utf-8")}
        audit_data_user_actions = {
            "service_name": "Module Management",
            "created_date": request_received_at,
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "export",
            "request_received_at": request_received_at,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Auditing user actions.")
        return response
    except Exception as e:
        error_type = str(type(e).__name__)
        logging.exception(f"An error occurred: {e}")
        message = f"Error is {e}"
        response = {"flag": False, "message": message}
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "export",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return response



def people_revio_customers_list_view(data):

    """
    Fetches a paginated list of Rev.io customer data for the People module based on 
    user access, filters, and sorting preferences.

    Args:
        data (dict): Input data containing keys like:
            - tenant_name (str): Tenant name for access scope.
            - role_name (str): Role of the user (e.g. "admin", "user").
            - db_name (str): Tenant-specific database name.
            - col_sort (dict): Optional sorting column and direction (e.g., {"name": "asc"}).
            - mod_pages (dict): Pagination info with 'start' and 'end' indexes.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Success status of the operation.
            - message (str): Success or error message.
            - data (list): Serialized customer records with timestamps converted to tenant timezone.
            - headers_map (dict): Mapping of column headers.
            - dropdown_options (list): Filter dropdown options.
            - pages (dict): Pagination metadata with total count.
    """
    logging.info(f"### Request Data for people_revio_customers_list_view: {data}")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    # logging.info(f"Request Data: {data}")

    tenant_name = data.get("tenant_name", None)
    role_name = data.get("role_name", None)
    username = data.get("username", "")
    # del db_config['customers']
    # del db_config['service_providers']
    col_sort= data.get("col_sort", "")
    tenant_database = data.get("db_name", "")
    try:
        # Remove specific keys from the database config if they exist
        db_config.pop('customers', None)
        db_config.pop('service_providers', None)
    except Exception as e:
        # Safely ignore any unexpected errors
        logging.exception(f"Exception while removing the filters")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    # killbill_database =  DB(os.environ['BILLING_PLATFORM'], **common_utils_database_config)
    mode = os.environ.get('ENV','')
    try:
        billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
        killbill_database = DB(billing_platform_db_name, **db_config)
    except Exception as e:
        # Safely ignore any unexpected errors
        logging.exception(f"Exception while connecting to billing db as the billing is not enabled for this tenant{e}")
    logging.info(f"### DB config: {db_config}")


    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]



    try:
        return_json_data = {}

        # Fetch tenant_id based on tenant_name
        # tenant_id = common_utils_database.get_data("tenant", {'tenant_name': tenant_name}, ['id'])['id'].to_list()[0]

        # Pagination logic
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)

        limit = end_page - start_page
        offset = start_page

        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(common_utils_database,data)

        headers_map = get_headers_mapping(
            tenant_database,
            ["people_rev_io_customers"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            common_utils_database
        )

        # Prepare dropdown data
        dropdown_options = [{"label": "All", "value": "all"}]  # Add the "All" option

        customers = []
        service_providers = []
        customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, database,tenant_name,role_name)
        logging.info(f"### Customers: {customers}, Service Providers: {service_providers}")

        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            # Construct the ORDER BY clause
            order_condition = (
                f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
            )
        else:
            # If users is None or empty, we skip the WHERE clause entirely
            order_condition = (
                f" ORDER BY modified_date DESC LIMIT 100 OFFSET {start_page}"
            )

        filters = []
        if customers:
            if len(customers) == 1:
                filters.append(f" customer_name = '{customers[0]}'")  # Add single quotes
            else:
                filters.append(f"  customer_name IN {tuple(customers)}")  # Tuple already includes quotes

        user_query = f"""
            SELECT CONCAT(first_name, ' ', last_name) AS full_name
            FROM users
            WHERE username = '{username}'
        """



        # Execute query safely
        user_result = common_utils_database.execute_query(user_query, True)

        if user_result is not None and not user_result.empty:
            users = user_result["full_name"].tolist()


        # Construct the WHERE clause conditionally based on 'users'
        if customers:
            users_condition = (
                f""" OR created_by IN ({','.join(f"'{user}'" for user in users)}) """
                f"""OR modified_by IN ({','.join(f"'{user}'" for user in users)})  """
            )
        else:
            users_condition = ""


        if service_providers or customers:

            query = """
                            SELECT
                                COUNT(*) OVER() AS total_count,
                                id,
                                partner,
                                agent_name,
                                name,
                                billing_customer_id,
                                account,
                                customer_bill_period_end_day,
                                customer_bill_period_end_hour,
                                customer_name,
                                created_by,
                                modified_by,
                                cust_id,
                                tenant_id,
                                user_type,
                                country,
                                postal_code,
                                state,
                                city,
                                address1 as address_line_2,
                                address2 as address_line_1,
                                btn_provider,
                                billing_cycle_range,
                                parent_accounts,
                                bp_account_type as account_type,
                                telephone_number,
                                billing_email
                                
                            FROM
                                public.vw_people_revio_customers
                            """



            # Append filters to the WHERE clause
            if filters:
                query += " WHERE " + f""" tenant_id =  {tenant_id} and """  + " AND ".join(filters)  # Properly join conditions with AND

            # Add the order condition
            query += f"{users_condition} {order_condition}"
        else:
            query = f"""
                        SELECT
                                COUNT(*) OVER() AS total_count,
                                id,
                                partner,
                                agent_name,
                                name,
                                billing_customer_id,
                                account,
                                customer_bill_period_end_day,
                                customer_bill_period_end_hour,
                                customer_name,
                                created_by,
                                modified_by,
                                cust_id,
                                tenant_id,
                                user_type,
                                country,
                                postal_code,
                                state,
                                city,
                                address1 as address_line_2,
                                address2 as address_line_1,
                                btn_provider,
                                billing_cycle_range,
                                parent_accounts,
                                bp_account_type as account_type,
                                telephone_number,
                                billing_email
                        FROM
                            public.vw_people_revio_customers
                            where tenant_id = {tenant_id}
                        {order_condition}"""

        params = [limit, offset]
        logging.info(f"### Executing query to fetch all customers with params: {params}")

        # Execute the main query and get results
        # start_time = time.time()
        result = database.execute_query(query,True)
        # query_duration = time.time() - start_time
        # logging.info(f"### Query executed in {query_duration:.2f} seconds")

        # Execute the count query
        logging.info("### Executing count query.")
        # count_result = database.execute_query(count_query, True)
        total_count = int(result.iloc[0]["total_count"]) if not result.empty else 0

        # Pagination pages info
        pages = {"start": start_page, "end": end_page, "total": total_count}

        logging.info("### Preparing the response data.")
        # Execute each query and store the result
        result = database.execute_query(query, params=params)
        df_dict = result.to_dict(orient='records')
        df_dict = convert_timestamp_data(
            result.to_dict(orient="records"), tenant_time_zone
        )
        
        

        tenant_row = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name, "is_active": True},
            ["id", "parent_tenant_id"]
        )

        tenant_id = tenant_row["id"].to_list()[0] if not tenant_row.empty else None
        parent_tenant_id = tenant_row["parent_tenant_id"].to_list()[0] if not tenant_row.empty else None

        if parent_tenant_id:  # It's a subtenant
            # Get parent tenant details
            parent_row = common_utils_database.get_data("tenant", {"id": parent_tenant_id, "is_active": True}, ["id", "tenant_name"])
            parent_tenant = {parent_row["tenant_name"].to_list()[0]: parent_tenant_id}

            # Get sibling subtenants
            sub_tenants_data = common_utils_database.get_data(
                "tenant", {"parent_tenant_id": parent_tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenant = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }
            service_providers=database.get_data('serviceprovider',{'is_active':True},['service_provider_name'])
            service_providers=service_providers['service_provider_name'].to_list()

        else:  # It's a parent tenant
            parent_tenant = {tenant_name: tenant_id}
            sub_tenants_data = common_utils_database.get_data(
                "tenant", {"parent_tenant_id": tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenants = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }
            sub_tenant=dict(sorted(sub_tenants.items()))
            service_providers_query=f'''select distinct service_provider_display_name from sim_management_inventory where tenant_id={tenant_id} and is_active=True'''
            service_providers=database.execute_query(service_providers_query,True)['service_provider_display_name'].to_list()
        
        
        # Dropdown: predefined account types
        account_type=['Standard','Parent','Child']

        # Dropdown: fetch active service providers linked with billing periods
        query = """
            SELECT DISTINCT sp.id as id, sp.display_name as display_name
            FROM public.serviceprovider sp
            INNER JOIN public.billing_period bp ON sp.id = bp.service_provider_id
            ORDER BY sp.id DESC
        """
        service_provider_query = database.execute_query(query, flag=True)
            
        provider_list = sorted(set(
            name for name in service_provider_query['display_name'] if name is not None
        ))
        
            

        # Dropdown: list of user full names
        users_query=common_utils_database.get_data(table_name="users",columns=["first_name","last_name"])
        
        
            
        users_list = sorted(set(
            users_query.apply(lambda row: f"{row['first_name']} {row['last_name']}", axis=1).tolist()
        ))
        formatted_list=[]
        service_locations={}
        try:
        
            # Dropdown: parent account numbers
            account_numbers = killbill_database.get_data(
                'customer_profiles',
                {"account_type": 'Parent'},
                ["account_number", "customer_name"]
            )

            # Check if data was retrieved successfully
            if account_numbers is not False and not account_numbers.empty:
                formatted_list = sorted([
                    f"{row['account_number']} - {row['customer_name']}"
                    for _, row in account_numbers.iterrows()
                ])
            else:
                # Handle the error case
                print("Warning: Could not retrieve account numbers. Check if 'customer_name' column exists.")
                formatted_list = []

            # Dropdown: service location states
            service_location_data = killbill_database.get_data(
                table_name="service_locations",
                condition=None,
                columns=["states", "postal_codes"]
            )

            if service_location_data is not False and not service_location_data.empty:
                state_to_postal = {}
                for _, row in service_location_data.iterrows():
                    state = row["states"]
                    postal = row["postal_codes"]
                    # If you expect multiple postal codes per state:
                    if state in state_to_postal:
                        # Append or extend list if not duplicate
                        if postal not in state_to_postal[state]:
                            state_to_postal[state].append(postal)
                    else:
                        state_to_postal[state] = [postal]
                # If you prefer single postal code per state and want to overwrite or choose one:
                # state_to_postal = {row["states"]: row["postal_codes"] for _, row in service_location_data.iterrows()}
                service_locations = state_to_postal
            else:
                logging.info("### Warning: Could not retrieve service locations.")
                service_locations = {"Alabama":["AL"],"Alaska":["AK"],"Arizona":["AZ"],"Arkansas":["AR"],"California":["CA"],
                                 "Colorado":["CO"],"Connecticut":["CT"],"Delaware":["DE"],"Florida":["FL"],"Georgia":["GA"],
                                 "Hawaii":["HI"],"Idaho":["ID"],"Illinois":["IL"],"Indiana":["IN"],"Iowa":["IA"],"Kansas":["KS"],
                                 "Kentucky":["KY"],"Louisiana":["LA"],"Maine":["ME"],"Maryland":["MD"],"Massachusetts":["MA"],
                                 "Michigan":["MI"],"Minnesota":["MN"],"Mississippi":["MS"],"Missouri":["MO"],"Montana":["MT"],
                                 "Nebraska":["NE"],"Nevada":["NV"],"New Hampshire":["NH"],"New Jersey":["NJ"],"New Mexico":["NM"],
                                 "New York":["NY"],"North Carolina":["NC"],"North Dakota":["ND"],"Ohio":["OH"],"Oklahoma":["OK"],
                                 "Oregon":["OR"],"Pennsylvania":["PA"],"Rhode Island":["RI"],"South Carolina":["SC"],
                                 "South Dakota":["SD"],"Tennessee":["TN"],"Texas":["TX"],"Utah":["UT"],"Vermont":["VT"],
                                 "Virginia":["VA"],"Washington":["WA"],"West Virginia":["WV"],"Wisconsin":["WI"],"Wyoming":["WY"]}
        except Exception as e:
            logging.info(f"Error Fetching the billing data{e}")
            service_locations = {"Alabama":["AL"],"Alaska":["AK"],"Arizona":["AZ"],"Arkansas":["AR"],"California":["CA"],
                                 "Colorado":["CO"],"Connecticut":["CT"],"Delaware":["DE"],"Florida":["FL"],"Georgia":["GA"],
                                 "Hawaii":["HI"],"Idaho":["ID"],"Illinois":["IL"],"Indiana":["IN"],"Iowa":["IA"],"Kansas":["KS"],
                                 "Kentucky":["KY"],"Louisiana":["LA"],"Maine":["ME"],"Maryland":["MD"],"Massachusetts":["MA"],
                                 "Michigan":["MI"],"Minnesota":["MN"],"Mississippi":["MS"],"Missouri":["MO"],"Montana":["MT"],
                                 "Nebraska":["NE"],"Nevada":["NV"],"New Hampshire":["NH"],"New Jersey":["NJ"],"New Mexico":["NM"],
                                 "New York":["NY"],"North Carolina":["NC"],"North Dakota":["ND"],"Ohio":["OH"],"Oklahoma":["OK"],
                                 "Oregon":["OR"],"Pennsylvania":["PA"],"Rhode Island":["RI"],"South Carolina":["SC"],
                                 "South Dakota":["SD"],"Tennessee":["TN"],"Texas":["TX"],"Utah":["UT"],"Vermont":["VT"],
                                 "Virginia":["VA"],"Washington":["WA"],"West Virginia":["WV"],"Wisconsin":["WI"],"Wyoming":["WY"]}

        # Set the response data
        if not result.empty:
            return_json_data["flag"] = True
            return_json_data["message"] = "Data fetched successfully"
            return_json_data["data"] = serialize_data(df_dict)
            return_json_data["headers_map"] = headers_map
            return_json_data["dropdown_options"] = dropdown_options
            return_json_data["pages"] = pages
            logging.info("### Data fetched successfully.")
            return_json_data["sub_tenant"] = sub_tenant
            return_json_data["tenant_name"] = tenant_name
            return_json_data['account_type'] = account_type
            return_json_data['btn_provider'] = provider_list
            return_json_data['sales_person'] = users_list
            return_json_data['parent_accounts'] = formatted_list
            return_json_data['state'] = service_locations
            return_json_data["service_providers"] = service_providers
            return_json_data["agent"] = ["Catapult"]
        else:
            return_json_data["flag"] = True
            return_json_data["message"] = "No data found or an error occurred"
            return_json_data["data"] = []
            return_json_data["dropdown_options"] = dropdown_options
            return_json_data["headers_map"] = headers_map
            return_json_data["sub_tenant"] = sub_tenant
            return_json_data["tenant_name"] = tenant_name
            return_json_data['account_type'] = account_type
            return_json_data['btn_provider'] = provider_list
            return_json_data['sales_person'] = users_list
            return_json_data['parent_accounts'] = formatted_list
            return_json_data['state'] = service_locations
            return_json_data["service_providers"] = service_providers
            return_json_data["agent"] = ["Catapult"]
            logging.warning("No data found.")

        try:
            audit_data_user_actions = {
                "service_name": "people_revio_customers_list_view",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "People module",
                "comments": f"getting revio customers list view for tenant: {tenant_name}",
                "request_received_at": request_received_at,
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"### Exception while updating audit and exception is : {e}")

        return return_json_data

    except Exception as e:
        logging.error(f"### An error occurred: {str(e)}")
        # Error handling
        return_json_data["flag"] = False
        return_json_data["headers_map"] = headers_map
        return_json_data["message"] = f"Failed!! Error: {str(e)}"
        return_json_data["data"] = []
        response = "failed while fetching the data"
        error_type = str(type(e).__name__)
        # Error logging
        error_data = {
            "service_name": "people_revio_customers_list_view",
            "error_message": str(e),
            "error_type": error_type,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Failed to fetch revio customers list view for tenant: {tenant_name}",
            "module_name": "People module",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return return_json_data



    
def load_integration_authentication_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_integration_authentication_id.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs


def get_integration_authentication_id_by_unique_name(json_data, tenant_name):
    logging.info(f"Tenant Name: {tenant_name}")
    """Fetches 'main_name' of a provider based on its unique name."""
    return json_data.get(tenant_name, {}).get("INTEGRATION_AUTHENTICATION_ID", None)





def add_people_revcustomer_dropdown_data(data):
    """
    Description: Retrieves add_service_product dropdown data from the database based on unique identifiers and columns provided in the input data.
    Validates the access token and logs the request, then fetches and returns the device history if the token is valid.
    """
    # checking the access token valididty
    username = data.get("username", None)

    tenant_name = data.get("tenant_name", None)
    session_id = data.get("session_id", None)
    module_name = data.get("module_name", None)
    tenant_database = data.get("db_name", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    try:
        if tenant_name == "Altaworx Test":
            tenant_name = "Altaworx"
        ##fetching the tenant data
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name},
            ["id","parent_tenant_id"]
            )
        tenant_id = tenant_data["id"].to_list()[0]
        parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
        integration_authentication_json_data = load_integration_authentication_json()
        integration_auth_id = get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)
        if not integration_auth_id and parent_tenant_id:
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
                parent_tenant_data = common_utils_database.get_data(
                "tenant", {"id": parent_tenant_id},
                ["tenant_name"]
                )
                parent_tenant_name = parent_tenant_data["tenant_name"].to_list()[0]
                integration_auth_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, parent_tenant_name)
        elif not integration_auth_id and not parent_tenant_id:
            integration_auth_id=get_integration_authentication_id_by_unique_name(integration_authentication_json_data, 'Altaworx')
        response_data = {}
        rev_customer_name = data.get("customer_name", None)
        response_message = ""
        # Query 1: Get customer ID
        query1 = f"""select ia.username from integration_authentication ia where ia.integration_id =3 and ia.is_active =true
        and ia.tenant_id = {tenant_id}"""
        logging.info("Executing Query 1 to retrieve customer ID.")

        rev_io_account_df = database.execute_query(query1, flag=True)
        # Extract only the 'username' column values as a list
        if isinstance(rev_io_account_df, pd.DataFrame) and not rev_io_account_df.empty:
            rev_io_account = rev_io_account_df["username"].dropna().tolist()
            # Remove duplicates by converting to a set and back to a list
            rev_io_account = list(dict.fromkeys(rev_io_account))

            response_data["rev_io_account"] = rev_io_account
            logging.debug(f"Retrieved rev_io_account: {rev_io_account}")
        else:
            logging.info("No data found or query failed")
        # Retrieve all customer_name values from the 'customers' table
        customer_names_df_query = f"""
                SELECT customer_name, rev_customer_id
                FROM revcustomer
                WHERE is_active = 'true' and bp_customer='false'
                AND is_deleted = 'false'
                AND rev_customer_id IS NOT NULL
                AND rev_customer_id <> ''
                AND integration_authentication_id = {integration_auth_id}
                AND status in ('OPEN','Open','open')
                AND rev_parent_customer_id is null
                ORDER BY customer_name, rev_customer_id;
            """
        logging.info("Executing Query 3 to retrieve customer rate plans.")
        customer_names_df = database.execute_query(customer_names_df_query, flag=True)
        if isinstance(customer_names_df, pd.DataFrame) and not customer_names_df.empty:
            # customer_names = customer_names_df["customer_name"].tolist()
            # customer_names = list(set(customer_names))
            response_data["customer_names"] = [
                f"{row['customer_name']} - {row['rev_customer_id']}"  # Adjust column names as needed
                for index, row in customer_names_df.iterrows()
            ]
            # logging.debug(f"Retrieved customer names: {customer_names}")
        else:
            logging.info("No customer names found or query failed")
            response_data["customer_names"] = []

        # Query 2: Get Bill Profile
        query2 = f"""SELECT  description || ' -- ' || bill_profile_id AS description  FROM public.revbillprofile
        where integration_authentication_id = {integration_auth_id}
        and is_active = 'true' and is_deleted = 'false'
        order by description ASC"""

        logging.info("Executing Query 2 to retrieve bill profiles.")
        rev_io_bill_profile_df = database.execute_query(query2, flag=True)
        # Extract only the 'username' column values as a list
        if (
            isinstance(rev_io_bill_profile_df, pd.DataFrame)
            and not rev_io_bill_profile_df.empty
        ):
            rev_bill_profile_list = (
                rev_io_bill_profile_df["description"].dropna().unique().tolist()
            )
            response_data["rev_bill_profile"] = rev_bill_profile_list
            logging.debug(f"Retrieved bill profiles: {rev_bill_profile_list}")
        else:
            logging.info("No bill profiles found or query failed")
            response_data["rev_bill_profile"] = []

        # Query 3: Get Customer Rate Plan
        query3 = f"""
                SELECT *
                FROM revcustomer
                WHERE is_active = 'true' and bp_customer='false'
                AND is_deleted = 'false'
                AND rev_customer_id IS NOT NULL
                AND rev_customer_id <> ''
                AND integration_authentication_id = {integration_auth_id}
                AND status in ('OPEN','Open','open')
                ORDER BY customer_name, rev_customer_id;
            """
        logging.info("Executing Query 3 to retrieve customer rate plans.")
        customer_rate_plan = database.execute_query(query3, flag=True)
        # Extract only the 'username' column values as a list
        if (
            isinstance(customer_rate_plan, pd.DataFrame)
            and not customer_rate_plan.empty
        ):
            # Construct the customer rate plan list
            response_data["customer_rate_plan"] = [
                f"{row['customer_name']} -- {row['rev_customer_id']}"  # Adjust column names as needed
                for index, row in customer_rate_plan.iterrows()
            ]
            logging.debug(
                f"Retrieved customer rate plans: {response_data['customer_rate_plan']}"
            )
        else:
            logging.warning("No customers found or query failed")
            response_data["customer_rate_plan"] = []

        message = " data sent sucessfully"
        response = {"flag": True, "message": message, "response_data": response_data}
        return response
    except Exception as e:
        logging.warning(f"Something went wrong and error is {e}")
        message = "Something went wrong while getting add service product"
        # Error Management
        error_data = {
            "service_name": "SIM management",
            "error_messag": message,
            "error_type": e,
            "user": username,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": module_name,
        }
        common_utils_database.log_error_to_db(error_data, "error_table")
        return {"flag": False, "message": message}





def download_people_bulk_upload_template(data):
    # Construct the SQL query based on the provided logic
    query = """
        SELECT column_name
        FROM information_schema.columns
        WHERE
            (table_name = 'revagent' AND column_name = 'agent_name') OR
            (table_name = 'revcustomer' AND column_name IN ('customer_name', 'rev_customer_id')) OR
            (table_name = 'customers' AND column_name IN ('tenant_name','customer_bill_period_end_day', 'customer_bill_period_end_hour'));
    """

    # Execute the query to fetch the columns without parameters (set flag=True)
    tenant_database = data.get("db_name", "")
    # database Connection
    database = DB(tenant_database, **db_config)
    logging.info(f"Executing query to fetch column names from the database: {query}")
    columns_df = database.execute_query(
        query, flag=True
    )  # Use flag=True since no parameters are required

    if isinstance(
        columns_df, bool
    ):  # Handle case if execution returns True (error scenario)

        logging.info("Query execution returned a boolean value instead of a DataFrame.")
        return {"flag": False, "error": "Failed to retrieve columns from the database."}
    logging.debug(
        f"Columns retrieved from the database: {columns_df['column_name'].tolist()}"
    )
    # Remove the 'id' column if it exists
    columns_df = columns_df[columns_df["column_name"] != "id"]
    columns_df["column_name"] = (
        columns_df["column_name"].str.replace("_", " ").str.capitalize()
    )
    # logging.info(columns_df, "00000000000000000")
    # logging.info(columns_df['column_name'].values, "o99999999999999999999999")

    # Create an empty DataFrame with the column names as columns
    result_df = pd.DataFrame(columns=columns_df["column_name"].values)
    # logging.info(result_df, "88888876543")

    logging.debug(f"Resulting DataFrame structure: {result_df.columns.tolist()}")
    # Convert the DataFrame to blob (binary data) and return it as part of the response
    blob_data = dataframe_to_blob(result_df)
    response = {"flag": True, "blob": blob_data.decode("utf-8")}
    logging.info("Successfully generated the bulk upload template.")
    return response


def convert_booleans(data):
    logging.debug(f"Initial data for conversion: {data}")
    for key, value in data.items():
        if isinstance(value, str) and value.lower() == "true":
            data[key] = True
            logging.debug(f"Converted '{key}' from string 'true' to boolean True")
        elif isinstance(value, str) and value.lower() == "false":
            data[key] = False
            logging.debug(f"Converted '{key}' from string 'false' to boolean False")
        elif isinstance(value, dict):  # Recursively process nested dictionaries
            logging.debug(
                f"Found nested dictionary at key '{key}', processing recursively."
            )
            convert_booleans(value)
    return data  # Return the modified dictionary



def decode_password(encoded_pwd: str) -> str:
    """
    Decode the stored password. Replace with your actual decode logic.
    """
    # Example: if it was base64-encoded in the DB:
    return base64.b64decode(encoded_pwd).decode("utf-8")

def decode_token(encoded_token: str) -> str:
    """
    Decode the stored token_value. Replace with your actual decode logic.
    """
    return base64.b64decode(encoded_token).decode("utf-8")

def get_headers(database,tenant_id):
    """Fetch and prepare headers for Telegence API requests.
    This function retrieves the necessary authentication details from the database,
    decodes them, and constructs the headers required for API requests.
    Args:

        database (object): Database connection or handler object.
        tenant_id (int): The tenant ID to fetch the integration authentication details.
    Returns:
        dict: Headers containing 'Authorization' and 'Ocp-Apim-Subscription-Key'.
    """
    try:
        rev_io_data_query=f'''SELECT username,password,token_value FROM public.integration_authentication
        where integration_id in (select id from integration where name='Rev.IO'
        ) and tenant_id={tenant_id}'''
        rev_io_dataframe=database.execute_query(rev_io_data_query,True)
        revio_username = rev_io_dataframe["username"].to_list()[0]
        encoded_pwd = rev_io_dataframe["password"].to_list()[0]
        encoded_token = rev_io_dataframe["token_value"].to_list()[0]
        password = decode_password(encoded_pwd)
        token_value = decode_token(encoded_token)
        # 3. Re-encode username:password into Basic
        user_pass = f"{revio_username}:{password}"
        # base64 encode
        b64 = base64.b64encode(user_pass.encode("utf-8")).decode("utf-8")
        rev_app_id = f"Basic {b64}"

        # 4. app_secret is the decoded token_value
        rev_app_secret = token_value

        headers = {
            "Authorization": rev_app_id,
            "Ocp-Apim-Subscription-Key": rev_app_secret,
            "Accept": "application/json",
        }  

        return headers
    except Exception as e:
        logging.error(f"### fetch_headers Error occurred while fetching headers: {e}")
        headers = {
            "Authorization": "",
            "Ocp-Apim-Subscription-Key": "",
        }  
        return headers




import uuid
from datetime import datetime
import pandas as pd



def submit_update_info_people_revcustomer(data):
    """
    Updates email template data for a specified module by checking user and tenant permissions.
    Constructs and executes SQL queries to fetch and manipulate data, handles errors, and logs relevant information.
    """
    logging.info(f"submit_update_info_people_revcustomer recived data is {data}")
    data = convert_booleans(data)
    changed_data = data.get("changed_data", {})
    user_name = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    new_data = {k: v for k, v in data.get("new_data", {}).items() if v}
    new_payload = {k: v for k, v in data.get("new_payload", {}).items() if v}
    unique_id = changed_data.get("id")
    action = data.get("action", "")
    api_payload = data.get("api_payload", "")

    # Database connection setup
    tenant_database = data.get("db_name", "")
    # database Connection
    dbs = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    tenant_id = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    
    integration_authentication_json_data = load_integration_authentication_json()
    integration_auth_id = get_integration_authentication_id_by_unique_name(integration_authentication_json_data, tenant_name)

    try:
        if action == "create":
            new_payload["tenant_id"] = tenant_id
            # choose parent_customer if valid, otherwise fallback to service_address_company_name
            parent = new_payload.get("parent_customer")
            if parent in (None, "None", ""):
                customer = new_payload.get("service_address_company_name")
            else:
                # remove the trailing " -- 12345" part
                customer = parent.split(" -- ")[0].strip()
            new_payload["customer_name"] = customer

            new_payload["tenant_name"] = tenant_name
            new_data = {k: v for k, v in new_data.items() if v not in [None, "None"]}
            for k, v in new_data.items():
                if isinstance(v, list):
                    if all(isinstance(item, dict) for item in v):
                        new_data[k] = json.dumps(
                            v
                        )  # Convert list of dicts to JSON string
                    else:
                        new_data[k] = ", ".join(
                            str(item) for item in v if item is not None
                        )  # Convert other types to strings

            new_payload = {
                k: v for k, v in new_payload.items() if v not in [None, "None"]
            }
            for k, v in new_payload.items():
                if isinstance(v, list):
                    if all(isinstance(item, dict) for item in v):
                        new_payload[k] = json.dumps(
                            v
                        )  # Convert list of dicts to JSON string
                    else:
                        new_payload[k] = ", ".join(
                            str(item) for item in v if item is not None
                        )  # Convert other types to strings

            # url = 'https://api.revioapi.com/v1/Customers'
            url = os.getenv("PEOPLE_REVIO_CUSTOMER", " ")
            # headers = {
            #     "Ocp-Apim-Subscription-Key": "0fc3f44bc0814510ba38c7fa27a151a7",
            #     "Authorization": "Basic QU1PUFRvUmV2aW9AYWx0YXdvcnhfc2FuZGJveDpHZW9sb2d5N0BTaG93aW5nQFN0YW5r",
            # }

            # First check parent tenant if needed
            if tenant_name not in ("Altaworx Test", "Altaworx", "Altaworx - Go Tech"):
                parent_tenant_query = f'''
                    SELECT parent_tenant_id
                    FROM tenant
                    WHERE tenant_name = '{tenant_name}'
                '''
                parent_tenant_id_df = common_utils_database.execute_query(parent_tenant_query, True)

                if not parent_tenant_id_df.empty:
                    parent_tenant_id = parent_tenant_id_df['parent_tenant_id'].to_list()[0]

                    if parent_tenant_id is not None:
                        parent_tenant_id = int(parent_tenant_id)
                        parent_tenant_name_query = f'''
                            SELECT tenant_name
                            FROM tenant
                            WHERE id = {parent_tenant_id}
                        '''
                        parent_tenant_name_df = common_utils_database.execute_query(parent_tenant_name_query, True)

                        if not parent_tenant_name_df.empty:
                            tenant_name = parent_tenant_name_df['tenant_name'].to_list()[0]

            # Now set headers based on tenant_name
            headers=get_headers(dbs,tenant_id)

            # Pass the new_data as params in the GET request
            params = api_payload

            logging.info(f"submit_update_info_people_revcustomer api_payload = {api_payload}")
            logging.info(f"submit_update_info_people_revcustomer url = {url}, headers = {headers} and params={params}")

            # Call the API and check response
            api_response = requests.post(url, headers=headers, json=params)
            logging.info(f"submit_update_info_people_revcustomer API response status_code = {api_response.status_code}")
            logging.info(f"submit_update_info_people_revcustomer API response payload = {api_response.text}")
            if api_response.status_code in [200,201]:
                # Success, construct and return response with both API and database insert responses
                message = "Add Rev.io product data submitted successfully."
                
                # Get the Rev.io customer ID from API response
                api_response_data = api_response.json()
                rev_customer_id = api_response_data.get("Id") or api_response_data.get("id")
                
                # Get parent customer ID if parent_customer exists
                parent_customer_id = None
                parent_rev_customer_id = new_payload.get("parent_customer")
                
                if parent_rev_customer_id and parent_rev_customer_id not in (None, "None", ""):
                    parent_query = """
                        SELECT id 
                        FROM rev_customers 
                        WHERE rev_customer_id = %s
                    """
                    parent_result = dbs.execute_query(parent_query, params=[str(parent_rev_customer_id)])
                    
                    if isinstance(parent_result, list) and parent_result:
                        parent_customer_id = parent_result[0].get("id")
                    elif isinstance(parent_result, pd.DataFrame) and not parent_result.empty:
                        parent_customer_id = parent_result.iloc[0].get("id")
                
                # Prepare data for customers table (Site table in .NET)
                current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                customers_data = {
                    "tenant_id": tenant_id,
                    "customer_name": f"{new_payload.get('service_address_company_name', '')} ({rev_customer_id})",
                    "address1": new_payload.get("service_address_address_line_1"),
                    "address2": new_payload.get("service_address_address_line_2"),
                    "city": new_payload.get("service_address_city"),
                    "state": new_payload.get("service_address_state"),
                    "postal_code": new_payload.get("service_address_postal_code"),
                    "country": new_payload.get("service_address_country_code"),
                    "created_by": new_payload.get("created_by"),
                    "is_deleted": False,
                    "is_active": True
                }
                
                # Remove None values
                customers_data = {k: v for k, v in customers_data.items() if v is not None}
                
                # Prepare data for rev_customers table
                rev_customers_data = {
                    "rev_customer_id": str(rev_customer_id),
                    "customer_name": new_payload.get("service_address_company_name"),
                    "created_by": new_payload.get("created_by"),
                    "is_deleted": False,
                    "is_active": True,
                    "rev_parent_customer_id": parent_rev_customer_id if parent_rev_customer_id not in (None, "None", "") else None,
                    "parent_customer_id": parent_customer_id,
                    "child_count": 0,
                    "integration_authentication_id": integration_auth_id,
                    "status": new_payload.get("status"),
                    "bill_profile_id": new_payload.get("bill_profile") or new_payload.get("bill_profile_id"),
                }
                
                # Remove None values
                rev_customers_data = {k: v for k, v in rev_customers_data.items() if v is not None}
                
                # Insert into customers table first
                # customers_insert_response = dbs.insert_data(customers_data, "customers")
                
                # Insert into rev_customers table
                rev_customers_insert_response = dbs.insert_data(rev_customers_data, "revcustomer")
                
                # Add rev_customer_id to customers_data to establish relationship
                if rev_customers_insert_response:
                    customers_data["rev_customer_id"] = rev_customers_insert_response

                
                rev_customers_insert_response = str(rev_customers_insert_response)
                # Insert into customers table (child record)
                customers_insert_response = dbs.insert_data(customers_data, "customers")
                
                # Ensure insert responses are dictionaries for consistency
                if isinstance(customers_insert_response, int):
                    customers_insert_response = {"success": True, "inserted_id": customers_insert_response}
                elif not isinstance(customers_insert_response, dict):
                    customers_insert_response = {
                        "success": False,
                        "message": "Unknown insert response format for customers table",
                    }
                
                if isinstance(rev_customers_insert_response, (int, str)):
                    # Treat integer ID or UUID string the same way
                    rev_customers_insert_response = {
                        "success": True,
                        "inserted_id": rev_customers_insert_response
                    }

                elif not isinstance(rev_customers_insert_response, dict):
                    rev_customers_insert_response = {
                        "success": False,
                        "message": f"Unknown insert response format for rev_customers table {type(rev_customers_insert_response)} ",
                    }

                
                # Create the response data including both the API response and insert responses
                response_data = {
                    "flag": True,
                    "message": message,
                    "api_response": api_response_data,
                    "customers_insert_response": customers_insert_response,
                    "rev_customers_insert_response": rev_customers_insert_response,
                }
                
                return response_data
            else:
                # API call failed, return error message
                response_data = {"flag": False,
                    "message":f"Failed to retrieve data from client API: {api_response.status_code} - {api_response.text}"
                }
                return response_data


        elif action == "update":
            # Remove fields not in 'customers' table from 'changed_data'
            allowed_fields = [
                "id",
                "customer_bill_period_end_day",
                "customer_bill_period_end_hour",
                "modified_by",
                "modified_date",
            ]
            filtered_changed_data = {
                k: v
                for k, v in changed_data.items()
                if k in allowed_fields and v is not None
            }

            # Ensure 'id' is available for WHERE clause
            if "id" in filtered_changed_data:
                dbs.update_dict(
                    "customers",
                    filtered_changed_data,
                    {"id": filtered_changed_data["id"]},
                )
                message = "Update successful."
                response_data = {"flag": True, "message": message}
            else:
                message = "Update failed. Missing required ID for update."
                response_data = {"flag": False, "message": message}

            return response_data

        elif action == "info":
            line_item_count = 0  # Initialize with a default value

            query = """
                SELECT COUNT(dt.customer_id) AS TotalSimCardCount
                    FROM public.device jd
                    INNER JOIN public.device_tenant dt ON jd.id = dt.device_id
                    INNER JOIN public.customers s ON dt.customer_id = s.id
                    WHERE jd.is_active = 'true'
                        AND jd.is_deleted = 'false'
                        AND (dt.customer_id IS NOT NULL
                            AND s.id IS NOT NULL
                            AND s.id = %s)
                        AND dt.tenant_id = %s;
            """
            params = [data["info_data"]["id"], tenant_id]

            # Execute the query
            result = dbs.execute_query(query, params=params)

            if isinstance(result, list) and result:
                line_item_count = result[0].get("line_item_count", 0)
            elif isinstance(result, pd.DataFrame) and not result.empty:
                line_item_count = result.iloc[0].get("line_item_count", 0)

            response_data = {
                "flag": True,
                "message": f"{action} Successfully",
                "line_item_count": str(line_item_count),
            }
            return response_data
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        message = "Unable to save the data"
        response = {"flag": False, "message": message}

        return response



def people_bulk_import_data(data):
    username = data.get("username")
    insert_flag = data.get("insert_flag", "append")
    tenant_database = data.get("db_name", "")

    # Initialize the database connection
    database = DB(tenant_database, **db_config)

    # Check if blob data is provided
    blob_data = data.get("blob")
    if not blob_data:
        logging.warning("Blob data not provided")
        return {"flag": False, "message": "Blob data not provided"}

    try:
        # Extract and decode the blob data
        blob_data = blob_data.split(",", 1)[1]
        blob_data += "=" * (-len(blob_data) % 4)  # Padding for base64 decoding
        file_stream = BytesIO(base64.b64decode(blob_data))

        # Read the data into a DataFrame
        uploaded_dataframe = pd.read_excel(file_stream, engine="openpyxl")

        # SQL query for fetching columns dynamically
        query = """
            SELECT
                C.tenant_name AS tenant_name,
                RA.agent_name AS agent_name,
                RC.customer_name AS customer_name,
                RC.rev_customer_id AS rev_customer_id,
                C.customer_bill_period_end_day,
                C.customer_bill_period_end_hour
            FROM
                revcustomer RC
            LEFT JOIN
                revagent RA ON RA.rev_agent_id = RC.agent_id
            LEFT JOIN
                customers C ON C.rev_customer_id = RC.id
            LIMIT 100 OFFSET 0;
        """
        # Fetch the columns and data from the query
        result_df = database.execute_query(query, True)

        uploaded_dataframe.columns = uploaded_dataframe.columns.str.replace(
            " ", "_"
        ).str.lower()
        print(uploaded_dataframe.columns, "333333333333333333")
        # Normalize DataFrame columns
        uploaded_columns = [col.strip().lower() for col in uploaded_dataframe.columns]
        query_columns = [col.strip().lower() for col in result_df.columns]

        # Compare the column names
        if sorted(uploaded_columns) != sorted(query_columns):
            logging.warning("Column mismatch detected")
            return {
                "flag": False,
                "message": "Columns didn't match",
                "uploaded_columns": list(set(uploaded_columns) - set(query_columns)),
                "query_columns": list(set(query_columns) - set(uploaded_columns)),
            }

        # Split uploaded dataframe into separate dataframes for each table
        revcustomer_data = uploaded_dataframe[
            ["customer_name", "rev_customer_id", "agent_name"]
        ]
        revagent_data = uploaded_dataframe[["agent_name"]].drop_duplicates()
        customers_data = uploaded_dataframe[
            [
                "tenant_name",
                "customer_name",
                "customer_bill_period_end_day",
                "customer_bill_period_end_hour",
            ]
        ]

        # Perform the insertion
        if insert_flag == "append":
            database.insert(
                revcustomer_data, "revcustomer", if_exists="append", method="multi"
            )
            database.insert(
                revagent_data, "revagent", if_exists="append", method="multi"
            )
            database.insert(
                customers_data, "customers", if_exists="append", method="multi"
            )
            logging.info("Append operation completed successfully")
            return {"flag": True, "message": "Append operation is done"}

        logging.error("Invalid insert_flag value")
        return {"flag": False, "message": "Invalid insert_flag value"}

    except Exception as e:
        return {
            "flag": False,
            "message": f"An error occurred during the import: {str(e)}",
        }


def convert_timestamp(data):
    logging.debug(f"Converting data: {data}")
    if isinstance(data, pd.Timestamp):
        logging.debug(f"Converting pd.Timestamp: {data}")
        return data.strftime("%m-%d-%Y %H:%M:%S")
    elif isinstance(data, dict):
        logging.debug("Processing dictionary in convert_timestamp")
        return {k: convert_timestamp(v) for k, v in data.items()}
    elif isinstance(data, list):
        logging.debug("Processing list in convert_timestamp")
        return [convert_timestamp(v) for v in data]
    else:
        logging.debug(f"No conversion needed for type: {type(data)}")
        return data


def get_user_acess_filters(username, database,tenant_name,role_name):
    """
    Fetches user-specific access filters based on the user's role and tenant association.

    Args:
        database (DB): An instance of the DB connection (for tenant-specific database).
        tenant_name (str): The name of the tenant the user belongs to.
        role_name (str): The role of the user (e.g., Admin, Super Admin, etc.)

    Returns:
        tuple:
            - customers (tuple or None): List of allowed customer names.
            - service_providers (tuple or None): List of allowed service providers.
            - billing_account_number (tuple or None): Allowed billing account numbers.
            - feature_codes (tuple or None): List of allowed feature codes.
            - customer_rate_plan_name (tuple or None): List of allowed rate plan names.
    """
    if role_name in ('Super Admin','Partner Admin','Agent Partner Admin'):
        return None, None, None, None, None
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
        ["id", "db_name","parent_tenant_id"]
    )

    tenant_id = tenant_data["id"].to_list()[0]
    db_name = tenant_data["db_name"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    if tenant_id:
        tenant_id=int(tenant_id)

    database = DB(db_name, **db_config_withoutfilter)
    if parent_tenant_id and role_name in ('Admin'):
        try:
            # Sample query execution
            query = f'''SELECT customers, service_provider, customer_names, rate_plan_name, feature_codes, billing_account_number FROM tenant_based_partner_admin_filters WHERE tenant_id={tenant_id}
            '''
            df = common_utils_database.execute_query(query, True)

            # Initialize sets to accumulate unique values
            merged_customers = set()
            merged_service_provider = set()
            merged_rate_plan_name = set()
            merged_feature_codes = set()
            merged_billing_account_number = set()

            # Iterate over each row and collect values
            for index, row in df.iterrows():
                # Merge customers and customer_names
                for col in ['customers', 'customer_names']:
                    try:
                        values = json.loads(row[col]) if row[col] else []
                        merged_customers.update(values)
                    except Exception as e:
                        logging.error(f"### Error parsing {col}: {e}")


                # Process other columns
                for col, target in [
                    ('service_provider', merged_service_provider),
                    ('rate_plan_name', merged_rate_plan_name),
                    ('feature_codes', merged_feature_codes)
                ]:
                    try:
                        values = json.loads(row[col]) if row[col] else []
                        target.update(values)
                    except Exception as e:
                        logging.error(f"### Error parsing {col}: {e}")

                # Handle billing_account_number separately (not a list)
                billing_value = row['billing_account_number']
                if pd.notna(billing_value):
                    merged_billing_account_number.add(str(billing_value))

            # Final variables
            customers = tuple(sorted(merged_customers)) if merged_customers else None
            service_providers = tuple(sorted(merged_service_provider)) if merged_service_provider else None
            customer_rate_plan_name = tuple(sorted(merged_rate_plan_name)) if merged_rate_plan_name else None
            feature_codes = tuple(sorted(merged_feature_codes)) if merged_feature_codes else None
            billing_account_number = tuple(sorted(merged_billing_account_number)) if merged_billing_account_number else None
            return customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name
        except Exception as e:
            logging.exception(f"### Error while fetching filters of Partner for the tenant: {e}")
            return None, None, None, None, None
    query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{username}' and tenant_id={tenant_id}"
    filters = common_utils_database.execute_query(query, True)

    try:
        customer_group = filters["customer_group"].to_list()[0]

    except Exception as e:
        logging.error(f"Exception occurred while getting customer_group: {str(e)}")
        customer_group = None    

    customer_group_data = None
    customer_rate_plan_name = None
    billing_account_number = None
    feature_codes = None
    customer_names=None

    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )
        logging.info(f'### customer_group_data:{customer_group_data}')

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name:{e}")
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))
            except Exception as e:
                logging.exception(f"### Error extracting rate_plan_name: {e}")
                customer_names=None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None

            except Exception as e:
                logging.exception(f"### Error extracting billing_account_number: {e}")
                billing_account_number=None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception(f"### Error extracting feature_codes : {e}")
    if customer_names is None:
        try:
            customers = tuple(json.loads(filters["customers"].to_list()[0]))
        except Exception as e:
            logging.error(f"Error while loading customers from filters: {e}")
            customers = None
    else:
        customers=customer_names

    try:
        service_providers = tuple(json.loads(filters["service_provider"].to_list()[0]))
    except Exception as e:
        logging.error(f"Error while loading service providers from filters: {e}")
        service_providers = None
    return customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name



def people_list_view(data):
    """
    Description: Retrieves emails in list view data from the database.
    Validates the access token and logs the request, then fetches and returns the device history if the token is valid.
    """
    logging.info("Starting people_list_view function")
    # print(f"Request Data: {data}")
    # Database Connection
    try:
        del db_config['customers']
        del db_config['service_providers']
    except:
        logging.info("there are not in confic")
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    role_name = data.get("role_name", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    module_name = data.get("module_name", "")
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    # Initialize data_list to hold customer data
    total_resellers = 0
    return_json_data = {}
    try:
        dbs = DB(tenant_database, **db_config)
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)
        limit = 100  # Set the limit to 100

        logging.info(f"Received request data")
        logging.info(
            f"Module name: {module_name}, Role name: {role_name}, Start page: {start_page}"
        )

        if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]

        # Query to get the list of tenants
        tenant_list = database.get_data("tenant", {"is_active": True, "parent_tenant_id": tenant_id,}, ["tenant_name"]
            )["tenant_name"].to_list()

        # Remove duplicates by converting to a set and back to a list
        tenant_list.append(tenant_name)
        tenant_list = list(set(tenant_list))

        # Sort the list alphabetically
        tenant_list.sort()
        # tenant_query = "SELECT DISTINCT tenant_name FROM tenant WHERE is_active=True"
        # tenant_list = database.execute_query(tenant_query, True)[
        #     "tenant_name"
        # ].to_list()
        logging.info("Fetched tenant list")

        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(database,data)


        tenant_condition = f""" where tenant_id = {tenant_id} """




        # Handle 'NetSapiens Customers'
        if module_name == "NetSapiens Customers":

            customers = []
            service_providers = []
            billing_account_number=[]
            feature_codes=[]
            customer_rate_plan_name=[]
            customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
            print(
                f"customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name", customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name
            )

            if col_sort:
                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]  # Get the first and only pair
                # Construct the ORDER BY clause
                order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
            else:
                # If users is None or empty, we skip the WHERE clause entirely
                order_condition = f"ORDER BY modified_date DESC, customer_name DESC LIMIT 100 OFFSET {start_page}"





            if customers or billing_account_number or feature_codes or customer_rate_plan_name:



                query = f"""
                    SELECT
                        *
                    FROM vw_people_netsapiens_customers_list_view
                """
                filters = []

                # Add filters dynamically
                if customers:
                    if len(customers) == 1:
                        filters.append(f"customer_name = '{customers[0]}'")  # Add single quotes
                    else:
                        filters.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes

                # if service_providers:
                #     if len(service_providers) == 1:
                #         filters.append(f"service_provider = '{service_providers[0]}'")  # Add single quotes
                #     else:
                #         filters.append(f"service_provider IN {tuple(service_providers)}")  # Tuple already includes quotes

                # Append filters to the WHERE clause
                if filters:
                    query += f"""{tenant_condition} """ + " AND ".join(filters)

                # Add the order condition
                query += f" {order_condition}"

                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM vw_people_netsapiens_customers_list_view

                """
                if filters:
                    count_query += " WHERE " + " AND ".join(filters)
            else:
                query = f"""
                    SELECT
                        *
                    FROM vw_people_netsapiens_customers_list_view
                    {tenant_condition}
                    {order_condition}
                """
                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM vw_people_netsapiens_customers_list_view

                """


            # Execute the query using the existing execute_query function
            result = dbs.execute_query(query, True)
            total_count_result = dbs.execute_query(count_query, True)
            total_count = (
                total_count_result["total_count"].iloc[0]
                if not total_count_result.empty
                else 0
            )
            pages = {"start": start_page, "end": end_page, "total": int(total_count)}
            logging.info("Query executed for NetSapiens Customers")

            # Get headers mapping
            headers_map = get_headers_mapping(
                tenant_database,
                ["NetSapiens Customers"],
                role_name,
                "",
                "",
                "",
                "",
                data,
                database,
            )

            if not result.empty:
                if 'netsapiens_customer_id' in result.columns:
                    result['netsapiens_customer_id'] = result['netsapiens_customer_id'].astype('Int64')
                df_dict = result.to_dict(orient="records")
                df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
                df_dict = serialize_data(df_dict)

                logging.info(f"Data fetched for NetSapiens Customers")

                # Prepare final response
                return_json_data.update(
                    {
                        "flag": True,
                        "message": "Data fetched successfully",
                        "data": df_dict,
                        "tenant_name": tenant_list,
                        "headers_map": headers_map,
                        "pages": pages,
                    }
                )
                return return_json_data
            else:
                return_json_data.update(
                    {"flag": True, "data": [], "message": "No data found!","tenant_name": tenant_list,
                        "headers_map": headers_map}
                )
                logging.warning("No data found for NetSapiens Customers")
                return return_json_data

        # Handle 'Bandwidth customers'
        elif module_name == "Bandwidth Customers":


            customers = []
            service_providers = []
            billing_account_number=[]
            feature_codes=[]
            customer_rate_plan_name=[]
            customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
            print(
                f"customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name", customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name
            )

            if col_sort:
                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]  # Get the first and only pair
                # Construct the ORDER BY clause
                order_condition = (
                    f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
                )
            else:
                # If users is None or empty, we skip the WHERE clause entirely
                order_condition = f"ORDER BY modified_date DESC, customer_name ASC LIMIT 100 OFFSET {start_page}"



            if customers or billing_account_number or feature_codes or customer_rate_plan_name:
                filters = []


                query = f"""
                    SELECT
                        *
                    FROM vw_people_bandwidth_customers
                """

                # Add filters dynamically
                if customers:
                    if len(customers) == 1:
                        filters.append(f"customer_name = '{customers[0]}'")  # Add single quotes
                    else:
                        filters.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes

                # if service_providers:
                #     if len(service_providers) == 1:
                #         filters.append(f"service_provider = '{service_providers[0]}'")  # Add single quotes
                #     else:
                #         filters.append(f"service_provider IN {tuple(service_providers)}")  # Tuple already includes quotes

                # Append filters to the WHERE clause
                if filters:
                    query += f"""{tenant_condition} """ + " AND ".join(filters)

                # Add the order condition
                query += f" {order_condition}"

                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM vw_people_bandwidth_customers

                """

                if filters:
                    count_query += " WHERE " + " AND ".join(filters)



            else:
                query = f"""
                    SELECT
                        *
                    FROM vw_people_bandwidth_customers
                    {tenant_condition}
                    {order_condition}
                    """

                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM vw_people_bandwidth_customers

                """

            print(query, "111111111111111111111111111111")
            # Execute the query using the existing execute_query function
            result = dbs.execute_query(query, True)

            total_count_result = dbs.execute_query(count_query, True)
            total_count = (
                total_count_result["total_count"].iloc[0]
                if not total_count_result.empty
                else 0
            )
            logging.info("Query executed for Bandwidth Customers")
            headers_map = get_headers_mapping(
                tenant_database,
                ["Bandwidth Customers"],
                role_name,
                "",
                "",
                "",
                "",
                data,
                database,
            )

            # Check if result is empty
            if result.empty:
                return_json_data.update(
                    {
                        "flag": True,
                        "data": [],
                        "message": "No data found for Bandwidth customers!",
                        "tenant_name": tenant_list,
                        "headers_map": headers_map,
                        "total_resellers": total_resellers,
                    }
                )
                logging.warning("No data found for Bandwidth customers")
                return return_json_data

            # Process and format the data
            df_dict = result.to_dict(orient="records")
            # total = len(df_dict)
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)
            pages = {"start": start_page, "end": end_page, "total": int(total_count)}

            logging.info("Returning data response")
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "tenant_name": tenant_list,
                    "headers_map": headers_map,
                    "pages": pages,
                    "total_resellers": total_resellers,
                }
            )
            return return_json_data
        elif module_name == "E911 Customers":
            customers = []
            service_providers = []
            billing_account_number=[]
            feature_codes=[]
            customer_rate_plan_name=[]
            customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
            print(
                f"customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name", customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name
            )

            if col_sort:
                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]  # Get the first and only pair
                # Construct the ORDER BY clause
                order_condition = (
                    f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
                )
            else:
                # If users is None or empty, we skip the WHERE clause entirely
                order_condition = (
                    f"ORDER BY modified_date DESC LIMIT 100 OFFSET {start_page}"
                )

            # filters_list = []
            # if customers:
            #     if len(customers) == 1:
            #         filters_list.append(f"customer_name = '{customers[0]}'")  # Add single quotes
            #     else:
            #         filters_list.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes

            user_query = f"""
                SELECT CONCAT(first_name, ' ', last_name) AS full_name
                FROM users
                WHERE username = '{username}'
            """



            # Execute query safely
            user_result = database.execute_query(user_query, True)

            if user_result is not None and not user_result.empty:
                users = user_result["full_name"].tolist()


            # Construct the WHERE clause conditionally based on 'users'
            if customers:
                users_condition = (
                    f"""AND created_by IN ({','.join(f"'{user}'" for user in users)}) """
                    f"""OR modified_by IN ({','.join(f"'{user}'" for user in users)}) """
                    f"""OR deleted_by IN ({','.join(f"'{user}'" for user in users)})"""
                )
            else:
                users_condition = ""


            if service_providers or customers or billing_account_number or feature_codes or customer_rate_plan_name:


                query = f"""
                    SELECT
                    id,
                    account_name,
                    account_id,
                    created_by,
                    created_date,
                    modified_by,
                    modified_date,
                    deleted_by,
                    deleted_date,
                    is_active,
                    is_deleted
                    FROM e911customers
                    WHERE is_active = 'true' AND is_deleted = 'false'
                    {users_condition}
                    {order_condition}
                """
                count_query = f"""
                    SELECT COUNT(*) AS total_count
                        FROM e911customers
                WHERE is_active = 'true' AND is_deleted = 'false'
                {users_condition}

                """
            else:
                query = f"""
                SELECT
                id,
                account_name,
                account_id,
                created_by,
                created_date,
                modified_by,
                modified_date,
                deleted_by,
                deleted_date,
                is_active,
                is_deleted
                FROM e911customers
                WHERE is_active = 'true' AND is_deleted = 'false'
                {order_condition}
                """
                count_query = """
                    SELECT COUNT(*) AS total_count
                        FROM e911customers
                WHERE is_active = 'true' AND is_deleted = 'false'

                """

            # Execute the query using the existing execute_query function
            print(query, "11111111111111111111111111111122222222222222")
            result = dbs.execute_query(query, True)


            total_count_result = dbs.execute_query(count_query, True)
            total_count = (
                total_count_result["total_count"].iloc[0]
                if not total_count_result.empty
                else 0
            )
            logging.info("Query executed for e911customers")
            headers_map = get_headers_mapping(
                tenant_database,
                ["E911 Customers"],
                role_name,
                "",
                "",
                "",
                "",
                data,
                database,
            )

            # Check if result is empty
            if result.empty:
                return_json_data.update(
                    {
                        "flag": True,
                        "data": [],
                        "message": "No data found for E911 Customers!",
                        "tenant_name": tenant_list,
                        "headers_map": headers_map,
                        "total_resellers": total_resellers,
                    }
                )
                logging.info("No data found for E911 Customers")
                return return_json_data

            # Process and format the data
            df_dict = result.to_dict(orient="records")
            # total = len(df_dict)
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)
            pages = {"start": start_page, "end": end_page, "total": int(total_count)}

            logging.info("Returning data response")
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "tenant_name": tenant_list,
                    "headers_map": headers_map,
                    "pages": pages,
                    "total_resellers": total_resellers,
                }
            )
            try:
                audit_data_user_actions = {
                    "service_name": "People",
                    "created_date": request_received_at,
                    "created_by": username,
                    "status": str(response["flag"]),
                    "session_id": ui_session_id,
                    "tenant_name": tenant_name,
                    "module_name": "people",
                    "comments": "list view of people module",
                    "request_received_at": request_received_at,
                }

                database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"Exception is {e}")
            return return_json_data

    except Exception as e:
        logging.exception("An error occurred in people_list_view")
        message = "Unable to save the data"
        # Error Management
        error_data = {
            "service_name": "People",
            "error_messag": message,
            "error_type": e,
            "user": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "People",
        }
        database.log_error_to_db(error_data, "error_table")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, [module_name], role_name, "", "", "", "", data, database
        )
        response={
                        "flag": True,
                        "data": [],
                        "message": "No data found for E911 Customers!",
                        "tenant_name": [],
                        "headers_map": headers_map,
                        "total_resellers": [],
                    }
        return response



# def convert_timestamp_data(df_dict, tenant_time_zone):
#     """Convert timestamp columns in the provided dictionary list to the tenant's timezone."""
#     # Create a timezone object
#     target_timezone = timezone(tenant_time_zone)

#     # List of timestamp columns to convert
#     timestamp_columns = [
#         "created_date",
#         "modified_date",
#         "deleted_date",
#     ]  # Adjust as needed based on your data

#     # Convert specified timestamp columns to the tenant's timezone
#     for record in df_dict:
#         for col in timestamp_columns:
#             if col in record and record[col] is not None:
#                 # Convert to datetime if it's not already
#                 timestamp = pd.to_datetime(record[col], errors="coerce")
#                 if timestamp.tz is None:
#                     # If the timestamp is naive, localize it to UTC first
#                     timestamp = timestamp.tz_localize("UTC")
#                 # Now convert to the target timezone
#                 record[col] = timestamp.tz_convert(target_timezone).strftime(
#                     "%m-%d-%Y %H:%M:%S"
#                 )  # Ensure it's a string
#     return df_dict


# def serialize_data(data):
#     """Recursively convert pandas objects in the data structure to serializable types."""
#     if isinstance(data, list):
#         return [serialize_data(item) for item in data]
#     elif isinstance(data, dict):
#         return {key: serialize_data(value) for key, value in data.items()}
#     elif isinstance(data, pd.Timestamp):
#         return data.strftime("%m-%d-%Y %H:%M:%S")  # Convert to string
#     else:
#         return data  # Return as is if not a pandas object
import json
def get_customers_list_view_data(data):
    """
    Description: Retrieves emails in list view data from the database.
    Validates the access token and logs the request, then fetches and returns the device history if the token is valid.
    """
    logging.info("Starting people_list_view function")
    # print(f"Request Data: {data}")
    # Database Connection
    try:
        if db_config and 'customers' in db_config:
            db_config.pop('customers')
        if db_config and 'service_providers' in db_config:
            db_config.pop('service_providers')
    except Exception as e:
        logging.exception("Error while removing keys from db_config")
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    role_name = data.get("role_name", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    module_name = data.get("module_name", "")
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    # Initialize data_list to hold customer data
    total_resellers = 0
    return_json_data = {}
    try:
        dbs = DB(tenant_database, **db_config_withoutfilter)
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)
        limit = 100  # Set the limit to 100
        customers=None

        logging.info(f"Received request data")
        logging.info(
            f"Module name: {module_name}, Role name: {role_name}, Start page: {start_page}"
        )

        if tenant_name == "Altaworx Test":
            tenant_name ="Altaworx"
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(database,data)
        customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
        print(
            f"customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name", customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name
        )

        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            # Construct the ORDER BY clause
            order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
        else:
            # If users is None or empty, we skip the WHERE clause entirely
            order_condition = f"ORDER BY id DESC LIMIT 100 OFFSET {start_page}"
        if customers:
            query = f"""
                SELECT
                id,
                    customer_name,
                    netsapiens_type,
                    inactivity_start,
                    inactivity_end,
                    address1,
                    address2,
                    city,
                    postal_code,
                    county_parish_borough,
                    state,
                    country,
                    customer_bill_period_end_day,
                    customer_bill_period_end_hour,
                    apt_suite,
                    tenant_name
                    FROM public.customers
                    WHERE is_active = TRUE
                    AND tenant_id = {tenant_id}


            """
            filters = []

            # Add filters dynamically
            if customers:
                print(customers, "customerscustomerscustomerscustomers")
                customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{username}'
                '''
                customers_df=dbs.execute_query(customers_query,True)
                if not customers_df.empty:
                    existing_customers=customers_df['customer_name'].to_list()
                    if existing_customers:
                        existing_customers_tuple = tuple(existing_customers)
                        print(existing_customers_tuple, "existing_customersexisting_customersexisting_customers")
                        # Concatenate the tuple customers with the new tuple (existing_customers_tuple)
                        customers = customers + existing_customers_tuple  # Concatenating two tuples
                if len(customers) == 1:
                    filters.append(f"customer_name = '{customers[0]}'")  # Add single quotes
                else:
                    filters.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes
            # Append filters to the WHERE clause
            if filters:
                print(filters, "filtersfiltersfiltersfilters")
                query += " AND " + " AND ".join(filters)


            # Add the order condition
            query += f" {order_condition}"

            count_query = f"""
                SELECT COUNT(*)  as total_count
                FROM public.customers
                WHERE is_active = TRUE

                and tenant_id = {tenant_id}


            """
            if filters:
                count_query += " AND " + " AND ".join(filters)
        else:
            query = f"""
                SELECT
                id,
                    customer_name,
                    netsapiens_type,
                    inactivity_start,
                    inactivity_end,
                    address1,
                    address2,
                    city,
                    postal_code,
                    county_parish_borough,
                    state,
                    country,
                    customer_bill_period_end_day,
                    customer_bill_period_end_hour,
                    apt_suite,
                    tenant_name
                    FROM public.customers
                    WHERE is_active = TRUE
                    AND rev_customer_id IS NULL
                    and tenant_id = {tenant_id}


                {order_condition}
            """
            count_query = f"""
                SELECT COUNT(*) as total_count
                FROM public.customers
                WHERE is_active = TRUE
                and tenant_id = {tenant_id}


            """


        # Execute the query using the existing execute_query function
        print("queryquery11111query",query, "queryquery11111query")
        result = dbs.execute_query(query, True)
        total_count_result = dbs.execute_query(count_query, True)
        total_count = (
            total_count_result["total_count"].iloc[0]
            if not total_count_result.empty
            else 0
        )
        pages = {"start": start_page, "end": end_page, "total": int(total_count)}
        logging.info("Query executed for  Customers")

        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            ["Customers"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            database,
        )
        # First, get the tenant record by name
        tenant_row = database.get_data(
            "tenant", {"tenant_name": tenant_name, "is_active": True},
            ["id", "parent_tenant_id"]
        )

        tenant_id = tenant_row["id"].to_list()[0] if not tenant_row.empty else None
        parent_tenant_id = tenant_row["parent_tenant_id"].to_list()[0] if not tenant_row.empty else None

        if parent_tenant_id:  # It's a subtenant
            # Get parent tenant details
            parent_row = database.get_data("tenant", {"id": parent_tenant_id, "is_active": True}, ["id", "tenant_name"])
            parent_tenant = {parent_row["tenant_name"].to_list()[0]: parent_tenant_id}

            # Get sibling subtenants
            sub_tenants_data = database.get_data(
                "tenant", {"parent_tenant_id": parent_tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenant = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }

        else:  # It's a parent tenant
            parent_tenant = {tenant_name: tenant_id}
            sub_tenants_data = database.get_data(
                "tenant", {"parent_tenant_id": tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenants = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }
            sub_tenant=dict(sorted(sub_tenants.items()))
        # Final result
        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)

            logging.info(f"Data fetched for Customers")

            # Prepare final response
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "tenant_name":parent_tenant,
                    "sub_tenant": sub_tenant,
                    "headers_map": headers_map,
                    "pages": pages,"tenant_name":tenant_name
                }
            )
            #return return_json_data
        else:
            return_json_data.update(
                {"flag": True, "data": [], "message": "No data found!","tenant_name": tenant_list,
                    "headers_map": headers_map}
            )
            logging.warning("No data found for  Customers")
            #return return_json_data
        logging.info("Returning data response")
        return_json_data.update(
            {
                "flag": True,
                "message": "Data fetched successfully",
                "data": df_dict,
                "tenant_name":parent_tenant,
                    "sub_tenant": sub_tenant,
                "headers_map": headers_map,
                "pages": pages,
            }
        )
        try:
            audit_data_user_actions = {
                "service_name": "People",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "people",
                "comments": "list view of Customers module",
                "request_received_at": request_received_at,
            }

            database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return return_json_data

    except Exception as e:
        logging.exception("An error occurred in people_list_view")
        message = "Unable Fetch the Customers data"
        # Error Management
        error_data = {
            "service_name": "People",
            "error_messag": message,
            "error_type": e,
            "user": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "People",
        }
        database.log_error_to_db(error_data, "error_table")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, ["Customers"], role_name, "", "", "", "", data, database
        )
        response={
                        "flag": True,
                        "data": [],
                        "message": "No data found for Customers!",
                        "tenant_name": [],
                        "headers_map": headers_map,
                    }
        return response

def create_customer(data):
    """
    Processes customer rate plan data by creating or updating rate plans in the database.
    Validates input, handles errors, and logs actions.

    Parameters:
        data (dict): A dictionary containing the rate plan data to process, including:
            - 'Partner' (str): The partner name.
            - 'session_id' (str): The session ID associated with the request.
            - 'username' (str): The username of the requester.
            - 'rate_plan_data' (dict): The rate plan data containing the fields to update.
            - 'action' (str): Action to perform, either 'create' or 'update'.
            - 'table_name' (str): The database table for storing rate plans.
            - 'db_name' (str): The tenant database name.

    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
    """
    try:
        logging.info(f"create_customer data : {data}")

        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        new_data=data.get('new_data',{})
        tenant_name = new_data.get("tenant_name", "")
        action=data.get("action", "")


        if action=='edit':
            cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            updated_id=cleaned_data.pop("id", None)
            if updated_id:
                database.update_dict('customers', cleaned_data, {'id': updated_id})
        else:
            tenant_id=common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"]).iloc[0]["id"]
            if tenant_id:
                new_data["tenant_id"]=int(tenant_id)
            new_data["created_by"]=data.get("username", "")
            cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            logging.info(f"create_customer cleaned_data: {cleaned_data}")
            # fetch customer_name from cleaned_data and check customer already exists in db
            customer_name=cleaned_data.get("customer_name", "")
            existing_customers=database.get_data("customers", {"customer_name": customer_name}, ["customer_name"])
            if not existing_customers.empty:
                raise Exception("Customer already exists")
            insert_id = database.insert_data(cleaned_data, "customers")
            logging.info(f"customer  created successfully with ID: {insert_id}")
        try:
            audit_data_user_actions = {
                "service_name": "People Module",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Sim Management",
                "comments": "Creating the customers module data",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return {
            "flag": True,
            "message": f"Customers created successfully",
            "status_code": 200,
        }

    except Exception as e:
        logging.error(f"Error processing customer rate plans: {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "People Module",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "create_customers",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return {
            "flag": False,
            "message": f"Error processing customers : {e}",
            "status_code": 500,
        }
    


def create_billing_platform_customer(data):
    """
    Processes customer rate plan data by creating or updating rate plans in the database.
    Validates input, handles errors, and logs actions.

    Parameters:
        data (dict): A dictionary containing the rate plan data to process, including:
            - 'Partner' (str): The partner name.
            - 'session_id' (str): The session ID associated with the request.
            - 'username' (str): The username of the requester.
            - 'rate_plan_data' (dict): The rate plan data containing the fields to update.
            - 'action' (str): Action to perform, either 'create' or 'update'.
            - 'table_name' (str): The database table for storing rate plans.
            - 'db_name' (str): The tenant database name.

    Returns:
        dict: A response dictionary with:
            - 'flag' (bool): Indicates success (True) or failure (False).
            - 'message' (str): Describes the result of the operation.
    """
    logging.info(f"### Starting create_billing_platform_customer function with data: {data}")
    try:
        request_received_at = data.get("request_received_at", "")
        username = data.get("username", "")
        sessionID = data.get("sessionID", "")
        Partner = data.get("Partner", "")
        logging.info(f"### Processing customer data: {data}")

        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        # try:
        # # Initialize database connection
        #     killbill_database = DB("billing_platform", **common_utils_database_config)
        # except Exception as e:
        #     logging.info(f"### Database connection failed: {e}")
        #     return {"flag": False, "message": "Database connection error"}

        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        new_data = data.get('new_data', {})
        tenant_name = new_data.get("tenant_name", "")
        action = data.get("action", "")

        if action == 'edit':
            cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            updated_id = cleaned_data.pop("id", None)
            if updated_id:
                database.update_dict('customers', cleaned_data, {'id': updated_id})
        else:
            tenant_id=common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"]).iloc[0]["id"]
            if tenant_id:
                new_data["tenant_id"] = int(tenant_id)
            new_data["created_by"] = data.get("username", "")
            cleaned_data = {k: v for k, v in new_data.items() if v != ''}
            
            # Insert customer data
            insert_id = database.insert_data(cleaned_data, "customers")
            logging.info(f"### Customer created successfully with ID: {insert_id}")
            
            """
            # Prepare and insert customer profile
            profile_data = {
                "customer_name": cleaned_data.get("customer_name", ""),
                "billing_platform_customer_id": insert_id,
                "created_by": data.get("username", ""),
                "is_active": True,
                "is_deleted": False
            }
            # Insert into customer_profiles
            p = killbill_database.insert_data(profile_data, "customer_profiles")
            
            logging.info(f"Customer profile created successfully with ID: {p}")
            logging.info(f"Customer profile created successfully for customer ID: {insert_id}")

            # Update the customers table with the billing_platform_customer_id
            database.update_dict('customers', {'billing_platform_customer_id': p}, {'id': insert_id})
            logging.info(f"Updated customers table with billing_platform_customer_id: {p} for customer ID: {insert_id}")
            """
        
        response = {
            "flag": True,
            "message": "Customer processed successfully",
            "status_code": 200,
        }

        # Audit logging
        try:
            audit_data_user_actions = {
                "service_name": "create_billing_platform_customer",
                "created_by": username ,
                "status": str(response['flag']),
                "session_id": sessionID ,
                "tenant_name": Partner ,
                "module_name": "People Module",
               "comments": f"Created new customer record with data: {json.dumps(serialize_data(cleaned_data))}",
                "request_received_at": request_received_at ,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging exception: {e}")

        return response 
    except Exception as e:
        logging.exception("### Error processing customer:")
        message = f"Exception in create_billing_platform_customer for user {username}"
        common_utils_database.log_error_to_db(
            {
                "service_name": "create_billing_platform_customer",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": username ,
                "session_id": sessionID ,
                "tenant_name": Partner ,
                "comments": message ,
                "module_name": "People Module",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {
            "flag": False,
            "message": f"Error processing customer: {e}",
            "status_code": 500,
        }

def db_name_to_billing_platform_db(db_name,mode):
    """
    Splits the payload by '_beta' and appends '_billing_platform_beta'.
    Example: 'altaworx_central_beta' → 'altaworx_central_billing_platform_beta'
    """
    if mode.lower()=='beta':
        try:
            return db_name.split("_beta")[0] + "_billing_platform_beta"
        except Exception as e:
            logging.error(f"Failed to get billing platform db name: {e}")
            return None
    elif mode.lower()=='prod':
        try:
            return db_name + "_billing_platform"
        except Exception as e:
            logging.error(f"Failed to get billing platform db name: {e}")
            return None
    else:
        return None
 

def get_billing_platform_customer_list_view_data(data):
    """
    Fetches and returns a list view of Billing Customers along with pagination, 
    tenant details, dropdowns, and headers, based on user role and permissions.

    Args:
        data (dict): Input dictionary containing:
            - role_name (str): User role
            - tenant_name (str): Tenant name
            - module_name (str): Module being accessed
            - db_name (str): Target database name

    Returns:
        dict: A JSON-style dictionary with the following keys:
            - flag (bool): Success or failure flag
            - message (str): Response message
            - data (list): List of customer records
            - tenant_name (dict): Parent tenant info
            - sub_tenant (dict): Sub-tenant mapping
            - headers_map (dict): Column header mappings
            - pages (dict): Pagination details
            - account_type (list): Account type options
            - btn_provider (list): Dropdown of service providers
            - sales_person (list): Dropdown of sales users
            - parent_accounts (list): Parent account number + name options
            - state (list): List of states from service locations
    """
    logging.info(f"### Starting people_list_view function request data is {data}")
    # Database Connection
    try:
        if db_config and 'customers' in db_config:
            db_config.pop('customers')
        if db_config and 'service_providers' in db_config:
            db_config.pop('service_providers')
    except Exception as e:
        logging.exception(f"### Error while removing keys from db_config : {e}")
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    #killbill_database =  DB(os.environ['BILLING_PLATFORM'], **common_utils_database_config)
    mode = os.environ.get('ENV','')
    billing_platform_db_name = db_name_to_billing_platform_db(data.get("db_name", ""), mode)
    killbill_database = DB(billing_platform_db_name, **db_config)
    role_name = data.get("role_name", "")
    username = data.get("username", "")
    ui_session_id = data.get("sessionID", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    module_name = data.get("module_name", "")
    tenant_database = data.get("db_name", "")
    request_received_at = data.get("request_received_at", "")
    col_sort = data.get("col_sort", "")
    # Initialize data_list to hold customer data
    # total_resellers = 0
    return_json_data = {}
    try:
        dbs = DB(tenant_database, **db_config_withoutfilter)
        start_page = data.get("mod_pages", {}).get("start", 0)
        end_page = data.get("mod_pages", {}).get("end", 100)
        # limit = 100  # Set the limit to 100
        customers=None

        logging.info("### Received request data")
        logging.info(f"### Module name: {module_name}, Role name: {role_name}, Start page: {start_page}")

        if tenant_name == "Altaworx Test":
            tenant_name ="Altaworx"
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
        # # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(database,data)
        customers, service_providers,billing_account_number, feature_codes,customer_rate_plan_name = get_user_acess_filters(username, dbs,tenant_name,role_name)
        logging.info(f"### customers: {customers}, service_providers: {service_providers}, billing_account_number: {billing_account_number}, feature_codes: {feature_codes}, customer_rate_plan_name: {customer_rate_plan_name}")

        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            # Construct the ORDER BY clause
            order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start_page}"
        else:
            # If users is None or empty, we skip the WHERE clause entirely
            order_condition = f"ORDER BY id DESC LIMIT 100 OFFSET {start_page}"
        if customers:
            query = f"""
                SELECT
                id,
                    customer_name,
                    netsapiens_type,
                    inactivity_start,
                    inactivity_end,
                    address1,
                    address2,
                    city,
                    postal_code,
                    county_parish_borough,
                    state,
                    country,
                    customer_bill_period_end_day,
                    customer_bill_period_end_hour,
                    apt_suite,
                    tenant_name,
                    user_type,
                    bp_account_number,
                    bp_account_type,
                    bp_billing_cycle_start_date
                    FROM public.customers
                    WHERE is_active = TRUE 
                    AND tenant_id = {tenant_id}

            """
            filters = []

            # Add filters dynamically
            if customers:
                customers_query=f'''select customer_name from billing_platform_customers where tenant_id={tenant_id} and is_active=True and created_by='{username}'
                '''
                customers_df=dbs.execute_query(customers_query,True)
                if not customers_df.empty:
                    existing_customers=customers_df['customer_name'].to_list()
                    if existing_customers:
                        existing_customers_tuple = tuple(existing_customers)
                        # Concatenate the tuple customers with the new tuple (existing_customers_tuple)
                        customers = customers + existing_customers_tuple  # Concatenating two tuples
                if len(customers) == 1:
                    filters.append(f"customer_name = '{customers[0]}'")  # Add single quotes
                else:
                    filters.append(f"customer_name IN {tuple(customers)}")  # Tuple already includes quotes
            # Append filters to the WHERE clause
            if filters:
                query += " AND " + " AND ".join(filters)


            # Add the order condition
            query += f" {order_condition}"

            count_query = f"""
                SELECT COUNT(*)  as total_count
                FROM public.customers
                WHERE is_active = TRUE 
                and tenant_id = {tenant_id}
            """
            if filters:
                count_query += " AND " + " AND ".join(filters)
        else:
            query = f"""
                SELECT
                id,
                    customer_name,
                    netsapiens_type,
                    inactivity_start,
                    inactivity_end,
                    address1,
                    address2,
                    city,
                    postal_code,
                    county_parish_borough,
                    state,
                    country,
                    customer_bill_period_end_day,
                    customer_bill_period_end_hour,
                    apt_suite,
                    tenant_name, 
                    user_type,
                    bp_account_number,
                    bp_account_type,
                    bp_billing_cycle_start_date
                    FROM public.customers
                    WHERE is_active = TRUE 
                    and tenant_id = {tenant_id}
                    {order_condition}
            """
            count_query = f"""
                SELECT COUNT(*) as total_count
                FROM public.customers
                WHERE is_active = TRUE  
                and tenant_id = {tenant_id}
            """


        # Execute the query using the existing execute_query function
        result = dbs.execute_query(query, True)
        total_count_result = dbs.execute_query(count_query, True)
        total_count = (
            total_count_result["total_count"].iloc[0]
            if not total_count_result.empty
            else 0
        )
        pages = {"start": start_page, "end": end_page, "total": int(total_count)}
        logging.info("### Query executed for  Billing Customers")

        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            ["Billing Customers"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            database,
        )
        # First, get the tenant record by name
        tenant_row = database.get_data(
            "tenant", {"tenant_name": tenant_name, "is_active": True},
            ["id", "parent_tenant_id"]
        )

        tenant_id = tenant_row["id"].to_list()[0] if not tenant_row.empty else None
        parent_tenant_id = tenant_row["parent_tenant_id"].to_list()[0] if not tenant_row.empty else None

        if parent_tenant_id:  # It's a subtenant
            # Get parent tenant details
            parent_row = database.get_data("tenant", {"id": parent_tenant_id, "is_active": True}, ["id", "tenant_name"])
            parent_tenant = {parent_row["tenant_name"].to_list()[0]: parent_tenant_id}

            # Get sibling subtenants
            sub_tenants_data = database.get_data(
                "tenant", {"parent_tenant_id": parent_tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenant = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }
            service_providers=dbs.get_data('serviceprovider',{'is_active':True},['service_provider_name'])
            service_providers=service_providers['service_provider_name'].to_list()

        else:  # It's a parent tenant
            parent_tenant = {tenant_name: tenant_id}
            sub_tenants_data = database.get_data(
                "tenant", {"parent_tenant_id": tenant_id, "is_active": True},
                ["id", "tenant_name"]
            )
            sub_tenants = {
                name: _id
                for name, _id in zip(sub_tenants_data["tenant_name"], sub_tenants_data["id"])
            }
            sub_tenant=dict(sorted(sub_tenants.items()))
            service_providers_query=f'''select distinct service_provider_display_name from sim_management_inventory where tenant_id={tenant_id} and is_active=True'''
            service_providers=dbs.execute_query(service_providers_query,True)['service_provider_display_name'].to_list()
        
        # Final result
        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            df_dict = serialize_data(df_dict)
            # Dropdown: predefined account types
            account_type=['Standard','Parent','Child']

            # Dropdown: fetch active service providers linked with billing periods
            query = """
                SELECT DISTINCT sp.id as id, sp.display_name as display_name
                FROM public.serviceprovider sp
                INNER JOIN public.billing_period bp ON sp.id = bp.service_provider_id
                ORDER BY sp.id DESC
            """
            service_provider_query = dbs.execute_query(query, flag=True)
            provider_list = sorted(set(
                name for name in service_provider_query['display_name'] if name is not None
            ))

            # Dropdown: list of user full names
            users_query=database.get_data(table_name="users",columns=["first_name","last_name"])
            users_list = sorted(set(
                users_query.apply(lambda row: f"{row['first_name']} {row['last_name']}", axis=1).tolist()
            ))
            
            # Dropdown: parent account numbers
            account_numbers=killbill_database.get_data('customer_profiles',{"account_type":'Parent'},["account_number", "customer_name"])
            #account_numbers_list = sorted(account_numbers["account_number"].to_list())
            formatted_list = sorted([
            f"{row['account_number']} - {row['customer_name']}"
            for _, row in account_numbers.iterrows()
        ])


            # Dropdown: service location states
            service_location_list= killbill_database.get_data(table_name="service_locations",condition=None,columns=["states"])["states"].to_list()
            service_locations=sorted(list(set(service_location_list)))

            logging.info("### Data fetched for Billing Customers")

            # Prepare final response
            return_json_data.update(
                {
                    "flag": True,
                    "message": "Data fetched successfully",
                    "data": df_dict,
                    "sub_tenant": sub_tenant,
                    "headers_map": headers_map,
                    "pages": pages,"tenant_name":tenant_name,'account_type':account_type,
                'btn_provider':provider_list,
                'sales_person': users_list,
                'parent_accounts': formatted_list,
                'state': service_locations,
                "service_providers":service_providers
                }
            )
            #return return_json_data
        else:
            return_json_data.update(
                {"flag": True, "data": [], "message": "No data found!",
                    "headers_map": headers_map}
            )
            logging.warning("### No data found for  Customers")
            #return return_json_data
        logging.info("### Returning data response")
        return_json_data.update(
            {
                "flag": True,
                "message": "Data fetched successfully",
                "data": df_dict,
                "tenant_name":parent_tenant,
                    "sub_tenant": sub_tenant,
                "headers_map": headers_map,
                "pages": pages,
            }
        )
        try:
            audit_data_user_actions = {
                "service_name": "get_billing_platform_customer_list_view_data",
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "session_id": ui_session_id,
                "tenant_name": tenant_name,
                "module_name": "People module",
                "comments": f"Fetched Billing Customers list view data for module: {module_name}",
                "request_received_at": request_received_at,
            }

            database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception while updating audit and exception is {e}")
        return return_json_data

    except Exception as e:
        logging.exception("### An error occurred in people_list_view")
        response = "Unable Fetch the Billing Customers data"
        # Error Management
        error_data = {
            "service_name": "get_billing_platform_customers_list_view_data",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": username,
            "session_id": ui_session_id,
            "tenant_name": tenant_name,
            "comments": f"Failed to fetch Billing Customers list view data for module: {module_name}",
            "module_name": "People module",
        }
        database.log_error_to_db(error_data, "error_log_table")
        # Get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, ["Billing Customers"], role_name, "", "", "", "", data, database
        )
        response={
                        "flag": True,
                        "data": [],
                        "message": "No data found for Billing Customers!",
                        "tenant_name": [],
                        "headers_map": headers_map,
                    }
        return response

