import psycopg2
import time

# Database connection details
DB_HOST = "your-rds-endpoint"
DB_PORT = 5432
DB_NAME = "your-database-name"
DB_USER = "your-username"
DB_PASSWORD = "your-password"

# Views to monitor
VIEWS = [
    "vw_view1",
    "vw_view2",
    "vw_view3"
]

def fetch_counts():
    try:
        # Connect to the database
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        cursor = conn.cursor()

        # Query each view
        for view in VIEWS:
            cursor.execute(f"SELECT COUNT(*) FROM {view}")
            count = cursor.fetchone()[0]
            print(f"View: {view}, Count: {count}")
        
        cursor.close()
        conn.close()

    except Exception as e:
        print(f"Error fetching counts: {e}")

if __name__ == "__main__":
    while True:
        fetch_counts()
        time.sleep(60)  # Wait for 60 seconds before running again

