import psycopg2
import boto3
import json
import time
from datetime import datetime, timedelta
import pytz
import logging
import sys



from opensearchpy import OpenSearch, helpers
import uuid
from multiprocessing import Pool
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests.auth import HTTPBasicAuth

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)  # Send logs to stdout
    ]
)

logging.info("Lambda Scheduler started!")

# Master database connection details
MASTER_DB_HOST = "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
MASTER_DB_PORT = 5432
MASTER_DB_NAME = "common_utils"
MASTER_DB_USER = "root"
MASTER_DB_PASSWORD = "AmopTeam123"

# AWS Lambda details
AWS_REGION = "us-east-1"
LAMBDA_FUNCTION_NAME = "hybrid_logstash_uat"
AWS_ACCESS_KEY_ID = "AKIAQEFWAKZ76R32NXGY"
AWS_SECRET_ACCESS_KEY = "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"

lambda_client = boto3.client(
    "lambda",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

# Dictionary to store the index_modified_date for each view
# index_modified_dates = {}


es = OpenSearch(
    ['https://search-amopsearchuat-dzxpse4exyj37kauestkbgeady.us-east-1.es.amazonaws.com'],
    #['https://search-amopsearch-df66xuwugs7f6b43ihav5yd5zm.us-east-1.es.amazonaws.com/'],
    #['https://search-amopsearchprod-xj5nowuexkwrreanprpiwyzdzy.us-east-1.es.amazonaws.com'],
    http_auth=('admin', 'Amopteam@123'),
    use_ssl=True,
    verify_certs=True,
    timeout=60
)

def fetch_latest_modified_dates_for_views(view_names):
    """
            Fetch the latest modified_date for each view and store in view_index_dates dictionary.
    """
    view_index_dates={}
    for view_name in view_names:
        index=f"{view_name}_altaworx_test"
        latest_modified_date = get_latest_modified_date_from_index(index)
        latest_modified_date = latest_modified_date.replace('T', ' ')
        view_index_dates[view_name] = latest_modified_date
        # logging.info(f"Fetched latest modified_date for {view_name}: {latest_modified_date}")
    return view_index_dates


def trigger_lambda(view,index_modified_date,db_modified_date, tenant_name):
    """Invoke the AWS Lambda function."""
    try:
        # if isinstance(last_modified, datetime):
        #     last_modified = last_modified.isoformat()
        payload = {
            "view_name": view,
            "start_date": str(index_modified_date),
            "end_date":str(db_modified_date),
            "tenant_name": tenant_name
        }
        payload_bytes = json.dumps(payload).encode('utf-8')

        response = lambda_client.invoke(
             FunctionName=LAMBDA_FUNCTION_NAME,
             InvocationType="Event",  # Asynchronous invocation
             Payload=payload_bytes
         )
    except Exception as e:
        print(f"Error triggering Lambda: {e}")

def fetch_database_configurations():
    """Fetch database configurations and view names from the master database."""
    try:
        conn = psycopg2.connect(
            host=MASTER_DB_HOST,
            port=MASTER_DB_PORT,
            database=MASTER_DB_NAME,
            user=MASTER_DB_USER,
            password=MASTER_DB_PASSWORD
        )
        cursor = conn.cursor()
        cursor.execute("SELECT tenant_name, view FROM view_schedule_data")
        db_configurations = cursor.fetchall()
        cursor.close()
        conn.close()
        return db_configurations
    except Exception as e:
        #print(f"Error fetching database configurations: {e}")
        return []

def fetch_counts_and_trigger(db_config,view_names,view_index_dates):
    """Fetch counts and trigger Lambda for views in a specific database."""
    tenant_name, view = db_config
    try:
        conn = psycopg2.connect(
            host=MASTER_DB_HOST,
            port=MASTER_DB_PORT,
            database=tenant_name,
            user=MASTER_DB_USER,
            password=MASTER_DB_PASSWORD
        )
        cursor = conn.cursor()

        for view in view_names:
            # Get index_modified_date for the view
            index_modified_date = index_modified_dates.get(view, None)
            # if not index_modified_date:
            #     # Initialize index_modified_date to the current timestamp if it doesn't exist
            #     index_modified_date = datetime.now(pytz.utc)
            #     index_modified_dates[view] = index_modified_date
            # Fetch the latest modified_date from the database
            cursor.execute(f"SELECT MAX(modified_date) FROM {view}")
            db_modified_date = cursor.fetchone()[0]

            #print("db_modified_date---------------",db_modified_date,index_modified_date)

            if not db_modified_date:
                logging.info(f"No  modified_date  found in view {view} for tenant {tenant_name} .")
                continue

            # Check if records exist between index_modified_date and db_modified_date
            cursor.execute(f"SELECT COUNT(*) FROM {view} WHERE modified_date > %s AND modified_date <= %s",
                           (str(index_modified_date), str(db_modified_date)))
            print(f"SELECT COUNT(*) FROM {view} WHERE modified_date > %s AND modified_date <= %s",
                           (str(index_modified_date), str(db_modified_date)))
            count = cursor.fetchone()[0]

            if count > 0:
                logging.info(f"Database: {tenant_name}, View: {view}, Count: {count}, Index Modified Date: {index_modified_date}, DB Modified Date: {db_modified_date}")
                # Trigger Lambda
                trigger_lambda(view,index_modified_date,db_modified_date, tenant_name)
            else:
                print("count is not greater than 0")
            # Update index_modified_date for the next iteration
            index_modified_dates[view] = str(db_modified_date)
        #print("index_modified_dates---------",index_modified_dates)
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Error processing database {tenant_name}: {e}")

def get_latest_modified_date_from_index(index_name):
    """
    Get the latest modified_date from the given OpenSearch index.
    """
    field_name = "modified_date"
    if index_name == 'email_audit_altaworx_test':
        field_name = "created_date"
    
    query = {
        "size": 1,
        "sort": [
            {field_name: {"order": "desc"}}
        ],
        "_source": [field_name]
    }
    
    try:
        response = es.search(index=index_name, body=query)
        hits = response.get('hits', {}).get('hits', [])
        if hits:
            return hits[0]['_source'][field_name]
        else:
            logging.warning(f"No documents found in OpenSearch index: {index_name}")
            return None
    except Exception as e:
        logging.error(f"Error fetching latest modified_date from OpenSearch index {index_name}: {e}")
        return None


#view_names = ["vw_optimization_smi_result_customer_charge_queue", "vw_carrier_search_view",
#                  "vw_customer_search_view", "vw_optimization_push_charges_data", "vw_optimization_error_details",
#                  "vw_optimization_smi_result_customer_charge_queue_summary", "vw_optimization_instance_summary",
#                  "sim_management_bulk_change_view"]

view_names = ["vw_optimization_smi_result_customer_charge_queue", "vw_carrier_search_view",
                  "vw_customer_search_view", "vw_optimization_push_charges_data", "vw_optimization_error_details",
                  "vw_optimization_smi_result_customer_charge_queue_summary", "vw_optimization_instance_summary",
                  "sim_management_bulk_change_view","sim_management_inventory_action_history","vw_automation_rule_log_list_view","vw_customer_rate_pool_usage_report","vw_usage_by_line_report","automation_rule_verification_report_view","vw_carrier_rate_plan","vw_people_bandwidth_customers","vw_people_revio_customers","vw_combined_device_inventory_export"]
view_names=list(set(view_names))

view_index_dates=fetch_latest_modified_dates_for_views(view_names)
index_modified_dates=view_index_dates


if __name__ == "__main__":

    
    print("$$$$$$$$$$$$",view_index_dates)

    while True:
        utc_tz = pytz.utc
        realtime = datetime.now(utc_tz)
        # Fetch and process data
        db_configurations = fetch_database_configurations()
        for db_config in db_configurations:
            print("-----------fecthing")
            fetch_counts_and_trigger(db_config,view_names,view_index_dates)
            
        time.sleep(5)

