import psycopg2
import boto3
import json
import time
from datetime import datetime,timedelta
import pytz



import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)  # Send logs to stdout
    ]
)

logging.info("Lambda Scheduler started!")



# Master database connection details
MASTER_DB_HOST = "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
MASTER_DB_PORT = 5432
MASTER_DB_NAME = "common_utils"
MASTER_DB_USER = "root"
MASTER_DB_PASSWORD = "AmopTeam123"

# AWS Lambda details
AWS_REGION = "us-east-1"
LAMBDA_FUNCTION_NAME = "hybrid_logstash_uat"
AWS_ACCESS_KEY_ID = "AKIAQEFWAKZ76R32NXGY"
AWS_SECRET_ACCESS_KEY = "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"

lambda_client = boto3.client(
    "lambda",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

# Initialize the Lambda client
#lambda_client = boto3.client("lambda", region_name=AWS_REGION)

def trigger_lambda(view_name, last_modified,tenant_name):
    """Invoke the AWS Lambda function."""
    try:
        # last_modified_str = last_modified.isoformat() if isinstance(last_modified, datetime) else last_modified
        if isinstance(last_modified, datetime):
            last_modified = last_modified.isoformat()
        payload = {
            "view_name": view_name,
            "last_modified": last_modified,
            "tenant_name":tenant_name
        }
        payload_bytes = json.dumps(payload).encode('utf-8')

        # payload_bytes = json.dumps(payload).encode('utf-8')

        response = lambda_client.invoke(
            FunctionName=LAMBDA_FUNCTION_NAME,
            InvocationType="Event",  # Asynchronous invocation
            Payload=payload_bytes
        )
        print(f"Lambda triggered for {view_name} with last_modified {last_modified}: {response['StatusCode']}")
    except Exception as e:
        print(f"Error triggering Lambda: {e}")

def fetch_database_configurations():
    """Fetch database configurations and view names from the master database."""
    try:
        # Connect to the master database
        conn = psycopg2.connect(
            host=MASTER_DB_HOST,
            port=MASTER_DB_PORT,
            database=MASTER_DB_NAME,
            user=MASTER_DB_USER,
            password=MASTER_DB_PASSWORD
        )
        cursor = conn.cursor()

        # Fetch database details and view names
        cursor.execute("SELECT tenant_name, view FROM view_schedule_data")
        db_configurations = cursor.fetchall()

        cursor.close()
        conn.close()

        return db_configurations
    except Exception as e:
        print(f"Error fetching database configurations: {e}")
        return []

def fetch_counts_and_trigger(db_config,given_datetime):
    """Fetch counts and trigger Lambda for views in a specific database."""
    tenant_name, view = db_config

    # Check if 'view' contains valid JSON data
    try:
        view_names = view 
        view_names=["vw_optimization_smi_result_customer_charge_queue","vw_carrier_search_view","vw_customer_search_view","vw_optimization_push_charges_data","vw_optimization_error_details","vw_optimization_smi_result_customer_charge_queue_summary","vw_optimization_instance_summary","sim_management_bulk_change_view"] 
        #print("view_names----------------",view_names) # Assuming `view_names` is stored as a JSON array in the database
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON for tenant '{tenant_name}' views: {e}. Skipping this entry.")
        return

    try:
        # Connect to the target database
        conn = psycopg2.connect(
            host=MASTER_DB_HOST,
            port=MASTER_DB_PORT,
            database=tenant_name,
            user=MASTER_DB_USER,
            password=MASTER_DB_PASSWORD
        )
        cursor = conn.cursor()

        for view in view_names:
            #view = str(view).strip()
           # print("#########################vew"  , view)
            # Fetch rows where updated_at > given datetime
            #given_datetime = "2025-01-02 20:33:00.000"  # Replace with your logic for retrieving the datetime
            cursor.execute(f"SELECT COUNT(*) FROM {view} WHERE modified_date > %s", (given_datetime,))
            count = cursor.fetchone()[0]

            if count > 0:
                # Fetch the latest modified datetime
                cursor.execute(f"SELECT MAX(modified_date) FROM {view} WHERE modified_date > %s", (given_datetime,))
                last_modified = cursor.fetchone()[0]

                logging.info(f"Database: {tenant_name}, View: {view}, Count: {count}, Last Modified: {last_modified}")

                # Trigger Lambda
                if last_modified:
                    trigger_lambda(view, last_modified,tenant_name)
                else:
                    print("Not triggered")

        cursor.close()
        conn.close()

    except Exception as e:
        print(f"Error processing database {tenant_name}: {e}")

if __name__ == "__main__":
    utc_tz = pytz.utc
    given_datetime = datetime.strptime("2025-01-14 16:54:00.352", "%Y-%m-%d %H:%M:%S.%f")
    given_datetime = utc_tz.localize(given_datetime)
    while True:
        #realtime = datetime.now(utc_tz)
        #given_datetime = utc_tz.localize(given_datetime)
        #realtime = datetime.now(utc_tz)+timedelta(hours=5, minutes=30)
        #print("############    realtime",realtime)
        #db_configurations = fetch_database_configurations()
        #if given_datetime + timedelta(seconds=10) > realtime + timedelta(seconds=10):
        #    print("Waiting for real-time to catch up...")
        #    time.sleep(10)  # Wait to synchronize with real-time
        #    continue
        #given_datetime=given_datetime.replace(tzinfo=None)
        #logging.info(f"### given_datetime, {given_datetime}")
        #for db_config in db_configurations:
        #    fetch_counts_and_trigger(db_config,given_datetime)
        #given_datetime += timedelta(seconds=10)
        #time.sleep(10)  # Wait for 60 seconds before running again


        realtime = datetime.now(utc_tz)

        # Log real-time for debugging
        logging.info(f"Current real-time: {realtime}")

        # Ensure that given time is less than or equal to real-time
        if given_datetime > realtime:
            logging.info("Waiting for real-time to catch up...")
            time_to_wait = (given_datetime - realtime).total_seconds()
            time.sleep(time_to_wait)  # Wait until real-time catches up
            continue

        # Fetch and process data
        logging.info(f"Processing for given_datetime: {given_datetime}")
        db_configurations = fetch_database_configurations()
        for db_config in db_configurations:
            fetch_counts_and_trigger(db_config, given_datetime)

        # Increment the given_datetime by 10 seconds for the next iteration
        given_datetime += timedelta(seconds=10)

        # Ensure smooth looping without excessive CPU usage
        time.sleep(1)

