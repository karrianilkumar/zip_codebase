"""
@author: Gopi Teja,Phaneendra
Created Date: 2022-11-23
"""

import json
import logging
import schedule
#import requests
import time
import requests
import datetime
import pytz

import os
import multiprocessing


##Kore daily sync function

# Define the 'clean_daily_sync' function
def clean_daily_sync(tenant_id):
    print(f"#### Cleaning up for {tenant_id}")
    try:
        # Call the clean_daily_sync endpoint before kore_daily_sync
        response = requests.post(f'http://carrier_data_sync_container:5000/kore_daily_sync',json={"tenant_id": tenant_id,"path":"/clean_daily_sync"})
        print(f"Response from Clean daily sync: {response.json()}")
    except Exception as e:
        print(f"Error calling clean_daily_sync: {e}")

def start_kore_daily_sync(tenant_id):
    print(f"#### Started start_kore_daily_sync of {tenant_id}")

    # Call kore_daily_sync function (assuming Kore container exposes an endpoint to call this)
    try:
        response = requests.post(f'http://carrier_data_sync_container:5000/run_scheduled_sync_tasks', json={"tenant_id": tenant_id,"path":"/kore_dialy_sync"})
        print(f"Response from Kore container: {response.json()}")
    except Exception as e:
        print(f"Error calling Kore container: {e}")

## Schedule the task to run at a specific time for kore_daily_sync
def scheduled_task(tenant_id):
    start_kore_daily_sync(tenant_id)


## Schedule the task to run at a specific time for kore_daily_sync
def run_schedule():
    print("Checking if it's time for Kore sync...")
    # 5:35 PM IST -> 12:05 PM UTC
    at_time = "08:30"  # 2:00 PM IST in UTC
    utc = pytz.utc

    now_utc = datetime.datetime.now(utc).strftime("%H:%M")
    print(f"monitoring..kore sync.{now_utc}")
    print(f"at time..{at_time}")
    if now_utc == at_time:
        print(f"Running scheduled job at {now_utc} UTC")
        scheduled_task('altaworx_test')



'''
Webbing daily sync function
'''
## Define the 'start_webbing_daily_sync' function
def start_webbing_daily_sync(tenant_id):
    print(f"#### Started start_webbing_daily_sync of {tenant_id}")
    try:
        response = requests.post(f'http://carrier_data_sync_container:5000/run_scheduled_sync_tasks', json={"tenant_id": tenant_id, "path": "/webbing_dialy_syncs"})
        print(f"Response from Webbing container: {response.json()}")
    except Exception as e:
        print(f"Error calling Webbing container: {e}")



# Function to schedule Webbing sync
def run_schedule_webbing():
    print("Checking if it's time for Webbing sync...")
    # 3:00 PM IST equals 09:30 UTC
    # Desired time in UTC corresponding to 1:30 PM IST is 08:00 UTC
    #at_time = "08:00"  # 1:30 PM IST in UTC
    # 8:30 PM IST → 15:00 UTC
    at_time = "15:00"
    utc = pytz.utc

    now_utc = datetime.datetime.now(utc).strftime("%H:%M")
    print(f"monitoring.Webbing Sync..{now_utc}")
    if now_utc == at_time:
        print(f"Running Webbing scheduled job at {now_utc} UTC")
        start_webbing_daily_sync('altaworx_test')


####Dialy Usage Report
'''
Webbing daily sync function
'''
## Define the 'start_dialy_usage_report_upload' function
def start_dialy_usage_report_upload(tenant_id):
    print(f"#### Started start_dialy_usage_report_upload of {tenant_id}")
    try:
        response = requests.post(f'http://carrier_data_sync_container:5000/run_scheduled_sync_tasks', json={"tenant_id": tenant_id, "path": "/dialy_usage_report_upload"})
        print(f"Response from start_dialy_usage_report_upload: {response.json()}")
    except Exception as e:
        print(f"Error calling start_dialy_usage_report_upload container: {e}")



# Function to schedule Webbing sync
def run_dialy_usage_report_upload():
    print("Checking if it's time for Dialy Usage Report Upload...")
    # 5:50 PM IST corresponds to 12:20 PM UTC
    # 3:00 PM IST equals 09:30 UTC
    at_time = "10:05"
    utc = pytz.utc

    now_utc = datetime.datetime.now(utc).strftime("%H:%M")
    print(f"monitoring.run_dialy_usage_report_upload Sync..{now_utc}")
    if now_utc == at_time:
        print(f"Running run_dialy_usage_report_upload scheduled job at {now_utc} UTC")
        start_dialy_usage_report_upload('altaworx_test')


##schedule the tasks for dialy Telgo Calls
# Function to trigger the Telgo caller
def start_telgo_caller(tenant_id):
    print(f"#### Started start_telgo_caller of {tenant_id}")
    try:
        response = requests.post(
            'http://carrier_data_sync_container:5000/run_scheduled_sync_tasks',
            json={"tenant_id": tenant_id, "path": "/initiate_telgoo5_sim_deactivation_sync"}
        )
        print(f"Response from Webbing container: {response.json()}")
    except Exception as e:
        print(f"Error calling Webbing container: {e}")

# Schedule to run every minute
def run_telgo():
    start_telgo_caller('altaworx_test')


##Telgo5 sim deactivation calls every 1 minute
schedule.every(1).minutes.do(run_telgo)

##Kore daily sync every 1 minute
schedule.every(1).minutes.do(run_schedule)

##Webbing daily sync every 1 minute
schedule.every(1).minutes.do(run_schedule_webbing)

##Dialy Usage Report upload every 1 minute
schedule.every(1).minutes.do(run_dialy_usage_report_upload)

if __name__ == '__main__':
    while True:
        schedule.run_pending()
        time.sleep(1)

