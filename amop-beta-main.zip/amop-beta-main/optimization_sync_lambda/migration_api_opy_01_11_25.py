"""
Author : Vyshnavi.K, Bhavani.Ganta
Created Date : 09-12-2024
main fn: main_migration_func
"""

# 1. Standard Library Imports
import os
import json
import re
import time
import math
import threading
from datetime import datetime, timedelta,timezone
import copy
import uuid
import boto3
import traceback

# 2. Third-Party Imports
import pandas as pd
from pandas import Timestamp
from sqlalchemy import create_engine, exc, text
import pytds
import psycopg2
from psycopg2.extras import execute_values
from tenacity import retry, stop_after_attempt, wait_fixed
from dotenv import load_dotenv

# 3. Local Application Imports
from common_utils.logging_utils import Logging
from common_utils.email_trigger import send_email
# from optimization_migration import optimization_sync_comm_group
import requests
import random
from botocore.exceptions import NoCredentialsError, ClientError
from io import BytesIO

logging = Logging(name="migration_api_opt")


# logging.basicConfig(filename='db_migration.log', level=logging.ERROR,
                    # format='%(asctime)s %(levelname)s:%(message)s')

onepoint_o_database=os.getenv("ONEPOINTODATABASE","AltaworxCentral_Test")

port_mapping={
        "altaworx_central":5000,
        "altaworx_go_tech":5003,
        "spectrotel":5004
    }
class MigrationScheduler:



    def create_postgres_connection(self,postgres_db_name):
        logging.info(f"In create_postgres_connection {postgres_db_name}")

        load_dotenv()
        hostname = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        try:
            connection=self.create_connection(db_type,hostname,postgres_db_name,user,password,port)
            logging.info(f"in create postgres connection {connection}")
        except Exception as e:
            logging.info(f"Error while establishing connection {e}")
        return connection

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
    def create_connection(self,db_type='',host='', db_name='',username='', password='',port='',driver='',max_retry=3):
        """
        Establishes a database connection to PostgreSQL or MSSQL based on the provided parameters.

        Retries the connection up to a specified number of times in case of failure.

        Args:
            db_type (str): Type of the database ('postgresql' or 'mssql').
            host (str): Hostname or IP address of the database server.
            db_name (str): Name of the database.
            username (str): Username for authentication.
            password (str): Password for authentication.
            port (str): Port number for the database connection.
            driver (str): Driver details (used for MSSQL if required).
            max_retry (int): Maximum number of retry attempts (default: 3).

        Returns:
            connection: A database connection object or None if the connection fails.
        """
        connection = None
        retry = 1
        logging.info(f"db_type:{db_type}, host--{host}-db_name-{db_name}, username-{username},password-{password},port-{port},driver-{driver}")
        db_type = db_type.strip()
        host = host.strip()
        db_name = db_name.strip()
        username = username.strip()
        password = password.strip()
        port = port.strip()
        driver = driver.strip()
        if db_type=='postgresql':
            try:
                logging.info(f"creating postgresql connection")

                connection = psycopg2.connect(
                    host=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )
                logging.info("Connection to PostgreSQL DB successful")
            except Exception as e:
                logging.warning(f"Failed to connect to PostgreSQL DB: {e}")
        elif db_type=='mssql':
            logging.info(f"Creating MSSQL connection")
            try:
                connection = pytds.connect(
                    server=host,
                    database=db_name,
                    user=username,
                    password=password,
                    port=port
                )

                logging.info("Connection to MSSQL successful!")
            except Exception as e:
                logging.warning(f"Failed to connect to MSSQL DB: {e}")
        return connection

    def execute_query(self,connection,query):
        """
        Executes a SQL query using the given database connection and returns the result as a DataFrame.

        Args:
            connection: The database connection object to execute the query.
            query (str): The SQL query to be executed.

        Returns:
            pd.DataFrame: The result of the query as a pandas DataFrame, or None if an error occurs.
        """
        try:
            result_df=pd.read_sql_query(query,connection)
            return result_df
        except Exception as e:
            logging.error(f"Error executing query: {e}")
            return None

    def get_from_clause_index(self,query):
        """
        Identifies the starting index of the "FROM" clause in a SQL query.

        This method uses a regular expression to locate the standalone "FROM" keyword
        in the provided SQL query, ignoring case sensitivity. It raises an exception
        if the "FROM" clause is not found in the query.

        Args:
            query (str): The SQL query string.

        Returns:
            int: The starting index of the "FROM" keyword in the query.

        Raises:
            ValueError: If the query does not contain a "FROM" clause.
        """
    # This regex will match the standalone "FROM" keyword
        match = re.search(r"\bFROM\b", query, re.IGNORECASE)
        # logging.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@getting the index of from",match.start() )
        if match:
            return match.start()  # Return the starting index of "FROM"
        else:
            raise ValueError("Invalid query: Missing FROM clause.")

    def get_updated_records_query(self, columns, last_id, full_from_table, query, error_id_list):
        """
        Generate a query to fetch updated records based on dynamic conditions.

        This method constructs a SQL query dynamically to fetch records that are updated
        (based on `id`, `modifieddate`, and `deleteddate`) after the provided values.
        It supports handling table aliases and building WHERE clauses intelligently.

        Args:
            columns (list): List of column names to use in the WHERE clause.
            last_id (list): List of values corresponding to the columns for filtering.
            full_from_table (str): Fully qualified table name if provided.
            query (str): The base query string to enhance with dynamic WHERE conditions.
            error_id_list (list): List of error IDs to include in the query.

        Returns:
            str: A dynamically constructed query string.
            None: If an error occurs during query generation.

        Raises:
            ValueError: If the base query is invalid (e.g., missing a FROM clause).
        """
        try:
            # Initialize the WHERE clause
            where_conditions = []
            modified_date_condition = None
            deleted_date_condition = None

            # Parse the FROM clause to extract table aliases
            from_clause_start = self.get_from_clause_index(query)
            if from_clause_start == -1:
                raise ValueError("Invalid query: Missing FROM clause.")

            # Extract the part of the query after FROM
            from_clause = query[from_clause_start + 4:].strip()

            # Split on JOIN, comma, or WHERE to isolate the FROM section
            from_clause = from_clause.split(" WHERE")[0].split(" JOIN")[0].split(",")[0].strip()
            from_clause_split = from_clause.split()

            table_aliases = {}
            for idx, word in enumerate(from_clause_split):
                if self.recognize_format(word):
                    # Check if there is an alias available
                    if idx + 1 < len(from_clause_split):
                        alias = from_clause_split[idx + 1]
                        table_aliases[alias] = word

            # Check if ModifiedDate, DeletedDate, or ID exists in the query to determine alias
            date_column_alias = None
            for alias in table_aliases:
                alias_modifieddate = f"{alias}.modifieddate"
                alias_deleteddate = f"{alias}.deleteddate"
                alias_id = f"{alias}.id"

                # Check if any of these columns with alias exist in the query
                if (alias_modifieddate in query.lower() or
                    alias_deleteddate in query.lower() or
                    alias_id in query.lower()):
                    date_column_alias = alias
                    break

            # Constructing the WHERE clause dynamically
            for col, val in zip(columns, last_id):
                col_lower = col.lower()

                if col_lower == 'id' and date_column_alias:
                    col_with_alias = f"{date_column_alias}.{col}"
                    if isinstance(val, str):
                        where_conditions.append(f"{col_with_alias} > '{val}'")
                    else:
                        where_conditions.append(f"{col_with_alias} > {val}")

                elif col_lower == "modifieddate":
                    if date_column_alias:
                        col_with_alias = f"{date_column_alias}.{col}"
                        if isinstance(val, str):
                            modified_date_condition = f"{col_with_alias} > '{val}'"
                        else:
                            modified_date_condition = f"{col_with_alias} > {val}"
                    elif col_lower in query.lower():
                        # Handle case where no alias but column exists in query
                        if isinstance(val, str):
                            modified_date_condition = f"{col} > '{val}'"
                        else:
                            modified_date_condition = f"{col} > {val}"

                elif col_lower == "deleteddate":
                    if date_column_alias:
                        col_with_alias = f"{date_column_alias}.{col}"
                        if isinstance(val, str):
                            deleted_date_condition = f"{col_with_alias} > '{val}'"
                        else:
                            deleted_date_condition = f"{col_with_alias} > {val}"
                    elif col_lower in query.lower():
                        # Handle case where no alias but column exists in query
                        if isinstance(val, str):
                            deleted_date_condition = f"{col} > '{val}'"
                        else:
                            deleted_date_condition = f"{col} > {val}"

                else:
                    # Handle other columns
                    if isinstance(val, str):
                        where_conditions.append(f"{col} > '{val}'")
                    else:
                        where_conditions.append(f"{col} > {val}")

            # Handle error_id_list
            if error_id_list:
                if date_column_alias:
                    col_with_alias = f"{date_column_alias}.id"
                    error_id_list_str = ', '.join([str(i) for i in error_id_list])
                    error_id_condition = f"{col_with_alias} IN ({error_id_list_str})"
                    where_conditions.append(error_id_condition)
                else:
                    error_id_list_str = ', '.join([str(i) for i in error_id_list])
                    error_id_condition = f"id IN ({error_id_list_str})"
                    where_conditions.append(error_id_condition)

            # Combine the conditions
            where_clause = ""
            if where_conditions:
                where_clause = " WHERE " + " OR ".join(where_conditions)

            # Add modified date condition
            if modified_date_condition:
                if where_clause:
                    where_clause += f" OR {modified_date_condition}"
                else:
                    where_clause = f" WHERE {modified_date_condition}"

            # Add deleted date condition
            if deleted_date_condition:
                if where_clause:
                    where_clause += f" OR {deleted_date_condition}"
                else:
                    where_clause = f" WHERE {deleted_date_condition}"

            # Construct the final query
            if full_from_table:
                migrate_records = f"SELECT * FROM {full_from_table}{where_clause} ORDER BY id ASC"
            elif query:
                if "ORDER BY" in query.upper():
                    parts = query.rsplit("ORDER BY", 1)
                    # Add the WHERE clause before the last "ORDER BY"
                    query = parts[0] + where_clause + " ORDER BY" + parts[1]
                else:
                    query += where_clause
                migrate_records = query

        except Exception as e:
            logging.info(f"Error in generating query to select records: {e}")
            migrate_records = None

        return migrate_records
    """
    #Commenting below bloc because this is for user interaction not used in lambda
    def main(self):
        load_dotenv()  # Load environment variables from .env file
        migration_details_dict={}

        logging.info("Beginning migration")

        hostname = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        db_name = 'Migration_Test'
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        migration_table=os.getenv('MIGRATION_TABLE')

        postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
        query = f"SELECT migration_name FROM {migration_table}"
        rows = self.execute_query(postgres_conn, query)


        if rows.empty:
            logging.info("No existing jobs found. Creating a new job.")
            new_job = self.create_new_migration(postgres_conn, migration_table)

        else:
            user_choice = input("Do you want to create a new migration job or select an existing one? (new/existing): ").strip().lower()

            if user_choice == 'new':
                logging.info("Creating a new migration job.")
                new_job = self.create_new_migration(postgres_conn, migration_table)
            elif user_choice == 'existing':
                logging.info("Existing jobs:")
                # logging.info(rows)
                for index, row in rows.iterrows():
                    logging.info(f"{index + 1}. {row['migration_name']}")

                choice = input("Enter 'single' to execute a single job immediately or 'scheduled' to schedule jobs: ").strip().lower()

                if choice == 'single':
                    job_name = input("Enter the job name you want to execute: ").strip()
                    self.main_migration_func(job_name, postgres_conn)
                elif choice == 'scheduled':
                    job_names = input("Enter the job names you want to select (comma-separated for multiple jobs): ").strip().split(',')
                    job_names = [job.strip() for job in job_names]

                    start_times = {}
                    for job_name in job_names:
                        start_time_str = input(f"Enter the start time for the migration '{job_name}' (in HH:MM:SS format): ")
                        start_time = datetime.strptime(start_time_str, "%H:%M:%S").time()
                        start_times[job_name] = start_time

                    days_to_run = int(input("Enter the number of days to run the job (including today): "))

                    now = datetime.now()
                    for job_name, start_time in start_times.items():
                        for day in range(days_to_run):
                            start_datetime = datetime.combine(now + timedelta(days=day), start_time)
                            delay_seconds = (start_datetime - now).total_seconds()
                            start_time_12hr = start_datetime.strftime("%I:%M:%S %p")
                            logging.info(f"Scheduled to start '{job_name}' at: {start_time_12hr} on {start_datetime.date()}")
                            threading.Timer(delay_seconds, self.main_migration_func, [job_name, postgres_conn]).start()

            else:
                logging.info("Invalid choice. Please enter 'new' or 'existing'.")
                self.main()"""


    def get_migration_details(self, job_name, conn,migrations_table):
        """
        Fetch migration details for a specific job from the migrations table.

        This method queries the database to retrieve migration details for a given job name.
        It executes the query, fetches the result as a pandas DataFrame, and converts it
        to a dictionary format.

        Args:
            job_name (str): The name of the migration job to fetch details for.
            conn (object): The database connection object to execute the query.
            migrations_table (str): The name of the migrations table in the database.

        Returns:
            dict: A dictionary containing the details of the migration job.
                If no details are found or an error occurs, an empty dictionary is returned.
        """
        try:
            query = f"SELECT * FROM {migrations_table} WHERE migration_name = '{job_name}'"
            query_result = self.execute_query(conn, query)
            return query_result.to_dict(orient='records')[0]
        except Exception as e:
            logging.error(f"Error while fetching the {job_name} details - {e}")
            return {}

    def get_db_config(self, migration_details_dict):
        """
        Extract and process database configuration from migration details.

        This method retrieves the database configuration from the given migration details dictionary.
        If the configuration is a JSON string, it converts it into a Python dictionary.
        If the configuration is not present or invalid, it falls back to a default configuration.

        Args:
            migration_details_dict (dict): A dictionary containing migration details,
                                        including the database configuration under 'from_db_config'.

        Returns:
            dict: A dictionary containing database configuration details, either from the input
        """
        db_config = migration_details_dict.get('from_db_config')
        if db_config and not isinstance(db_config, dict):
            db_config = json.loads(db_config)
        return db_config or {
            'hostname': os.getenv('MSSQL_DB_HOST'),
            'port': os.getenv('MSSQL_DB_PORT'),
            'user': os.getenv('MSSQL_DB_USER'),
            'password': os.getenv('MSSQL_DB_PASSWORD'),
            'from_db_type': os.getenv('MSSQL_DB_TYPE')
        }


    def update_migration_details_dict(self,insert_records,success,failures,last_id_time,error_msg):
        try:
            migration_details_updated_dict={}
            migration_details_updated_dict['status']=insert_records
            # migration_details_updated_dict['last_id']=last_id_time
            migration_update_list=[]
            migration_update_dict={'Success_Records':success,'failed_records':failures}
            #migration_update_list=[migration_update]
            migration_details_updated_dict['last_id']=str(last_id_time)
            migration_update_list.append(migration_update_dict)
            migration_details_updated_dict['migration_update']=json.dumps(migration_update_list)
            migrated_time=datetime.now()
            # logging.info(f"Current_time is {migrated_time}")
            migration_details_updated_dict['last_migrated_time']=migrated_time
            migration_details_updated_dict['error_message']=error_msg
            logging.info(f"migration_details_updated_dict is {migration_details_updated_dict}")

        except Exception as e:
            logging.error(f"Error while updating migration details dict : {e}")
        return migration_details_updated_dict

    #removing this because its doing some unnecessary updates
    def update_migration_details_dict_(
            self,
            migration_details_dict,
            insert_records,
            success,
            failures,
            last_id_time,
            db_config):
        """
        Update the migration details dictionary with the latest migration status.

        This method updates various fields in the migration details dictionary,
        including status, last migrated ID/time, database configurations,
        and mappings, while handling success and failure records.

        Args:
            migration_details_dict (dict): The dictionary containing migration details to be updated.
            insert_records (int): The number of records inserted in the migration.
            success (int): The count of successfully migrated records.
            failures (int): The count of failed migrations.
            last_id_time (str/datetime): The last ID or timestamp of the migrated record.
            db_config (dict): The database configuration dictionary.

        Returns:
            dict: The updated migration details dictionary.
        """
        try:
            # Update the current migration status and the last migrated ID/time
            migration_details_dict['status']=insert_records
            migration_details_dict['last_id']=last_id_time

            # Update migration update list with success and failure records
            migration_update_list=migration_details_dict['migration_update'] or []
            if isinstance(migration_update_list, str):
                migration_update_list = json.loads(migration_update_list)  # If it's a string, convert it back to a list
            if not isinstance(migration_update_list, list):
                migration_update_list = []
            logging.info(f"Migration Status {migration_update_list}")
            migration_update_dict={'Success_Records':success,'failed_records':failures}
            #migration_update_list=[migration_update]

            migration_update_list.append(migration_update_dict)
            migration_details_dict['migration_update']=json.dumps(migration_update_list)

            migration_details_dict['from_db_config']=json.dumps(db_config)
            to_mapping=migration_details_dict['table_mappings']
            migration_details_dict['table_mappings']=json.dumps(to_mapping)

            reverse_sync_mapping=migration_details_dict['reverse_sync_mapping']
            migration_details_dict['reverse_sync_mapping']=json.dumps(reverse_sync_mapping)

            migrated_time=datetime.now()
            # logging.info(f"Current_time is {migrated_time}")
            migration_details_dict['last_migrated_time']=migrated_time
        except Exception as e:
            logging.error(f"Error while updating migration details dict : {e}")
        return migration_details_dict

    def select_updated_records(self,columns_list, last_id_list, full_from_table):
        """
        Construct and return a SQL query to select updated records based on dynamic column values.

        This method generates a WHERE clause dynamically using the provided list of columns
        and corresponding last IDs or values. The final SQL query is constructed to select records
        that have values greater than the provided last IDs.

        Args:
            columns_list (list): List of column names used for comparison in the WHERE clause.
            last_id_list (list): List of last ID values to compare against for each column in columns_list.
            full_from_table (str): The name of the table from which records are selected.

        Returns:
            str: The constructed SQL query as a string.
        """
        # Constructing the WHERE clause dynamically
        where_conditions = []
        for col, val in zip(columns_list, last_id_list):
            if isinstance(val, str):
                where_conditions.append(f"{col} > '{val}'")
            else:
                where_conditions.append(f"{col} > {val}")

        where_clause = " AND ".join(where_conditions)

        # Constructing the SQL query
        migrate_records = f"SELECT * FROM {full_from_table} WHERE {where_clause}"

        return migrate_records
    def get_to_db_config(self, migration_details_dict):
        """
        Extract and process database configuration from migration details.

        This method retrieves the database configuration from the given migration details dictionary.
        If the configuration is a JSON string, it converts it into a Python dictionary.
        If the configuration is not present or invalid, it falls back to a default configuration.

        Args:
            migration_details_dict (dict): A dictionary containing migration details,
                                        including the database configuration under 'from_db_config'.

        Returns:
            dict: A dictionary containing database configuration details, either from the input
        """
        db_config = migration_details_dict.get('to_db_config')
        if db_config and not isinstance(db_config, dict):
            db_config = json.loads(db_config)
        return db_config 

    def main_migration_func(self,job_name,key_name=None):
        """
        The main migration function that handles the process of migrating data from one database to another.
        This includes both table-to-table migration and query-based migration, with support for reverse synchronization.

        Args:
            job_name (str): The name of the migration job to be executed.

        Returns:
            bool: Returns True if the migration job completes successfully, otherwise returns False.
        """
        try:
            logging.info("starting the job",{job_name})
            load_dotenv()
            hostname = os.getenv('PSQL_DB_HOST')
            port = os.getenv('PSQL_DB_PORT')
            user = os.getenv('PSQL_DB_USER')
            password = os.getenv('PSQL_DB_PASSWORD')
            db_type = os.getenv('PSQL_DB_TYPE')
            db_name=os.getenv('PSQL_DB_NAME')
            logging.info("postgress sql db configuration loaded successfully")
            # logging.info(hostname,port)

            # Create the PostgreSQL connection to the source database
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info("Connection to PostgreSQL DB successful")
            #Before starting the job insert a record in history table
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            hist_insert_data={'key_name':key_name,'job_name':job_name,'job_start_time':datetime.now(timezone.utc).replace(tzinfo=None),
                              'request_triggered_by':'optimization_sync_lambda'}

            trace_id=self.insert_dict(postgres_conn,history_table,hist_insert_data,True,'trace_id')
            logging.info(f"Trace Id after insertion is {trace_id}")


            logging.info(f"{trace_id} Executing job: {job_name}")
            load_dotenv()
            migration_table=os.getenv('MIGRATION_TABLE')
            # migration_table='migrations_2'
            logging.info(f"migrations table {migration_table}")
            migration_details_dict=self.get_migration_details(job_name,postgres_conn,migration_table)

            table_flag=migration_details_dict['table_flag']
            logging.info(f"{trace_id} Table Flag is {table_flag}")


            # to_hostname = os.getenv('PSQL_DB_HOST')
            # to_port = os.getenv('PSQL_DB_PORT')
            # to_db_name =migration_details_dict['to_database']
            # to_user = os.getenv('PSQL_DB_USER')
            # to_password = os.getenv('PSQL_DB_PASSWORD')
            # to_db_type = os.getenv('PSQL_DB_TYPE')
            # to_table=migration_details_dict['to_table']
            to_db_config = self.get_to_db_config(migration_details_dict)
            if to_db_config is None:
                logging.info(f"To db configurations not found")
                msg=f"Error in main-last migration {job_name} to_db_config is empty"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                logging.info(f"Error in main_migration_fun:last_id_migration {job_name}")
                return True
            to_hostname = to_db_config['hostname']
            to_port = to_db_config['port']
            to_db_name = migration_details_dict['to_database']
            to_user = to_db_config['user']
            to_password = to_db_config['password']
            to_db_type = to_db_config['to_db_type']
            to_table = migration_details_dict['to_table']
            to_connection=self.create_connection(to_db_type,to_hostname,to_db_name,to_user,to_password,to_port)


            migration_status=migration_details_dict['status']
            reverse_sync_flag = migration_details_dict["reverse_sync"]
            reverse_sync_mappings = migration_details_dict["reverse_sync_mapping"]

            # Handle reverse sync if the flag is set
            if reverse_sync_flag:
                logging.info(
                    f"####################{trace_id} Reverse sync for {job_name} starting"
                )
                reverse_sync_flag,error_msg,rev_error_id_list = self.reverse_sync_migration(
                    job_name,
                    to_connection,
                    reverse_sync_mappings,
                    migration_details_dict,
                    trace_id,
                    postgres_conn
                )
                if reverse_sync_flag is False:
                    logging.error(
                        f"#################### Reverse sync for {job_name} failed"
                    )
                    tb = traceback.format_exc()
                    error_message_tb=f'{error_msg} {tb}'
                    update_hist={'error_msg':error_message_tb,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'rev_sync_error_id':json.dumps(reverse_sync_mappings),'rev_sync_error_id':json.dumps(rev_error_id_list)}
                    self.update_table(postgres_conn,history_table,update_hist,{'trace_id':trace_id})
                    return False

            if table_flag:
                logging.info(f"{trace_id} Table to Table migration for {job_name}")
                if migration_status=='first':
                    first_table_migrate=self.first_migration(table_flag,to_connection,
                                                         postgres_conn,migration_details_dict,migration_table,job_name,trace_id)
                else:
                    logging.info(f"###############{trace_id} LAST ID migration for {job_name}")
                    last_id_migration=self.last_id_migration(table_flag,to_connection,
                                                         postgres_conn,migration_details_dict,migration_table,job_name,trace_id)

            else:
                logging.info(f"{trace_id} Executing {job_name}")

                if migration_status=='first':
                    try:
                        logging.info(f"{trace_id} FIRST MIGRATION -- {job_name}")
                        first_migration=self.first_migration(table_flag,to_connection,
                                                     postgres_conn,migration_details_dict,migration_table,job_name,trace_id)
                    except Exception as e:
                        tb = traceback.format_exc()
                        msg=f"Error in first migration {job_name} {e} {tb}"
                        update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                        self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                        logging.error(f"Error in main_migration_func:first_migration {job_name} -{e}")

                else:
                    logging.info(f"{trace_id} LAST ID MIGRATION -- {job_name}")
                    try:
                        last_id_migration=self.last_id_migration(table_flag,to_connection, postgres_conn,migration_details_dict,migration_table,job_name,trace_id)
                    except Exception as e:
                        tb = traceback.format_exc()
                        msg=f"Error in main-last migration {job_name} {e} {tb}"
                        update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                        self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                        logging.error(f"Error in main_migration_fun:last_id_migration {job_name} -{e}")

            return_flag = True
        except Exception as e:
            # If any error occurs, log the error and set return_flag to False
            return_flag = False
            tb = traceback.format_exc()
            msg=f"Error in {job_name} {e} {tb}"
            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
            logging.error(f"Error in main_migration_fun {job_name} -{e} {tb}")
        finally:
            # Close the database connection
                if postgres_conn:
                    postgres_conn.close()
                    logging.info("Connection closed.")
        return return_flag
    def first_migration(
            self,
            table_flag,
            to_connection,
            postgres_conn,
            migration_details_dict,
            migration_table,
            job_name,
            trace_id
    ):
        """
        Perform the first migration process for moving data from
        a source (SQL Server or query) to a target database (PostgreSQL).

        Args:
            table_flag (bool): Flag to determine if the migration is based on a table or a query.
            to_connection: The connection object to the target database (PostgreSQL).
            postgres_conn: The connection to the PostgreSQL database.
            migration_details_dict (dict): Contains all the necessary details for
            migration like source database, table, queries, etc.
            migration_table (str): The target migration table name.
            job_name (str): The name of the job to log migration status.

        Returns:
            None
        """
        try:
            if table_flag:
                from_database=migration_details_dict['from_database']
                from_table=migration_details_dict['from_table']

                if not self.is_valid_table_name(from_table):
                    full_from_table=f'[{from_database}].[dbo].[{from_table}]'
                    # logging.info(f"full table name {full_from_table}")
                else:
                    full_from_table=from_table
                logging.info(f"{trace_id} table to table migration")
                from_query=f"select * from {full_from_table} order by {primary_id_col}"
            else:
                logging.info(f"!!!!!!!!!!!!! query based migration")
                from_query=migration_details_dict['from_query']
                to_query=migration_details_dict['to_query']

            logging.info(f"{trace_id} common process for both")
            #establishing from conn
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            db_config=self.get_db_config(migration_details_dict)
            from_host=db_config['hostname']
            from_port=db_config['port']
            from_user=db_config['user']
            from_pwd=db_config['password']
            from_db_type=db_config['from_db_type']
            from_database=migration_details_dict['from_database']
            from_driver=os.getenv('MSSQL_DB_DRIVER')
            from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
            logging.info(f"{trace_id} Connection ssms: {from_connection}")
            primary_id_col=migration_details_dict['primary_id_column']
            logging.info(f"primary id column is {primary_id_col}")
            df_size=os.getenv('DF_SIZE')
            df_size=int(df_size)
            # db_config=self.get_db_config(migration_details_dict)
            to_table=migration_details_dict['to_table']

            max_retries=3
            from_query=' '.join(from_query.split())
            from_query=from_query.rstrip(';')
            logging.info(f"{trace_id} {job_name}  from query before {from_query}")
            count_query=self.get_count_query(from_query)

            count_query=' '.join(count_query.split())
            logging.info(f"{trace_id} {job_name}COUNT QUERY  {count_query}")
            success_count=0
            try:
                batch_queries,total_count=self.generate_batch_queries(count_query,from_query,from_connection,df_size,primary_id_col)

                if batch_queries is False and total_count is False:
                    logging.error(f"{trace_id} Error in generating batch queries")
                    error_msg="Error in generating batch queries"
                    update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                    self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                    return False
            except Exception as e:
                logging.error(f"{trace_id} Error in generating batch queries {e}")
                tb = traceback.format_exc()
                update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return False

            if total_count==0:
                logging.info(f"{trace_id} No records found for migration")
                msg=f"No records found for migration"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'total_count':total_count,'success':0,'failed':0,'job_status_msg':'SUCCESS'}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return True
            else:
                logging.info(f"Total count is {total_count}")
                update_dict={'total_count':total_count}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})


            if batch_queries:
                for query in batch_queries:
                    logging.info(f"executing query {query}")
                    attempt=0
                    df=None
                    try:
                        while attempt < max_retries:
                            if not self.check_connection(from_connection):
                                logging.warning(f"{trace_id} Connection lost. Attempting to reconnect...")
                                from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
                                if from_connection is None:
                                    logging.error("Failed to re-establish connection.")
                                    break
                            df=self.execute_query(from_connection,query)

                            if df is not None:
                                df = df.astype(object).mask(df.isna(), None)
                                logging.info(f"{job_name} Dataframe got is \n {df.head()}")
                                logging.info(f"{job_name} ################# The number of rows in the DataFrame is: {df.shape[0]}")
                                df=self.modify_uuid_cols(df)
                                break  # Exit the retry loop if successful
                            else:
                                logging.error(f"{trace_id} Error in executing query, retrying...")
                                attempt += 1
                                time.sleep(5)
                    except Exception as e:
                        logging.error(f"{trace_id} An error occurred: {str(e)}")
                        attempt += 1
                        time.sleep(5)


                    success_count=self.initate_complete_migration(df,to_connection,postgres_conn,migration_table,job_name,migration_details_dict,to_table,db_config,trace_id,total_count,success_count)
            else:
                logging.info(f"No batch queries check count")
                msg=f"No batch Queries formed, check count"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                return True
        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"Error in first migration {e} {tb}")
            error_msg=f"Error in first migration {e} {tb}"
            self.update_table(postgres_conn,history_table,{'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)},{'trace_id':trace_id})
            return False

    def last_id_migration(
            self,
            table_flag,
            to_connection,
            postgres_conn,
            migration_details_dict,
            migration_table,
            job_name,
            trace_id
    ):
        """
        Migrates data from one database table to another using a batch processing approach.
        It performs migrations based on the last migrated record (identified by the `last_id`) and applies
        various checks such as connection validation, query execution, and retries in case of failure.

        Args:
            table_flag (bool): A flag indicating whether to perform table-to-table migration (True) or use custom queries (False).
            to_connection (object): The database connection object for the destination database.
            postgres_conn (object): The connection object for PostgreSQL (used if needed for custom queries).
            migration_details_dict (dict): A dictionary containing migration details such as the source and target tables, time columns, and last migrated ID.
            migration_table (str): The name of the migration table in the destination database.
            job_name (str): The name of the migration job.

        Returns:
            None: This function does not return any values. It performs data migration and logs the progress. If an error occurs, it is logged.

        Raises:
            ValueError: If no records are available for migration (i.e., batch queries return no results).
            Exception: If there is a failure during the migration process (e.g., database connection issues or query execution errors).
        """
        try:
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            to_db_name =migration_details_dict['to_database']
            to_table=migration_details_dict['to_table']
            time_column_check=migration_details_dict['time_column_check']
            time_columns = [col.strip() for col in time_column_check.split(',')]
            df_size=os.getenv('DF_SIZE')
            df_size=int(df_size)
            logging.info(f"{trace_id} {job_name} time column check got is {time_columns}")
            primary_id_col=migration_details_dict['primary_id_column']

            last_id=migration_details_dict['last_id']
            success_count=0
            if last_id:

                try:
                    if isinstance(last_id,str) or isinstance(last_id,int):
                        if last_id == '[null]' or last_id == 'null' or last_id=='[]':
                            # logging.info(f"in if where last id is [null]")
                            last_id=self.update_last_id_list(to_db_name,to_table,time_columns,primary_id_col)

                        else:
                            if last_id.startswith('{') and last_id.endswith('}'):
                                # Remove the curly braces
                                last_id = [int(last_id[1:-1])]
                            else:
                                # last_id=f'[{last_id}]'
                                last_id=json.loads(last_id)
                                logging.info(f"json loads last_id {last_id}")

                except Exception as e:
                    logging.exception(f"{trace_id} {job_name} Erro loading last_id list {e}")
                    last_id=self.update_last_id_list(to_db_name,to_table,time_columns,primary_id_col)
                    # last_id=self.load_last_id(last_id)
                logging.info(f"{job_name} last_id after load_last_id is {last_id}")

            if not last_id:
                last_id=self.update_last_id_list(to_db_name,to_table,time_columns,primary_id_col)

            ###need to get error ids from previous job
            error_ids_query=f"select error_id_list,job_end_time from {history_table} where job_name='{job_name}' and trace_id<>'{trace_id}' order by job_end_time desc limit 1"
            error_ids_df=self.execute_query(postgres_conn,error_ids_query)
            # logging.info(f"DF is {error_ids_df}")
            if not error_ids_df.empty:
                error_id_list = error_ids_df['error_id_list'][0]
                last_migrated_time_prev=error_ids_df['job_end_time'][0]
            else:
            # Handle the empty DataFrame case (e.g., return or log an error)
                logging.info(f"{trace_id} DataFrame 'error_ids_df' is empty.")
                error_id_list=[]
                last_migrated_time_prev=[]

            last_migrated_time_query=f"select job_end_time from {history_table} where job_name='{job_name}' and trace_id<>'{trace_id}' and job_status_msg='SUCCESS' order by id desc limit 1"
            last_migrated_df=self.execute_query(postgres_conn,last_migrated_time_query)
            if not last_migrated_df.empty:
                    last_migrated_time_job=last_migrated_df['job_end_time'][0]
            else:
                last_migrated_time_job=None
                logging.info(f"{trace_id} DataFrame 'job_start_df' is empty.")
                    # last_migrated_time_job=last_migrated_df['job_start_time'][0]
                # logging.info(f"Last migrated time is {last_migrated_time_job}")

            logging.info(f"{trace_id} Error id list {error_id_list}, type is {type(error_id_list)}")
            logging.info(f"{trace_id} Last migrated time is {last_migrated_time_job}")


            if table_flag:
                logging.info(f"{trace_id} Table to Table migration")
                from_table=migration_details_dict['from_table']
                from_database=migration_details_dict['from_database']
                if not self.is_valid_table_name(from_table):
                    full_from_table=f'[{from_database}].[dbo].[{from_table}]'
                    # logging.info(f"full table name {full_from_table}")
                else:
                    full_from_table=from_table
                logging.info(f"{trace_id} The last id migrated is {last_id} from column {time_column_check},{full_from_table}")
                from_query=self.get_updated_records_query(time_columns,last_id,full_from_table,None,error_id_list)

            else:
                if last_migrated_time_job:
                    last_migrated_time=last_migrated_time_job
                else:
                    last_migrated_time=migration_details_dict['last_migrated_time']

                logging.info(f"{trace_id} {job_name} The last id migrated is {last_id} from column {time_column_check}")
                logging.info(f"{job_name} calling from_query")
                from_query_=migration_details_dict['from_query']
                logging.info(f"from_query from db is {from_query_}")
                to_query=migration_details_dict['to_query']

                if "modified_date" in from_query_.lower() and "created_date" in from_query_.lower() and isinstance(last_id[0], str) :
                    logging.info("This condition handles syncing tables that have a UUID-type ID column.")
                    logging.info(f"{type(last_id[0])} {last_id}")
                    logging.info(f"{trace_id} last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} last migrated time after fn is {last_migrated_time_str} and type{type(last_migrated_time_str)}")
                    time_columns_dup=['DATEADD(MINUTE, -DATEDIFF(MINUTE, GETUTCDATE(), GETDATE()), CreatedDate)']
                    time_columns_dup.append('ModifiedDate')
                    last_id_dup=[last_migrated_time_str]
                    last_id_dup.append(last_migrated_time_str)
                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    #logging.info(time_columns_dup,"############################## time_columns_dup",last_id_dup) #it contains last id, last_migrated_time
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")

                elif (('deleteddate' in from_query_.lower() or 'deleted_date' in from_query_.lower())
                    and ('modifieddate' in from_query_.lower() or 'modified_date' in from_query_.lower())):

                    # last_migrated_time=migration_details_dict['last_migrated_time']
                    logging.info(f"Both deleteddate and modifieddate are present in the query")
                    logging.info(f"{trace_id} deleteddate,modifieddate last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} deleteddate,modifieddate last migrated time after fn is {last_migrated_time_str} and type {type(last_migrated_time_str)}")
                    time_columns_dup=copy.deepcopy(time_columns)
                    # time_columns_dup.append('ModifiedDate','DeletedDate')
                    last_id_dup=copy.deepcopy(last_id)
                    # last_id_dup.append(last_migrated_time_str,last_migrated_time_str)
                    time_columns_dup.extend(['ModifiedDate', 'DeletedDate'])
                    last_id_dup.extend([last_migrated_time_str, last_migrated_time_str])

                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")

                elif 'modifieddate' in from_query_.lower() or 'modified_date' in from_query_.lower():
                    # last_migrated_time=migration_details_dict['last_migrated_time']
                    logging.info(f"{trace_id} last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} last migrated time after fn is {last_migrated_time_str} and type{type(last_migrated_time_str)}")
                    time_columns_dup=copy.deepcopy(time_columns)
                    time_columns_dup.append('ModifiedDate')
                    last_id_dup=copy.deepcopy(last_id)
                    last_id_dup.append(last_migrated_time_str)

                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    #logging.info(time_columns_dup,"time_columns_dup",last_id_dup) it contains last id, last_migrated_time
                    #return None
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")

                #handling date_of_change for device_status_history table
                elif 'dateofchange' in from_query_.lower() or 'date_of_change' in from_query_.lower():
                    # last_migrated_time=migration_details_dict['last_migrated_time']
                    logging.info(f"{trace_id} dateofchange last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} dateofchange last migrated time after fn is {last_migrated_time_str} and type{type(last_migrated_time_str)}")
                    time_columns_dup=copy.deepcopy(time_columns)
                    time_columns_dup.append('DateOfChange')
                    last_id_dup=copy.deepcopy(last_id)
                    last_id_dup.append(last_migrated_time_str)

                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    #logging.info(time_columns_dup,"time_columns_dup",last_id_dup) it contains last id, last_migrated_time
                    #return None
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")
                #also need to handle when only deleted date is present
                elif 'deleteddate' in from_query_.lower() or 'deleted_date' in from_query_.lower():
                    logging.info(f"only deleteddate is present in the query")
                    logging.info(f"{trace_id} deleteddate last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    last_migrated_time_str=self.to_mssql_datetime(f'{last_migrated_time}')
                    logging.info(f"{job_name} deleteddate,last migrated time after fn is {last_migrated_time_str} and type {type(last_migrated_time_str)}")
                    time_columns_dup=copy.deepcopy(time_columns)
                    time_columns_dup.append('DeletedDate')
                    last_id_dup=copy.deepcopy(last_id)
                    last_id_dup.append(last_migrated_time_str)

                    logging.info(f"{trace_id} {job_name} after modifying time col and last_migrated time {time_columns},{time_columns_dup},{last_id},{last_id_dup}")
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    from_query=self.get_updated_records_query(time_columns_dup,last_id_dup,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} after updating query {from_query}")

                else:
                    from_query_=' '.join(from_query_.split())
                    from_query_=from_query_.rstrip(';')
                    from_query=self.get_updated_records_query(time_columns,last_id,None,from_query_,error_id_list)
                    logging.info(f"{trace_id} {job_name} From query git is  {from_query}")

            logging.info(f"common process for both")
            #establishing from conn
            db_config=self.get_db_config(migration_details_dict)
            from_host=db_config['hostname']
            from_port=db_config['port']
            from_user=db_config['user']
            from_pwd=db_config['password']
            from_db_type=db_config['from_db_type']
            from_driver=os.getenv('MSSQL_DB_DRIVER')
            from_database=migration_details_dict['from_database']
            from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
            logging.info(f"{trace_id} Connection ssms: {from_connection}")

            from_query=' '.join(from_query.split())
            from_query=from_query.rstrip(';')
            logging.info(f"{trace_id} going to count query is {from_query}")
            count_query=self.get_count_query(from_query)

            try:
                batch_queries,total_count=self.generate_batch_queries(count_query,from_query,from_connection,df_size,time_column_check)

                if batch_queries is False and total_count is False:
                    logging.error(f"{trace_id} Error in generating batch queries")
                    error_msg="Error in generating batch queries"
                    update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                    self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                    if postgres_conn:
                        postgres_conn.close()
                        logging.info("Connection closed.")
                    return False

            except Exception as e:
                logging.error(f"{trace_id} Error in generating batch queries {e}")
                tb = traceback.format_exc()
                update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                if postgres_conn:
                    postgres_conn.close()
                    logging.info("Connection closed.")
                return False

            if total_count==0:
                logging.info(f"{trace_id} No records found for migration")
                msg=f"No records found for migration"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'total_count':total_count,'success':0,'failed':0,'job_status_msg':'SUCCESS'}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                if postgres_conn:
                    postgres_conn.close()
                    logging.info("Connection closed.")
                return True
            else:
                logging.info(f"Total count is {total_count}")
                update_dict={'total_count':total_count}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})


            max_retries=3
            if batch_queries:
                for query in batch_queries:
                    logging.info(f"{trace_id} {job_name} executing query {query}")
                    attempt=0
                    df=None
                    try:
                        while attempt < max_retries:
                            if not self.check_connection(from_connection):
                                logging.warning("Connection lost. Attempting to reconnect...")
                                from_connection=self.create_connection(from_db_type,from_host,from_database,from_user,from_pwd,from_port,from_driver)
                                if from_connection is None:
                                    logging.error("Failed to re-establish connection.")
                                    break
                            df=self.execute_query(from_connection,query)

                            if df is not None:
                                df = df.astype(object).mask(df.isna(), None)
                                # logging.info(f"{trace_id} {job_name} Dataframe got is \n {df.head()}")
                                logging.info(f"{trace_id} {job_name}The number of rows in the DataFrame is: {df.shape[0]}")
                                df=self.modify_uuid_cols(df)
                                break  # Exit the retry loop if successful
                            else:
                                logging.error(f"{trace_id} {job_name} Error in executing query, retrying...")
                                attempt += 1
                                time.sleep(5)
                    except Exception as e:
                        logging.error(f"{trace_id} {job_name} An error occurred: {str(e)}")
                        attempt += 1
                        time.sleep(5)

                    if df is None:
                        logging.info(f"{trace_id} Error in executing query, check the query once")
                    else:
                        # df=self.execute_query(from_connection,from_query)
                        # df = df.astype(object).mask(df.isna(), None)
                        # logging.info(f"{job_name} DataFrame is \n {df.head()}")
                        logging.info(f"{trace_id} {job_name} ############# The number of rows in the DataFrame is: {df.shape[0]}")
                        # logging.info(f'{job_name} the last 5 rows:{df.tail(1)}')



                        success_count=self.initate_complete_migration(df,to_connection,postgres_conn,migration_table,job_name,migration_details_dict,to_table,db_config,trace_id,total_count,success_count)
            else:
                logging.info(f"{trace_id} No batch Queries formed, check count")
                msg=f"No batch Queries formed, check count"
                update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                from_connection.close()
                return True
        except Exception as e:
            from_connection.close()
            tb = traceback.format_exc()
            try:
                load_dotenv()
                hostname = os.getenv("PSQL_DB_HOST")
                port = os.getenv("PSQL_DB_PORT")
                db_name = os.getenv("PSQL_DB_NAME")
                user = os.getenv("PSQL_DB_USER")
                password = os.getenv("PSQL_DB_PASSWORD")
                db_type = os.getenv("PSQL_DB_TYPE")
                common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                postgres_conn_common = self.create_connection(
                db_type, hostname, common_db_name, user, password, port
                )
    #             update_dict={
    #                 "subject":"AMOP: UAT : 1.0 to 2.0 (Forward Sync) - occured as exception",
    #                 "Body":(
    #     f"An exception occurred during the forward sync job.\n\n"
    #     f"Job Name: {job_name}\n"
    #     f"Error Message: {str(e)}\n\n"
    #     f"Please investigate the issue at the earliest.\n\n"
    #     f"Regards,\nAMOP Lambda Monitor"
    # )
    #             }
    #             self.update_table(
    #                postgres_conn_common,
    #                 "email_templates",
    #                 update_dict,
    #                 {"template_name": "Sync Error"},
    #             )
    #             result = send_email("Sync Error", user_mail="vyshnavi.k@algonox.com")
            except Exception as e:
                logging.info(f"Error in mail sending: {e}")

                pass
            logging.error(f"{trace_id} Error in last_id_migration {e} {tb}")
            error_msg=f"Error in last_id_migration {e} {tb}"
            update_dict={'error_msg':error_msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
            return False
        finally:
            # Close the database connection
            if postgres_conn:
                postgres_conn.close()
                logging.info("Connection closed.")
            if from_connection:
                from_connection.close()
                logging.info("Source connection closed.")
    def execute_update_queries(self,queries,to_database,set_session,postgres_conn):
        # logging.info(queries)
        # logging.info(to_database)
        # db_name=to_database
        # hostname = os.getenv('PSQL_DB_HOST')
        # port = os.getenv('PSQL_DB_PORT')
        # user = os.getenv('PSQL_DB_USER')
        # password = os.getenv('PSQL_DB_PASSWORD')
        # db_type = os.getenv('PSQL_DB_TYPE')
        # postgres_conn = self.create_connection(
        #         db_type, hostname, db_name, user, password, port
        #     )

        try:
            cursor = postgres_conn.cursor()
            if set_session:
                logging.info(f"setting the session varible to true")
                cursor.execute("SELECT set_config('myvars.update_in_progress', 'true', true)")
                errors = []
            for query_dict in queries:
                # Loop through each query key-value pair in the dictionary
                for query_name, query_text in query_dict.items():
                    logging.info(f"Executing {query_name}: {query_text}")
                    start_time = time.time()
                    try:
                    # Execute the SQL query
                        cursor.execute(query_text)
                        end_time = time.time()

                        # Calculate the duration (in seconds)
                        duration = end_time - start_time
                        logging.info(f"Executed {query_name} successfully in {duration:.2f} seconds.")

                        # Optionally, commit the transaction if needed
                        #postgres_conn.commit()

                    except Exception as e:
                    # If there is an error, logging.info the error message and continue

                        logging.info(f"Error executing {query_name}: {e}")
                        errors.append({
                        "error_query": query_name,
                        "trigger_name":"error updating inventory data from 1.0",
                        "error_msg": str(e),
                        "error_timestamp":datetime.now(timezone.utc).replace(tzinfo=None)
                        })
                        postgres_conn.rollback()

            if set_session:
                logging.info(f"setting the session varible to false")
                cursor.execute("SELECT set_config('myvars.update_in_progress', 'false', true)")
            for err in errors:
                try:
                    insert_error = """
                    INSERT INTO public.trigger_error_logs (
                        trigger_name, error_msg,error_query, error_timestamp
                    )
                    VALUES (%s, %s, %s, %s, %s)
                    """
                    cursor.execute(insert_error, (
                        err["trigger_name"], err["error_msg"],
                         err["trigger_table"], err["error_query"],
                        err["error_timestamp"]
                    ))
                    postgres_conn.commit()
                    logging.info("Logged error to trigger_error_logs.")
                except Exception as insert_ex:
                    logging.info(f"Failed to log error to trigger_error_logs: {insert_ex}")
                    postgres_conn.rollback()
            postgres_conn.commit()
            cursor.close()
        except Exception as e:
            logging.info(f"Error connecting to database or creating cursor: {e}")
        finally:
        # Close the database connection
            if postgres_conn:
                postgres_conn.close()
                logging.info("Connection closed.")


    def execute_update_queries_bak_21_05_2025(self,queries,to_database):
        #commenting this function to resolve the blocking querues issue in uat
        # logging.info(queries)
        # logging.info(to_database)
        db_name=to_database
        hostname = os.getenv('PSQL_DB_HOST')
        port = os.getenv('PSQL_DB_PORT')
        user = os.getenv('PSQL_DB_USER')
        password = os.getenv('PSQL_DB_PASSWORD')
        db_type = os.getenv('PSQL_DB_TYPE')
        postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

        try:
            cursor = postgres_conn.cursor()
            for query_dict in queries:
                # Loop through each query key-value pair in the dictionary
                for query_name, query_text in query_dict.items():
                    logging.info(f"Executing {query_name}: {query_text}")
                    start_time = time.time()
                    try:
                    # Execute the SQL query
                        cursor.execute(query_text)
                        end_time = time.time()

                        # Calculate the duration (in seconds)
                        duration = end_time - start_time
                        logging.info(f"Executed {query_name} successfully in {duration:.2f} seconds.")

                        # Optionally, commit the transaction if needed
                        postgres_conn.commit()

                    except Exception as e:
                    # If there is an error, logging.info the error message and continue
                        logging.error(f"Error executing {query_name}: {e}")
                        postgres_conn.rollback()
            cursor.close()
        except Exception as e:
            logging.error(f"Error connecting to database or creating cursor: {e}")
        finally:
        # Close the database connection
            if postgres_conn:
                postgres_conn.close()
                logging.info("Connection closed.")

    def initate_complete_migration(self,df,to_connection,postgres_conn,migration_table,job_name,migration_details_dict,to_table,db_config,trace_id,total_count,success_count=0):
        try:
            to_db_name =migration_details_dict['to_database']
            time_column_check=migration_details_dict['time_column_check']
            time_columns = [col.strip() for col in time_column_check.split(',')]

            # logging.info(f"time column check got is {time_columns}")
            primary_id_col=migration_details_dict['primary_id_column']
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')

            if not to_table:
                logging.info(f"{trace_id} to table is emty so getting temp_table and to_mapping list")
                temp_table=migration_details_dict['temp_table']
                to_mapping=migration_details_dict['table_mappings']

                logging.info(f"{trace_id} temp table to insert data is {temp_table}")
                logging.info(f"{trace_id} table mappings {to_mapping}")

                insert_records,success,failures,last_id_time=self.insert_records_postgresql_batch_5(to_connection,df,temp_table,primary_id_col,time_columns,trace_id)

                if last_id_time is None:
                    logging.info(f"{trace_id} last_id is {last_id_time}")
                    last_id_time=self.update_last_id_list(to_db_name,to_table,time_columns,primary_id_col)
                    logging.info(f"{trace_id} last_id after {last_id_time}")

                table_names = [item["table_name"] for item in to_mapping]
                logging.info(f"{trace_id} insertion in temp table is done, transferring to tables: {table_names}")

                logging.info(f"{trace_id} now neeed to insert queries in tables")

                insert_flag, inserted_records, failed_records, last_id_tm=self.insert_records_postgresql_to_mapping(postgres_conn,to_mapping,primary_id_col,time_columns)
                logging.info(f"insert_flag :{insert_flag}")
                logging.info(f"inserted_records :: {inserted_records} failed_records {failed_records}")
                logging.info(f"last_id_time_ is {last_id_tm}")

                if insert_flag:
                    logging.info(f"################################## Migration Successfull")

                else:
                    logging.warning(f"Errors in Migration")
                    last_id_tm=None

                # migration_details_dict_updated=self.update_migration_details_dict(migration_details_dict,insert_records,success,failures,last_id_time,db_config)
                # migration_details_dict_updated['table_mappings']=json.dumps(to_mapping)
                migration_details_dict_updated=self.update_migration_details_dict(insert_records,success,failures,last_id_time)
                logging.info(f"{job_name} migration details dict {migration_details_dict_updated}")
                logging.info(f"###################### Details to update in table \n Status:{migration_details_dict_updated['status']},Last ID:{migration_details_dict_updated['last_id']},Migration Update:{migration_details_dict_updated['migration_update']}")
                logging.info(f"Updating table")
                uu=self.update_table(postgres_conn,migration_table,migration_details_dict_updated,{'migration_name':job_name})
                return True

            else:
                logging.info(f"{trace_id} To table is {to_table}")
                # insert_records,success,failures,last_id_time=self.insert_records_postgresql_batch_5(to_connection,df,to_table,primary_id_col,time_columns)

                insert_records,success,failures,last_id_time,error_msg,error_id_list=self.insert_records_postgresql_batch_5(to_connection,df,to_table,primary_id_col,time_columns,trace_id)
                success_count+=success
                logging.warning(f"{trace_id} Error ID list is {error_id_list}")

                if total_count:
                    if success_count+failures==total_count:
                        logging.info(f"Migration completed successfully")
                        job_status_msg='SUCCESS'
                    else:
                        job_status_msg='FAILED'

                if last_id_time is None:
                        last_id_time=self.update_last_id_list(to_db_name,to_table,time_columns,primary_id_col)



                # migration_details_dict_updated=self.update_migration_details_dict(migration_details_dict,insert_records,success,failures,last_id_time,db_config)
                migration_details_dict_updated=self.update_migration_details_dict(insert_records,success,failures,last_id_time,error_msg)

                logging.info(f"{trace_id} {job_name} ############################# Details to update in table \n Status:{migration_details_dict_updated['status']},Last_ID:{migration_details_dict_updated['last_id']},Migration Update:{migration_details_dict_updated['migration_update']}")
                logging.info(f"{trace_id} {job_name} Updating table")
                to_database=migration_details_dict['to_database']

                if migration_details_dict['is_update']:
                    queries=migration_details_dict['update_queries']
                    inv_update=migration_details_dict['inv_update']
                    self.execute_update_queries(queries,to_database,inv_update,to_connection)

                logging.info(f"{trace_id} {job_name} Updating tables after migration is done")
                uu=self.update_table(postgres_conn,migration_table,migration_details_dict_updated,{'migration_name':job_name})

                update_hist_table={'error_id_list':json.dumps(error_id_list),'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_msg,'success':success_count,'failed':failures,'job_status_msg':job_status_msg}
                self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})

                return success_count


        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"{trace_id} {job_name} error while completing migration: {e} {tb}")
            error_message=f"error while completing migration: {e} {tb}"
            update_hist_table={'error_id_list':json.dumps(error_id_list),'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_message}
            self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})
            return False


    def insert_records_postgresql_to_mapping(self,postgres_connection, tables_dict, migration_track_col, time_columns):
        logging.info(f"#######################################################")
        # logging.info(f"Starting postgres connection is {postgres_connection}")
        inserted_records = 0
        failed_records = 0
        insert_flag = True
        batch_size = 5000
        failed_log = []
        last_id_time = None
        total_start_time = time.time()

        def insert_table_data(df, table_name):
            nonlocal inserted_records, failed_records, last_id_time, insert_flag

            columns = df.columns.tolist()
            num_batches = math.ceil(len(df) / batch_size)
            # logging.info(f"Processing table {table_name} with {len(columns)} columns")
            # logging.info(f"Number of Batches Created: {num_batches} with batch size {batch_size}")

            # # Prepare the SQL queries
            # columns_str = ', '.join(columns)
            # update_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in columns])

            safe_columns = [self.pg_safe_col(col) for col in columns]
            columns_str = ', '.join(safe_columns)

            update_clause = ', '.join(
                f"{self.pg_safe_col(col)} = EXCLUDED.{self.pg_safe_col(col)}"
                for col in columns
            )

            insert_query_update = f'''
                INSERT INTO {table_name} ({columns_str})
                VALUES %s
                ON CONFLICT ({migration_track_col}) DO UPDATE
                SET {update_clause}
            '''
            insert_query_no_conflict = f'INSERT INTO {table_name} ({columns_str}) VALUES %s'

            for batch_index in range(num_batches):
                start_index = batch_index * batch_size
                end_index = min((batch_index + 1) * batch_size, len(df))

                batch_df = df.iloc[start_index:end_index]
                rows = [tuple(row) for row in batch_df.to_numpy()]

                batch_start_time = time.time()

                try:
                    with postgres_connection.cursor() as cur:
                        execute_values(cur, insert_query_no_conflict, rows)
                    postgres_connection.commit()
                    inserted_records += len(rows)
                except psycopg2.Error as e:
                    logging.warning(f"Error inserting batch {batch_index + 1} without ON CONFLICT: {e}")
                    postgres_connection.rollback()

                    try:
                        with postgres_connection.cursor() as cur:
                            execute_values(cur, insert_query_update, rows)
                        postgres_connection.commit()
                        inserted_records += len(rows)
                    except psycopg2.Error as e2:
                        logging.warning(f"Error inserting batch {batch_index + 1} with ON CONFLICT: {e2}")
                        postgres_connection.rollback()

                        for row_index, row in batch_df.iterrows():
                            try:
                                with postgres_connection.cursor() as cur:
                                    cur.execute(insert_query_no_conflict, (tuple(row),))
                                postgres_connection.commit()
                                inserted_records += 1
                            except psycopg2.Error as e3:
                                logging.warning(f"Error inserting row {row_index + start_index} without ON CONFLICT: {e3}")
                                postgres_connection.rollback()

                                try:
                                    with postgres_connection.cursor() as cur:
                                        cur.execute(insert_query_update, (tuple(row),))
                                    postgres_connection.commit()
                                    inserted_records += 1
                                except psycopg2.Error as e4:
                                    logging.warning(f"Error inserting row {row_index + start_index} with ON CONFLICT: {e4}")
                                    postgres_connection.rollback()
                                    failed_records += 1
                                    insert_flag = False
                                    failed_log.append({
                                        'table_name': table_name,
                                        'batch_index': batch_index,
                                        'row_index': row_index + start_index,
                                        'error': str(e4),
                                        'failed_id': row[migration_track_col]  # Capture ID of the failed record
                                    })
                                    with open('error_log.txt', 'a') as f:
                                        f.write(f"Failed row details:\nTable: {table_name}\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e4)}\nFailed ID: {row[migration_track_col]}\n\n")

                batch_end_time = time.time()
                logging.info(f"Inserted batch {batch_index + 1} of {num_batches} with {len(rows)} records")
                logging.info(f"Batch insertion time: {batch_end_time - batch_start_time:.2f} seconds")

                last_id_time = [batch_df[col].iloc[-1] for col in time_columns]

        for table_dict in tables_dict:
            query = table_dict.get("query")
            # logging.info(f"query is {query}")
            table_name = table_dict.get("table_name")
            logging.info(f"the data to be inserted on table {table_name}")

            try:

                df = self.execute_query(postgres_connection, query)
                df = df.astype(object).mask(df.isna(), None)
                logging.info(f"query result is \n {df.head()}")
                logging.info(f"The number of rows in the DataFrame is: {df.shape[0]}")

                insert_table_data(df, table_name)
            except Exception as e:
                logging.error(f"Error executing query or inserting data into table {table_name}: {e}")
                with open('error_log.txt', 'a') as f:
                    f.write(f"Error executing query or inserting data into table {table_name}: {str(e)}\n")

        total_end_time = time.time()
        logging.info(f"Total insertion time: {total_end_time - total_start_time:.2f} seconds")
        last_id_time_=self.jsonify_last_id(last_id_time)
        logging.info(f"last_id_time_ is {last_id_time_}")

        return insert_flag, inserted_records, failed_records, last_id_time_

    def pg_safe_col(self, col):
        """
        Quote PostgreSQL reserved keywords.
        """
        if col.lower() in {"group", "type", "user", "order", "value", "limit"}:
            return f'"{col}"'
        return col

    def convert_dict_to_json(self, value):
        """
        Convert dict or list values to JSON strings for PostgreSQL insertion.
        """
        if isinstance(value, (dict, list)):
            return json.dumps(value)
        return value

    def modify_uuid_cols(self,df):
        # Regular expression pattern for UUID
        uuid_pattern = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')

        # Step 1: Identify columns that contain UUIDs
        uuid_columns = []
        for col in df.columns:
            if df[col].apply(lambda x: bool(uuid_pattern.match(str(x)))).any():
                uuid_columns.append(col)

        # Step 2: Convert identified UUID columns to strings
        for col in uuid_columns:
            # df[col] = df[col].astype(str)
            # Apply conversion only where value is a valid UUID
            df[col] = df[col].apply(lambda x: str(x) if pd.notna(x) and uuid_pattern.match(str(x)) else x)
        # logging.info the columns identified as containing UUIDs
        logging.info(f"Columns identified as containing UUIDs: {uuid_columns}")
        return df

    def check_connection(self, connection):
        """
        Check if the connection is still active by executing a simple query.

        Args:
            connection: The database connection object.

        Returns:
            bool: True if the connection is active, False otherwise.
        """
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT 1")
            return True
        # except pyodbc.Error:
        except pytds.DatabaseError:
            return False

    def recognize_format(self,s):
        pattern1 = r'^[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)+$'
        pattern2 = r'^\[[a-zA-Z0-9]+\](\.\[[a-zA-Z0-9]+\])+$'
        pattern3 = r'^[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)+$'          # No brackets format
        pattern4 = r'^\[[a-zA-Z0-9_]+\](\.\[[a-zA-Z0-9_]+\])+$'
        pattern5= r'^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)+$'

        if re.match(pattern1, s):
            return True
        elif re.match(pattern2, s):
            return True
        elif re.match(pattern3, s):
            return True
        elif re.match(pattern4, s):
            return True
        elif re.match(pattern5, s):
            return True
        else:
            return False

    def clean_query(self, original_query):
    # Split the query by 'ORDER BY' into parts
        parts = original_query.rsplit('ORDER BY')
        #return None
    # Count the number of ORDER BY clauses
        order_by_count = len(parts) - 1  # Each 'ORDER BY' splits the query into parts

    # Check if there are multiple ORDER BY clauses
        if order_by_count > 1:
        # Rebuild the query without the second ORDER BY clause
            query_without_second_order_by = parts[0] + 'ORDER BY' + ''.join(parts[1:2])  # Keep the first ORDER BY and everything after the first
        elif order_by_count == 1:
        # Only one ORDER BY found, return the part before it
            query_without_second_order_by = parts[0]
        else:
            # No ORDER BY found
            query_without_second_order_by = original_query

    # Remove trailing semicolon and whitespace
        query_cleaned = query_without_second_order_by.rstrip(';').strip()

        return query_cleaned  # Return both cleaned query


    def get_count_query(self,original_query):
        # Clean the original query
        cleaned_query = self.clean_query(original_query)

        # Construct the count query
        count_query = f"""
        SELECT COUNT(*) AS total_count
        FROM (
            {cleaned_query}
        ) AS subquery;
        """
        logging.info(f"count_query {count_query}")
        return count_query

    def generate_batch_queries(self, count_query, from_query, db_conn, df_size, time_column_check):
        """
        Generate batch SQL queries for pagination from a SQL Server database.

        Parameters:
        - count_query (str): SQL query to get the count of records.
        - from_query (str): SQL query to fetch the records.
        - df_size (int): Number of records per batch.

        Returns:
        - List[str]: List of SQL queries for each batch.
        """
        try:
            logging.info(f"primary id col is {time_column_check}")
            # List to hold the batch queries
            batch_queries = []
            logging.info(f"count query is {count_query}")
            try:
                with db_conn.cursor() as cursor:
                    # Execute the count query
                    # db_conn.timeout = 180000
                    # cursor.timeout=180000
                    #logging.info("Cursor timeout:", cursor.timeout)

                    cursor.execute(count_query)
                    total_count = cursor.fetchone()[0]
            except Exception as e:
                tb = traceback.format_exc()
                logging.error(f"Exception in executing count query {e},{tb}")
                return False,False


            logging.info(f"TOTAL COUNT {total_count} type {type(total_count)}")
            if total_count == 0:
                return False,0
                # raise ValueError("No Updated Records in DB")

            # Split the query into words to extract the last 5 words
            # last_five_words = from_query.split()[-5:]  # Get the last 5 words
            last_five_words =  [word.lower() for word in from_query.split()[-4:]]
            # logging.info(f"Last five words of the query: {last_five_words}")

            # Check if 'order by' is in the last 5 words
            if 'order' in last_five_words and 'by' in last_five_words:
                # logging.info(f"'ORDER BY' clause present")
                # Use the existing ORDER BY clause
                from_query = from_query.rstrip(';')
                base_query = from_query
            else:
                # logging.info(f"Adding 'ORDER BY'")
                # logging.info(f"time_column_check col is {time_column_check}")
                # Add a placeholder ORDER BY clause
                base_query = f"{from_query} ORDER BY {time_column_check}"

            # Calculate the total number of batches needed
            num_batches = (total_count + df_size - 1) // df_size

            # Generate batch queries
            for batch_number in range(num_batches):
                # Calculate the offset
                offset = batch_number * df_size

                # Construct the batch query with OFFSET and FETCH NEXT
                batch_query = (
                    f"{base_query} "
                    f"OFFSET {offset} ROWS "
                    f"FETCH NEXT {df_size} ROWS ONLY"
                )
                # logging.info(f"batch_query : {batch_query}")

                # Append the batch query to the list
                batch_queries.append(batch_query)

            return batch_queries,total_count
        except Exception as e:
            logging.error(f"Exception in count checking {e}")
            return False,False


    def generate_batch_queries_bak9oct24(self,count_query, from_query,db_conn, df_size,primary_id_col): #in order by checking its checking in whole query
        """
        Generate batch SQL queries for pagination from a SQL Server database.

        Parameters:
        - count_query (str): SQL query to get the count of records.
        - from_query (str): SQL query to fetch the records.
        - df_size (int): Number of records per batch.

        Returns:
        - List[str]: List of SQL queries for each batch.
        """
        try:
            logging.info(f"primary id col is {primary_id_col}")
            # List to hold the batch queries
            batch_queries = []

            with db_conn.cursor() as cursor:
                # Execute the count query
                cursor.execute(count_query)
                total_count = cursor.fetchone()[0]

            logging.info(f"TOTAL COUNT {total_count} type {type(total_count)}")
            if total_count==0:
                raise ValueError("No Updated Records in DB")

            # Determine if the from_query already contains an ORDER BY clause
            if 'order by' in from_query.lower():
                logging.info(f"order by cluase present")
                # Use the existing ORDER BY clause
                from_query=from_query.rstrip(';')
                base_query = from_query

            else:
                logging.info(f"adding order by")
                logging.info(f"primary id col is {primary_id_col}")
                # Add a placeholder ORDER BY clause
                base_query = f"{from_query} ORDER BY {primary_id_col}"

            # Calculate the total number of batches needed
            # Assuming you will use `count_query` externally to determine the number of batches
            # For simplicity, let's assume a dummy total_count value here

            num_batches = (total_count + df_size - 1) // df_size

            # Generate batch queries
            for batch_number in range(num_batches):
                # Calculate the offset
                offset = batch_number * df_size

                # Construct the batch query with OFFSET and FETCH NEXT
                batch_query = (
                    f"{base_query} "
                    f"OFFSET {offset} ROWS "
                    f"FETCH NEXT {df_size} ROWS ONLY"
                )
                logging.info(f"batch_query : {batch_query}")

                # Append the batch query to the list
                batch_queries.append(batch_query)

            return batch_queries
        except Exception as e:
            logging.info(f"Exception in count checking {e}")
            return False

    def to_mssql_datetime(self,timestamp_str):
        """
        Convert a high-precision timestamp string to a format compatible with SQL Server's datetime.

        Args:
        - timestamp_str (str): A timestamp string with high precision (e.g., '2024-08-08 13:27:12.954566').

        Returns:
        - str: A string formatted as SQL Server datetime (e.g., '2024-08-08 13:27:12.954').
        """
        try:
            # Step 1: Parse the string timestamp into a Python datetime object
            dt = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S.%f')

            # Step 2: Truncate the microseconds to fit MSSQL datetime (3 digits of milliseconds)
            dt = dt.replace(microsecond=(dt.microsecond // 1000) * 1000)

            # Step 3: Convert the datetime object back to a string compatible with MSSQL datetime format
            mssql_datetime_str = dt.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

            return mssql_datetime_str
        except ValueError as e:
            raise ValueError(f"Invalid timestamp format: {timestamp_str}. Error: {e}")

    def get_all_records(self,connection,table_name,primary_id_col):
        try:
            df_rows=f"select * from {table_name} order by {primary_id_col}"
            df = self.execute_query(connection,df_rows)
            df = df.astype(object).mask(df.isna(), None)
            return df

        except Exception as e:
            logging.error(f"Error while fetching all records {e}")
            return None

    def load_last_id(self,last_id_str):
        try:
            # Attempt to convert to integer
            last_id_int = int(last_id_str)
            return last_id_int  # Return as integer if successful
        except ValueError:
            try:
                # Attempt to convert to datetime
                last_id_timestamp = datetime.strptime(last_id_str, '%Y-%m-%d %H:%M:%S')
                return last_id_timestamp
            except ValueError:
                try:
                    last_id_timestamp = datetime.fromisoformat(last_id_str)
                    return last_id_timestamp  # Return as datetime if successful
                except ValueError:
                    try:
                        last_id=json.loads(last_id_str)
                        return last_id
                    except ValueError:
                        logging.error(f"Error while loading last_id from db")
                        return None # Return None if conversion fails

    def enclose_uppercase_words(self,input_string):
        # Split the input string by commas and strip any surrounding whitespace
        words = [word.strip() for word in input_string.split(',')]

        # Function to check if a word contains uppercase characters
        def needs_quotes(word):
            return any(char.isupper() for char in word)

        # Enclose words with uppercase characters in double quotes
        quoted_words = [f'"{word}"' if needs_quotes(word) else word for word in words]

        # Join the words back into a single string separated by commas
        return ', '.join(quoted_words)

    def insert_dict(self, conn, table_name, data_dict,return_flag=False,return_col=None):
        """
        Insert a row into a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to insert into
        :param data_dict: Dictionary containing column-value pairs to insert
        """
        try:
            # Convert dictionary values to JSON strings if necessary
            for key, value in data_dict.items():
                if isinstance(value, dict):
                    data_dict[key] = json.dumps(value)

            # Generate the column names and placeholders for the SQL query
            columns = ', '.join(data_dict.keys())
            placeholders = ', '.join(['%s'] * len(data_dict))

            # Create the SQL query
            if return_flag:
                sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders}) RETURNING {return_col}"
            else:
                sql_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            values = list(data_dict.values())

            # logging.info(f"SQL Query: {sql_query}")
            # logging.info(f"Values: {values}")

            # Execute the query
            with conn.cursor() as cursor:
                cursor.execute(sql_query, values)
                if return_col:
                    return_val= cursor.fetchone()[0]
                conn.commit()
                # conn.commit()
            logging.info("Insert successful")
            if return_flag:
                return return_val
            else:
                return True
        except Exception as e:
            conn.rollback()
            logging.error(f"Error inserting into table: {e}")
            return False

    def is_valid_table_name(self,table_name):
        pattern = r'^\[\w+\]\.\[\w+\]\.\[\w+\]$'
        return re.match(pattern, table_name) is not None

    def update_table(self,conn, table_name, data_dict, condition_dict):
        """
        Update a PostgreSQL table using a dictionary.

        :param conn: psycopg2 connection object
        :param table_name: Name of the table to update
        :param data_dict: Dictionary containing column-value pairs to update
        :param condition_dict: Dictionary containing column-value pairs for the WHERE condition
        """
        try:
            # Generate the SET part of the SQL query
            set_clause = ', '.join([f"{col} = %s" for col in data_dict.keys()])

            if condition_dict:

            # Generate the WHERE part of the SQL query
                where_clause = ' AND '.join([f"{col} = %s" for col in condition_dict.keys()])


            if condition_dict:
            # Complete SQL query
                sql_query = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"
                values = list(data_dict.values()) + list(condition_dict.values())

            else:
                sql_query = f"UPDATE {table_name} SET {set_clause}"
                values = list(data_dict.values())

            # Combine the values for the SET and WHERE parts


            logging.info(f"SQL Quey {sql_query} and values are {values}")

            ## Execute the query
            with conn.cursor() as cursor:
                cursor.execute(sql_query, values)
                conn.commit()
            logging.info("################################## Update successful")
        except Exception as e:
            conn.rollback()
            logging.error(f"Error updating table: {e}")

    def camel_to_snake_case(self,camel_str):
        # Convert a camelCase or PascalCase string to snake_case
        return ''.join(['_' + i.lower() if i.isupper() else i for i in camel_str]).lstrip('_')

    def insert_records_postgresql_batch_5(self, postgres_connection, df, insert_table_name, primary_id_col, time_columns,trace_id):
        """
        Inserts records into a PostgreSQL table in batches, with error handling for individual rows.

        Args:
            postgres_connection: The connection object to the PostgreSQL database.
            df: The DataFrame containing the data to be inserted.
            insert_table_name: The name of the table where data will be inserted.
            migration_track_col: The column used for tracking the migration progress.
            time_columns: List of columns that hold timestamp data.

        Returns:
            A tuple containing:
            - insert_flag (bool): Indicates whether the insertion was successful.
            - inserted_records (int): The number of successfully inserted records.
            - failed_records (int): The number of failed records.
            - last_id_time (str): JSON string of the last timestamp(s) from the successfully inserted records.

        Process:
        1. Calculates the number of batches needed based on the batch size (5000).
        2. Attempts to insert each batch:
            a. First, with the ON CONFLICT clause to handle conflicts.
            b. If the batch insertion fails, tries inserting the batch without the ON CONFLICT clause.
            c. If the batch insertion still fails, attempts to insert each row individually:
                i. First, with the ON CONFLICT clause.
                ii. If the individual row insertion fails, tries without the ON CONFLICT clause.
        3. Logs errors for any rows that fail to insert.
        4. Tracks the number of successfully inserted and failed records.
        5. Calculates and logs the total insertion time.
        6. Serializes and returns the last timestamp(s) and id(S) from the successfully inserted records.

        Notes:
        - Retries for 3 times when insert/update fails
        - Logs detailed error messages and failed record IDs to 'error_log.txt'.
        """
        # logging.info(f"Inserting into table {insert_table_name}, column {migration_track_col}")
        # logging.info(f"time columns got are {time_columns}")
        try:

            inserted_records = 0
            failed_records = 0
            insert_flag = True
            batch_size = 5000
            failed_log = []
            last_id_time = None
            num_batches = math.ceil(len(df) / batch_size)
            error_msg='SUCCESS'
            error_id_list=[]
            stop_insertion=False
            logging.info(f"{trace_id} {insert_table_name} Records to insert: {df.shape[0]}")
            logging.info(f"{trace_id} {insert_table_name} No of Batches Created: {num_batches} with batch size {batch_size}")

            # Extract column names once
            columns = ', '.join(df.columns)
            # logging.info(f"Columns: {columns}")

            # Check for time_columns and convert to snake_case if not in columns
            time_column_snake_case = []

            for col in time_columns:
                if col not in columns:
                    # Convert camelCase to snake_case
                    snake_case_col = self.camel_to_snake_case(col)
                    time_column_snake_case.append(snake_case_col)
                else:
                    time_column_snake_case.append(self.camel_to_snake_case(col))  # Convert existing ones too

            logging.info(f"{trace_id} {insert_table_name} time_column_snake_case::: {time_column_snake_case}")

            # Prepare the update clause for ON CONFLICT
            #logging.info(update_clause)
            # Prepare the update clause for ON CONFLICT (excluding 'device_history_id')
            #update_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in df.columns  ])
            update_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in df.columns if col not in time_column_snake_case])

            #update_clause = ', '.join([f"{col} = EXCLUDED.{col}" for col in df.columns])
            # logging.info("*******************update_clause",update_clause)
            total_start_time = time.time()

            # Define the insert block operation
            def insert_block_operation():
                nonlocal inserted_records, failed_records, last_id_time, insert_flag,error_msg,stop_insertion,error_id_list

                for batch_index in range(num_batches):
                    # if stop_insertion:
                    #     break
                    start_index = batch_index * batch_size
                    end_index = min((batch_index + 1) * batch_size, len(df))

                    batch_df = df.iloc[start_index:end_index]
                    rows = [tuple(row) for row in batch_df.to_numpy()]

                    insert_query_update = f'''
                        INSERT INTO {insert_table_name} ({columns})
                        VALUES %s
                        ON CONFLICT ({primary_id_col}) DO UPDATE
                        SET {update_clause}
                    '''
                    # logging.info("#######################insert_query_update",insert_query_update)
                    # logging.info(f"update clause is {update_clause}")
                    insert_query_no_conflict = f'INSERT INTO {insert_table_name} ({columns}) VALUES %s'

                    batch_start_time = time.time()

                    try:
                        with postgres_connection.cursor() as cur:
                            # Attempt to insert the batch without ON CONFLICT clause
                            logging.info(f"{insert_table_name} Trying to insert without update")
                            execute_values(cur, insert_query_no_conflict, rows)
                        postgres_connection.commit()

                        inserted_records += len(rows)
                        logging.info(f"{trace_id} Inserted records are {inserted_records}")
                        # Update last_id_time with the values from the last row of the batch
                        last_id_time = [rows[-1][batch_df.columns.get_loc(col)] for col in time_column_snake_case]
                        # error_msg='Success'

                    except psycopg2.Error as e:
                        logging.warning(f"{trace_id} {insert_table_name} Warning inserting batch {batch_index + 1} without ON CONFLICT: {e}")
                        postgres_connection.rollback()  # Rollback after the first error

                        try:
                            with postgres_connection.cursor() as cur:
                                # Attempt to insert the batch with ON CONFLICT clause
                                logging.info(f"{trace_id} {insert_table_name} trying insert with update")
                                # logging.info("updating query execution starts")
                                # logging.info(f"insert query with update {insert_query_update}")
                                execute_values(cur, insert_query_update, rows)
                                # logging.info("executed the updating query execution starts")
                            postgres_connection.commit()
                            inserted_records += len(rows)

                            logging.info(f"{trace_id} Inserted records are {inserted_records}")
                            # Update last_id_time with the values from the last row of the batch
                            last_id_time = [rows[-1][batch_df.columns.get_loc(col)] for col in time_column_snake_case]
                            # error_msg='Success'

                        except psycopg2.Error as e2:
                            logging.warning(f"{trace_id} {insert_table_name} Warning inserting batch {batch_index + 1} with ON CONFLICT: {e2}")
                            postgres_connection.rollback()  # Rollback after the second error

                            # Try inserting rows individually
                            for row_index, row in batch_df.iterrows():
                                # if stop_insertion:
                                #     break
                                try:
                                    row_as_numpy = row.to_numpy()
                                    row_as_tuple = tuple(row_as_numpy)
                                    with postgres_connection.cursor() as cur:
                                        # Attempt to insert individual row without ON CONFLICT clause
                                        cur.execute(insert_query_no_conflict, (row_as_tuple,))
                                    postgres_connection.commit()
                                    inserted_records += 1
                                    error_msg='success'

                                    # Update last_id_time with the values from the current row
                                    last_id_time = [row[col] for col in time_column_snake_case]
                                except psycopg2.Error as e3:
                                    logging.warning(f"{insert_table_name} Error inserting row {row_index + start_index} without ON CONFLICT: {e3}")
                                    postgres_connection.rollback()  # Rollback after the third error

                                    try:
                                        row_as_numpy = row.to_numpy()
                                        row_as_tuple = tuple(row_as_numpy)
                                        with postgres_connection.cursor() as cur:
                                            # Attempt to insert individual row without ON CONFLICT clause
                                            cur.execute(insert_query_update, (row_as_tuple,))
                                        postgres_connection.commit()
                                        inserted_records += 1

                                        # Update last_id_time with the values from the current row
                                        last_id_time = [row[col] for col in time_column_snake_case]

                                    except psycopg2.Error as e4:
                                        logging.warning(f"{trace_id} {insert_table_name} Error inserting row {row_index + start_index} with ON CONFLICT: {e4}")
                                        postgres_connection.rollback()  # Rollback after the fourth error
                                        # stop_insertion = True
                                        error_id_=row[primary_id_col.lower()]
                                        logging.info(f"Error id is {error_id_}")
                                        error_id_list.append(error_id_)
                                        logging.info(f"Error id list is {error_id_list}")
                                        error_msg=str(e4)
                                        last_id_time = [row[col] for col in time_column_snake_case]
                                        failed_records += 1
                                        insert_flag = False
                                        # Log the failed row details
                                        failed_log.append({
                                            'batch_index': batch_index,
                                            'row_index': row_index + start_index,
                                            'error': str(e4),
                                            'failed_id': row['id']  # Capture ID of the failed record
                                        })
                                        # with open('error_log.txt', 'a') as f:
                                        #     f.write(f"Failed row details:\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e4)}\nFailed ID: {row['id']}\n\n")
                                        logging.error(
                                            f"{insert_table_name} Failed row details:\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e4)}\nFailed ID: {row['id']}\n\n"
                                        )
                    # else:
                    #     # If batch insertion is successful, count all rows as inserted
                    #     inserted_records += len(rows)

                    logging.info(f"{trace_id} Inserted records are {inserted_records}")

                    batch_end_time = time.time()
                    logging.info(f"{trace_id} {insert_table_name} Inserted batch {batch_index + 1} of {num_batches} with {len(rows)} records {batch_end_time - batch_start_time:.2f} seconds")
                    logging.info(f"{trace_id} {insert_table_name} Batch insertion time: {batch_end_time - batch_start_time:.2f} seconds")

                    # Update last_id_time with the time columns from the last row of the current batch
                    # last_id_time = [batch_df[col].iloc[-1] for col in time_columns] #uncomment this

                    # if batch_index == 4:
                    #     break

            # Retry the entire block operation up to 3 times
            # for attempt in range(3):
            try:
                insert_block_operation()
                # break  # Break the retry loop if successful
            except Exception as e:
                # logging.error(f"{trace_id} {insert_table_name} Error in whole insert block operation on attempt : {e}")
                last_id_time=None
                logging.error(
                    f"{trace_id} {insert_table_name} Error in whole insert block operation on attempt : {str(e)}\n"
                )
                error_msg=f"{trace_id} {insert_table_name} Error in whole insert block operation on attempt : {str(e)}"
                    # with open('error_log.txt', 'a') as f:
                    #     f.write(f"Error in whole insert block operation on attempt {attempt + 1}: {str(e)}\n")

            total_end_time = time.time()
            logging.info(f"{trace_id} {insert_table_name} Total insertion time: {total_end_time - total_start_time:.2f} seconds")

            # Serialize and jsonify the last_id_time
            logging.info(f"last_id_time is {last_id_time}")
            if last_id_time:
                last_id_time_ = self.serialize_timestamps_and_jsonify(last_id_time)
                logging.info(f"last_id_time_: {last_id_time_}")
            else:
                last_id_time=None

            if failed_records>0:
                last_id_time_=None

            # return insert_flag, inserted_records, failed_records, last_id_time_
        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"{trace_id} {insert_table_name} Error while inserting records {e}")
            error_msg=f"Error in inserting records {e} {tb}"
            return False,0,0,None,error_msg,error_id_list
        return insert_flag, inserted_records, failed_records, last_id_time_,error_msg,error_id_list


    def update_records_postgresql_batch(self, postgres_connection, df, update_table_name, migration_track_col, time_columns):
        """
        Updates records in a PostgreSQL table in batches, with error handling for individual rows.

        Args:
            postgres_connection: The connection object to the PostgreSQL database.
            df: The DataFrame containing the data to be updated.
            update_table_name: The name of the table where data will be updated.
            migration_track_col: The column used for tracking the migration progress.
            time_columns: List of columns that hold timestamp data.

        Returns:
            A tuple containing:
            - update_flag (bool): Indicates whether the update was successful.
            - updated_records (int): The number of successfully updated records.
            - failed_records (int): The number of failed records.
            - last_id_time (str): JSON string of the last timestamp(s) from the successfully updated records.

        Process:
        1. Calculates the number of batches needed based on the batch size (5000).
        2. Attempts to update each batch:
            a. Updates the batch records.
            b. If the batch update fails, tries updating the batch one record at a time.
        3. Logs errors for any rows that fail to update.
        4. Tracks the number of successfully updated and failed records.
        5. Calculates and logs the total update time.
        6. Serializes and returns the last timestamp(s) and id(S) from the successfully updated records.

        Notes:
        - Retries for 3 times when update fails
        - Logs detailed error messages and failed record IDs to 'error_log.txt'.
        """

        updated_records = 0
        failed_records = 0
        update_flag = True
        batch_size = 5000
        failed_log = []
        last_id_time = None
        num_batches = math.ceil(len(df) / batch_size)
        logging.info(f"############# Records to update: {df.shape[0]}")
        logging.info(f"########### No of Batches Created: {num_batches} with batch size {batch_size}")

        # Extract column names once, excluding the primary key column
        columns = [col for col in df.columns if col != 'id']
        column_names = ', '.join(columns)
        logging.info(f"Columns: {column_names}")

        # Prepare the set clause for the update statement
        set_clause = ', '.join([f"{col} = %s" for col in columns])
        update_query = f'''
            UPDATE {update_table_name}
            SET {set_clause}
            WHERE id = %s
        '''

        total_start_time = time.time()

        # Define the update block operation
        def update_block_operation():
            nonlocal updated_records, failed_records, last_id_time, update_flag

            for batch_index in range(num_batches):
                start_index = batch_index * batch_size
                end_index = min((batch_index + 1) * batch_size, len(df))

                batch_df = df.iloc[start_index:end_index]
                rows = [tuple(row) for row in batch_df.to_numpy()]

                batch_start_time = time.time()

                try:
                    with postgres_connection.cursor() as cur:
                        # Attempt to update the batch
                        logging.info(f"Trying to update batch {batch_index + 1}")
                        for row in rows:
                            cur.execute(update_query, (*row[1:], row[0]))
                    postgres_connection.commit()
                except psycopg2.Error as e:
                    logging.warning(f"Error updating batch {batch_index + 1}: {e}")
                    postgres_connection.rollback()  # Rollback after the first error

                    # Try updating rows individually
                    for row_index, row in batch_df.iterrows():
                        try:
                            with postgres_connection.cursor() as cur:
                                # Attempt to update individual row
                                cur.execute(update_query, (tuple(row[1:]), row['id']))
                            postgres_connection.commit()
                            updated_records += 1
                        except psycopg2.Error as e3:
                            logging.warning(f"Error updating row {row_index + start_index}: {e3}")
                            postgres_connection.rollback()  # Rollback after the third error
                            failed_records += 1
                            update_flag = False
                            # Log the failed row details
                            failed_log.append({
                                'batch_index': batch_index,
                                'row_index': row_index + start_index,
                                'error': str(e3),
                                'failed_id': row['id']  # Capture ID of the failed record
                            })
                            logging.error(
                                f"Failed row details:\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e3)}\nFailed ID: {row['id']}\n\n"
                            )
                            # with open('error_log.txt', 'a') as f:
                            #     f.write(f"Failed row details:\nBatch index: {batch_index}\nRow index: {row_index + start_index}\nError: {str(e3)}\nFailed ID: {row['id']}\n\n")
                else:
                    # If batch update is successful, count all rows as updated
                    updated_records += len(rows)

                batch_end_time = time.time()
                logging.info(f"Updated batch {batch_index + 1} of {num_batches} with {len(rows)} records")
                logging.info(f"Batch update time: {batch_end_time - batch_start_time:.2f} seconds")

                # Update last_id_time with the time columns from the last row of the current batch
                last_id_time = [batch_df[col].iloc[-1] for col in time_columns]

        # Retry the entire block operation up to 3 times
        for attempt in range(3):
            try:
                update_block_operation()
                break  # Break the retry loop if successful
            except Exception as e:
                logging.error(f"Error in whole update block operation on attempt {attempt + 1}: {e}")
                # with open('error_log.txt', 'a') as f:
                #     f.write(f"Error in whole update block operation on attempt {attempt + 1}: {str(e)}\n")

        total_end_time = time.time()
        logging.info(f"Total update time: {total_end_time - total_start_time:.2f} seconds")

        # Serialize and jsonify the last_id_time
        last_id_time_ = self.serialize_timestamps_and_jsonify(last_id_time)
        logging.info(f"last_id_time_: {last_id_time_}")

        return update_flag, updated_records, failed_records, last_id_time_


    def log_failed_batch(self,batch_index, error):
        with open('error_log.txt', 'a') as f:
            f.write(f"Failed batch details:\nBatch index: {batch_index}\nError: {str(error)}\n\n")

    def serialize_timestamps_and_jsonify(self,input_list):
        try:
            if input_list:
                serialized_list = []

                for item in input_list:
                    if isinstance(item, Timestamp):
                        serialized_list.append(item.to_pydatetime().isoformat())
                    elif isinstance(item, datetime):
                        serialized_list.append(item.isoformat())
                    else:
                        serialized_list.append(item)

                return json.dumps(serialized_list)
            else:
                return None
        except Exception as e:
            logging.info(f"Error serialize_timestamps_and_jsonify - {e}")
            return None

    def update_last_id_list(self,db_name, insert_table_name, time_check_cols, primary_id_col):
        try:
            postgres_connection = self.create_postgres_connection(db_name)
            last_id_time = []
            with postgres_connection.cursor() as cursor:
                # Constructing the SELECT query dynamically for multiple columns
                select_cols = ', '.join(time_check_cols)
                if not primary_id_col:
                    query=f"SELECT {select_cols} FROM {insert_table_name} ORDER BY {select_cols} DESC LIMIT 1"
                else:
                    query = f"SELECT {select_cols} FROM {insert_table_name} ORDER BY {primary_id_col} DESC LIMIT 1"

                cursor.execute(query)
                result = cursor.fetchone()


                if result:
                    for value in result:
                        if isinstance(value, datetime):
                            last_id_time.append(value.isoformat())
                        else:
                            last_id_time.append(value)
                else:
                    last_id_time = None

        except Exception as fetch_error:
            last_id_time = None
            logging.error(f"{insert_table_name} Error fetching last inserted record: {fetch_error}")

        return last_id_time

    def get_ssms_last_id(self, ssms_connection, full_from_table,id_column_10):
        """
            Retrieves the maximum ID from a specific table in the SQL Server database.

            Args:
                ssms_connection: The connection object to the SQL Server Management Studio (SSMS) database.
                full_from_table (str): The name of the table from which to fetch the maximum ID and last modified date.

            Returns:
                tuple: A tuple containing the maximum ID (int or None) .
                False: In case of an error during the query execution.
        """
        try:

        # Query to fetch the maximum ID and last modified date
            query = f"SELECT  TOP 1 {id_column_10} AS last_id  FROM {full_from_table} order by {id_column_10} desc;"
            logging.info(f"{query} query to get sandbox id  ")
        # Create a cursor and execute the query
            cursor = ssms_connection.cursor()
            cursor.timeout=360
            cursor.execute(query)

            result = cursor.fetchone()
            last_id = result[0] if result else None
            logging.info(f"last_id: {last_id} retrieved sandbox last id ")
            # Close the connection
            cursor.close()

            return last_id
        except Exception as e:
            logging.info(f"Error occurred in getting lastid from device_history table: {e}")
            return False

    def get_ssms_last_id_(self, ssms_connection, full_from_table): #removing on 11-dec-2024 fro revcustomer bug
        """
        Retrieves the maximum ID and last modified date from a specific table in the SQL Server database.

        Args:
            ssms_connection: The connection object to the SQL Server Management Studio (SSMS) database.
            full_from_table (str): The name of the table from which to fetch the maximum ID and last modified date.

        Returns:
            tuple: A tuple containing the maximum ID (int or None) and the last modified date in PostgreSQL format (str or None).
            False: In case of an error during the query execution.
        """
        try:
        # Query to fetch the maximum ID and last modified date
            query = f"SELECT MAX(id) AS last_id, MAX(modifieddate) AS last_modified_date FROM {full_from_table}"
            logging.info(f"{query}")
        # Create a cursor and execute the query
            cursor = ssms_connection.cursor()
            cursor.execute(query)

        # Fetch the result
            result = cursor.fetchone()
            if result:
                last_id = result[0]  # MAX(id)
                mssql_last_modified_date = result[1]  # MAX(modifieddate)

            # Convert MSSQL datetime to PostgreSQL-compatible format if it exists
                if mssql_last_modified_date:
                    psql_last_modified_date = mssql_last_modified_date.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    psql_last_modified_date = None
            else:
                last_id = None
                psql_last_modified_date = None

        # Close the cursor
            cursor.close()

        # Return the results as a tuple
            return last_id, psql_last_modified_date

        except Exception as e:
            logging.error(f"Error occurred:fn get_ssms_last_id {e}")
            return False

    def convert_timestamp_to_sql_datetime(self, ts):
        """
        Converts a pandas timestamp to a SQL-compatible datetime format.
        The function checks if the timestamp is null and returns None. Otherwise, it formats
        the timestamp to a string in the format 'YYYY-MM-DD HH:MM:SS.MMM' which is compatible
        with SQL datetime types.

        Args:
            ts (Timestamp or None): The pandas timestamp to convert.

        Returns:
            str or None: The formatted datetime string for SQL or None if the input is null.
        """
        if pd.isnull(ts):
            return None  # or 'NULL' if you are preparing a string for SQL queries
        return ts.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    def construct_merge_query(self, df, table_name, compare_column):
        """
        Constructs a SQL MERGE query for inserting or updating records in the target table.
        This function compares data from a pandas DataFrame with the target table using a specified
        comparison column and generates an appropriate SQL query.

        Args:
            df (pandas.DataFrame): The DataFrame containing the data to merge.
            table_name (str): The name of the target table.
            compare_column (str): The column to compare for matching records in the merge.

        Returns:
            str: The SQL MERGE query as a string.
        """
        compare_column=compare_column.lower()
        # if 'id' in df.columns:
        #     df = df.drop(columns=['id'])

        # Extract column names from the DataFrame to be used in the query
        columns = df.columns.tolist()

        # Prepare the column names for the query
        source_columns = ", ".join(columns)

        # Build the USING (VALUES...) section dynamically
        values_list = []
        for _, row in df.iterrows():
            values = []
            for col in columns:
                value = row[col]
                if pd.isnull(value):  # Handle NULL values
                    values.append("NULL")
                elif isinstance(value, str):  # Add quotes for string values
                    #values.append(f"'{value}'")
                    escaped_value = value.replace("'", "''")
                    values.append(f"'{escaped_value}'")
                else:
                    values.append(str(value))  # For numeric or boolean values
            values_list.append(f"({', '.join(values)})")

        values_section = ",    ".join(values_list)

        # Build the UPDATE SET part by excluding the compare_column
        '''update_set_clause = ",        ".join(
            [
                f"target.{col} = source.{col}"
                for col in columns if col != compare_column or col != "Id" or col != "id"
            ]
        )
        logging.info(update_set_clause)'''
        update_set_clause = ",        ".join(
        [
        f"target.{col} = source.{col}"
        for col in columns
        if col.lower() != compare_column.lower()  # Exclude "id" and compare_column
        ]
        )
        #logging.info(update_set_clause)
        #return None
        # Remove 'id' column if it exists in the DataFrame
        '''if "id" in df.columns:
            psql_values = df["id"].tolist()
            df = df.drop(columns=["id"])'''
        if compare_column in df.columns:
            logging.info(f"{compare_column} in df columns ")
            psql_values = df[compare_column].tolist()
            df = df.drop(columns=[compare_column])
        columns2 = df.columns.tolist()
        # Build the INSERT part using all columns
        insert_columns = ", ".join(columns2)
        insert_values = ", ".join([f"source.{col}" for col in columns2])

        # Construct the full MERGE query
        query = f"""MERGE INTO {table_name} AS target
        USING (VALUES
            {values_section}
        ) AS source ({source_columns})
        ON target.{compare_column} = source.{compare_column}
        WHEN MATCHED THEN
            UPDATE SET
                {update_set_clause}
        WHEN NOT MATCHED THEN
            INSERT ({insert_columns})
            VALUES ({insert_values});
        """
        logging.info(f"Generated Merge Query   construct_merge_query:, ")#{query}
        # Construct the final MERGE query
        # query = f"""
        # MERGE INTO {table_name} AS target
        # USING (VALUES
        #     {values_section}
        # ) AS source ({source_columns})
        # ON target.{compare_column} = source.{compare_column}  -- Unique column
        # WHEN MATCHED THEN
        #     UPDATE SET
        #         {update_set_clause}
        # WHEN NOT MATCHED THEN
        #     INSERT ({insert_columns})
        #     VALUES ({insert_values});
        # """
        return query,psql_values

    def update_psql_id_with_10_return_ids(self,postgres_conn,table20,mssql_ids,psql_values,id_column_20):
        logging.info("updating the postgress sql ids ")
        if len(mssql_ids) != len(psql_values):
            raise ValueError("The length of inserted_ids and id_values must be the same")
        case_statements = []
        logging.info("mssql inserted ids are",mssql_ids)
        logging.info("pssql ids are ",psql_values)
        for mssql_id, psql_value in zip(mssql_ids, psql_values):
            case_statements.append(f"WHEN {id_column_20} ='{psql_value}' THEN '{mssql_id}'")
        logging.info(f"case_statements are : {case_statements}")
        update_query = f"""
        UPDATE {table20}
        SET {id_column_20} = CASE
            {' '.join(case_statements)}
            ELSE {id_column_20}
            END
        WHERE {id_column_20} IN ({', '.join(f"'{val}'" for val in psql_values)});
        """
        #logging.info(postgres_conn)
        logging.info("Generated Update Query:\n", update_query)
        # Execute the query
        try:
           with postgres_conn.cursor() as cursor:
            cursor.execute(update_query)  # Execute the query
            postgres_conn.commit()  # Commit the transaction
            logging.info("Query executed and changes committed successfully.")
        except Exception as e:
            postgres_conn.rollback()  # Rollback in case of error
            logging.error("Error occurred during query execution:", str(e))
            raise ValueError(f"Error in updating ids in postgresql with 1.0 ids in reverse sync")
    def construct_merge_query_uuid(self, df, table_name, compare_column):
        """
        Constructs a SQL MERGE query for inserting or updating records in the target table.
        This function compares data from a pandas DataFrame with the target table using a specified
        comparison column and generates an appropriate SQL query.

        Args:
            df (pandas.DataFrame): The DataFrame containing the data to merge.
            table_name (str): The name of the target table.
            compare_column (str): The column to compare for matching records in the merge.

        Returns:
            str: The SQL MERGE query as a string.
        """
        compare_column=compare_column.lower()
        # if 'id' in df.columns:
        #     df = df.drop(columns=['id'])

        # Extract column names from the DataFrame to be used in the query
        columns = df.columns.tolist()

        # Prepare the column names for the query
        source_columns = ", ".join(columns)

        # Build the USING (VALUES...) section dynamically
        values_list = []
        for _, row in df.iterrows():
            values = []
            for col in columns:
                value = row[col]
                if pd.isnull(value):  # Handle NULL values
                    values.append("NULL")
                elif isinstance(value, str):  # Add quotes for string values
                    values.append(f"'{value}'")
                else:
                    values.append(str(value))  # For numeric or boolean values
            values_list.append(f"({', '.join(values)})")

        values_section = ",    ".join(values_list)
        update_set_clause = ",        ".join(
        [
        f"target.{col} = source.{col}"
        for col in columns
        if col.lower() != compare_column.lower()  # Exclude "id" and compare_column
        ]
        )
        '''if compare_column in df.columns:
            logging.info(f"{compare_column} in df columns ")
            psql_values = df[compare_column].tolist()
            df = df.drop(columns=[compare_column])
        else:
            psql_values=None'''
        psql_values=df[compare_column].to_list()
        columns2 = df.columns.tolist()
        # Build the INSERT part using all columns
        insert_columns = ", ".join(columns2)
        insert_values = ", ".join([f"source.{col}" for col in columns2])

        # Construct the full MERGE query
        query = f"""MERGE INTO {table_name} AS target
        USING (VALUES
            {values_section}
        ) AS source ({source_columns})
        ON target.{compare_column} = source.{compare_column}
        WHEN MATCHED THEN
            UPDATE SET
                {update_set_clause}
        WHEN NOT MATCHED THEN
            INSERT ({insert_columns})
            VALUES ({insert_values});
        """
        logging.info(f"Generated Merge Query   construct_merge_query:, {query}")
        return query,psql_values
    def segregate_records(self, df, compare_column, last_id=None):
        """
        Splits DataFrame into insert and update records based only on compare_column vs last_id.

        :param df: Input DataFrame
        :param compare_column: Column to compare (e.g. "id" or "username")
        :param last_id: Last synced ID (int or str, optional)
        :return: (df_insert, df_update)
        """
        df = df.copy()
        df.columns = [col.lower() for col in df.columns]
        compare_column = compare_column.lower()
        try:
            if compare_column not in df.columns:
                
                raise KeyError(f"Column '{compare_column}' not found in DataFrame. Available columns: {list(df.columns)}")

            if last_id is not None:
                # Create a boolean mask for updates (existing records)
                is_update_mask = df[compare_column] <= last_id
            else:
                # If no last_id, no updates, all are inserts
                is_update_mask = [False] * len(df)

            # Use the mask to split
            df_update = df[is_update_mask].copy()
            df_insert = df[~pd.Series(is_update_mask, index=df.index)].copy()

            logging.info(f"Records to Insert: {df_insert.shape[0]}")
            logging.info(f"Records to Update: {df_update.shape[0]}")

            return df_insert, df_update

        except KeyError as ke:
            logging.info(f"[ERROR] KeyError in segregate_records: {ke}")
            raise

        except TypeError as te:
            logging.info(f"[ERROR] TypeError in segregate_records: Likely due to type mismatch between column and last_id. Details: {te}")
            raise

        except Exception as e:
            logging.info(f"[ERROR] Unexpected error in segregate_records: {e}")
            raise
    def insert_with_identity(self, df, table_name, connection):
        """
        Inserts data into a SQL Server table in batches using IDENTITY_INSERT ON/OFF
        and parameterized queries to avoid SQL injection.

        Args:
            df (pandas.DataFrame): DataFrame containing data to insert.
            table_name (str): Fully qualified table name (e.g., 'dbo.DeviceStatus').
            connection: Active pyodbc connection to the SQL Server database.

        Returns:
            None
        """

        try:
            logging.info(f"[INFO] Starting insert_with_identity for table: {table_name}")
            logging.info(f"[INFO] Number of rows in DataFrame: {len(df)}")

            batch_size = 1000
            cursor = connection.cursor()
            columns = df.columns.tolist()

            if not columns:
                logging.info("[WARN] No columns found in DataFrame. Nothing to insert.")
                return

            column_list_str = ", ".join(f"[{col}]" for col in columns)
            placeholders = ", ".join(["%s"] * len(columns))  # pyodbc uses '?'
            logging.info(f"[INFO] Columns to insert: {column_list_str}")
            logging.info(f"[INFO] Placeholders string: {placeholders}")

            num_rows = len(df)
            if num_rows == 0:
                logging.info("[WARN] DataFrame is empty. No rows to insert.")
                return

            # Turn on IDENTITY_INSERT once before batches
            logging.info(f"[INFO] Enabling IDENTITY_INSERT on {table_name}")
            cursor.execute(f"SET IDENTITY_INSERT {table_name} ON;")

            for start in range(0, num_rows, batch_size):
                end = min(start + batch_size, num_rows)
                batch_df = df.iloc[start:end]
                logging.info(f"[INFO] Inserting batch rows {start} to {end-1} (total {end - start} rows)")

                # Convert batch rows to tuples, replace NaN with None
                values = [tuple(None if pd.isnull(val) else val for val in row) for row in batch_df.to_numpy()]

                insert_sql = f"INSERT INTO {table_name} ({column_list_str}) VALUES ({placeholders})"
                cursor.executemany(insert_sql, values)
                logging.info(f"[INFO] Batch inserted successfully.")

                connection.commit()
                logging.info(f"[INFO] Transaction committed for batch rows {start} to {end-1}")

            # Turn off IDENTITY_INSERT after all batches
            logging.info(f"[INFO] Disabling IDENTITY_INSERT on {table_name}")
            cursor.execute(f"SET IDENTITY_INSERT {table_name} OFF;")

            cursor.close()
            logging.info(f"[INFO] insert_with_identity completed successfully for {table_name}")

        except Exception as e:
            tb = traceback.format_exc()
            logging.info(f"[ERROR] Exception during insert_with_identity for table '{table_name}': {e}")
            logging.info(f"[ERROR] Traceback:\n{tb}")
            try:
                logging.info(f"[INFO] Attempting to disable IDENTITY_INSERT after exception on {table_name}")
                cursor.execute(f"SET IDENTITY_INSERT {table_name} OFF;")
                connection.commit()
                logging.info(f"[INFO] IDENTITY_INSERT disabled successfully after exception.")
            except Exception as inner_e:
                logging.info(f"[ERROR] Failed to disable IDENTITY_INSERT after exception: {inner_e}")

    def insert_into_ssms(
        self, ssms_conn, df, insert_table_name, migration_track_col, time_columns,table_20,postgres_conn,id_column_10,id_column_20,primary_id_col,uuid_flag=False,last_id=None
    ):
        """
        Inserts records into a SQL Server Management Studio (SSMS) database in batches.
        The method constructs and executes a merge query for inserting or updating records
        and handles errors by retrying failed batches and logging failures.

        Args:
            ssms_conn: The connection object to the SSMS database.
            df (pandas.DataFrame): The DataFrame containing the data to be inserted.
            insert_table_name (str): The name of the target table in the database.
            migration_track_col (str): The column used for tracking migration in the merge query.
            time_columns (list): The columns containing timestamp information for tracking the last record.

        Returns:
            bool: Returns True if the insertion was successful, False if there were failures.
        """
        try:

            inserted_records = 0
            failed_records = 0
            insert_flag = True
            batch_size = 50
            failed_log = []
            last_id_time = None
            num_batches = math.ceil(len(df) / batch_size)
            stop_insertion=False
            rev_error_id_list=[]
            error_msg=None
            '''logging.info(f"############# Records to insert: {df.shape[0]}")
            logging.info(f"########### No of Batches Created: {num_batches} with batch size {batch_size} {insert_table_name}")
            logging.info(f"time columns are {time_columns}")'''
            if not uuid_flag:
                df_to_insert,df_to_update=self.segregate_records(df,id_column_10,last_id[0])
            else:
                df_to_update=df
                df_to_insert = pd.DataFrame()
            logging.info(f"Seggreageted records are12345 {df_to_insert}")
            if df_to_insert is not None and not df_to_insert.empty and not uuid_flag:
                logging.info(f"Records insertion function is calling here")
                self.insert_with_identity(df_to_insert,insert_table_name,ssms_conn)
            num_batches = math.ceil(len(df_to_update) / batch_size)
            logging.info(f"############# Records to insert: {df_to_update.shape[0]}")
            logging.info(f"########### No of Batches Created: {num_batches} with batch size {batch_size} {insert_table_name}")
            logging.info(f"time columns are {time_columns}")

            def insert_block_operation():
                """
                Performs the insert operation in batches, constructs the merge queries,
                and handles errors such as failed records and retries.
                """
                nonlocal inserted_records, failed_records, last_id_time, insert_flag,stop_insertion,rev_error_id_list
                for batch_index in range(num_batches):
                    # Get the start and end indices for the current batch
                    start_index = batch_index * batch_size
                    end_index = min((batch_index + 1) * batch_size, len(df_to_update))
                    # Extract the current batch from the DataFrame
                    batch_df = df_to_update.iloc[start_index:end_index]

                    # logging.info(f"batch_df is {batch_df.head()}")

                    # Construct the merge query for the batch
                    if not uuid_flag:
                        insert_query_update,psql_values = self.construct_merge_query(
                            batch_df, insert_table_name,id_column_10
                        )
                    if uuid_flag:
                        logging.info(f"here we need to insert id also {uuid_flag}")
                    #logging.info(f"insert_query_update {insert_query_update}")
                        insert_query_update,psql_values = self.construct_merge_query_uuid(
                            batch_df, insert_table_name,id_column_10
                        )

                    #logging.info(f"insert_query_update {insert_query_update}")

                    if insert_query_update:
                        try:
                            # Execute the merge query and commit the transaction
                            cursor = ssms_conn.cursor()
                            # logging.info(cursor)

                            # logging.info(insert_query_update)

                            cursor.execute(insert_query_update)  # Execute the query
                            #mssql_ids = cursor.fetchall()

                            #mssql_ids=[(80,)]

                            #mssql_ids=list(mssql_ids[0])
                            # logging.info("these are before list",mssql_ids)
                            #mssql_ids=[item[0] for item in mssql_ids]
                            #results=[]
                            #for last_id_ssms in mssql_ids:
                                #result = self.convert_uuid_id(last_id_ssms)
                                #results.append(result)
                            #mssql_ids=results
                            # logging.info(mssql_ids)
                            #logging.info(f"the new id which is inserted in mssql {mssql_ids}")
                            #logging.info(f"the postgress sql ids are {psql_values}")
                            # logging.info(mssql_ids)
                            # logging.info(table_20)
                            #logging.info(postgres_conn)

                            ssms_conn.commit()  # Commit the transaction
                            logging.info(f"Records are inserted into mssql database successfully {batch_index} {insert_table_name}")

                            #self.update_psql_id_with_10_return_ids(postgres_conn,table_20,mssql_ids,psql_values,id_column_20)
                            inserted_records += len(
                                batch_df
                            )  # Update the count of inserted records
                            last_row = batch_df.iloc[
                                -1
                            ]  # Get the last row in the batch

                            last_id_time = [
                                last_row[col]
                                for col in time_columns
                                if col in batch_df.columns
                            ]  # Capture time column values
                            # return None
                        except Exception as e:
                            # If the batch insertion fails, rollback and log the failure
                            ssms_conn.rollback()
                            logging.error(
                                f"########### Failed to execute query for batch {batch_index}: {e}"
                            )
                            failed_records += len(
                                batch_df
                            )  # Increment the count of failed records
                            failed_log.append(
                                {
                                    "batch_index": batch_index,
                                    "query": insert_query_update,
                                }
                            )
                            # Retry the insertion by executing individual queries for each row
                            try:
                                logging.info(
                                    f"############### Retrying with individual queries:"
                                )
                                for idx, row in batch_df.iterrows():
                                    # Construct the insert query for the individual row
                                    individual_insert_query = (
                                        self.construct_merge_query(
                                            pd.DataFrame([row]),
                                            insert_table_name,
                                            migration_track_col,
                                        )
                                    )
                                    cursor.execute(
                                        insert_query_update
                                    )  # Execute the query
                                    ssms_conn.commit()  # Commit the transaction
                                    inserted_records += 1
                                    last_id_time = [
                                        row[col]
                                        for col in time_columns
                                        if col in batch_df.columns
                                    ]
                                    # logging.info(individual_insert_query)
                            except Exception as e:
                                # If individual queries fail, rollback and log the error
                                ssms_conn.rollback()
                                error_id=row['id']
                                rev_error_id_list.append(error_id)
                                logging.info(f"rev_error_id_list {rev_error_id_list}")
                                error_msg=f'error in insert_ssms rev_sync {e}'
                                logging.error(
                                    f"Failed to execute query for batch {batch_index}: {e}"
                                )
                                failed_records += len(
                                    batch_df
                                )  # Increment the count of failed records
                                failed_log.append(
                                    {
                                        "batch_index": batch_index,
                                        "query": insert_query_update,
                                    }
                                )
                                insert_flag = False

                    else:
                        # If no insert query was generated, flag as failed
                        insert_flag = False
                        raise ValueError(f"Couldn't get insert query for the records")

            # Retry mechanism for handling failed insert block operations
            # for attempt in range(3):
            try:
                insert_block_operation()
                # break  # Break the retry loop if successful
            except Exception as e:
                # logging.error(
                #     f"Error in whole insert block operation on attempt {attempt + 1}: {e}"
                # )
                last_id_time = None
                insert_flag = False
                # with open('error_log.txt', 'a') as f:
                # f.write(f"Error in whole insert block operation on attempt {attempt + 1}: {str(e)}\n")
                logging.error(
                    f"Error in whole insert block operation on attempt {str(e)}\n"
                )

        except Exception as e:
            # Handle unexpected errors and log them
            insert_flag = False
            tb = traceback.format_exc()
            error_msg=f"Exception in inserting records into 1.0 for Reverse Sync: {e} {tb}"
            logging.error(
                f"Exception in inserting records into 1.0 for Reverse Sync: {e}"
            )
            return False,error_msg,rev_error_id_list
        return insert_flag,error_msg,rev_error_id_list

    def convert_uuid_id(self,id):
        if isinstance(id, uuid.UUID):
            return str(id)
        uuid_pattern = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')
        if isinstance(id, str) and uuid_pattern.match(id):
            return str(id)  # Convert and return the UUID as a string
        return id

    def reverse_sync_migration(
        self, job_name, postgres_conn, reverse_sync_mappings, migration_details_dict,trace_id,postgres_hist_conn
    ):

        """
        Handles the reverse synchronization migration for data transfer between the source and target databases.
        It retrieves data from the source database using the provided reverse sync mappings and inserts it into
        the target database.

        Args:
            job_name (str): The name of the migration job.
            postgres_conn (connection): The connection to the PostgreSQL target database.
            reverse_sync_mappings (list): A list of mappings that define how to sync data between databases.
            migration_details_dict (dict): Dictionary containing the migration job details.

        Returns:
            None
        """
        try:
            logging.info(f"{trace_id} Starting Reverse sync")
            rev_error_id_list=[]
            error_msg=None
            # Get the database configuration for the source database
            db_config = self.get_db_config(migration_details_dict)
            from_host = db_config["hostname"]
            from_port = db_config["port"]
            from_user = db_config["user"]
            from_pwd = db_config["password"]
            from_db_type = db_config["from_db_type"]
            from_database = migration_details_dict["from_database"]
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            history_table=os.getenv("MIGRATIONS_HISTORY_TABLE")

            logging.info("Create a connection to the source database using the retrieved configuration")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            id_column_20 = migration_details_dict.get('primary_id_column')
            id_column_10 = migration_details_dict.get('time_column_check')
            logging.info(f"20 id column is {id_column_20}")
            logging.info(f"10 id got  column is {id_column_10}")

            # Iterate through each mapping item in reverse_sync_mappings
            # logging.info(f"From connection is {from_connection}")
            for dict_item in reverse_sync_mappings:
                from_20_query = dict_item["query"]
                table_10 = dict_item["table"]
                migration_track_col = dict_item["ref"]
                table_20=dict_item["table20"]
                logging.info("1.0 table is ",table_10,"2.0 table is ",table_20)

                # Check if the table name is valid and construct the full table name
                if not self.is_valid_table_name(table_10):
                    full_from_table = f"[{from_database}].[dbo].[{table_10}]"
                    logging.info(f"full table name {full_from_table}")
                else:
                    full_from_table = table_10

                # Get the last ID from the source database
                logging.info(f"table 10 is {full_from_table}")
                last_id_ssms = self.get_ssms_last_id(from_connection, full_from_table,id_column_10)
                logging.info(f"last id from 1.0 is   convertbeforeint into uuid {last_id_ssms} {full_from_table} {id_column_20}")
                last_id_ssms=self.convert_uuid_id(last_id_ssms)
                logging.info(f"last id from 1.0 is after convertint into uuid {last_id_ssms} {full_from_table} {id_column_20}")
                uuid_flag=False
                # Clean up and format the query for retrieving updated records
                from_query_20 = " ".join(from_20_query.split())
                from_query_20 = from_query_20.rstrip(";")

                ###need to get error ids from previous job
                error_ids_query=f"select rev_sync_error_id,job_end_time from {history_table} where job_name='{job_name}' and trace_id<>'{trace_id}' order by job_end_time desc limit 1"
                error_ids_df=self.execute_query(postgres_hist_conn,error_ids_query)
                # logging.info(f"DF is {error_ids_df}")
                if not error_ids_df.empty:
                    error_id_list=error_ids_df['rev_sync_error_id'][0]
                    last_migrated_time_prev=error_ids_df['job_end_time'][0]
                else:
                # Handle the empty DataFrame case (e.g., return or log an error)
                    logging.info(f"{trace_id} DataFrame 'error_ids_df' is empty.")
                    error_id_list=[]
                    last_migrated_time_prev=[]
                logging.info(f"Error id list {error_id_list}, type is {type(error_id_list)}")

                last_migrated_time_query=f"select job_end_time from {history_table} where job_name='{job_name}' and trace_id<>'{trace_id}' and job_status_msg='SUCCESS' order by id desc limit 1"
                last_migrated_df=self.execute_query(postgres_hist_conn,last_migrated_time_query)
                if not last_migrated_df.empty:
                    last_migrated_time_job=last_migrated_df['job_end_time'][0]
                else:
                    last_migrated_time_job=None
                    logging.info(f"{trace_id} DataFrame 'job start time' is empty.")
                logging.info(f"Last migrated time is {last_migrated_time_job}")

                if last_migrated_time_job:
                    last_migrated_time=last_migrated_time_job
                else:
                    last_migrated_time = migration_details_dict["last_migrated_time"]


                # Check if the query involves 'modified_date', which means using a timestamp-based condition
                if "modified_date" in from_query_20.lower() and isinstance(last_id_ssms, int)  and id_column_20.lower() in from_20_query.lower():
                    logging.info(f"entered integer id part{last_id_ssms}")
                    # last_migrated_time = migration_details_dict["last_migrated_time"]
                    logging.info(f"last_migrated time is {last_migrated_time} and type {type(last_migrated_time)}")
                    time_cols = [id_column_20, "modified_date"]
                    time_cols_ssms = [id_column_20, "modifieddate"]
                    primary_id_col = [id_column_20]
                    last_id = [last_id_ssms, f"{last_migrated_time}"]
                    logging.info(f"after modifying time col and last_migrated time{last_id_ssms}, {time_cols},{last_id}" )

                elif "modified_date" in from_20_query.lower() and "created_date" in from_20_query.lower() and isinstance(last_id_ssms, str):
                    logging.info("this part for the uuid columns")
                    time_cols=["modified_date","created_date"]
                    time_cols_ssms=["id"]
                    primary_id_col = None
                    #  last_migrated_time=migration_details_dict["last_migrated_time"]
                    last_id=[f"{last_migrated_time}",f"{last_migrated_time}"]
                    uuid_flag=True

                else:
                    # Default to using only the ID column for the condition
                    time_cols = [id_column_20]
                    time_cols_ssms = [id_column_20]
                    last_id = [last_id_ssms]
                    primary_id_col = [id_column_20]


                logging.info(f"before passing time_cols and last_id to get_updated_records_query these are the values {time_cols},{last_id}")

                # Get the SQL query to fetch updated records from the source database
                pgsql_from_query = self.get_updated_records_query(
                    time_cols, last_id, None, from_query_20,error_id_list
                )
                logging.info(f"after updating query to get get_updated_records_query {pgsql_from_query},{time_cols},{last_id}")
                logging.info(f"sleeping 50s before executing execute query")
                time.sleep(50)    
                df_from_20 = self.execute_query(postgres_conn, pgsql_from_query)
                if df_from_20 is None or df_from_20.shape[0] == 0:
                    logging.info("execute_query returned None.")
                    logging.info(f"{trace_id} execute_query returned None.")
                    return True,'SUCCESS',rev_error_id_list

                #log if the df is empty or df is None
                if df_from_20.empty or df_from_20 is None or df_from_20.shape[0] == 0:
                    logging.info("DataFrame is empty; there are no updated records.")
                    logging.info(f"{trace_id} DataFrame is empty; there are no updated records.")
                    return True,'SUCCESS',rev_error_id_list

                else:
                    logging.info(f"df_from_20 is {df_from_20}")

                # Convert datetime columns to SQL-compatible format
                for col in df_from_20.columns:
                    if pd.api.types.is_datetime64_any_dtype(df_from_20[col]):
                        df_from_20[col] = df_from_20[col].apply(
                            self.convert_timestamp_to_sql_datetime
                        )

                # Replace NaN values with None and convert boolean values to integers (1/0)
                df_from_20 = df_from_20.astype(object).mask(df_from_20.isna(), None)
                #df_from_20.replace({True: 1, False: 0}, inplace=True)
                df_from_20 = df_from_20.applymap(lambda x: 1 if x is True else (0 if x is False else x))
                logging.info(f"############# Result DF:::::{df_from_20}")
                df_from_20=self.modify_uuid_cols(df_from_20)

                # Insert the data into the target database (SSMS)

                insert_flag,error_msg,rev_error_id_list=self.insert_into_ssms(
                    from_connection,
                    df_from_20,
                    full_from_table,
                    migration_track_col,
                    time_cols_ssms,
                    table_20,postgres_conn,
                    id_column_10,
                    id_column_20,primary_id_col,
                    uuid_flag,
                    last_id
                )
            logging.info(f"Error id list {rev_error_id_list}")
            update_hist_table={'rev_sync_error_id':json.dumps(rev_error_id_list),'error_msg':error_msg}
            self.update_table(postgres_hist_conn,history_table,update_hist_table,{'trace_id':trace_id})
            return True,'SUCCESS',rev_error_id_list
        except Exception as e:
            tb = traceback.format_exc()
            logging.error(f"Error in reverse sync migration: {e}")
            error_message=f"Error in reverse sync migration: {e} {tb}"
            self.update_table(postgres_hist_conn,history_table,{'error_msg':error_message},{'trace_id':trace_id})
            return False,error_message,rev_error_id_list



    def delete_message_from_sqs(self, receipt_handle):
        try:
            queue_url=os.getenv("OPTIMIZATION_QUEUE_URL")
            sqs.delete_message(
                # QueueUrl="https://sqs.us-east-1.amazonaws.com/008971638399/optimisation_sync_uat.fifo",
                QueueUrl=queue_url,
                ReceiptHandle=receipt_handle,
            )
            logging.info("Message deleted from SQS successfully.")
        except Exception as e:
            logging.error(f"Error deleting message from SQS: {e}")
            raise

    def send_msg_to_opt_sync_queue(self, message_body):
        try:
            logging.info("-----------", message_body)
            # Initialize the SQS client
            logging.info("calling SQS QUEUEEEEEEEEEEEEEE")
            sqs_client = boto3.client("sqs", region_name="us-east-1")
            message_body["sqs_flag"] = True
            queue_url=os.getenv("OPTIMIZATION_QUEUE_URL")
            # queue_url = "https://sqs.us-east-1.amazonaws.com/008971638399/optimisation_sync_uat.fifo"
            # Send the message to the SQS queue
            message_group_id = str(uuid.uuid4())
            response = sqs_client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(message_body),
                MessageGroupId=message_group_id,
                MessageDeduplicationId=str(uuid.uuid4()),
            )

            logging.info(
                f"Message sent to SQS queue {queue_url}. Message ID: {response['MessageId']}"
            )
            return response["MessageId"]
        except Exception as e:
            logging.error(f"Error sending message to SQS queue: {e}")
            raise

    def function_to_check_sub_tenant_or_parent_name(self, postgres_conn, tenant_name):
        try:
            # SQL query to check tenant information
            query = """
                SELECT id,tenant_name, parent_tenant_id, db_name
                FROM public.tenant
                WHERE tenant_name = %s
                ORDER BY id DESC
                LIMIT 1;
            """

            # Execute the query with the tenant_id
            cursor = postgres_conn.cursor()
            cursor.execute(query, (tenant_name,))
            result = cursor.fetchone()

            # Check if the result exists
            if result:
                tenant_id, tenant_name, parent_tenant_id, db_name = result

                # Determine the flags based on parent_tenant_id
                if parent_tenant_id is not None:
                    parent_query = """
                    SELECT tenant_name
                    FROM public.tenant
                    WHERE id = %s
                    LIMIT 1;
                    """
                    cursor.execute(parent_query, (parent_tenant_id,))
                    parent_result = cursor.fetchone()

                    if parent_result:
                        tenant_name = parent_result[0]  # Overwrite with parent tenant name

                parent_tenant_flag = True if parent_tenant_id is None else False
                sub_tenant_flag = not parent_tenant_flag
                return tenant_name

            else:
                # If no result is found, raise an exception
                raise ValueError(f"No tenant found with tenant_id {tenant_name}")
        except Exception as e:
        # Handle any errors that may occur
            logging.info(f"Error occurred: {e}")
            return None, None, None  # Return None if there's an error

    def construct_condition_query(self,base_query, condition_column, value):
        """
        Replace placeholder in condition and append it to the base query.

        Args:
            base_query (str): The main SELECT query.
            condition_column (str): The condition string with placeholders like {device_id}.
            value (any): The value to insert into the condition (e.g., 1234).

        Returns:
            str: Fully constructed SQL query.
        """
        try:
            # Remove trailing semicolon if present
            base_query = base_query.strip().rstrip(';')
            # Create WHERE clause
            # Handle list or tuple as IN condition
            if isinstance(value, (list, tuple)):
            # Format values for SQL (assumes values are ints or properly sanitized strings)
                formatted_values = ', '.join([f"'{v}'" if isinstance(v, str) else str(v) for v in value])
                where_clause = f"WHERE {condition_column} IN ({formatted_values})"
            else:
                formatted_value = f"'{value}'" if isinstance(value, str) else value
                where_clause = f"WHERE {condition_column} = {formatted_value}"
            # Check if ORDER BY already exists
            if "ORDER BY" in base_query.upper():
                # Inject WHERE before ORDER BY
                parts = base_query.rsplit("ORDER BY", 1)
                full_query = f"{parts[0]} {where_clause} ORDER BY{parts[1]}"
            else:
                full_query = f"{base_query} {where_clause}"
            return full_query

        except KeyError as e:
            raise ValueError(f"Missing placeholder in condition: {e}")

    def inventory_live_sync(self, key_name, device_id=None):
        """
        Perform reverse data sync from PostgreSQL to MSSQL for specified  job.

        This function retrieves a list of migration job names from the `lambda_sync_jobs` table
        based on the given `key_name`. For each job, it fetches the associated reverse sync
        configuration, constructs condition-based queries, pulls data from PostgreSQL (2.0),
        and then updates the corresponding records in MSSQL (1.0) using a dynamically built
        MERGE (upsert) query.

        Args:
            key_name (str): The key identifier to fetch the list of migration job names from `lambda_sync_jobs`.
            device_id (int or list, optional): Device ID(s) to use for conditional filtering in the query.
            mobility_device_id (int or list, optional): Mobility device ID(s), reserved for future use or extended filters.

        Returns:
            bool: Returns True after successfully syncing or if no data is available to sync.

        Raises:
            Exception: Any unexpected error during query execution, database connection, or data transformation is caught and logged.
        """
        try:
            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            migration_table = "lambda_sync_jobs"
            job_scheduled_query = f"select migration_names_list from {migration_table} where key_name='{key_name}'"
            rows = self.execute_query(postgres_conn, job_scheduled_query)
            logging.info(f"{key_name}------Data from key name is {rows},{type(rows)}")
            job_names_list = rows["migration_names_list"][0]

            for job_name in job_names_list:
                migration_table = os.getenv('MIGRATION_TABLE')
                logging.info(f"migrations table {migration_table}")
                migration_details_dict = self.get_migration_details(job_name, postgres_conn, migration_table)
                logging.info(f"migrations details dict {migration_details_dict}")
                if not migration_details_dict:
                    logging.info(f"No migration config found for job: {job_name}")
                    continue
                to_db_config = self.get_to_db_config(migration_details_dict)


                reverse_sync_mappings = migration_details_dict["reverse_sync_mapping"]
                for dict_item in reverse_sync_mappings:
                    logging.info(f"dict_item gotten is {dict_item}")
                    from_20_query = dict_item["query"]
                    table_10 = dict_item["table"]
                    migration_track_col = dict_item["ref"]
                    table_20 = dict_item["table20"]
                    condition = dict_item.get("condition")
                    if not condition:
                        self.main_migration_func(job_name)
                        continue

                    #insert trace id
                    history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
                    hist_insert_data={'key_name':key_name,'job_name':job_name,'job_start_time':datetime.now(timezone.utc),
                              'request_triggered_by':'optimization_sync_lambda','inv_id':device_id}

                    trace_id=self.insert_dict(postgres_conn,history_table,hist_insert_data,True,'trace_id')
                    logging.info(f"Trace Id after insertion is {trace_id}")


                    logging.info(f"1.0 table is {table_10}, 2.0 table is {table_20}, condition is {condition}")

                    full_query = self.construct_condition_query(from_20_query, condition, device_id)
                    logging.info(f"Final constructed query: {full_query}")

                    to_db_name = migration_details_dict['to_database']
                    if to_db_config is None:
                        logging.info(f"To db configurations not found")
                        msg=f"Error in main-last migration {job_name} to_db_config is empty"
                        update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc)}
                        self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                        logging.info(f"Error in main_migration_fun:last_id_migration {job_name}")
                        return True
                    to_hostname = to_db_config['hostname']
                    to_port = to_db_config['port']
                    to_db_name = migration_details_dict['to_database']
                    to_user = to_db_config['user']
                    to_password = to_db_config['password']
                    to_db_type = to_db_config['to_db_type']
                    
                    to_table = migration_details_dict['to_table']
                    
                    to_connection=self.create_connection(to_db_type,to_hostname,to_db_name,to_user,to_password,to_port)

                    logging.info(f"to databse is {to_db_name}")
                    #to_connection = self.create_connection(db_type, hostname, to_db_name, user, password, port)

                    df_from_20 = self.execute_query(to_connection, full_query)

                    if df_from_20 is None or df_from_20.shape[0] == 0 or df_from_20.empty:
                        logging.info("execute_query returned None.")
                        logging.info(f"{trace_id} execute_query returned None.")
                        return True

                    for col in df_from_20.columns:
                        if pd.api.types.is_datetime64_any_dtype(df_from_20[col]):
                            df_from_20[col] = df_from_20[col].apply(
                                self.convert_timestamp_to_sql_datetime
                            )

                    # Replace NaN values with None and convert boolean values to integers (1/0)
                    df_from_20 = df_from_20.astype(object).mask(df_from_20.isna(), None)
                    #df_from_20.replace({True: 1, False: 0}, inplace=True)
                    df_from_20 = df_from_20.applymap(lambda x: 1 if x is True else (0 if x is False else x))
                    logging.info(f"############# Result DF:::::{df_from_20}")
                    df_from_20=self.modify_uuid_cols(df_from_20)
                    id_column_20 = migration_details_dict.get('primary_id_column')
                    id_column_10 = migration_details_dict.get('time_column_check')
                    db_config = self.get_db_config(migration_details_dict)
                    from_host = db_config["hostname"]
                    from_port = db_config["port"]
                    from_user = db_config["user"]
                    from_pwd = db_config["password"]
                    from_db_type = db_config["from_db_type"]
                    from_database = migration_details_dict["from_database"]
                    from_driver = os.getenv("MSSQL_DB_DRIVER")

                    logging.info("Create a connection to the source database using the retrieved configuration")
                    ssms_conn = self.create_connection(
                        from_db_type,
                        from_host,
                        from_database,
                        from_user,
                        from_pwd,
                        from_port,
                        from_driver,
                    )

                    if df_from_20 is None:
                        logging.info("execute_query returned None.")
                        return True

                    logging.info(f"data fetched successfully {df_from_20.head()}")

                    insert_query_update,psql_values = self.construct_merge_query(
                        df_from_20, table_10, id_column_10
                    )
                    logging.info(f"query constructed is {insert_query_update}")

                    if insert_query_update:
                        try:
                            cursor = ssms_conn.cursor()
                            cursor.execute(insert_query_update)  # Execute the query
                            ssms_conn.commit()  # Commit the transaction
                            logging.info("Records are inserted into MSSQL database successfully")

                        except Exception as e:
                            ssms_conn.rollback()
                            tb = traceback.format_exc()
                            msg=f"Error in {job_name} {e} {tb}"
                            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
                            self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
                            logging.error(f"An error occurred in inventory sync: {e}")
                    else:
                        logging.info("Insert query is not formed")


        except Exception as e:
            tb = traceback.format_exc()
            msg=f"Error in {job_name} {e} {tb}"
            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})
            logging.error(f"An error occurred in inventory sync: {e}")
            logging.info(f"An error occurred in inventory sync: {e}")

    def post_with_retries_old(self,url, json, retries=1):
        '''
        main container caller function
        Args:
            url (str): The URL to send the POST request to.
            json (dict): The JSON data to include in the POST request.
            retries (int): Number of retry attempts in case of failure.
        '''
        delay = 1
        for attempt in range(1, retries + 1):
            try:
                resp = requests.post(url, json=json, timeout=60)
                if resp.status_code < 400:
                    return resp.json()
            except requests.RequestException:
                pass  # ignore and retry

            logging.warning("Attempt %d failed; retrying in %ds", attempt, delay)
            time.sleep(delay + random.uniform(0, 0.5))
            delay *= 2
        logging.error("All %d attempts failed", retries)
        return None  # After all retries fail

    def post_with_retries(self, url, json, retries=3, initial_delay=30):
        '''
        Sends a POST request with exponential backoff retries.
        
        Args:
            url (str): The URL to send the POST request to.
            json (dict): The JSON data to include in the POST request.
            retries (int): Number of retry attempts after the initial failure (default: 3).
            initial_delay (int): Base delay in seconds for the first retry (default: 30).
        
        Returns:
            tuple: (bool, dict|str|None)
                - First element: True if successful (status < 400), False otherwise
                - Second element:
                    - On success: the parsed JSON response
                    - On failure: a string describing the error reason
        '''
        delay = initial_delay
        max_attempts = retries + 1  # Includes the initial attempt
        last_error = None

        for attempt in range(1, max_attempts + 1):
            try:
                resp = requests.post(url, json=json, timeout=60)
                
                if resp.status_code < 400:
                    logging.info(f"Success on attempt {attempt}/{max_attempts}: POST to {url}")
                    return True
                
                # HTTP error status
                error_msg = f"HTTP {resp.status_code}: {resp.reason}"
                if resp.text:
                    try:
                        error_details = resp.json()
                    except ValueError:
                        error_details = resp.text[:500]  # Truncate long bodies
                    error_msg += f" | Body: {error_details}"
                
                logging.warning(
                    f"Attempt {attempt}/{max_attempts} failed with {resp.status_code}; "
                    f"{'retrying in ~{int(delay)}s' if attempt < max_attempts else 'no more retries'}"
                )
                last_error = f"HTTP {resp.status_code} after {max_attempts} attempts"

            except requests.RequestException as e:
                logging.warning(
                    f"Attempt {attempt}/{max_attempts} failed with exception: {e}; "
                    f"{'retrying in ~{int(delay)}s' if attempt < max_attempts else 'no more retries'}"
                )
                last_error = f"Request exception: {type(e).__name__} - {e}"

            # If not the last attempt, wait and retry
            if attempt < max_attempts:
                jitter = random.uniform(0, 0.5 * delay)
                sleep_time = delay + jitter
                logging.info(f"Sleeping {sleep_time:.1f}s before retry {attempt + 1}/{max_attempts}")
                time.sleep(sleep_time)
                delay *= 2

        # All attempts failed
        logging.error(f"All {max_attempts} attempts failed for POST to {url}. Last error: {last_error}")
        return False

    def lambda_sync_jobs_(self, data, comm_group_flag=False):
        # completed_dict={}
        try:
            key_name=data.get("key_name")
            if key_name == "communication_plan_sync":
                logging.info(f"[info] key name obtained communication_plan_sync and sleeping it for 75 seconds {key_name}")
                time.sleep(75)
            logging.info(f"######### In lambda sync job data: {data}")
            container_flag=data.get("container_flag",False)
            logging.info(f"container flag here is {container_flag}")
            # if container_flag:
            #     logging.info(f"Need to call container here for {data}")
            #     url = f"http://54.152.69.196:5001/migration_beta"
            #     logging.info(f"Calling container with data: {data}")
            #     try:
            #         result=self.post_with_retries(url, data, retries=1)
            #         response={"flag": True, "message": "Request forwarded to EC2 successfully"}
            #     except Exception as e:
            #         logging.info(f"Error in calling container {e}")
            #         response={"flag": False, "message": "Error in forwarding request to EC2"}
            #     return response
            start_time = time.time()
            opt_session_uuid = None
            
            opt_run_time=data.get("opt_run_time")
            logging.info(f"optimization rune time gotten is {opt_run_time}")
                        
            
            if data.get("key_name") == "optimization_sync":
                    logging.info(f"Optimization sync started at: {datetime.now()}")
                    sync_start_time = time.time()
            else:
                    sync_start_time = None     
                                
            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            # hostname = os.get"amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"  # "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
            # port = "5432"
            # db_name = "Migration_Test"
            # user = "root"
            # password = "AmopTeam123"
            # db_type = "postgresql"
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            common_utils_db=os.getenv("COMMON_UTILS_DB_NAME")
            comm_postgres_con= self.create_connection(
                db_type, hostname,common_utils_db, user, password, port
            )
            if comm_group_flag:
                data = data.get("data", None)
            bulk_change_id=data.get("bulk_change_id",None)
            key_name_received = data.get("key_name", None)
            tenant_name = data.get('tenant_name',None)
            logging.info(f"tenant_name received {tenant_name}")
            if tenant_name:
                tenant_name=self.function_to_check_sub_tenant_or_parent_name(comm_postgres_con,tenant_name)
            logging.info(f"tenant_name finally gotten after checking subtenant {tenant_name}")
            tenant_id = data.get('tenant_id', None)
            if tenant_name == "":
                tenant_name = None
            if tenant_name is None and tenant_id is not None:
                try:
                    common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                    postgres_conn_common = self.create_connection(
                        db_type, hostname, common_db_name, user, password, port
                    )
                    tenant_name_query = f"select tenant_name from tenant where id={tenant_id}"
                    tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                    tenant_name = tenant_name_df['tenant_name'].iloc[0]
                except Exception as e:
                    logging.error(f"Error in getting tenant name from tenant_id: {e}")
                    tenant_id = None
                    pass
            mode = os.getenv("MODE")
            if tenant_id == 1 and mode=="UAT":
                tenant_name = "Altaworx Test"

            if tenant_name is None and tenant_id is None:
                logging.error(f"{key_name_received}: Tenant name and tenant id is None")
                return {'flag':False,'message':'Tenant Name and Tenant Id is None'}

            if tenant_name == "Altaworx Test":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx_central_beta"
            elif tenant_name == "Altaworx":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx_central_beta"
            else:
                try:
                    common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                    postgres_conn_common = self.create_connection(
                        db_type, hostname, common_db_name, user, password, port
                    )
                    tenant_name_query = f"select db_name from tenant where tenant_name='{tenant_name}'"
                    tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                    db_name = tenant_name_df['db_name'].iloc[0].lower()
                except Exception as e:
                    logging.error(f"Error in getting tenant name from tenant_id: {e}")
                    db_name = tenant_name
                    pass
                tenant_name_lcase = db_name
                tenant_name_ = tenant_name
            logging.info(f"tenant name lowercase is {tenant_name_lcase}")
            container_name=tenant_name_lcase
            if container_name in ('altaworx','altaworx_central_beta'):
                container_name='altaworx_central'
            elif container_name in ('altaworx_go_tech_beta'):
                container_name='altaworx_go_tech'
            elif container_name in ('spectrotel_beta'):
                container_name='spectrotel'
            # port=port_mapping.get(tenant_name_lcase,5000)
            port=port_mapping.get(container_name,5001)
            logging.info(f"port mapped is {port} for tenant {container_name}")
            url=f"http://54.152.69.196:{port}/migration_{container_name}"
            logging.info(f"url formed is {url}")
            if container_flag:
                logging.info(f"Need to call container here for {data}")
                logging.info(f"Calling container with data:{url} {data}")
                try:
                    self.post_with_retries(url, data, retries=3)
                    response={"flag": True, "message": "Request forwarded to EC2 successfully"}
                except Exception as e:
                    logging.info(f"Error in calling container {e}")
                    response={"flag": False, "message": "Error in forwarding request to EC2"}
                return response

            if key_name_received and tenant_name:
                key_name = f"{key_name_received}_{tenant_name_lcase.lower()}"
            else:
                key_name = key_name_received
            if key_name_received=="users_sync":
                self.users_table_sync(data)
                return True
            logging.info(f"Received Key name {key_name_received} and tenant name {tenant_name_lcase.lower()}, Final key formed is {key_name}")

            #Before starting the job insert a record in history table
            history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            hist_insert_data={'key_name':key_name_received,'job_name':'live-sync','job_start_time':datetime.now(timezone.utc).replace(tzinfo=None),
                              'request_triggered_by':'optimization_sync_lambda'}

            trace_id=self.insert_dict(postgres_conn,history_table,hist_insert_data,True,'trace_id')
            logging.info(f"Trace Id after insertion is {trace_id}")

            aws_scheduler=data.get('schedule_flag',None)
            logging.info(f"Schedule flag is {aws_scheduler}")
            from_20_flag=False

            service_provider_id=data.get('service_provider_id', None)
            device_id=data.get('device_id',None)
            mobility_device_id=data.get('mobility_device_id',None)
            json_data = self.load_json()
            telegence_ids = self.get_provider_ids(json_data, tenant_name_, ["Telegence"])
            logging.info(f"### save_data_to_10 telegence_ids is {telegence_ids}")

            if key_name_received == 'm2m_inventory_live_sync_from_20' and (device_id is not None or mobility_device_id is not None) :
                from_20_flag=True
                if service_provider_id and  int(service_provider_id) in telegence_ids:
                    key_name = f"mobility_inventory_live_sync_from_20_{tenant_name_lcase.lower()}"
                else:
                    key_name = f"m2m_inventory_live_sync_from_20_{tenant_name_lcase.lower()}"

            if key_name_received=='m2m_inventory_live_sync_from_20' and from_20_flag is True:
                logging.info(f"inventory sync ")
                logging.info(f"key name formed is {key_name}")
                if device_id:
                    id_to_send=device_id
                else:
                    id_to_send=mobility_device_id
                try:
                    self.inventory_live_sync(key_name,id_to_send)
                except Exception as e:
                    logging.info(f"Error in lambda_sync_jobs - inventory live sync {e}")
                    if trace_id:
                        error_msg=f"Error in lambda_sync_jobs - inventory live sync {e}"
                        job_status_msg='Failed'
                        update_hist_table={'error_id_list':None,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_msg,'success':0,'failed':0,'job_status_msg':job_status_msg}
                        self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})
                if trace_id:
                    error_msg=None
                    job_status_msg='Success'
                    update_hist_table={'error_id_list':None,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_msg,'success':0,'failed':0,'job_status_msg':job_status_msg}
                    self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})
                return True

            if key_name_received == "optimization_setting_sync":
                logging.info(f"Optimization Setting Begining {key_name}")
                try:
                    self.optimization_setting_handler(f"optimization_setting_{tenant_name_lcase.lower()}",tenant_id,trace_id=trace_id)
                except Exception as e:
                    logging.info(f"Error in lambda_sync_jobs - optimization_setting_handler {e}")
                    if trace_id:
                        error_msg=f"Error in lambda_sync_jobs - optimization_setting_handler {e}"
                        job_status_msg='Failed'
                        update_hist_table={'error_id_list':None,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_msg,'success':0,'failed':0,'job_status_msg':job_status_msg}
                        self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})
                return True

            if key_name_received == "optimization_sync":
                opt_session_uuid = data.get("session_id")
            else:
                opt_session_uuid = None
            if key_name_received == "rev_service_line_sync":
                service_number = data.get("service_number")
            else:
                # opt_session_uuid=None
                service_number = None

            logging.info(f"Begining Migration for {key_name}--{opt_session_uuid}")
            migration_table = "lambda_sync_jobs"
            job_scheduled_query = f"select migration_names_list from {migration_table} where key_name='{key_name}'"
            rows = self.execute_query(postgres_conn, job_scheduled_query)
            logging.info(f"{key_name}------Data from key name is {rows},{type(rows)}")
            if rows is None or rows.empty:
                logging.error(
                    f"Migration config missing: table={migration_table}, key_name={key_name}"
                )
                raise Exception(
                    f"Migration configuration not found for key_name='{key_name}'"
                )

            job_names_list = rows["migration_names_list"][0]
            logging.info(
                f"{key_name}--------Job names are {job_names_list},{type(job_names_list)}"
            )
            jobs_status_dict = {"Success": [], "failed": []}
            logging.info(
                f"{key_name}---------Job names are {job_names_list},{type(job_names_list)}"
            )

            try:
                for job in job_names_list:
                    if aws_scheduler is True:
                        try:
                            job_name_dict = {}
                            job_name_dict["job_name"] = job
                            time_elapsed = time.time() - start_time
                            logging.info(
                                f"Time elapsed since start: {time_elapsed:.2f} seconds before starting job: {job}"
                            )
                            logging.info(
                                f"Sending ip is {opt_session_uuid}- {job_name_dict}"
                            )
                            logging.info(f"Job started in lambda_sync_jobs: {job}")
                            job_start_time = time.time()
                            # Create the message body
                            data = {'key_name':key_name,'job_name': job, 'path': "/main_migration_func"}
                            logging.info(f"Sending job to SQS queue: {job}")
                            # Send message to SQS
                            migration_job=self.send_msg_to_opt_sync_queue(data)
                            if migration_job is True:
                                jobs_status_dict['Success'].append(job)
                                logging.info(f"{key_name}----Job is done {job}")
                            else:
                                jobs_status_dict['failed'].append(job)
                                logging.info(f"{key_name}---Errors in job {job}")
                            # Log success for job enqueue
                            jobs_status_dict['Success'].append(job)
                            logging.info(f"{key_name} - Job sent to SQS successfully: {job}")

                        except Exception as e:
                            jobs_status_dict["failed"].append(job)
                            logging.error(
                                f"{key_name} - Failed to send job {job} to SQS: {e}"
                            )
                    else:
                        try:
                            job_name_dict = {}
                            job_name_dict["job_name"] = job
                            time_elapsed = time.time() - start_time
                            logging.info(
                                f"Time elapsed since start: {time_elapsed:.2f} seconds before starting job: {job}"
                            )
                            logging.info(
                                f"Sending ip is {opt_session_uuid}- {job_name_dict}"
                            )
                            logging.info(f"Job started in lambda_sync_jobs: {job}")
                            job_start_time = time.time()

                            migration_job = self.main_migration_func(job, key_name_received)

                            job_end_time = time.time()
                            job_duration = job_end_time - job_start_time
                            if migration_job is True:
                                jobs_status_dict["Success"].append(job)
                                logging.info(
                                    f"{key_name}----Job is done {job} completed successfully in {job_duration:.2f} seconds"
                                )
                            else:
                                jobs_status_dict["failed"].append(job)
                                logging.info(
                                    f"{opt_session_uuid}----{key_name}---Errors in job {job} failed in {job_duration:.2f} seconds"
                                )
                            # Create the message body
                            # data = {'job_name': job, 'path': "/main_migration_func"}
                            # logging.info(f"Sending job to SQS queue: {job}")

                            # Send message to SQS
                            # migration_job=self.send_msg_to_opt_sync_queue(data)
                            # if migration_job is True:
                            #     jobs_status_dict['Success'].append(job)
                            #     logging.info(f"{key_name}----Job is done {job}")
                            # else:
                            #     jobs_status_dict['failed'].append(job)
                            #     logging.info(f"{key_name}---Errors in job {job}")
                            # Log success for job enqueue
                            # jobs_status_dict['Success'].append(job)
                            # logging.info(f"{key_name} - Job sent to SQS successfully: {job}")
                        except Exception as e:
                            # Log failure for job enqueue
                            jobs_status_dict["failed"].append(job)
                            logging.error(
                                f"{key_name} - Failed to send job {job} to SQS: {e}"
                            )

            #     for job in job_names_list:
            #         data={}
            #         data['job_name']=job
            #         migration_job=self.main_migration_func(job)
            #         if migration_job is True:
            #             jobs_status_dict['Success'].append(job)
            #             logging.info(f"{key_name}----Job is done {job}")
            #         else:
            #             jobs_status_dict['failed'].append(job)
            #             logging.info(f"{key_name}---Errors in job {job}")
            except Exception as e:
                logging.error(
                    f"Error in lamda_sync_jobs_ {key_name} in job {job}-- {e}"
                )

            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            # db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")

            # hostname = "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"  # "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
            # port = "5432"
            # # db_name = "altaworx_test"
            # user = "root"
            # password = "AmopTeam123"
            # db_type = "postgresql"

            try:

                if tenant_name:
                    common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                    tenant_name_q=f"select db_name,db_config from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                    logging.info(f"Tenant name query is {tenant_name_q}")
                    tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                    logging.info(f"Tenant DF is {tenant_name_res}")
                    if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                        tenant_name_ = tenant_name_res['db_name'][0]
                        db_name=tenant_name_
                        db_config=tenant_name_res['db_config'][0]
                        if isinstance(db_config, str):
                            db_config = json.loads(db_config)
                        logging.info(f"Tenant name is {tenant_name_}")
                    else:
                        raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")

                else:
                    # db_name='altaworx_test'
                    logging.error(f"{opt_session_uuid} Tenant name is not provided")
            except Exception as e:
                logging.error(f"An error occurred loading tenant {opt_session_uuid} : {str(e)}")
                # db_name='altaworx_test'
            tenant_hostname=db_config['hostname']

            postgres_conn_altaworx = self.create_connection(
                db_type, tenant_hostname, db_name, user, password, port
            )

            if service_number:
                logging.info(f"{key_name} -------- service_number is {service_number}")
                update_dict = {"rev_service_line_status": "completed"}
                service_number_update = self.update_table(
                    postgres_conn_altaworx,
                    "rev_service",
                    update_dict,
                    {"number": service_number},
                )

            if (
                opt_session_uuid
                and comm_group_flag == False
                and key_name_received == "optimization_sync"
            ):
                logging.info(f"{key_name}-----opt session id {opt_session_uuid}")
                opt_run_end_time = datetime.now()
                # opt_dict={'progress':'75'}
                opt_dict = {
                    "progress": "75",
                    "optimization_run_end_time": opt_run_end_time,
                }
                logging.info(
                    f"############### {key_name} Updating optimization_session where session_id is {opt_session_uuid}"
                )
                opt_update = self.update_table(
                    postgres_conn_altaworx,
                    "optimization_session",
                    opt_dict,
                    {"session_id": opt_session_uuid},
                )
                data_ = {
                    "session_id": opt_session_uuid,
                    "path": "/optimization_sync_comm_group",
                    "tenant_name":tenant_name,
                    "sync_start_time": sync_start_time
                }
                logging.info(f"Input data {opt_session_uuid} is {data_}")
                # oo=self.send_msg_to_opt_sync_queue(data_)
                # logging.info("oo----------comm group-------",oo)
                # oo=self.optimization_sync_comm_group(data_)
                try:
                    logging.info(f"{opt_session_uuid} Calling SQS with {data_}")
                    oo = self.send_msg_to_opt_sync_queue(data_)
                    logging.info("SQS Message sent successfully for Comm_group")
                except Exception as e:
                    logging.error(f"Message sending failed for comm_group: {e}")

            elif (
                opt_session_uuid
                and comm_group_flag is True
                and key_name_received == "optimization_sync"
            ):
                logging.info(
                    f"{opt_session_uuid}: {key_name} Sync is Completed, Setting Progress to 100 AND Starting SYnc of tables"
                )
                # job = 'OptimizationSync'
                # migration_job=self.main_migration_func(job)
                # data = {"key_name": "optimization_sync","session_id": opt_session_uuid}
                # try:
                #     sync_all_opt_tables = self.lambda_sync_jobs_(data)
                #     logging.info(f"{opt_session_uuid}:Sync of all optimization tables is completed")
                # except Exception as e:
                #     logging.exception(f"{opt_session_uuid}:Error in sync of all optimization tables, {e}")
                opt_run_end_time = datetime.now()
                logging.info(
                    f"{opt_session_uuid}:{job} Sync is Completed, Setting Progress to 100"
                )
                opt_dict = {
                    "progress": "100",
                    "optimization_run_end_time": opt_run_end_time,
                    "opt_run_time":opt_run_time
                }
                # completed_dict[opt_session_uuid]='Complete'
                opt_update = self.update_table(
                    postgres_conn_altaworx,
                    "optimization_session",
                    opt_dict,
                    {"session_id": opt_session_uuid},
                )
                try:
                    logging.info(f"Push charges sync completed — fetching total SMS charges...{opt_session_uuid} ")

                    total_sms_charges_query = f"""
                        SELECT get_sms_charge_total(voi.optimization_instance_id) AS sms_charge_total
                        FROM vw_optimization_instance_pushed_charges voi
                        WHERE voi.session_id = '{opt_session_uuid}'
                    """

                    total_sms_charges_res = self.execute_query(postgres_conn_altaworx, total_sms_charges_query)

                    if not total_sms_charges_res.empty:
                        total_sms_charges = total_sms_charges_res['sms_charge_total'].iloc[0] or 0
                        total_sms_charges = float(total_sms_charges)
                        logging.info(f"Total SMS charges fetched successfully:{opt_session_uuid} {total_sms_charges}")
                    else:
                        logging.info(f"No records found for total SMS charges. {opt_session_uuid}")
                        total_sms_charges = 0

                    if total_sms_charges != 0:
                        logging.info(f"Updating the SMS charges in optimization_session table for session_id = {opt_session_uuid}")
                        update_dict = {
                            "total_sms_charges_20": total_sms_charges
                        }

                        self.update_table(
                            postgres_conn_altaworx,
                            "optimization_session",
                            update_dict,
                            {"session_id": opt_session_uuid},   # don't cast to int if it’s UUID-like
                        )
                        logging.info(" SMS charges updated successfully in optimization_session.")
                    else:
                        logging.info("Skipping update — total_sms_charges is 0.")
                except Exception as e:
                    logging.info(f" An error occurred while fetching or updating total SMS charges: {e}")

            # elif completed_dict is None:
            #     re_call=self.lambda_sync_jobs_(data)
            if bulk_change_id:
                update_dict = {"Progress": "Sync completed"}
                bulk_change_update = self.update_table(
                    postgres_conn_altaworx,
                    "sim_management_bulk_change",
                    update_dict,
                    {"id":bulk_change_id },
                )

            last_migrated_time = datetime.now()
            update_dict = {
                "sync_status": "Completed",
                "sync_job_status": json.dumps(jobs_status_dict),
                "last_migrated_time": last_migrated_time,
            }
            # update_dict=json.dumps(update_dict)
            logging.info(f"{opt_session_uuid} : sync update dict {update_dict}")
            update_sync_status = self.update_table(
                postgres_conn, migration_table, update_dict, {"key_name": key_name}
            )

            ##commenting for ticket 2114- new implementation if sync process
            # if not comm_group_flag:
            #     logging.info(f"Calling Lambda for error processes")
            #     comm_groups_sync=self.optimization_sync_comm_group(data)
            if trace_id:
                error_msg=None
                job_status_msg='Success'
                update_hist_table={'error_id_list':None,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':error_msg,'success':0,'failed':0,'job_status_msg':job_status_msg}
                self.update_table(postgres_conn,history_table,update_hist_table,{'trace_id':trace_id})

        except Exception as e:
            logging.error(
                f"{opt_session_uuid}:Error in lamda_sync_jobs_ {key_name} {e}"
            )
            if trace_id:
                tb = traceback.format_exc()
                msg=f"Error in lamda_sync_jobs_ {key_name} {e} {tb}"
                job_status_msg='Success'
                update_dict={'error_id_list':None,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'error_msg':msg,'success':0,'failed':0,'job_status_msg':job_status_msg}
                self.update_table(postgres_conn,history_table,update_dict,{'trace_id':trace_id})

            # logging.info(f"Error in main_migration_fun:last_id_migration {key_name} -{e}")
            return job_names_list

    def fetch_run_status_ids_(self, from_connection, from_database, session_id):
        query = (
            f"SELECT RunStatusId FROM {from_database}.dbo.vwOptimizationInstance "
            f"WHERE SessionId='{session_id}'"
        )
        result = self.execute_query(from_connection, query)
        logging.info(f"Query Result: {result}")
        return set(result["RunStatusId"])

    def fetch_run_status_ids(
        self, from_connection, from_database, session_id, error_ids
    ):
        try:
            scheduler = MigrationScheduler()
            error_ids_list = ", ".join(map(str, error_ids))
            query = (
                f"SELECT RunStatusId FROM {from_database}.dbo.vwOptimizationInstance "
                f"WHERE SessionId='{session_id}'AND RunStatusId IN ({error_ids_list})"
            )
            logging.info(f"Executing query to fetch run status ids: {query}")
            result = scheduler.execute_query(from_connection, query)
            logging.info(f"Returning RunStatusIds {result} {session_id}")
            return result
        except Exception as e:
            logging.error(f"Error in fetching run status ids {e}")
            return None

    def optimization_sync_comm_group(self, data):
        try:

            logging.info("Starting Optimiation Error Updates Sync....")
            logging.info("runinng using sqs  !!!!!!!!!!!!!")
            load_dotenv()
            
            last_hit_time = None
            sync_start_time = data.get("sync_start_time", None)
            if sync_start_time:
                logging.info(f"Optimization sync start time received: {datetime.fromtimestamp(sync_start_time)}")
            

            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")

            session_id = data.get("session_id")
            tenant_name=data.get('tenant_name',None)
            if tenant_name == 'Altaworx Test':
                tenant_name_ = 'altaworx'
                tenant_name_lcase = "altaworx"
            elif tenant_name == "Altaworx":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
            else:
                try:
                    common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                    postgres_conn_common = self.create_connection(
                        db_type, hostname, common_db_name, user, password, port
                    )
                    tenant_name_query = f"select db_name from tenant where tenant_name='{tenant_name}'"
                    tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                    db_name = tenant_name_df['db_name'].iloc[0].lower()
                except Exception as e:
                    logging.info(f"Error in getting tenant name from tenant_id: {e}")
                    db_name = tenant_name
                    pass
                tenant_name_lcase = db_name
                tenant_name_ = tenant_name

            # fetch the details of database as hosts will be different for each tenant
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            postgres_conn = self.create_connection(
                        db_type, hostname, db_name, user, password, port
                    )
            migrations_table = os.getenv('MIGRATION_TABLE')
            db_config_details = f"select from_db_config from {migrations_table} where migration_name='optimization_commgroup_commplan_{tenant_name_lcase.lower()}'"
            db_config_details = self.execute_query(postgres_conn,db_config_details)
            db_config_details = db_config_details["from_db_config"].tolist()[0]
            from_host = db_config_details["hostname"]
            from_port = db_config_details["port"]
            from_user = db_config_details["user"]
            from_pwd = db_config_details["password"]


            # from_host = os.getenv("MSSQL_DB_HOST")
            # from_port = os.getenv("MSSQL_DB_PORT")
            # from_user = os.getenv("MSSQL_DB_USER")
            # from_pwd = os.getenv("MSSQL_DB_PASSWORD")
            from_db_type = os.getenv("MSSQL_DB_TYPE")
            from_database = os.getenv("MSSQL_DB_NAME")
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            error_ids = {1, 2, 3, 4, 5}
            return_dict = {}
            success_or_failure_ids={6,7}
            for attempt in range(5):
                logging.info(
                    f"Attempt {attempt}: Executing query to fetch run status id's"
                )
                if attempt == 3:
                    logging.info(f"Attempt is {attempt} breaking.....")
                    logging.info(f"Restarting session {session_id} with SQS")
                    data_ = {
                        "session_id": session_id,
                        "path": "/optimization_sync_comm_group",
                        "timestamp": str(datetime.utcnow()),
                        "tenant_name": tenant_name_
                    }
                    try:
                        logging.info("SQS Message sent successfully for Comm_group")
                        oo = self.send_msg_to_opt_sync_queue(data_)
                        logging.info("SQS Message sent successfully for Comm_group")
                    except Exception as e:
                        logging.error(f"Message sending failed for comm_group: {e}")
                    break
                else:
                    logging.info(f"Attempt is {attempt} continuing.....")
                logging.info(
                    f"Comm Group Sync {session_id} Attempt {attempt}: Executing query to fetch run status id's"
                )
                # logging.info(f"Attempt {attempt}: Executing query to fetch run status id's")
                
                if last_hit_time:
                    diff = int(time.time() - last_hit_time)
                    logging.info(f"Last hit was {diff} seconds" if diff < 60 else f"Last hit was {diff//60} minutes")
                    last_hist_msg=f"{diff} seconds" if diff < 60 else f"{diff//60} minutes"
                    update_dict={
                        "last_update": last_hist_msg
                    }
                    condition_dict={"session_id":session_id}
                    self.update_table(
                    postgres_conn_tenant,
                    "optimization_session",
                    update_dict,
                   condition_dict
                )
                last_hit_time = time.time()  
                
                error_ids_df = self.fetch_run_status_ids(
                    from_connection, from_database, session_id, error_ids
                )
                logging.info(
                    f"Attempt {attempt} error ids from 1.0 for session {session_id} -- {error_ids_df} "
                )
                if error_ids_df is None:
                    logging.info(
                        f"Comm Group Sync {session_id} :: No such session Id found in 1.0 check the logs {session_id}"
                    )
                    return_dict = {
                        "flag": False,
                        "message": "No such session Id found in 1.0 check the logs",
                    }

                # elif error_ids_df.empty and attempt < 3:
                #     logging.info(
                #         f"Attempt {attempt} Comm Group Sync {session_id} No records with Errors or Comm Group Setup waiting for 5 min....."
                #     )
                #     return_dict = {
                #         "flag": False,
                #         "message": "No records with Errors or Comm Group Setup waiting for 1 min",
                #     }
                #     time.sleep(60)

                elif not error_ids_df.empty:
                    logging.info(
                        f"Attempt {attempt} Comm Group Sync {session_id} Found records with Errors or Comm Group Setup waiting for 5 min....."
                    )
                    return_dict = {
                        "flag": False,
                        "message": "Found records with Errors or Comm Group Setup waiting for 5 min",
                    }
                    time.sleep(3 * 60)
                else:
                    # <<=== CHANGE STARTS HERE ===>>
                    logging.info(
                        f"Comm Group Sync {session_id} :: No records found, sleeping 2 minutes before re-checking run status IDs"
                    )
                    time.sleep(2 * 60)
                    
                    if last_hit_time:
                        diff = int(time.time() - last_hit_time)
                        logging.info(f"Last hit was {diff} seconds ago" if diff < 60 else f"Last hit was {diff//60} minutes ago")

                    last_hit_time = time.time()    
                                        
                    
                    error_ids_df_retry = self.fetch_run_status_ids(
                        from_connection, from_database, session_id, error_ids
                    )
                    if not error_ids_df_retry.empty:
                        logging.info(
                            f"Comm Group Sync {session_id} :: Found records with Errors after 2 minutes, following wait & retry process"
                        )
                        return_dict = {
                            "flag": False,
                            "message": "Found records with Errors or Comm Group Setup after 2 min sleep, waiting for 3 min",
                        }
                        time.sleep(3 * 60)
                        continue
                    else:
                        logging.info(
                            f"Comm Group Sync {session_id} :: Still no records after 2 minutes, proceeding with sync"
                        )
                    # <<=== CHANGE ENDS HERE ===>>
                    for attempts in range(3):
                        
                        if last_hit_time:
                            diff = int(time.time() - last_hit_time)
                            logging.info(f"Last hit was {diff} seconds" if diff < 60 else f"Last hit was {diff//60} minutes ")

                        last_hit_time = time.time()                         
                        
                        error_ids_df_sub = self.fetch_run_status_ids(
                        from_connection, from_database, session_id, success_or_failure_ids
                        )
                        if not error_ids_df_sub.empty:
                            logging.info(
                                f"Attempt {attempts} Comm Group Sync {session_id} found Success or Failure records, so begining the sync "
                            )
                            break
                        else:
                            logging.info(
                                f"Attempt {attempts} Comm Group Sync {session_id} Success or Failure records and Error records  not found, so begining the sync"
                            )
                            time.sleep(60)
                    logging.info(
                        f"@@@@ Comm Group Sync {session_id} Attempt {attempt}: Comm Group Setup records not found, so begining the sync"
                    )
                    # Modified date is not being updated in 1.0 OptimizationInstance table, to handle it updating the last id for each session
                    last_instance_id = f"""SELECT TOP 1 Id FROM {from_database}.dbo.vwOptimizationInstance WHERE SessionId='{session_id}' ORDER BY Id ASC"""
                    last_instance_id_result = self.execute_query(
                        from_connection, last_instance_id
                    )
                    last_instance_id_ = last_instance_id_result["Id"].tolist()[0]
                    last_instance_id = int(last_instance_id_) - 1
                    # logging.info(f"Last Instance Id is {last_instance_id}")
                    logging.info(f"{session_id} Last Instance Id is {last_instance_id}")
                    # hostname = os.getenv("PSQL_DB_HOST")
                    # port = os.getenv("PSQL_DB_PORT")
                    # db_name = os.getenv("PSQL_DB_NAME")
                    # user = os.getenv("PSQL_DB_USER")
                    # password = os.getenv("PSQL_DB_PASSWORD")
                    # db_type = os.getenv("PSQL_DB_TYPE")

                    # hostname = os.getenv("")#"amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"  # "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
                    # port = "5432"
                    # db_name = "Migration_Test"
                    # db_main = "altaworx_test"
                    # user = "root"
                    # password = "AmopTeam123"
                    # db_type = "postgresql"

                    try:

                        if tenant_name:
                            common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                            tenant_name_q=f"select db_name from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                            logging.info(f"Tenant name query is {tenant_name_q}")
                            tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                            logging.info(f"Tenant DF is {tenant_name_res}")
                            if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                                tenant_name_ = tenant_name_res['db_name'][0]
                                db_main=tenant_name_
                                logging.info(f"Tenant name is {tenant_name}")
                            else:
                                raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")


                        else:
                            # db_main='altaworx_test'
                            logging.error("Tenant name is not provided")
                    except Exception as e:
                        logging.error(f"An error occurred loading tenant: {str(e)}")
                        # db_main='altaworx_test'

                    # postgres_conn = self.create_connection(
                    #     db_type, hostname, db_name, user, password, port
                    # )
                    last_id = f"{[last_instance_id]}"
                    logging.info(f"Last Instance Id is {last_id}")
                    update_dict = {"last_id": last_id}
                    load_dotenv()
                    # migrations_table=os.getenv('MIGRATION_TABLE')
                    uu = self.update_table(
                        postgres_conn,
                        migrations_table,
                        update_dict,
                        {"migration_name": f"optimization_instance_{tenant_name_lcase.lower()}"}
                    )

                    data_opt = {
                        "data": {
                            "key_name": "optimization_sync",
                            "session_id": session_id,
                            "tenant_name":tenant_name,
                            "opt_run_time":sync_start_time
                        }
                    }
                    status_flag = True
                    logging.info(f"Calling final Sync for Comm Group {session_id}")
                    logging.info(
                        f"data for Comm group syn is {data_opt}, status flag is {status_flag}"
                    )
                    opt_sync = self.lambda_sync_jobs_(data_opt, True)
                    return_dict = {
                        "flag": True,
                        "message": "Optimization Sync Successfull",
                    }
                    break

            logging.info("Attempts Completed,Retrying again")

            # data_opt={"data": {"key_name": "optimization_sync", "session_id": session_id}}
            # opt_sync=self.lambda_sync_jobs_(data_opt,True)
            # status_flag=True
        except Exception as e:
            logging.error(
                f"{session_id} Error in running optimization sync in case of comm group errors {e}"
            )
            return {"flag": False, "message": {e}}
        

        finally:
            # ---- TOTAL SYNC TIME ----
            if data.get("sync_start_time"):
                sync_start_time = data["sync_start_time"]
                sync_end_time = time.time()
                total_sync_seconds = sync_end_time - sync_start_time

                # Convert into readable format
                readable_total_time = self.format_time_readable(total_sync_seconds)

                logging.info(f"Total time taken for full optimization sync: {readable_total_time}")

                # Store into optimization_session table
                try:
                    update_dict = {"opt_run_time": readable_total_time}

                    self.update_table(
                        postgres_conn_tenant,
                        "optimization_session",
                        update_dict,
                        {"session_id": session_id}
                    )

                    logging.info(f"Updated opt_run_time = '{readable_total_time}' for session_id = {session_id}")

                except Exception as e:
                    logging.info(f"Error updating opt_run_time: {e}")

            else:
                logging.info("sync_start_time not found in data, cannot calculate total time.")            

            
                
                
            # FINAL last hit log
            
            if last_hit_time:
                diff = int(time.time() - last_hit_time)

                if diff < 60:
                    last_update_text = f"{diff} seconds"
                else:
                    last_update_text = f"{diff // 60} minutes"

                    logging.info(f"Last hit was {last_update_text}")
            else:
                last_update_text = None
                
            if last_update_text:
                try:
                    update_dict = {"last_update": last_update_text}

                    self.update_table(
                        postgres_conn_tenant,
                        "optimization_session",
                        update_dict,
                        {"session_id": session_id}
                    )
                    logging.info(f"Updated optimization_session.last_update with '{last_update_text}'")

                except Exception as e:
                    logging.info(f"Failed to update last_update in optimization_session: {e}")
        
               
        return return_dict

    '''def optimization_status_syncs(self):
        try:
            load_dotenv()
            logging.info(f"Begining Migration for statuses")
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            # hostname = "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com"  # "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com"
            # port = "5432"
            # db_name = "Migration_Test"
            # db_main = "altaworx_test"
            # user = "root"
            # password = "AmopTeam123"
            # db_type = "postgresql"
            try:
                postgres_conn_altaworx = self.create_connection(
                    db_type, hostname, db_main, user, password, port
                )
                get_pending_session_ids = f"select session_id from optimization_session where progress<>'100' order by optimization_run_start_date asc nulls last"
                get_pending_session_id_result = self.execute_query(
                    postgres_conn_altaworx, get_pending_session_ids
                )
            except Exception as e:
                pending_session_ids = []
            if (
                get_pending_session_id_result is not None
                and not get_pending_session_id_result.empty
            ):
                pending_session_ids = get_pending_session_id_result[
                    "session_id"
                ].tolist()
            logging.info(f"result is {pending_session_ids}")
            result_dict = {}
            for session_id in pending_session_ids:
                logging.info(f"Session id is {session_id}")
                data = {"key_name": "optimization_sync", "session_id": session_id}
                logging.info(f"Session id is {session_id} is starting, data is {data}")
                try:
                    result = self.optimization_sync_comm_group(data)
                    if result["flag"]:
                        result_dict[session_id] = "Success"
                    else:
                        result_dict[session_id] = f"Failed-{result['message']}"

                except Exception as e:
                    logging.error(
                        f"Error in optimization_sync_comm_group for session_id {session_id}: {e}"
                    )
                    result_dict[session_id] = f"Failed: {str(e)}"

                opt_dict = {"optimization_status_syncs": result_dict[session_id]}
                logging.info(
                    f"############### Updating optimization_session where session_id is {session_id}"
                )
                opt_update = self.update_table(
                    postgres_conn_altaworx,
                    "optimization_session",
                    opt_dict,
                    {"session_id": session_id},
                )

            logging.info(f"Session id is {session_id} is done")
            logging.info(f"Result dict is {result_dict}")

        except Exception as e:
            logging.error(f"Error in optimization_status_syncs {e}")
            return {"flag": False, "message": {e}}
        return {"flag": True, "message": result_dict}'''

    def get_processed_count(
        self, from_connection, check_view, opt_session_id, instance_ids_tuple,union_flag
    ):
        try:
            if union_flag:
                processed_count=0
                not_processed_count=0
                if len(instance_ids_tuple)==1:
                    instance_ids_tuple=str(instance_ids_tuple).replace(",","")
                processed_count_query=f"""SELECT SUM(cnt) AS total_count
                                        FROM (
                                                SELECT COUNT(*) as cnt FROM AltaworxCentral_Test.dbo.vwOptimizationDeviceResult_CustomerChargeQueue
                                                WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=1 and OptimizationInstanceId in {instance_ids_tuple}
                                                union all
                                                SELECT COUNT(*) FROM AltaworxCentral_Test.dbo.vwOptimizationMobilityDeviceResult_CustomerChargeQueue
                                                WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=1 and OptimizationInstanceId in {instance_ids_tuple}
                                            ) AS combined_counts
                                            """
                processed_count_result=self.execute_query(from_connection,processed_count_query)

                logging.info(f"Processed Count Query {processed_count_query}")
                logging.info(f"Processed Count Result {processed_count_result}")
                if processed_count_result.empty:
                    processed_count=0
                else:
                    processed_count=processed_count_result['total_count'].iloc[0]

                logging.info(f"Processed Count {processed_count}")
                not_processed_count_query=f"""SELECT SUM(cnt) AS total_count
                                            FROM (
                                                SELECT COUNT(*) as cnt FROM AltaworxCentral_Test.dbo.vwOptimizationDeviceResult_CustomerChargeQueue
                                                WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=0 and OptimizationInstanceId in {instance_ids_tuple}
                                                union all
                                                SELECT COUNT(*) as mobility_count FROM AltaworxCentral_Test.dbo.vwOptimizationMobilityDeviceResult_CustomerChargeQueue
                                                WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=0 and OptimizationInstanceId in {instance_ids_tuple}
                                            ) AS combined_counts"""
                not_processed_count_result=self.execute_query(from_connection,not_processed_count_query)
                logging.info(f"Not Processed Count Query {not_processed_count_query}")
                logging.info(f"Not Processed Count Result {not_processed_count_result}")
                if not_processed_count_result.empty:
                        not_processed_count=0
                else:
                    not_processed_count=not_processed_count_result['total_count'].iloc[0]
                logging.info(f"Not Processed Count {not_processed_count}")
                return processed_count,not_processed_count
            else:
                processed_count = 0
                not_processed_count = 0
                if len(instance_ids_tuple) == 1:
                    instance_ids_tuple = str(instance_ids_tuple).replace(",", "")
                processed_count_query = f"SELECT COUNT(*) FROM {onepoint_o_database}.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=1 and OptimizationInstanceId in {instance_ids_tuple}"
                # processed_count_query=f"SELECT COUNT(*) FROM AltaworxCentral_Test.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=1"
                processed_count_result = self.execute_query(
                    from_connection, processed_count_query
                )
                logging.info(f"Processed Count Query {processed_count_query}")
                logging.info(f"Processed Count Result {processed_count_result}")
                if processed_count_result.empty:
                    processed_count = 0
                else:
                    processed_count = processed_count_result[""].iloc[0]
                logging.info(f"Processed Count {processed_count}")

                # not_processed_count_query=f"SELECT COUNT(*) FROM AltaworxCentral_Test.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=0"
                not_processed_count_query = f"SELECT COUNT(*) FROM {onepoint_o_database}.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}' AND IsProcessed=0 and OptimizationInstanceId in {instance_ids_tuple}"
                not_processed_count_result = self.execute_query(
                    from_connection, not_processed_count_query
                )
                logging.info(f"Not Processed Count Query {not_processed_count_query}")
                logging.info(f"Not Processed Count Result {not_processed_count_result}")
                if not_processed_count_result.empty:
                    not_processed_count = 0
                else:
                    not_processed_count = not_processed_count_result[""].iloc[0]
                logging.info(f"Not Processed Count {not_processed_count}")
                return processed_count, not_processed_count
        except Exception as e:
            logging.error(f"Error in get_processed_count {e}")
            return {"flag": False, "message": {e}}

    def load_json(self):
        """
        Loads a JSON file and returns the data.

        :param file_path: Absolute path to the JSON file.
        :return: Parsed JSON data as a dictionary, or None if an error occurs.

        """
        # Define the JSON file path
        FILE_PATH = "tenant_based_serviceproviders.json"
        file_path=FILE_PATH
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return json.load(file)
        except FileNotFoundError:
            logging.warning(f"Error: JSON file not found at {file_path}")
        except json.JSONDecodeError:
            logging.warning(f"Error: Invalid JSON format in {file_path}")
        except Exception as e:
            logging.exception(f"Unexpected error while reading JSON: {e}")

        return {}  # Return None if an error occurs


    def get_provider_ids(self,json_data, tenant_name, provider_names):
        """Fetches only the IDs of specified providers for a given tenant."""
        return [
            details["id"]
            for provider_name, details in json_data.get(tenant_name, {}).items()
            if provider_name in provider_names
        ]

    def push_charges_sync(self, data):
        try:
            load_dotenv()
            logging.info(f"In lambda sync job data received for push charges {data}")

            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")

            key_name_received=data.get('key_name')
            logging.info(f"Key name {key_name_received}")
            tenant_name=data.get('tenant_name')
            opt_session_id = data.get("session_id")
            service_provider_id = data.get("service_provider_id")
            service_provider_ids = data.get("service_provider_ids")
            sync_call_first = data.get("sync_call_first", False)
            instance_ids = data.get("instance_id", None)
            total_count = data.get("total", None)
            sqs_flag = data.get("sqs_flag", False)
            tota_count_int = int(total_count)
            logging.info(f"Total count is {tota_count_int}")
            instance_ids_tuple = tuple(instance_ids)
            logging.info(f"Instance Ids {instance_ids}")
            #adding tenant name key handling
            service_provider_ids=data.get('service_provider_ids',None)
            tenant_name=data.get('tenant_name',None)
            common_utils_db=os.getenv("COMMON_UTILS_DB_NAME")
            comm_postgres_con= self.create_connection(
                db_type, hostname,common_utils_db, user, password, port
            )
            if isinstance(service_provider_ids,str) and len(service_provider_ids)>0:
                union_flag=True
            else:
                union_flag=False

            if tenant_name:
                tenant_name=self.function_to_check_sub_tenant_or_parent_name(comm_postgres_con,tenant_name)
            logging.info(f"tenant_name finally gotten after checking subtenant {tenant_name}")

            if tenant_name is None:
                logging.info(f"{key_name_received}: Tenant name and tenant id is None")
                return {'flag':False,'message':'Tenant Name and Tenant Id is None'}

            if tenant_name == "Altaworx Test":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
            elif tenant_name == "Altaworx":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
            
            try:
                common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                postgres_conn_common = self.create_connection(
                    db_type, hostname, common_db_name, user, password, port
                )
                tenant_name_query = f"select db_name,db_config from tenant where tenant_name='{tenant_name}'"
                tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                db_name = tenant_name_df['db_name'].iloc[0].lower()
                db_config = tenant_name_df['db_config'].iloc[0]
                if isinstance(db_config, str):
                    db_config = json.loads(db_config)
            except Exception as e:
                logging.info(f"Error in getting tenant name from tenant_id: {e}")
                db_name = tenant_name
                pass
                tenant_name_lcase = db_name
                tenant_name_ = tenant_name
            tenant_hostname=db_config['hostname']
            logging.info(f"Tenant hostname found {tenant_hostname}")

            if key_name_received and tenant_name:
                key_name = f"{key_name_received}_{tenant_name_lcase.lower()}"
            else:
                key_name = key_name_received
            logging.info(f"Received Key name {key_name_received} and tenant name {tenant_name_lcase.lower()}, Final key formed is {key_name}")

            json_data = self.load_json()
            telegence_ids = self.get_provider_ids(json_data, tenant_name, ["Telegence"])
            if service_provider_id in telegence_ids:
                logging.info(
                    f"Service Provider ID {service_provider_id} is mobility for session id {opt_session_id}"
                )
                mobility_flag = True
            else:
                mobility_flag = False

            logging.info(
                f"Begining Migration for {key_name}-session id {opt_session_id}"
            )
            if mobility_flag:
                check_view = "vwOptimizationMobilityDeviceResult_CustomerChargeQueue"
            else:
                check_view = "vwOptimizationDeviceResult_CustomerChargeQueue"

            # fetch the details of database as hosts will be different for each tenant
            # hostname = os.getenv("PSQL_DB_HOST")
            # port = os.getenv("PSQL_DB_PORT")
            # db_name = os.getenv("PSQL_DB_NAME")
            # user = os.getenv("PSQL_DB_USER")
            # password = os.getenv("PSQL_DB_PASSWORD")
            # db_type = os.getenv("PSQL_DB_TYPE")
            migration_db_name = os.getenv("PSQL_DB_NAME")
            postgres_conn = self.create_connection(
                        db_type, hostname, migration_db_name, user, password, port
                    )
            migrations_table = os.getenv('MIGRATION_TABLE')
            db_config_details = f"select from_db_config from {migrations_table} where migration_name='optimization_commgroup_commplan_{tenant_name.lower()}'"

            db_config_details = self.execute_query(postgres_conn,db_config_details)
            db_config_details = db_config_details["from_db_config"].tolist()[0]
            if isinstance(db_config_details, str):  # Convert only if it's a string
                db_config_details = json.loads(db_config_details)

            from_host = db_config_details["hostname"]
            from_port = db_config_details["port"]
            from_user = db_config_details["user"]
            from_pwd = db_config_details["password"]
            # from_host = os.getenv("MSSQL_DB_HOST")
            # from_port = os.getenv("MSSQL_DB_PORT")
            from_db_type = os.getenv("MSSQL_DB_TYPE")
            from_database = os.getenv("MSSQL_DB_NAME")
            # from_user = os.getenv("MSSQL_DB_USER")
            # from_pwd = os.getenv("MSSQL_DB_PASSWORD")
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            logging.info(
                f"session id {opt_session_id} From Host {from_host} From Port {from_port} From DB Type {from_db_type} From Database {from_database} From User {from_user} From Pwd {from_pwd} From Driver {from_driver}"
            )
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(
                f"session id {opt_session_id} From Connection {from_connection}"
            )
            # get_query=f"SELECT id FROM AltaworxCentral_Test.dbo.OptimizationSession where sessionid='{opt_session_id}'"
            # result=self.execute_query(from_connection,get_query)
            # opt_session_id=result['id'].iloc[0]

            check_query = f"SELECT * FROM {onepoint_o_database}.dbo.{check_view} WHERE OptimizationSessionId='{opt_session_id}'"
            logging.info(f"Check Query {check_query}")
            check_query_result = self.execute_query(from_connection, check_query)
            logging.info(
                f"Result f Query {opt_session_id}: {check_query_result.head()}"
            )
            # if check_query_result.empty:
            #     logging.info(f"No records found for the session id {opt_session_id} in {check_view}")
            #     logging.error(f"No records found for the session id {opt_session_id} in {check_view}")
            #     return {"flag":False,"message":f"No records found for the session id {opt_session_id} in {check_view}"}
            # else:
            # hostname = os.getenv("PSQL_DB_HOST")
            # port = os.getenv("PSQL_DB_PORT")
            # # db_name = os.getenv("PSQL_MAIN_DB")
            # user = os.getenv("PSQL_DB_USER")
            # password = os.getenv("PSQL_DB_PASSWORD")
            # db_type = os.getenv("PSQL_DB_TYPE")

            try:

                if tenant_name:
                    common_utils_conn=self.create_connection(db_type,hostname,'common_utils',user,password,port)
                    tenant_name_q=f"select db_name,db_config from tenant where tenant_name='{tenant_name}' and is_active=true and is_deleted=false"
                    logging.info(f"Tenant name query is {tenant_name_q}")
                    tenant_name_res=self.execute_query(common_utils_conn,tenant_name_q)
                    logging.info(f"Tenant DF is {tenant_name_res}")
                    if tenant_name_res is not None and not tenant_name_res.empty and 'db_name' in tenant_name_res.columns:
                        tenant_name_ = tenant_name_res['db_name'][0]
                        db_name=tenant_name_
                        logging.info(f"Tenant name is {tenant_name_}")
                        db_config = tenant_name_df['db_config'].iloc[0]
                        if isinstance(db_config, str):
                            db_config = json.loads(db_config)
                    else:
                        raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")


                else:
                    logging.error(f"An error occurred loading tenant  :No tenant name found")
                    # db_name='altaworx_test'
            except Exception as e:
                logging.error(f"An error occurred loading tenant  : {str(e)}")
                # db_name='altaworx_test'
            tenant_db_host=db_config['hostname']


            logging.info(
                f"Hostname {tenant_db_host} Port {port} DB Name {db_name} User {user} Password {password} DB Type {db_type}"
            )
            postgres_conn_altaworx = self.create_connection(
                db_type, tenant_db_host, db_name, user, password, port
            )
            logging.info(f"Main conn in push charges {postgres_conn_altaworx}")

            retries = 4
            for attempt in range(retries):
                logging.info(
                    f"session id {opt_session_id} Attempt {attempt}: Executing query to fetch processed count"
                )
                processed_count, not_processed_count = self.get_processed_count(
                    from_connection, check_view, opt_session_id, instance_ids_tuple,union_flag
                )

                update_dict = {"push_charges_not_processed_count": int(processed_count)}
                logging.info(
                    f"session id {opt_session_id} Counts returned -- update_dict {update_dict}"
                )
                logging.info(
                    f"############### Updating optimization_session where session_id is {opt_session_id},update_dict={update_dict}"
                )
                if processed_count == 0 and sync_call_first:
                    logging.info("dont update")
                    uu = self.update_table(
                        postgres_conn_altaworx,
                        "optimization_session",
                        update_dict,
                        {"id": int(opt_session_id)},
                    )
                else:
                    uu = self.update_table(
                        postgres_conn_altaworx,
                        "optimization_session",
                        update_dict,
                        {"id": int(opt_session_id)},
                    )

                # if processed_count==0:
                #     logging.info(f"Processed count 0 ")
                #     update_dict={"push_charges_processed_count":int(processed_count)}
                #     uu=self.update_table(postgres_conn_altaworx,'optimization_session',update_dict,{'id':int(opt_session_id)})
                # else:

                # update_dict={'push_charges_not_processed_count':int(not_processed_count),'push_charges_processed_count':int(processed_count)}
                # update_dict={'push_charges_not_processed_count':int(not_processed_count),'push_charges_processed_count':int(processed_count)}

                # if not_processed_count==0 and processed_count>0:
                if (
                    processed_count == tota_count_int
                    or processed_count > tota_count_int
                ):
                    logging.info(
                        f"Total Match session id {opt_session_id} processed_count-{processed_count}"
                    )
                    update_dict = {
                        "push_charges_not_processed_count": int(processed_count)
                    }
                    if processed_count == 0 and sync_call_first:
                        uu = self.update_table(
                            postgres_conn_altaworx,
                            "optimization_session",
                            update_dict,
                            {"id": int(opt_session_id)},
                        )
                    else:
                        uu = self.update_table(
                            postgres_conn_altaworx,
                            "optimization_session",
                            update_dict,
                            {"id": int(opt_session_id)},
                        )
                    # logging.info(f"session id {opt_session_id} breaking the loop not_processed_count-{not_processed_count},processed_count-{processed_count}")
                    processed_flag = True
                    break
                elif attempt == retries - 1:
                    data_ = {
                        "session_id": opt_session_id,
                        "path": "/push_charges_sync",
                        "key_name": "optimization_sync_push_charges",
                        "instance_id": instance_ids,
                        "total": total_count,
                        "service_provider_id": service_provider_id,
                        "service_provider_ids":service_provider_ids,
                        "sqs_flag": True,
                        "timestamp": str(datetime.utcnow()),
                        "tenant_name": tenant_name
                    }
                    # logging.info(f"session id {opt_session_id} Attempts are completed,forcing the processed flag and syncing the data {attempt}")
                    # processed_flag=True
                    logging.info(
                        f"session id {opt_session_id} Attempts are completed calling SQS with {data_}"
                    )
                    processed_flag = False
                    try:
                        logging.info(f"SQS Message sent successfully for Push Charges")
                        oo = self.send_msg_to_opt_sync_queue(data_)
                        logging.info(f"SQS Message sent successfully for Push Charges")
                    except Exception as e:
                        logging.error(f"Message sending failed for Push Charges: {e}")

                else:
                    logging.info(
                        f" session id {opt_session_id} Records are not processed for the session id {opt_session_id} in {check_view}, Waiting for the next sync"
                    )
                    time.sleep(60)
            if processed_flag:
                logging.info(
                    f"All records are processed for the session id {opt_session_id} in {check_view}, Starting the sync"
                )
                logging.info(f"Begining Migration for {key_name}")
                hostname = os.getenv("PSQL_DB_HOST")
                port = os.getenv("PSQL_DB_PORT")
                db_name = os.getenv("PSQL_DB_NAME")
                user = os.getenv("PSQL_DB_USER")
                password = os.getenv("PSQL_DB_PASSWORD")
                db_type = os.getenv("PSQL_DB_TYPE")
                logging.info(
                    f"Hostname {hostname} Port {port} DB Name {db_name} User {user} Password {password} DB Type {db_type}"
                )
                postgres_conn = self.create_connection(
                    db_type, hostname, db_name, user, password, port
                )
                migration_table = "lambda_sync_jobs"
                job_scheduled_query = f"select migration_names_list from {migration_table} where key_name='{key_name}'"
                rows = self.execute_query(postgres_conn, job_scheduled_query)
                logging.info(
                    f"session id {opt_session_id} Data from key name is {rows},{type(rows)}"
                )
                job_names_list = rows["migration_names_list"][0]
                logging.info(
                    f"session id {opt_session_id} Job names are {job_names_list},{type(job_names_list)}"
                )
                jobs_status_dict = {"Success": [], "failed": []}
                logging.info(
                    f"session id {opt_session_id} Job names are {job_names_list},{type(job_names_list)}"
                )
                try:
                    for job in job_names_list:
                        migration_job = self.main_migration_func(job, key_name)
                        # migration_job=True
                        logging.info(
                            f"session id {opt_session_id} migration job has run -- {job}"
                        )
                        if migration_job is True:
                            jobs_status_dict["Success"].append(job)
                            logging.info(f"Job is done {job}")
                        else:
                            jobs_status_dict["failed"].append(job)
                            logging.info(f"Errors in job {job}")
                except Exception as e:
                    logging.info(
                        f"Error in push_charges_sync {key_name} in job {job}-- {e}"
                    )
                try:
                    logging.info(f"Push charges sync completed — fetching total SMS charges... {opt_session_id}")

                    total_sms_charges_query = f"""
                        SELECT get_sms_charge_total(voi.optimization_instance_id) AS sms_charge_total
                        FROM vw_optimization_instance_pushed_charges voi
                        WHERE voi.optimization_session_id = '{opt_session_id}'
                    """

                    total_sms_charges_res = self.execute_query(postgres_conn_altaworx, total_sms_charges_query)

                    if not total_sms_charges_res.empty:
                        total_sms_charges = total_sms_charges_res['sms_charge_total'].iloc[0] or 0
                        total_sms_charges = float(total_sms_charges)
                        logging.info(f"Total SMS charges fetched successfully: {total_sms_charges}")
                    else:
                        logging.info(f"No records found for total SMS charges. {opt_session_id}")
                        total_sms_charges = 0

                    if total_sms_charges != 0:
                        logging.info(f"Updating the SMS charges in optimization_session table for session_id = {opt_session_id}")
                        update_dict = {
                            "total_sms_charges_20": total_sms_charges
                        }

                        self.update_table(
                            postgres_conn_altaworx,
                            "optimization_session",
                            update_dict,
                            {"id": opt_session_id},   # don't cast to int if it’s UUID-like
                        )
                        logging.info(f" SMS charges updated successfully in optimization_session.{opt_session_id}")
                    else:
                        logging.info(f"Skipping update — total_sms_charges is 0.{opt_session_id}")

                except Exception as e:
                    logging.info(f" An error occurred while fetching or updating total SMS charges: {e} {opt_session_id}")

        except Exception as e:
            logging.info(f"Error in push_charges_sync {key_name} {e}")

    def optimization_sync_comm_group_bak_24dec24(
        self, data
    ):  # removing on for ticket 2114 (implemention function for comm group error)
        try:
            logging.info(f"Starting Optimiation Error Updates Sync....")
            load_dotenv()
            session_id = data.get("session_id")
            from_host = os.getenv("MSSQL_DB_HOST")
            from_port = os.getenv("MSSQL_DB_PORT")
            from_user = os.getenv("MSSQL_DB_USER")
            from_pwd = os.getenv("MSSQL_DB_PASSWORD")
            from_db_type = os.getenv("MSSQL_DB_TYPE")
            from_database = os.getenv("MSSQL_DB_NAME")
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            # logging.info(f"from driver {from_driver}")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            error_ids = {1, 2, 3, 4, 5}
            for attempt in range(3):
                logging.info(f"Attempt {attempt}: Executing query to fetch run status id's")
                error_ids_df = self.fetch_run_status_ids(
                    from_connection, from_database, session_id, error_ids
                )
                if not error_ids_df.empty:
                    logging.info(
                        f"Found records with Errors or Comm Group Setup waiting for 5 min....."
                    )
                    time.sleep(30)
                else:
                    logging.info(
                        f"Attempt {attempt}: Comm Group Setup records not found, so begining the sync"
                    )
                    data_opt = {
                        "data": {
                            "key_name": "optimization_sync",
                            "session_id": session_id,
                        }
                    }
                    opt_sync = self.lambda_sync_jobs_(data_opt, True)

            logging.info(f"Attempts Completed,Syncing the data")
            data_opt = {
                "data": {"key_name": "optimization_sync", "session_id": session_id}
            }
            opt_sync = self.lambda_sync_jobs_(data_opt, True)
        except Exception as e:
            logging.error(
                f"Error in running optimization sync in case of comm group errors {e}"
            )
            return {"flag": False, "message": {e}}
        return {"flag": True, "message": "Optimization Sync Successfull"}

    def optimization_sync_comm_group_old(self, data):
        try:
            logging.info(f"Starting Optimiation Error Updates Sync....")
            load_dotenv()
            session_id = data.get("session_id")
            from_host = os.getenv("MSSQL_DB_HOST")
            from_port = os.getenv("MSSQL_DB_PORT")
            from_user = os.getenv("MSSQL_DB_USER")
            from_pwd = os.getenv("MSSQL_DB_PASSWORD")
            from_db_type = os.getenv("MSSQL_DB_TYPE")
            from_database = os.getenv("MSSQL_DB_NAME")
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            # logging.info(f"from driver {from_driver}")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )

            retries = 3
            for attempt in range(3):
                logging.info(
                    f"Attempt {attempt}: Executing query to fetch run status id's"
                )
                unique_run_status_ids = self.fetch_run_status_ids(
                    from_connection, from_database, session_id
                )
                logging.info(
                    f"Attempt-{attempt}: Run Status ids::{unique_run_status_ids}"
                )
                comm_group_error_id = 2
                error_ids = {1, 2, 3, 4, 5}
                if unique_run_status_ids & error_ids:
                    logging.info(
                        f"Found records with Errors or Comm Group Setup waiting for 5 min....."
                    )
                    time.sleep(4 * 60)
                else:
                    logging.info(
                        f"Comm Group Setup records not found, so begining the sync"
                    )
                    data_opt = {
                        "data": {
                            "key_name": "optimization_sync",
                            "session_id": session_id,
                        }
                    }
                    opt_sync = self.lambda_sync_jobs_(data_opt, flag=True)

            logging.info(f"Attempts Completed,Syncing the data")
            data_opt = {
                "data": {"key_name": "optimization_sync", "session_id": session_id}
            }
            opt_sync = self.lambda_sync_jobs_(data_opt, Flag=True)

        except Exception as e:
            logging.error(
                f"Error in running optimization sync in case of comm group errors {e}"
            )
            return {"flag": False, "message": {e}}
        return {"flag": True, "message": "Optimization Sync Successfull"}

    def get_mapping_details(self, conn,transfer_name):
        """
        this function used to get mapping details for optimization_setting
        """
        try:
            query = f"SELECT col_mapping_10_to_20 FROM mapping_table WHERE transfer_name ='{transfer_name}' "
            query_result = self.execute_query(conn, query)
            return query_result.to_dict(orient="records")[0]
        except Exception as e:
            logging.info(f"Error while fetching the details - {e}")
            return {}

    def update_optimization_setting_table(
        self, columns_mapping, result_data, rev_settings_dict, to_connection
    ):
        columns_mapping_dict = dict(columns_mapping)
        swapped_columns_mapping_dict = {v: k for k, v in columns_mapping_dict.items()}
        settings_dict = dict(
            zip(result_data["setting_key"], result_data["setting_value"])
        )
        set_clause = []
        values = []
        for setting_key, setting_value in settings_dict.items():
            actual_column_name = swapped_columns_mapping_dict.get(setting_key)
            if actual_column_name:
                set_clause.append(f"{actual_column_name} = %s")
                values.append(setting_value)
        logging.info(f"set clause is {set_clause}")
        logging.info(f"Now adding rev setting to the set clause")

        if rev_settings_dict:
            for rev_key, rev_value in rev_settings_dict.items():
                set_clause.append(f"{rev_key} = %s")
                values.append(rev_value)
        logging.info(f"final set clause {set_clause}")
        logging.info(f"final values are {values}")

        if set_clause:
            update_query = f"""
                    UPDATE optimization_setting
                    SET {', '.join(set_clause)}
                                """

        logging.info(f"swapped_columns_mapping_dict {swapped_columns_mapping_dict}")
        logging.info(f"settings_dict------{settings_dict}")
        logging.info(f"update_query----------- {update_query}")
        logging.info(f"values {values}")
        try:
            # Creating a cursor to execute the query
            with to_connection.cursor() as cur:
                # Execute the update query with the values
                cur.execute(update_query, tuple(values))

                # Commit the transaction
                to_connection.commit()
                logging.info("Update successful")

        except Exception as e:
            # Handle any exceptions that occur during the update
            logging.error(f"Error updating optimization_setting table: {e}")
            to_connection.rollback()
        return None

    def optimization_setting_handler(self, job_name,tenant_id,tenant_name=None,trace_id=None):
        try:
            logging.info(f"starting the job for optimzation_settings table {job_name}")
            load_dotenv()
            msg=None
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            db_name = os.getenv("PSQL_DB_NAME")
            transfer_name=job_name

            logging.info(
                f" {job_name} postgress sql db configuration loaded successfully"
            )
            tenant_json=self.load_json()
            if tenant_name:
                tenant_id_dict=tenant_json.get('TenanatIds')
                tenant_id=tenant_id_dict.get(tenant_name)

            # logging.info(hostname,port)

            # Create the PostgreSQL connection to the source database
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info(f"*********************** Executing job: {job_name}")

            load_dotenv()
            migration_table=os.getenv('MIGRATION_TABLE')
            migrations_history_table=os.getenv('MIGRATIONS_HISTORY_TABLE')
            # hist_insert_data={'key_name':job_name,'job_name':job_name,'job_start_time':datetime.now(timezone.utc).replace(tzinfo=None),
            #                   'request_triggered_by':'optimization_sync_lambda_trigger'}
            # trace_id=self.insert_dict(postgres_conn,migrations_history_table,hist_insert_data,True,'trace_id')
            # migration_table='migrations_2'
            logging.info(f"migrations table {migration_table}")
            migration_details_dict = self.get_migration_details(
                job_name, postgres_conn, migration_table
            )

            table_flag = migration_details_dict["table_flag"]
            logging.info(f"!!!!!!!!!!!!!!!!!!! Table Flag is {table_flag}")
            to_hostname = os.getenv("PSQL_DB_HOST")
            to_port = os.getenv("PSQL_DB_PORT")
            to_db_name = migration_details_dict["to_database"]
            to_user = os.getenv("PSQL_DB_USER")
            to_password = os.getenv("PSQL_DB_PASSWORD")
            to_db_type = os.getenv("PSQL_DB_TYPE")
            to_table = migration_details_dict["to_table"]
            from_query = migration_details_dict["from_query"]
            # logging.info(from_query)
            mapping_details_dict = self.get_mapping_details(postgres_conn,transfer_name)
            logging.info(f"mapping_details_dict is {mapping_details_dict}")
            columns_setting = mapping_details_dict["col_mapping_10_to_20"][
                "optimizationsetting"
            ].items()

            db_config = self.get_db_config(migration_details_dict)
            from_host = db_config["hostname"]
            from_port = db_config["port"]
            from_user = db_config["user"]
            from_pwd = db_config["password"]
            from_db_type = db_config["from_db_type"]
            from_database = migration_details_dict["from_database"]
            from_driver = os.getenv("MSSQL_DB_DRIVER")
            from_connection = self.create_connection(
                from_db_type,
                from_host,
                from_database,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            load_dotenv()
            basemultitenant=os.getenv('BASE_MULTI_TENANT_DB')
            from_query_rev_settings = f"""SELECT MAX(CASE WHEN ObjectId = 28 THEN co.customname END) AS revio_ftp_host,
                                        MAX(CASE WHEN ObjectId = 29 THEN co.customname END) AS revio_ftp_username,
                                        MAX(CASE WHEN ObjectId = 30 THEN co.customname END) AS revio_ftp_password,
                                        MAX(CASE WHEN ObjectId = 31 THEN co.customname END) AS rev_io_ftp_path,
                                        MAX(CASE WHEN ObjectId = 32 THEN co.customname END) AS rev_io_push_customer_charge_type
                                    FROM
                                        {basemultitenant}.dbo.CustomObject co
                                    WHERE
                                        TenantId = {tenant_id} AND ObjectId IN (28, 29, 30, 31, 32);"""

            from_query_rev_settings_ = " ".join(from_query_rev_settings.split())
            logging.info(f"from_query_rev_settings_ is {from_query_rev_settings_}")
            multi_tenant_host = os.getenv("BASE_MULTI_TENANT_HOST")
            port = os.getenv("FROM_DB_PORT")
            user = os.getenv("FROM_DB_USER")
            password = os.getenv("FROM_DB_PASSWORD")
            db_type = os.getenv("FROM_DB_TYPE")
            db_name = os.getenv("BASE_MULTI_TENANT_DB")
            driver = os.getenv("FROM_DB_DRIVER")
            multi_tenant_conn = self.create_connection(
                db_type, multi_tenant_host, db_name, user, password, port
            )
            logging.info(f"multi tenant connn is {multi_tenant_conn}")

            result = self.execute_query(from_connection, from_query)
            logging.info(f"optimization setting result is {result}")

            result2 = self.execute_query(multi_tenant_conn, from_query_rev_settings_)
            result2_dict = result2.to_dict(orient="records")[0]
            rev_settings_dict = result2_dict
            logging.info(f"Second result is {result2_dict}")

            to_connection = self.create_connection(
                to_db_type, to_hostname, to_db_name, to_user, to_password, to_port
            )
            logging.info(f"to_connection is {to_connection}")
            self.update_optimization_setting_table(
                columns_setting, result, rev_settings_dict, to_connection
            )

            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None),'job_status_msg':'Success'}
            self.update_table(postgres_conn,migrations_history_table,update_dict,{'trace_id':trace_id})
            # self.update_optimization_setting_table(columns_setting,result,to_connection)
        except Exception as e:
            # If any error occurs, log the error and set return_flag to False
            return_flag = False
            tb = traceback.format_exc()
            msg=f"Error in optimization setting {job_name} {e} {tb}"
            update_dict={'error_msg':msg,'job_end_time':datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn,migrations_history_table,update_dict,{'trace_id':trace_id})
            logging.info(f"Error in job {job_name} -{e}")
            return return_flag
        return True
    def find_customer_id(self,d):
        results = []
        if isinstance(d, dict):
            for k, v in d.items():
                if k == 'SiteId':
                    results.append(v)
                else:
                    results.extend(self.find_customer_id(v))
        elif isinstance(d, list):
            for item in d:
                results.extend(self.find_customer_id(item))
        return results
    def fetch_bulk_change_data(self, conn, bulk_change_ids, query_json):
        try:
            logging.info(f"Starting fetch_bulk_change_data... {conn} {bulk_change_ids} {query_json}")

            cur = conn.cursor()
            logging.info(f"Database cursor created.")

            # Execute query to get iccid and msisdn
            logging.info(f"Executing query to fetch subscriber numbers for bulk_change_ids: {bulk_change_ids}")
            cur.execute(query_json['subscriber_numbers'], (tuple(bulk_change_ids),))

            # Fetch data
            rows = cur.fetchall()
            columns = [desc[0] for desc in cur.description]  # get column names

            # Create DataFrame
            df = pd.DataFrame(rows, columns=columns)

            logging.info(f"Fetched {len(df)} subscriber records. {bulk_change_ids}")

            # Convert to list of dictionaries
            subscriber_data = df.to_dict(orient='records')

            # Optional: logging.info one sample record
            if subscriber_data:
                logging.info(f"Sample subscriber record: {subscriber_data}")


            # Execute query to get change_request (bulk_change_id confirmation)
            logging.info(f"Executing query to fetch change request data... {bulk_change_ids}")
            cur.execute(query_json['change_request_data'], (tuple(bulk_change_ids),))
            row = cur.fetchone()

            if row and row[0] is not None:
                try:
                    request_data_json = json.loads(row[0])
                except json.JSONDecodeError as e:
                    logging.info(f" Error decoding JSON: {e}")
                    request_data_json = {}
            else:
                request_data_son = {}

            logging.info(f"Fetched change request record: {row}")
            logging.info(f"Change Request Data: {request_data_json} {bulk_change_ids}")

            cur.close()
            logging.info(f"Database cursor closed. {bulk_change_ids}")

            logging.info(f"fetch_bulk_change_data completed successfully. {bulk_change_ids}")
            return subscriber_data, request_data_json

        except Exception as e:
            logging.info(f"Error occurred in fetch_bulk_change_data: {e} {bulk_change_ids}")
            return [], []

    def escape_sql_value(self,val):
        if isinstance(val, str):
            # Escape single quotes by doubling them for SQL
            safe_val = val.replace("'", "''")
            return f"'{safe_val}'"
        elif val is None:
            return 'NULL'
        else:
            return str(val)

    def execute_dynamic_update(self,conn, base_query, condition_list, siteid):
        """
        Execute a dynamic MSSQL UPDATE query for given conditions.

        :param conn: pyodbc connection object
        :param base_query: UPDATE query string with placeholders
        :param condition_list: List of dicts, each containing 'iccid', 'msisdn', 'tenantid'
        :param siteid: New siteid to set
        """

        if not condition_list:
            logging.info("No condition values provided.")
            return
        logging.info(f"conditions query {condition_list}")
        logging.info(f"siteid to update {siteid}")

        # Extract values from the condition list
        iccids = [item['iccid'] for item in condition_list]
        msisdns = [item['msisdn'] for item in condition_list]
        tenantids = [item['tenantid'] for item in condition_list]

        # Dynamically build the IN clause placeholders
        msisdn_str = ', '.join(self.escape_sql_value(x) for x in msisdns)
        iccid_str = ', '.join(self.escape_sql_value(x) for x in iccids)
        tenantid_str = ', '.join(self.escape_sql_value(x) for x in tenantids)

        # Replace placeholders in the base_query
        final_query = base_query.replace('IN_ICCID', iccid_str)
        final_query = final_query.replace('IN_MSISDN', msisdn_str)
        final_query = final_query.replace('IN_TENANTID', tenantid_str)
        final_query=final_query.replace('SITEID',str(siteid[0]))
        logging.info(f"Executing Query:{final_query}")

        # Execute the query
        try:
            cursor = conn.cursor()
            cursor.execute(final_query)
            conn.commit()
            logging.info("Update successful.")
        except Exception as e:
            logging.info(f"Error occurred: {e}")
            conn.rollback()



    def bulk_change_sync_10(self,data):
        try:
            logging.info(f"######### In lambda sync job data: {data}")
            start_time = time.time()
            bulk_change_id=data.get("bulk_change_id",None)
            key_name_received = data.get("key_name", None)
            tenant_name = data.get('tenant_name',None)
            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            common_utils_db=os.getenv("COMMON_UTILS_DB_NAME")
            comm_postgres_con= self.create_connection(
                db_type, hostname,common_utils_db, user, password, port
            )
            logging.info(f"Database connections established successfully. {bulk_change_id}")
            if tenant_name == "Altaworx Test":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
            elif tenant_name == "Altaworx":
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
            else:
                try:
                    common_db_name = os.getenv("COMMON_UTILS_DB_NAME")
                    postgres_conn_common = self.create_connection(
                        db_type, hostname, common_db_name, user, password, port
                    )
                    tenant_name_query = f"select db_name from tenant where tenant_name='{tenant_name}'"
                    tenant_name_df = self.execute_query(postgres_conn_common, tenant_name_query)
                    db_name = tenant_name_df['db_name'].iloc[0].lower()
                except Exception as e:
                    logging.info(f"Error in getting tenant name from tenant_id: {e} {bulk_change_id}")
                    db_name = tenant_name
                    pass
                tenant_name_lcase = db_name
                tenant_name_ = tenant_name
            transfer_name='asgin_customer_sync_altaworx'
            mapping_table=os.getenv('BULK_CHANGE_TABLE')
            mapping_details_query = f"select * from {mapping_table} where transfer_name ='{transfer_name}' order by id asc"
            mapping_details = self.execute_query(postgres_conn, mapping_details_query)

            if mapping_details.empty or mapping_details is None:
                raise ValueError(
                    "No Mappings present for transfer"
                )  # raising error if unable to get required data from db

            mapping_details = mapping_details.to_dict(orient="records")[0]
            logging.info(f"mapping details gotten is {mapping_details} {bulk_change_id}")
            mssql_config = mapping_details.get("db_config", {})
            db_name_20 = mapping_details["db_name_20"]
            db_name_10 = mapping_details.get("db_name_10", {})
            logging.info(f"DB Name (PostgreSQL - 20): {db_name_20} {bulk_change_id}")
            logging.info(f"DB Name (MSSQL - 10): {db_name_10} {bulk_change_id}")
            psql_db_conn = self.create_connection(
                db_type, hostname, db_name_20, user, password, port
            )
            logging.info(f"PSSQL connection established.{bulk_change_id}")

            if mssql_config:
                from_host = mssql_config.get("hostname")
                from_port = mssql_config.get("port")
                ssms_db_name = db_name_10
                from_user = mssql_config.get("user")
                from_db_type = mssql_config.get("from_db_type")
                from_pwd = mssql_config.get("password")
                from_driver = os.getenv("FROM_DB_DRIVER")
            else:
                logging.info(f"no mappings present for the configurations so returning the function {bulk_change_id}")
                return True
            logging.info(f"Connecting to MSSQL source database...{bulk_change_id}")
            mssql_conn = self.create_connection(
                from_db_type,
                from_host,
                ssms_db_name,
                from_user,
                from_pwd,
                from_port,
                from_driver,
            )
            logging.info(f"MSSQL connection established.{bulk_change_id}")
            data_query_20 = mapping_details.get('20_data_query', {})
            logging.info(f"20_data_query: {data_query_20} {bulk_change_id}")
            subscriber_numbers,change_request=self.fetch_bulk_change_data(psql_db_conn,[bulk_change_id],data_query_20)
            logging.info(f"Subscriber numbers and change request gotten is {type(subscriber_numbers)} {subscriber_numbers} {change_request}")
            siteid=self.find_customer_id(change_request)
            logging.info(f"Site id is {siteid} {bulk_change_id}")
            update_query_10=mapping_details.get('10_update_query',{})
            logging.info(f"1.0 update query is {update_query_10} {bulk_change_id}")
            self.execute_dynamic_update(mssql_conn,update_query_10["update_query"],subscriber_numbers,siteid)

        except Exception as e:
            logging.info(f"Error in bulk_change_sync_10: {e} {bulk_change_id}")
    # def escape_sql_value(self,val):
    #     if isinstance(val, str):
    #         # Escape single quotes by doubling them for SQL
    #         safe_val = val.replace("'", "''")
    #         return f"'{safe_val}'"
    #     elif val is None:
    #         return 'NULL'
    #     else:
    #         return str(val)

    def find_values_by_key(self, d, key_to_find):
        results = []
        if isinstance(d, dict):
            for k, v in d.items():
                if k == key_to_find:
                    results.append(v)
                else:
                    results.extend(self.find_values_by_key(v, key_to_find))
        elif isinstance(d, list):
            for item in d:
                results.extend(self.find_values_by_key(item, key_to_find))
        return results
    
    def request_key_value_dict(self, d, keys_to_find):
        """
        Extracts values from nested dict `d` using key mapping.

        :param d: The input dictionary to search.
        :param keys_to_find: dict of {search_key: output_key}
        :return: dict of {output_key: first_matched_value or None}
        """
        results = {}
        for search_key, result_key in keys_to_find.items():
            values = self.find_values_by_key(d, search_key)
            results[result_key] = values[0] if values else None
        return results
    def generate_update_conditions_for_table(self, table_fields, values):
        """
        Generate SQL SET clauses for each table based on matching keys in the values dict.

        :param table_fields: Dict with table name as key and list of column names as values
        :param values: Dict of field: value to update
        :return: Dict of table: SET clause string
        """
        update_statements = {}

        for table, fields in table_fields.items():
            set_clauses = []
            for field in fields:
                if field in values and values[field] is not None:
                    value = values[field]
                    if isinstance(value, str):
                        escaped_value = value.replace("'", "''")  # escape single quotes
                        clause = f"{field} = '{escaped_value}'"
                    else:
                        clause = f"{field} = {value}"
                    set_clauses.append(clause)

            if set_clauses:
                update_statements[table] = "SET " + ", ".join(set_clauses)

        return update_statements

    def clean_update_condition(self,update_condition_str):
            # Remove leading/trailing spaces
            cleaned = update_condition_str.strip()
            # logging.info("cleaned",cleaned)
            # If it starts with 'SET', remove it
            if cleaned.upper().startswith("SET "):
                # logging.info("yes")
                cleaned = cleaned[4:].strip()
            return cleaned

    def execute_update_queries_to_10(self, conn, base_query, condition_list, update_condition, bulk_change_id=None):
        """
        Execute a dynamic MSSQL UPDATE query for given conditions.

        :param conn: pyodbc connection object
        :param base_query: UPDATE query string with placeholders (IN_ICCID, IN_MSISDN, IN_TENANTID, UPDATE_CONDITION)
        :param condition_list: List of dicts with 'iccid', 'msisdn', 'tenantid'
        :param update_condition: Condition value to replace UPDATE_CONDITION placeholder
        :param bulk_change_id: Optional, used for logging
        """

        if not condition_list:
            logging.info(f"{bulk_change_id} - No conditions provided. Skipping update.")
            return

        logging.info(f"{bulk_change_id} - Executing dynamic update with conditions: {condition_list}")
        logging.info(f"{bulk_change_id} - Update condition:raw {update_condition}")
        cleaned_update_condition = self.clean_update_condition(update_condition)
        logging.info(f"{bulk_change_id} - Cleaned Update condition: {update_condition}")

        try:
            # Extract unique values
            iccids = [item['iccid'] for item in condition_list if 'iccid' in item]
            msisdns = [item['msisdn'] for item in condition_list if 'msisdn' in item]
            tenantids = [item['tenantid'] for item in condition_list if 'tenantid' in item]

            # Prepare SQL-safe strings for IN clauses
            iccid_str = ', '.join(self.escape_sql_value(x) for x in iccids)
            msisdn_str = ', '.join(self.escape_sql_value(x) for x in msisdns)
            tenantid_str = ', '.join(self.escape_sql_value(x) for x in tenantids)

            # Replace placeholders in the base query
            final_query = (
                base_query
                .replace('IN_ICCID', iccid_str)
                .replace('IN_MSISDN', msisdn_str)
                .replace('IN_TENANTID', tenantid_str)
                .replace('UPDATE_CONDITION', update_condition)
            )

            logging.info(f"{bulk_change_id} - Final update query: {final_query}")

            # Execute the update
            cursor = conn.cursor()
            cursor.execute(final_query)
            conn.commit()
            logging.info(f"{bulk_change_id} - Update executed successfully.")

        except Exception as e:
            logging.info(f"{bulk_change_id} - Error executing update: {e}")
            conn.rollback()

    def build_update_msisdn_query(self,table_name, request_data):
        """
        Builds a dynamic UPDATE query for changing MSISDN values using CASE in MSSQL.

        Args:
            table_name (str): Name of the table to update.
            request_data (dict): JSON-like dict containing:
                old_msisdn (list[str]): List of old MSISDN values.
                new_msisdn (list[str]): List of new MSISDN values (same length as old_msisdn).
                effective_date (str): Date in 'DD/MM/YYYY' format.

        Returns:
            str: The constructed SQL UPDATE query.
        """
        old_list = request_data["old_msisdn"]
        new_list = request_data["new_msisdn"]

        # Build CASE statement
        case_parts = [f"WHEN msisdn = '{old}' THEN '{new}'" for old, new in zip(old_list, new_list)]
        case_sql = " ".join(case_parts)

        # Build full SQL query
        query = f"""
        UPDATE {table_name}
        SET msisdn = CASE {case_sql} END

        WHERE msisdn IN ({", ".join(f"'{old}'" for old in old_list)});
        """

        return query.strip()
    def update_iccid_imei_case(self,table_name, records):
        """
        Build dynamic CASE-based UPDATE query from subscriber_number, IMEI, and ICCID in change_request JSON.
        """
        case_imei = []
        case_iccid = []
        msisdn_list = []

        for record in records:
            msisdn = record.get("subscriber_number")
            change_request_str = record.get("change_request")

            # Parse JSON string
            try:
                change_request_data = json.loads(change_request_str)
            except json.JSONDecodeError:
                raise ValueError(f"Invalid JSON in change_request for subscriber_number {msisdn}")

            # Extract values
            imei = None
            iccid = None
            for sc in change_request_data.get("Request", {}).get("serviceCharacteristic", []):
                if sc.get("name") == "IMEI":
                    imei = sc.get("value")
                elif sc.get("name") == "sim":
                    iccid = sc.get("value")

            if not imei or not iccid:
                raise ValueError(f"Missing IMEI or ICCID in change_request for subscriber_number {msisdn}")

            # Build CASE parts
            case_imei.append(f"WHEN msisdn = '{msisdn}' THEN '{imei}'")
            case_iccid.append(f"WHEN msisdn = '{msisdn}' THEN '{iccid}'")
            msisdn_list.append(f"'{msisdn}'")

        # Join CASE statements
        case_imei_sql = " ".join(case_imei)
        case_iccid_sql = " ".join(case_iccid)
        msisdn_in_clause = ", ".join(msisdn_list)

        # Construct final query
        update_query = f"""
        UPDATE {table_name}
        SET imei = CASE {case_imei_sql} END,
            iccid = CASE {case_iccid_sql} END
        WHERE msisdn IN ({msisdn_in_clause});
        """
        return update_query.strip()
    def carrier_rate_plan(self,d):
        results = []
        if isinstance(d, dict):
            for k, v in d.items():
                if k == 'CarrierRatePlan':
                    results.append(v)
                else:
                    results.extend(self.carrier_rate_plan(v))
        elif isinstance(d, list):
            for item in d:
                results.extend(self.carrier_rate_plan(item))
        return results
    def verizon_inventory_flag(self, d):
        if isinstance(d, dict):
            for k, v in d.items():
                if k == "UpdateStatus" and v == "inventory":
                    return True
                if self.verizon_inventory_flag(v):
                    return True
        elif isinstance(d, list):
            for item in d:
                if self.verizon_inventory_flag(item):
                    return True
        return False
    def bulk_change_sync_10_updated(self, data):
        try:
            logging.info(f"In bulk_change_sync_10_updated - received data: {data}")
            start_time = time.time()

            bulk_change_id = data.get("bulk_change_id")
            key_name_received = data.get("key_name")
            tenant_name = data.get("tenant_name")

            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")

            # Primary PostgreSQL connection
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)

            # Common utils connection
            common_utils_db = os.getenv("COMMON_UTILS_DB_NAME")
            comm_postgres_con = self.create_connection(db_type, hostname, common_utils_db, user, password, port)
            logging.info(f"{bulk_change_id} - Database connections established successfully.")

            # Resolve sub-tenant/parent tenant name
            if tenant_name:
                tenant_name = self.function_to_check_sub_tenant_or_parent_name(comm_postgres_con, tenant_name)
            logging.info(f"{bulk_change_id} - Final tenant name after resolving subtenant: {tenant_name}")

            if tenant_name in ["Altaworx", "Altaworx Test"]:
                tenant_name_ = "Altaworx"
                tenant_name_lcase = "altaworx"
                db_name = "altaworx_central_beta"
                tenant_id = 1
                try:
                    tenant_query = f"SELECT db_config FROM tenant WHERE tenant_name = '{tenant_name_}'"
                    tenant_df = self.execute_query(comm_postgres_con, tenant_query)
                    db_config=tenant_df['db_config'][0]
                    if isinstance(db_config, str):
                        db_config = json.loads(db_config)
                except Exception as e:
                    print(f"{bulk_change_id} - Error getting db_name for tenant: {e}")
            else:
                try:
                    tenant_query = f"SELECT id, db_name,db_config FROM tenant WHERE tenant_name = '{tenant_name}'"
                    tenant_df = self.execute_query(comm_postgres_con, tenant_query)
                    db_name = tenant_df['db_name'].iloc[0].lower()
                    tenant_id = tenant_df['id'].iloc[0]
                    db_config=tenant_df['db_config'][0]
                    if isinstance(db_config, str):
                        db_config = json.loads(db_config)
                except Exception as e:
                    logging.info(f"{bulk_change_id} - Error getting db_name for tenant: {e}")
                    db_name = tenant_name
                tenant_name_ = tenant_name
                tenant_name_lcase = db_name

            # Reload config and fetch Telegence provider IDs
            tenant_hostname=db_config['hostname']
            logging.info(f"{bulk_change_id} Tenant hostname is {tenant_hostname}")
            json_data = self.load_json()
            telegence_ids = self.get_provider_ids(json_data, tenant_name_, ["Telegence"])

            # Fetch service provider ID
            service_provider_query = f"""
                    SELECT 
                        smbc.service_provider_id,
                        i.portal_type_id
                    FROM sim_management_bulk_change smbc
                    JOIN serviceprovider sp 
                        ON sp.id = smbc.service_provider_id
                    JOIN integration i 
                        ON i.id = sp.integration_id
                    WHERE smbc.id = {bulk_change_id}
                """
            psql_db_connection = self.create_connection(db_type, tenant_hostname, db_name, user, password, port)
            service_provider_id_df = self.execute_query(psql_db_connection, service_provider_query)
            service_provider_id = service_provider_id_df.iloc[0]['service_provider_id']
            portal_type_id=service_provider_id_df.iloc[0]['portal_type_id']
            logging.info(f"{bulk_change_id} - Service provider ID: {service_provider_id} {portal_type_id}")

            # Determine transfer name
            mobility_flag = False
            if tenant_name.lower() in ('altaworx_central','altaworx') and portal_type_id == 2:
                transfer_name='all_bulk_changes_sync_altaworx'
                mobility_flag = True
            elif tenant_name.lower() in ('altaworx_central','altaworx') and portal_type_id==0:
                transfer_name='all_bulk_changes_sync_device_altaworx'
            elif tenant_name.lower() == 'spectrotel' and portal_type_id==2:
                transfer_name='all_bulk_changes_sync_spectrotel'
                mobility_flag = True
            elif tenant_name.lower() == 'spectrotel' and portal_type_id==0:
                transfer_name='all_bulk_changes_sync_device_spectrotel'
            # elif tenant_name in ('altaworx_go_tech','Altaworx - Go Tech'):
            #     transfer_name='all_bulk_changes_sync_altaworx_go_tech'
            elif tenant_name in ('altaworx_go_tech','Altaworx - Go Tech') and portal_type_id==0:
                transfer_name='all_bulk_changes_sync_device_altaworx_go_tech_beta'
            elif tenant_name in ('altaworx_go_tech','Altaworx - Go Tech') and portal_type_id==2:
                transfer_name='all_bulk_changes_sync_altaworx_go_tech_beta'
                mobility_flag = True
            else:
                logging.info("Tenant not found in save_data_20_from_10")
                raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")


            # Get mapping details
            mapping_table = os.getenv('BULK_CHANGE_TABLE')
            mapping_query = f"SELECT * FROM {mapping_table} WHERE transfer_name = '{transfer_name}' ORDER BY id ASC"
            mapping_details_df = self.execute_query(postgres_conn, mapping_query)

            if mapping_details_df.empty:
                raise ValueError(f"{bulk_change_id} - No mappings present for transfer: {transfer_name}")

            mapping_details = mapping_details_df.to_dict(orient="records")[0]
            logging.info(f"{bulk_change_id} - Mapping details: {mapping_details}")

            mssql_config = mapping_details.get("db_config", {})
            db_name_20 = mapping_details["db_name_20"]
            db_name_10 = mapping_details.get("db_name_10")
            logging.info(f"{bulk_change_id} - PostgreSQL DB (20): {db_name_20}")
            logging.info(f"{bulk_change_id} - MSSQL DB (10): {db_name_10}")
            pssq_db_config=mapping_details.get("postgres_config", {})

            logging.info(f"{bulk_change_id} - MSSQL config: {mssql_config}")
            logging.info(f"{bulk_change_id} - PostgreSQL config: {pssq_db_config}")
            logging.info(f"{bulk_change_id} - PostgreSQL DB (20): {db_name_20}")
            logging.info(f"{bulk_change_id} - MSSQL DB (10): {db_name_10}")
            pssql_hostname = pssq_db_config.get("hostname")
            logging.info(f"{bulk_change_id} - PostgreSQL hostname: {pssql_hostname}")

            # Create PostgreSQL connection for 20
            psql_db_conn = self.create_connection(db_type, pssql_hostname, db_name_20, user, password, port)
            logging.info(f"{bulk_change_id} - PostgreSQL connection for DB 20 established.")

            if not mssql_config:
                logging.info(f"{bulk_change_id} - No MSSQL configuration found. Exiting function.")
                return True

            # Connect to MSSQL
            mssql_conn = self.create_connection(
                mssql_config.get("from_db_type"),
                mssql_config.get("hostname"),
                db_name_10,
                mssql_config.get("user"),
                mssql_config.get("password"),
                mssql_config.get("port"),
                os.getenv("FROM_DB_DRIVER"),
            )
            logging.info(f"{bulk_change_id} - MSSQL connection established.")

            # Fetch 20 data query and 10 update query
            data_query_20 = mapping_details.get('20_data_query', {})
            update_queries_10 = mapping_details.get('10_update_query', {})
            logging.info(f"{bulk_change_id} - 20 data query: {data_query_20}")
            logging.info(f"{bulk_change_id} - 10 update queries: {update_queries_10}")

            # Get change request type
            change_request_query = f"SELECT change_request_type FROM sim_management_bulk_change WHERE id = {bulk_change_id}"
            change_request_df = self.execute_query(psql_db_conn, change_request_query)

            if not change_request_df.empty:
                received_request = change_request_df.iloc[0]['change_request_type']
                logging.info(f"{bulk_change_id} - Received change request type: {received_request}")
            else:
                logging.info(f"{bulk_change_id} - No change request found for given bulk_change_id.")
                return False

            # Fetch change request mappings and request data
            bulk_changes_request = mapping_details.get('bulk_change_request_type', {})
            tables_dict = mapping_details.get('table_col_mappings', {})
            request_values_to_find = bulk_changes_request[received_request]

            logging.info(f"{bulk_change_id} - Mapped request keys: {request_values_to_find}")

            subscriber_numbers, change_request_data = self.fetch_bulk_change_data(psql_db_conn, [bulk_change_id], data_query_20)
            logging.info(f"{bulk_change_id} - Change request data: {change_request_data}")
            if received_request == 'Change Phone Number':
                try:
                    logging.info(f"Received request {received_request} {bulk_change_id}")

                    # Build the dynamic update query
                    update_query_formed = self.build_update_msisdn_query(
                        'mobilitydevice',
                        change_request_data
                    )

                    logging.info(f"Finally update query to update change phone number: {update_query_formed} {bulk_change_id}")

                    # Execute the query
                    cursor = mssql_conn.cursor()
                    start_time = time.time()
                    cursor.execute(update_query_formed)
                    mssql_conn.commit()
                    end_time = time.time()  # End timer
                    execution_time = end_time - start_time
                    logging.info(f"Update successful. Time taken: {execution_time:.4f} seconds {bulk_change_id}")
                    return True

                except Exception as e:
                    logging.info(f"Error while updating Change Phone Number: {e} {bulk_change_id}")
                    mssql_conn.rollback()
                    return False
            elif received_request=='Change ICCID/IMEI':
                try:
                    logging.info(f"received request {received_request} {bulk_change_id}")
                    imei_iccid_query=f"select subscriber_number,change_request from sim_management_bulk_change_request where bulk_change_id={bulk_change_id}"
                    imei_iccid_df=self.execute_query(psql_db_conn,imei_iccid_query)
                    if not imei_iccid_df.empty:
                        logging.info(f"df received is {imei_iccid_df} {bulk_change_id}")
                        imei_iccid_list = imei_iccid_df.to_dict(orient='records')
                        logging.info(f" data frame received is {imei_iccid_list}")
                        update_query_imei_msisdn=self.update_iccid_imei_case('mobilitydevice',imei_iccid_list)
                        logging.info(f"Change ICCID/IMEI query formed is {update_query_imei_msisdn}")

                        cursor = mssql_conn.cursor()
                        start_time = time.time()
                        #cursor.execute(update_query_imei_msisdn)
                        mssql_conn.commit()
                        end_time = time.time()  # End timer
                        execution_time = end_time - start_time
                        logging.info(f"Update successful. Time taken: {execution_time:.4f} seconds {bulk_change_id}")
                        return True
                except Exception as e:
                    logging.info(f"Error while updating Change Phone Number: {e} {bulk_change_id}")
                    mssql_conn.rollback()
                    return False
            elif received_request=='Activate New Service':
                logging.info(f" Change Carrier Rate Plan received request {received_request} {bulk_change_id}")
                data_opt = {
                            "key_name": "mobility_from_20_rev_sync",
                            "tenant_name":tenant_name
                    }
                self.lambda_sync_jobs_(data_opt)
                logging.info(f" reverse sync is called to sync data to 1.0 {received_request} {bulk_change_id}")
                return True
            elif received_request=='Update Device Status':
                logging.info(f"[INFO] Received request: {received_request} | Bulk Change ID: {bulk_change_id}")
                logging.info("[INFO] Checking for Verizon inventory flag...")

                verizon_inventory_flag = self.verizon_inventory_flag(change_request_data)
                logging.info(f"[DEBUG] Verizon inventory flag check result: {verizon_inventory_flag}")

                if verizon_inventory_flag:
                    logging.info("[INFO] Inventory flag detected. Preparing data for lambda sync jobs...")
                    
                    data_opt = {
                        "key_name": "m2m_from_20_rev_sync",
                        "tenant_name": tenant_name
                    }
                    
                    logging.info(f"[DEBUG] Data being sent to lambda_sync_jobs_: {data_opt}")
                    self.lambda_sync_jobs_(data_opt)
                    
                    logging.info("[SUCCESS] Lambda sync job triggered successfully for inventory flag.")
                    return True
                else:
                    logging.info("[WARN] Inventory flag not found. Skipping lambda sync job.")
            elif received_request=='Assign Customer':
                logging.info(f" Assign Customer received request {received_request} {bulk_change_id}")
                DeviceId = change_request_data.get('DeviceId', None)
                if mobility_flag:
                    customer_id_query_table = "mobility_device_tenant"
                    device_column = "mobility_device_id"
                else:
                    customer_id_query_table = "device_tenant"
                    device_column = "device_id"
                customer_id_query = f"""
                    SELECT customer_id, account_number
                    FROM {customer_id_query_table}
                    WHERE {device_column} = {DeviceId}
                    and tenant_id = {tenant_id}
                    ORDER BY id DESC
                    LIMIT 1
                """
                customer_id_df = self.execute_query(psql_db_conn, customer_id_query)
                if not customer_id_df.empty:
                    customer_id = int(customer_id_df.iloc[0]['customer_id'])
                    account_number = int(customer_id_df.iloc[0]['account_number'])
                    logging.info(f"Gotten customer site id {customer_id} {account_number} {bulk_change_id}")
                    change_request_data['SiteId'] = customer_id
                    change_request_data['AccountNumber'] = account_number
                else:
                    logging.info(f"No matching customer id found. {bulk_change_id}")
                logging.info(f"change request data is {change_request_data}")
            elif received_request=='Change Carrier Rate Plan':
                logging.info(f" Change Carrier Rate Plan received request {received_request} {bulk_change_id}")
                carrier_rate_plan=self.carrier_rate_plan(change_request_data)
                logging.info(f"Gotten Carrier rate plan {carrier_rate_plan} {bulk_change_id}")
                rate_plan_code = carrier_rate_plan[0].replace("'", "''")
                carrier_rate_plan_id_query = f"""
                    SELECT id
                    FROM carrier_rate_plan
                    WHERE rate_plan_code = '{rate_plan_code}'
                    ORDER BY id DESC
                    LIMIT 1
                """
                carrier_rate_plan_id_df = self.execute_query(psql_db_conn, carrier_rate_plan_id_query)

                if not carrier_rate_plan_id_df.empty:
                    carrier_rate_plan_id = int(carrier_rate_plan_id_df.iloc[0]['id'])
                    logging.info(f"Carrier rate plan id gotten is {carrier_rate_plan_id} {bulk_change_id}")
                    change_request_data['CarrierRatePlanId']=carrier_rate_plan_id
                    logging.info(f"change request data is {change_request_data}")

                else:
                    logging.info(f"No matching carrier rate plan found. {bulk_change_id}")


            final_update_dict = self.request_key_value_dict(change_request_data, request_values_to_find)
            logging.info(f"{bulk_change_id} - Final update dict: {final_update_dict}")

            update_statements = self.generate_update_conditions_for_table(tables_dict, final_update_dict)
            logging.info(f"{bulk_change_id} - Update statements generated: {update_statements}")


            for table_name_10, update_statement in update_statements.items():
                if table_name_10 in ["Device_Tenant", "MobilityDevice_Tenant"] and received_request == 'Change Customer Rate Plan':
                    logging.info(f"{bulk_change_id} - checking update for table {table_name_10} due to request type {received_request}")
                    parts = update_statement.replace("SET", "").split(",")
                    cleaned_parts = []
                    has_customer_rate_pool = False
                    for part in parts:
                        column, value = map(str.strip, part.split("="))

                        if column == "CustomerRatePoolId":
                            has_customer_rate_pool = True

                            if int(value) < 0:
                                logging.info(
                                    f"{bulk_change_id} - removing CustomerRatePoolId "
                                    f"due to negative value ({value})"
                                )
                                continue  # remove negative value

                        cleaned_parts.append(f"{column} = {value}")
                    # If CustomerRatePoolId was not present, add it as NULL
                    if not has_customer_rate_pool:
                        logging.info(
                            f"{bulk_change_id} - adding CustomerRatePoolId = NULL "
                            f"in {table_name_10}"
                        )
                        cleaned_parts.append("CustomerRatePoolId = NULL")
                    update_statements[table_name_10] = "SET " + ", ".join(cleaned_parts)
                else:
                    update_statements[table_name_10] = update_statement
                
                logging.info(f" {bulk_change_id} Update statements are {update_statements}")
                update_query = update_queries_10.get(table_name_10)
                logging.info(f"{bulk_change_id} - Executing update on table {table_name_10} with query: {update_query}  {update_queries_10}")
                self.execute_update_queries_to_10(mssql_conn, update_query, subscriber_numbers, update_statements[table_name_10], bulk_change_id)


        except Exception as e:
            logging.info(f"{bulk_change_id} - Error in bulk_change_sync_10_updated: {str(e)}")
    def optimization_to_stop_manually(self, data):
        """
        Stops an active optimization process manually.
        Updates optimization_session in both 2.0 (PostgreSQL) and 1.0 (MSSQL).
        """
        session_id = data.get("session_id")  # Extract early for logs

        try:
            logging.info(f"[{session_id}] Starting manual optimization stop process.")
            logging.info(f"[{session_id}] Received payload: {data}")

            tenant_name = data.get("tenant_name")
            username = data.get("username")
            logging.info(f"[{session_id}] Extracted tenant_name='{tenant_name}', username='{username}'")

            # Load environment variables
            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            common_db_name = os.getenv("COMMON_UTILS_DB_NAME")

            # Connect to common_utils database
            try:
                common_utils_conn = self.create_connection(
                    db_type, hostname, common_db_name, user, password, port
                )
                logging.info(f"[{session_id}] Connected to common_utils database '{common_db_name}'.")
            except Exception as e:
                logging.error(f"[{session_id}] Failed to connect to common_utils DB: {e}")
                return

            # Tenant DB lookup
            try:
                tenant_query = (
                    f"SELECT db_name, db_config FROM tenant "
                    f"WHERE tenant_name = '{tenant_name}' AND is_active = true AND is_deleted = false"
                )
                tenant_result = self.execute_query(common_utils_conn, tenant_query)
                if tenant_result is None or tenant_result.empty or "db_name" not in tenant_result.columns:
                    raise ValueError(f"Tenant '{tenant_name}' not found or inactive.")
            except Exception as e:
                logging.error(f"[{session_id}] Tenant lookup failed: {e}")
                return

            tenant_db_name = tenant_result["db_name"][0]
            db_config = tenant_result["db_config"][0]
            if isinstance(db_config, str):
                db_config = json.loads(db_config)

            tenant_hostname = db_config["hostname"]
            if tenant_name=='Altaworx' or tenant_name=="Altaworx Test":
                tenant_db_name='altaworx_central_beta'
                tenant_mig_name='altaworx_beta'
            else:
                tenant_mig_name=tenant_db_name

            # Connect to tenant DB
            try:
                postgres_conn_altaworx = self.create_connection(
                    db_type, tenant_hostname, tenant_db_name, user, password, port
                )
                logging.info(f"[{session_id}] Connected to tenant DB successfully.")
            except Exception as e:
                logging.error(f"[{session_id}] Failed to connect to tenant DB: {e}")
                return

            # Update optimization_session in PostgreSQL
            try:
                update_dict_20 = {
                    "is_active": False,
                    "is_deleted": True,
                    "stopped_by": username,
                    "progress_msg": "The optimization process has been stopped manually"
                }
                self.update_table(
                    postgres_conn_altaworx,
                    "optimization_session",
                    update_dict_20,
                    {"session_id": session_id},
                )
                logging.info(f"[{session_id}] PostgreSQL optimization_session table updated successfully.")
            except Exception as e:
                logging.error(f"[{session_id}] Failed to update PostgreSQL optimization_session: {e}")

            # Connect to migration DB for MSSQL details
            try:
                migration_db_name = os.getenv("PSQL_DB_NAME")
                postgres_conn = self.create_connection(
                    db_type, hostname, migration_db_name, user, password, port
                )
            except Exception as e:
                logging.error(f"[{session_id}] Failed to connect to migration DB: {e}")
                return

            # Get MSSQL config
            try:
                migrations_table = os.getenv("MIGRATION_TABLE")
                db_config_query = (
                    f"SELECT from_db_config FROM {migrations_table} "
                    f"WHERE migration_name='optimization_session_{tenant_mig_name.lower()}'"
                )
                logging.info(f"[{session_id}] Fetching MSSQL config for query is {db_config_query}.")
                db_config_details = self.execute_query(postgres_conn, db_config_query)
                if db_config_details is None or db_config_details.empty:
                    logging.warning(f"[{session_id}] No migration config found for {tenant_mig_name}.")
                    return

                db_config_details = db_config_details["from_db_config"].tolist()[0]
                if isinstance(db_config_details, str):
                    db_config_details = json.loads(db_config_details)

                from_host = db_config_details["hostname"]
                from_port = db_config_details["port"]
                from_user = db_config_details["user"]
                from_pwd = db_config_details["password"]
                from_db_type = os.getenv("MSSQL_DB_TYPE")
                from_database = os.getenv("MSSQL_DB_NAME")
                from_driver = os.getenv("MSSQL_DB_DRIVER")
            except Exception as e:
                logging.error(f"[{session_id}] Failed to fetch MSSQL config: {e}")
                return

            # Connect to MSSQL and update
            try:
                from_connection = self.create_connection(
                    from_db_type, from_host, from_database, from_user, from_pwd, from_port, from_driver
                )
                cursor = from_connection.cursor()
                mssql_update_query = (
                    f"UPDATE OptimizationSession "
                    f"SET IsActive = 0, IsDeleted = 1 "
                    f"WHERE SessionId = '{session_id}'"
                )
                cursor.execute(mssql_update_query)
                from_connection.commit()
                cursor.close()
                logging.info(f"[{session_id}] MSSQL optimization_session record updated successfully.")
            except Exception as e:
                logging.error(f"[{session_id}] Failed to update MSSQL optimization_session: {e}")

            logging.info(f"[{session_id}] Manual stop process completed.")
            return True

        except Exception as e:
            logging.error(f"[{session_id}] Unexpected error: {e}")
            return False

        finally:
            try:
                if 'postgres_conn_altaworx' in locals(): postgres_conn_altaworx.close()
                if 'common_utils_conn' in locals(): common_utils_conn.close()
                if 'postgres_conn' in locals(): postgres_conn.close()
                if 'from_connection' in locals(): from_connection.close()
            except Exception as e:
                logging.warning(f"[{session_id}] Error closing connections: {e}")
    def last_id_migration_psql(
            self,
            to_connection,
            postgres_conn,
            migration_details_dict,
            migration_table,
            job_name,
            trace_id
    ):
        try:
            # --------------------------------------
            # Environment & table setup
            # --------------------------------------
            history_table = os.getenv('MIGRATIONS_HISTORY_TABLE')
            to_table = migration_details_dict.get('table_name')
            conflict_cols = migration_details_dict.get('conflict_cols')
            time_columns = migration_details_dict.get('primary_id_column')
            df_size = int(os.getenv('DF_SIZE', 5000))  # default batch size

            logging.info(f"{trace_id} {job_name} → Time column(s): {time_columns}")

            last_id = migration_details_dict.get('last_id')
            success_count = 0

            # --------------------------------------
            # Helper function to fetch last_id from DB
            # --------------------------------------
            def fetch_last_id():
                try:
                    return self.update_last_id_list(to_table, conflict_cols, to_connection)
                except Exception as e:
                    logging.info(f"{trace_id} {job_name} → Failed to fetch last_id from DB: {e}")
                    return None

            # --------------------------------------
            # Process last_id safely
            # --------------------------------------
            if last_id:
                try:
                    if last_id in ['[null]', 'null', '[]']:
                        logging.info(f"{trace_id} {job_name} → last_id is null-like, fetching from DB")
                        last_id = fetch_last_id()
                    elif isinstance(last_id, str) and last_id.startswith('{') and last_id.endswith('}'):
                        last_id = [int(last_id[1:-1])]
                        logging.info(f"{trace_id} {job_name} → Parsed curly-brace last_id: {last_id}")
                    elif isinstance(last_id, str):
                        last_id = json.loads(last_id)
                        logging.info(f"{trace_id} {job_name} → Loaded JSON last_id: {last_id}")
                    elif isinstance(last_id, int):
                        last_id = [last_id]
                        logging.info(f"{trace_id} {job_name} → Converted int last_id to list: {last_id}")
                except Exception as e:
                    logging.info(f"{trace_id} {job_name} → Error parsing last_id: {e}")
                    last_id = fetch_last_id()
            else:
                logging.info(f"{trace_id} {job_name} → last_id missing, fetching from DB")
                last_id = fetch_last_id()

            logging.info(f"{trace_id} {job_name} → Final last_id to use: {last_id}")

            # --------------------------------------
            # Fetch previous error IDs
            # --------------------------------------
            error_ids_query = f"""
                SELECT error_id_list, job_end_time
                FROM {history_table}
                WHERE job_name = '{job_name}' AND trace_id <> '{trace_id}'
                ORDER BY job_end_time DESC
                LIMIT 1
            """
            error_ids_df = self.execute_query(postgres_conn, error_ids_query)
            error_id_list = []
            last_migrated_time_prev = None
            if error_ids_df is not None and not error_ids_df.empty:
                error_id_list = error_ids_df['error_id_list'][0]
                last_migrated_time_prev = error_ids_df['job_end_time'][0]
            logging.info(f"{trace_id} {job_name} → Previous error IDs: {error_id_list}")

            # --------------------------------------
            # Fetch last successful migration time
            # --------------------------------------
            last_migrated_time_query = f"""
                SELECT job_end_time
                FROM {history_table}
                WHERE job_name='{job_name}' AND trace_id<>'{trace_id}' AND job_status_msg='SUCCESS'
                ORDER BY id DESC LIMIT 1
            """
            last_migrated_df = self.execute_query(postgres_conn, last_migrated_time_query)
            if last_migrated_df is not None and not last_migrated_df.empty:
                last_migrated_time_job = last_migrated_df['job_end_time'][0]
            else:
                last_migrated_time_job = None
                logging.info(f"{trace_id} {job_name} → No previous successful migration found.")

            last_migrated_time = last_migrated_time_job or migration_details_dict.get('last_migrated_time')
            logging.info(f"{trace_id} {job_name} → Using last migrated time: {last_migrated_time}")

            # --------------------------------------
            # Construct the from_query dynamically
            # --------------------------------------
            from_query_ = migration_details_dict.get('data_query')
            if not from_query_:
                raise ValueError(f"{trace_id} {job_name} → data_query is missing in migration_details_dict")

            from_query_ = ' '.join(from_query_.split()).rstrip(';')

            if "modified_date" in from_query_.lower() and "created_date" in from_query_.lower() and isinstance(last_id[0], str):
                time_columns_dup = copy.deepcopy(time_columns)
                time_columns_dup.append("ModifiedDate")
                last_id_dup = [last_migrated_time, last_migrated_time]
                from_query = self.get_updated_records_query(time_columns_dup, last_id_dup, None, from_query_, error_id_list)
            elif "modified_date" in from_query_.lower() and isinstance(last_id[0], int):
                where_condition_cols = ['modified_date'] + time_columns if isinstance(time_columns, list) else ['modified_date', time_columns]
                last_migrated_time_str = str(last_migrated_time)
                last_migrated_time_str = self.to_psql_timestamp(last_migrated_time_str)
                where_condition_vals = [last_migrated_time_str, last_id[0]]
                from_query = self.get_updated_records_query(where_condition_cols, where_condition_vals, None, from_query_, error_id_list)
            else:
                from_query = from_query_

            logging.info(f"{trace_id} {job_name} → Final query for migration: {from_query}")

            # --------------------------------------
            # Count and batch queries
            # --------------------------------------
            count_query = self.get_count_query(from_query)
            logging.info(f"{trace_id} {job_name} → Count query: {count_query}")

            try:
                batch_queries, total_count = self.generate_batch_queries(count_query, from_query, to_connection, df_size, time_columns)
                if not batch_queries or total_count is False:
                    error_msg = "No batch queries generated or total_count invalid"
                    logging.info(f"{trace_id} {job_name} → {error_msg}")
                    update_dict = {'error_msg': error_msg, 'job_end_time': datetime.now(timezone.utc).replace(tzinfo=None)}
                    self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
                    return False
            except Exception as e:
                tb = traceback.format_exc()
                logging.info(f"{trace_id} {job_name} → Error generating batch queries: {e}\n{tb}")
                update_dict = {'error_msg': str(e), 'job_end_time': datetime.now(timezone.utc).replace(tzinfo=None)}
                self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
                return False

            if total_count == 0:
                logging.info(f"{trace_id} {job_name} → No records found for migration")
                update_dict = {
                    'error_msg': "No records found",
                    'job_end_time': datetime.now(timezone.utc).replace(tzinfo=None),
                    'total_count': total_count,
                    'success': 0,
                    'failed': 0,
                    'job_status_msg': 'SUCCESS'
                }
                self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
                return True

            update_dict = {'total_count': total_count}
            self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
            logging.info(f"{trace_id} {job_name} → Total records to migrate: {total_count}")

            # --------------------------------------
            # Execute batch queries
            # --------------------------------------
            max_retries = 3
            for query in batch_queries:
                attempt = 1
                while attempt <= max_retries:
                    try:
                        df = self.execute_query(to_connection, query)
                        if df is not None:
                            df = df.astype(object).mask(df.isna(), None)
                            df = self.modify_uuid_cols(df)
                            logging.info(f"{trace_id} {job_name} → Batch executed, rows: {len(df)}")
                            break
                        else:
                            logging.info(f"{trace_id} {job_name} → Batch query returned None, retrying...")
                            attempt += 1
                            time.sleep(5)
                    except Exception as e:
                        logging.info(f"{trace_id} {job_name} → Error executing batch query: {e}")
                        attempt += 1
                        time.sleep(5)

                # --------------------------------------
                # Start migration for this batch
                # --------------------------------------
                success_count = self.initate_complete_migration_psql(
                    df,
                    to_connection,
                    postgres_conn,
                    migration_table,
                    conflict_cols,
                    job_name,
                    migration_details_dict,
                    to_table,
                    trace_id,
                    total_count,
                    success_count
                )
                logging.info(f"{trace_id} {job_name} → Success count so far: {success_count}")

            return success_count

        except Exception as e:
            tb = traceback.format_exc()
            logging.info(f"{trace_id} {job_name} → Unexpected error during last_id_migration_psql: {e}\n{tb}")
            update_dict = {'error_msg': str(e), 'job_end_time': datetime.now(timezone.utc).replace(tzinfo=None)}
            self.update_table(postgres_conn, history_table, update_dict, {'trace_id': trace_id})
            return False

    def insert_records_postgresql_batch_5_psql(
        self,
        postgres_connection,
        df,
        insert_table_name,
        conflict_cols,
        trace_id
    ):
        try:
            logging.info(f"[{trace_id}] [START] insert_records_postgresql_batch_5_psql")
            logging.info(f"[{trace_id}] Target table: {insert_table_name}")
            logging.info(f"[{trace_id}] Total records received: {len(df)}")

            inserted_records = 0
            failed_records = 0
            insert_flag = True
            batch_size = 5000
            failed_log = []
            last_id_value = None
            error_msg = "SUCCESS"
            error_id_list = []

            num_batches = math.ceil(len(df) / batch_size)
            logging.info(f"[{trace_id}] Batch size: {batch_size}")
            logging.info(f"[{trace_id}] Total batches to process: {num_batches}")

            # Column handling
            # columns = ', '.join(df.columns)
            safe_columns = [self.pg_safe_col(col) for col in df.columns]
            columns = ', '.join(safe_columns)

            conflict_cols = json.loads(conflict_cols)
            time_column_snake_case = conflict_cols

            logging.info(f"[{trace_id}] Conflict columns: {conflict_cols}")

            # update_clause = ', '.join([
            #     f"{col} = EXCLUDED.{col}"
            #     for col in df.columns
            #     if col not in time_column_snake_case
            # ])
            update_clause = ', '.join(
                f"{self.pg_safe_col(col)} = EXCLUDED.{self.pg_safe_col(col)}"
                for col in df.columns
                if col not in time_column_snake_case
            )

            conflict_cols_str = ", ".join(conflict_cols)

            total_start_time = time.time()

            # ----------------------------------------------------------
            # Batch insertion logic
            # ----------------------------------------------------------
            def insert_block_operation():
                nonlocal inserted_records, failed_records, last_id_value, insert_flag, error_msg, error_id_list

                for batch_index in range(num_batches):
                    start_index = batch_index * batch_size
                    end_index = min((batch_index + 1) * batch_size, len(df))
                    batch_df = df.iloc[start_index:end_index]

                    # rows = [tuple(row) for row in batch_df.to_numpy()]

                    rows = [
                        tuple(self.convert_dict_to_json(v) for v in row)
                        for row in batch_df.to_numpy()
                    ]

                    insert_query = f"""
                        INSERT INTO {insert_table_name} ({columns})
                        VALUES %s
                        ON CONFLICT ({conflict_cols_str}) DO UPDATE
                        SET {update_clause}
                    """

                    logging.info(
                        f"[{trace_id}] Processing batch "
                        f"{batch_index + 1}/{num_batches} | "
                        f"Rows: {start_index} - {end_index}"
                    )

                    batch_start_time = time.time()

                    try:
                        with postgres_connection.cursor() as cur:
                            execute_values(cur, insert_query, rows)

                        postgres_connection.commit()
                        inserted_records += len(rows)

                        last_id_value = [
                            rows[-1][batch_df.columns.get_loc(col)]
                            for col in time_column_snake_case
                        ]

                        logging.info(
                            f"[{trace_id}] Batch {batch_index + 1} SUCCESS | "
                            f"Inserted: {len(rows)} | "
                            f"Total Inserted: {inserted_records}"
                        )

                    except psycopg2.Error as batch_error:
                        logging.info(
                            f"[{trace_id}] Batch {batch_index + 1} FAILED | "
                            f"Error: {batch_error}"
                        )
                        postgres_connection.rollback()

                        # Row-level fallback
                        for row_index, row in batch_df.iterrows():
                            try:
                                row_tuple = tuple(row.to_numpy())

                                with postgres_connection.cursor() as cur:
                                    cur.execute(insert_query, (row_tuple,))

                                postgres_connection.commit()
                                inserted_records += 1
                                last_id_value = [row[col] for col in time_column_snake_case]

                            except psycopg2.Error as row_error:
                                postgres_connection.rollback()
                                failed_records += 1
                                insert_flag = False
                                error_msg = str(row_error)

                                error_id_list.append(row["id"])

                                failed_log.append({
                                    "batch": batch_index + 1,
                                    "row_index": row_index + start_index,
                                    "error": str(row_error),
                                    "failed_id": row["id"]
                                })

                                logging.info(
                                    f"[{trace_id}] Row insert FAILED | "
                                    f"Batch: {batch_index + 1} | "
                                    f"Row ID: {row['id']} | "
                                    f"Error: {row_error}"
                                )

                    batch_end_time = time.time()
                    logging.info(
                        f"[{trace_id}] Batch {batch_index + 1} completed in "
                        f"{batch_end_time - batch_start_time:.2f}s"
                    )

            try:
                insert_block_operation()
            except Exception as e:
                last_id_value = None
                error_msg = str(e)
                logging.info(f"[{trace_id}] Fatal error during insert operation: {e}")

            total_end_time = time.time()
            logging.info(
                f"[{trace_id}] Insert completed | "
                f"Total Time: {total_end_time - total_start_time:.2f}s | "
                f"Inserted: {inserted_records} | "
                f"Failed: {failed_records}"
            )

            if failed_records > 0:
                last_id_value = None

        except Exception as e:
            tb = traceback.format_exc()
            error_msg = f"Error in inserting records: {e}"
            logging.info(f"[{trace_id}] CRITICAL ERROR: {error_msg}\n{tb}")
            return False, 0, 0, None, error_msg, error_id_list

        logging.info(f"[{trace_id}] [END] insert_records_postgresql_batch_5_psql")
        return insert_flag, inserted_records, failed_records, last_id_value, error_msg, error_id_list

    def get_updated_records_query_psql(self, columns, last_id, full_from_table, query, error_id_list):
        """
        Generate a SQL query to fetch updated records based on dynamic conditions.

        Args:
            columns (list): Column names for filtering.
            last_id (list): Values corresponding to the columns.
            full_from_table (str): Fully qualified table name, if provided.
            query (str): Base SQL query to enhance.
            error_id_list (list): List of error IDs to include in query.

        Returns:
            str: Dynamically constructed SQL query.
            None: If error occurs.
        """
        try:
            if not query and not full_from_table:
                raise ValueError("Either 'query' or 'full_from_table' must be provided.")

            # Parse FROM clause to find table aliases
            from_clause_start = self.get_from_clause_index(query) if query else -1
            table_alias = None
            if from_clause_start != -1:
                from_clause = query[from_clause_start + 4:].strip()
                from_clause = from_clause.split(" WHERE")[0].split(" JOIN")[0].split(",")[0].strip()
                from_words = from_clause.split()
                if len(from_words) > 1 and self.recognize_format(from_words[0]):
                    table_alias = from_words[1]

            # Build conditions
            where_conditions = []
            modified_condition = None
            deleted_condition = None

            for col, val in zip(columns, last_id):
                col_lower = col.lower()
                col_name = f"{table_alias}.{col}" if table_alias else col

                if col_lower == "id":
                    where_conditions.append(f"{col_name} > {val}" if isinstance(val, (int, float)) else f"{col_name} > '{val}'")
                elif col_lower == "modifieddate":
                    modified_condition = f"{col_name} > '{val}'" if isinstance(val, str) else f"{col_name} > {val}"
                elif col_lower == "deleteddate":
                    deleted_condition = f"{col_name} > '{val}'" if isinstance(val, str) else f"{col_name} > {val}"
                else:
                    where_conditions.append(f"{col_name} > '{val}'" if isinstance(val, str) else f"{col_name} > {val}")

            # Include error_id_list
            if error_id_list:
                error_col = f"{table_alias}.id" if table_alias else "id"
                ids_str = ', '.join([str(i) for i in error_id_list])
                where_conditions.append(f"{error_col} IN ({ids_str})")

            # Combine conditions
            all_conditions = []
            if where_conditions:
                all_conditions.append("(" + " OR ".join(where_conditions) + ")")
            if modified_condition:
                all_conditions.append(modified_condition)
            if deleted_condition:
                all_conditions.append(deleted_condition)

            where_clause = ""
            if all_conditions:
                where_clause = " WHERE " + " OR ".join(all_conditions)

            # Construct final query
            if full_from_table:
                final_query = f"SELECT * FROM {full_from_table}{where_clause} ORDER BY id ASC"
            else:
                query = query.rstrip(';')
                if "ORDER BY" in query.upper():
                    parts = query.rsplit("ORDER BY", 1)
                    final_query = parts[0] + where_clause + " ORDER BY" + parts[1]
                else:
                    final_query = query + where_clause

            return final_query

        except Exception as e:
            logging.info(f"[ERROR] {e} - Failed to generate updated records query")
            return None

    def initate_complete_migration_psql(
        self,
        df,
        to_connection,
        postgres_conn,
        migration_table,
        conflict_cols,
        job_name,
        migration_details_dict,
        to_table,
        trace_id,
        total_count,
        success_count=0,
    ):
        """
        Inserts a batch of records into PostgreSQL and updates migration state.
        """
        history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")

        # Defaults to avoid UnboundLocalError in except block
        error_id_list = []
        error_msg = None
        failures = 0
        job_status_msg = "FAILED"

        try:
            logging.info(f"[{trace_id}] Starting batch migration for table: {to_table}")
            logging.info(f"[{trace_id}] Conflict columns: {conflict_cols}")

            # --------------------------------------------------
            # Insert records
            # --------------------------------------------------
            (
                insert_records,
                success,
                failures,
                last_id_value,
                error_msg,
                error_id_list,
            ) = self.insert_records_postgresql_batch_5_psql(
                to_connection, df, to_table, conflict_cols, trace_id
            )

            success_count += success

            logging.info(
                f"[{trace_id}] Batch result → "
                f"Inserted: {success}, Failed: {failures}, "
                f"Total Success: {success_count}, Last ID: {last_id_value}"
            )

            # --------------------------------------------------
            # Determine job status
            # --------------------------------------------------
            if total_count and (success_count + failures == total_count):
                job_status_msg = "SUCCESS"

            # --------------------------------------------------
            # Update last_id if missing
            # --------------------------------------------------
            if last_id_value is None:
                logging.info(f"[{trace_id}] Last ID missing, recalculating...")
                last_id_value = self.update_last_id_list(
                    to_table, conflict_cols, to_connection
                )

            # --------------------------------------------------
            # Update migration tracking table
            # --------------------------------------------------
            migration_update_payload = self.update_migration_details_dict(
                insert_records,
                success,
                failures,
                last_id_value,
                error_msg,
            )

            logging.info(
                f"[{trace_id}] Updating migration table → "
                f"Status: {migration_update_payload.get('status')}, "
                f"Last ID: {migration_update_payload.get('last_id')}"
            )

            self.update_table(
                postgres_conn,
                migration_table,
                migration_update_payload,
                {"migration_name": job_name},
            )

            # --------------------------------------------------
            # Execute post-migration update queries (if any)
            # --------------------------------------------------
            if migration_details_dict.get("is_update"):
                queries = migration_details_dict.get("update_queries", [])
                if queries:
                    logging.info(f"[{trace_id}] Executing post-migration update queries")
                    self.execute_update_queries(queries, to_connection)

            # --------------------------------------------------
            # Update history table
            # --------------------------------------------------
            history_update = {
                "error_id_list": json.dumps(error_id_list),
                "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                "error_msg": error_msg,
                "success": success_count,
                "failed": failures,
                "job_status_msg": job_status_msg,
            }

            self.update_table(
                postgres_conn,
                history_table,
                history_update,
                {"trace_id": trace_id},
            )

            logging.info(f"[{trace_id}] Batch migration completed → {job_status_msg}")
            return success_count

        except Exception as e:
            tb = traceback.format_exc()
            error_message = f"Error during migration: {e}\n{tb}"

            logging.info(f"[{trace_id}]  Migration error: {e}")

            # Safe history update on failure
            self.update_table(
                postgres_conn,
                history_table,
                {
                    "error_id_list": json.dumps(error_id_list),
                    "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    "error_msg": error_message,
                    "job_status_msg": "FAILED",
                },
                {"trace_id": trace_id},
            )

            return False

    def first_migration_psql(
        self,
        to_connection,
        from_connection,
        postgres_conn,
        migration_details_dict,
        migration_table,
        job_name,
        trace_id,
    ):
        """
        Perform the first migration process for moving data from source DB
        to target PostgreSQL database.
        """

        try:
            logging.info(f"[{trace_id}] Starting FIRST migration process")

            history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")
            from_query = migration_details_dict["data_query"]
            conflict_cols = migration_details_dict["conflict_cols"]
            primary_id_col = migration_details_dict["primary_id_column"]
            to_table = migration_details_dict["table_name"]

            df_size = int(os.getenv("DF_SIZE", 10000))
            max_retries = 3
            success_count = 0

            # --------------------------------------------------
            # Clean & prepare queries
            # --------------------------------------------------
            from_query = " ".join(from_query.split()).rstrip(";")
            count_query = " ".join(self.get_count_query(from_query).split())

            logging.info(f"[{trace_id}] FROM QUERY  : {from_query}")
            logging.info(f"[{trace_id}] COUNT QUERY : {count_query}")

            # --------------------------------------------------
            # Generate batch queries
            # --------------------------------------------------
            try:
                batch_queries, total_count = self.generate_batch_queries(
                    count_query,
                    from_query,
                    from_connection,
                    df_size,
                    primary_id_col,
                )
            except Exception as e:
                tb = traceback.format_exc()
                self.update_table(
                    postgres_conn,
                    history_table,
                    {
                        "error_msg": f"Error generating batch queries: {e}\n{tb}",
                        "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    },
                    {"trace_id": trace_id},
                )
                return False

            if total_count == 0:
                logging.info(f"[{trace_id}] No records found for migration")

                self.update_table(
                    postgres_conn,
                    history_table,
                    {
                        "total_count": 0,
                        "success": 0,
                        "failed": 0,
                        "job_status_msg": "SUCCESS",
                        "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    },
                    {"trace_id": trace_id},
                )
                return True

            # --------------------------------------------------
            # Update total count
            # --------------------------------------------------
            self.update_table(
                postgres_conn,
                history_table,
                {"total_count": total_count},
                {"trace_id": trace_id},
            )

            logging.info(f"[{trace_id}] Total records to migrate: {total_count}")

            # --------------------------------------------------
            # Execute batch queries
            # --------------------------------------------------
            for query in batch_queries:
                logging.info(f"[{trace_id}] Executing batch query")

                df = None
                attempt = 1

                while attempt <= max_retries:
                    try:
                        df = self.execute_query(from_connection, query)

                        if df is not None and not df.empty:
                            df = df.astype(object).mask(df.isna(), None)
                            df = self.modify_uuid_cols(df)

                            logging.info(
                                f"[{trace_id}] Batch fetched | rows={df.shape[0]}"
                            )
                            break

                        logging.info(
                            f"[{trace_id}] Empty DataFrame, retrying (attempt {attempt})"
                        )
                    except Exception as e:
                        logging.info(
                            f"[{trace_id}] Batch query error (attempt {attempt}): {e}"
                        )

                    attempt += 1
                    time.sleep(5)

                if df is None or df.empty:
                    raise Exception("Failed to fetch batch data after retries")

                # --------------------------------------------------
                # Start migration for this batch
                # --------------------------------------------------
                success_count = self.initate_complete_migration_psql(
                    df,
                    to_connection,
                    postgres_conn,
                    migration_table,
                    conflict_cols,
                    job_name,
                    migration_details_dict,
                    to_table,
                    trace_id,
                    total_count,
                    success_count,
                )

                logging.info(f"[{trace_id}] Success count so far: {success_count}")

            # --------------------------------------------------
            # Final success update
            # --------------------------------------------------
            self.update_table(
                postgres_conn,
                history_table,
                {
                    "success": success_count,
                    "failed": total_count - success_count,
                    "job_status_msg": "SUCCESS",
                    "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                },
                {"trace_id": trace_id},
            )

            logging.info(f"[{trace_id}] FIRST migration completed successfully")
            return True

        except Exception as e:
            tb = traceback.format_exc()
            logging.info(f"[{trace_id}] FIRST migration failed: {e}")

            self.update_table(
                postgres_conn,
                history_table,
                {
                    "error_msg": f"{e}\n{tb}",
                    "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                },
                {"trace_id": trace_id},
            )
            return False

    def get_to_db_config_psql(self, migration_details_dict):
        """
        Extract and process database configuration from migration details.

        This method retrieves the database configuration from the given migration details dictionary.
        If the configuration is a JSON string, it converts it into a Python dictionary.
        If the configuration is not present or invalid, it falls back to a default configuration.

        Args:
            migration_details_dict (dict): A dictionary containing migration details,
                                        including the database configuration under 'from_db_config'.

        Returns:
            dict: A dictionary containing database configuration details, either from the input
        """
        db_config = migration_details_dict.get('to_db_config')
        if db_config and not isinstance(db_config, dict):
            db_config = json.loads(db_config)
        return db_config 
    def from_db_config_psql(self, migration_details_dict):
        """
        Extract and process database configuration from migration details.

        This method retrieves the database configuration from the given migration details dictionary.
        If the configuration is a JSON string, it converts it into a Python dictionary.
        If the configuration is not present or invalid, it falls back to a default configuration.

        Args:
            migration_details_dict (dict): A dictionary containing migration details,
                                        including the database configuration under 'from_db_config'.

        Returns:
            dict: A dictionary containing database configuration details, either from the input
        """
        db_config = migration_details_dict.get('from_db_config')
        if db_config and not isinstance(db_config, dict):
            db_config = json.loads(db_config)
        return db_config
    def to_psql_timestamp(self,ts_str: str) -> str:
        """
        Convert a timestamp like '2025-11-24 14:23:55.260032+00:00'
        into PostgreSQL compatible format '2025-11-24 14:23:55.260032+00'.
        """
        dt = datetime.fromisoformat(ts_str)
        return dt.strftime("%Y-%m-%d %H:%M:%S.%f%z")
    def start_migration_sync_psql(self, job_name, key_name=None):
        """
        Starts PostgreSQL migration job for 2.0+ tables.
        Handles first-time and last-id-based migrations.
        """
        postgres_conn = None
        trace_id = None

        try:
            logging.info(f"[INFO] Starting migration sync for job: {job_name}")

            # --------------------------------------------------
            # Load environment variables
            # --------------------------------------------------
            load_dotenv()

            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            db_name = os.getenv("PSQL_DB_NAME")
            history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")

            # --------------------------------------------------
            # Connect to Metadata DB
            # --------------------------------------------------
            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )
            logging.info("[INFO] Connected to PostgreSQL metadata DB")

            # --------------------------------------------------
            # Insert Job Start History
            # --------------------------------------------------
            job_start_time = datetime.now(timezone.utc).replace(tzinfo=None)

            hist_insert_data = {
                "key_name": key_name,
                "job_name": job_name,
                "job_start_time": job_start_time,
                "request_triggered_by": "optimization_sync_lambda",
            }

            trace_id = self.insert_dict(
                postgres_conn,
                history_table,
                hist_insert_data,
                True,
                "trace_id",
            )

            logging.info(f"[INFO] Job started | trace_id={trace_id}")

            # --------------------------------------------------
            # Fetch migration details
            # --------------------------------------------------
            migration_table = "data_sync_mappings_for_inv_20"
            migration_details = self.get_migration_details(
                job_name, postgres_conn, migration_table
            )

            # --------------------------------------------------
            # Load DB configurations
            # --------------------------------------------------
            to_db_config = self.get_to_db_config_psql(migration_details)
            from_db_config = self.from_db_config_psql(migration_details)

            if not to_db_config or not from_db_config:
                msg = f"Missing DB configuration for migration '{job_name}'"
                logging.info(f"[ERROR] {msg}")

                self.update_table(
                    postgres_conn,
                    history_table,
                    {
                        "error_msg": msg,
                        "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    },
                    {"trace_id": trace_id},
                )
                return False

            logging.info("[INFO] Source and Target DB configs loaded successfully")

            # --------------------------------------------------
            # Create DB connections
            # --------------------------------------------------
            to_connection = self.create_connection(
                to_db_config["to_db_type"],
                to_db_config["hostname"],
                to_db_config["to_database"],
                to_db_config["user"],
                to_db_config["password"],
                to_db_config["port"],
            )

            from_connection = self.create_connection(
                from_db_config["to_db_type"],
                from_db_config["hostname"],
                from_db_config["to_database"],
                from_db_config["user"],
                from_db_config["password"],
                from_db_config["port"],
            )

            table_name = migration_details["table_name"]
            logging.info(f"[INFO] Starting migration for table: {table_name}")

            # --------------------------------------------------
            # Execute Migration
            # --------------------------------------------------
            migration_status = migration_details.get("status")
            #migration_status="first"
            if migration_status == "first":
                logging.info(f"[INFO] First-time migration | trace_id={trace_id}")

                self.first_migration_psql(
                    to_connection,
                    from_connection,
                    postgres_conn,
                    migration_details,
                    migration_table,
                    job_name,
                    trace_id,
                )
            else:
                logging.info(f"[INFO] Last-ID based migration | trace_id={trace_id}")

                self.last_id_migration_psql(
                    to_connection,
                    postgres_conn,
                    migration_details,
                    migration_table,
                    job_name,
                    trace_id,
                )

            # --------------------------------------------------
            # Update Success Status
            # --------------------------------------------------
            self.update_table(
                postgres_conn,
                history_table,
                {
                    "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                },
                {"trace_id": trace_id},
            )

            logging.info(f"[SUCCESS] Migration completed | trace_id={trace_id}")
            return True

        except Exception as e:
            tb = traceback.format_exc()
            logging.info(f"[CRITICAL] Migration failed | job={job_name} | error={e}")

            if postgres_conn and trace_id:
                self.update_table(
                    postgres_conn,
                    history_table,
                    {
                        "error_msg": f"{e}\n{tb}",
                        "job_end_time": datetime.now(timezone.utc).replace(tzinfo=None),
                    },
                    {"trace_id": trace_id},
                )
            raise
    def billing_tables_sync_(self, data):
        """
        Triggers billing table migrations based on key_name.
        Fetches migration jobs from DB and executes them sequentially.
        """
        start_time = time.time()

        key_name = data.get("key_name")
        if not key_name:
            raise ValueError("[ERROR] key_name is missing in input data")

        logging.info(f"[INFO] Starting billing migration for key_name: {key_name}")

        try:
            # Load environment variables
            load_dotenv()
            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            db_name = os.getenv("PSQL_DB_NAME")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            common_utils_db = os.getenv("COMMON_UTILS_DB_NAME")

            # Create DB connections
            postgres_conn = self.create_connection(db_type, hostname, db_name, user, password, port)
            comm_postgres_con = self.create_connection(db_type, hostname, common_utils_db, user, password, port)

            # Fetch scheduled migration jobs
            migration_table = "lambda_sync_jobs"
            job_query = f"""
                SELECT migration_names_list
                FROM {migration_table}
                WHERE key_name = '{key_name}'
            """
            logging.info(f"[DEBUG] Fetching jobs: {job_query}")
            rows = self.execute_query(postgres_conn, job_query)

            if rows.empty or not rows["migration_names_list"][0]:
                raise Exception(f"[ERROR] No migration jobs found for key_name: {key_name}")

            job_names_list = rows["migration_names_list"][0]
            logging.info(f"[INFO] Jobs scheduled: {job_names_list}")

            jobs_status_dict = {"Success": [], "Failed": []}

            # Execute jobs sequentially
            for job in job_names_list:
                logging.info(f"[INFO] Starting job: {job}")
                job_start_time = time.time()

                try:
                    migration_job_status = self.start_migration_sync_psql(job, key_name)
                    job_duration = time.time() - job_start_time

                    if migration_job_status is True:
                        jobs_status_dict["Success"].append(job)
                        logging.info(f"[SUCCESS] {key_name} | Job {job} completed in {job_duration:.2f}s")
                    else:
                        jobs_status_dict["Failed"].append(job)
                        logging.info(f"[FAILED] {key_name} | Job {job} failed in {job_duration:.2f}s")

                except Exception as job_error:
                    jobs_status_dict["Failed"].append(job)
                    logging.info(f"[ERROR] {key_name} | Job {job} raised exception: {job_error}")

            total_duration = time.time() - start_time
            logging.info(f"[INFO] Migration finished for {key_name} in {total_duration:.2f} seconds")

            # Update migration table
            last_migrated_time = datetime.now()
            update_dict = {
                "sync_status": "Completed",
                "sync_job_status": json.dumps(jobs_status_dict),
                "last_migrated_time": last_migrated_time
            }
            logging.info(f"[INFO] Updating sync status for {key_name}: {update_dict}")
            self.update_table(postgres_conn, migration_table, update_dict, {"key_name": key_name})

            return jobs_status_dict

        except Exception as e:
            logging.info(f"[CRITICAL] Migration failed for key_name={key_name}: {e}")
            raise
    def __init__(self):
        """
        Initialize S3 client using IAM Role.
        No access keys or endpoint URLs required.
        """
        self.s3_client = boto3.client("s3")
    def read_file_from_s3(
        self,
        filename: str,
        bucket_name: str,
        folder_name: str,
        trace_id: str,
        postgres_conn,
        s3_client=None,
        max_retries: int = 3,
        retry_delay: int = 120
    ) -> pd.DataFrame:
        """
        Reads an Excel file from AWS S3 and returns a Pandas DataFrame.
        Uses IAM Role credentials (no access keys required).
        Retries up to max_retries times on failure.
        """

        attempt = 1

        while attempt <= max_retries:
            try:
                logging.info(f"[INFO][{trace_id}] Attempt {attempt}/{max_retries} | Reading file from S3 | Bucket: {bucket_name} | Folder: {folder_name} | File: {filename}")

                # Create S3 client ONLY if not passed
                if s3_client is None:
                    s3_client = boto3.client("s3")

                # Construct S3 key safely
                folder_name = folder_name.strip("/")
                s3_key = f"{folder_name}/{filename}" if folder_name else filename

                logging.info(f"[INFO][{trace_id}] Full S3 Key: {s3_key}")

                response = s3_client.get_object(
                    Bucket=bucket_name,
                    Key=s3_key
                )

                file_bytes = response["Body"].read()

                df = pd.read_excel(BytesIO(file_bytes))

                logging.info(
                    f"[SUCCESS][{trace_id}] File read successfully | "
                    f"Rows: {df.shape[0]} | Columns: {df.shape[1]}"
                )

                return df  

            except Exception as exc:
                logging.error(
                    f"[ERROR][{trace_id}] Attempt {attempt}/{max_retries} failed: {exc}"
                )

                if attempt == max_retries:
                    logging.error(
                        f"[FAILURE][{trace_id}] All {max_retries} attempts failed while reading S3 file"
                    )

                    # Update history table on FINAL failure only
                    try:
                        load_dotenv()
                        history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")
                        update_data = {
                            "error_msg": f"S3 read error: {exc}",
                            "job_end_time": datetime.now(timezone.utc),
                        }
                        self.update_table(
                            postgres_conn,
                            history_table,
                            update_data,
                            {"trace_id": trace_id}
                        )
                        logging.info(
                            f"[ERROR][{trace_id}] Updated history table with S3 read failure"
                        )
                    except Exception as update_exc:
                        logging.error(
                            f"[ERROR][{trace_id}] Failed to update history table: {update_exc}"
                        )
                    return pd.DataFrame()

                logging.info(
                    f"[RETRY][{trace_id}] Retrying after {retry_delay} seconds..."
                )
                time.sleep(retry_delay)
                attempt += 1
    def execute_query(self,connection,query):
        """
        Executes a SQL query using the given database connection and returns the result as a DataFrame.

        Args:
            connection: The database connection object to execute the query.
            query (str): The SQL query to be executed.

        Returns:
            pd.DataFrame: The result of the query as a pandas DataFrame, or None if an error occurs.
        """
        try:
            result_df=pd.read_sql_query(query,connection)
            return result_df
        except Exception as e:
            logging.info(f"Error executing query: {e}")
            return None
    def to_snake_case(self,name: str) -> str:
        # Handle CamelCase / PascalCase → snake_case
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
        s2 = re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1)

        # Step 2: lowercase
        s = s2.lower()

        # Step 3: fix broken abbreviations like m2_m → m2m
        s = re.sub(r'([a-z0-9])_([a-z0-9])_', r'\1\2_', s)
        s = re.sub(r'_([a-z0-9])_([a-z0-9])_', r'_\1\2_', s)
        s = re.sub(r'^([a-z0-9])_([a-z0-9])_', r'\1\2_', s)

        # Step 4: remove duplicate underscores
        s = re.sub(r'__+', '_', s)

        return s.strip('_')

    def insert_df_with_retry_on_conflict(
            self,
            conn,
            df,
            table_name,
            conflict_cols,
            trace_id,
            postgres_conn,
            history_table,
            file_name,
            max_retries=3,
            retry_delay=60,
            batch_size=5000
        ):
        """
        Insert DataFrame into PostgreSQL using execute_values with ON CONFLICT DO UPDATE
        and retry mechanism. Processes data in batches. All logs include trace_id.
        Records error messages in history table if any batch fails.
        Measures and logging.infos time taken for each batch and total insertion.
        """
        try:
            if df.empty:
                logging.info(f"[WARN][{trace_id}] DataFrame is empty. Skipping insert.")
                return True

            all_cols = list(df.columns)
            update_cols = [c for c in all_cols if c not in conflict_cols]

            if not update_cols:
                raise ValueError(f"[DB][{trace_id}] No columns available for update in ON CONFLICT clause")

            total_rows = len(df)
            logging.info(f"[INFO][{trace_id}] Starting batch insert | Total rows: {total_rows} | Batch size: {batch_size}")

            total_start_time = time.time()  # Track total time
            # Calculate total number of batches
            total_batches = (total_rows + batch_size - 1) // batch_size  # ceiling division

            for batch_num, start_idx in enumerate(range(0, total_rows, batch_size), start=1):
                end_idx = min(start_idx + batch_size, total_rows)
                batch_df = df.iloc[start_idx:end_idx]
                values = [tuple(row) for row in batch_df.itertuples(index=False, name=None)]

                insert_query = f"""
                    INSERT INTO {table_name} ({", ".join(all_cols)})
                    VALUES %s
                    ON CONFLICT ({", ".join(conflict_cols)})
                    DO UPDATE SET
                    {", ".join([f"{col} = EXCLUDED.{col}" for col in update_cols])}
                """

                attempt = 1
                batch_start_time = time.time()  # Start time for this batch

                while attempt <= max_retries:
                    try:
                        logging.info(
                            f"[DB][{trace_id}] Batch {batch_num}/{total_batches} insert attempt {attempt}/{max_retries} | "
                            f"Table: {table_name} | Rows in batch: {len(values)} | "
                            f"Batch range: {start_idx}-{end_idx-1} | Total rows: {total_rows}"
                        )

                        with conn.cursor() as cursor:
                            psycopg2.extras.execute_values(
                                cursor,
                                insert_query,
                                values,
                                page_size=len(values)
                            )

                        conn.commit()
                        batch_end_time = time.time()
                        batch_duration = batch_end_time - batch_start_time

                        logging.info(
                            f"[SUCCESS][{trace_id}] Batch {batch_num}/{total_batches} inserted/updated successfully | "
                            f"Rows processed in batch: {len(values)} | "
                            f"Time taken: {batch_duration:.2f} seconds"
                        )
                        break  # Break retry loop if successful

                    except Exception as exc_inner:
                        conn.rollback()
                        logging.info(f"[ERROR][{trace_id}] Batch {batch_num}/{total_batches} insert attempt {attempt} failed: {exc_inner}")

                        if attempt == max_retries:
                            error_msg = f"Error message: {exc_inner}"
                            update_data = {
                                "error_msg": error_msg,
                                "job_end_time": datetime.now(timezone.utc),
                            }
                            try:
                                self.update_table(postgres_conn, history_table, update_data, {"trace_id": trace_id})
                                logging.info(f"[ERROR][{trace_id}] Updated history table with error message")
                            except Exception as update_exc:
                                logging.info(f"[ERROR][{trace_id}] Failed to update history table: {update_exc}")

                            logging.info(f"[FAILURE][{trace_id}] All {max_retries} retry attempts exhausted for batch {batch_num}/{total_batches}")
                            raise

                        logging.info(f"[RETRY][{trace_id}] Retrying batch {batch_num}/{total_batches} after {retry_delay} seconds...")
                        time.sleep(retry_delay)
                        attempt += 1
            total_end_time = time.time()
            total_duration = total_end_time - total_start_time
            total_duration_minutes = total_duration / 60 
            logging.info(f"[INFO][{trace_id}] All batches processed successfully Total rows: {total_rows} | Total time: {total_duration_minutes:.2f} minutes")
            return True

        except Exception as exc_outer:
            logging.info(f"[ERROR][{trace_id}] Unexpected error in insert_df_with_retry_on_conflict: {exc_outer}")
            import traceback
            traceback.logging.info_exc()
            try:
                error_msg = f"Error message: {exc_outer}"
                update_data = {
                    "error_msg": error_msg,
                    "job_end_time": datetime.now(timezone.utc),
                }
                self.update_table(postgres_conn, history_table, update_data, {"trace_id": trace_id})
                logging.info(f"[ERROR][{trace_id}] Updated history table with outer exception")
            except Exception as update_exc:
                logging.info(f"[ERROR][{trace_id}] Failed to update history table for outer exception: {update_exc}")
            return True
    def move_s3_file_to_archive(
        self,
        bucket_name: str,
        inbound_prefix: str,
        archive_prefix: str,
        filename: str,
        trace_id: str,
        postgres_conn,
        max_retries: int = 3,
        retry_delay: int = 10,
        s3_client=None
    ):
        """
        Moves a file from inbound S3 folder to archive folder
        by copying and deleting the source object.
        Retries up to max_retries times on failure and updates history table if final failure occurs.
        """

        attempt = 1
        while attempt <= max_retries:
            try:
                if s3_client is None:
                    s3_client = self.s3_client

                inbound_prefix = inbound_prefix.strip("/")
                archive_prefix = archive_prefix.strip("/")

                source_key = f"{inbound_prefix}/{filename}" if inbound_prefix else filename
                target_key = f"{archive_prefix}/{filename}"

                logging.info(
                    f"[INFO][{trace_id}] Attempt {attempt}/{max_retries} | Archiving file | "
                    f"Source: {source_key} -> Target: {target_key}"
                )

                # Copy object
                s3_client.copy_object(
                    Bucket=bucket_name,
                    CopySource={"Bucket": bucket_name, "Key": source_key},
                    Key=target_key
                )

                # Delete original
                s3_client.delete_object(
                    Bucket=bucket_name,
                    Key=source_key
                )

                logging.info(
                    f"[SUCCESS][{trace_id}] File archived successfully | {filename}"
                )
                return True  

            except Exception as exc:
                logging.error(
                    f"[ERROR][{trace_id}] Attempt {attempt}/{max_retries} failed to archive file {filename}: {exc}"
                )

                if attempt == max_retries:
                    logging.error(
                        f"[FAILURE][{trace_id}] All {max_retries} attempts failed for archiving file {filename}"
                    )

                    # Update history table on FINAL failure
                    try:
                        load_dotenv()
                        history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")
                        update_data = {
                            "error_msg": f"S3 archive error: {exc}",
                            "job_end_time": datetime.now(timezone.utc),
                        }
                        self.update_table(
                            postgres_conn,
                            history_table,
                            update_data,
                            {"trace_id": trace_id}
                        )
                        logging.info(
                            f"[ERROR][{trace_id}] Updated history table with S3 archive failure"
                        )
                    except Exception as update_exc:
                        logging.error(
                            f"[ERROR][{trace_id}] Failed to update history table: {update_exc}"
                        )
                    raise  # re-raise exception after updating history table

                # Retry delay before next attempt
                logging.info(f"[RETRY][{trace_id}] Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
                attempt += 1

    def amop_usage_sync(self, data):
        try:
            logging.info("[INFO] AMOP Usage Sync Process Started")
            logging.info(f"[INFO] Received payload: {data}")

            tenant_id = data.get("tenant_id")
            file_name = data.get("filename")
            key_name = f"tenant_id-{tenant_id} filename-{file_name}"

            logging.info(f"[PAYLOAD] tenant_id extracted : {tenant_id}")
            logging.info(f"[PAYLOAD] file_name extracted : {file_name}")
            logging.info(f"[PAYLOAD] key_name generated  : {key_name}")

            logging.info("[ENV] Loading environment variables from .env file")
            load_dotenv()

            bucket_name = os.getenv("S3_BUCKET")
            inbound_folder = os.getenv("INBOUND_PREFIX")

            logging.info(f"[ENV] S3 Bucket Name      : {bucket_name}")
            logging.info(f"[ENV] S3 Inbound Folder   : {inbound_folder}")

            hostname = os.getenv("PSQL_DB_HOST")
            port = os.getenv("PSQL_DB_PORT")
            user = os.getenv("PSQL_DB_USER")
            password = os.getenv("PSQL_DB_PASSWORD")
            db_type = os.getenv("PSQL_DB_TYPE")
            db_name = os.getenv("PSQL_DB_NAME")
            common_utils_db = os.getenv("COMMON_UTILS_DB_NAME")

            logging.info("[ENV] PostgreSQL configuration loaded successfully")

            logging.info("[DB] Creating MIgration Test DB PostgreSQL connection")

            postgres_conn = self.create_connection(
                db_type, hostname, db_name, user, password, port
            )

            logging.info(" MIgration Test DB connection established successfully")

            logging.info("[DB] Creating Common Utils PostgreSQL connection")
            comm_postgres_con = self.create_connection(
                db_type, hostname, common_utils_db, user, password, port
            )
            logging.info("[DB] Common Utils PostgreSQL connection established successfully")
      
            logging.info("[DB] Fetching tenant database configuration")

            tenant_name_q=f"select db_name,db_config from tenant where id='{tenant_id}' and is_active=true and is_deleted=false"
            logging.info(f"[DB][QUERY] {tenant_name_q}")
            tenant_name_res = self.execute_query(comm_postgres_con, tenant_name_q)
            logging.info(f"[DB] Tenant query result:{tenant_name_res}")

            if (
                tenant_name_res is not None
                and not tenant_name_res.empty
                and "db_name" in tenant_name_res.columns
            ):
                tenant_name_ = tenant_name_res["db_name"][0]
                db_name = tenant_name_
                db_config = tenant_name_res["db_config"][0]

                if isinstance(db_config, str):
                    db_config = json.loads(db_config)

                logging.info(f"[TENANT] Tenant DB name resolved : {tenant_name_}")
            else:
                raise ValueError(f"[TENANT] Tenant '{tenant_id}' not found or inactive")

            tenant_hostname = db_config.get("hostname")
            logging.info(f"[TENANT] Tenant DB hostname resolved : {tenant_hostname}")

            # --------------------------------------------------
            # Create tenant-specific DB connection
            # --------------------------------------------------
            logging.info("[DB] Creating tenant-specific PostgreSQL connection")
            postgres_conn_altaworx = self.create_connection(
                db_type, tenant_hostname, db_name, user, password, port
            )

            logging.info("[DB] Tenant PostgreSQL connection established successfully")

            # Before starting the job, insert a record in the history table
            history_table = os.getenv("MIGRATIONS_HISTORY_TABLE")
            job_start_time = datetime.now(timezone.utc).replace(tzinfo=None)

            logging.info(f"[INFO] Job start time: {job_start_time}")

            hist_insert_data = {
                "key_name": key_name,
                "job_name": file_name,
                "job_start_time": job_start_time,
                "request_triggered_by": "s3 bucket sync",
            }

            trace_id = self.insert_dict(
                postgres_conn, history_table, hist_insert_data, True, "trace_id"
            )
            logging.info(f"[INFO] Trace ID after insertion: {trace_id}")
            logging.info(f"[INFO] Executing job: {file_name} {trace_id}")
            # --------------------------------------------------
            # Validate S3 config
            # --------------------------------------------------

            if not bucket_name or not inbound_folder:
                logging.info("[ERROR] S3_BUCKET or INBOUND_PREFIX is missing in environment variables")
                error_msg = (
                    f"ERROR: S3_BUCKET or INBOUND_PREFIX is missing "
                    f"in environment variables for file {file_name}"
                )
                update_data = {
                    "error_msg": error_msg,
                    "job_end_time": datetime.now(timezone.utc),
                }
                self.update_table(postgres_conn, history_table, update_data, {"trace_id": trace_id})
                logging.info(f"[ERROR] Error in main_migration_fun:last_id_migration for file {file_name}")
                return True
            df=self.read_file_from_s3(
                file_name,
                bucket_name,
                inbound_folder,
                trace_id,
                postgres_conn
            )
            if df is None or df.empty:
                logging.info(f"[WARN][{trace_id}] DataFrame is empty or None. Skipping further processing.")
                return True
            
            df.columns = [self.to_snake_case(col) for col in df.columns]
            # Remove existing 'id' column if it exists
            if 'id' in df.columns:
                df = df.drop(columns=['id'])
            # Rename device_usage_id to id
            df = df.rename(columns={'device_usage_id': 'id'})
            df = df.astype(object).mask(df.isna(), None)

            logging.info(f"Trace ID: {trace_id} |Shape: {df.shape} | Rows: {len(df)} | Columns: {df.shape[1]} {df.head(5)}")
            response=self.insert_df_with_retry_on_conflict(
                conn=postgres_conn_altaworx,
                df=df,
                table_name="device_usage",
                conflict_cols=["id"],  # adjust if needed
                trace_id=trace_id,
                postgres_conn=postgres_conn,
                history_table=history_table,
                file_name=file_name,
                max_retries=3,
                retry_delay=60,
                batch_size=5000
            )
            if response:
                logging.info(f"[INFO][{trace_id}] File processed successfully: {file_name}")
                load_dotenv()
                archive_prefix = os.getenv("ARCHIVE_FOLDER")
                archive_status = self.move_s3_file_to_archive(
                    bucket_name=bucket_name,
                    inbound_prefix=inbound_folder,
                    archive_prefix=archive_prefix,
                    filename=file_name,
                    trace_id=trace_id,
                    postgres_conn=postgres_conn,   # <-- add this
                    max_retries=3,
                    retry_delay=60,
                    s3_client=self.s3_client
                )

                if not archive_status:
                    logging.error(
                        f"[WARN][{trace_id}] File processed but failed to archive: {file_name}"
                    )
                    return False
                count=len(df)
                logging.info(f"[INFO][{trace_id}] File processed and archived successfully: {file_name} {count}")
                update_data = {
                    "job_status_msg": "Successfully processed the file",
                    "job_end_time": datetime.now(timezone.utc),
                    "success": str(count),        
                    "total_count": str(count)     
                }
                self.update_table(postgres_conn, history_table, update_data, {"trace_id": trace_id})
            logging.info("[INFO] AMOP Usage Sync initialization completed")
            
        except Exception as exc:
            logging.info("[ERROR] AMOP usage sync process failed")
            logging.info(f"[ERROR] Exception message: {exc}")
            logging.info("[ERROR] Stack trace:")
            error_msg = f"Error message: {exc}"
            update_data = {
                "error_msg": error_msg,
                "job_end_time": datetime.now(timezone.utc),
            }
            # Update history table even on exception
            self.update_table(postgres_conn, history_table, update_data, {"trace_id": trace_id})
            logging.info(f"[ERROR] Error in main_migration_fun:last_id_migration for file {file_name}")
            return True
    def update_data_history_table_bulk(
    self, postgres_conn, table_name, data_list, conflict_cols
    ):
        """
        Inserts or updates data in a PostgreSQL table using bulk UPSERT.
        """
        logging.info(f"[UPSERT] Starting bulk upsert for table: {table_name}")

        if not data_list:
            logging.info("[UPSERT] No data provided. Skipping insert/update.")
            return []

        logging.info(f"[UPSERT] Total records received: {len(data_list)}")

        try:
            with postgres_conn.cursor() as cursor:
                logging.info("[UPSERT] Cleaning data before insert")
                data_list = self.clean_data_list(data_list)

                columns = list(data_list[0].keys())
                logging.info(f"[UPSERT] Columns detected: {columns}")

                columns_str = ", ".join(columns)
                conflict_cols_str = ", ".join(conflict_cols)

                update_set = ", ".join(
                    f"{col} = EXCLUDED.{col}"
                    for col in columns
                    if col not in conflict_cols
                )

                query = f"""
                    INSERT INTO {table_name} ({columns_str})
                    VALUES %s
                    ON CONFLICT ({conflict_cols_str})
                    DO UPDATE SET {update_set}
                    RETURNING id, username;
                """

                logging.info(f"[UPSERT] Executing query on {table_name} {query}")
                values = [
                    tuple(record.get(col) for col in columns)
                    for record in data_list
                ]

                execute_values(cursor, query, values)
                returned_rows = cursor.fetchall()
                postgres_conn.commit()

                result = [
                    {"id": row[0], "username": row[1]}
                    for row in returned_rows
                ]

                logging.info(
                    f"[UPSERT] Successfully inserted/updated "
                    f"{len(result)} records in {table_name}"
                )

            return result

        except Exception as e:
            postgres_conn.rollback()
            logging.info(f"[UPSERT][ERROR] Failed for table {table_name}: {e}")
            return []


    def clean_data_list(self, data_list):
        """Convert NaT / NaN values to None for PostgreSQL compatibility."""
        logging.info("[CLEAN] Cleaning incoming data")

        for idx, record in enumerate(data_list):
            for key, value in record.items():
                if value is None:
                    continue
                if isinstance(value, float) and math.isnan(value):
                    record[key] = None
                elif isinstance(value, pd._libs.tslibs.nattype.NaTType):
                    record[key] = None
                elif isinstance(value, pd.Timestamp):
                    record[key] = (
                        None if pd.isna(value)
                        else value.strftime("%Y-%m-%d %H:%M:%S")
                    )
                elif isinstance(value, str) and value.lower() in [
                    "nat", "nan", "none", "null"
                ]:
                    record[key] = None

            if idx == 0:
                logging.info(f"[CLEAN] Sample cleaned record: {record}")

        logging.info("[CLEAN] Data cleaning completed")
        return data_list
    def create_pg_connection(self,db_config):
        """
        Creates and returns a PostgreSQL connection object using given db_config.

        db_config example:
        {
            "port": "5432",
            "user": "root",
            "db_type": "postgresql",
            "database": "altaworx_central",
            "hostname": "amoppostgresdb.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
            "password": "AmopTeam123"
        }
        """

        try:
            connection = psycopg2.connect(
                    host=db_config["hostname"],
                    database=db_config["database"],
                    user=db_config["user"],
                    password=db_config["password"],
                    port=db_config.get("port", 5432),
                )
            logging.info(f"Connected to DB: {db_config['database']} at {db_config['hostname']}")
            return connection

        except Exception as e:
            logging.info(f" Error connecting to PostgreSQL DB: {e}")
            return None


    def users_table_sync(self, data):
        """
        Sync users table data from MSSQL to PostgreSQL.
        """
        logging.info("[USERS_SYNC] Sync process started")

        if not data:
            logging.info("[USERS_SYNC] No data received. Exiting.")
            return

        multi_tenant_conn = None
        comm_postgres_con = None

        try:
            user_id = data.get("user_id")
            logging.info(f"[USERS_SYNC] Processing user_id: {user_id}")

            logging.info("[USERS_SYNC] Connecting to MSSQL database")
            load_dotenv()
            mssql_host=os.getenv('BASE_MULTI_TENANT_HOST')
            
            load_dotenv()
            logging.info("[USERS_SYNC] Connecting to MSSQL database")
            mssql_host=os.getenv("BASE_MULTI_TENANT_HOST")
            mssql_db=os.getenv("BASE_MULTI_TENANT_DB")
            mssql_user=os.getenv("BASE_MULTI_TENANT_USER")
            mssql_pass=os.getenv("BASE_MULTI_TENANT_PASSWORD")
            #mssql_port=os.getenv("BASE_MULTI_TENANT_PORT")
            multi_tenant_conn = self.create_connection(
            "mssql",
            mssql_host,
            mssql_db,
            mssql_user,
            mssql_pass
            )

            comm_postgres_con = self.create_connection(
                os.getenv("PSQL_DB_TYPE"),
                os.getenv("PSQL_DB_HOST"),
                os.getenv("COMMON_UTILS_DB_NAME"),
                os.getenv("PSQL_DB_USER"),
                os.getenv("PSQL_DB_PASSWORD"),
                os.getenv("PSQL_DB_PORT"),
            )

            logging.info("[USERS_SYNC] Fetching user data from MSSQL")
            users_data_query = """
                SELECT 
                    ur.id AS user_role_id_10,
                    u.id AS user_id_10,
                    u.TenantId AS tenant_id,
                    u.Username AS username,
                    u.Email AS email,
                    u.FirstName AS first_name,
                    u.LastName AS last_name,
                    u.Phone AS phone,
                    u.IsDeleted AS is_deleted,
                    u.IsActive AS is_active,
                    u.IsAuthApiMigrated AS migrated,
                    u.[password] AS password,
                    u.createdby AS created_by,
                    u.modifiedby AS modified_by,
                    u.deletedby AS deleted_by,
                    u.salt AS salt,
                    u.LastLogin AS last_login,
                    u.Address1 AS address1,
                    u.address2 AS address2,
                    u.city,
                    u.state,
                    u.role,
                    u.TimeZone AS timezone,
                    t.name AS tenant_name
                FROM basemultitenant_betaprod.dbo.[user] u
                JOIN basemultitenant_betaprod.dbo.tenant t 
                    ON t.id = u.TenantId
                LEFT JOIN basemultitenant_betaprod.dbo.user_role ur 
                    ON u.id = ur.userid
                AND ur.id = (
                        SELECT TOP 1 ur_inner.id
                        FROM basemultitenant_betaprod.dbo.user_role ur_inner
                        WHERE ur_inner.userid = u.id
                        ORDER BY ur_inner.modifieddate DESC,
                                ur_inner.createddate DESC
                )
                WHERE u.id = %s;
            """

            cursor = multi_tenant_conn.cursor()
            cursor.execute(users_data_query, (user_id,))
            rows = cursor.fetchall()

            logging.info(f"[USERS_SYNC] Records fetched from MSSQL: {len(rows)}")

            columns = [col[0] for col in cursor.description]
            df = pd.DataFrame(rows, columns=columns)
            data_list = df.to_dict(orient="records")

            logging.info("[USERS_SYNC] Starting UPSERT into PostgreSQL users table")
            user_id_name_list=self.update_data_history_table_bulk(
                comm_postgres_con,
                "users",
                data_list,
                ["user_id_10"],
            )
            if not user_id_name_list:
                logging.info("[USERS_SYNC] No user records returned from upsert")
                return False

            first_record = user_id_name_list[0]

            user_id_20 = first_record.get("id")
            user_name = first_record.get("username")

            if not user_id_20 or not user_name:
                logging.info(f"[USERS_SYNC] Missing id or username in response: {first_record}")
                return False
            logging.info(f"[USERS_SYNC] id or username in response: {user_id_20} {user_name}")

            #logging.info(f"[USERS_SYNC] Sync completed successfully for user_id {user_id}")
            try:
                logging.info(f" [USERS_SYNC] Customers or customergroups and syncing was started {user_id}")
                users_cust_query = f"""
                        SELECT
                            r.name AS tenant_role,
                            urs.TenantId AS tenant_id,
                            urs.siteid AS customer_id,
                            urs.sitegroupid AS customer_group_id
                        FROM basemultitenant_betaprod.dbo.User_Role_Site urs
                        JOIN basemultitenant_betaprod.dbo.Role r
                            ON urs.RoleId = r.id
                        WHERE urs.userid = {user_id} AND urs.Isactive=1 and urs.isdeleted=0
                """
                cursor = multi_tenant_conn.cursor()
                cursor.execute(users_data_query, (user_id,))
                rows = cursor.fetchall()
                logging.info(f"[USERS_SYNC] Records fetched from MSSQL: {len(rows)}")
                columns = [col[0] for col in cursor.description]
                customers_df = pd.DataFrame(rows, columns=columns)
                logging.info(f"Customer mapping for user_id_20 is  '{user_id_20}'  user_id_10 is {user_id}  : {customers_df.to_dict(orient='records')}")
                final_output = []

                for row in customers_df.to_dict(orient="records"):

                    tenant_id = row["tenant_id"]
                    customer_group_id = row.get("customer_group_id")
                    customer_id = row.get("customer_id")
                    tenant_role = row.get("tenant_role")

                    logging.info(f"Processing Tenant {tenant_id}:")
                    logging.info(f" → Customer Group ID IS : {customer_group_id}")
                    logging.info(f" → Customer ID IS : {customer_id}")

                    # -------------------------------------------------
                    # STEP 1: Fetch tenant DB config
                    # -------------------------------------------------
                    tenant_config_query = f"""
                        SELECT db_config
                        FROM tenant
                        WHERE id = {tenant_id}
                    """

                    tenant_config_df = self.execute_query(
                        comm_postgres_con, tenant_config_query
                    )
                    records = tenant_config_df.to_dict(orient="records")

                    if not records:
                        logging.info(f"No DB config found for tenant {tenant_id}")
                        final_output.append({
                            "tenant_id": tenant_id,
                            "user_id": user_id_20,
                            "user_name":user_name,
                            "tenant_role": tenant_role,
                            "customer_group": None,
                            "customers": []
                        })
                        continue

                    db_config = records[0]["db_config"]
                    logging.info(f"DB Config for tenant {tenant_id}: {db_config}")

                    # -------------------------------------------------
                    # STEP 2: Connect to tenant DB
                    # -------------------------------------------------
                    tenant_db_con = self.create_pg_connection(db_config)

                    if not tenant_db_con:
                        logging.info(f"Failed to connect to tenant DB for {tenant_id}")
                        final_output.append({
                            "tenant_id": tenant_id,
                            "user_id": user_id_20,
                            "tenant_role": tenant_role,
                            "customer_group": None,
                            "customers": []
                        })
                        continue

                    # -------------------------------------------------
                    # DEFAULT OUTPUT VALUES
                    # -------------------------------------------------
                    customer_group_name = None
                    customer_names = []

                    # -------------------------------------------------
                    # STEP 3: Fetch CUSTOMER GROUP NAME
                    # -------------------------------------------------
                    if customer_group_id:
                        group_query = f"""
                            SELECT name
                            FROM customergroups
                            WHERE id = {customer_group_id}
                        """
                        group_df = self.execute_query(tenant_db_con, group_query)
                        group_records = group_df.to_dict(orient="records")

                        if group_records:
                            customer_group_name = group_records[0]["name"]

                    # -------------------------------------------------
                    # STEP 4: Fetch CUSTOMER NAME
                    # -------------------------------------------------
                    if customer_id:
                        customer_query = f"""
                            SELECT customer_name
                            FROM customers
                            WHERE id = {customer_id}
                        """
                        cust_df = self.execute_query(tenant_db_con, customer_query)
                        cust_records = cust_df.to_dict(orient="records")

                        if cust_records:
                            customer_names = [
                                r["customer_name"] for r in cust_records
                            ]

                    # -------------------------------------------------
                    # STEP 5: APPEND FINAL OUTPUT
                    # -------------------------------------------------
                    final_output.append({
                        "tenant_id": tenant_id,
                        "customer_group": customer_group_name,
                        "customers": customer_names,   # always LIST
                        "user_id": user_id_20,
                        "user_name":user_name,
                        "tenant_role": tenant_role
                    })
                logging.info(f"After iterating through tenant wise final output dictionary gotten is {final_output}")
                try: 
                    logging.info("[USER_MODULE_SYNC] Deactivating old mappings")
                    deactive_query = """
                        UPDATE user_module_tenant_mapping
                        SET is_active = false,
                            is_deleted = true
                        WHERE user_id = %s
                        AND is_active = true;
                        """
                    with comm_postgres_con.cursor() as cur:
                        cur.execute(deactive_query, (user_id,))
                        logging.info(f"[USER_MODULE_SYNC] Rows deactivated: {cur.rowcount}")
                    comm_postgres_con.commit()
                except Exception as e: 
                    logging.info(f"An error occured in deactivating previous records in user_module_tenant_mapping {e}")
                try:
                    logging.info(f"Insertion of new records into user_module_tenant_mapping began {user_id_20} {user_name}")
                    insert_query = """
                        INSERT INTO user_module_tenant_mapping (
                            user_id,
                            user_name,
                            tenant_id,
                            tenant_role,
                            customer_group,
                            customers,
                            is_active,
                            is_deleted
                        )
                        VALUES (%s, %s, %s, %s, %s, %s, true, false);
                    """
                    with comm_postgres_con.cursor() as cur:
                        for record in final_output:
                            cur.execute(
                                insert_query,
                                (
                                    record["user_id"],        # user_id_20
                                    record["user_name"],
                                    record["tenant_id"],
                                    record["tenant_role"],
                                    record["customer_group"],
                                    record["customers"],      # json / array
                                )
                            )
                    comm_postgres_con.commit()
                    logging.info("[USER_MODULE_SYNC] user_module_tenant_mapping inserted successfully")
                except Exception as e: 
                    logging.info(f"An error occured in inserting the data into user_module_tenant_mapping {e}")
            except Exception as e: 
                logging.info(f"An Error Occured in users table customergroup and roles sync {e}")
        except Exception as e:
            logging.info(f"[USERS_SYNC][ERROR] User sync failed for user_id={user_id}: {e}")
            raise
        finally:
            logging.info("[USERS_SYNC] Closing database connections")
            if multi_tenant_conn:
                multi_tenant_conn.close()
            if comm_postgres_con:
                comm_postgres_con.close()



##Calling the main method of class
# if __name__ == "__main__":
#     scheduler = MigrationScheduler()
#     #scheduler.main()
# scheduler.main_migration_func("automation_rule_altaworx")
