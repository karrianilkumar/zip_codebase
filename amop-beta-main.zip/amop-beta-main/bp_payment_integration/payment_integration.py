#Lambda
"""
@Author1 : Srikanth Rekkala
Created Date: 26-08-2025
"""

# Importing the necessary Libraries
import ast
import boto3
import requests
import os
import pandas as pd
from common_utils.billing_platform_email_trigger import send_email
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import fetch_tenant_timezone
import datetime
from datetime import time,date
from datetime import datetime, timedelta
import time
from io import BytesIO
import json
import re
import pytds
import pytz
from pytz import timezone
from pytz import UnknownTimeZoneError, timezone
#download template dependencies
import base64
from reportlab.lib.utils import ImageReader
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
import io
from dateutil.parser import parse
from dateutil.relativedelta import relativedelta
import xml.etree.ElementTree as ET
import pandas as pd
import ast
from collections import Counter
from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib import colors
from PIL import Image, UnidentifiedImageError
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter



# Dictionary to store database configuration settings retrieved from environment variables.
common_utils_database_config = {
    "host": os.environ["HOST"],
    "port": os.environ["PORT"],
    "user": os.environ["USER"],
    "password": os.environ["PASSWORD"],
    "multi_schema":False
}
logging = Logging(name="payment_integration")

def clean_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        print(f"Exception while converting")
        return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name,role_name,readme_flag):
    """
    Creates a database configuration dictionary with user-specific filters based on tenant and role.

    Args:
        user (str): Username to look up permissions for
        db_config_making (dict): Base database configuration to extend
        tenant_database (str): Name of the tenant database
        tenant_name (str): Name of the tenant
        role_name (str): User's role (e.g., 'Super Admin')
        readme_flag (bool): Flag to determine query format (client_id vs user_name)

    Returns:
        dict: Modified database configuration with user-specific filters
    """
    logging.info(f"db_config_maker is in progress {role_name}")
    # Connect to common_utils database to get tenant info
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"],**common_utils_database_config)
    # Get tenant ID and parent tenant ID
    tenant_data = common_utils_database.get_data(
    "tenant", {"tenant_name": tenant_name},
    ["id","parent_tenant_id"]
    )
    tenant_id = tenant_data["id"].to_list()[0]
    parent_tenant_id = tenant_data["parent_tenant_id"].to_list()[0]
    # Bypass filtering for Super Admin users
    if role_name in ('Super Admin','Partner Admin') and not parent_tenant_id:
        logging.info(f"Getting access filters for  in tenant: {tenant_name} with role: {role_name} in if condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name in ('Super Admin','Partner Admin') and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in else condition and parent_tenant_id {parent_tenant_id}")
        return db_config_making
    elif role_name =="Agent Partner Admin" and parent_tenant_id:
        logging.info(f"Getting access filters forin tenant: {tenant_name} with role: {role_name} in elif second condition")
        pass
    else:
        logging.info(f"Getting access filin tenant: {tenant_name} with role: {role_name} in else condition")
        pass
    if tenant_id:
        tenant_id=int(tenant_id)
    #Get user permissions from mapping table
    if readme_flag:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where client_id ='{user}' and tenant_id={tenant_id}"
        filters = common_utils_database.execute_query(query, True)
        if filters.empty:
            query = f"""
                SELECT customers, service_provider, customer_group
                FROM user_module_tenant_mapping
                WHERE user_name = '{user}' AND tenant_id = {tenant_id}
            """
            filters = common_utils_database.execute_query(query, True)
    else:
        query = f"select customers,service_provider,customer_group from user_module_tenant_mapping where user_name ='{user}' and tenant_id={tenant_id}"

        filters = common_utils_database.execute_query(query, True)
    # Connect to tenant database
    database = DB(tenant_database, **db_config)
    # Extract customer group if exists
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    # If user has a customer group, get additional filters from it
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            # Extract rate plan names
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
            # Extract customer names
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
                customer_names=None
            # Extract billing account number
            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception("Error extracting billing_account_number:", e)
                billing_account_number=None
            # Extract feature codes
            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception("Error extracting feature_codes:", e)
    # Set customer filter - use customer group names if available, otherwise use direct mapping
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    #customer=clean_tuple(customer)
    # Get service provider info and convert names to IDs
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            formatted_values = "', '".join(service_provider)
            query = f"SELECT id FROM serviceprovider WHERE service_provider_name IN ('{formatted_values}')"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    # Get additional customers created by this user
    try:
        customers_query=f'''select customer_name from customers where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customers_df=database.execute_query(customers_query,True)
        if not customers_df.empty:
            existing_customers=customers_df['customer_name'].to_list()
            if existing_customers:
                # Clean the customer value
                fixed_customer_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer, str):
                    customer_list = [customer]
                elif isinstance(customer, tuple):
                    customer_list = list(customer)
                else:
                    customer_list = customer  # Already a list

                fixed_customer_list = customer_list.copy()

                # Split the string into items and strip any unwanted characters
                for item in customer_list[0].split("', '"):
                    fixed_customer_list.append(item.strip("',"))  # Remove extra quotes and commas
                logging.info('customer_list before extend:', customer_list)

                # Extend with existing customers
                fixed_customer_list.extend(existing_customers)
                logging.info('customer_list after extend:', fixed_customer_list)

                # Optional: Convert back to tuple if needed
                customer = tuple(fixed_customer_list)
                logging.info('final customer tuple:', customer)
                customer=clean_tuple(customer)
        else:
            pass

    except Exception as e:
        logging.exception(f"Error while fetching the customers for the user {user} in tenant {tenant_name}: {e}")
    # Get additional rate plans created by this user
    try:
        customer_rate_plan_query=f'''select rate_plan_name from customerrateplan where tenant_id={tenant_id} and is_active=True and created_by='{user}'
        '''
        customer_rate_plan_df=database.execute_query(customer_rate_plan_query,True)
        if not customer_rate_plan_df.empty:
            existing_rate_plans=customer_rate_plan_df['rate_plan_name'].to_list()
            if existing_rate_plans:
                # Clean the customer value
                fixed_customer_rate_plan_list=[]
                # Clean the customer value
                # If you want to ensure it's always a list:
                if isinstance(customer_rate_plan_name, str):
                    customer_rate_plan_list = [customer_rate_plan_name]
                elif isinstance(customer_rate_plan_name, tuple):
                    customer_rate_plan_list = list(customer_rate_plan_name)
                else:
                    customer_rate_plan_list = customer_rate_plan_name  # Already a list

                fixed_customer_rate_plan_list = customer_rate_plan_list.copy() # Remove extra quotes and commas
                logging.info('customer_ rate plan list before extend:', fixed_customer_rate_plan_list)

                # Extend with existing customers
                fixed_customer_rate_plan_list.extend(existing_rate_plans)
                logging.info('customer rate plan_list after extend:', fixed_customer_rate_plan_list)

                # Optional: Convert back to tuple if needed
                customer_rate_plan_name = tuple(fixed_customer_rate_plan_list)
                logging.info('final customer rate plan tuple:', customer_rate_plan_name)

    except Exception as e:
        logging.exception(f"Error while fetching the customers  for the user {user} in tenant {tenant_name}: {e}")
    # Update configuration with all filters
    logging.info(f"{user} user is service_provider is {service_provider} and service_provider_id is {service_provider_id} and ")
    if role_name =="Agent Partner Admin" and parent_tenant_id:
        db_config_making["customers"] = None
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = None
        db_config_making["feature_codes"] = None
        db_config_making["billing_account_number"] = None
        return db_config_making
    else:
        db_config_making["customers"] = customer
        db_config_making["service_providers"] = service_provider
        db_config_making["service_provider_id"] = service_provider_id
        db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
        db_config_making["feature_codes"] = feature_codes
        db_config_making["billing_account_number"] = billing_account_number
        return db_config_making

def function_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    try:
        current_time = datetime.now()
        logging.info(f"###{path},time started : {current_time}, data received is : {data}")
    except Exception as e:
        logging.error(f"Error in function_caller: {e}")
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    logging.info(f"### db_config created is : {db_config}")
    access_token = data.get("z_access_token",None)
    tenant_database = data.get("db_name")
    if not access_token:
        role_name = data.get("role_name", "") or data.get('role', "") or data.get('role',"") or 'Super Admin'
        tenant_name = data.get("tenant_name", "") or data.get('tenant', "") or data.get('Partner',"")
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'
        readme_flag=False
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
        logging.info(f"db_config is created {path}")
    else:
        ##API Call
        logging.info(f"db_config will be created for service accountss")
        logging.info(f"path gotten is {path}")
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        user = data.get("client_id", "")
        service_data = common_utils_database.get_data(
            "service_accounts", {"client_id": user,"is_active":"True"}
        )

        if service_data.empty:
            logging.info(f"Invalid client ID: {user}")
            return {"flag": False, "message": "Invalid client ID"}

        tenant_name = service_data["tenant"].to_list()[0]
        role_name = service_data["role"].to_list()[0]
        tenant_data = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}
        )
        tenant_database = tenant_data["db_name"].to_list()[0]
        data['tenant_name']=tenant_name
        data['db_name']=tenant_database
        readme_flag=True
        db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name,role_name,readme_flag)
        db_config = db_config_making
    # Map API paths to corresponding handler functions
    path_function_map = {
        "/get_payment_token": get_payment_token,
        "/webhook_response_handler": webhook_response_handler,
        "/fetch_transaction_status": fetch_transaction_status,
        "/fetch_payment_methods": fetch_payment_methods,
        "/update_default_payment_method": update_default_payment_method,
        "/delete_payment_method": delete_payment_method,
        "/cancel_payment": cancel_payment,
        "/chargeback_history_list_view": chargeback_history_list_view,
        "/test_file": lambda data: test_file(),  # No parameters
        "/transaction_charge_back": transaction_charge_back,
        "/charge_back_exceptions_list_view": charge_back_exceptions_list_view,
        "/generate_payment_receipt": generate_payment_receipt,
        "/charge_back_exceptions_export": charge_back_exceptions_export,
        "/auto_debit_by_guid": auto_debit_by_guid,  # No parameters
        "/multi_account_auto_debit": multi_account_auto_debit,
        "/charge_back_daily_detail_sync": charge_back_daily_detail_sync,
        "/export_charge_back_exceptions": export_charge_back_exceptions,
        "/get_export_status": get_export_status,
    }
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result


def db_config_maker_2_1_2026(user,db_config_making):
    """
    Creates and returns an updated database configuration by adding customer 
    and service provider details for the given user.

    This function:
    - Connects to the COMMON_UTILS_DATABASE
    - Fetches the customers and service providers assigned to the user
    - Updates the db_config_making dictionary with these details

    Args:
        user (str): The username for which to fetch customer and service provider data.
        db_config_making (dict): Basic DB connection config (host, port, user, password)

    Returns:
        dict: Updated db_config with 'customers' and 'service_providers' keys added.
    """

    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config_making)

    query=f"select customers,service_provider from users where username ='{user}'"
    filters=common_utils_database.execute_query(query,True)
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting customer: {str(e)}")
      customer= None     

    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))

    except Exception as e:
      logging.error(f"Exception occurred while getting service_provider: {str(e)}")
      service_provider=None   

    db_config_making["customers"]= customer
    db_config_making["service_providers"]=service_provider

    return db_config_making

def function_caller_2_1_2026(data, path):
    """
    Main function caller that handles database configuration setup and routes people module-related requests.

    This function:
    1. Initializes database configuration from environment variables
    2. Determines the user and tenant-specific configuration
    3. Routes the request to the appropriate people module handler function based on the path

    Args:
        data (dict): Request data containing user/tenant information (e.g., username, db_name)
        path (str): API endpoint path being invoked

    Returns:
        dict: Result of the invoked handler function or an error message for an invalid path
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    # Access global db_config variable
    global db_config

    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    # Extract username from data (fallback handling)
    user = data.get("username") or data.get("user_name")

    # Build tenant-specific DB config
    db_config_making = db_config_maker(user, db_config)
    db_config = db_config_making
    logging.info(f"### db_config created is : {db_config}")

    # Map API paths to corresponding handler functions
    path_function_map = {
        "/get_payment_token": get_payment_token,
        "/webhook_response_handler": webhook_response_handler,
        "/fetch_transaction_status": fetch_transaction_status,
        "/fetch_payment_methods": fetch_payment_methods,
        "/update_default_payment_method": update_default_payment_method,
        "/delete_payment_method": delete_payment_method,
        "/cancel_payment": cancel_payment,
        "/chargeback_history_list_view": chargeback_history_list_view,
        "/test_file": lambda data: test_file(),  # No parameters
        "/transaction_charge_back": transaction_charge_back,
        "/charge_back_exceptions_list_view": charge_back_exceptions_list_view,
        "/generate_payment_receipt": generate_payment_receipt,
        "/charge_back_exceptions_export": charge_back_exceptions_export,
        "/auto_debit_by_guid": auto_debit_by_guid,  # No parameters
        "/multi_account_auto_debit": multi_account_auto_debit,
        "/charge_back_daily_detail_sync": charge_back_daily_detail_sync,
        "/export_charge_back_exceptions": export_charge_back_exceptions,
        "/get_export_status": get_export_status,
    }
    # Route to the correct function based on the path
    handler = path_function_map.get(path)

    if handler:
        result = handler(data)
    else:
        logging.warning(f"### Invalid path or method requested: {path}")
        result = {"flag": False, "error": "Invalid path or method"}

    return result

def format_amount(value):
    try:
        return "{:,.2f}".format(float(value))
    except (TypeError, ValueError):
        return value

def update_transaction_status(data):
    """
    Retrieves and updates the transaction status for a given bill ID from the billing database, 
    retrying with exponential backoff if not found. Returns a success message if the transaction is successful, 
    a failure message if unsuccessful, or an error if the bill ID is not found.

    Args:
        data (dict): A dictionary containing the following keys:
            - username (str, optional): The username associated with the transaction. Defaults to an empty string.
            - table_name (str, optional): The database table to query. Defaults to "payment_history".
            - bill_id (str): The bill ID for which the transaction status needs to be retrieved.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the transaction is successful, False otherwise.
            - message (str): A descriptive message about the transaction status.
    """
    
    # Extract values from the input dictionary
    batch_id = data.get("batch_id", "")
    if not batch_id:
        return {"flag": False, "message": "Batch ID is Empty"}
    billing_db_name = data.get('billing_db_name',None)

    # DB Name Validation
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    try:
        # Initialize database connection
        killbill_database = DB(billing_db_name, **db_config)
    except Exception as e:
        print(f"Database connection failed: {e}")
        return {"flag": False, "message": "Database connection error"}

    # Define retry parameters
    retries = 3  # Number of retry attempts
    delay = 2    # Initial delay in seconds for exponential backoff

    bill_id_df = None  # Initialize variable to store query result
    message='Transaction is Pending'
    flag=True
    # Retry mechanism to fetch transaction status
    for attempt in range(retries):
        try:
            #Fetch the transaction tratus of a Bill ID
            batch_id_df = killbill_database.get_data('payment_batch_info', {"id": batch_id}, ["batch_id"])
            if batch_id_df is not None and not batch_id_df.empty:
                # Extract the transaction status if data is found
                batch_status = str(batch_id_df['batch_id'].tolist()[0])
                print(f'##batch_status attempt {attempt+1}: {batch_status}')
                if str(batch_status)=='1':
                    message = "Transaction Successful"
                    break  # Exit loop if status is found
                elif str(batch_status)=='0':
                    message = "Transaction Failed"
                    flag=False
                    break  # Exit loop if status is found
                else:
                    print(f"Transaction is pending, retrying ({attempt+1}/{retries})...")
                    time.sleep(delay)
                    delay *= 2  # Exponential backoff (2s -> 4s -> 8s)
            else:
                # If transaction is not found, retry after a delay
                print(f"Transaction not found, retrying ({attempt+1}/{retries})...")
                time.sleep(delay)
                delay *= 2  # Exponential backoff (2s -> 4s -> 8s)
        except Exception as e:
            print(f"Error retrieving transaction data (attempt {attempt+1}): {e}")
            time.sleep(delay)
            delay *= 2
    return {'flag':flag,"message":message}


# Function to parse XML and extract required fields
def payment_method_handler_for_auto_debit(storage_safe_data, account_number, billing_platform_db, reference_data, card_last_four, account_brand,category):
    """
    Handles payment method persistence in the billing platform.

    This function checks if a payment method already exists in the `payment_methods` table 
    based on account_number, account_guid, and storage_safe_guid. 
    If not found, it inserts a new payment method record with details like card last four digits,
    expiry date, and brand.

    Args:
        storage_safe_data (dict): StorageSafe response containing account identifiers.
        account_number (str): The unique account number in the billing platform.
        billing_platform_db (object): Database handler with methods get_data and insert_data.
        reference_data (dict): Reference details containing card expiration info.
        card_last_four (str): Last four digits of the card.
        account_brand (str): Card brand (e.g., VISA, MasterCard).

    Returns:
        None
    """
    logging.info(f'## payment_method_handler function called with account_number {account_number} reference_data {reference_data} card_last_four {card_last_four} account_brand {account_brand} category {category}')
    try:
        if storage_safe_data:
            # Extract identifiers from StorageSafe data
            account_guid = storage_safe_data.get("AccountGuid")
            storage_safe_guid = storage_safe_data.get("Guid")

            # Proceed only if required identifiers and account number exist
            if account_guid and storage_safe_guid and account_number:
                # Check if the payment method already exists in DB
                existing_pm_df = billing_platform_db.get_data(
                    "payment_methods",
                    {
                        "account_number": account_number,
                        "account_guid": account_guid,
                        "storage_safe_guid": storage_safe_guid
                    },
                    ["id"]
                )

                if existing_pm_df is None or existing_pm_df.empty:
                    # Format expiry date (e.g., "1134" → "11/34")
                    expiry_date = reference_data.get("Expiration", "")
                    if len(expiry_date) == 4:
                        expiry_date = expiry_date[:2] + "/" + expiry_date[2:]

                    # Prepare new payment method entry
                    new_payment_method = {
                        "account_number": account_number,
                        "account_guid": account_guid,
                        "storage_safe_guid": storage_safe_guid,
                        "last_four": card_last_four,
                        "expiry_date": expiry_date,
                        "payment_method": account_brand,
                        "method_type": category
                    }
                    # Insert into payment_methods table
                    insert_id = billing_platform_db.insert_data([new_payment_method], "payment_methods")
                    logging.info(f"## payment_method_handler New payment method stored: {new_payment_method}")
                    return insert_id
                else:
                    # Log if the payment method already exists
                    logging.info("## payment_method_handler Payment method already exists, skipping insert.")
                    return False
        else:
            logging.info("## payment_method_handler Empty storage_safe_data")
            return False
    except Exception as e:
        logging.info(f"## payment_method_handler exception occured as {e}")
        return False


def payment_method_handler(storage_safe_data, account_number, billing_platform_db, reference_data, card_last_four, account_brand,category,name_on_card):
    """
    Handles payment method persistence in the billing platform.

    This function checks if a payment method already exists in the `payment_methods` table 
    based on account_number, account_guid, and storage_safe_guid. 
    If not found, it inserts a new payment method record with details like card last four digits,
    expiry date, and brand.

    Args:
        storage_safe_data (dict): StorageSafe response containing account identifiers.
        account_number (str): The unique account number in the billing platform.
        billing_platform_db (object): Database handler with methods get_data and insert_data.
        reference_data (dict): Reference details containing card expiration info.
        card_last_four (str): Last four digits of the card.
        account_brand (str): Card brand (e.g., VISA, MasterCard).

    Returns:
        None
    """
    logging.info(f'## payment_method_handler function called with account_number {account_number} reference_data {reference_data} card_last_four {card_last_four} account_brand {account_brand} category {category}')
    try:
        if storage_safe_data:
            # Extract identifiers from StorageSafe data
            account_guid = storage_safe_data.get("AccountGuid")
            storage_safe_guid = storage_safe_data.get("Guid")

            # Proceed only if required identifiers and account number exist
            if account_guid and storage_safe_guid and account_number:
                # Check if the payment method already exists in DB
                existing_pm_df = billing_platform_db.get_data(
                    "payment_methods",
                    {
                        "account_number": account_number,
                        "account_guid": account_guid,
                        "storage_safe_guid": storage_safe_guid
                    },
                    ["id"]
                )

                if existing_pm_df is None or existing_pm_df.empty:
                    # Format expiry date (e.g., "1134" → "11/34")
                    expiry_date = reference_data.get("Expiration", "")
                    if len(expiry_date) == 4:
                        expiry_date = expiry_date[:2] + "/" + expiry_date[2:]

                    # Prepare new payment method entry
                    new_payment_method = {
                        "account_number": account_number,
                        "account_guid": account_guid,
                        "storage_safe_guid": storage_safe_guid,
                        "last_four": card_last_four,
                        "expiry_date": expiry_date,
                        "payment_method": account_brand,
                        "method_type": category
                    }
                    if name_on_card:
                        new_payment_method["name_on_card"] = name_on_card
                    # Insert into payment_methods table
                    insert_id = billing_platform_db.insert_data([new_payment_method], "payment_methods")
                    logging.info(f"## payment_method_handler New payment method stored: {new_payment_method}")
                    return insert_id
                else:
                    # Log if the payment method already exists
                    logging.info("## payment_method_handler Payment method already exists, skipping insert.")
                    return False
        else:
            logging.info("## payment_method_handler Empty storage_safe_data")
            return False
    except Exception as e:
        logging.info(f"## payment_method_handler exception occured as {e}")
        return False

def convert_to_tenant_timezone(event_date, tenant_name, database):
    """
    Convert a given datetime object to the tenant's timezone.

    Parameters:
        event_date (datetime): The timestamp to be converted.
        tenant_name (str): The tenant identifier.
        database: Database connection object for fetching tenant timezone.

    Returns:
        datetime: Converted datetime object in tenant's timezone.
    """
    if not event_date or not tenant_name:
        logging.info("## convert_to_tenant_timezone: Invalid input parameters.")
        return event_date

    # Fetch tenant timezone from DB
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = database.execute_query(
        tenant_timezone_query, params=[tenant_name]
    )

    if tenant_timezone.empty or not tenant_timezone.iloc[0]['time_zone']:
        return event_date  # No timezone found, return as is

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']

    # Handle formats like: "(UTC+05:30) Asia/Kolkata"
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(\S+/\S+)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')
    logging.info(f"## convert_to_tenant_timezone: tenant_time_zone: {tenant_time_zone}")
    try:
        # Attach UTC if event_date is naive
        if event_date.tzinfo is None:
            logging.info(f"## convert_to_tenant_timezone: event_date is naive, attaching UTC: {event_date}")
            event_date = event_date.replace(tzinfo=pytz.UTC)
        # Convert to tenant's timezone
        return event_date.astimezone(pytz.timezone(tenant_time_zone))
    except Exception as e:
        logging.info(f"## convert_to_tenant_timezone: Error in timezone conversion. {e}")
        return event_date  # Fallback: return original

def sanitize_string(s):
    if isinstance(s, str):
        # remove sneaky invisible characters
        for ch in ["\u2060", "\u200b", "\u200c", "\u200d"]:
            s = s.replace(ch, "")
    return s

def db_connection_by_tenant_name(tenant_name,common_utils_db):
    """
    Fetches the credit card fee for each account under a given tenant.

    Input:
        data = {
            "tenant_id": "TENANT123"
        }

    Output:
        {
            "account_number_1": credit_card_fee_value,
            "account_number_2": credit_card_fee_value,
            ...
        }

    Logic:
        1. Fetch account_number, credit_card_fee from customer_profiles where tenant_id matches.
        2. Fetch default_settings for all tenants (includes enable_credit_card_fee_type and credit_card_fee).
        3. For each account:
           - Decide if fee applies using apply_cc_fee()
           - Use customer-specific fee if exists, otherwise tenant default.
           - Return the computed mapping as a dict.
    """
    logging.info(f'## db_connection_by_tenant_name function called with tenant_name {tenant_name}')
    try:
        if not tenant_name:
            return False
        # Fetch tenant info from common_utils_database
        tenant_df = common_utils_db.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["tenant_name", "db_name", "db_config"]
        )

        if tenant_df.empty:
            logging.info(f"## db_connection_by_tenant_name No tenant info found for tenant_name {tenant_name}")
            return False

        tenant_data = tenant_df.to_dict(orient="records")[0]
        tenant_db_config = tenant_data.get("db_config", {})

        # --- Step 2: Establish Billing Platform DB Connection ---
        billing_db_config = {
            "host": tenant_db_config.get("hostname"),
            "port": tenant_db_config.get("port"),
            "user": tenant_db_config.get("user"),
            "password": tenant_db_config.get("password"),
            "multi_schema": False
        }
        return billing_db_config
    except Exception as e:
        logging.error(f"## db_connection_by_tenant_name Exception orccured as : {e}")
        return False

def webhook_response_handler(data):
    """
    Processes webhook transaction data received from a payment gateway (TRX), 
    updates billing platform database with payment and billing information, 
    manages customer account balances and ledgers, and triggers notification emails.

    Parameters
    ----------
    data : dict
        The webhook payload containing transaction results and reference information.
        Expected to have keys 'Result' and 'Reference' with transaction details.

    Returns
    -------
    dict
        A dictionary with:
        - 'flag': bool indicating if processing succeeded,
        - 'message': str providing success or error details.

    Overview
    --------
    The function performs these key operations:
    1. Extracts and parses the transaction data, including response code, reference IDs,
       payment amount, and transaction date/time.
    2. Determines payment status ("Success" or "Fail") based on response code.
    3. Retrieves related bill IDs and associated bill records.
    4. Fetches customer profile including account balance and contact info.
    5. For successful transactions:
       - Applies payment amount across bills, updating payments, remaining, and amount_due fields.
       - Updates the customer's account balance and amount due.
       - Creates ledger entries recording payment receipts.
       - Triggers a "Payment Successful" email notification (if enabled).
    6. For failed transactions:
       - Creates ledger entries recording payment failure.
       - Triggers a "Payment Failure" email notification (if enabled).
       - Does not modify bills or account balances.
    7. Saves all transaction history entries in the payment history table.
    8. Updates the transaction status in the database.
    9. Logs audit information regarding the webhook processing duration and details.
    """
    # function implementation here...

    logging.info("## webhook_response_handler function called")
    try:
        logging.info(f"## webhook_response_handler Received TRX transaction data: {data}")

        start_time = time.time()
        # billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # Extract key fields
        result = data.get('Result', {})
        reference_data = data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        bill_id = reference_data.get('PurchaseId', '')
        card_last_four = reference_data.get('LastFour', '')
        tran_date = reference_data.get('TranDate')
        tran_time = reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')

        category =  None
        mail_payment_mode = 'Card Payment'
        if account_brand.lower() == 'ach':
            category = 'ach'
            mail_payment_mode = 'ACH Payment'
            amount = None
        else:
            category = 'credit'
            amount = float(result.get('ApprovedAmount', '0'))

        # Name on card
        name_on_card = ""
        account_info = data.get("Account", {})
        first_name = account_info.get("FirstName", "")
        last_name = account_info.get("LastName", "")
        if first_name or last_name:
            name_on_card = f"{first_name} {last_name}".strip()
        # Fetch CustomFields
        agent = ""
        custom_fields = data.get("CustomFields", [])
        for field in custom_fields:
            if isinstance(field, dict) and field.get("Id") == "UserDefinedAgent":
                agent = field.get("Value", "")
                break
        # Fetch CustomFields (Agent, Billing DB Name, Tenant Name)
        agent = ""
        billing_db_name = None
        tenant_name = None

        custom_fields = data.get("CustomFields", [])
        logging.info(f"## webhook_response_handler custom_fields {custom_fields}")
        for field in custom_fields:
            if not isinstance(field, dict):
                continue
            field_id = field.get("Id")
            field_value = field.get("Value", "")
            if field_id == "UserDefinedAgent":
                agent = field_value
            elif field_id == "UserDefinedTenantDbName":
                billing_db_name = field_value
            elif field_id == "UserDefinedTenantName":
                tenant_name = field_value

        # Log and validate
        logging.info(f"## webhook_response_handler extracted custom fields: "
                    f"agent={agent}, billing_db_name={billing_db_name}, tenant_name={tenant_name}")

        # Validate Billing DB
        if not billing_db_name:
            logging.info(f"## webhook_response_handler billing_db_name is Empty")
            return {"flag":False,"message":"Billing DB Name is required"}
        tenant_db_config = db_connection_by_tenant_name(tenant_name, database)
        # Now use the billing_db_name when creating DB connection
        if tenant_db_config:
            logging.info(f"## webhook_response_handler tenant_db_config {tenant_db_config}")
            billing_platform_db = DB(billing_db_name, **tenant_db_config)
        else:
            logging.info(f"## webhook_response_handler Failed to establish database connection for tenant_name {tenant_name}")
            return {"flag": "False", "message": "Failed to establish database connection for tenant"}
        
        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
                # Convert to tenant's timezone
                # event_date = convert_to_tenant_timezone(event_date, tenant_name, database)
            except Exception as e:
                logging.warning(f"## webhook_response_handler Failed to parse transaction datetime: {e}")

        status = "Success" if response_code == "00" else "Fail"
        batch_list_df = billing_platform_db.get_data("transaction_status", {"id": str(bill_id)}, ["bill_list","bill_amount","credit_card_fee","created_by"])
        if not batch_list_df.empty:
            bill_list = batch_list_df['bill_list'].tolist()[0]
            bill_list = ast.literal_eval(bill_list) if bill_list else []
            bill_amount = batch_list_df['bill_amount'].tolist()[0] if batch_list_df['bill_amount'].tolist()[0] else 0
            credit_card_fee = float(batch_list_df['credit_card_fee'].tolist()[0] or 0)
            created_by = batch_list_df['created_by'].tolist()[0]
        else:
            created_by = ''
            bill_amount = 0
            bill_list = []
            credit_card_fee = 0
        if not amount:
            amount = bill_amount
        # Deduct credit card fee before splitting across bills
        amount_for_bills = float(amount) - float(credit_card_fee)
        if amount_for_bills < 0:
            amount_for_bills = 0
        bills_df = billing_platform_db.get_data('customer_bills', {'id': bill_list},
                                                 ["id", "payments", "total", "amount_due", 'remaining'],
                                                 {'created_date': 'asc'})
        if isinstance(bills_df, bool) or bills_df is None or bills_df.empty:
            bill_id_df = []
        else:
            bill_id_df = bills_df.to_dict(orient="records")

        account_number_df = billing_platform_db.get_data("customer_bills", {"id": bill_list[0]}, ["account_number"])
        account_number = str(account_number_df['account_number'].tolist()[0]) if not account_number_df.empty else ""

        # Handling of Payment method
        insert_id = payment_method_handler(storage_safe_data,account_number ,billing_platform_db ,reference_data , card_last_four , account_brand, category,name_on_card)
        # fetch customer info
        email, customer_name, tenant_name, tenant_id = '', '', '', None
        account_balance, account_amount_due = 0, 0
        if account_number:
            customer_profiles_df = billing_platform_db.get_data("customer_profiles", {"account_number": account_number},
                                                    ["sales_person", "email", "customer_name", "amount_due",
                                                     "tenant_name", "tenant_id", "account_balance"])
            if customer_profiles_df is not None and not customer_profiles_df.empty:
                email = customer_profiles_df['email'].tolist()[0]
                customer_name = customer_profiles_df['customer_name'].tolist()[0]
                account_amount_due = float(customer_profiles_df['amount_due'].tolist()[0])
                tenant_name = customer_profiles_df['tenant_name'].tolist()[0]
                tenant_id = customer_profiles_df['tenant_id'].tolist()[0]
                account_balance = float(customer_profiles_df['account_balance'].tolist()[0])

        transaction_history_rows = []
        total_bill_amount = 0
        total_amount_due = 0
        formatted_date = ""
        receipt_url = ""
        if status == "Success":
            logging.info(f"## webhook_response_handler Transaction Success Case")
            # ----------------------------
            # SPLIT AMOUNT ACROSS BILLS
            # ----------------------------
            amount_paid = amount_for_bills
            row_index = 0
            total_amount_due = 0
            total_bill_amount = 0
            while amount_paid > 0 and row_index < len(bill_id_df):
                bill_dict = bill_id_df[row_index]
                current_bill_id = bill_dict.get('id', '')
                payments = float(bill_dict.get('payments', 0))
                total = float(bill_dict.get('total', 0))
                amount_due = float(bill_dict.get('amount_due', 0))
                remaining = float(bill_dict.get('remaining', 0))
                total_bill_amount = total_bill_amount + total 

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining = 0
                    amount_due = 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0
                
                total_amount_due = total_amount_due + amount_due
                # update bill
                updated_data = {"payments": str(payments), "total": str(total),
                                "amount_due": str(amount_due), "remaining": str(remaining)}
                billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})
                bill_credit_card_fee = 0
                try:
                    # Calculate bill proportion based on total without fee
                    bill_proportion = amount_for_invoice / amount_for_bills if amount_for_bills else 0
                    # Calculate per-bill credit card fee
                    bill_credit_card_fee = round(credit_card_fee * bill_proportion, 2) if bill_proportion > 0 else 0
                except Exception as e:
                    logging.info(f"## webhook_response_handler Exceptinon occured as {e}")
                    bill_credit_card_fee = 0

                # ledger entry
                ledger_description = f'''Payment Received - Thank you!
                Amount Paid : ${amount_for_invoice}  Date : {event_date.strftime("%m-%d-%Y") if event_date else None}'''
                transaction_data = {
                    "ref": reference,
                    "status": 'Successful',
                    # "date": event_date.isoformat() if event_date else None,
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(bill_credit_card_fee),
                    "name_on_card": name_on_card,
                    "created_by": created_by
                }
                transaction_history_rows.append(transaction_data)
                row_index += 1

            # update account profile
            account_balance -= amount
            account_amount_due -= amount
            update_account_balance_data = {"account_balance": round(account_balance, 2),
                                          "amount_due": round(account_amount_due, 2)}
            billing_platform_db.update_dict('customer_profiles', update_account_balance_data, {"account_number": account_number})

            if transaction_history_rows:
                for tx in transaction_history_rows:
                    tx["account_balance"] = round(account_balance, 2)

            # Email trigger for success
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Successful"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                total_remaining = sum(float(item['remaining']) if 'remaining' in item else 0 for item in bill_id_df)
                # due_amount_is = total_remaining
                total_bill_amount = sum(float(item['total']) if 'total' in item else 0 for item in bill_id_df)
                due_amount_is = total_bill_amount - amount if total_bill_amount > amount else 0
                # try:
                #     receipt_dict = {
                #         "tenant_name": tenant_name,
                #         "tenant_id": tenant_id,
                #         "ref": reference
                #     }
                #     #calling generate_payment_receipt
                #     resp = generate_payment_receipt(receipt_dict)
                #     receipt_url = resp["download_url"]  
                #     logging.info(f'receipt_url------------{receipt_url}')
                # except Exception as e:
                #     logging.info(f'error when creating receipt link-----{e}')  
                # placeholders_dict = {
                #     "payment_date": formatted_date,
                #     "bill_id": bill_list,
                #     "transaction_id": reference,
                #     "payment_mode": mail_payment_mode,
                #     "total_amount": round(total_bill_amount, 2),
                #     "amount_paid": round(amount, 2),
                #     "due_amount": round(total_amount_due, 2),
                #     "user_name": customer_name,
                #     "receipt_link": f"{receipt_url}"
                # }
                # logging.info(f"## webhook_response_handler placeholders_dict: {placeholders_dict}")
                # notification_result = send_email(
                #     template_name='Payment Successful',
                #     to_email=email,
                #     placeholder_value=placeholders_dict,
                #     subject_placeholders={},
                #     comments='Transaction Successful',
                #     customer_name=customer_name,
                #     account_number=account_number,
                #     tenant_id = tenant_id
                # )
                # try:
                #     email_trigger_time = datetime.fromtimestamp(time.time())
                #     logging.info(f'email_trigger_time---------{email_trigger_time}')
                #     update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                #     logging.info(f"## webhook_response_handler update_status: {update_status}")
                # except Exception as e:
                #     logging.error(f'## webhook_response_handler Error updating email trigger time: {e}')

        else:  
            logging.info(f"## webhook_response_handler Transaction Failed Case")
            # Mark all bills with zero payment changes, just add failure entry in payment history
            ledger_description = f'''Payment Failed
            Amount : ${amount}   Date: {event_date.strftime("%m-%d-%Y") if event_date else None}'''
            for bill_dict in bill_id_df:
                current_bill_id = bill_dict.get('id', '')
                amount_due_value = float(bill_dict.get('amount_due', 0))
                transaction_data = {
                    "ref": reference,
                    "status": 'Failed',
                    # "date": event_date.isoformat() if event_date else None,
                    # "amount": str(amount),
                    "amount": str(amount_due_value),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee),
                    "name_on_card": name_on_card,
                    "created_by": created_by
                }
                transaction_history_rows.append(transaction_data)

            # No account balance or bills update on failure

            # Email trigger for failure
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Failure"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": format_amount(amount),
                    "user_name": customer_name,
                    "due_amount": format_amount(account_amount_due),
                }
                logging.info(f"## webhook_response_handler placeholders_dict: {placeholders_dict}")
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    billing_db_name = billing_platform_db
                )
                try:
                    email_trigger_time = datetime.fromtimestamp(time.time())
                    logging.info(f'email_trigger_time---------{email_trigger_time}')
                    update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Failure"})
                    logging.info(f"## webhook_response_handler update_status: {update_status}")
                except Exception as e:
                    logging.error(f'## webhook_response_handler Error updating email trigger time: {e}')

        # insert payment history
        if transaction_history_rows:
            logging.info(f"## webhook_response_handler transaction_history_rows: {transaction_history_rows}")
            insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
            logging.info(f"## webhook_response_handler insert_status: {insert_status}")
            try:
                receipt_dict = {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "ref": reference,
                    "billing_db_name": billing_db_name
                }
                #calling generate_payment_receipt
                resp = generate_payment_receipt(receipt_dict)
                logging.info(f'## generate_payment_receipt resp: {resp}')
                receipt_url = resp["download_url"]  
                logging.info(f'receipt_url------------{receipt_url}')
            except Exception as e:
                logging.info(f'error when creating receipt link-----{e}')  
            
            new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
            formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
            placeholders_dict = {
                "payment_date": formatted_date,
                "bill_id": formatted_bill_list,
                "transaction_id": reference,
                "payment_mode": mail_payment_mode,
                "total_amount": format_amount(total_bill_amount),
                "amount_paid": format_amount(amount),
                "due_amount": format_amount(total_amount_due),
                "user_name": customer_name,
                "receipt_link": receipt_url
            }
            logging.info(f"## webhook_response_handler placeholders_dict: {placeholders_dict}")
            placeholders_dict = {k: sanitize_string(str(v)) for k, v in placeholders_dict.items()}
            notification_result = send_email(
                template_name='Payment Successful',
                to_email=email,
                placeholder_value=placeholders_dict,
                subject_placeholders={},
                comments='Transaction Successful',
                customer_name=customer_name,
                account_number=account_number,
                tenant_id = tenant_id,
                is_html=True,
                billing_db_name = billing_platform_db
            )
            try:
                email_trigger_time = datetime.fromtimestamp(time.time())
                logging.info(f'email_trigger_time---------{email_trigger_time}')
                update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                logging.info(f"## webhook_response_handler update_status: {update_status}")
            except Exception as e:
                logging.error(f'## webhook_response_handler Error updating email trigger time: {e}')

        # update transaction status table
        payment_status_data = {'batch_status': status}
        if status == "Fail":
            payment_status_data['failed_data'] = str(result)
        if reference:
            payment_status_data['guid'] = reference
        billing_platform_db.update_dict('transaction_status', payment_status_data, {"id": str(bill_id)})

        # audit log
        audit_data_user_actions = {
            "service_name": "webhook_response_handler",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        message = 'Error occured in Webhook Handler'
        logging.error(f"## webhook_response_handler Error in webhook_response_handler: {e}")
        error_data = {
                "service_name": "webhook_response_handler",
                "error_message": message,
                "error_type": message,
                "users": 'System',
                "comments": json.dumps(data),
                "module_name": 'Payment History',
                "request_received_at": event_date.isoformat() if event_date else None,
                }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': message}

def webhook_response_handler_19_1(data):
    """
    Processes webhook transaction data received from a payment gateway (TRX), 
    updates billing platform database with payment and billing information, 
    manages customer account balances and ledgers, and triggers notification emails.

    Parameters
    ----------
    data : dict
        The webhook payload containing transaction results and reference information.
        Expected to have keys 'Result' and 'Reference' with transaction details.

    Returns
    -------
    dict
        A dictionary with:
        - 'flag': bool indicating if processing succeeded,
        - 'message': str providing success or error details.

    Overview
    --------
    The function performs these key operations:
    1. Extracts and parses the transaction data, including response code, reference IDs,
       payment amount, and transaction date/time.
    2. Determines payment status ("Success" or "Fail") based on response code.
    3. Retrieves related bill IDs and associated bill records.
    4. Fetches customer profile including account balance and contact info.
    5. For successful transactions:
       - Applies payment amount across bills, updating payments, remaining, and amount_due fields.
       - Updates the customer's account balance and amount due.
       - Creates ledger entries recording payment receipts.
       - Triggers a "Payment Successful" email notification (if enabled).
    6. For failed transactions:
       - Creates ledger entries recording payment failure.
       - Triggers a "Payment Failure" email notification (if enabled).
       - Does not modify bills or account balances.
    7. Saves all transaction history entries in the payment history table.
    8. Updates the transaction status in the database.
    9. Logs audit information regarding the webhook processing duration and details.
    """
    # function implementation here...

    logging.info("## webhook_response_handler function called")
    try:
        logging.info(f"## webhook_response_handler Received TRX transaction data: {data}")

        start_time = time.time()
        # billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # Extract key fields
        result = data.get('Result', {})
        reference_data = data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        bill_id = reference_data.get('PurchaseId', '')
        card_last_four = reference_data.get('LastFour', '')
        tran_date = reference_data.get('TranDate')
        tran_time = reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')

        category =  None
        mail_payment_mode = 'Card Payment'
        if account_brand.lower() == 'ach':
            category = 'ach'
            mail_payment_mode = 'ACH Payment'
            amount = None
        else:
            category = 'credit'
            amount = float(result.get('ApprovedAmount', '0'))

        # Name on card
        name_on_card = ""
        account_info = data.get("Account", {})
        first_name = account_info.get("FirstName", "")
        last_name = account_info.get("LastName", "")
        if first_name or last_name:
            name_on_card = f"{first_name} {last_name}".strip()
        # Fetch CustomFields
        agent = ""
        custom_fields = data.get("CustomFields", [])
        for field in custom_fields:
            if isinstance(field, dict) and field.get("Id") == "UserDefinedAgent":
                agent = field.get("Value", "")
                break
        # Fetch CustomFields (Agent, Billing DB Name, Tenant Name)
        agent = ""
        billing_db_name = None
        tenant_name = None

        custom_fields = data.get("CustomFields", [])
        logging.info(f"## webhook_response_handler custom_fields {custom_fields}")
        for field in custom_fields:
            if not isinstance(field, dict):
                continue
            field_id = field.get("Id")
            field_value = field.get("Value", "")
            if field_id == "UserDefinedAgent":
                agent = field_value
            elif field_id == "UserDefinedTenantDbName":
                billing_db_name = field_value
            elif field_id == "UserDefinedTenantName":
                tenant_name = field_value

        # Log and validate
        logging.info(f"## webhook_response_handler extracted custom fields: "
                    f"agent={agent}, billing_db_name={billing_db_name}, tenant_name={tenant_name}")

        # Validate Billing DB
        if not billing_db_name:
            logging.info(f"## webhook_response_handler billing_db_name is Empty")
            return {"flag":False,"message":"Billing DB Name is required"}
        tenant_db_config = db_connection_by_tenant_name(tenant_name, database)
        # Now use the billing_db_name when creating DB connection
        if tenant_db_config:
            logging.info(f"## webhook_response_handler tenant_db_config {tenant_db_config}")
            billing_platform_db = DB(billing_db_name, **tenant_db_config)
        else:
            logging.info(f"## webhook_response_handler Failed to establish database connection for tenant_name {tenant_name}")
            return {"flag": "False", "message": "Failed to establish database connection for tenant"}
        
        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
                # Convert to tenant's timezone
                # event_date = convert_to_tenant_timezone(event_date, tenant_name, database)
            except Exception as e:
                logging.warning(f"## webhook_response_handler Failed to parse transaction datetime: {e}")

        status = "Success" if response_code == "00" else "Fail"
        batch_list_df = billing_platform_db.get_data("transaction_status", {"id": str(bill_id)}, ["bill_list","bill_amount","credit_card_fee","created_by"])
        if not batch_list_df.empty:
            bill_list = batch_list_df['bill_list'].tolist()[0]
            bill_list = ast.literal_eval(bill_list) if bill_list else []
            bill_amount = batch_list_df['bill_amount'].tolist()[0] if batch_list_df['bill_amount'].tolist()[0] else 0
            credit_card_fee = float(batch_list_df['credit_card_fee'].tolist()[0] or 0)
            created_by = batch_list_df['created_by'].tolist()[0]
        else:
            created_by = ''
            bill_amount = 0
            bill_list = []
            credit_card_fee = 0
        if not amount:
            amount = bill_amount
        # Deduct credit card fee before splitting across bills
        amount_for_bills = float(amount) - float(credit_card_fee)
        if amount_for_bills < 0:
            amount_for_bills = 0
        bills_df = billing_platform_db.get_data('customer_bills', {'id': bill_list},
                                                 ["id", "payments", "total", "amount_due", 'remaining'],
                                                 {'created_date': 'asc'})
        if isinstance(bills_df, bool) or bills_df is None or bills_df.empty:
            bill_id_df = []
        else:
            bill_id_df = bills_df.to_dict(orient="records")

        account_number_df = billing_platform_db.get_data("customer_bills", {"id": bill_list[0]}, ["account_number"])
        account_number = str(account_number_df['account_number'].tolist()[0]) if not account_number_df.empty else ""

        # Handling of Payment method
        insert_id = payment_method_handler(storage_safe_data,account_number ,billing_platform_db ,reference_data , card_last_four , account_brand, category,name_on_card)
        # fetch customer info
        email, customer_name, tenant_name, tenant_id = '', '', '', None
        account_balance, account_amount_due = 0, 0
        if account_number:
            customer_profiles_df = billing_platform_db.get_data("customer_profiles", {"account_number": account_number},
                                                    ["sales_person", "email", "customer_name", "amount_due",
                                                     "tenant_name", "tenant_id", "account_balance"])
            if customer_profiles_df is not None and not customer_profiles_df.empty:
                email = customer_profiles_df['email'].tolist()[0]
                customer_name = customer_profiles_df['customer_name'].tolist()[0]
                account_amount_due = float(customer_profiles_df['amount_due'].tolist()[0])
                tenant_name = customer_profiles_df['tenant_name'].tolist()[0]
                tenant_id = customer_profiles_df['tenant_id'].tolist()[0]
                account_balance = float(customer_profiles_df['account_balance'].tolist()[0])

        transaction_history_rows = []
        total_bill_amount = 0
        total_amount_due = 0
        formatted_date = ""
        receipt_url = ""
        if status == "Success":
            logging.info(f"## webhook_response_handler Transaction Success Case")
            # ----------------------------
            # SPLIT AMOUNT ACROSS BILLS
            # ----------------------------
            amount_paid = amount_for_bills
            row_index = 0
            total_amount_due = 0
            total_bill_amount = 0
            while amount_paid > 0 and row_index < len(bill_id_df):
                bill_dict = bill_id_df[row_index]
                current_bill_id = bill_dict.get('id', '')
                payments = float(bill_dict.get('payments', 0))
                total = float(bill_dict.get('total', 0))
                amount_due = float(bill_dict.get('amount_due', 0))
                remaining = float(bill_dict.get('remaining', 0))
                total_bill_amount = total_bill_amount + total 

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining = 0
                    amount_due = 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0
                
                total_amount_due = total_amount_due + amount_due
                # update bill
                updated_data = {"payments": str(payments), "total": str(total),
                                "amount_due": str(amount_due), "remaining": str(remaining)}
                billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})
                bill_credit_card_fee = 0
                try:
                    # Calculate bill proportion based on total without fee
                    bill_proportion = amount_for_invoice / amount_for_bills if amount_for_bills else 0
                    # Calculate per-bill credit card fee
                    bill_credit_card_fee = round(credit_card_fee * bill_proportion, 2) if bill_proportion > 0 else 0
                except Exception as e:
                    logging.info(f"## webhook_response_handler Exceptinon occured as {e}")
                    bill_credit_card_fee = 0

                # ledger entry
                ledger_description = f'''Payment Received - Thank you!
                Amount Paid : ${amount_for_invoice}  Date : {event_date.strftime("%m-%d-%Y") if event_date else None}'''
                transaction_data = {
                    "ref": reference,
                    "status": 'Successful',
                    # "date": event_date.isoformat() if event_date else None,
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(bill_credit_card_fee),
                    "name_on_card": name_on_card,
                    "created_by": created_by
                }
                transaction_history_rows.append(transaction_data)
                row_index += 1

            # update account profile
            account_balance -= amount
            account_amount_due -= amount
            update_account_balance_data = {"account_balance": round(account_balance, 2),
                                          "amount_due": round(account_amount_due, 2)}
            billing_platform_db.update_dict('customer_profiles', update_account_balance_data, {"account_number": account_number})

            if transaction_history_rows:
                for tx in transaction_history_rows:
                    tx["account_balance"] = round(account_balance, 2)

            # Email trigger for success
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Successful"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                total_remaining = sum(float(item['remaining']) if 'remaining' in item else 0 for item in bill_id_df)
                # due_amount_is = total_remaining
                total_bill_amount = sum(float(item['total']) if 'total' in item else 0 for item in bill_id_df)
                due_amount_is = total_bill_amount - amount if total_bill_amount > amount else 0
                # try:
                #     receipt_dict = {
                #         "tenant_name": tenant_name,
                #         "tenant_id": tenant_id,
                #         "ref": reference
                #     }
                #     #calling generate_payment_receipt
                #     resp = generate_payment_receipt(receipt_dict)
                #     receipt_url = resp["download_url"]  
                #     logging.info(f'receipt_url------------{receipt_url}')
                # except Exception as e:
                #     logging.info(f'error when creating receipt link-----{e}')  
                # placeholders_dict = {
                #     "payment_date": formatted_date,
                #     "bill_id": bill_list,
                #     "transaction_id": reference,
                #     "payment_mode": mail_payment_mode,
                #     "total_amount": round(total_bill_amount, 2),
                #     "amount_paid": round(amount, 2),
                #     "due_amount": round(total_amount_due, 2),
                #     "user_name": customer_name,
                #     "receipt_link": f"{receipt_url}"
                # }
                # logging.info(f"## webhook_response_handler placeholders_dict: {placeholders_dict}")
                # notification_result = send_email(
                #     template_name='Payment Successful',
                #     to_email=email,
                #     placeholder_value=placeholders_dict,
                #     subject_placeholders={},
                #     comments='Transaction Successful',
                #     customer_name=customer_name,
                #     account_number=account_number,
                #     tenant_id = tenant_id
                # )
                # try:
                #     email_trigger_time = datetime.fromtimestamp(time.time())
                #     logging.info(f'email_trigger_time---------{email_trigger_time}')
                #     update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                #     logging.info(f"## webhook_response_handler update_status: {update_status}")
                # except Exception as e:
                #     logging.error(f'## webhook_response_handler Error updating email trigger time: {e}')

        else:  
            logging.info(f"## webhook_response_handler Transaction Failed Case")
            # Mark all bills with zero payment changes, just add failure entry in payment history
            ledger_description = f'''Payment Failed
            Amount : ${amount}   Date: {event_date.strftime("%m-%d-%Y") if event_date else None}'''
            for bill_dict in bill_id_df:
                current_bill_id = bill_dict.get('id', '')
                amount_due_value = float(bill_dict.get('amount_due', 0))
                transaction_data = {
                    "ref": reference,
                    "status": 'Failed',
                    # "date": event_date.isoformat() if event_date else None,
                    # "amount": str(amount),
                    "amount": str(amount_due_value),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee),
                    "name_on_card": name_on_card,
                    "created_by": created_by
                }
                transaction_history_rows.append(transaction_data)

            # No account balance or bills update on failure

            # Email trigger for failure
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Failure"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": round(amount, 2),
                    "user_name": customer_name,
                    "due_amount": round(account_amount_due, 2),
                }
                logging.info(f"## webhook_response_handler placeholders_dict: {placeholders_dict}")
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    billing_db_name = billing_platform_db
                )
                try:
                    email_trigger_time = datetime.fromtimestamp(time.time())
                    logging.info(f'email_trigger_time---------{email_trigger_time}')
                    update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Failure"})
                    logging.info(f"## webhook_response_handler update_status: {update_status}")
                except Exception as e:
                    logging.error(f'## webhook_response_handler Error updating email trigger time: {e}')

        # insert payment history
        if transaction_history_rows:
            logging.info(f"## webhook_response_handler transaction_history_rows: {transaction_history_rows}")
            insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
            logging.info(f"## webhook_response_handler insert_status: {insert_status}")
            try:
                receipt_dict = {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "ref": reference,
                    "billing_db_name": billing_db_name
                }
                #calling generate_payment_receipt
                resp = generate_payment_receipt(receipt_dict)
                logging.info(f'## generate_payment_receipt resp: {resp}')
                receipt_url = resp["download_url"]  
                logging.info(f'receipt_url------------{receipt_url}')
            except Exception as e:
                logging.info(f'error when creating receipt link-----{e}')  
            
            new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
            formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
            placeholders_dict = {
                "payment_date": formatted_date,
                "bill_id": formatted_bill_list,
                "transaction_id": reference,
                "payment_mode": mail_payment_mode,
                "total_amount": round(total_bill_amount, 2),
                "amount_paid": round(amount, 2),
                "due_amount": round(total_amount_due, 2),
                "user_name": customer_name,
                "receipt_link": receipt_url
            }
            logging.info(f"## webhook_response_handler placeholders_dict: {placeholders_dict}")
            placeholders_dict = {k: sanitize_string(str(v)) for k, v in placeholders_dict.items()}
            notification_result = send_email(
                template_name='Payment Successful',
                to_email=email,
                placeholder_value=placeholders_dict,
                subject_placeholders={},
                comments='Transaction Successful',
                customer_name=customer_name,
                account_number=account_number,
                tenant_id = tenant_id,
                is_html=True,
                billing_db_name = billing_platform_db
            )
            try:
                email_trigger_time = datetime.fromtimestamp(time.time())
                logging.info(f'email_trigger_time---------{email_trigger_time}')
                update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                logging.info(f"## webhook_response_handler update_status: {update_status}")
            except Exception as e:
                logging.error(f'## webhook_response_handler Error updating email trigger time: {e}')

        # update transaction status table
        payment_status_data = {'batch_status': status}
        if status == "Fail":
            payment_status_data['failed_data'] = str(result)
        if reference:
            payment_status_data['guid'] = reference
        billing_platform_db.update_dict('transaction_status', payment_status_data, {"id": str(bill_id)})

        # audit log
        audit_data_user_actions = {
            "service_name": "webhook_response_handler",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        message = 'Error occured in Webhook Handler'
        logging.error(f"## webhook_response_handler Error in webhook_response_handler: {e}")
        error_data = {
                "service_name": "webhook_response_handler",
                "error_message": message,
                "error_type": message,
                "users": 'System',
                "comments": json.dumps(data),
                "module_name": 'Payment History',
                "request_received_at": event_date.isoformat() if event_date else None,
                }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': message}

def build_elements_backup(batch_id, customer_name, customer_email, country, city, postal_code, telephone_number, agent, payment_types,payment_method , account_number, billing_platform_db , state,address_line_1):
    """
    Build PayPage Elements dynamically.
    Add StorageSafe fields only for Credit.
    """
    elements = [
        {"Id": "IndustryDataPurchaseId", "Required": "1", "Value": str(batch_id), "Visible": "1"},
        {"Id": "IndustryDataIndustry", "Required": "1", "Value": "CardNotPresent", "Visible": "1"},
        {"Id": "IndustryDataEci", "Required": "1", "Value": "7", "Visible": "1"},
        {"Id": "AccountFirstName", "Required": "1", "Value": customer_name, "Label": "Customer Name", "Visible": "1"},
        {"Id": "UserDefinedAgent", "Required": "0", "Value": agent, "Label": "Agent", "Visible": "1"},
        {"Id": "ShippingEmail", "Required": "0", "Value": customer_email, "Visible": "1"},
        {"Id": "ShippingPhone", "Required": "0", "Value": telephone_number, "Visible": "1"},
        {
            "Id": "ShippingEmail",
            "Required": "1",
            "Label": "Email",
            "Value": customer_email,
            "Visible": "1"
        },
        {
            "Id": "ShippingAddress",
            "Required": "0",
            "Label": "Address",
            "Value": address_line_1,
            "Visible": "1"
        },
        {
            "Id": "ShippingAddress2",
            "Required": "0",
            "Label": "Address 2",
            "Value": "",
            "Visible": "1"
        },
        {
            "Id": "ShippingCity",
            "Required": "0",
            "Label": "City",
            "Value": city,
            "Visible": "1"
        },
        {
            "Id": "ShippingPostal",
            "Required": "0",
            "Label": "Postal Code",
            "Value": postal_code,
            "Visible": "1"
        },
        {
            "Id": "ShippingCountry",
            "Required": "0",
            "Label": "Country",
            "Value": country,
            "Visible": "1"
        },
        {
            "Id": "ShippingRegion",
            "Required": "0",
            "Label": "State",
            "Value": state,
            "Visible": "1"
        }
    ]


    # Add StorageSafe only if Credit payment is enabled
    # if payment_method.lower() == "card payment":
    #     elements.extend([
    #         {"Id": "StorageSafeAccountGuid", "Required": "1", "Value": 'EWH3HG2WG6NKD3W', "Visible": "0"},
    #         {"Id": "StorageSafeGenerate", "Required": "1", "Value": "1", "Visible": "0"},
    #         {"Id": "StorageSafeGuid", "Required": "1", "Value": 'EWH3HG2WG6QBX3B', "Visible": "0"},
    #     ])
    # else:
    #     logging.info(f"## build_elements Payment method is not Credit: {payment_method}")
    #     elements.extend([
    #         {"Id": "StorageSafeAccountGuid", "Required": "0", "Value": 'EW6TWX5VG628030', "Visible": "0"},
    #         {"Id": "StorageSafeGenerate", "Required": "1", "Value": "0", "Visible": "0"},
    #         {"Id": "StorageSafeGuid", "Required": "0", "Value": '', "Visible": "0"},
    #     ])
    payment_method_df = billing_platform_db.get_data(
            "payment_methods",
            {"account_number": str(account_number), "default_payment": True},
            ["account_guid", "storage_safe_guid"]
        )
    if payment_method_df is not None and not payment_method_df.empty:
        row = payment_method_df.iloc[0]
        account_guid = str(row["account_guid"])
        storage_safe_guid = str(row["storage_safe_guid"])

        elements.extend([
            {
                "Id": "StorageSafeGenerate",
                "Required": "1",
                "Value": "0",  # don’t generate since we already have saved one
                "Visible": "0"
            },
            {
                "Id": "StorageSafeGuid",
                "Required": "1",
                "Value": storage_safe_guid,
                "Visible": "0"
            },
            {
                "Id": "StorageSafeAccountGuid",
                "Required": "1",
                "Value": account_guid,
                "Visible": "0"
            }
        ])
    else:
        # No saved payment method → use empty placeholders
        elements.extend([
            {
                "Id": "StorageSafeGenerate",
                "Required": "1",
                "Value": "1",  # generate new
                "Visible": "0"
            },
            {
                "Id": "StorageSafeGuid",
                "Required": "0",
                "Value": "",
                "Visible": "0"
            },
            {
                "Id": "StorageSafeAccountGuid",
                "Required": "0",
                "Value": "",
                "Visible": "0"
            }
        ])
    return {"Element": elements}


def build_elements(batch_id, customer_name, customer_email, country, city, postal_code, telephone_number, agent, payment_types,payment_method , account_number, billing_platform_db,state , address_line_1,tenant_name,billing_db_name):
    """
    Build PayPage Elements dynamically.
    Add StorageSafe fields only for Credit.
    """
    # elements = [
    #     {"Id": "IndustryDataPurchaseId", "Required": "1", "Value": str(batch_id), "Visible": "1"},
    #     {"Id": "IndustryDataIndustry", "Required": "1", "Value": "CardNotPresent", "Visible": "1"},
    #     {"Id": "IndustryDataEci", "Required": "1", "Value": "7", "Visible": "1"},
    #     {"Id": "AccountFirstName", "Required": "1", "Value": customer_name, "Label": "Customer Name", "Visible": "1"},
    #     {"Id": "UserDefinedAgent", "Required": "0", "Value": agent, "Label": "Agent", "Visible": "1"},
    #     {"Id": "ShippingEmail", "Required": "0", "Value": customer_email, "Visible": "1"},
    #     {"Id": "ShippingCountry", "Required": "1", "Value": country, "Visible": "1"},
    #     {"Id": "ShippingCity", "Required": "0", "Value": city, "Visible": "1"},
    #     {"Id": "ShippingPostal", "Required": "1", "Value": postal_code, "Visible": "1"},
    #     {"Id": "ShippingFirstName", "Required": "1", "Value": "", "Label": "First Name", "Visible": "1"},
    #     {"Id": "ShippingLastName", "Required": "1", "Value": "", "Label": "Last Name", "Visible": "1"},
    #     {"Id": "ShippingPhone", "Required": "0", "Value": telephone_number, "Visible": "1"},
    #     {
    #     "Id": "ShippingAddress",
    #     "Required": "0",
    #     "Label": "Address",
    #     "Value": address_line_1,
    #     "Visible": "1"
    #     },
    #     {
    #     "Id": "ShippingAddress2",
    #     "Required": "0",
    #     "Label": "Address 2",
    #     "Value": "",
    #     "Visible": "1"
    #     },
    #     {
    #     "Id": "ShippingRegion",
    #     "Required": "1",
    #     "Label": "State",
    #     "Value": state,
    #     "Visible": "1"
    #     }
    # ]
    elements = [
        {"Id": "IndustryDataPurchaseId", "Required": "1", "Value": str(batch_id), "Visible": "1"},
        {"Id": "IndustryDataIndustry", "Required": "1", "Value": "CardNotPresent", "Visible": "1"},
        {"Id": "IndustryDataEci", "Required": "1", "Value": "7", "Visible": "1"},
        {"Id": "AccountFirstName", "Required": "1", "Value": customer_name, "Label": "Customer Name", "Visible": "1"},
        {"Id": "UserDefinedAgent", "Required": "0", "Value": agent, "Label": "Agent", "Visible": "1"},
        {"Id": "UserDefinedTenantName", "Required": "0", "Value": tenant_name, "Label": "Tenant Name", "Visible": "1"},
        {"Id": "UserDefinedTenantDbName", "Required": "0", "Value": billing_db_name, "Label": "Tenant DB Name", "Visible": "0"},
        {"Id": "AccountEmail", "Required": "0", "Value": customer_email, "Visible": "1"},
        {"Id": "AccountCountry", "Required": "1", "Value": country, "Visible": "1"},
        {"Id": "AccountCity", "Required": "0", "Value": city, "Visible": "1"},
        {"Id": "AccountPostal", "Required": "1", "Value": postal_code, "Visible": "1"},
        {"Id": "AccountFirstName", "Required": "1", "Value": "", "Label": "First Name", "Visible": "1"},
        {"Id": "AccountLastName", "Required": "1", "Value": "", "Label": "Last Name", "Visible": "1"},
        {"Id": "AccountPhone", "Required": "0", "Value": telephone_number, "Visible": "1"},
        {"Id": "AccountAddress","Required": "0","Label": "Address","Value": address_line_1,"Visible": "1"},
        {"Id": "AccountAddress2","Required": "0","Label": "Address 2","Value": "","Visible": "1"},
        {"Id": "AccountRegion","Required": "1","Label": "State","Value": state,"Visible": "1"}
    ]

    # Add StorageSafe only if Credit payment is enabled
    # if payment_method.lower() == "card payment":
    #     elements.extend([
    #         {"Id": "StorageSafeAccountGuid", "Required": "1", "Value": 'EWH3HG2WG6NKD3W', "Visible": "0"},
    #         {"Id": "StorageSafeGenerate", "Required": "1", "Value": "1", "Visible": "0"},
    #         {"Id": "StorageSafeGuid", "Required": "1", "Value": 'EWH3HG2WG6QBX3B', "Visible": "0"},
    #     ])
    # else:
    #     logging.info(f"## build_elements Payment method is not Credit: {payment_method}")
    #     elements.extend([
    #         {"Id": "StorageSafeAccountGuid", "Required": "0", "Value": 'EW6TWX5VG628030', "Visible": "0"},
    #         {"Id": "StorageSafeGenerate", "Required": "1", "Value": "0", "Visible": "0"},
    #         {"Id": "StorageSafeGuid", "Required": "0", "Value": '', "Visible": "0"},
    #     ])
    
    payment_method_df = billing_platform_db.get_data(
            "payment_methods",
            {"account_number": str(account_number), "default_payment": True},
            ["account_guid", "storage_safe_guid"]
        )
    if payment_method_df is not None and not payment_method_df.empty:
        row = payment_method_df.iloc[0]
        account_guid = str(row["account_guid"])
        storage_safe_guid = str(row["storage_safe_guid"])

        elements.extend([
            {
                "Id": "StorageSafeGenerate",
                "Required": "1",
                "Value": "0",  # don’t generate since we already have saved one
                "Visible": "0"
            },
            {
                "Id": "StorageSafeGuid",
                "Required": "1",
                "Value": storage_safe_guid,
                "Visible": "0"
            },
            {
                "Id": "StorageSafeAccountGuid",
                "Required": "1",
                "Value": account_guid,
                "Visible": "0"
            }
        ])
    else:
        # No saved payment method → use empty placeholders
        elements.extend([
            {
                "Id": "StorageSafeGenerate",
                "Required": "1",
                "Value": "1",  # generate new
                "Visible": "0"
            },
            {
                "Id": "StorageSafeGuid",
                "Required": "0",
                "Value": "",
                "Visible": "0"
            },
            {
                "Id": "StorageSafeAccountGuid",
                "Required": "0",
                "Value": "",
                "Visible": "0"
            }
        ])
    return {"Element": elements}

def apply_cc_fee(payment_method, fee_setting, payment_type):
    """
    Determines if a credit card (CC) fee should be applied for a given payment attempt.

    The logic considers:
    - The user's payment method (must be credit card/card payment).
    - The system or tenant's fee configuration (applies to all, only manual, or only auto-debit CC payments).
    - The context of the payment (manual or auto-debit).

    Returns:
    - True if a CC fee is applicable based on conditions.
    - False if fee should not be applied or in case of any exception.

    Parameters:
    - payment_method (str): The payment method used (e.g., "Card Payment", "Credit Card").
    - fee_setting (str): Tenant's fee setting ("all cc payments", "only manual payments", "only auto-debit payments").
    - payment_type (str): Payment context ("manual", "auto-debit").
    """
    try:
        logging.info(f'## apply_cc_fee fucntion called with payment_method {payment_method} fee_setting {fee_setting} payment_type {payment_type}')
        # Normalize input for consistent case comparison and handling empty/null
        payment_method = (payment_method or "").strip().lower()
        fee_setting = (fee_setting or "").strip().lower()
        payment_type = (payment_type or "").strip().lower()

        # Apply fee only if the payment method is a credit card
        if payment_method != "card payment" and payment_method != "credit card":
            return False
        # Fee applies to all credit card payments
        if fee_setting == "all cc payments":
            return True
        # Fee applies only to manual CC payments
        elif fee_setting == "only manual payments" and payment_type == "manual":
            return True
        # Fee applies only to auto-debit CC payments
        elif fee_setting == "only auto-debit payments" and payment_type == "auto-debit":
            return True
        # For any other condition, do not apply fee
        return False
    except Exception as e:
        logging.info(f'## apply_cc_fee exception occured as e {e}')
        return False

def get_payment_token(data):
    """
    Sends Initialize PayPage request to TRX and returns payment URL.
    """
    logging.info(f'## get_payment_token called with data {data}')
    start_time = time.time()

    # UI Input Variables
    tenant_name = data.get("tenant_name","")
    tenant_id = data.get("tenant_id","")
    created_by = data.get("username", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("sessionID", "")
    module_name = data.get("module_name", "Payment History")
    credit_card_fee_flag = data.get("credit_card_fee", data.get("credit_card_flag",False))
    invoice_id = str(data.get("bill_id", ""))
    amount_from_invoice = data.get("item_amount", 0)
    account_number = data.get("account_number", "")
    agent = data.get("agent", "")
    payment_method = data.get('payment_method','Card Payment')
    billing_db_name = data.get('billing_db_name',None)

    # ENV Variables
    merchant_key = os.environ.get("merchant_key", "")
    merchant_secret = os.environ.get("merchant_secret", "")
    payment_trigger_url = os.environ.get("payment_trigger_url", "")
    response_url = os.environ.get("response_url", "")
    approval_url = os.environ.get("approval_url", "")
    rejected_url = os.environ.get("rejected_url", "")
    post_url = os.environ.get("post_url", "")
    guid = os.environ.get("Guid", "")
    trx_client_id = os.environ.get("trx_client_id", "")
    trx_current_code = os.environ.get("trx_current_code", "")
    trx_session_time = os.environ.get("trx_session_time", "")
    mode = os.getenv('ENV', '')

    # Amount validation
    if float(amount_from_invoice) <= 0:
        return {"flag": False, "message": "Amount is Invalid"}
    # Tenant ID Validation
    if not tenant_id:
        return {"flag": False, "message": "Tenant ID is Invalid"}
    
    # Tenant Name Validation
    if not tenant_name:
        return {"flag": False, "message": "Tenant Name is Required"}

    # DB Name Validation
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    
    required_env_vars = ['merchant_key', 'merchant_secret', 'payment_trigger_url', 'response_url', 'approval_url', 'rejected_url', 'post_url', 'Guid','trx_client_id','trx_current_code','trx_session_time']
    for env_var in required_env_vars:
        if not os.environ.get(env_var):
            return {"flag": False, "message": f"{env_var} is not set in environment variables"}
    # DB connections
    billing_platform_db = DB(billing_db_name, **db_config)
    common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)


    if mode == 'UAT':
        if tenant_id in  ['212',212]:
            tenant_name = 'Altaworx'
            tenant_id = '1'


    credit_card_fee_value = 0  # default

    # Step 1: Check for Card Payment
    if payment_method.lower() == "card payment" and credit_card_fee_flag:
        tenant_id_condition = {"sub_tenant_id": tenant_id}

        # Step 2: Get fee_setting (enable_credit_card_fee_type) from default_settings
        default_settings_df = billing_platform_db.get_data(
            "default_settings",
            tenant_id_condition,
            ["enable_credit_card_fee_type", "credit_card_fee"]
        )

        fee_setting = ""
        default_fee_percentage = 0
        if default_settings_df is not None and not default_settings_df.empty:
            fee_setting = str(default_settings_df.iloc[0].get("enable_credit_card_fee_type") or "").strip()
            default_fee_percentage = float(default_settings_df.iloc[0].get("credit_card_fee") or 0)
            logging.info(f"## get_payment_token: Found fee_setting={fee_setting}, default_fee_percentage={default_fee_percentage}")
        else:
            logging.info("## get_payment_token: No enable_credit_card_fee_type found in default_settings")

        # Step 3: Decide if fee applies (payment_type fixed as manual)
        if apply_cc_fee(payment_method, fee_setting, "manual"):
            # Step 4: Try fetching fee percentage from customer_profiles
            customer_fee_df = billing_platform_db.get_data(
                "customer_profiles",
                {"account_number": str(account_number)},
                ["credit_card_fee"]
            )

            fee_percentage = 0
            if customer_fee_df is not None and not customer_fee_df.empty:
                fee_percentage_value = customer_fee_df.iloc[0].get("credit_card_fee")
                if fee_percentage_value is not None:
                    fee_percentage = float(fee_percentage_value)
                else:
                    fee_percentage = default_fee_percentage
                # fee_percentage = float(customer_fee_df.iloc[0].get("credit_card_fee") or 0)
                logging.info(f"## get_payment_token: Found customer-specific credit_card_fee {fee_percentage}%")
            else:
                fee_percentage = default_fee_percentage
                logging.info(f"## get_payment_token: Using default credit_card_fee {fee_percentage}%")

            # Step 5: Apply fee if > 0
            if fee_percentage > 0:
                credit_card_fee_value = round((float(amount_from_invoice) * fee_percentage) / 100, 2)
                amount_from_invoice = f"{(float(amount_from_invoice) + credit_card_fee_value):.2f}"
                logging.info(f"## get_payment_token: Applied credit card fee {credit_card_fee_value} ({fee_percentage}%)")
            else:
                logging.info("## get_payment_token: No credit card fee applied (fee_percentage=0)")
        else:
            logging.info(f"## get_payment_token: apply_cc_fee returned False, skipping fee application (fee_setting={fee_setting})")



    # Insert batch
    # batch_data = {"batch_status": "Pending", "bill_list": invoice_id}
    # batch_data = {"batch_status": "Pending", "bill_list": invoice_id, "bill_amount": amount_from_invoice ,"payment_type":payment_method}
    batch_data = {"batch_status": "Pending", "bill_list": invoice_id, "bill_amount": amount_from_invoice ,"payment_type":payment_method, "credit_card_fee": credit_card_fee_value, "account_number":account_number, "created_by":created_by}
    batch_id = billing_platform_db.insert_data(batch_data, "transaction_status")

    # Customer lookup
    customer_profiles_df = billing_platform_db.get_data(
        "customer_profiles",
        {"account_number": str(account_number)},
        ["email", "customer_name", "country", "city", "postal_code", "telephone_number", "sales_person","state" , "address_line_1"],
    )
    customer_name = customer_email = city = country = postal_code = telephone_number = sales_person = state = address_line_1 = ""

    if customer_profiles_df is not None and not customer_profiles_df.empty:
        row = customer_profiles_df.iloc[0]
        customer_name = str(row["customer_name"])
        customer_email = str(row["email"])
        country = str(row["country"])
        city = str(row["city"])
        postal_code = str(row["postal_code"])
        telephone_number = str(row["telephone_number"])
        sales_person = str(row["sales_person"])
        state = str(row["state"])
        address_line_1 = str(row["address_line_1"])

    if not agent and sales_person:
        agent = sales_person
    
    # Payment Types (default = Credit + ACH + Finance)
    payment_types = data.get("payment_types", [
        {"TranType": "Ach"},
        {"TranType": "Finance"},
        # {"TranType": "Credit", "CardType": ["Visa", "MasterCard", "Amex", "Discover"], "GooglePay": "0", "ApplePay": "1"}
        {"TranType": "Credit", "CardType": ["Visa", "MasterCard", "Amex", "Discover"]}
    ])

    # Build payload
    payload = {
        "Message": {
            "Request": {
                "PayPage": {
                    "Guid": guid,
                    "Session": {
                        "TimeToLive": trx_session_time,
                        "Style": {
                            "bodyBg": "#FFFFFF",  # White main background
                            "mainColor": "#2563EB",  # Primary Blue (Pay Now button)
                            "titleColor": "#111827",  # Dark gray text
                            "subTitleColor": "#6B7280",  # Muted gray
                            "formBg": "#F9FAFB",  # Light gray for input boxes
                            "formBorder": "#E5E7EB",
                            "buttonPrimaryBg": "#2563EB",  # Blue button
                            "buttonPrimaryColor": "#FFFFFF",
                            "buttonPrimaryHoverBg": "#1D4ED8",
                            "buttonPrimaryHoverColor": "#FFFFFF",
                            "buttonSecondaryBg": "#F3F4F6",  # Light gray secondary button
                            "buttonSecondaryColor": "#374151",
                            "buttonSecondaryHoverBg": "#E5E7EB",
                            "buttonSecondaryHoverColor": "#111827",
                            "billingBg": "#FFFFFF",
                            "billingMainColor": "#2563EB"
                            },
                        "Elements": build_elements(batch_id, customer_name, customer_email, country, city, postal_code, telephone_number, agent, payment_types,payment_method ,account_number,billing_platform_db , state,address_line_1,tenant_name,billing_db_name),
                        # "SoftDescriptors": {
                        #     "MerchantPhone": "1-800-123-4567",
                        #     "MerchantName": "Test Store",
                        #     "MerchantState": "NY"
                        # },
                        "Detail": {
                            "Amount": amount_from_invoice,
                            "TranAction": "Sale",
                            "CurrencyCode": trx_current_code
                        },
                        "Processing": {
                            "Verbose": "1",
                            "EnableShipping": "0",
                            "EnableBilling": "1",
                            "EnableBillingSummary": "1",
                            "EnableSectionHeaders": "0",
                            "ResponseUrl": response_url,
                            "ApprovalUrl": approval_url,
                            "RejectedUrl": rejected_url
                        },
                        "PaymentTypes": {"PaymentType": payment_types},
                        "Locale": "en-US"
                    }
                },
                "Detail": {"TranType": "PayPage", "TranAction": "Initialize"}
            }
        }
    }
    logging.info(f'## get_payment_token TRX Request Payload {json.dumps(payload)}')

    try:
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
    except requests.RequestException as e:
        logging.error(f'## get_payment_token TRX Request Error {e}')
        failed_data = {"batch_id": batch_id, "error_text": str(e)}
        error_data = {
            "service_name": "get_payment_token",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": f"Request error: {str(e)}"}

    # Parse response
    try:
        res_json = response.json()
        logging.info(f'## get_payment_token TRX Response {res_json}')
        result_code = res_json["Message"]["Response"]["Result"]["ResponseCode"]

        if result_code == "00":
            guid = res_json["Message"]["Response"]["PayPage"]["Guid"]
            session = res_json["Message"]["Response"]["PayPage"]["Session"]
            payment_url = f"{payment_trigger_url}/?clientId={trx_client_id}&paypage={guid}&session={session}"
            logging.info(f'## get_payment_token TRX Payment URL {payment_url}')
            token_data = {"token": payment_url, "batch_id": batch_id}
            audit_data_user_actions = {
                "service_name": "get_payment_token",
                "created_by": created_by,
                "status": "Success",
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(token_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
            return {"flag": True, "token": payment_url, "batch_id": batch_id}

        # TRX returned error
        error_text = res_json["Message"]["Response"]["Result"].get("ResponseText", "Unknown error")
        logging.error(f'##  get_payment_token TRX Error {error_text}')
        failed_data = {"batch_id": batch_id, "error_response": res_json}
        error_data = {
            "service_name": "get_payment_token",
            "error_message": error_text,
            "error_type": str(type(error_text).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": f"TRX error: {error_text}"}

    except (KeyError, TypeError, ValueError) as e:
        logging.error(f'## get_payment_token TRX Parse Error {e}')
        failed_data = {"batch_id": batch_id}
        error_data = {
            "service_name": "get_payment_token",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "token": "Invalid response format"}

def fetch_transaction_status(data):
    """
    Retrieves and updates the transaction status for a given bill ID from the billing database, 
    retrying with exponential backoff if not found. Returns a success message if the transaction is successful, 
    a failure message if unsuccessful, or an error if the bill ID is not found.

    Args:
        data (dict): A dictionary containing the following keys:
            - username (str, optional): The username associated with the transaction. Defaults to an empty string.
            - table_name (str, optional): The database table to query. Defaults to "payment_history".
            - bill_id (str): The bill ID for which the transaction status needs to be retrieved.

    Returns:
        dict: A dictionary containing:
            - flag (bool): True if the transaction is successful, False otherwise.
            - message (str): A descriptive message about the transaction status.
    """
    logging.info(f'## fetch_transaction_status function called with data {data}')
    batch_id = data.get("batch_id", "")
    reference_guid = data.get("reference", "")
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    if not batch_id:
        return {"flag": False, "message": "Batch ID is Empty"}
    if not reference_guid:
        return {"flag": False, "message": "Reference Guid is Empty"}

    try:
        billing_platform_db = DB(billing_db_name, **db_config)
    except Exception as e:
        print(f"Database connection failed: {e}")
        return {"flag": False, "message": "Database connection error"}

    retries = 3
    delay = 2  # seconds exponential backoff
    message = 'Transaction is Pending'
    flag = True

    for attempt in range(retries):
        try:
            batch_id_df = billing_platform_db.get_data('transaction_status', {"id": batch_id}, ["batch_status", "failed_data"])
            if batch_id_df is not None and not batch_id_df.empty:
                batch_status = str(batch_id_df['batch_status'].tolist()[0])
                failed_data_raw = batch_id_df['failed_data'].tolist()[0] if 'failed_data' in batch_id_df.columns else None

                print(f'## fetch_transaction_status batch_status attempt {attempt+1}: {batch_status}')

                if batch_status == 'Success':
                    message = "Transaction Successful"
                    break
                elif batch_status == 'Fail':
                    message = "Transaction Failed"
                    flag = False
                    # Parse failed_data JSON string safely if it's set
                    failed_data = None
                    if failed_data_raw:
                        try:
                            failed_data = ast.literal_eval(failed_data_raw) if isinstance(failed_data_raw, str) else failed_data_raw
                        except Exception as ex:
                            print(f"Error parsing failed_data: {ex}")
                    return {
                        'flag': False,
                        'message': message,
                        'failed_data': failed_data
                    }
                else:
                    print(f"## fetch_transaction_status Transaction is pending, retrying ({attempt+1}/{retries})...")
                    time.sleep(delay)
                    delay *= 2
            else:
                print(f"## fetch_transaction_status Transaction not found, retrying ({attempt+1}/{retries})...")
                time.sleep(delay)
                delay *= 2
        except Exception as e:
            print(f"## fetch_transaction_status Error retrieving transaction data (attempt {attempt+1}): {e}")
            time.sleep(delay)
            delay *= 2

    return {'flag': flag, "message": message}

def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    billing_platform_database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    
    # Extract relevant details from the input data dictionary
    main_module_name=data.get("main_module_name", "Customer Profiles")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")
    parent_module_name = data.get("parent_module", "Billing Platform")

    try:
        logging.info(f"tenant_name is-----{tenant_name}")
        # Retrieve tenant ID based on tenant name
        tenant_id = database.get_data(
            "tenant", {"tenant_name": tenant_name},["id"]
        )["id"].to_list()[0]
    except Exception as e:
        logging.warning(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = billing_platform_database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": main_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, main_module_name, database, parent_module_name, role
                )

        except Exception as e:
            logging.exception(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        if module_name in ["Customer Services Carrier","Customer Services Customer"]:
            module_name = "Customer Services"
        ret_out[module_name] = headers

    return ret_out



def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name, role
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        logging.debug("Raw user features fetched: %s", user_features_raw)

        if not user_features_raw or user_features_raw[0] is None:
            query=f'''select module_features from role_module where role='{role}'
            '''
            user_features_raw=common_utils_database.execute_query(query,True)["module_features"].to_list()  # Convert the result to a list
        
        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  
        
        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  

    except Exception as e:
        # Catch any exceptions and log a warning
        logging.warning("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def data_update_db(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        print(f'INchanged_data---------{changed_data}---{unique_id}------{table_name}')

        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            print(f"***update_data {update_data}")
            # Perform the update operation
            db.update_dict(table_name, update_data, {"id": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at','date']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict

def data_update_db_account_number(changed_data,unique_id,table_name,db):
    """
    Updates the data in the specified database table based on the provided `unique_id` and `changed_data`. The function
    filters out any `None` or `"None"` values from the data, excluding columns like "unique_col" and "id" from the
    update process, and then performs the update in the database.

    Args:
        changed_data (dict): A dictionary containing the columns and values to be updated in the database.
        unique_id (int): The unique identifier of the record to be updated.
        table_name (str): The name of the table where the update should be applied.
        db (object): The database object that facilitates database operations.

    Returns:
        bool: Returns `True` if the update was successful, otherwise `False`.
    """

    try:
        if unique_id is not None:
            # Filter out values that are None or "None"
            changed_data = {
                k: v
                for k, v in changed_data.items()
                if v is not None and v != "None"
            }

            # Prepare the update data excluding unique columns
            update_data = {
                key: value
                for key, value in changed_data.items()
                if key != "unique_col" and key != "id"
            }
            print(f"***update_data {update_data}")
            # Perform the update operation
            db.update_dict(table_name, update_data, {"account_number": unique_id})
        return True
    except Exception as e:
        logging.exception(f"Exception occured while updating data ..{e}")
        return False

def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object

def current_cycle_calculate(created_date, bill_cycle_start_date):
    if not isinstance(created_date, datetime):
        created_date = datetime.strptime(str(created_date), "%Y-%m-%d")
        logging.info(f"### created_date: {created_date}")
    if not isinstance(bill_cycle_start_date, datetime):
        bill_cycle_start_date = datetime.strptime(str(bill_cycle_start_date), "%Y-%m-%d")
        logging.info(f"### bill_cycle_start_date: {bill_cycle_start_date}")

    cycle_start = bill_cycle_start_date

    while True:
        next_cycle_start = cycle_start + relativedelta(months=1)

        # If created_date falls within current cycle interval, return created_date as cycle start
        # if cycle_start <= created_date < next_cycle_start:
        #     logging.info(f"### current_cycle: created_date {created_date} in cycle {cycle_start} to {next_cycle_start}")
        #     return created_date

        # Otherwise increment cycle_start to next cycle
        if next_cycle_start > created_date:
            logging.info(f"### current_cycle: cycle_start exceeded created_date, returning {cycle_start}")
            return cycle_start

        cycle_start = next_cycle_start

def fetch_payment_methods(data):
    """
    Retrieves all payment methods for a given account_number and identifies the default payment method.
    Returns sample:
        {
            "payment_methods": [
                {
                    "number": "XXXXXXXXXX1234",
                    "type": "Visa",
                    "expiry": "03/31",
                },
                ...
            ],
            "default_method": {
                "number": "XXXXXXXXXX1234",
                "type": "Visa",
                "expiry": "03/31",
            }
        }
    """
    logging.info(f'## fetch_payment_methods function called with data {data}')
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}

    try:
        account_number = data.get('account_number','')
        if not account_number:
            return {'flag': False, 'message': 'Account Number Required'}
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        if account_number:
            logging.info(f"## billing_collections_bills_list_view account_number is {account_number}")
            customer_profiles=billing_platform_db.get_data("customer_profiles",{"account_number":account_number},["id","bill_cycle_start_date","account_balance", "account_type", "customer_address_text","created_date"]).to_dict(orient="records")
            customer_profiles=customer_profiles[0]
            bill_cycle_start_date = customer_profiles.get("bill_cycle_start_date",None)
            created_date = customer_profiles.get("created_date", None)
            customer_profile_id=customer_profiles.get("id",None)
        cycle_start_date = current_cycle_calculate(created_date, bill_cycle_start_date)
        
        # Format cycle_start_date as string (e.g. MM-DD-YYYY or YYYY-MM-DD)
        if cycle_start_date:
            cycle_str = cycle_start_date.strftime("%m-%d-%Y")  # or "%Y-%m-%d" as per your preference
        else:
            cycle_str = ""
        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
        today = datetime.now(pytz.timezone(tenant_time_zone)).date()
        all_bills = billing_platform_db.get_data(
            table_name="customer_bills",
            condition={"customer_profile_id": customer_profile_id, "is_active": True},
            columns=["remaining", "due_date_of_this_bill"]
        ).to_dict(orient="records")
        overdue_amount = 0.0
        for bill in all_bills:
            remaining = bill.get("remaining") or 0
            due_date = bill.get("due_date_of_this_bill")
            if remaining >= 0 and due_date:
                if isinstance(due_date, str):
                    due_date = datetime.strptime(due_date, "%Y-%m-%d").date()
                elif isinstance(due_date, datetime):
                    due_date = due_date.date()
                if due_date < today:
                    overdue_amount += float(remaining or 0)

        user_profile_details={
                "Balance": "{:,.2f}".format(customer_profiles.get('account_balance') or 0),
                "Account Type": customer_profiles.get('account_type',''),
                "Overdue": "{:,.2f}".format(overdue_amount),
                "Address": customer_profiles.get('customer_address_text',''),
                # "Cycle": format_cycle_date(bill_cycle_start_date)
                "Cycle": cycle_str
            }
        if account_number:
            account_status_query = billing_platform_db.get_data(
            "customer_profiles",
            {"account_number": str(account_number)},
            ["is_active"]
        ).to_dict(orient='records')
        if account_status_query:
            account_status = account_status_query[0]['is_active']
        methods_df = billing_platform_db.get_data(
            "payment_methods",
            {"account_number": str(account_number),"is_active":True},
            ["last_four", "payment_method", "expiry_date", "default_payment","id"],
            {'id':'DESC'}
        )

        payment_methods = []
        default_method = None

        if methods_df is not None and not methods_df.empty:
            logging.info(f'## fetch_payment_methods methods_df {methods_df}')
            for _, row in methods_df.iterrows():
                method = {
                    "number": f"XXXXXXXXXX{row['last_four']}",  # Masked number format
                    "type": row["payment_method"],
                    "expiry": row["expiry_date"],
                    "id":row["id"]
                }
                payment_methods.append(method)
                # Robust check for boolean default field
                if str(row.get("default_payment", "0")).lower() in ("1", "true", "yes"):
                    default_method = method
        if not payment_methods:
            return {
                'flag': True,
                'Validation': True,
                'message': 'This account has no saved payment methods',
                'payment_methods': [],
                'default_method': None,
                'user_profile_details' : user_profile_details
            }
        return {
            'flag': True,
            'message': 'Payment Methods Fetched Successfully',
            "payment_methods": payment_methods,
            "default_method": default_method,
            "account_status": account_status,
            "user_profile_details": user_profile_details
        }
    except Exception as e:
        logging.info(f'## fetch_payment_methods Error occurred while fetching payment methods: {e}')
        return {
            'flag': False,
            'message': 'Failed to fetch Payment Methods',
            'payment_methods': [],
            'default_method': None
        }


def fetch_payment_methods_29(data):
    """
    Retrieves all payment methods for a given account_number and identifies the default payment method.
    Returns sample:
        {
            "payment_methods": [
                {
                    "number": "XXXXXXXXXX1234",
                    "type": "Visa",
                    "expiry": "03/31",
                },
                ...
            ],
            "default_method": {
                "number": "XXXXXXXXXX1234",
                "type": "Visa",
                "expiry": "03/31",
            }
        }
    """
    logging.info(f'## fetch_payment_methods function called with data {data}')
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}

    try:
        account_number = data.get('account_number','')
        if not account_number:
            return {'flag': False, 'message': 'Account Number Required'}
        
        billing_platform_db = DB(billing_db_name, **db_config)
        if account_number:
            account_status_query = billing_platform_db.get_data(
            "customer_profiles",
            {"account_number": str(account_number)},
            ["is_active"]
        ).to_dict(orient='records')
        if account_status_query:
            account_status = account_status_query[0]['is_active']
        methods_df = billing_platform_db.get_data(
            "payment_methods",
            {"account_number": str(account_number),"is_active":True},
            ["last_four", "payment_method", "expiry_date", "default_payment","id"],
            {'id':'DESC'}
        )

        payment_methods = []
        default_method = None

        if methods_df is not None and not methods_df.empty:
            logging.info(f'## fetch_payment_methods methods_df {methods_df}')
            for _, row in methods_df.iterrows():
                method = {
                    "number": f"XXXXXXXXXX{row['last_four']}",  # Masked number format
                    "type": row["payment_method"],
                    "expiry": row["expiry_date"],
                    "id":row["id"]
                }
                payment_methods.append(method)
                # Robust check for boolean default field
                if str(row.get("default_payment", "0")).lower() in ("1", "true", "yes"):
                    default_method = method
        if not payment_methods:
            return {
                'flag': True,
                'Validation': True,
                'message': 'This account has no saved payment methods',
                'payment_methods': [],
                'default_method': None
            }
        return {
            'flag': True,
            'message': 'Payment Methods Fetched Successfully',
            "payment_methods": payment_methods,
            "default_method": default_method,
            "account_status": account_status
        }
    except Exception as e:
        logging.info(f'## fetch_payment_methods Error occurred while fetching payment methods: {e}')
        return {
            'flag': False,
            'message': 'Failed to fetch Payment Methods',
            'payment_methods': [],
            'default_method': None
        }

def update_default_payment_method(data):
    """
    Updates the default payment method for an account.
    If payment_method is empty, only resets old default payment methods.
    Args:
        data (dict): Payload containing account_number and changed_data.
    Returns:
        dict: {'flag': True/False, 'message': str}
    """
    logging.info(f'## update_default_payment_method called with data {data}')
    try:
        start_time = time.time()

        # Extract parameters
        tenant_name = data.get("tenant_name")
        created_by = data.get("firstLastName", "")
        request_received_at = data.get("request_received_at", "")
        session_id = data.get("sessionID", "")
        module_name = data.get("module_name", "Payment Profiles")
        account_number = data.get('account_number','')
        changed_data = data.get('changed_data','')
        payment_method = changed_data.get('payment_method', {})
        billing_db_name = data.get('billing_db_name',None)

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}

        # Validate account_number
        if not account_number:
            return {'flag': False, 'message': 'Account number is required'}

        # DB Connections
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # Step 1: Reset all payment methods for this account
        old_method_update_status = billing_platform_db.update_dict(
            "payment_methods",
            {"default_payment": False},
            {"account_number": str(account_number)}
        )

        # Step 2: If payment_method is provided, set it as default
        new_method_update_status = False
        if payment_method and all(k in payment_method for k in ("number", "type", "expiry")):
            last_four = payment_method['number'][-4:]
            pm_type = payment_method['type']
            expiry = payment_method['expiry']

            new_method_update_status = billing_platform_db.update_dict(
                "payment_methods",
                {"default_payment": True},
                {
                    "account_number": str(account_number),
                    "last_four": last_four,
                    "payment_method": pm_type,
                    "expiry_date": expiry
                }
            )

        # Step 3: Log audit and return response
        audit_data_user_actions = {
            "service_name": "update_default_payment_method",
            "created_by": created_by,
            "status": "Success" if old_method_update_status else "Failed",
            "time_consumed_secs": int(time.time() - start_time),
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(changed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")

        if payment_method and not new_method_update_status:
            message = 'No matching payment method found to set as default'
            logging.info(f'## update_default_payment_method {message}')
            error_data = {
                "service_name": "update_default_payment_method",
                "error_message": message,
                "error_type": 'Empty Data',
                "users": created_by,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(changed_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {'flag': False, 'message': message}

        return {'flag': True, 'message': 'Default payment methods updated successfully'}

    except Exception as e:
        logging.error(f'## update_default_payment_method error: {e}')
        error_data = {
            "service_name": "update_default_payment_method",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': 'Failed to update default payment method.'}



def delete_payment_method(data):
    """
    Deactivates (soft deletes) a payment method for an account.
    Performs audit logging for both success and errors.
    Args:
        data (dict): Must include:
            - account_number (str)
            - payment_method (dict) with keys:
                "number" (masked, last 4 digits), "type", "expiry"
    Returns:
        dict: { 'flag': True, 'message': "Payment method deactivated." }
    """
    logging.info(f'## delete_payment_method called with data {data}')
    try:
        start_time = time.time()

        # Metadata for auditing
        tenant_name = data.get("tenant_name")
        created_by = data.get("firstLastName", "")
        request_received_at = data.get("request_received_at", "")
        session_id = data.get("sessionID", "")
        module_name = data.get("module_name", "Payment Profiles")
        account_number = data.get('account_number','')
        changed_data = data.get('changed_data','')
        payment_method = changed_data.get('payment_method','')
        billing_db_name = data.get('billing_db_name',None)

        # Validations
        if not account_number:
            return {'flag': False, 'message': 'Account number is required'}
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        if not payment_method:
            return {'flag': False, 'message': 'Payment method details are required'}
        if not all(k in payment_method for k in ("number", "type", "expiry")):
            return {'flag': False, 'message': 'Incomplete payment method details'}

        last_four = payment_method['number'][-4:]
        pm_type = payment_method['type']
        expiry = payment_method['expiry']

        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

        update_status = billing_platform_db.update_dict(
            "payment_methods",
            {"is_active": False},
            {
                "account_number": str(account_number),
                "last_four": last_four,
                "payment_method": pm_type,
                "expiry_date": expiry
            }
        )

        if update_status:
            # Success audit logging
            audit_data_user_actions = {
                "service_name": "delete_payment_method",
                "created_by": created_by,
                "status": "Success",
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(payment_method),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
            return {'flag': True, 'message': 'Payment method deactivated successfully.'}
        else:
            # Failure audit logging
            message = 'No matching payment method found to deactivate.'
            logging.info(f'## delete_payment_method {message}')
            error_data = {
                "service_name": "delete_payment_method",
                "error_message": message,
                "error_type": 'Empty Data',
                "users": created_by,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(payment_method),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {'flag': False, 'message': message}

    except Exception as e:
        logging.error(f'## delete_payment_method error: {e}')
        # Exception error audit logging
        error_data = {
            "service_name": "delete_payment_method",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("firstLastName", ""),
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": json.dumps(data),
            "module_name": data.get("module_name", "Payment Profiles"),
            "request_received_at": data.get("request_received_at", ""),
        }
        try:
            common_utils_db.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f'## delete_payment_method error while logging audit: {log_e}')
        return {'flag': False, 'message': 'Failed to deactivate payment method.'}


def void_transaction(transaction_guid, post_url, merchant_key, merchant_secret, bp_common_utils_db, created_by='System', tenant_name=None, session_id=None, module_name='Payment Cancellation',request_received_at = None):
    """
    Calls the payment gateway to VOID a transaction.

    On success, returns the request payload and JSON response.
    On failure, logs detailed error information to error_log_table with user, tenant, session, and request context.

    Parameters:
    - transaction_guid (str): Unique ID of the transaction to void.
    - post_url (str): TRX API endpoint URL.
    - merchant_key (str): Merchant key for basic auth.
    - merchant_secret (str): Merchant secret for basic auth.
    - billing_platform_db (DB): Database connection for logging.
    - created_by (str): User who initiated the void (default 'System').
    - tenant_name (str|None): Tenant identifier.
    - session_id (str|None): Session tracking ID.
    - module_name (str): Logical module name for logging context.
    - request_received_at (str|None): Request timestamp for auditing.

    Returns:
    - tuple: (payload dict, response JSON) if successful.
    - bool False on failure.
    """
    logging.info(f"## void_transaction fucntion called with transaction_guid {transaction_guid}")
    payload = {
        "Message": {
            "Request": {
                "Detail": {
                    "TranType": "Credit",
                    "TranAction": "Void"
                },
                "Reference": {
                    "Guid": transaction_guid
                }
            }
        }
    }
    logging.info(f"## void_transaction payload: {payload}")
    try:
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
        res_json = response.json()
        logging.info(f"## void_transaction res_json: {res_json}")
        return res_json

    except Exception as e:
        failed_data = {'transaction_id':transaction_guid}
        # Error log
        error_data = {
            "service_name": "void_transaction",
            "error_message": str(e),
            "error_type": str(type(str(e)).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        logging.error(f"## void_transaction error: {e}")
        return False


def return_transaction(transaction_guid, amount, currency_code, post_url, merchant_key, merchant_secret, bp_common_utils_db, created_by='System', tenant_name=None, session_id=None, module_name='Payment Cancellation', request_received_at=None):
    """
    Calls the payment gateway to RETURN (refund) a transaction.

    On success, returns the request payload and JSON response.
    On failure, logs detailed error information to error_log_table with contextual data.

    Parameters and returns are similar to void_transaction, with additional:
    - amount (float): Amount to refund.
    - currency_code (str): Currency code for refund.

    Returns:
    - tuple: (payload dict, response JSON) if successful.
    - bool False on failure.
    """
    logging.info(f"## return_transaction transaction_guid - {transaction_guid} amount - {amount} currency_code - {currency_code}")
    payload = {
        "Message": {
            "Request": {
                "Detail": {
                    "TranType": "Credit",
                    "TranAction": "Return",
                    "Amount": str(amount),
                    "CurrencyCode": str(currency_code)
                },
                "Reference": {
                    "Guid": transaction_guid
                }
            }
        }
    }
    logging.info(f"## return_transaction payload: {payload}")
    try:
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
        res_json = response.json()
        logging.info(f"## return_transaction res_json: {res_json}")
        return res_json

    except Exception as e:
        failed_data = {'transaction_id':transaction_guid}
        # Error log
        error_data = {
            "service_name": "return_transaction",
            "error_message": str(e),
            "error_type": str(type(str(e)).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        logging.error(f"## return_transaction error: {e}")
        return False

def validate_trx_response(res_json, bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at):
    """
    Validates TRX API response by checking if Result.ResponseCode is '00'.
    Logs error audit and returns (False, debug_message) if validation fails.
    """
    logging.info(f"## validate_trx_response res_json {res_json}")
    result = res_json.get('Message', {}).get('Response', {}).get('Result', {})

    response_code = result.get('ResponseCode')
    debug_message = (
        result.get('DebugInfo') or
        result.get('ResponseText') or
        "Unknown error from TRX API"
    )

    logging.info(f"## validate_trx_response response_code {response_code} debug_message {debug_message}")

    if response_code != '00':
        error_message = f"TRX API ResponseCode validation failed. Response: {result}"
        logging.error(f"### validate_trx_response: {error_message}")
        error_data = {
            "service_name": "cancel_payment",
            "error_message": error_message,
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(result),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        return False, debug_message

    return True, None

def void_transaction_ach(transaction_guid, post_url, merchant_key, merchant_secret, bp_common_utils_db, created_by='System', tenant_name=None, session_id=None, module_name='Payment Cancellation', request_received_at=None):
    """
    Calls the payment gateway to VOID an ACH transaction.
    """
    logging.info(f"## void_transaction_ach called with transaction_guid {transaction_guid}")
    payload = {
        "Message": {
            "Request": {
                "Detail": {
                    "TranType": "Ach",
                    "TranAction": "Void"
                },
                "Reference": {
                    "Guid": transaction_guid
                }
            }
        }
    }
    try:
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
        res_json = response.json()
        logging.info(f"## void_transaction_ach res_json: {res_json}")
        return res_json

    except Exception as e:
        failed_data = {'transaction_id': transaction_guid}
        error_data = {
            "service_name": "void_transaction_ach",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        logging.error(f"## void_transaction_ach error: {e}")
        return False


def return_transaction_ach(transaction_guid, amount, currency_code, post_url, merchant_key, merchant_secret, bp_common_utils_db, created_by='System', tenant_name=None, session_id=None, module_name='Payment Cancellation', request_received_at=None):
    """
    Calls the payment gateway to RETURN (refund) an ACH transaction.
    """
    logging.info(f"## return_transaction_ach called with transaction_guid {transaction_guid}")
    payload = {
        "Message": {
            "Request": {
                "Detail": {
                    "TranType": "Ach",
                    "TranAction": "Return",
                    "Amount": str(amount),
                    "CurrencyCode": str(currency_code)
                },
                "Reference": {
                    "Guid": transaction_guid
                }
            }
        }
    }
    try:
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
        res_json = response.json()
        logging.info(f"## return_transaction_ach res_json: {res_json}")
        return res_json

    except Exception as e:
        failed_data = {'transaction_id': transaction_guid}
        error_data = {
            "service_name": "return_transaction_ach",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        logging.error(f"## return_transaction_ach error: {e}")
        return False


def get_customer_profile_id(account_number, billing_platform_db):
    """
    Fetch the customer_profile_id for the given account_number from the customer_profiles table.

    :param account_number: Account number whose profile ID needs to be fetched.
    :param killbill_database: Database connection instance.
    :return: customer_profile_id (int) if found, else None.
    """
    logging.info(f"## get_customer_profile_id account_number {account_number}")
    if not account_number:
        return None

    try:
        profile_details = billing_platform_db.get_data(
            "customer_profiles",
            {"account_number": str(account_number)},
            ["id"]
        )

        if profile_details is None or profile_details.empty: 
            logging.info(f"## get_customer_profile_id No customer profile found for account_number: {account_number}")
            return None

        # Assuming account_number is unique and returns only one row
        customer_profile_id = profile_details["id"].tolist()[0]
        return customer_profile_id

    except Exception as e:
        logging.error(f"## get_customer_profile_id Error fetching profile ID for account_number {account_number}: {e}")
        return None

def auto_bill_payment_calculation(data,bill_id):
    """
    Processes webhook transaction data received from a payment gateway (TRX), 
    updates billing platform database with payment and billing information, 
    manages customer account balances and ledgers, and triggers notification emails.

    Parameters
    ----------
    data : dict
        The webhook payload containing transaction results and reference information.
        Expected to have keys 'Result' and 'Reference' with transaction details.

    Returns
    -------
    dict
        A dictionary with:
        - 'flag': bool indicating if processing succeeded,
        - 'message': str providing success or error details.

    Overview
    --------
    The function performs these key operations:
    1. Extracts and parses the transaction data, including response code, reference IDs,
       payment amount, and transaction date/time.
    2. Determines payment status ("Success" or "Fail") based on response code.
    3. Retrieves related bill IDs and associated bill records.
    4. Fetches customer profile including account balance and contact info.
    5. For successful transactions:
       - Applies payment amount across bills, updating payments, remaining, and amount_due fields.
       - Updates the customer's account balance and amount due.
       - Creates ledger entries recording payment receipts.
       - Triggers a "Payment Successful" email notification (if enabled).
    6. For failed transactions:
       - Creates ledger entries recording payment failure.
       - Triggers a "Payment Failure" email notification (if enabled).
       - Does not modify bills or account balances.
    7. Saves all transaction history entries in the payment history table.
    8. Updates the transaction status in the database.
    9. Logs audit information regarding the webhook processing duration and details.
    """
    # function implementation here...

    logging.info("## auto_bill_payment_calculation function called")
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    try:
        logging.info(f"## auto_bill_payment_calculation Received TRX transaction data: {data}")

        start_time = time.time()
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # Extract key fields
        result = data.get('Result', {})
        reference_data = data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        # bill_id = reference_data.get('PurchaseId', '')
        bill_id = bill_id
        card_last_four = reference_data.get('LastFour', '')
        tran_date = reference_data.get('TranDate')
        tran_time = reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')
        category =  None
        mail_payment_mode = 'Card Payment'
        if account_brand.lower() == 'ach':
            category = 'ach'
            mail_payment_mode = 'ACH Payment'
            amount = None
        else:
            category = 'credit'
            amount = float(result.get('ApprovedAmount', '0'))

        # Fetch CustomFields
        agent = ""
        custom_fields = data.get("CustomFields", [])
        for field in custom_fields:
            if isinstance(field, dict) and field.get("Id") == "UserDefinedAgent":
                agent = field.get("Value", "")
                break
        
        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
                # Convert to tenant's timezone
                # event_date = convert_to_tenant_timezone(event_date, tenant_name, database)
            except Exception as e:
                logging.warning(f"## auto_bill_payment_calculation Failed to parse transaction datetime: {e}")

        status = "Success" if response_code == "00" else "Fail"
        batch_list_df = billing_platform_db.get_data("transaction_status", {"id": str(bill_id)}, ["bill_list","bill_amount","credit_card_fee"])
        if not batch_list_df.empty:
            bill_list = batch_list_df['bill_list'].tolist()[0]
            bill_list = ast.literal_eval(bill_list) if bill_list else []
            bill_amount = batch_list_df['bill_amount'].tolist()[0] if batch_list_df['bill_amount'].tolist()[0] else 0
            credit_card_fee = float(batch_list_df['credit_card_fee'].tolist()[0] or 0)
        else:
            bill_amount = 0
            bill_list = []
            credit_card_fee = 0
        if not amount:
            amount = bill_amount
        # Deduct credit card fee before splitting across bills
        amount_for_bills = float(amount) - float(credit_card_fee)
        if amount_for_bills < 0:
            amount_for_bills = 0
        bills_df = billing_platform_db.get_data('customer_bills', {'id': bill_list},
                                                 ["id", "payments", "total", "amount_due", 'remaining'],
                                                 {'created_date': 'asc'})
        if isinstance(bills_df, bool) or bills_df is None or bills_df.empty:
            bill_id_df = []
        else:
            bill_id_df = bills_df.to_dict(orient="records")

        account_number_df = billing_platform_db.get_data("customer_bills", {"id": bill_list[0]}, ["account_number"])
        account_number = str(account_number_df['account_number'].tolist()[0]) if not account_number_df.empty else ""

        # Handling of Payment method
        insert_id = payment_method_handler_for_auto_debit(storage_safe_data,account_number ,billing_platform_db ,reference_data , card_last_four , account_brand,category)
        # fetch customer info
        email, customer_name, tenant_name, tenant_id = '', '', '', None
        account_balance, account_amount_due = 0, 0
        if account_number:
            customer_profiles_df = billing_platform_db.get_data("customer_profiles", {"account_number": account_number},
                                                    ["sales_person", "email", "customer_name", "amount_due",
                                                     "tenant_name", "tenant_id", "account_balance"])
            if customer_profiles_df is not None and not customer_profiles_df.empty:
                email = customer_profiles_df['email'].tolist()[0]
                customer_name = customer_profiles_df['customer_name'].tolist()[0]
                account_amount_due = float(customer_profiles_df['amount_due'].tolist()[0])
                tenant_name = customer_profiles_df['tenant_name'].tolist()[0]
                tenant_id = customer_profiles_df['tenant_id'].tolist()[0]
                account_balance = float(customer_profiles_df['account_balance'].tolist()[0])

        transaction_history_rows = []

        if status == "Success":
            logging.info(f"## auto_bill_payment_calculation Transaction Success Case")
            # ----------------------------
            # SPLIT AMOUNT ACROSS BILLS
            # ----------------------------
            amount_paid = amount_for_bills
            row_index = 0
            total_amount_due = 0
            total_bill_amount = 0
            while amount_paid > 0 and row_index < len(bill_id_df):
                bill_dict = bill_id_df[row_index]
                current_bill_id = bill_dict.get('id', '')
                payments = float(bill_dict.get('payments', 0))
                total = float(bill_dict.get('total', 0))
                amount_due = float(bill_dict.get('amount_due', 0))
                remaining = float(bill_dict.get('remaining', 0))
                total_bill_amount = total_bill_amount + total 

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining = 0
                    amount_due = 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0
                
                total_amount_due = total_amount_due + amount_due
                # update bill
                updated_data = {"payments": str(payments), "total": str(total),
                                "amount_due": str(amount_due), "remaining": str(remaining)}
                billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})

                # ledger entry
                ledger_description = f'''Payment Received - Thank you!
                Amount Paid : ${amount_for_invoice}  Date : {event_date.strftime("%m-%d-%Y") if event_date else None}'''
                transaction_data = {
                    "ref": reference,
                    "status": 'Successful',
                    # "date": event_date.isoformat() if event_date else None,
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee)
                }
                transaction_history_rows.append(transaction_data)
                row_index += 1

            # update account profile
            account_balance -= amount
            account_amount_due -= amount
            update_account_balance_data = {"account_balance": round(account_balance, 2),
                                          "amount_due": round(account_amount_due, 2)}
            billing_platform_db.update_dict('customer_profiles', update_account_balance_data, {"account_number": account_number})

            if transaction_history_rows:
                for tx in transaction_history_rows:
                    tx["account_balance"] = round(account_balance, 2)

            # Email trigger for success
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Successful"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                total_remaining = sum(float(item['remaining']) if 'remaining' in item else 0 for item in bill_id_df)
                # due_amount_is = total_remaining
                total_bill_amount = sum(float(item['total']) if 'total' in item else 0 for item in bill_id_df)
                due_amount_is = total_bill_amount - amount if total_bill_amount > amount else 0
                # try:
                #     receipt_dict = {
                #         "tenant_name": tenant_name,
                #         "tenant_id": tenant_id,
                #         "ref": reference
                #     }
                #     #calling generate_payment_receipt
                #     resp = generate_payment_receipt(receipt_dict)
                #     receipt_url = resp["download_url"]  
                #     logging.info(f'receipt_url------------{receipt_url}')
                # except Exception as e:
                #     logging.info(f'error when creating receipt link-----{e}')  
                # placeholders_dict = {
                #     "payment_date": formatted_date,
                #     "bill_id": bill_list,
                #     "transaction_id": reference,
                #     "payment_mode": mail_payment_mode,
                #     "total_amount": round(total_bill_amount, 2),
                #     "amount_paid": round(amount, 2),
                #     "due_amount": round(total_amount_due, 2),
                #     "user_name": customer_name,
                #     "receipt_link": f"{receipt_url}"
                # }
                # logging.info(f"## auto_bill_payment_calculation placeholders_dict: {placeholders_dict}")
                # notification_result = send_email(
                #     template_name='Payment Successful',
                #     to_email=email,
                #     placeholder_value=placeholders_dict,
                #     subject_placeholders={},
                #     comments='Transaction Successful',
                #     customer_name=customer_name,
                #     account_number=account_number,
                #     tenant_id = tenant_id
                # )
                # try:
                #     email_trigger_time = datetime.fromtimestamp(time.time())
                #     logging.info(f'email_trigger_time---------{email_trigger_time}')
                #     update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                #     logging.info(f"## auto_bill_payment_calculation update_status: {update_status}")
                # except Exception as e:
                #     logging.error(f'## auto_bill_payment_calculation Error updating email trigger time: {e}')

        else:  
            logging.info(f"## auto_bill_payment_calculation Transaction Failed Case")
            # Mark all bills with zero payment changes, just add failure entry in payment history
            ledger_description = f'''Payment Failed
            Amount : ${amount}   Date: {event_date.strftime("%m-%d-%Y") if event_date else None}'''
            for bill_dict in bill_id_df:
                current_bill_id = bill_dict.get('id', '')
                transaction_data = {
                    "ref": reference,
                    "status": 'Failed',
                    # "date": event_date.isoformat() if event_date else None,
                    "amount": str(amount),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee)
                }
                transaction_history_rows.append(transaction_data)

            # No account balance or bills update on failure

            # Email trigger for failure
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Failure"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": format_amount(amount),
                    "user_name": customer_name,
                    "due_amount": format_amount(account_amount_due),
                }
                logging.info(f"## auto_bill_payment_calculation placeholders_dict: {placeholders_dict}")
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    billing_db_name = billing_platform_db
                )
                try:
                    email_trigger_time = datetime.fromtimestamp(time.time())
                    logging.info(f'email_trigger_time---------{email_trigger_time}')
                    update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Failure"})
                    logging.info(f"## auto_bill_payment_calculation update_status: {update_status}")
                except Exception as e:
                    logging.error(f'## auto_bill_payment_calculation Error updating email trigger time: {e}')

        # insert payment history
        if transaction_history_rows:
            logging.info(f"## auto_bill_payment_calculation transaction_history_rows: {transaction_history_rows}")
            insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
            logging.info(f"## auto_bill_payment_calculation insert_status: {insert_status}")
            try:
                receipt_dict = {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "ref": reference
                }
                #calling generate_payment_receipt
                resp = generate_payment_receipt(receipt_dict)
                receipt_url = resp["download_url"]  
                logging.info(f'receipt_url------------{receipt_url}')
            except Exception as e:
                logging.info(f'error when creating receipt link-----{e}')  
            
            new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
            formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
            placeholders_dict = {
                "payment_date": formatted_date,
                "bill_id": formatted_bill_list,
                "transaction_id": reference,
                "payment_mode": mail_payment_mode,
                "total_amount": format_amount(total_bill_amount),
                "amount_paid": format_amount(amount),
                "due_amount": format_amount(total_amount_due),
                "user_name": customer_name,
                "receipt_link": receipt_url
            }
            logging.info(f"## auto_bill_payment_calculation placeholders_dict: {placeholders_dict}")
            placeholders_dict = {k: sanitize_string(str(v)) for k, v in placeholders_dict.items()}
            notification_result = send_email(
                template_name='Payment Successful',
                to_email=email,
                placeholder_value=placeholders_dict,
                subject_placeholders={},
                comments='Transaction Successful',
                customer_name=customer_name,
                account_number=account_number,
                tenant_id = tenant_id,
                is_html=True,
                billing_db_name = billing_platform_db
            )
            try:
                email_trigger_time = datetime.fromtimestamp(time.time())
                logging.info(f'email_trigger_time---------{email_trigger_time}')
                update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                logging.info(f"## auto_bill_payment_calculation update_status: {update_status}")
            except Exception as e:
                logging.error(f'## auto_bill_payment_calculation Error updating email trigger time: {e}')

        # update transaction status table
        payment_status_data = {'batch_status': status}
        if status == "Fail":
            payment_status_data['failed_data'] = str(result)
        billing_platform_db.update_dict('transaction_status', payment_status_data, {"id": str(bill_id)})

        # audit log
        audit_data_user_actions = {
            "service_name": "auto_bill_payment_calculation",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        message = 'Error occured in Webhook Handler'
        logging.error(f"## auto_bill_payment_calculation Error in auto_bill_payment_calculation: {e}")
        error_data = {
                "service_name": "auto_bill_payment_calculation",
                "error_message": message,
                "error_type": message,
                "users": 'System',
                "comments": json.dumps(data),
                "module_name": 'Payment History',
                "request_received_at": event_date.isoformat() if event_date else None,
                }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': message}

def auto_bill_payment_calculation_19_1(data,bill_id):
    """
    Processes webhook transaction data received from a payment gateway (TRX), 
    updates billing platform database with payment and billing information, 
    manages customer account balances and ledgers, and triggers notification emails.

    Parameters
    ----------
    data : dict
        The webhook payload containing transaction results and reference information.
        Expected to have keys 'Result' and 'Reference' with transaction details.

    Returns
    -------
    dict
        A dictionary with:
        - 'flag': bool indicating if processing succeeded,
        - 'message': str providing success or error details.

    Overview
    --------
    The function performs these key operations:
    1. Extracts and parses the transaction data, including response code, reference IDs,
       payment amount, and transaction date/time.
    2. Determines payment status ("Success" or "Fail") based on response code.
    3. Retrieves related bill IDs and associated bill records.
    4. Fetches customer profile including account balance and contact info.
    5. For successful transactions:
       - Applies payment amount across bills, updating payments, remaining, and amount_due fields.
       - Updates the customer's account balance and amount due.
       - Creates ledger entries recording payment receipts.
       - Triggers a "Payment Successful" email notification (if enabled).
    6. For failed transactions:
       - Creates ledger entries recording payment failure.
       - Triggers a "Payment Failure" email notification (if enabled).
       - Does not modify bills or account balances.
    7. Saves all transaction history entries in the payment history table.
    8. Updates the transaction status in the database.
    9. Logs audit information regarding the webhook processing duration and details.
    """
    # function implementation here...

    logging.info("## auto_bill_payment_calculation function called")
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    try:
        logging.info(f"## auto_bill_payment_calculation Received TRX transaction data: {data}")

        start_time = time.time()
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # Extract key fields
        result = data.get('Result', {})
        reference_data = data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        # bill_id = reference_data.get('PurchaseId', '')
        bill_id = bill_id
        card_last_four = reference_data.get('LastFour', '')
        tran_date = reference_data.get('TranDate')
        tran_time = reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')
        category =  None
        mail_payment_mode = 'Card Payment'
        if account_brand.lower() == 'ach':
            category = 'ach'
            mail_payment_mode = 'ACH Payment'
            amount = None
        else:
            category = 'credit'
            amount = float(result.get('ApprovedAmount', '0'))

        # Fetch CustomFields
        agent = ""
        custom_fields = data.get("CustomFields", [])
        for field in custom_fields:
            if isinstance(field, dict) and field.get("Id") == "UserDefinedAgent":
                agent = field.get("Value", "")
                break
        
        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
                # Convert to tenant's timezone
                # event_date = convert_to_tenant_timezone(event_date, tenant_name, database)
            except Exception as e:
                logging.warning(f"## auto_bill_payment_calculation Failed to parse transaction datetime: {e}")

        status = "Success" if response_code == "00" else "Fail"
        batch_list_df = billing_platform_db.get_data("transaction_status", {"id": str(bill_id)}, ["bill_list","bill_amount","credit_card_fee"])
        if not batch_list_df.empty:
            bill_list = batch_list_df['bill_list'].tolist()[0]
            bill_list = ast.literal_eval(bill_list) if bill_list else []
            bill_amount = batch_list_df['bill_amount'].tolist()[0] if batch_list_df['bill_amount'].tolist()[0] else 0
            credit_card_fee = float(batch_list_df['credit_card_fee'].tolist()[0] or 0)
        else:
            bill_amount = 0
            bill_list = []
            credit_card_fee = 0
        if not amount:
            amount = bill_amount
        # Deduct credit card fee before splitting across bills
        amount_for_bills = float(amount) - float(credit_card_fee)
        if amount_for_bills < 0:
            amount_for_bills = 0
        bills_df = billing_platform_db.get_data('customer_bills', {'id': bill_list},
                                                 ["id", "payments", "total", "amount_due", 'remaining'],
                                                 {'created_date': 'asc'})
        if isinstance(bills_df, bool) or bills_df is None or bills_df.empty:
            bill_id_df = []
        else:
            bill_id_df = bills_df.to_dict(orient="records")

        account_number_df = billing_platform_db.get_data("customer_bills", {"id": bill_list[0]}, ["account_number"])
        account_number = str(account_number_df['account_number'].tolist()[0]) if not account_number_df.empty else ""

        # Handling of Payment method
        insert_id = payment_method_handler_for_auto_debit(storage_safe_data,account_number ,billing_platform_db ,reference_data , card_last_four , account_brand,category)
        # fetch customer info
        email, customer_name, tenant_name, tenant_id = '', '', '', None
        account_balance, account_amount_due = 0, 0
        if account_number:
            customer_profiles_df = billing_platform_db.get_data("customer_profiles", {"account_number": account_number},
                                                    ["sales_person", "email", "customer_name", "amount_due",
                                                     "tenant_name", "tenant_id", "account_balance"])
            if customer_profiles_df is not None and not customer_profiles_df.empty:
                email = customer_profiles_df['email'].tolist()[0]
                customer_name = customer_profiles_df['customer_name'].tolist()[0]
                account_amount_due = float(customer_profiles_df['amount_due'].tolist()[0])
                tenant_name = customer_profiles_df['tenant_name'].tolist()[0]
                tenant_id = customer_profiles_df['tenant_id'].tolist()[0]
                account_balance = float(customer_profiles_df['account_balance'].tolist()[0])

        transaction_history_rows = []

        if status == "Success":
            logging.info(f"## auto_bill_payment_calculation Transaction Success Case")
            # ----------------------------
            # SPLIT AMOUNT ACROSS BILLS
            # ----------------------------
            amount_paid = amount_for_bills
            row_index = 0
            total_amount_due = 0
            total_bill_amount = 0
            while amount_paid > 0 and row_index < len(bill_id_df):
                bill_dict = bill_id_df[row_index]
                current_bill_id = bill_dict.get('id', '')
                payments = float(bill_dict.get('payments', 0))
                total = float(bill_dict.get('total', 0))
                amount_due = float(bill_dict.get('amount_due', 0))
                remaining = float(bill_dict.get('remaining', 0))
                total_bill_amount = total_bill_amount + total 

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining = 0
                    amount_due = 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0
                
                total_amount_due = total_amount_due + amount_due
                # update bill
                updated_data = {"payments": str(payments), "total": str(total),
                                "amount_due": str(amount_due), "remaining": str(remaining)}
                billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})

                # ledger entry
                ledger_description = f'''Payment Received - Thank you!
                Amount Paid : ${amount_for_invoice}  Date : {event_date.strftime("%m-%d-%Y") if event_date else None}'''
                transaction_data = {
                    "ref": reference,
                    "status": 'Successful',
                    # "date": event_date.isoformat() if event_date else None,
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee)
                }
                transaction_history_rows.append(transaction_data)
                row_index += 1

            # update account profile
            account_balance -= amount
            account_amount_due -= amount
            update_account_balance_data = {"account_balance": round(account_balance, 2),
                                          "amount_due": round(account_amount_due, 2)}
            billing_platform_db.update_dict('customer_profiles', update_account_balance_data, {"account_number": account_number})

            if transaction_history_rows:
                for tx in transaction_history_rows:
                    tx["account_balance"] = round(account_balance, 2)

            # Email trigger for success
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Successful"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                total_remaining = sum(float(item['remaining']) if 'remaining' in item else 0 for item in bill_id_df)
                # due_amount_is = total_remaining
                total_bill_amount = sum(float(item['total']) if 'total' in item else 0 for item in bill_id_df)
                due_amount_is = total_bill_amount - amount if total_bill_amount > amount else 0
                # try:
                #     receipt_dict = {
                #         "tenant_name": tenant_name,
                #         "tenant_id": tenant_id,
                #         "ref": reference
                #     }
                #     #calling generate_payment_receipt
                #     resp = generate_payment_receipt(receipt_dict)
                #     receipt_url = resp["download_url"]  
                #     logging.info(f'receipt_url------------{receipt_url}')
                # except Exception as e:
                #     logging.info(f'error when creating receipt link-----{e}')  
                # placeholders_dict = {
                #     "payment_date": formatted_date,
                #     "bill_id": bill_list,
                #     "transaction_id": reference,
                #     "payment_mode": mail_payment_mode,
                #     "total_amount": round(total_bill_amount, 2),
                #     "amount_paid": round(amount, 2),
                #     "due_amount": round(total_amount_due, 2),
                #     "user_name": customer_name,
                #     "receipt_link": f"{receipt_url}"
                # }
                # logging.info(f"## auto_bill_payment_calculation placeholders_dict: {placeholders_dict}")
                # notification_result = send_email(
                #     template_name='Payment Successful',
                #     to_email=email,
                #     placeholder_value=placeholders_dict,
                #     subject_placeholders={},
                #     comments='Transaction Successful',
                #     customer_name=customer_name,
                #     account_number=account_number,
                #     tenant_id = tenant_id
                # )
                # try:
                #     email_trigger_time = datetime.fromtimestamp(time.time())
                #     logging.info(f'email_trigger_time---------{email_trigger_time}')
                #     update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                #     logging.info(f"## auto_bill_payment_calculation update_status: {update_status}")
                # except Exception as e:
                #     logging.error(f'## auto_bill_payment_calculation Error updating email trigger time: {e}')

        else:  
            logging.info(f"## auto_bill_payment_calculation Transaction Failed Case")
            # Mark all bills with zero payment changes, just add failure entry in payment history
            ledger_description = f'''Payment Failed
            Amount : ${amount}   Date: {event_date.strftime("%m-%d-%Y") if event_date else None}'''
            for bill_dict in bill_id_df:
                current_bill_id = bill_dict.get('id', '')
                transaction_data = {
                    "ref": reference,
                    "status": 'Failed',
                    # "date": event_date.isoformat() if event_date else None,
                    "amount": str(amount),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee)
                }
                transaction_history_rows.append(transaction_data)

            # No account balance or bills update on failure

            # Email trigger for failure
            active_status_query = database.get_data("email_templates", {"template_name": "Payment Failure"}, ["email_status"])
            active_status = active_status_query["email_status"].to_list()[0] if not active_status_query.empty else 'false'
            if str(active_status).strip().lower() == 'true':
                formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": round(amount, 2),
                    "user_name": customer_name,
                    "due_amount": round(account_amount_due, 2),
                }
                logging.info(f"## auto_bill_payment_calculation placeholders_dict: {placeholders_dict}")
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    billing_db_name = billing_platform_db
                )
                try:
                    email_trigger_time = datetime.fromtimestamp(time.time())
                    logging.info(f'email_trigger_time---------{email_trigger_time}')
                    update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Failure"})
                    logging.info(f"## auto_bill_payment_calculation update_status: {update_status}")
                except Exception as e:
                    logging.error(f'## auto_bill_payment_calculation Error updating email trigger time: {e}')

        # insert payment history
        if transaction_history_rows:
            logging.info(f"## auto_bill_payment_calculation transaction_history_rows: {transaction_history_rows}")
            insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
            logging.info(f"## auto_bill_payment_calculation insert_status: {insert_status}")
            try:
                receipt_dict = {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "ref": reference
                }
                #calling generate_payment_receipt
                resp = generate_payment_receipt(receipt_dict)
                receipt_url = resp["download_url"]  
                logging.info(f'receipt_url------------{receipt_url}')
            except Exception as e:
                logging.info(f'error when creating receipt link-----{e}')  
            
            new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
            formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
            placeholders_dict = {
                "payment_date": formatted_date,
                "bill_id": formatted_bill_list,
                "transaction_id": reference,
                "payment_mode": mail_payment_mode,
                "total_amount": round(total_bill_amount, 2),
                "amount_paid": round(amount, 2),
                "due_amount": round(total_amount_due, 2),
                "user_name": customer_name,
                "receipt_link": receipt_url
            }
            logging.info(f"## auto_bill_payment_calculation placeholders_dict: {placeholders_dict}")
            placeholders_dict = {k: sanitize_string(str(v)) for k, v in placeholders_dict.items()}
            notification_result = send_email(
                template_name='Payment Successful',
                to_email=email,
                placeholder_value=placeholders_dict,
                subject_placeholders={},
                comments='Transaction Successful',
                customer_name=customer_name,
                account_number=account_number,
                tenant_id = tenant_id,
                is_html=True,
                billing_db_name = billing_platform_db
            )
            try:
                email_trigger_time = datetime.fromtimestamp(time.time())
                logging.info(f'email_trigger_time---------{email_trigger_time}')
                update_status = database.update_dict(table_name='email_templates', values={"last_email_triggered_at": email_trigger_time},and_conditions={"template_name": "Payment Successful"})
                logging.info(f"## auto_bill_payment_calculation update_status: {update_status}")
            except Exception as e:
                logging.error(f'## auto_bill_payment_calculation Error updating email trigger time: {e}')

        # update transaction status table
        payment_status_data = {'batch_status': status}
        if status == "Fail":
            payment_status_data['failed_data'] = str(result)
        billing_platform_db.update_dict('transaction_status', payment_status_data, {"id": str(bill_id)})

        # audit log
        audit_data_user_actions = {
            "service_name": "auto_bill_payment_calculation",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        message = 'Error occured in Webhook Handler'
        logging.error(f"## auto_bill_payment_calculation Error in auto_bill_payment_calculation: {e}")
        error_data = {
                "service_name": "auto_bill_payment_calculation",
                "error_message": message,
                "error_type": message,
                "users": 'System',
                "comments": json.dumps(data),
                "module_name": 'Payment History',
                "request_received_at": event_date.isoformat() if event_date else None,
                }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': message}


def webhook_response_handler_for_auto_debit(data, context, billing_platform_db, common_utils_db, database,billing_db_name):
    """
    Optimized webhook handler - uses pre-fetched context to reduce DB calls.
    Processes webhook transaction data, updates bills, account balances,
    inserts payment history, and triggers email notifications.
    """
    logging.info(f"## webhook_response_handler_for_auto_debit called with {data} context {context}")
    
    try:
        start_time = time.time()
        result, reference_data = data.get('Result', {}), data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        # -----------------------------
        # Extract transaction details
        # -----------------------------
        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        card_last_four = reference_data.get('LastFour', '')
        tran_date, tran_time = reference_data.get('TranDate'), reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')
        mail_payment_mode = 'ACH Payment' if account_brand.lower() == 'ach' else 'Card Payment'
        category = 'ach' if account_brand.lower() == 'ach' else 'credit'
        amount = float(result.get('ApprovedAmount', '0')) if category == 'credit' else None

        # Custom fields
        agent = next((f.get("Value") for f in data.get("CustomFields", []) if f.get("Id") == "UserDefinedAgent"), "")

        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
            except Exception as e:
                logging.warning(f"## webhook_response_handler_for_auto_debit Failed to parse date: {e}")

        status = "Success" if response_code == "00" else "Fail"

        # -----------------------------
        # Use context (instead of DB lookups)
        # -----------------------------
        txn_record = context.get("transaction_status_record")
        bill_list = ast.literal_eval(txn_record['bill_list'].tolist()[0]) if txn_record is not None else []
        bill_id = txn_record['id'].tolist()[0] if txn_record is not None else None
        total_due_with_fee = context.get("total_due_with_fee")
        # bill_amount = txn_record['bill_amount'].tolist()[0] if txn_record is not None else 0
        bill_amount = float(total_due_with_fee) if total_due_with_fee is not None else 0
        updated_credit_card_fee = context.get("updated_credit_card_fee")
        credit_card_fee = float(updated_credit_card_fee) if updated_credit_card_fee is not None else 0
        # credit_card_fee = float(txn_record['credit_card_fee'].tolist()[0] or 0) if txn_record is not None else 0

        bills = context.get("bills", [])
        profile = context.get("customer_profile", {})
        email_templates = context.get("email_templates", pd.DataFrame())
        name_on_card = context.get("payment_method", {}).get("name_on_card", "")

        account_number = profile.get("account_number", "")
        email, customer_name = profile.get("email", ""), profile.get("customer_name", "")
        tenant_name, tenant_id = profile.get("tenant_name", ""), profile.get("tenant_id")
        account_balance, account_amount_due = float(profile.get("account_balance", 0)), float(profile.get("amount_due", 0))

        if not amount:
            amount = bill_amount
        amount_for_bills = max(float(amount) - float(credit_card_fee), 0)

        # -----------------------------
        # Process transaction
        # -----------------------------
        transaction_history_rows = []
        formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
        total_amount_due, total_bill_amount, receipt_url = 0, 0, ""

        if status == "Success":
            logging.info("## webhook_response_handler_for_auto_debit Transaction Success Case")

            # Split across bills
            amount_paid = amount_for_bills
            for bill_dict in bills:
                if amount_paid <= 0:
                    break
                current_bill_id = bill_dict["id"]
                payments = float(bill_dict.get("payments", 0))
                total = float(bill_dict.get("total", 0))
                amount_due = float(bill_dict.get("amount_due", 0))
                remaining = float(bill_dict.get("remaining", 0))
                total_bill_amount += total

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining, amount_due = 0, 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0

                total_amount_due += amount_due

                bill_credit_card_fee = 0
                try:
                    # Calculate bill proportion based on total without fee
                    bill_proportion = amount_for_invoice / amount_for_bills if amount_for_bills else 0
                    # Calculate per-bill credit card fee
                    bill_credit_card_fee = round(credit_card_fee * bill_proportion, 2) if bill_proportion > 0 else 0
                except Exception as e:
                    logging.info(f"## webhook_response_handler Exceptinon occured as {e}")
                    bill_credit_card_fee = 0

                # Update bill
                updated_data = {"payments": str(payments), "total": str(total),"amount_due": str(amount_due), "remaining": str(remaining)}
                logging.info(f"## webhook_response_handler_for_auto_debit updated_data {updated_data}")
                bills_update_status = billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})
                logging.info(f"## webhook_response_handler_for_auto_debit bills_update_status {bills_update_status}")

                # Ledger entry
                ledger_description = f'Payment Received - Thank you! Amount Paid: ${amount_for_invoice:.2f}  Date: {event_date.strftime("%m-%d-%Y")}'
                ledger_account_balance = round(account_balance - float(amount_for_invoice), 2)
                transaction_history_rows.append({
                    "ref": reference,
                    "status": 'Successful',
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(bill_credit_card_fee),
                    "account_balance": str(ledger_account_balance),
                    "name_on_card": name_on_card,
                    "created_by": "System"
                })

            # Update account balance
            account_balance -= amount
            account_amount_due -= amount
            try:
                account_data_update_status = billing_platform_db.update_dict(
                    'customer_profiles',
                    {
                        "account_balance": round(account_balance, 2),
                        "amount_due": round(account_amount_due, 2),
                        "last_payment_triggered_at": datetime.now(),   
                        "payment_flag": True
                    },
                    {"account_number": account_number}
                )
                logging.info(f"## webhook_response_handler_for_auto_debit account_data_update_status {account_data_update_status}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_auto_debit Account data update error: {e}")
                # account_data_update_status = billing_platform_db.update_dict('customer_profiles',{"account_balance": round(account_balance, 2),"amount_due": round(account_amount_due, 2)},{"account_number": account_number})
            # Insert payment history BEFORE receipt/email
            if transaction_history_rows:
                logging.info(f"## webhook_response_handler_for_auto_debit transaction_history_rows {transaction_history_rows}")
                payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
                logging.info(f"## webhook_response_handler_for_auto_debit payment_insert_status {payment_insert_status}")
            
            # Receipt generation
            try:
                receipt_dict = {"tenant_name": tenant_name, "tenant_id": tenant_id, "ref": reference, "billing_db_name":billing_db_name}
                resp = generate_payment_receipt(receipt_dict)
                logging.info(f"## webhook_response_handler_for_auto_debit Receipt response: {resp}")
                receipt_url = resp.get("download_url", "")
                logging.info(f"## webhook_response_handler_for_auto_debit Receipt URL: {receipt_url}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_auto_debit Receipt error: {e}")

            # Send success email if enabled
            if not email_templates[email_templates["template_name"] == "Payment Successful"].empty:
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "total_amount": format_amount(total_bill_amount),
                    "amount_paid": format_amount(amount),
                    "due_amount": format_amount(total_amount_due),
                    "user_name": customer_name,
                    "receipt_link": receipt_url
                }
                # send_email("Payment Successful", email, placeholders_dict, {}, "Transaction Successful",
                #            customer_name, account_number, tenant_id, is_html=True)\
                notification_result = send_email(
                    template_name='Payment Successful',
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Successful',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    is_html=True,
                    billing_db_name = billing_platform_db
                )

        else:  # Failure case
            logging.info("## webhook_response_handler_for_auto_debit Transaction Failed Case")
            ledger_description = f'Payment Failed Amount: ${amount}   Date: {event_date.strftime("%m-%d-%Y")}'
            logging.info(f"## webhook_response_handler_for_auto_debit bills {bills}")
            for bill_dict in bills:
                logging.info(f"## webhook_response_handler_for_auto_debit bill_dict {bill_dict}")
                current_bill_id = bill_dict["id"]
                logging.info(f"## webhook_response_handler_for_auto_debit current_bill_id {current_bill_id}")
                ledger_account_balance = round(account_balance - float(amount), 2)
                transaction_history_rows.append({
                    "ref": reference,
                    "status": 'Failed',
                    "amount": str(amount),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee),
                    "account_balance": str(ledger_account_balance),
                    "name_on_card": name_on_card,
                    "created_by": "System" 
                })
            try:
                # Update customer_profiles for failure
                account_data_update_status = billing_platform_db.update_dict(
                    'customer_profiles',
                    {
                        "last_payment_triggered_at": datetime.now(),  
                        "payment_flag": False
                    },
                    {"account_number": account_number}
                )
                logging.info(f"## webhook_response_handler_for_auto_debit account_data_update_status {account_data_update_status}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_auto_debit Account data update error: {e}")
            # Insert payment history BEFORE receipt/email
            if transaction_history_rows:
                logging.info(f"## webhook_response_handler_for_auto_debit transaction_history_rows {transaction_history_rows}")
                payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
                logging.info(f"## webhook_response_handler_for_auto_debit payment_insert_status {payment_insert_status}")
            
            # Send failure email if enabled
            if not email_templates[email_templates["template_name"] == "Payment Failure"].empty:
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": format_amount(amount),
                    "user_name": customer_name,
                    "due_amount": format_amount(account_amount_due)
                }
                # send_email("Payment Failure", email, placeholders_dict, {}, "Transaction Failed",
                #            customer_name, account_number, tenant_id)
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    billing_db_name = billing_platform_db
                )

        # # -----------------------------
        # # Insert payment history
        # # -----------------------------
        # if transaction_history_rows:
        #     logging.info(f"## webhook_response_handler_for_auto_debit transaction_history_rows {transaction_history_rows}")
        #     payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
        #     logging.info(f"## webhook_response_handler_for_auto_debit payment_insert_status {payment_insert_status}")

        # -----------------------------
        # Update transaction status
        # -----------------------------
        update_data = {"batch_status": status}
        if status == "Fail":
            update_data["failed_data"] = str(result)
        if reference:
            update_data["guid"] = reference
        billing_platform_db.update_dict('transaction_status', update_data, {"id": str(bill_id)})

        # -----------------------------
        # Audit logging
        # -----------------------------
        audit_data = {
            "service_name": "webhook_response_handler_for_auto_debit",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        logging.error(f"## webhook_response_handler_for_auto_debit error: {e}")
        error_data = {
            "service_name": "webhook_response_handler_for_auto_debit",
            "error_message": str(e),
            "error_type": str(type(str(e)).__name__),
            "users": "System",
            "session_id": None,
            "tenant_name": None,
            "comments": json.dumps(data),
            "module_name": 'Auto-Debit',
            "request_received_at": event_date.isoformat() if event_date else None,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': str(e)}

def webhook_response_handler_for_auto_debit_19_1(data, context, billing_platform_db, common_utils_db, database,billing_db_name):
    """
    Optimized webhook handler - uses pre-fetched context to reduce DB calls.
    Processes webhook transaction data, updates bills, account balances,
    inserts payment history, and triggers email notifications.
    """
    logging.info(f"## webhook_response_handler_for_auto_debit called with {data} context {context}")
    
    try:
        start_time = time.time()
        result, reference_data = data.get('Result', {}), data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        # -----------------------------
        # Extract transaction details
        # -----------------------------
        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        card_last_four = reference_data.get('LastFour', '')
        tran_date, tran_time = reference_data.get('TranDate'), reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')
        mail_payment_mode = 'ACH Payment' if account_brand.lower() == 'ach' else 'Card Payment'
        category = 'ach' if account_brand.lower() == 'ach' else 'credit'
        amount = float(result.get('ApprovedAmount', '0')) if category == 'credit' else None

        # Custom fields
        agent = next((f.get("Value") for f in data.get("CustomFields", []) if f.get("Id") == "UserDefinedAgent"), "")

        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
            except Exception as e:
                logging.warning(f"## webhook_response_handler_for_auto_debit Failed to parse date: {e}")

        status = "Success" if response_code == "00" else "Fail"

        # -----------------------------
        # Use context (instead of DB lookups)
        # -----------------------------
        txn_record = context.get("transaction_status_record")
        bill_list = ast.literal_eval(txn_record['bill_list'].tolist()[0]) if txn_record is not None else []
        bill_id = txn_record['id'].tolist()[0] if txn_record is not None else None
        total_due_with_fee = context.get("total_due_with_fee")
        # bill_amount = txn_record['bill_amount'].tolist()[0] if txn_record is not None else 0
        bill_amount = float(total_due_with_fee) if total_due_with_fee is not None else 0
        updated_credit_card_fee = context.get("updated_credit_card_fee")
        credit_card_fee = float(updated_credit_card_fee) if updated_credit_card_fee is not None else 0
        # credit_card_fee = float(txn_record['credit_card_fee'].tolist()[0] or 0) if txn_record is not None else 0

        bills = context.get("bills", [])
        profile = context.get("customer_profile", {})
        email_templates = context.get("email_templates", pd.DataFrame())
        name_on_card = context.get("payment_method", {}).get("name_on_card", "")

        account_number = profile.get("account_number", "")
        email, customer_name = profile.get("email", ""), profile.get("customer_name", "")
        tenant_name, tenant_id = profile.get("tenant_name", ""), profile.get("tenant_id")
        account_balance, account_amount_due = float(profile.get("account_balance", 0)), float(profile.get("amount_due", 0))

        if not amount:
            amount = bill_amount
        amount_for_bills = max(float(amount) - float(credit_card_fee), 0)

        # -----------------------------
        # Process transaction
        # -----------------------------
        transaction_history_rows = []
        formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
        total_amount_due, total_bill_amount, receipt_url = 0, 0, ""

        if status == "Success":
            logging.info("## webhook_response_handler_for_auto_debit Transaction Success Case")

            # Split across bills
            amount_paid = amount_for_bills
            for bill_dict in bills:
                if amount_paid <= 0:
                    break
                current_bill_id = bill_dict["id"]
                payments = float(bill_dict.get("payments", 0))
                total = float(bill_dict.get("total", 0))
                amount_due = float(bill_dict.get("amount_due", 0))
                remaining = float(bill_dict.get("remaining", 0))
                total_bill_amount += total

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining, amount_due = 0, 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0

                total_amount_due += amount_due

                bill_credit_card_fee = 0
                try:
                    # Calculate bill proportion based on total without fee
                    bill_proportion = amount_for_invoice / amount_for_bills if amount_for_bills else 0
                    # Calculate per-bill credit card fee
                    bill_credit_card_fee = round(credit_card_fee * bill_proportion, 2) if bill_proportion > 0 else 0
                except Exception as e:
                    logging.info(f"## webhook_response_handler Exceptinon occured as {e}")
                    bill_credit_card_fee = 0

                # Update bill
                updated_data = {"payments": str(payments), "total": str(total),"amount_due": str(amount_due), "remaining": str(remaining)}
                logging.info(f"## webhook_response_handler_for_auto_debit updated_data {updated_data}")
                bills_update_status = billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})
                logging.info(f"## webhook_response_handler_for_auto_debit bills_update_status {bills_update_status}")

                # Ledger entry
                ledger_description = f'Payment Received - Thank you! Amount Paid: ${amount_for_invoice:.2f}  Date: {event_date.strftime("%m-%d-%Y")}'
                ledger_account_balance = round(account_balance - float(amount_for_invoice), 2)
                transaction_history_rows.append({
                    "ref": reference,
                    "status": 'Successful',
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(bill_credit_card_fee),
                    "account_balance": str(ledger_account_balance),
                    "name_on_card": name_on_card,
                    "created_by": "System"
                })

            # Update account balance
            account_balance -= amount
            account_amount_due -= amount
            try:
                account_data_update_status = billing_platform_db.update_dict(
                    'customer_profiles',
                    {
                        "account_balance": round(account_balance, 2),
                        "amount_due": round(account_amount_due, 2),
                        "last_payment_triggered_at": datetime.now(),   
                        "payment_flag": True
                    },
                    {"account_number": account_number}
                )
                logging.info(f"## webhook_response_handler_for_auto_debit account_data_update_status {account_data_update_status}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_auto_debit Account data update error: {e}")
                # account_data_update_status = billing_platform_db.update_dict('customer_profiles',{"account_balance": round(account_balance, 2),"amount_due": round(account_amount_due, 2)},{"account_number": account_number})
            # Insert payment history BEFORE receipt/email
            if transaction_history_rows:
                logging.info(f"## webhook_response_handler_for_auto_debit transaction_history_rows {transaction_history_rows}")
                payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
                logging.info(f"## webhook_response_handler_for_auto_debit payment_insert_status {payment_insert_status}")
            
            # Receipt generation
            try:
                receipt_dict = {"tenant_name": tenant_name, "tenant_id": tenant_id, "ref": reference, "billing_db_name":billing_db_name}
                resp = generate_payment_receipt(receipt_dict)
                logging.info(f"## webhook_response_handler_for_auto_debit Receipt response: {resp}")
                receipt_url = resp.get("download_url", "")
                logging.info(f"## webhook_response_handler_for_auto_debit Receipt URL: {receipt_url}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_auto_debit Receipt error: {e}")

            # Send success email if enabled
            if not email_templates[email_templates["template_name"] == "Payment Successful"].empty:
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "total_amount": round(total_bill_amount, 2),
                    "amount_paid": round(amount, 2),
                    "due_amount": round(total_amount_due, 2),
                    "user_name": customer_name,
                    "receipt_link": receipt_url
                }
                # send_email("Payment Successful", email, placeholders_dict, {}, "Transaction Successful",
                #            customer_name, account_number, tenant_id, is_html=True)\
                notification_result = send_email(
                    template_name='Payment Successful',
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Successful',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    is_html=True,
                    billing_db_name = billing_platform_db
                )

        else:  # Failure case
            logging.info("## webhook_response_handler_for_auto_debit Transaction Failed Case")
            ledger_description = f'Payment Failed Amount: ${amount}   Date: {event_date.strftime("%m-%d-%Y")}'
            logging.info(f"## webhook_response_handler_for_auto_debit bills {bills}")
            for bill_dict in bills:
                logging.info(f"## webhook_response_handler_for_auto_debit bill_dict {bill_dict}")
                current_bill_id = bill_dict["id"]
                logging.info(f"## webhook_response_handler_for_auto_debit current_bill_id {current_bill_id}")
                ledger_account_balance = round(account_balance - float(amount), 2)
                transaction_history_rows.append({
                    "ref": reference,
                    "status": 'Failed',
                    "amount": str(amount),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee),
                    "account_balance": str(ledger_account_balance),
                    "name_on_card": name_on_card,
                    "created_by": "System" 
                })
            try:
                # Update customer_profiles for failure
                account_data_update_status = billing_platform_db.update_dict(
                    'customer_profiles',
                    {
                        "last_payment_triggered_at": datetime.now(),  
                        "payment_flag": False
                    },
                    {"account_number": account_number}
                )
                logging.info(f"## webhook_response_handler_for_auto_debit account_data_update_status {account_data_update_status}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_auto_debit Account data update error: {e}")
            # Insert payment history BEFORE receipt/email
            if transaction_history_rows:
                logging.info(f"## webhook_response_handler_for_auto_debit transaction_history_rows {transaction_history_rows}")
                payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
                logging.info(f"## webhook_response_handler_for_auto_debit payment_insert_status {payment_insert_status}")
            
            # Send failure email if enabled
            if not email_templates[email_templates["template_name"] == "Payment Failure"].empty:
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": round(amount, 2),
                    "user_name": customer_name,
                    "due_amount": round(account_amount_due, 2)
                }
                # send_email("Payment Failure", email, placeholders_dict, {}, "Transaction Failed",
                #            customer_name, account_number, tenant_id)
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    billing_db_name = billing_platform_db
                )

        # # -----------------------------
        # # Insert payment history
        # # -----------------------------
        # if transaction_history_rows:
        #     logging.info(f"## webhook_response_handler_for_auto_debit transaction_history_rows {transaction_history_rows}")
        #     payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
        #     logging.info(f"## webhook_response_handler_for_auto_debit payment_insert_status {payment_insert_status}")

        # -----------------------------
        # Update transaction status
        # -----------------------------
        update_data = {"batch_status": status}
        if status == "Fail":
            update_data["failed_data"] = str(result)
        if reference:
            update_data["guid"] = reference
        billing_platform_db.update_dict('transaction_status', update_data, {"id": str(bill_id)})

        # -----------------------------
        # Audit logging
        # -----------------------------
        audit_data = {
            "service_name": "webhook_response_handler_for_auto_debit",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        logging.error(f"## webhook_response_handler_for_auto_debit error: {e}")
        error_data = {
            "service_name": "webhook_response_handler_for_auto_debit",
            "error_message": str(e),
            "error_type": str(type(str(e)).__name__),
            "users": "System",
            "session_id": None,
            "tenant_name": None,
            "comments": json.dumps(data),
            "module_name": 'Auto-Debit',
            "request_received_at": event_date.isoformat() if event_date else None,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': str(e)}

def test_file():
    """
    Fetches the credit card fee for each account under a given tenant.

    Input:
        data = {
            "tenant_id": "TENANT123"
        }

    Output:
        {
            "account_number_1": credit_card_fee_value,
            "account_number_2": credit_card_fee_value,
            ...
        }

    Logic:
        1. Fetch account_number, credit_card_fee from customer_profiles where tenant_id matches.
        2. Fetch default_settings for all tenants (includes enable_credit_card_fee_type and credit_card_fee).
        3. For each account:
           - Decide if fee applies using apply_cc_fee()
           - Use customer-specific fee if exists, otherwise tenant default.
           - Return the computed mapping as a dict.
    """

    try:
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        result = db_connection_by_tenant_name("Altaworx",common_utils_database)
        if result:
            logging.info(f"## credit_card_fee_accounts_by_tenant result {result}")
            return {'flag':True,'result':result}
        return {'flag':False,'result':''}

    except Exception as e:
        logging.error(f"## credit_card_fee_accounts_by_tenant Exception: {e}")
        return {"flag": False, "message": str(e)}
 
def get_bill_ranges_by_ids(bill_ids, billing_platform_db):
    """
    Fetch start_date and end_date from the database for given bill IDs
    and return them in the format 'MM-DD-YYYY - MM-DD-YYYY'.
    """
    logging.info(f"## get_bill_ranges_by_ids bill_ids {bill_ids}")
    if not bill_ids:
        logging.info("## get_bill_ranges_by_ids No bill_ids provided")
        return {}

    try:
        bill_details = billing_platform_db.get_data(
            "customer_bills",
            {"id": bill_ids},
            ["id", "bill_cycle_start_date", "bill_cycle_end_date"]
        )
        logging.info(f"## get_bill_ranges_by_ids bill_details {bill_details}")

        # Normalize output
        if isinstance(bill_details, dict):
            bill_details = [bill_details]

        elif isinstance(bill_details, str):
            # Try to detect DataFrame string vs JSON
            try:
                bill_details = json.loads(bill_details)  # JSON case
            except Exception:
                logging.warning("## get_bill_ranges_by_ids bill_details looks like a DataFrame string")
                return {}

        elif hasattr(bill_details, "to_dict"):  # DataFrame case
            bill_details = bill_details.to_dict(orient="records")

        bill_id_range_dict = {}
        for bill in bill_details:
            bill_id = bill["id"]
            start_date = bill["bill_cycle_start_date"]
            end_date = bill["bill_cycle_end_date"]

            # Ensure datetime
            if isinstance(start_date, str):
                start_date = pd.to_datetime(start_date)
            if isinstance(end_date, str):
                end_date = pd.to_datetime(end_date)

            formatted_range = f"{start_date.strftime('%m-%d-%Y')} - {end_date.strftime('%m-%d-%Y')}"
            bill_id_range_dict[str(bill_id)] = formatted_range

        return bill_id_range_dict

    except Exception as e:
        logging.error(f"## get_bill_ranges_by_ids Error fetching bill ranges for bill_ids {bill_ids}: {e}")
        return {}

def update_account_balance(total_amount, billing_platform_db, account_number):
    """
    Fetches the account_balance from customer_profiles for the account_number,
    adds total_amount, and updates the account_balance.
    Returns True on successful update, False otherwise.
    """
    logging.info(f"## update_account_balance function called with total_amount {total_amount} account_number {account_number}")
    try:
        # Fetch the current balance
        result = billing_platform_db.get_data(
            "customer_profiles",
            {"account_number": str(account_number)},
            ['account_balance']
        )
        if result is None or result.empty:
            logging.error(f"## update_account_balance Account number {account_number} not found in customer_profiles")
            return 0

        # Convert to numeric safely, fallback to 0
        current_balance = result.iloc[0].get("account_balance", 0)
        if current_balance is None:
            current_balance = 0
        current_balance = float(current_balance)
        total_amount = float(total_amount)

        new_balance = current_balance + total_amount

        # Update the balance in DB (send as numeric, conversion depends on DB driver)
        update_status = billing_platform_db.update_dict(
            "customer_profiles",
            {"account_balance": str(new_balance)},
            {"account_number": str(account_number)}
        )
        if update_status:
            logging.info(f"## update_account_balance Updated account_balance for {account_number} to {new_balance}")
            return new_balance
        else:
            logging.error(f"## update_account_balance Failed to update account_balance for {account_number}")
            return 0
    except Exception as e:
        logging.error(f"## update_account_balance Error updating account_balance: {e}")
        return 0

def insert_cancel_payment_history(
    billing_platform_db, payment_df, new_transaction_id, new_date,
    bp_common_utils_db, created_by, tenant_name, session_id, module_name,
    request_received_at,new_account_balanace=0.0
):
    """
    Inserts a copy of payment history records into cancel_payment_history with updated
    transaction_id and date fields, and also creates corresponding entries in customer_charges
    including bill_range and customer_profile_id.

    :return: True if both inserts succeed, else False
    """
    logging.info(
        f"## insert_cancel_payment_history called with new_transaction_id={new_transaction_id}, "
        f"new_date={new_date}, total_records={payment_df}"
    )

    try:
        updated_records = []
        unposted_insert_data = []

        # --- Get account_number (all rows have the same account_number) ---
        account_number = payment_df.iloc[0].get("account_number")
        logging.info(f"## insert_cancel_payment_history account_number={account_number}")
        customer_profile_id = get_customer_profile_id(account_number, billing_platform_db)
        logging.info(f"## insert_cancel_payment_history Fetched customer_profile_id={customer_profile_id} for account_number={account_number}")

        # --- Get bill ranges ---
        bill_ids = payment_df['bill_id'].dropna().unique().tolist()
        logging.info(f"## insert_cancel_payment_history bill_ids={bill_ids} type of bill_id {type(bill_ids)}")
        bill_ranges = get_bill_ranges_by_ids(bill_ids, billing_platform_db)
        logging.info(f"## insert_cancel_payment_history Bill ranges fetched: {bill_ranges}")

        for _, row in payment_df.iterrows():
            row_dict = row.to_dict()
            bill_id = row_dict.get("bill_id",None)
            amount = row_dict.get("amount",None)
            payment_id = row_dict.get("id",None)

            # Remove DB-managed fields to avoid conflicts on insert
            for field in ["id", "created_date", "modified_date"]:
                row_dict.pop(field, None)

            # Update transaction_id and date
            row_dict['ref'] = new_transaction_id
            row_dict['date'] = new_date
            updated_records.append(row_dict)

            # Get this bill's range (or empty if missing)
            bill_range = bill_ranges.get(bill_id, '')

            # Build customer_charges record
            try:
                formatted_bill_id = f"INV{str(int(bill_id)).zfill(4)}"
            except:
                formatted_bill_id = bill_id
            unposted_insert_data.append({
                "charge_amount": amount,
                "charge_description": "Cancel Payment",
                "charge_type": "Cancel Payment",
                "category": "Cancel Payment",
                "ledger_description": f"Payment Returned for Bill ID :{formatted_bill_id} with Amount : ${amount}",
                "tenant_id": row_dict.get("tenant_id", None),
                "tenant_name": row_dict.get("tenant_name", ''),
                # "bill_id": bill_id,
                "bill_range": bill_range,
                "payment_id": payment_id,
                "customer_profile_id": customer_profile_id,
                "account_balance":str(new_account_balanace)
            })
        logging.info(f"## insert_cancel_payment_history updated_records : {updated_records} unposted_insert_data {unposted_insert_data}")
        # After building updated_records
        for record in updated_records:
            record.pop("id", None)
            record.pop("created_date", None)
            record.pop("modified_date", None)
        # Insert into cancel_payment_history
        insert_status = billing_platform_db.insert_data(updated_records, "cancel_payment_history")
        # Insert into customer_charges
        charges_insert_status = billing_platform_db.insert_data(unposted_insert_data, "customer_charges")

        if insert_status and charges_insert_status:
            logging.info("Insert into insert_cancel_payment_history and customer_charges successful.")
            return True
        else:
            logging.error("Insert into insert_cancel_payment_history or customer_charges failed.")
            return False

    except Exception as e:
        # Log the error to error_log_table
        failed_data = {'transaction_data': payment_df.to_dict(orient="records")}
        error_data = {
            "service_name": "insert_cancel_payment_history",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        logging.error(f"## insert_cancel_payment_history error: {e}")
        return False

def cancel_payment(data):
    """
    Main function to process a payment cancellation or refund request.

    - Validates and extracts required data and environment configuration.
    - Retrieves all payment_history records for the specified transaction GUID.
    - Determines if the cancellation is a 'Void' (within 24 hours) or 'Return' (refund).
    - Calls appropriate TRX API function (void_transaction or return_transaction).
    - Inserts the updated payment history records with new transaction info into cancel_payment_history.
    - Adds detailed audit logs on success or error audit logs on failure.
    - Returns structured dict indicating success/failure and processing details.

    Parameters:
    - data (dict): Input payload containing 'updated_data' and contextual user/session info.

    Returns:
    - dict: Result of cancellation operation with flags and messages.
    """
    logging.info(f'###cancel_payment_fucntion function called with data {data}')

    # Start Date 
    start_time = time.time()
    
    # Parameter's from UI
    updated_data = data.get('updated_data', {})
    transaction_guid = updated_data.get('transaction_id', None)
    cancel_reason = updated_data.get('reason', None)
    account_number = data.get('account_number','')
    customer_name = data.get('customer_name','')
    tenant_id = data.get('tenant_id',None)
    tenant_name = data.get("tenant_name", '')
    mode = os.getenv('ENV', '')
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}

    # Required parameter's validations
    if not transaction_guid:
        return {'flag': False, "message": "Transaction ID is Required"}
    if not account_number:
        return {'flag': False, "message": "Account Number is Required"}
    if not tenant_id:
        return {'flag': False, "message": "Tenant ID is Required"}

    # Mode Check
    if mode == 'UAT':
        if str(tenant_id)=='212':
            tenant_name = 'Altaworx'
            tenant_id = '1'

    # DB Connections
    billing_platform_db = DB(billing_db_name, **db_config)
    bp_common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # ENV Variables
    post_url = os.environ.get("post_url", "")
    merchant_key = os.environ.get("merchant_key", "")
    merchant_secret = os.environ.get("merchant_secret", "")
    currency_code = os.environ.get("trx_current_code", "")

    # Validation for ENV Variables
    required_env_vars = ["post_url", "merchant_key", "merchant_secret", "trx_current_code"]
    missing_env = [var for var in required_env_vars if not var]
    if missing_env:
        return {"flag": False, "message": f"Missing required ENV variables: {', '.join(missing_env)}"}

    # Additional metadata for audit
    created_by = data.get("username", "")
    session_id = data.get("session_id", None)
    module_name = data.get('module_name','Payment Cancellation')
    request_received_at = data.get('request_received_at',None)

    payment_df = billing_platform_db.get_data("payment_history", {"ref": transaction_guid}, None)
    if payment_df is None or payment_df.empty:
        return {"flag": False, "message": "Transaction not found in payment_history."}

    logging.info(f'### cancel_payment_fucntion fetched payment_df {payment_df}')
    payment_category = payment_df['category'].iloc[0] if 'category' in payment_df.columns else None

    # Handle missing or None values safely
    if not payment_category:
        return {"flag": False, "message": "Payment category is missing or null for this transaction."}

    if payment_category.lower() not in ['credit', 'ach']:
        return {"flag": False, "message": f"Unsupported payment category: {payment_category}"}

    payment_category = payment_category.lower()

    logging.info(f"## cancel_payment_fucntion payment_category = {payment_category}")
    total_amount = payment_df['amount'].sum()
    total_amount = round(float(total_amount), 2)
    date_str = payment_df["date"].min()
    txn_time = datetime.fromisoformat(date_str) if isinstance(date_str, str) else date_str
    now = datetime.utcnow()
    time_diff = now - txn_time
    txn_date_only = txn_time.date()
    today_date_only = now.date()
    logging.info(f"## cancel_payment Transaction time_diff = {time_diff}, txn_date={txn_date_only}, today={today_date_only}")
    
    action = None
    try:
        #  if transaction date is before today → must use RETURN
        if txn_date_only < today_date_only:
            action = "Returned"
            logging.info(f'###cancel_payment performing RETURN action (txn_date is before today)')
            if payment_category == "ach":
                res_json = return_transaction_ach(
                    transaction_guid, total_amount, currency_code,
                    post_url, merchant_key, merchant_secret,
                    bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
                )
            else:  # credit
                res_json = return_transaction(
                    transaction_guid, total_amount, currency_code,
                    post_url, merchant_key, merchant_secret,
                    bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
                )

        # if transaction is from today and < 24 hours → VOID
        elif time_diff < timedelta(hours=24):
            action = "Voided"
            logging.info(f'###cancel_payment performing VOID action (same-day and <24h)')
            if payment_category == "ach":
                res_json = void_transaction_ach(
                    transaction_guid, post_url, merchant_key, merchant_secret,
                    bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
                )
            else:  # credit
                res_json = void_transaction(
                    transaction_guid, post_url, merchant_key, merchant_secret,
                    bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
                )

        # fallback: RETURN
        else:
            action = "Returned"
            logging.info(f'###cancel_payment performing RETURN action (default fallback)')
            if payment_category == "ach":
                res_json = return_transaction_ach(
                    transaction_guid, total_amount, currency_code,
                    post_url, merchant_key, merchant_secret,
                    bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
                )
            else:  # credit
                res_json = return_transaction(
                    transaction_guid, total_amount, currency_code,
                    post_url, merchant_key, merchant_secret,
                    bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
                )
        logging.info(f"## cancel_payment_fucntion TRX API response: {res_json}")

        # --- Validate TRX API response ---
        is_valid, debug_msg = validate_trx_response(res_json, bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
        )
        if not is_valid:
            return {"flag": True, "message": debug_msg,"validation":True}
        if not is_valid:
            logging.warning(f"## cancel_payment_fucntion TRX response invalid: {debug_msg}")
            # Insert failed record into charge_back_history
            failed_chargeback_data = {
                # Modify the bill_list to prefix each bill_id with "INV"
                # "bill_list": ",".join([f"INV{str(bill_id)}" for bill_id in payment_df["bill_id"].tolist()]) if "bill_id" in payment_df.columns else None,
                "bill_list": ",".join([f"INV{str(int(bill_id)).zfill(4)}" for bill_id in payment_df["bill_id"].tolist()]) if "bill_id" in payment_df.columns else None,
                "account_number": account_number,
                "cancel_reason": cancel_reason or debug_msg,
                "amount": str(total_amount),
                "last_four": payment_df["method"].iloc[0] if "method" in payment_df.columns else None,
                "activity": "Return Failed",
                "category": payment_df["category"].iloc[0] if "category" in payment_df.columns else None,
                # "date": request_received_at,
                "ref_guid": transaction_guid,
                "customer_name": customer_name,
                "status": "Failed",
                "created_date": request_received_at,
                "modified_date": request_received_at,
                "tenant_id": tenant_id,
                "tenant_name": tenant_name,
                "created_by": created_by,
                "modified_by": created_by
            }
            chargeback_insert_status = billing_platform_db.insert_data(failed_chargeback_data, "charge_back_history")
            logging.info(f"## cancel_payment_fucntion inserted FAILED record into charge_back_history for ref={transaction_guid} chargeback_insert_status {chargeback_insert_status}")
            
            return {"flag": True, "message": debug_msg, "validation": True}
        cancel_payment_data = {"cancel_payment_flag": True}
        if cancel_reason:
            cancel_payment_data['cancel_reason'] = cancel_reason
        if created_by:
            cancel_payment_data['modified_by'] = created_by
        if action:
            cancel_payment_data['status'] = action
        billing_platform_db.update_dict(
            "payment_history",
            cancel_payment_data,
            {"ref": transaction_guid}
        )
        logging.info(f"## cancel_payment_fucntion marked payment_history as cancelled for ref {transaction_guid}")

        # Then insert into charge_back_history
        chargeback_data = {
            # Modify the bill_list to prefix each bill_id with "INV"
            # "bill_list": ",".join([f"INV{str(bill_id)}" for bill_id in payment_df["bill_id"].tolist()]) if "bill_id" in payment_df.columns else None,
            "bill_list": ",".join([f"INV{str(int(bill_id)).zfill(4)}" for bill_id in payment_df["bill_id"].tolist()]) if "bill_id" in payment_df.columns else None,
            "account_number": account_number,
            "cancel_reason": cancel_reason or res_json.get('Message', {}).get('Response', {}).get('ResponseText', ''),
            "amount": str(total_amount),
            "last_four": payment_df["method"].iloc[0] if "method" in payment_df.columns else None,
            "activity": action,
            "category": payment_df["category"].iloc[0] if "category" in payment_df.columns else None,
            # "date": request_received_at,
            "ref_guid": transaction_guid,
            "customer_name": customer_name,
            "status": action,
            "created_date": request_received_at,
            "modified_date": request_received_at,
            "tenant_id": tenant_id,
            "tenant_name": tenant_name,
            "created_by": created_by,
            "modified_by": created_by
        }
        logging.info(f"## cancel_payment_fucntion inserted record into charge_back_history for chargeback_data {chargeback_data}")

        chargeback_insert_status = billing_platform_db.insert_data(chargeback_data,"charge_back_history")
        logging.info(f"## cancel_payment_fucntion inserted record into charge_back_history for  chargeback_insert_status {chargeback_insert_status} chargeback_data {chargeback_data}")

        new_transaction_id = res_json.get('Message', {}).get('Response', {}).get('TransactionId', transaction_guid)
        new_date = datetime.utcnow().isoformat()

        new_account_balanace = update_account_balance(total_amount , billing_platform_db, account_number)
        logging.info(f"## cancel_payment_fucntion balance_update_status {new_account_balanace}")
        if not new_account_balanace:
            new_account_balanace = 0
        insert_status = insert_cancel_payment_history(billing_platform_db, payment_df, new_transaction_id, new_date, bp_common_utils_db, created_by, tenant_name, session_id, module_name,request_received_at,new_account_balanace)
        # balance_update_status = update_account_balance(total_amount , billing_platform_db, account_number)
        # logging.info(f"## cancel_payment balance_update_status {balance_update_status}")
        
        # Audit success
        if insert_status:
            updated_data = {'transaction_id':transaction_guid}
            message = "Failed update transaction data"
            response = {'flag':True,"message":message}
            audit_data = {
                "service_name": "cancel_payment",
                "status": "Success",
                "created_by": created_by,
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(updated_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            bp_common_utils_db.update_audit(audit_data, "audit_user_actions")
            logging.info(f"Audit logged for insert_cancel_payment_history: {audit_data}")
        else:
            failed_data = {'transaction_id':transaction_guid}
            # Error audit
            error_data = {
                "service_name": "cancel_payment",
                "error_message": "Insert operation returned failure status",
                "users": created_by,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(failed_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
            logging.error(f"Error audit logged for insert_cancel_payment_history: {error_data}")

        return {"flag": True, "message": f"Successfully Cancelled the Transaction"}

    except Exception as e:
        logging.error(f"## cancel_payment error: {str(e)}")
        # Error log
        error_data = {
            "service_name": "cancel_payment",
            "error_message": str(e),
            "error_type": str(type(str(e)).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": 'Failed to perform Payment Return'}



def chargeback_history_list_view(data):
    """
    Fetches and returns cancel payment (chargeback) history for a tenant account with pagination and sorting.
    The function applies the tenant's timezone to timestamps, retrieves header mappings for UI display,
    and structures the response in a standardized format.

    Parameters:
        data (dict): A dictionary containing the request details, including:
            - 'db_name' (str, optional): Tenant database name (default: 'altaworx_central').
            - 'role_name' (str, optional): Role name of the requesting user.
            - 'tenant_name' (str): Tenant name, used to fetch tenant timezone and headers.
            - 'mod_pages' (dict, optional): Pagination details:
                - 'start' (int, optional): Starting index (default: 0).
                - 'end' (int, optional): Ending index (default: 100).
            - 'col_sort' (dict, optional): Sorting configuration (e.g., {"date": "desc"}).
            - 'account_number' (str, optional): Account number to fetch chargeback history for.
            - 'table_name' (str, optional): Table name to query (default: 'cancel_payment_history').

    Returns:
        dict: A structured response containing:
            - 'flag' (bool): Success status.
            - 'message' (str): Status message.
            - 'data' (dict): Cancel payment history data (with timestamps adjusted to tenant timezone).
            - 'header_map' (dict): Column header configuration for UI rendering.
            - 'pages' (dict): Pagination metadata including start, end, and total record count.
    """
    logging.info(f"## chargeback_history_list_view called with data {data}")
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    # Db Connections
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
    killbill_database = DB(billing_db_name, **db_config)
    tenant_database=data.get('db_name','altaworx_central')
    common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

    # Fetch Required Parameter's from UI
    role_name = data.get('role_name', '')
    tenant_name =data.get('tenant_name','')
    
    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    account_number = data.get('account_number', '')
    col_sort = data.get("col_sort", "")
    limit = end - start
    offset = start
    table_name = data.get('table_name','cancel_payment_history')
    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_time_zone = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name},["time_zone"]
        )["time_zone"].to_list()[0]
    logging.info(f"## chargeback_history_list_view **tenant_time_zone {tenant_time_zone}")

    if tenant_time_zone is None:
            raise ValueError("No valid timezone found for tenant.")

    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    total_count_result = killbill_database.get_data(
            table_name, {"account_number": account_number},["id"]
        )["id"].to_list()
    total_count=len(total_count_result)
    logging.info(f"## chargeback_history_list_view **totalquery {total_count_result}")
    logging.info(f"## chargeback_history_list_view total_count_result: {type(total_count)} - {total_count}")

    # Pagination information
    pages_data = {
        "start": start,
        "end": end,
        "total": total_count
    }

    if col_sort:
        order =  {k: v.lower() for k, v in col_sort.items()}
        logging.info(f"orderis {order}")
    else:
        order= {"date":"desc"}

    # Retrieve payment history data based on account number and pagination
    df_dict= killbill_database.get_data(
        table_name = table_name,
        condition = {"account_number": account_number},
        columns = None,
        order = order,
        mod_pages = {"start": start, "end": end}
    ).to_dict(orient="records")
    logging.info(f'####chargeback_history_list_view df_dict{df_dict}')
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    try:
        # Prepare response data
        header_map = get_headers_mapping(tenant_database,["Cancel Payment History"],role_name, '', '', '', '',data)
        data_dict_all = {"cancel_payment_history": serialize_data(df_dict)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
        }
        return response

    except Exception as e:
        logging.exception(f"## chargeback_history_list_view Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response

def insert_transaction_charge_back_history(
    billing_platform_db, payment_df, new_transaction_id, new_date,
    bp_common_utils_db, created_by, tenant_name, session_id, module_name,
    request_received_at, charge_back_fee=0.0,new_account_balanace = 0.0
):
    """
    Creates chargeback history and customer charge records for a cancelled payment.

    Parameters:
        billing_platform_db: Database connection object for billing platform inserts.
        payment_df (pd.DataFrame): Original payment records to copy/transform.
        new_transaction_id (str): New reference transaction ID to set in history.
        new_date (datetime): Date to replace in the new history records.
        bp_common_utils_db: Database connection for logging errors.
        created_by (str): User or process creating this record.
        tenant_name (str): Tenant name for context.
        session_id (str): Session ID for traceability.
        module_name (str): Name of the calling module.
        request_received_at (datetime): Timestamp of the request.
        charge_back_fee (float, optional): Extra fee to be added to the first bill amount.

    Returns:
        bool: True if both history and charges inserts succeed, False otherwise.
    """

    logging.info(
        f"## insert_transaction_charge_back_history called with new_transaction_id={new_transaction_id}, "
        f"new_date={new_date}, total_records={payment_df}"
    )

    try:
        updated_records = []
        unposted_insert_data = []

        # --- Get account_number (all rows have the same account_number) ---
        account_number = payment_df.iloc[0].get("account_number")
        logging.info(f"## insert_transaction_charge_back_history account_number={account_number}")
        customer_profile_id = get_customer_profile_id(account_number, billing_platform_db)
        logging.info(f"## insert_transaction_charge_back_history Fetched customer_profile_id={customer_profile_id} for account_number={account_number}")

        # --- Get bill ranges ---
        bill_ids = payment_df['bill_id'].dropna().unique().tolist()
        logging.info(f"## insert_transaction_charge_back_history bill_ids={bill_ids} type of bill_id {type(bill_ids)}")
        bill_ranges = get_bill_ranges_by_ids(bill_ids, billing_platform_db)
        logging.info(f"## insert_transaction_charge_back_history Bill ranges fetched: {bill_ranges}")
        
        first_row_processed = False
        for _, row in payment_df.iterrows():
            row_dict = row.to_dict()
            bill_id = row_dict.get("bill_id",None)
            amount = row_dict.get("amount",None)
            payment_id = row_dict.get("id",None)

            # Remove DB-managed fields to avoid conflicts on insert
            for field in ["id", "created_date", "modified_date"]:
                row_dict.pop(field, None)

            # Update transaction_id and date
            row_dict['ref'] = new_transaction_id
            row_dict['date'] = new_date
            updated_records.append(row_dict)

            # Get this bill's range (or empty if missing)
            bill_range = bill_ranges.get(bill_id, '')
            # Add charge_back_fee to the first bill only
            if not first_row_processed and charge_back_fee:
                logging.info(f"## insert_transaction_charge_back_history Adding charge_back_fee {charge_back_fee} to bill_id={bill_id}")
                amount = float(amount) + float(charge_back_fee)
                first_row_processed = True
            # Build customer_charges record
            try:
                formatted_bill_id = f"INV{str(int(bill_id)).zfill(4)}"
            except:
                formatted_bill_id = bill_id
            unposted_insert_data.append({
                "charge_amount": amount,
                "charge_description": "Chargeback",
                "charge_type": "Chargeback",
                "category": "Chargeback",
                "ledger_description": f"Chargeback done for Bill ID :{formatted_bill_id} with Amount : ${amount}",
                "tenant_id": row_dict.get("tenant_id", None),
                "tenant_name": row_dict.get("tenant_name", ''),
                # "bill_id": bill_id,
                "bill_range": bill_range,
                "payment_id": payment_id,
                "customer_profile_id": customer_profile_id,
                "account_balance": str(new_account_balanace)
            })
        logging.info(f"## insert_transaction_charge_back_history updated_records : {updated_records} unposted_insert_data {unposted_insert_data}")
        # After building updated_records
        for record in updated_records:
            record.pop("id", None)
            record.pop("created_date", None)
            record.pop("modified_date", None)
        # Insert into cancel_payment_history
        insert_status = billing_platform_db.insert_data(updated_records, "cancel_payment_history")
        # Insert into customer_charges
        charges_insert_status = billing_platform_db.insert_data(unposted_insert_data, "customer_charges")

        if insert_status and charges_insert_status:
            logging.info("Insert into insert_transaction_charge_back_history and customer_charges successful.")
            return True
        else:
            logging.error("Insert into insert_transaction_charge_back_history or customer_charges failed.")
            return False

    except Exception as e:
        # Log the error to error_log_table
        failed_data = {'transaction_data': payment_df.to_dict(orient="records")}
        error_data = {
            "service_name": "insert_transaction_charge_back_history",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(failed_data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        logging.error(f"## insert_transaction_charge_back_history error: {e}")
        return False

def transaction_charge_back(data):
    """
    Main function to process a payment cancellation or refund request.

    - Validates and extracts required data and environment configuration.
    - Retrieves all payment_history records for the specified transaction GUID.
    - Determines if the cancellation is a 'Void' (within 24 hours) or 'Return' (refund).
    - Calls appropriate TRX API function (void_transaction or return_transaction).
    - Inserts the updated payment history records with new transaction info into transaction_charge_back_history.
    - Adds detailed audit logs on success or error audit logs on failure.
    - Returns structured dict indicating success/failure and processing details.

    Parameters:
    - data (dict): Input payload containing 'updated_data' and contextual user/session info.

    Returns:
    - dict: Result of cancellation operation with flags and messages.
    """
    start_time = time.time()
    logging.info(f'###transaction_charge_back function called with data {data}')
    updated_data = data.get('updated_data', {})
    transaction_guid = updated_data.get('transaction_id', None)
    cancel_reason = updated_data.get('reason', None)
    charge_back_fee = updated_data.get('charge_back_fee', 0)
    account_number = data.get('account_number','')
    customer_name = data.get('customer_name','')
    tenant_id = data.get('tenant_id',None)
    tenant_name = data.get("tenant_name", '')
    mode = os.getenv('ENV', '')
    billing_db_name = data.get('billing_db_name',None)

    # Validations
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    
    if not transaction_guid:
        return {'flag': False, "message": "Transaction ID is Required"}
    if not account_number:
        return {'flag': False, "message": "Account Number is Required"}
    
    # Mode Check
    if mode == 'UAT':
        if str(tenant_id)=='212':
            tenant_name = 'Altaworx'
            tenant_id = '1'

    billing_platform_db = DB(billing_db_name, **db_config)
    bp_common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # ENV Variables
    post_url = os.environ.get("post_url", "")
    merchant_key = os.environ.get("merchant_key", "")
    merchant_secret = os.environ.get("merchant_secret", "")
    currency_code = os.environ.get("trx_current_code", "")

    required_env_vars = ["post_url", "merchant_key", "merchant_secret", "trx_current_code"]
    missing_env = [var for var in required_env_vars if not var]
    if missing_env:
        return {"flag": False, "message": f"Missing required ENV variables: {', '.join(missing_env)}"}

    # Additional metadata for audit
    created_by = data.get("username", "")
    session_id = data.get("session_id", None)
    module_name = data.get('module_name','Payment Cancellation')
    request_received_at = data.get('request_received_at',None)

    payment_df = billing_platform_db.get_data("payment_history", {"ref": transaction_guid}, None)
    if payment_df is None or payment_df.empty:
        return {"flag": False, "message": "Transaction not found in payment_history."}

    logging.info(f'###transaction_charge_back fetched payment_df {payment_df}')
    payment_category = payment_df['category'].iloc[0] if 'category' in payment_df.columns else None

    # Handle missing or None values safely
    if not payment_category:
        return {"flag": False, "message": "Payment category is missing or null for this transaction."}

    if payment_category.lower() not in ['credit', 'ach']:
        return {"flag": False, "message": f"Unsupported payment category: {payment_category}"}

    payment_category = payment_category.lower()

    logging.info(f"## transaction_charge_back payment_category = {payment_category}")
    total_amount = payment_df['amount'].sum()
    total_amount = round(float(total_amount), 2)
    # formatted_amount = f"{amount_value:.2f}" 
    action = None
    try:
        if payment_category == "ach":
            action = "Returned"
            res_json = return_transaction_ach(
                transaction_guid, total_amount, currency_code,
                post_url, merchant_key, merchant_secret,
                bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
            )
        else:  # credit
            action = "Returned"
            res_json = return_transaction(
                transaction_guid, total_amount, currency_code,
                post_url, merchant_key, merchant_secret,
                bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
            )
        logging.info(f"## transaction_charge_back TRX API response: {res_json}")

        # --- Validate TRX API response ---
        is_valid, debug_msg = validate_trx_response(res_json, bp_common_utils_db, created_by, tenant_name, session_id, module_name, request_received_at
        )
        if not is_valid:
            logging.warning(f"## cancel_payment_fucntion TRX response invalid: {debug_msg}")
            # Insert failed record into charge_back_history
            failed_chargeback_data = {
                # "bill_list": ",".join([f"INV{str(bill_id)}" for bill_id in payment_df["bill_id"].tolist()]) if "bill_id" in payment_df.columns else None,
                "bill_list": ",".join([f"INV{str(int(bill_id)).zfill(4)}" for bill_id in payment_df["bill_id"].tolist()]) if "bill_id" in payment_df.columns else None,
                "account_number": account_number,
                "cancel_reason": cancel_reason or debug_msg,
                "amount": str(total_amount),
                "last_four": payment_df["method"].iloc[0] if "method" in payment_df.columns else None,
                "activity": "Return Failed",
                "category": payment_df["category"].iloc[0] if "category" in payment_df.columns else None,
                # "date": request_received_at,
                "ref_guid": transaction_guid,
                "customer_name": customer_name,
                "status": "Failed",
                "created_date": request_received_at,
                "modified_date": request_received_at,
                "tenant_id": tenant_id,
                "tenant_name": tenant_name,
                "created_by": created_by,
                "modified_by": created_by
            }
            chargeback_insert_status = billing_platform_db.insert_data(failed_chargeback_data, "charge_back_history")
            logging.info(f"## cancel_payment_fucntion inserted FAILED record into charge_back_history for ref={transaction_guid} chargeback_insert_status {chargeback_insert_status}")
            
            return {"flag": True, "message": debug_msg, "validation": True}
        transaction_charge_back_data = {"cancel_payment_flag": True}
        if cancel_reason:
            transaction_charge_back_data['cancel_reason'] = cancel_reason
        if created_by:
            transaction_charge_back_data['modified_by'] = created_by
        if action:
            transaction_charge_back_data['status'] = action
        logging.info(f"## transaction_charge_back transaction_charge_back_data {transaction_charge_back_data}")
        update_status = billing_platform_db.update_dict(
            "payment_history",
            transaction_charge_back_data,
            {"ref": transaction_guid}
        )
        logging.info(f"## transaction_charge_back marked payment_history as cancelled for ref={transaction_guid} update_status {update_status}")

        new_transaction_id = res_json.get('Message', {}).get('Response', {}).get('TransactionId', transaction_guid)
        new_date = datetime.utcnow().isoformat()

        new_account_balanace = update_account_balance(total_amount , billing_platform_db, account_number)
        logging.info(f"## cancel_payment balance_update_status {new_account_balanace}")
        if not new_account_balanace:
            new_account_balanace = 0
        insert_status = insert_transaction_charge_back_history(billing_platform_db, payment_df, new_transaction_id, new_date, bp_common_utils_db, created_by, tenant_name, session_id, module_name,request_received_at,charge_back_fee,new_account_balanace)
        # After inserting into transaction_charge_back_history
        chargeback_data = {
            # "bill_list": ",".join([f"INV{str(bill_id)}" for bill_id in payment_df["bill_id"].tolist()]) if "bill_id" in payment_df.columns else None,
            "bill_list": ",".join([f"INV{str(int(bill_id)).zfill(4)}" for bill_id in payment_df["bill_id"].tolist()]) if "bill_id" in payment_df.columns else None,
            "account_number": account_number,
            "cancel_reason": cancel_reason or res_json.get('Message', {}).get('Response', {}).get('ResponseText', ''),
            "amount": str(total_amount),
            "last_four": payment_df["method"].iloc[0] if "method" in payment_df.columns else None,
            "activity": action,
            "category": payment_df["category"].iloc[0] if "category" in payment_df.columns else None,
            # "date": request_received_at,
            "ref_guid": transaction_guid,
            "customer_name": customer_name,
            "status": action,
            "created_date": request_received_at,
            "modified_date": request_received_at,
            "tenant_id": tenant_id,
            "tenant_name": tenant_name,
            "created_by": created_by,
            "modified_by": created_by
        }
        chargeback_insert_status = billing_platform_db.insert_dict(chargeback_data,"charge_back_history")
        logging.info(f"## transaction_charge_back inserted record into charge_back_history: {chargeback_data} status: {chargeback_insert_status}")

        # account_balance_update_status = update_account_balance(total_amount , billing_platform_db , account_number)
        # logging.info(f"## transaction_charge_back account_balance_update_status {account_balance_update_status}")
        
        # Audit success
        if insert_status:
            updated_data = {'transaction_id':transaction_guid}
            message = "Failed update transaction data"
            audit_data = {
                "service_name": "transaction_charge_back",
                "status": "Success",
                "created_by": created_by,
                "time_consumed_secs": int(time.time() - start_time),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(updated_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            bp_common_utils_db.update_audit(audit_data, "audit_user_actions")
            logging.info(f"Audit logged for transaction_charge_back: {audit_data}")
        else:
            failed_data = {'transaction_id':transaction_guid}
            # Error audit
            error_data = {
                "service_name": "transaction_charge_back",
                "error_message": "Insert operation returned failure status",
                "users": created_by,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": json.dumps(failed_data),
                "module_name": module_name,
                "request_received_at": request_received_at,
            }
            bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
            logging.error(f"Error audit logged for transaction_charge_back: {error_data}")

        return {"flag": True, "message": f"Successfully Processed the Chargeback"}

    except Exception as e:
        logging.error(f"## transaction_charge_back error: {str(e)}")
        # Error log
        error_data = {
            "service_name": "transaction_charge_back",
            "error_message": str(e),
            "error_type": str(type(str(e)).__name__),
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "comments": json.dumps(data),
            "module_name": module_name,
            "request_received_at": request_received_at,
        }
        bp_common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": 'Failed to perform Chargeback'}



def call_trx_api(post_url, merchant_key, merchant_secret, payload):
    """
    Calls the TRX API and returns a tuple: (success_flag, response_or_error_message)

    Returns:
        (bool, dict or str): True and JSON response on success, False and error message on failure.
    """
    headers = {
        "Content-Type": "application/json",
        "Merchant-Key": merchant_key,
        "Merchant-Secret": merchant_secret
    }

    try:
        logging.info(f"### call_trx_api sending request to post_url {post_url} with payload: {json.dumps(payload)} with headers {headers}")
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
        return True, response.json()
    except requests.exceptions.RequestException as e:
        logging.error(f"### call_trx_api request failed: {str(e)}")
        return False, f"Request failed: {str(e)}"
    except Exception as e:
        logging.error(f"### call_trx_api unexpected error: {str(e)}")
        return False, f"Unexpected error: {str(e)}"

def get_customer_names_by_user(
    role_name,
    username,
    common_utils_database,
    tenant_db
):
    """
    Returns customer names accessible to the given user based on role and mappings.

    Rules:
    - Super Admin & Partner Admin → returns None (unrestricted access)
    - User has 'customers' field → returns parsed customer list
    - User has 'customer_group' → returns customers from group mapping
    - No mapping found or errors → returns empty list []

    Args:
        role_name (str): User's role name for admin bypass check
        username (str): Username to lookup customer permissions
        common_utils_database: Database connection for users table
        tenant_db: Tenant-specific database for customergroups table

    Returns:
        Optional[List[str]]: List of allowed customer names, None for admins, or []

    Raises:
        None: All errors handled gracefully, returns []
    """
    logging.info("## get_customer_names_by_user function called")

    try:
        # Admin bypass → no restriction
        if not role_name or str(role_name).lower() in ["super admin", "partner admin"]:
            logging.info("## get_customer_names_by_user admin role → unrestricted")
            return None

        # **FIX: Add null check before calling get_data**
        user_data = common_utils_database.get_data(
            table_name="users",
            condition={
                "username": username,
                "is_active": True
            },
            columns=["customers", "customer_group"]
        )

        # **FIX: Check for None or non-DataFrame response**
        if user_data is None or not hasattr(user_data, 'empty') or user_data.empty:
            logging.info("## get_customer_names_by_user user mapping not found")
            return []

        def normalize_value(value):
            """Normalize string/JSON/comma-separated values to list or None."""
            if value is None:
                return None

            if isinstance(value, str):
                cleaned = value.strip()
                if cleaned.lower() in ["", "null", "none"]:
                    return None

                try:
                    parsed = json.loads(cleaned)
                    return parsed
                except json.JSONDecodeError:
                    if "," in cleaned:
                        return [v.strip() for v in cleaned.split(",") if v.strip()]
                    return cleaned

            return value

        customers = normalize_value(user_data.iloc[0].get("customers"))
        customer_group = normalize_value(user_data.iloc[0].get("customer_group"))

        logging.info(
            f"## get_customer_names_by_user customers={customers}, customer_group={customer_group}"
        )

        # Case 1: Direct customers (highest priority)
        if customers:
            if isinstance(customers, str):
                customers = [customers]
            return customers

        # Case 2: Customer group lookup
        if customer_group:
            logging.info(f"## get_customer_names_by_user customer_group exist as {customer_group}")
            group_data = tenant_db.get_data(
                table_name="customergroups",
                condition={"name": customer_group},
                columns=["customer_names"]
            )

            # **FIX: Consistent null/empty check**
            # if group_data is None or not hasattr(group_data, 'empty') or group_data.empty:
            if group_data is None or group_data.empty:
                logging.info("## get_customer_names_by_user group not found or empty")
                return []

            customer_names = normalize_value(group_data.iloc[0].get("customer_names"))

            if isinstance(customer_names, str):
                customer_names = [customer_names]

            return customer_names or []

        # No customers or groups mapped
        logging.info("## get_customer_names_by_user no customers and no group")
        return []

    except Exception as e:
        logging.exception(f"## get_customer_names_by_user error: {e}")
        return []

def charge_back_exceptions_list_view(data):
    """
    Fetches chargeback exception details from the charge_back_history table,
    processes the response, and returns a paginated and role-based header-mapped result.

    Steps:
        1. Fetch records from charge_back_history for the given tenant_id
        2. Map fields to expected response format
        3. Apply pagination & headers
    """
    try:
        logging.info(f"### charge_back_exceptions_list_view called with data: {data}")
        start_time = time.time()

        # Extract inputs from UI Payload
        tenant_id = data.get("tenant_id",None)
        tenant_name = data.get("tenant_name", "")
        role_name = data.get("role_name", "")
        tenant_db = data.get("db_name", "")
        start = data.get("mod_pages", {}).get("start", 0)
        end = data.get("mod_pages", {}).get("end", 100)
        mode = os.getenv('ENV', '')
        col_sort = data.get("col_sort", "")
        billing_db_name = data.get('billing_db_name',None)

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        
        # DB connections
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        tenant_db_conn = DB(tenant_db, **db_config)

        tenant_time_zone = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name},["time_zone"]
            )["time_zone"].to_list()[0]
        logging.info(f"## chargeback_history_list_view **tenant_time_zone {tenant_time_zone}")

        if tenant_time_zone is None:
                raise ValueError("No valid timezone found for tenant.")

        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        if not tenant_id:
            return {"flag": True, "message": "Missing Tenant ID", "data": {},'Validation':True}
        # ---------- Customer Access ----------
        customer_names = None  # Default → no restriction

        if role_name not in ("Super Admin", "Partner Admin"):
            config_customers = db_config.get("customers")  # fetch from db_config if defined
            
            if config_customers:
                customer_names = normalize_customers_from_config(config_customers)

            # If no customers → return empty immediately
            if not customer_names:
                return {
                    "flag": True,
                    "message": "No chargeback exceptions found",
                    "header_map": {},
                    "data": {"exceptions": []},
                    "pages": {"start": start, "end": end, "total": 0}
                }

        if mode == 'UAT':
            if str(tenant_id)=='212':
                tenant_name = 'Altaworx'
                tenant_id = '1'
        if col_sort:
            order =  {k: v.lower() for k, v in col_sort.items()}
            logging.info(f"orderis {order}")
        else:
            order= {"date":"desc"}
        
        # Header mapping
        try:
            header_map = get_headers_mapping(
                tenant_db, ["Chargeback Exceptions"], role_name, '', '', '', '', data
            )
        except Exception as e:
            logging.error(f"### Error generating header_map: {str(e)}")
            header_map = {}

        conditions = {"tenant_id": str(tenant_id)}
        # Apply customer filter only if restricted
        if customer_names:
            conditions["customer_name"] = customer_names
        # Fetch all records for the given tenant_id
        cbh_records_df = billing_platform_db.get_data(
            "charge_back_history",
            conditions,
            [
                "bill_list",
                "account_number",
                "cancel_reason",
                "amount",
                "last_four",
                "activity",
                "category",
                "date",
                "ref_guid",
                "customer_name",
                "status"
            ],
            order
        )

        if cbh_records_df is None or cbh_records_df.empty:
            return {"flag": True, "message": "No chargeback exceptions found", "header_map": header_map,"data": {"exceptions": []}, "pages": {"start": start, "end": end, "total": 0}}

        # Extract start_date and end_date from payload
        start_date_str = data.get("start_date")  # e.g., "10/02/2025"
        end_date_str = data.get("end_date")      # e.g., "10/16/2025"

        # Convert start_date and end_date to datetime
        start_date = datetime.strptime(start_date_str, "%m/%d/%Y") if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%m/%d/%Y") + timedelta(days=1) if end_date_str else None

        # Filter DataFrame
        if cbh_records_df is not None and not cbh_records_df.empty:
            if start_date and end_date:
                cbh_records_df = cbh_records_df[
                    (cbh_records_df["date"] >= start_date) &
                    (cbh_records_df["date"] < end_date)  # less than to include full original end_date
                ]
        # Map records to response format
        # mapped_rows = []
        # for _, row in cbh_records_df.iterrows():
        #     mapped_rows.append({
        #         "bill_id": row.get("bill_list"),
        #         "account_number": row.get("account_number", ""),
        #         "cancel_reason": row.get("cancel_reason", ""),
        #         "amount": row.get("amount"),
        #         "method": row.get("last_four", ""),
        #         "activity": row.get("activity", ""),
        #         "category": row.get("category", ""),
        #         "date": row.get("date"),
        #         "ref": row.get("ref_guid", ""),
        #         "customer_name": row.get("customer_name", ""),
        #         "status": row.get("status", "")
        #     })

        # Map records to response format
        mapped_rows = []
        for _, row in cbh_records_df.iterrows():
            category = row.get("category", "")

            # Normalize category
            if category:
                if category.lower() == "credit":
                    category = "Credit"
                elif category.lower() == "ach":
                    category = "ACH"
                else:
                    category = category.capitalize()
            # Format amount to always show two decimal places
            amount_value = row.get("amount")
            try:
                if amount_value is not None and amount_value != "":
                #     amount_value = f"{float(amount_value):.2f}"
                # else:
                #     amount_value = "0.00"
                    amount_value = format_amount(amount_value)
            except Exception:
                amount_value = "0.00"
            mapped_rows.append({
                "bill_list": row.get("bill_list"),
                "account_number": row.get("account_number", ""),
                "cancel_reason": row.get("cancel_reason", ""),
                # "amount": row.get("amount"),
                "amount": amount_value,
                "last_four": row.get("last_four", ""),
                "activity": row.get("activity", ""),
                "category": category,
                "date": row.get("date"),
                "ref_guid": row.get("ref_guid", ""),
                "customer_name": row.get("customer_name", ""),
                "status": row.get("status", "")
            })


        # Pagination
        total_count = len(mapped_rows)
        pages = {"start": start, "end": end, "total": total_count}
        paginated_rows = mapped_rows[start:end]
        

        logging.info(f"## chargeback_history_list_view **paginated_rows {paginated_rows}----{tenant_time_zone}")
        paginated_rows = convert_timestamp(paginated_rows, tenant_time_zone)

        

        response = {
            "flag": True,
            "message": "Chargeback exception data fetched successfully",
            "data": {"exceptions": serialize_data(paginated_rows)},
            "header_map": header_map,
            "pages": pages,
            "time_consumed_secs": int(time.time() - start_time)
        }
        return response

    except Exception as e:
        logging.exception(f"### charge_back_exceptions_list_view unexpected error: {e}")
        message = "Failed to Fetch Charge Back List View"
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        error_data = {
            "service_name": "charge_back_exceptions_list_view",
            "error_message": message,
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"{message}: {str(e)}",
            "module_name": 'Chargeback Exceptions',
            "request_received_at": data.get("request_received_at", "")
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message, "data": {}}



def charge_back_exceptions_list_view_30_12_2025(data):
    """
    Fetches chargeback exception details from the charge_back_history table,
    processes the response, and returns a paginated and role-based header-mapped result.

    Steps:
        1. Fetch records from charge_back_history for the given tenant_id
        2. Map fields to expected response format
        3. Apply pagination & headers
    """
    try:
        logging.info(f"### charge_back_exceptions_list_view called with data: {data}")
        start_time = time.time()

        # Extract inputs from UI Payload
        tenant_id = data.get("tenant_id",None)
        tenant_name = data.get("tenant_name", "")
        role_name = data.get("role_name", "")
        tenant_db = data.get("db_name", "")
        start = data.get("mod_pages", {}).get("start", 0)
        end = data.get("mod_pages", {}).get("end", 100)
        mode = os.getenv('ENV', '')
        col_sort = data.get("col_sort", "")
        billing_db_name = data.get('billing_db_name',None)

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        
        # DB connections
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)

        tenant_time_zone = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name},["time_zone"]
            )["time_zone"].to_list()[0]
        logging.info(f"## chargeback_history_list_view **tenant_time_zone {tenant_time_zone}")

        if tenant_time_zone is None:
                raise ValueError("No valid timezone found for tenant.")

        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        if not tenant_id:
            return {"flag": True, "message": "Missing Tenant ID", "data": {},'Validation':True}
        if mode == 'UAT':
            if str(tenant_id)=='212':
                tenant_name = 'Altaworx'
                tenant_id = '1'
        if col_sort:
            order =  {k: v.lower() for k, v in col_sort.items()}
            logging.info(f"orderis {order}")
        else:
            order= {"date":"desc"}
        
        # Header mapping
        try:
            header_map = get_headers_mapping(
                tenant_db, ["Chargeback Exceptions"], role_name, '', '', '', '', data
            )
        except Exception as e:
            logging.error(f"### Error generating header_map: {str(e)}")
            header_map = {}

        # Fetch all records for the given tenant_id
        cbh_records_df = billing_platform_db.get_data(
            "charge_back_history",
            {"tenant_id": str(tenant_id)},
            [
                "bill_list",
                "account_number",
                "cancel_reason",
                "amount",
                "last_four",
                "activity",
                "category",
                "date",
                "ref_guid",
                "customer_name",
                "status"
            ],
            order
        )

        if cbh_records_df is None or cbh_records_df.empty:
            return {"flag": True, "message": "No chargeback exceptions found", "header_map": header_map,"data": {"exceptions": []}, "pages": {"start": start, "end": end, "total": 0}}

        # Extract start_date and end_date from payload
        start_date_str = data.get("start_date")  # e.g., "10/02/2025"
        end_date_str = data.get("end_date")      # e.g., "10/16/2025"

        # Convert start_date and end_date to datetime
        start_date = datetime.strptime(start_date_str, "%m/%d/%Y") if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%m/%d/%Y") + timedelta(days=1) if end_date_str else None

        # Filter DataFrame
        if cbh_records_df is not None and not cbh_records_df.empty:
            if start_date and end_date:
                cbh_records_df = cbh_records_df[
                    (cbh_records_df["date"] >= start_date) &
                    (cbh_records_df["date"] < end_date)  # less than to include full original end_date
                ]
        # Map records to response format
        # mapped_rows = []
        # for _, row in cbh_records_df.iterrows():
        #     mapped_rows.append({
        #         "bill_id": row.get("bill_list"),
        #         "account_number": row.get("account_number", ""),
        #         "cancel_reason": row.get("cancel_reason", ""),
        #         "amount": row.get("amount"),
        #         "method": row.get("last_four", ""),
        #         "activity": row.get("activity", ""),
        #         "category": row.get("category", ""),
        #         "date": row.get("date"),
        #         "ref": row.get("ref_guid", ""),
        #         "customer_name": row.get("customer_name", ""),
        #         "status": row.get("status", "")
        #     })

        # Map records to response format
        mapped_rows = []
        for _, row in cbh_records_df.iterrows():
            category = row.get("category", "")

            # Normalize category
            if category:
                if category.lower() == "credit":
                    category = "Credit"
                elif category.lower() == "ach":
                    category = "ACH"
                else:
                    category = category.capitalize()
            # Format amount to always show two decimal places
            amount_value = row.get("amount")
            try:
                if amount_value is not None and amount_value != "":
                    amount_value = f"{float(amount_value):.2f}"
                else:
                    amount_value = "0.00"
            except Exception:
                amount_value = "0.00"
            mapped_rows.append({
                "bill_list": row.get("bill_list"),
                "account_number": row.get("account_number", ""),
                "cancel_reason": row.get("cancel_reason", ""),
                # "amount": row.get("amount"),
                "amount": amount_value,
                "last_four": row.get("last_four", ""),
                "activity": row.get("activity", ""),
                "category": category,
                "date": row.get("date"),
                "ref_guid": row.get("ref_guid", ""),
                "customer_name": row.get("customer_name", ""),
                "status": row.get("status", "")
            })


        # Pagination
        total_count = len(mapped_rows)
        pages = {"start": start, "end": end, "total": total_count}
        paginated_rows = mapped_rows[start:end]
        

        logging.info(f"## chargeback_history_list_view **paginated_rows {paginated_rows}----{tenant_time_zone}")
        paginated_rows = convert_timestamp(paginated_rows, tenant_time_zone)

        

        response = {
            "flag": True,
            "message": "Chargeback exception data fetched successfully",
            "data": {"exceptions": serialize_data(paginated_rows)},
            "header_map": header_map,
            "pages": pages,
            "time_consumed_secs": int(time.time() - start_time)
        }
        return response

    except Exception as e:
        logging.exception(f"### charge_back_exceptions_list_view unexpected error: {e}")
        message = "Failed to Fetch Charge Back List View"
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        error_data = {
            "service_name": "charge_back_exceptions_list_view",
            "error_message": message,
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"{message}: {str(e)}",
            "module_name": 'Chargeback Exceptions',
            "request_received_at": data.get("request_received_at", "")
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message, "data": {}}


def format_amount_field_value(value):
    try:
        return "{:,.2f}".format(float(value))
    except (TypeError, ValueError):
        return value

def generate_payment_receipt(data):
    # DB Name Validation
    logging.info(f'generate_payment_receipt data-------{data}')
    billing_db_name = data.get('billing_db_name',None)
    if not billing_db_name:
        return {"flag":False,"message":"Billing DB Name is required"}
    
    # DB Connections
    killbill_database = DB(billing_db_name, **db_config)
    common_utils_db = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
    table = data.get("table_name", "payment_history")

    try:
        logging.info(f'data recieved-----{data}')
        payment_dict = {}
        tenant_id = data.get("tenant_id", "")
        tenant_name = data.get("tenant_name", "")
        mode = os.environ.get("ENV", "")
        if mode == "UAT" and tenant_name == 'Altaworx Test':
            tenant_id = 1
            tenant_name = 'Altaworx'

        try:
            logo_url = common_utils_db.get_data("tenant", {"tenant_name": tenant_name}, ["logo"]).get("logo", [""])[0]
        except:
            logo_url = ""

        logging.info(f"Logo URL: {logo_url}")
        row_id = data.get("id", "")
        ref = data.get("ref", "")
        payment_details = None
        if row_id:
            payment_details = killbill_database.get_data(
                table,
                {"id": int(row_id)},
                []
            ).to_dict(orient='records')
        elif ref:
            payment_details = killbill_database.get_data(
                table,
                {"ref": ref},
                []
            ).to_dict(orient='records')
        
        logging.info(f'payment_details------{payment_details}')
        if not payment_details:
            return {"flag": False, "message": "No payment details found for the given row_id."}
        payment_info = payment_details[0]
        account_number = payment_info.get("account_number", "")
        if account_number:
            customer_info = killbill_database.get_data(
                "customer_profiles",
                {"account_number": account_number},
                ["customer_name"]
            ).to_dict(orient='records')
            customer_name = customer_info[0].get("customer_name", "") if customer_info else ""
        payment_dict["customer"] = customer_name
        payment_dict["receipt_no"] = payment_info.get("id", "")
        payment_dict["received_by"] = tenant_name
        payment_dict["account_no"] = account_number
        records = []
        bill_ids = [record.get("bill_id") for record in payment_details if record.get("bill_id")]
        new_bill_list = killbill_database.get_data('customer_bills', {'id': bill_ids}, ['id', 'bill_id'])
        bill_id_map = dict(zip(new_bill_list['id'], new_bill_list['bill_id']))  # {id: bill_id}
        logging.info(f'bill_id_map--------{bill_id_map}')
        for record in payment_details:
            category = record.get("category", "")
            if isinstance(category, str):
                if category.lower() == "credit":
                    category = "Credit"
                elif category.lower() == "ach":
                    category = "ACH"
                else:
                    pass
            record_dict = {
                "bill_id": bill_id_map.get(int(record["bill_id"]) if str(record.get("bill_id")).isdigit() else "", ""),
                "transaction_id": record.get("ref", ""),
                "received_on": record.get("date").strftime("%m-%d-%Y") if record.get("date") else "",
                "method": category,
                "amount": format_amount_field_value(record.get("amount", 0) or 0)
            }
            records.append(record_dict)
        payment_dict["records"] = records

        logging.info(f'payment_dict------{payment_dict}')
        download_url = generate_payment_receipt_pdf(payment_dict, logo_url)

        return {"flag": True, "download_url": download_url}
    
    except Exception as e:
        logging.info(f"Error generating payment receipt: {str(e)}")
        return {"flag": False, "message": f"Error generating payment receipt: {str(e)}"}

def prepare_logo(logo_b64: str):
    # strip prefix if present
    if logo_b64.startswith("data:"):
        logo_b64 = logo_b64.split(",")[1]

    # decode and open with Pillow
    raw = base64.b64decode(logo_b64 + "===")
    img = Image.open(io.BytesIO(raw)).convert("RGBA")

    # create white background
    bg = Image.new("RGB", img.size, (255, 255, 255))
    bg.paste(img, mask=img.split()[3])  # paste using alpha channel

    # re-wrap into ImageReader for ReportLab
    buffer = io.BytesIO()
    bg.save(buffer, format="PNG")
    buffer.seek(0)
    return ImageReader(buffer)

def format_transaction_id(text):
    text = str(text).strip()
    max_line_length = 20

    # If text fits in one line → return single line
    if len(text) <= max_line_length:
        return [text]

    # Otherwise split into two lines
    line1 = text[:max_line_length]
    remaining = text[max_line_length:]

    line2 = remaining[:max_line_length]

    # If still more text beyond second line → add ellipsis
    if len(remaining) > max_line_length:
        line2 = line2[:max_line_length] + "..."

    return [line1, line2]

def generate_payment_receipt_pdf(data, logo_url, output_path="payment_receipt.pdf"):
    """
    Generates a payment receipt PDF with:
      - Logo at top-left
      - Receipt info at top-right
      - Table below details (header in grey, rows below)
    Uses A4 size. Uploads the PDF to S3.
    """
    try:
        # --- PDF Config ---
        page_width, page_height = A4
        left_margin = inch / 2
        right_margin = inch / 2
        top_margin = inch / 2
        row_height = 18  # slightly bigger row height for clarity

        buffer = BytesIO()
        c = canvas.Canvas(buffer, pagesize=A4)

        # --- Draw Logo (top-left) ---
        logo_height = 0
        if logo_url:
            try:
                if logo_url:
                    if logo_url.startswith('data:'):
                        # Split by comma and take the base64 part
                        logo_url = logo_url.split(',')[1]
                    logo_data = base64.b64decode(logo_url)
                    logo_stream = io.BytesIO(logo_data)
                    logo_image = prepare_logo(logo_url)
                    img_width, img_height = logo_image.getSize()
                    aspect = img_height / float(img_width)

                    display_width = 150
                    display_height = display_width * aspect

                    c.drawImage(logo_image, 30, page_height - display_height - 30,
                                width=display_width, height=display_height)
        
            except Exception as e:
                logging.warning(f"Failed to load logo: {e}")
                logo_height = 0

       
        receipt_fields = [
            ("Receipt No:", data.get("receipt_no", "")),
            ("Received By:", data.get("received_by", "")),
            ("Customer:", data.get("customer", "")),
            ("Acct No.:", data.get("account_no", "")),
        ]

        c.setFont("Helvetica", 10)
        line_height = 14
        top_y = page_height - top_margin - 15
        current_y = top_y

        # how far from right edge we draw values
        right_x = page_width - right_margin  

        # max label width so they align nicely
        max_label_width = max(c.stringWidth(lbl, "Helvetica", 10) for lbl, _ in receipt_fields)
        gap = 10  
        font_name = "Helvetica"
        font_size = 10

        # for label, value in receipt_fields:
        #     c.drawRightString(right_x, current_y, str(value))
        #     c.drawRightString(right_x - (c.stringWidth(str(value), "Helvetica", 10) + 10),
        #                     current_y, label)
        #     current_y -= line_height
        block_width = max_label_width + gap + 100   # adjust 120 → smaller = more right, bigger = more left

        for label, value in receipt_fields:
            label_x = right_x - block_width
            value_x = label_x + max_label_width + gap

            c.drawString(label_x, current_y, label)
            c.drawString(value_x, current_y, str(value))

            current_y -= line_height

        receipt_bottom_y = current_y - 10

        # --- Table Header & Rows ---  
        c.setFont("Helvetica-Bold", 10)
        row_height = 18
        padding_y = 4  # vertical padding inside cells

        # Table columns (x positions)
        columns = [
            ("S. No", left_margin),
            ("Bill ID", left_margin + 0.7 * inch),
            ("Transaction ID", left_margin + 1.8 * inch),
            ("Received On", left_margin + 4.0 * inch),
            ("Method", left_margin + 5.8 * inch),
            ("Amount", left_margin + 6.8 * inch),
        ]

        # Starting Y for the table (below receipt info/logo)
        table_start_y = min(page_height - top_margin - logo_height, receipt_bottom_y) - 30

        # --- Draw Header Box ---
        c.setFillColor(colors.whitesmoke)
        c.rect(
            left_margin,
            table_start_y - row_height,
            page_width - left_margin - right_margin + 10,
            row_height,
            fill=1,
            stroke=0
        )
        c.setFillColor(colors.black)

        # --- Draw Header Text (vertically centered in grey box) ---
        text_y = table_start_y - row_height + (row_height / 2) - 3  # tweak for baseline
        for col_name, x in columns:
            c.drawString(x, text_y, col_name)

        # --- Draw Rows ---
        c.setFont("Helvetica", 10)
        header_spacing = 6  # extra space between header and first row
        y = table_start_y - row_height - header_spacing
        for i, record in enumerate(data.get("records", []), start=1):
            y -= row_height  # move down for next row
            c.drawString(columns[0][1], y + padding_y, str(i))
            c.drawString(columns[1][1], y + padding_y, str(record.get("bill_id", "")))
            # c.drawString(columns[2][1], y + padding_y, str(record.get("transaction_id", "")))
            # --- Transaction ID special formatting ---
            tx_lines = format_transaction_id(record.get("transaction_id", ""))

            col_x = columns[2][1]
            line_spacing = 10
            font_size = 10
            top_padding = 4
            num_lines = len(tx_lines)

            if num_lines == 1:
                text_y = y + (row_height - font_size) / 2 + 1
                c.drawString(col_x, text_y, tx_lines[0])
            else:
                text_y = y + padding_y + 10
                for line in tx_lines:
                    c.drawString(columns[2][1], text_y, line)
                    text_y -= 10

            c.drawString(columns[3][1], y + padding_y, str(record.get("received_on", "")))
            c.drawString(columns[4][1], y + padding_y, str(record.get("method", "")))
            c.drawString(columns[5][1], y + padding_y, "$" + str(record.get("amount", "")))


        # --- Finalize PDF ---
        c.showPage()
        c.save()

        buffer.seek(0)

        # --- Upload to S3 ---
        try:
            reciept_id = data.get("receipt_no", "unknown_receipt")
            s3_key = f"billing_platform_uat/{reciept_id}.pdf"
            bucket_name = "billing-platform-email"
            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=bucket_name,
                Key=s3_key,
                Body=buffer.getvalue(),
                ContentType="application/pdf"
            )
            download_url = f"https://{bucket_name}.s3.amazonaws.com/{s3_key}"
            logging.info(f"PDF uploaded to S3: {download_url}")
            return download_url
        except Exception as e:
            logging.error(f"Error uploading to S3: {e}")
            return None

    except Exception as e:
        logging.info(f"Error generating PDF: {e}")
        return None



def export_to_s3_bucket_(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]
    logging.info(f'data recieved by export_to_s3_bucket_-------{data}')

    # Extract input parameters
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("username", "")
    session_id = data.get("session_id", "")
    tenant_database = data.get("db_name", "")
    data_frames = data.get("dfs", {})  # Expecting a dict {"Sheet1": df1, "Sheet2": df2}
    batch_unique_code = data.get("batch_unique_code", "")
    tenant_id = data.get("tenant_id", "")
    if module_name == 'Multi Account Payment':
        file_name = f"exports/uat/{module_name_snake_case}/transactions_{batch_unique_code}.xlsx"
    else:
        file_name = f"exports/uat/{module_name_snake_case}/{module_name}_{tenant_id}_{user_name}.xlsx"

    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

    db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

    # Update export status to 'Waiting'
    updated_flag=db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
    )
    if not updated_flag:
        db.insert_data({"status_flag": "Waiting", "url": "","tenant_id": tenant_id,"user_name": user_name,"module_name":module_name},"export_status")


    try:
        if not data_frames:
            db.update_dict(
                "export_status",
                {"status_flag": "No Data Found for export", "url": ""},
                {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name},
            )
            return {"flag": False, "message": "No data found for export."}

        excel_buffer = BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            for sheet_name, df in data_frames.items():
                if df.empty:
                    # df = pd.DataFrame(columns=["No Data"])
                    pass

                # Format column names
                acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN", "MB", "CCID", "ICCID", "SIM", "ID"}
                special_replacements = {"Att": "AT&T", "And": "and"}

                df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                    for col in df.columns
                ]
                df.columns = [
                    " ".join([special_replacements.get(word, word) for word in col.split(" ")]) for col in df.columns
                ]

                df.to_excel(writer, index=False, sheet_name=sheet_name)

                # Apply styles
                workbook = writer.book
                sheet = workbook[sheet_name]

                header_font = Font(bold=True)
                for cell in sheet[1]:
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    cell.font = header_font

                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        excel_buffer.seek(0)

        s3_client = boto3.client("s3")
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=file_name,
            Body=excel_buffer.getvalue(),
            ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )


        
        db.update_dict(
        "export_status",
        {"status_flag": "Success", "url": download_url},
        {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name})
            
        return {"flag": True, "download_url": download_url}

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name,"tenant_id": tenant_id,"user_name": user_name}
        )
        db.log_error_to_db(
            {
                "service_name": "export_to_s3_bucket_",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": f"Failed to export excel {module_name}",
                "module_name": "export",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}


def charge_back_exceptions_export(data):
    """
    Exports chargeback exceptions (from TRX API) for a given tenant and uploads the data to an S3 bucket.

    Parameters:
        data (dict): A dictionary containing:
            - start_date (str, optional): Start date for fetching exceptions (MM/DD/YYYY).
            - end_date (str, optional): End date for fetching exceptions (MM/DD/YYYY).
            - exception_type (str, optional): The type of exception (default: "Correction").
            - tenant_name (str, optional): The tenant name for error logging.
            - db_name (str, optional): The tenant DB name for header mapping.
            - username (str, optional): The username for error logging.
            - session_id (str, optional): Session ID for error logging.
            - request_received_at (str, optional): Request timestamp for error logging.

    Returns:
        dict: The response from `export_to_s3_bucket_`, indicating success or failure.
    """

    try:
        # Reuse your existing list view logic
        list_response = charge_back_exceptions_list_view(data)

        if not list_response.get("flag"):
            return {
                "flag": False,
                "message": f"Chargeback exceptions export failed: {list_response.get('message')}",
                "data": {}
            }

        exceptions = list_response.get("data", {}).get("exceptions", [])
        if not exceptions:
            return {
                "flag": False,
                "message": "No chargeback exception data found for export",
                "data": {}
            }

        # Column mapping for export
        columns = {
            "bill_id": "Bill_ID",
            "account_number": "Account_Number",
            "cancel_reason": "Cancel_Reason",
            "amount": "Amount",
            "method": "Method",
            "activity": "Activity",
            "category": "Card_Type",
            "date": "Date",
            "ref": "Transaction_ID"
        }

        final_res_list = []
        for record in exceptions:
            final_dict = {}
            for key, label in columns.items():
                final_dict[label] = record.get(key, "")
            final_res_list.append(final_dict)

        # Convert to DataFrame
        df = pd.DataFrame(final_res_list).fillna('')
        df = df.drop(columns=['tenant_id', 'modified_date'], errors='ignore')

        # Attach to data for export
        if not df.empty:
            data["dfs"] = {"chargeback_exceptions": df}
        else:
            data["dfs"] = {}

        # Export to S3
        return export_to_s3_bucket_(data)

    except Exception as e:
        logging.exception(f"Exception in charge_back_exceptions_export: {e}")
        return {
            "flag": False,
            "message": "Something went wrong during chargeback exceptions export",
            "data": {}
        }

def audit_success(common_utils_db, service_name, created_by, session_id, tenant_name, module_name, request_received_at, comments=None, time_consumed_secs=None):
    """
    Logs a success audit entry into audit_user_actions table.
    """
    try:
        audit_data = {
            "service_name": service_name,
            "status": "Success",
            "created_by": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "module_name": module_name,
            "request_received_at": request_received_at,
            "comments": json.dumps(comments) if comments else "{}",
            "time_consumed_secs": time_consumed_secs or 0
        }
        common_utils_db.update_audit(audit_data, "audit_user_actions")
        logging.info(f"## audit_success logged: {audit_data}")
    except Exception as e:
        logging.error(f"## audit_success failed: {e}")


def audit_error(common_utils_db, service_name, created_by, session_id, tenant_name, module_name, request_received_at, error_message, error_type="Exception", comments=None):
    """
    Logs an error audit entry into error_log_table.
    """
    try:
        error_data = {
            "service_name": service_name,
            "error_message": str(error_message),
            "error_type": error_type,
            "users": created_by,
            "session_id": session_id,
            "tenant_name": tenant_name,
            "module_name": module_name,
            "request_received_at": request_received_at,
            "comments": json.dumps(comments) if comments else "{}"
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        logging.error(f"## audit_error logged: {error_data}")
    except Exception as e:
        logging.error(f"## audit_error logging failed: {e}")


def validation_for_auto_debit_run(due_date, auto_debit_type):
    """
    Returns True if auto-debit should run today based on due_date and auto_debit_type.
    Rules:
      - Daily  => due_date + 0 days (every day from due date onwards)
      - Weekly => due_date + N*7 days (every 7 days after due date)
      - Null   => same as Daily
    """
    try:
        logging.info(f'## validation_for_auto_debit_run called with due_date {due_date}, auto_debit_type {auto_debit_type}')
        today = datetime.now().date()
        if not due_date:
            return False

        base_date = due_date.date()

        if not auto_debit_type or str(auto_debit_type).strip() == "":
            logging.info('## validation_for_auto_debit_run empty → treating as Daily')
            return today >= base_date

        auto_debit_type = auto_debit_type.lower()

        if auto_debit_type == "daily":
            logging.info('## validation_for_auto_debit_run = daily')
            return today >= base_date

        elif auto_debit_type == "weekly":
            logging.info('## validation_for_auto_debit_run = weekly')
            # Weekly runs if today is due_date + N*7
            days_since_due = (today - base_date).days
            return days_since_due >= 0 and days_since_due % 7 == 0

        else:
            logging.info(f'## Unknown validation_for_auto_debit_run {auto_debit_type}, defaulting to False')
            return False

    except Exception as e:
        logging.exception(f"## validation_for_auto_debit_run Exception occurred: {e}")
        return False

def auto_debit_by_guid(data):
    """
    Performs scheduled Auto-Debit (ACH / Credit Card) transactions for customer accounts
    with overdue bills, including auditing and error logging.

    The function validates merchant credentials, retrieves eligible customer profiles,
    checks overdue bills, creates a transaction batch, fetches payment methods, 
    processes payments through TRX, and audits both success and error cases.

    Parameters:
        None (uses environment variables and DB connections configured globally):
            - merchant_key (str): Merchant authentication key from environment.
            - merchant_secret (str): Merchant authentication secret from environment.
            - post_url (str): TRX API endpoint for processing transactions.
            - trx_current_code (str): Current TRX code for API integration.
            - BILLING_PLATFORM (str): Database connection string for billing platform.
            - BILLING_PLATFORM_COMMON_UTILS_DATABASE (str): DB connection string for billing platform utilities.
            - COMMON_UTILS_DATABASE (str): DB connection string for common utilities.

    Workflow:
        1. Validate merchant credentials from environment variables.
        2. Fetch customer profiles flagged for auto-debit.
        3. Retrieve overdue bills and filter accounts based on auto-debit type rules
           (Daily / Weekly / Null).
        4. Create and insert a transaction batch in the `transaction_status` table.
        5. Fetch default payment methods (ACH or Credit Card) for each account.
        6. Retrieve email templates for sending notifications.
        7. Perform auto-debit for each account using TRX API:
            - Credit card: `auto_debit_credit_card`
            - ACH: `auto_debit_ach`
        8. Handle TRX responses via `webhook_response_handler_for_auto_debit`.
        9. Log auditing success if all transactions processed,
           or log auditing error for validation/exceptions.

    Returns:
        dict: A structured response containing:
            - 'flag' (bool): Success status of the auto-debit process.
            - 'message' (str): Status message indicating result.
            - 'processed_accounts' (list): List of accounts processed with details such as
                - account_number (str)
                - customer_name (str)
                - bill_id (int)
                - due_date (str)
                - auto_debit_type (str)

    Auditing:
        - On success → Inserts an audit record with processed accounts and execution time.
        - On failure → Inserts an audit error record with exception details.
    """
    try:
        logging.info("## auto_debit_by_guid started")

        # Start time to track the event
        start_time = time.time()
        
        # DB Name Validation
        billing_db_name = data.get('billing_db_name',None)
        # tenant_db_config = data.get('tenant_db_config',None)
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}
        # ENV Variables
        merchant_key = os.environ.get("merchant_key")
        merchant_secret = os.environ.get("merchant_secret")
        post_url = os.environ.get("post_url", "")
        trx_current_code = os.environ.get("trx_current_code", "")

        # DB Connections
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # Validate merchant credentials once
        if not merchant_key or not merchant_secret or not post_url or not trx_current_code:
            message = "Merchant credentials are missing in environment variables"
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = "System",
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = datetime.utcnow().isoformat(),
                error_message = message,
                error_type = message,
                comments=message
            )
            return {'flag': False, "message": message}

        # -------------------------------
        # STEP 1: Fetch customer profiles
        # -------------------------------
        customer_profiles_data = killbill_database.get_data(
            "customer_profiles",
            {"auto_debit_flag": True},
            ["account_number", "id", "email", "customer_name", "amount_due", "tenant_name", "tenant_id", "account_balance","credit_card_fee"]
        )
        if customer_profiles_data is None or customer_profiles_data.empty:
            message = "No customer profiles found for auto-debit"
            audit_success(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = "System",
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = datetime.utcnow().isoformat(),
                comments=message,
                time_consumed_secs = int(time.time() - start_time)
            )
            return {"flag": True, "message": message}

        profiles_dict = {row["account_number"]: row for row in customer_profiles_data.to_dict(orient="records")}
        account_numbers = list(profiles_dict.keys())
        account_ids = [row["id"] for row in customer_profiles_data.to_dict(orient="records")]
        account_id_dict = dict(zip(account_numbers, account_ids))
        logging.info(f"## auto_debit_by_guid fetched profiles_dict {profiles_dict}")

        # -------------------------------
        # STEP 2: Fetch overdue bills
        # -------------------------------
        now = datetime.now()
        bills_df = killbill_database.get_data_bp(
            table_name="customer_bills",
            condition={
                "customer_profile_id": list(account_id_dict.values()),
                "amount_due": [">", 0],
                "due_date_of_this_bill": ["<=", now]
            },
            columns=["customer_profile_id", "due_date_of_this_bill", "id", "amount_due", "account_number", "payments", "total", "remaining"]
        )
        if bills_df is False or bills_df.empty:
            message = "No overdue bills found for auto-debit"
            account_data = {'account_numbers':account_numbers}
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = "System",
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = datetime.utcnow().isoformat(),
                comments=json.dumps(account_data),
                time_consumed_secs = int(time.time() - start_time)
            )
            return {"flag": True, "message": message}
        default_settings_map = {}
        try:
            # Fetch default_settings for all tenants at once
            default_settings_df = killbill_database.get_data(
                "default_settings",
                {},  # Fetch all
                ["sub_tenant_id", "enable_credit_card_fee_type", "credit_card_fee"]
            )
            # Build a dict for quick lookup by sub_tenant_id
            default_settings_map = {
                row["sub_tenant_id"]: {
                    "fee_setting": row["enable_credit_card_fee_type"],
                    "default_fee": float(row.get("credit_card_fee") or 0)
                } for row in default_settings_df.to_dict(orient="records")
            }
        except Exception as e:
            default_settings_map = {}
            logging.info(f"## auto_debit_by_guid Exception occured while fetching default settings as {e}")
        logging.info(f"## auto_debit_by_guid fetched default_settings_map {default_settings_map}")
        account_bill_data_mapping = {}
        bills_by_profile = {}
        processed_accounts = []
        for row in bills_df.to_dict(orient="records"):
            pid = row["customer_profile_id"]
            bills_by_profile.setdefault(pid, []).append(row)

        for acc_no, pid in account_id_dict.items():
            if pid in bills_by_profile:
                # Get latest bill (highest bill id)
                bills = sorted(bills_by_profile[pid], key=lambda x: x["id"], reverse=True)
                latest_bill = bills[0]
                due_date = latest_bill["due_date_of_this_bill"]
                auto_debit_type = profiles_dict[acc_no].get("auto_debit_type")

                if validation_for_auto_debit_run(due_date, auto_debit_type):
                    account_bill_data_mapping[acc_no] = bills
                    processed_accounts.append({
                        "account_number": acc_no,
                        "customer_name": profiles_dict[acc_no].get("customer_name"),
                        "bill_id": latest_bill["id"],
                        "due_date": str(due_date),
                        "auto_debit_type": auto_debit_type
                    })
                else:
                    logging.info(
                        f"## auto_debit_by_guid Skipping {acc_no}: auto_debit_type={auto_debit_type}, due_date={due_date}"
                    )


        logging.info(f"## auto_debit_by_guid fetched account_bill_data_mapping {account_bill_data_mapping}")

        # -------------------------------
        # STEP 3: Create transaction batch
        # -------------------------------
        batch_unique_code = f"BATCH-{int(time.time())}"
        logging.info(f"## auto_debit_by_guid batch_unique_code {batch_unique_code}")

        batch_data = []
        for acc_no, bills in account_bill_data_mapping.items():
            total_due = sum([float(b["amount_due"]) for b in bills])
            invoice_ids = [b["id"] for b in bills]
            batch_data.append({
                "batch_status": "Pending",
                "bill_list": str(invoice_ids),
                "bill_amount": total_due,
                "payment_type": "Auto-Debit",
                "credit_card_fee": 0,
                "batch_unique_code": batch_unique_code,
                "account_number": acc_no
            })
        if not batch_data:
            message = "No Payment Batch to be Updated"
            failed_data = {'bills_by_profile':bills_by_profile}
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = "System",
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = datetime.utcnow().isoformat(),
                error_message = message,
                error_type = message,
                comments=json.dumps(failed_data)
            )
            return {"flag": False, "message": message}

        batch_insert_status = killbill_database.insert_data(batch_data, "transaction_status")
        logging.info(f"## auto_debit_by_guid batch_insert_status {batch_insert_status}")
        if not batch_insert_status:
            message = "Failed to create payment batch"
            failed_data = {'batch_data':batch_data}
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = "System",
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = datetime.utcnow().isoformat(),
                error_message = message,
                error_type = message,
                comments = json.dumps(failed_data)
            )
            return {"flag": False, "message": message}

        transaction_status_records = killbill_database.get_data(
            "transaction_status",
            {"batch_unique_code": batch_unique_code},
            ["id", "account_number", "bill_list", "bill_amount", "credit_card_fee", "batch_status"]
        )
        if transaction_status_records is None or transaction_status_records.empty:
            message = "Failed to fetch transaction status records"
            failed_data = {'batch_unique_code':batch_unique_code}
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = "System",
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = datetime.utcnow().isoformat(),
                error_message = message,
                error_type = message,
                comments = json.dumps(failed_data)
            )
            return {"flag": False, "message": message}
        logging.info(f"## auto_debit_by_guid fetched transaction_status_records {transaction_status_records}")

        # -------------------------------
        # STEP 4: Fetch payment methods
        # -------------------------------
        pm_df = killbill_database.get_data(
            "payment_methods",
            {"account_number": account_numbers, "default_payment": True},
            ["account_number", "storage_safe_guid", "method_type", "name_on_card"]
        )
        payment_method_map = {row["account_number"]: row for row in pm_df.to_dict(orient="records")} if pm_df is not None else {}
        logging.info(f"## auto_debit_by_guid fetched payment_method_map {payment_method_map}")
        if not payment_method_map:
            message = "No payment methods found for auto-debit"
            failed_data = {'account_numbers':account_numbers}
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = "System",
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = datetime.utcnow().isoformat(),
                error_message = message,
                error_type = message,
                comments = json.dumps(failed_data)
            )
            return {"flag": False, "message": message}

        # -------------------------------
        # STEP 5: Fetch email templates once
        # -------------------------------
        email_templates_df = database.get_data("email_templates", {}, ["template_name", "email_status"])
        logging.info(f"## auto_debit_by_guid fetched email_templates_df {email_templates_df}")

        # -------------------------------
        # STEP 6: Perform Auto-Debit per account
        # -------------------------------
        for acc_no, bills in account_bill_data_mapping.items():
            logging.info(f"## auto_debit_by_guid processing account {acc_no} with bills {bills}")
            pm_info = payment_method_map.get(acc_no)
            if not pm_info:
                logging.warning(f"## auto_debit_by_guid No saved payment method for {acc_no}, skipping")
                continue

            # total_due = sum([float(b["amount_due"]) for b in bills])
            total_due = round(sum([float(b["amount_due"]) for b in bills]), 2)
            guid, method = pm_info["storage_safe_guid"], pm_info["method_type"]

            # --- CC Fee Handling ---
            credit_card_fee = 0
            total_due_with_fee = float(total_due)

            if method and method.lower() == "credit":
                profile = profiles_dict.get(acc_no, {})
                tenant_id = profile.get("tenant_id")

                # Get customer-specific fee if exists
                customer_fee_df = pd.DataFrame([profile])
                tenant_defaults = default_settings_map.get(tenant_id, {})
                default_fee_percentage = tenant_defaults.get("default_fee", 0)
                fee_setting = tenant_defaults.get("fee_setting", "")

                # Determine if fee applies at all
                should_apply_fee = apply_cc_fee(
                    payment_method="card payment",
                    fee_setting=fee_setting,
                    payment_type="auto-debit"
                )

                fee_percentage = 0
                if customer_fee_df is not None and not customer_fee_df.empty:
                    fee_percentage = float(customer_fee_df.iloc[0].get("credit_card_fee") or 0)
                    logging.info(f"## auto_debit_by_guid: Found customer-specific credit_card_fee {fee_percentage}%")
                else:
                    fee_percentage = default_fee_percentage
                    logging.info(f"## auto_debit_by_guid: Using default credit_card_fee {fee_percentage}%")

                # Apply fee only if the setting allows it
                if should_apply_fee and fee_percentage > 0:
                    credit_card_fee = round((float(total_due) * fee_percentage) / 100, 2)
                    total_due_with_fee = round(float(total_due) + credit_card_fee, 2)
                    logging.info(f"## auto_debit_by_guid: Applied credit card fee {credit_card_fee} ({fee_percentage}%)")
                else:
                    logging.info("## auto_debit_by_guid: No credit card fee applied (should_apply_fee=False or fee_percentage=0)")


            # Update transaction_status in database with computed credit card fee
            balance_update_status = killbill_database.update_dict(
                "transaction_status",
                {
                    "credit_card_fee": credit_card_fee,
                    "bill_amount": total_due_with_fee  # optional, updates total including fee
                },
                {"account_number": acc_no, "batch_unique_code": batch_unique_code}
            )
            logging.info(f"## auto_debit_by_guid: Updated transaction_status for {acc_no} with balance_update_status {balance_update_status} credit_card_fee={credit_card_fee}, total_due_with_fee={total_due_with_fee}")

            # --- Proceed with Transaction ---
            if method and method.lower() == "credit":
                trx_response = auto_debit_credit_card(
                    total_due_with_fee,
                    guid, merchant_key, merchant_secret, post_url, trx_current_code
                )
            elif method and method.lower() == "ach":
                trx_response = auto_debit_ach(
                    total_due, guid, merchant_key, merchant_secret, post_url, trx_current_code
                )
            else:
                logging.warning(f"## auto_debit_by_guid Invalid payment method {method} for {acc_no}, skipping")
                continue


            result = trx_response.get("Message", {}).get("Response", {})
            logging.info(f"## auto_debit_by_guid trx_response {trx_response}")
            if not result:
                continue

            account_txn_status = transaction_status_records[transaction_status_records["account_number"] == acc_no]

            # Build context
            context = {
                "transaction_status_record": account_txn_status,
                "updated_credit_card_fee": credit_card_fee,
                "total_due_with_fee": total_due_with_fee,
                "bills": bills,
                "customer_profile": profiles_dict.get(acc_no, {}),
                "payment_method": pm_info,
                "email_templates": email_templates_df
            }
            logging.info(f"## auto_debit_by_guid context {context}")

            webhook_response_handler_for_auto_debit({
                "Result": result.get("Result", {}),
                "Reference": result.get("Reference", {}),
                "StorageSafe": {"Guid": guid},
                "CustomFields": [{"Id": "UserDefinedAgent", "Value": ""}]
            }, context, killbill_database, common_utils_db, database,billing_db_name)
        # SUCCESS AUDIT
        audit_success(
            common_utils_db = common_utils_db,
            service_name = "auto_debit_by_guid",
            created_by = "System",  # or pull from context if user-driven
            session_id = None,
            tenant_name = None,
            module_name = "Auto-Debit",
            request_received_at = datetime.utcnow().isoformat(),
            comments = {"processed_accounts": processed_accounts},
            time_consumed_secs = int(time.time() - start_time)
        )
        return {"flag": True, "message": "Auto-debit process completed", "processed_accounts": processed_accounts}

    except Exception as e:
        message = f"Error Occured while performing Auto Debit"
        logging.error(f"## auto_debit_by_guid error: {e}")
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        audit_error(
            common_utils_db = common_utils_db,
            service_name = "auto_debit_by_guid",
            created_by = "System",
            session_id = None,
            tenant_name = None,
            module_name = "Auto-Debit",
            request_received_at = datetime.utcnow().isoformat(),
            error_message = str(e),
            error_type = type(e).__name__,
            comments = str(e)
        )
        return {"flag": False, "message": message}


def auto_debit_credit_card(amount, storage_safe_guid, merchant_key, merchant_secret, post_url, trx_current_code):
    logging.info(f"## auto_debit_credit_card called with amount={amount}, storage_safe_guid={storage_safe_guid}, trx_current_code={trx_current_code}")
    """
    Performs credit card auto-debit request via TRX.
    Handles network errors, timeouts, and invalid responses gracefully.
    """
    payload = {
        "Message": {
            "Request": {
                "Detail": {
                    "TranType": "Credit",
                    "TranAction": "Sale",
                    "Amount": str(amount), 
                    "CurrencyCode": trx_current_code
                },
                "IndustryData": {
                    "Industry": "CardNotPresent",
                    "Eci": "2",
                    "MarketSpecificId": "B"
                },
                "StorageSafe": {"Guid": storage_safe_guid},
                "Account": {"TokenSource": "TrxServices"}
            }
        }
    }
    logging.info(f"## auto_debit_credit_card: Payload: {payload}")
    try:
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=15
        )
        response.raise_for_status()  # raise if 4xx/5xx

        try:
            logging.info(f"## auto_debit_credit_card: Response: {response.json()}")
            return response.json()
        except ValueError:
            logging.error("## auto_debit_credit_card: Invalid JSON response")
            return {"Message": {"Response": {"Result": {"ResponseCode": "99", "ResponseText": "Invalid JSON"}}}}

    except requests.exceptions.Timeout:
        logging.error("## auto_debit_credit_card: Request timed out")
        return {"Message": {"Response": {"Result": {"ResponseCode": "98", "ResponseText": "Timeout"}}}}

    except requests.exceptions.RequestException as e:
        logging.error(f"## auto_debit_credit_card: Request failed: {e}")
        return {"Message": {"Response": {"Result": {"ResponseCode": "97", "ResponseText": str(e)}}}}


def auto_debit_ach(amount, storage_safe_guid, merchant_key, merchant_secret, post_url, trx_current_code):
    logging.info(
        f"## auto_debit_ach called with amount={amount}, storage_safe_guid={storage_safe_guid}, trx_current_code={trx_current_code}"
    )
    """
    Performs ACH auto-debit request via TRX using StorageSafe GUID.
    Handles network errors, timeouts, and invalid responses gracefully.
    """

    payload = {
        "Message": {
            "Request": {
                "Detail": {
                    "TranType": "Ach",
                    "TranAction": "Sale",
                    "Amount": str(amount), 
                    "CurrencyCode": trx_current_code
                },
                "IndustryData": {
                    "Industry": "CardNotPresent",
                    "Eci": "2"
                },
                "StorageSafe": {"Guid": storage_safe_guid}
            }
        }
    }

    logging.info(f"## auto_debit_ach: Payload: {payload}")

    try:
        response = requests.post(
            post_url,
            json=payload,
            auth=(merchant_key, merchant_secret),
            headers={"Content-Type": "application/json"},
            timeout=15
        )
        response.raise_for_status()

        try:
            resp_json = response.json()
            logging.info(f"## auto_debit_ach: Response: {resp_json}")
            return resp_json
        except ValueError:
            logging.error("## auto_debit_ach: Invalid JSON response")
            return {
                "Message": {
                    "Response": {
                        "Result": {
                            "ResponseCode": "99",
                            "ResponseText": "Invalid JSON"
                        }
                    }
                }
            }

    except requests.exceptions.Timeout:
        logging.error("## auto_debit_ach: Request timed out")
        return {
            "Message": {
                "Response": {
                    "Result": {
                        "ResponseCode": "98",
                        "ResponseText": "Timeout"
                    }
                }
            }
        }

    except requests.exceptions.RequestException as e:
        logging.error(f"## auto_debit_ach: Request failed: {e}")
        return {
            "Message": {
                "Response": {
                    "Result": {
                        "ResponseCode": "97",
                        "ResponseText": str(e)
                    }
                }
            }
        }

def normalize_bill_ids(bill_ids):
    """
    Ensures bill_ids is always returned as a list.
    
    Handles multiple input formats:
    - List (no change)
    - String representation of a list: "['123', '456']"
    - Comma-separated string: "123,456"
    - Single string: "123"
    """
    logging.info(f"## normalize_bill_ids called with bill_ids={bill_ids}")
    if isinstance(bill_ids, list):
        logging.info(f"## normalize_bill_ids: bill_ids is already a list: {bill_ids}")
        return bill_ids

    if isinstance(bill_ids, str):
        logging.info(f"## normalize_bill_ids: bill_ids is a string: {bill_ids}")
        try:
            # Case 1: Looks like a list string
            parsed = ast.literal_eval(bill_ids)
            if isinstance(parsed, list):
                return parsed
        except (ValueError, SyntaxError):
            pass

        # Case 2: Comma-separated string
        if "," in bill_ids:
            return [x.strip() for x in bill_ids.split(",") if x.strip()]

        # Case 3: Single value string
        return [bill_ids.strip()]

    # Fallback (unexpected type)
    logging.warning(f"normalize_bill_ids: unexpected type {type(bill_ids)} -> {bill_ids}")
    return []

def update_export_status():
    """
    Update url and status_flag to NULL based on module_name.
   
    Args:
        data (dict): should include keys 'db_name' and 'table_name'.
    """
    try:
        #database connection
        billing_platform_common_utils_db = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        update_status = billing_platform_common_utils_db.update_dict(
                "export_status",
                {"url": None, "status_flag": None},
                {"module_name": "Multi Account Payment"}
        )
        logging.info(f"## test_file rows updated for module: {update_status}")
 
        return {
            "flag": True,
            "message": "updated rows successfully"
        }
           
    except Exception as e:
        logging.error(f"Error updating rows: {e}")
        return {
            "flag": False,
            "message": str(e)
        }

def webhook_response_handler_for_multi_auto_debit(data, context, billing_platform_db, common_utils_db, database, billing_db_name):
    """
    Optimized webhook handler - uses pre-fetched context to reduce DB calls.
    Processes webhook transaction data, updates bills, account balances,
    inserts payment history, and triggers email notifications.
    """
    logging.info(f"## webhook_response_handler_for_multi_auto_debit called with {data} context {context}")
    
    try:
        start_time = time.time()
        result, reference_data = data.get('Result', {}), data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        # -----------------------------
        # Extract transaction details
        # -----------------------------
        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        card_last_four = reference_data.get('LastFour', '')
        tran_date, tran_time = reference_data.get('TranDate'), reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')
        mail_payment_mode = 'ACH Payment' if account_brand.lower() == 'ach' else 'Card Payment'
        category = 'ach' if account_brand.lower() == 'ach' else 'credit'
        amount = float(result.get('ApprovedAmount', '0')) if category == 'credit' else None

        # Extract UI Fields
        created_by = data.get("username", "")

        # Custom fields
        agent = next((f.get("Value") for f in data.get("CustomFields", []) if f.get("Id") == "UserDefinedAgent"), "")

        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
            except Exception as e:
                logging.warning(f"## webhook_response_handler_for_multi_auto_debit Failed to parse date: {e}")

        status = "Success" if response_code == "00" else "Fail"

        # -----------------------------
        # Use context (instead of DB lookups)
        # -----------------------------
        txn_record = context.get("transaction_status_record")
        bill_list = ast.literal_eval(txn_record['bill_list'].tolist()[0]) if txn_record is not None else []
        bill_id = txn_record['id'].tolist()[0] if txn_record is not None else None
        total_due_with_fee = context.get("total_due_with_fee")
        # bill_amount = txn_record['bill_amount'].tolist()[0] if txn_record is not None else 0
        bill_amount = float(total_due_with_fee) if total_due_with_fee is not None else 0
        updated_credit_card_fee = context.get("updated_credit_card_fee")
        credit_card_fee = float(updated_credit_card_fee) if updated_credit_card_fee is not None else 0
        # credit_card_fee = float(txn_record['credit_card_fee'].tolist()[0] or 0) if txn_record is not None else 0

        bills = context.get("bills", [])
        profile = context.get("customer_profile", {})
        email_templates = context.get("email_templates", pd.DataFrame())
        name_on_card = context.get("payment_method", {}).get("name_on_card", "")

        account_number = profile.get("account_number", "")
        email, customer_name = profile.get("email", ""), profile.get("customer_name", "")
        tenant_name, tenant_id = profile.get("tenant_name", ""), profile.get("tenant_id")
        account_balance, account_amount_due = float(profile.get("account_balance", 0)), float(profile.get("amount_due", 0))

        if not amount:
            amount = bill_amount
        amount_for_bills = max(float(amount) - float(credit_card_fee), 0)

        # -----------------------------
        # Process transaction
        # -----------------------------
        transaction_history_rows = []
        formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
        total_amount_due, total_bill_amount, receipt_url = 0, 0, ""

        if status == "Success":
            logging.info("## webhook_response_handler_for_multi_auto_debit Transaction Success Case")

            # Split across bills
            amount_paid = amount_for_bills
            for bill_dict in bills:
                if amount_paid <= 0:
                    break
                current_bill_id = bill_dict["id"]
                payments = float(bill_dict.get("payments", 0))
                total = float(bill_dict.get("total", 0))
                amount_due = float(bill_dict.get("amount_due", 0))
                remaining = float(bill_dict.get("remaining", 0))
                total_bill_amount += total

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining, amount_due = 0, 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0

                total_amount_due += amount_due

                bill_credit_card_fee = 0
                try:
                    # Calculate bill proportion based on total without fee
                    bill_proportion = amount_for_invoice / amount_for_bills if amount_for_bills else 0
                    # Calculate per-bill credit card fee
                    bill_credit_card_fee = round(credit_card_fee * bill_proportion, 2) if bill_proportion > 0 else 0
                except Exception as e:
                    logging.info(f"## webhook_response_handler Exceptinon occured as {e}")
                    bill_credit_card_fee = 0

                # Update bill
                updated_data = {"payments": str(payments), "total": str(total),"amount_due": str(amount_due), "remaining": str(remaining)}
                logging.info(f"## webhook_response_handler_for_multi_auto_debit updated_data {updated_data}")
                bills_update_status = billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})
                logging.info(f"## webhook_response_handler_for_multi_auto_debit bills_update_status {bills_update_status}")

                # Ledger entry
                ledger_description = f'Payment Received - Thank you! Amount Paid: ${amount_for_invoice:.2f}  Date: {event_date.strftime("%m-%d-%Y")}'
                ledger_account_balance = round(account_balance - float(amount_for_invoice), 2)
                transaction_history_rows.append({
                    "ref": reference,
                    "status": 'Successful',
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(bill_credit_card_fee),
                    "account_balance": str(ledger_account_balance),
                    "name_on_card": name_on_card,
                    "created_by": created_by if created_by else "system"
                })

            # Update account balance
            account_balance -= amount
            account_amount_due -= amount
            try:
                account_data_update_status = billing_platform_db.update_dict(
                    'customer_profiles',
                    {
                        "account_balance": round(account_balance, 2),
                        "amount_due": round(account_amount_due, 2),
                        "last_payment_triggered_at": datetime.now(),   
                        "payment_flag": True
                    },
                    {"account_number": account_number}
                )
                logging.info(f"## webhook_response_handler_for_multi_auto_debit account_data_update_status {account_data_update_status}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_multi_auto_debit Account data update error: {e}")
                # account_data_update_status = billing_platform_db.update_dict('customer_profiles',{"account_balance": round(account_balance, 2),"amount_due": round(account_amount_due, 2)},{"account_number": account_number})
            # Insert payment history BEFORE receipt/email
            if transaction_history_rows:
                logging.info(f"## webhook_response_handler_for_multi_auto_debit transaction_history_rows {transaction_history_rows}")
                payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
                logging.info(f"## webhook_response_handler_for_multi_auto_debit payment_insert_status {payment_insert_status}")
            
            # Receipt generation
            try:
                receipt_dict = {"tenant_name": tenant_name, "tenant_id": tenant_id, "ref": reference, "billing_db_name":billing_db_name}
                resp = generate_payment_receipt(receipt_dict)
                logging.info(f"## webhook_response_handler_for_multi_auto_debit Receipt response: {resp}")
                receipt_url = resp.get("download_url", "")
                logging.info(f"## webhook_response_handler_for_multi_auto_debit Receipt URL: {receipt_url}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_multi_auto_debit Receipt error: {e}")

            # Send success email if enabled
            if not email_templates[email_templates["template_name"] == "Payment Successful"].empty:
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "total_amount": format_amount(total_bill_amount),
                    "amount_paid": format_amount(amount),
                    "due_amount": format_amount(total_amount_due),
                    "user_name": customer_name,
                    "receipt_link": receipt_url
                }
                # send_email("Payment Successful", email, placeholders_dict, {}, "Transaction Successful",
                #            customer_name, account_number, tenant_id, is_html=True)\
                notification_result = send_email(
                    template_name='Payment Successful',
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Successful',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    is_html=True,
                    billing_db_name = billing_platform_db
                )

        else:  # Failure case
            logging.info("## webhook_response_handler_for_multi_auto_debit Transaction Failed Case")
            ledger_description = f'Payment Failed Amount: ${amount}   Date: {event_date.strftime("%m-%d-%Y")}'
            logging.info(f"## webhook_response_handler_for_multi_auto_debit bills {bills}")
            for bill_dict in bills:
                logging.info(f"## webhook_response_handler_for_multi_auto_debit bill_dict {bill_dict}")
                current_bill_id = bill_dict["id"]
                logging.info(f"## webhook_response_handler_for_multi_auto_debit current_bill_id {current_bill_id}")
                ledger_account_balance = round(account_balance - float(amount), 2)
                transaction_history_rows.append({
                    "ref": reference,
                    "status": 'Failed',
                    "amount": str(bill_dict.get("amount_due", 0)),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee),
                    "account_balance": str(ledger_account_balance),
                    "name_on_card": name_on_card,
                    "created_by": created_by if created_by else "System"
                })
            try:
                # Update customer_profiles for failure
                account_data_update_status = billing_platform_db.update_dict(
                    'customer_profiles',
                    {
                        "last_payment_triggered_at": datetime.now(),  
                        "payment_flag": False
                    },
                    {"account_number": account_number}
                )
                logging.info(f"## webhook_response_handler_for_multi_auto_debit account_data_update_status {account_data_update_status}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_multi_auto_debit Account data update error: {e}")
            # Insert payment history BEFORE receipt/email
            if transaction_history_rows:
                logging.info(f"## webhook_response_handler_for_multi_auto_debit transaction_history_rows {transaction_history_rows}")
                payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
                logging.info(f"## webhook_response_handler_for_multi_auto_debit payment_insert_status {payment_insert_status}")
            
            # Send failure email if enabled
            if not email_templates[email_templates["template_name"] == "Payment Failure"].empty:
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": format_amount(amount),
                    "user_name": customer_name,
                    "due_amount": format_amount(account_amount_due)
                }
                # send_email("Payment Failure", email, placeholders_dict, {}, "Transaction Failed",
                #            customer_name, account_number, tenant_id)
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    billing_db_name = billing_platform_db
                )

        # # -----------------------------
        # # Insert payment history
        # # -----------------------------
        # if transaction_history_rows:
        #     logging.info(f"## webhook_response_handler_for_auto_debit transaction_history_rows {transaction_history_rows}")
        #     payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
        #     logging.info(f"## webhook_response_handler_for_auto_debit payment_insert_status {payment_insert_status}")

        # -----------------------------
        # Update transaction status
        # -----------------------------
        update_data = {"batch_status": status}
        if status == "Fail":
            update_data["failed_data"] = str(result)
        if reference:
            update_data["guid"] = reference
        if created_by:
            update_data["created_by"] = created_by
        billing_platform_db.update_dict('transaction_status', update_data, {"id": str(bill_id)})

        # -----------------------------
        # Audit logging
        # -----------------------------
        audit_data = {
            "service_name": "webhook_response_handler_for_multi_auto_debit",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        logging.error(f"## webhook_response_handler_for_multi_auto_debit error: {e}")
        error_data = {
            "service_name": "webhook_response_handler_for_multi_auto_debit",
            "error_message": str(e),
            "error_type": str(type(str(e)).__name__),
            "users": "System",
            "session_id": None,
            "tenant_name": None,
            "comments": json.dumps(data),
            "module_name": 'Auto-Debit',
            "request_received_at": event_date.isoformat() if event_date else None,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': str(e)}

def webhook_response_handler_for_multi_auto_debit_19_1(data, context, billing_platform_db, common_utils_db, database, billing_db_name):
    """
    Optimized webhook handler - uses pre-fetched context to reduce DB calls.
    Processes webhook transaction data, updates bills, account balances,
    inserts payment history, and triggers email notifications.
    """
    logging.info(f"## webhook_response_handler_for_multi_auto_debit called with {data} context {context}")
    
    try:
        start_time = time.time()
        result, reference_data = data.get('Result', {}), data.get('Reference', {})
        storage_safe_data = data.get("StorageSafe", {})

        # -----------------------------
        # Extract transaction details
        # -----------------------------
        response_code = result.get('ResponseCode')
        reference = reference_data.get('Guid', '')
        card_last_four = reference_data.get('LastFour', '')
        tran_date, tran_time = reference_data.get('TranDate'), reference_data.get('TranTime')
        account_brand = reference_data.get('AccountBrand', '')
        mail_payment_mode = 'ACH Payment' if account_brand.lower() == 'ach' else 'Card Payment'
        category = 'ach' if account_brand.lower() == 'ach' else 'credit'
        amount = float(result.get('ApprovedAmount', '0')) if category == 'credit' else None

        # Extract UI Fields
        created_by = data.get("username", "")

        # Custom fields
        agent = next((f.get("Value") for f in data.get("CustomFields", []) if f.get("Id") == "UserDefinedAgent"), "")

        # Date parsing
        event_date = None
        if tran_date and tran_time:
            try:
                event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
            except Exception as e:
                logging.warning(f"## webhook_response_handler_for_multi_auto_debit Failed to parse date: {e}")

        status = "Success" if response_code == "00" else "Fail"

        # -----------------------------
        # Use context (instead of DB lookups)
        # -----------------------------
        txn_record = context.get("transaction_status_record")
        bill_list = ast.literal_eval(txn_record['bill_list'].tolist()[0]) if txn_record is not None else []
        bill_id = txn_record['id'].tolist()[0] if txn_record is not None else None
        total_due_with_fee = context.get("total_due_with_fee")
        # bill_amount = txn_record['bill_amount'].tolist()[0] if txn_record is not None else 0
        bill_amount = float(total_due_with_fee) if total_due_with_fee is not None else 0
        updated_credit_card_fee = context.get("updated_credit_card_fee")
        credit_card_fee = float(updated_credit_card_fee) if updated_credit_card_fee is not None else 0
        # credit_card_fee = float(txn_record['credit_card_fee'].tolist()[0] or 0) if txn_record is not None else 0

        bills = context.get("bills", [])
        profile = context.get("customer_profile", {})
        email_templates = context.get("email_templates", pd.DataFrame())
        name_on_card = context.get("payment_method", {}).get("name_on_card", "")

        account_number = profile.get("account_number", "")
        email, customer_name = profile.get("email", ""), profile.get("customer_name", "")
        tenant_name, tenant_id = profile.get("tenant_name", ""), profile.get("tenant_id")
        account_balance, account_amount_due = float(profile.get("account_balance", 0)), float(profile.get("amount_due", 0))

        if not amount:
            amount = bill_amount
        amount_for_bills = max(float(amount) - float(credit_card_fee), 0)

        # -----------------------------
        # Process transaction
        # -----------------------------
        transaction_history_rows = []
        formatted_date = event_date.strftime("%m-%d-%Y") if event_date else ""
        total_amount_due, total_bill_amount, receipt_url = 0, 0, ""

        if status == "Success":
            logging.info("## webhook_response_handler_for_multi_auto_debit Transaction Success Case")

            # Split across bills
            amount_paid = amount_for_bills
            for bill_dict in bills:
                if amount_paid <= 0:
                    break
                current_bill_id = bill_dict["id"]
                payments = float(bill_dict.get("payments", 0))
                total = float(bill_dict.get("total", 0))
                amount_due = float(bill_dict.get("amount_due", 0))
                remaining = float(bill_dict.get("remaining", 0))
                total_bill_amount += total

                if amount_paid >= remaining:
                    amount_for_invoice = remaining
                    payments += remaining
                    remaining, amount_due = 0, 0
                    amount_paid -= amount_for_invoice
                else:
                    amount_for_invoice = amount_paid
                    payments += amount_paid
                    remaining -= amount_paid
                    amount_due -= amount_paid
                    amount_paid = 0

                total_amount_due += amount_due

                bill_credit_card_fee = 0
                try:
                    # Calculate bill proportion based on total without fee
                    bill_proportion = amount_for_invoice / amount_for_bills if amount_for_bills else 0
                    # Calculate per-bill credit card fee
                    bill_credit_card_fee = round(credit_card_fee * bill_proportion, 2) if bill_proportion > 0 else 0
                except Exception as e:
                    logging.info(f"## webhook_response_handler Exceptinon occured as {e}")
                    bill_credit_card_fee = 0

                # Update bill
                updated_data = {"payments": str(payments), "total": str(total),"amount_due": str(amount_due), "remaining": str(remaining)}
                logging.info(f"## webhook_response_handler_for_multi_auto_debit updated_data {updated_data}")
                bills_update_status = billing_platform_db.update_dict('customer_bills', updated_data, {"id": current_bill_id})
                logging.info(f"## webhook_response_handler_for_multi_auto_debit bills_update_status {bills_update_status}")

                # Ledger entry
                ledger_description = f'Payment Received - Thank you! Amount Paid: ${amount_for_invoice:.2f}  Date: {event_date.strftime("%m-%d-%Y")}'
                ledger_account_balance = round(account_balance - float(amount_for_invoice), 2)
                transaction_history_rows.append({
                    "ref": reference,
                    "status": 'Successful',
                    "amount": str(amount_for_invoice),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(bill_credit_card_fee),
                    "account_balance": str(ledger_account_balance),
                    "name_on_card": name_on_card,
                    "created_by": created_by if created_by else "system"
                })

            # Update account balance
            account_balance -= amount
            account_amount_due -= amount
            try:
                account_data_update_status = billing_platform_db.update_dict(
                    'customer_profiles',
                    {
                        "account_balance": round(account_balance, 2),
                        "amount_due": round(account_amount_due, 2),
                        "last_payment_triggered_at": datetime.now(),   
                        "payment_flag": True
                    },
                    {"account_number": account_number}
                )
                logging.info(f"## webhook_response_handler_for_multi_auto_debit account_data_update_status {account_data_update_status}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_multi_auto_debit Account data update error: {e}")
                # account_data_update_status = billing_platform_db.update_dict('customer_profiles',{"account_balance": round(account_balance, 2),"amount_due": round(account_amount_due, 2)},{"account_number": account_number})
            # Insert payment history BEFORE receipt/email
            if transaction_history_rows:
                logging.info(f"## webhook_response_handler_for_multi_auto_debit transaction_history_rows {transaction_history_rows}")
                payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
                logging.info(f"## webhook_response_handler_for_multi_auto_debit payment_insert_status {payment_insert_status}")
            
            # Receipt generation
            try:
                receipt_dict = {"tenant_name": tenant_name, "tenant_id": tenant_id, "ref": reference, "billing_db_name":billing_db_name}
                resp = generate_payment_receipt(receipt_dict)
                logging.info(f"## webhook_response_handler_for_multi_auto_debit Receipt response: {resp}")
                receipt_url = resp.get("download_url", "")
                logging.info(f"## webhook_response_handler_for_multi_auto_debit Receipt URL: {receipt_url}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_multi_auto_debit Receipt error: {e}")

            # Send success email if enabled
            if not email_templates[email_templates["template_name"] == "Payment Successful"].empty:
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "total_amount": round(total_bill_amount, 2),
                    "amount_paid": round(amount, 2),
                    "due_amount": round(total_amount_due, 2),
                    "user_name": customer_name,
                    "receipt_link": receipt_url
                }
                # send_email("Payment Successful", email, placeholders_dict, {}, "Transaction Successful",
                #            customer_name, account_number, tenant_id, is_html=True)\
                notification_result = send_email(
                    template_name='Payment Successful',
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Successful',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    is_html=True,
                    billing_db_name = billing_platform_db
                )

        else:  # Failure case
            logging.info("## webhook_response_handler_for_multi_auto_debit Transaction Failed Case")
            ledger_description = f'Payment Failed Amount: ${amount}   Date: {event_date.strftime("%m-%d-%Y")}'
            logging.info(f"## webhook_response_handler_for_multi_auto_debit bills {bills}")
            for bill_dict in bills:
                logging.info(f"## webhook_response_handler_for_multi_auto_debit bill_dict {bill_dict}")
                current_bill_id = bill_dict["id"]
                logging.info(f"## webhook_response_handler_for_multi_auto_debit current_bill_id {current_bill_id}")
                ledger_account_balance = round(account_balance - float(amount), 2)
                transaction_history_rows.append({
                    "ref": reference,
                    "status": 'Failed',
                    "amount": str(bill_dict.get("amount_due", 0)),
                    "method": card_last_four,
                    "source": "TRX",
                    "bill_id": str(current_bill_id),
                    "auth_code": "-",
                    "account_number": account_number,
                    "ledger_description": ledger_description,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "agent": agent,
                    "category": category,
                    "credit_card_fee": str(credit_card_fee),
                    "account_balance": str(ledger_account_balance),
                    "name_on_card": name_on_card,
                    "created_by": created_by if created_by else "System"
                })
            try:
                # Update customer_profiles for failure
                account_data_update_status = billing_platform_db.update_dict(
                    'customer_profiles',
                    {
                        "last_payment_triggered_at": datetime.now(),  
                        "payment_flag": False
                    },
                    {"account_number": account_number}
                )
                logging.info(f"## webhook_response_handler_for_multi_auto_debit account_data_update_status {account_data_update_status}")
            except Exception as e:
                logging.error(f"## webhook_response_handler_for_multi_auto_debit Account data update error: {e}")
            # Insert payment history BEFORE receipt/email
            if transaction_history_rows:
                logging.info(f"## webhook_response_handler_for_multi_auto_debit transaction_history_rows {transaction_history_rows}")
                payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
                logging.info(f"## webhook_response_handler_for_multi_auto_debit payment_insert_status {payment_insert_status}")
            
            # Send failure email if enabled
            if not email_templates[email_templates["template_name"] == "Payment Failure"].empty:
                new_bill_list = billing_platform_db.get_data('customer_bills', {'id': bill_list}, ['bill_id'])
                formatted_bill_list = new_bill_list['bill_id'].tolist() if not new_bill_list.empty else []
                placeholders_dict = {
                    "payment_date": formatted_date,
                    "bill_id": formatted_bill_list,
                    "transaction_id": reference,
                    "payment_mode": mail_payment_mode,
                    "amount_paid": round(amount, 2),
                    "user_name": customer_name,
                    "due_amount": round(account_amount_due, 2)
                }
                # send_email("Payment Failure", email, placeholders_dict, {}, "Transaction Failed",
                #            customer_name, account_number, tenant_id)
                notification_result = send_email(
                    template_name="Payment Failure",
                    to_email=email,
                    placeholder_value=placeholders_dict,
                    subject_placeholders={},
                    comments='Transaction Failed',
                    customer_name=customer_name,
                    account_number=account_number,
                    tenant_id = tenant_id,
                    billing_db_name = billing_platform_db
                )

        # # -----------------------------
        # # Insert payment history
        # # -----------------------------
        # if transaction_history_rows:
        #     logging.info(f"## webhook_response_handler_for_auto_debit transaction_history_rows {transaction_history_rows}")
        #     payment_insert_status = billing_platform_db.insert_data(transaction_history_rows, 'payment_history')
        #     logging.info(f"## webhook_response_handler_for_auto_debit payment_insert_status {payment_insert_status}")

        # -----------------------------
        # Update transaction status
        # -----------------------------
        update_data = {"batch_status": status}
        if status == "Fail":
            update_data["failed_data"] = str(result)
        if reference:
            update_data["guid"] = reference
        if created_by:
            update_data["created_by"] = created_by
        billing_platform_db.update_dict('transaction_status', update_data, {"id": str(bill_id)})

        # -----------------------------
        # Audit logging
        # -----------------------------
        audit_data = {
            "service_name": "webhook_response_handler_for_multi_auto_debit",
            "created_by": 'System',
            "status": 'Success',
            "time_consumed_secs": int(time.time() - start_time),
            "comments": json.dumps(data),
            "module_name": 'Payment History',
            "request_received_at": event_date.isoformat() if event_date else None
        }
        common_utils_db.update_audit(audit_data, "audit_user_actions")

        return {'flag': True, 'message': 'Transaction processed successfully'}

    except Exception as e:
        logging.error(f"## webhook_response_handler_for_multi_auto_debit error: {e}")
        error_data = {
            "service_name": "webhook_response_handler_for_multi_auto_debit",
            "error_message": str(e),
            "error_type": str(type(str(e)).__name__),
            "users": "System",
            "session_id": None,
            "tenant_name": None,
            "comments": json.dumps(data),
            "module_name": 'Auto-Debit',
            "request_received_at": event_date.isoformat() if event_date else None,
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {'flag': False, 'message': str(e)}



def multi_account_auto_debit(data):
    """
    Performs Auto-Debit (ACH / Credit Card) transactions for customer accounts
    based on selected bills from the UI.

    Parameters:
        changed_data (dict): 
            {
                account_number: {
                    "bill_list": [bill_id1, bill_id2, ...],
                    "bill_total": float
                },
                ...
            }

    Workflow:
        1. Fetch customer profiles for provided account_numbers.
        2. Create transaction batch in `transaction_status`.
        3. Fetch default payment methods.
        4. Handle credit card fee if applicable.
        5. Perform auto-debit via TRX API.
        6. Handle TRX responses via webhook.
        7. Audit success or failure.
    """
    try:
        logging.info(f"## multi_account_auto_debit started with data {data}")
        changed_data = data.get('changed_data',{})
        start_time = time.time()

        # ENV Variables
        merchant_key = os.environ.get("merchant_key")
        merchant_secret = os.environ.get("merchant_secret")
        post_url = os.environ.get("post_url", "")
        trx_current_code = os.environ.get("trx_current_code", "")
        billing_db_name = data.get('billing_db_name',None)

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}

        # DB Connections
        killbill_database = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # UI Parameter's
        created_by = data.get('username','System')
        request_received_at = data.get("request_received_at", "")

        # Validate merchant credentials
        if not merchant_key or not merchant_secret or not post_url or not trx_current_code:
            message = "Merchant credentials missing"
            audit_error(common_utils_db, "multi_account_auto_debit", "System", None, None,
                        "Auto-Debit", request_received_at, message, message, message)
            return {'flag': False, "message": message}
        
        # Update Export Status
        update_status = update_export_status()
        logging.info(f"## multi_account_auto_debit update_status {update_status}")
        account_numbers = list(changed_data.keys())
        
        # Generate batch ID
        # -------------------------------
        # STEP 1: Fetch customer profiles
        # -------------------------------
        customer_profiles_data = killbill_database.get_data(
            "customer_profiles",
            {"account_number": account_numbers},
            ["account_number", "id", "email", "customer_name", "amount_due", "tenant_name", "tenant_id", "account_balance","credit_card_fee"]
        )

        if customer_profiles_data is None or customer_profiles_data.empty:
            message = "No customer profiles found for provided account_numbers"
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "multi_account_auto_debit",
                created_by = created_by,
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = request_received_at,
                error_message = message,
                error_type = message,
                comments=message
            )
            return {"flag": False, "message": message}

        profiles_dict = {row["account_number"]: row for row in customer_profiles_data.to_dict(orient="records")}
        account_ids = [row["id"] for _, row in customer_profiles_data.iterrows()]
        account_id_dict = dict(zip(account_numbers, account_ids))
        logging.info(f"## multi_account_auto_debit fetched profiles_dict {profiles_dict}")

        # -------------------------------
        # STEP 1.1: Fetch Customer Bill Details
        # -------------------------------
        all_bills_list = []
        for bill_info in changed_data.values():
            all_bills_list.extend(bill_info.get("bill_list", []))

        if not all_bills_list:
            message = "No bill IDs provided in changed_data"
            audit_error(
                common_utils_db,
                "multi_account_auto_debit",
                created_by,
                None,
                None,
                "Auto-Debit",
                request_received_at,
                message,
                message,
                json.dumps({"changed_data": changed_data})
            )
            return {"flag": False, "message": message}

        # Fetch detailed bill info from DB
        bills_df = killbill_database.get_data_bp(
            table_name="customer_bills",
            condition={"id": all_bills_list},
            columns=[
                "id",
                "customer_profile_id",
                "account_number",
                "amount_due",
                "total",
                "remaining",
                "payments",
                "due_date_of_this_bill"
            ]
        )

        if bills_df is None or bills_df.empty:
            message = "No bill details found for provided bill IDs"
            audit_error(
                common_utils_db,
                "multi_account_auto_debit",
                created_by,
                None,
                None,
                "Auto-Debit",
                request_received_at,
                message,
                message,
                json.dumps({"bill_ids": all_bills_list})
            )
            return {"flag": False, "message": message}

        logging.info(f"## multi_account_auto_debit fetched bills_df {bills_df}")

        # -------------------------------
        # STEP 2: Map Selected bills and Account Number
        # -------------------------------
        default_settings_map = {}
        try:
            # Fetch default_settings for all tenants at once
            default_settings_df = killbill_database.get_data(
                "default_settings",
                {},  # Fetch all
                ["sub_tenant_id", "enable_credit_card_fee_type", "credit_card_fee"]
            )
            # Build a dict for quick lookup by sub_tenant_id
            default_settings_map = {
                row["sub_tenant_id"]: {
                    "fee_setting": row["enable_credit_card_fee_type"],
                    "default_fee": float(row.get("credit_card_fee") or 0)
                } for row in default_settings_df.to_dict(orient="records")
            }
        except Exception as e:
            default_settings_map = {}
            logging.info(f"## multi_account_auto_debit Exception occured while fetching default settings as {e}")
        logging.info(f"## multi_account_auto_debit fetched default_settings_map {default_settings_map}")
        # Use changed_data directly
        account_bill_data_mapping = {}
        processed_accounts = []
        for acc_no, bill_info in changed_data.items():
            if acc_no not in profiles_dict:
                logging.warning(f"## multi_account_auto_debit: account {acc_no} not found in DB, skipping")
                continue

            # Map bills for processing
            account_bill_data_mapping[acc_no] = bill_info["bill_list"]
            processed_accounts.append({
                "account_number": acc_no,
                "customer_name": profiles_dict[acc_no].get("customer_name"),
                "bill_id": bill_info["bill_list"],  # store list here since multiple bills
                "due_date": None,
                "auto_debit_type": None
            })

        logging.info(f"## multi_account_auto_debit account_bill_data_mapping {account_bill_data_mapping}")

        # -------------------------------
        # STEP 3: Create transaction batch
        # -------------------------------
        batch_unique_code = f"BATCH-{int(time.time())}"
        batch_data = []
        for acc_no, bill_ids in account_bill_data_mapping.items():
            total_due = changed_data[acc_no]["bill_total"]
            bill_ids_cleaned = [int(bid) for bid in normalize_bill_ids(bill_ids) if str(bid).isdigit()]
            batch_data.append({
                "batch_status": "Pending",
                "bill_list": str(bill_ids_cleaned),
                "bill_amount": total_due,
                "payment_type": "Multi-Auto-Debit",
                "credit_card_fee": 0,
                "batch_unique_code": batch_unique_code,
                "account_number": acc_no,
                "created_by": data.get('username','System')
            })

        if not batch_data:
            message = "No Payment Batch to be Updated"
            audit_error(common_utils_db, "multi_account_auto_debit",created_by, None, None,
                        "Auto-Debit", request_received_at, message, message, json.dumps({"changed_data": changed_data}))
            return {"flag": False, "message": message}

        batch_insert_status = killbill_database.insert_data(batch_data, "transaction_status")
        logging.info(f"## multi_account_auto_debit batch_insert_status {batch_insert_status}")
        if not batch_insert_status:
            message = "Failed to create payment batch"
            audit_error(common_utils_db, "multi_account_auto_debit", created_by, None, None,
                        "Auto-Debit", request_received_at, message, message, json.dumps(batch_data))
            return {"flag": False, "message": message}

        transaction_status_records = killbill_database.get_data(
            "transaction_status",
            {"batch_unique_code": batch_unique_code},
            ["id", "account_number", "bill_list", "bill_amount", "credit_card_fee", "batch_status"]
        )
        if transaction_status_records is None or transaction_status_records.empty:
            message = "Failed to fetch transaction status records"
            failed_data = {'batch_unique_code':batch_unique_code}
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = created_by,
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = request_received_at,
                error_message = message,
                error_type = message,
                comments = json.dumps(failed_data)
            )
            return {"flag": False, "message": message}
        logging.info(f"## auto_debit_by_guid fetched transaction_status_records {transaction_status_records}")

        # -------------------------------
        # STEP 4: Fetch payment methods
        # -------------------------------
        pm_df = killbill_database.get_data(
            "payment_methods",
            {"account_number": account_numbers, "default_payment": True},
            ["account_number", "storage_safe_guid", "method_type", "name_on_card"]
        )
        # payment_method_map = {row["account_number"]: row for _, row in pm_df.iterrows()} if pm_df is not None else {}
        payment_method_map = {row["account_number"]: row for row in pm_df.to_dict(orient="records")} if pm_df is not None else {}
        logging.info(f"## auto_debit_by_guid fetched payment_method_map {payment_method_map}")
        if not payment_method_map:
            message = "No payment methods found for auto-debit"
            failed_data = {'account_numbers':account_numbers}
            audit_error(
                common_utils_db = common_utils_db,
                service_name = "auto_debit_by_guid",
                created_by = created_by,
                session_id = None,
                tenant_name = None,
                module_name = "Auto-Debit",
                request_received_at = request_received_at,
                error_message = message,
                error_type = message,
                comments = json.dumps(failed_data)
            )
            return {"flag": False, "message": message}

        # -------------------------------
        # STEP 5: Fetch email templates once
        # -------------------------------
        email_templates_df = database.get_data("email_templates", {}, ["template_name", "email_status"])
        logging.info(f"## auto_debit_by_guid fetched email_templates_df {email_templates_df}")

        # -------------------------------
        # STEP 6: Perform Auto-Debit per account
        # -------------------------------
        for acc_no, bill_ids in account_bill_data_mapping.items():
            pm_info = payment_method_map.get(acc_no)
            logging.info(f"## auto_debit_by_guid pm_info {pm_info}")
            if not pm_info:
                logging.warning(f"## multi_account_auto_debit No saved payment method for {acc_no}, skipping")
                continue
            total_due = round(changed_data[acc_no]["bill_total"], 2)
            logging.info(f'## auto_debit_by_guid total_due {total_due}')
            guid, method = pm_info["storage_safe_guid"], pm_info["method_type"]
            logging.info(f'## auto_debit_by_guid guid {guid} method {method}')
            # CC Fee Handling (same logic as before)
            credit_card_fee = 0
            total_due_with_fee = float(total_due)
            if method and method.lower() == "credit":
                profile = profiles_dict.get(acc_no, {})
                tenant_id = profile.get("tenant_id")
                tenant_defaults = default_settings_map.get(tenant_id, {})
                default_fee_percentage = tenant_defaults.get("default_fee", 0)
                fee_setting = tenant_defaults.get("fee_setting", "")

                should_apply_fee = apply_cc_fee(
                    payment_method="card payment",
                    fee_setting=fee_setting,
                    payment_type="auto-debit"
                )
                fee_percentage = float(profile.get("credit_card_fee") or default_fee_percentage)
                if should_apply_fee and fee_percentage > 0:
                    credit_card_fee = round((total_due * fee_percentage) / 100, 2)
                    total_due_with_fee = round(total_due + credit_card_fee, 2)

            # Update transaction_status with fee
            balance_update_status = killbill_database.update_dict(
                "transaction_status",
                {"credit_card_fee": credit_card_fee, "bill_amount": total_due_with_fee},
                {"account_number": acc_no, "batch_unique_code": batch_unique_code}
            )
            logging.info(f"## auto_debit_by_guid: Updated transaction_status for {acc_no} with balance_update_status {balance_update_status} credit_card_fee={credit_card_fee}, total_due_with_fee={total_due_with_fee}")

            # TRX processing
            if method and method.lower() == "credit":
                trx_response = auto_debit_credit_card(
                    total_due_with_fee, guid, merchant_key, merchant_secret, post_url, trx_current_code
                )
            elif method and method.lower() == "ach":
                trx_response = auto_debit_ach(
                    total_due, guid, merchant_key, merchant_secret, post_url, trx_current_code
                )
            else:
                logging.warning(f"## multi_account_auto_debit Invalid payment method {method} for {acc_no}")
                continue

            result = trx_response.get("Message", {}).get("Response", {})
            if not result:
                continue
            # Format bill id list
            bill_ids = normalize_bill_ids(bill_ids)
            logging.info(f"## auto_debit_by_guid: before bill_ids {bill_ids}")
            try:
                bill_ids = [int(bid) for bid in bill_ids if str(bid).isdigit()]
                logging.info(f"## auto_debit_by_guid: after bill_ids {bill_ids}")
            except Exception as e:
                logging.warning(f"## Failed to convert bill_ids to int: {e}")
            account_txn_status = transaction_status_records[transaction_status_records["account_number"] == acc_no]
            account_bills_data = bills_df[bills_df["id"].isin(bill_ids)].to_dict(orient="records")
            logging.info(f"## multi_account_auto_debit: account_bills_data {account_bills_data}")
            context = {
                "transaction_status_record": account_txn_status,
                "updated_credit_card_fee": credit_card_fee,
                "total_due_with_fee": total_due_with_fee,
                "bills": account_bills_data,
                "customer_profile": profiles_dict.get(acc_no, {}),
                "payment_method": pm_info,
                "email_templates": email_templates_df
            }
            webhook_response_handler_for_multi_auto_debit({
                "Result": result.get("Result", {}),
                "Reference": result.get("Reference", {}),
                "StorageSafe": {"Guid": guid},
                "CustomFields": [{"Id": "UserDefinedAgent", "Value": ""}]
            }, context, killbill_database, common_utils_db, database, billing_db_name)

        # SUCCESS AUDIT
        audit_success(
            common_utils_db, "multi_account_auto_debit", created_by, None, None,
            "Auto-Debit", request_received_at,
            comments={"processed_accounts": processed_accounts},
            time_consumed_secs=int(time.time() - start_time)
        )
        # return {"flag": True, "message": "Auto-debit process completed", "processed_accounts": processed_accounts}
        # -------------------------------
        # STEP: Fetch and return transaction details for this batch
        # -------------------------------
        try:
            transaction_data_input = {
                "batch_unique_code": batch_unique_code,
                "table_name": "transaction_status"
            }

            transaction_result = get_transaction_data_by_batch_code(transaction_data_input,killbill_database)
            logging.info(f"## multi_account_auto_debit transaction_result {transaction_result}")

            export_url = None
            if transaction_result.get("flag"):
                logging.info(f"## multi_account_auto_debit Returning transaction data for batch {batch_unique_code}")

                # Prepare DataFrame and export
                transaction_df = pd.DataFrame(transaction_result.get("data", []))
                transaction_df = transaction_df.fillna("")

                export_input = {
                    "dfs": {
                        "Transactions": transaction_df
                    },
                    "Partner": data.get("tenant_name", ""),
                    "request_received_at": data.get("request_received_at"),
                    "module_name": "Multi Account Payment",
                    "user_name": created_by,
                    "session_id": data.get("session_id"),
                    "batch_unique_code":batch_unique_code
                }

                export_result = export_to_s3_bucket_(export_input)
                export_url = export_result.get("download_url") if export_result.get("flag") else None

                return {
                    "flag": True,
                    "batch_unique_code": batch_unique_code,
                    "transactions": transaction_result.get("data", []),
                    "processed_accounts": processed_accounts,
                    "export_url": export_url
                }

            else:
                logging.warning(f"## multi_account_auto_debit No transactions found for batch {batch_unique_code}: {transaction_result.get('message')}")
                return {
                    "flag": True,
                    "batch_unique_code": batch_unique_code,
                    "message": "Auto-debit completed, but no transactions found",
                    "processed_accounts": processed_accounts
                }

        except Exception as e:
            logging.error(f"## multi_account_auto_debit Error fetching transactions for batch {batch_unique_code}: {e}")
            return {
                "flag": True,
                "batch_unique_code": batch_unique_code,
                "message": f"Auto-debit completed, but error fetching transactions: {str(e)}",
                "processed_accounts": processed_accounts
            }


    except Exception as e:
        logging.error(f"## multi_account_auto_debit error: {e}")
        audit_error(common_utils_db, "multi_account_auto_debit", data.get('created_by',''), None, None,
                    "Auto-Debit", data.get('request_received_at',None),
                    str(e), type(e).__name__, str(e))
        return {"flag": False, "message": "Error occurred while performing Auto Debit"}

def get_transaction_data_by_batch_code(data,killbill_database):
    """
    Fetch transaction details from transaction_status table
    based on the given batch_unique_code.
    Removes unnecessary columns and renames fields
    for clearer transaction reporting.
    """
    try:
        logging.info(f"## get_transaction_data_by_batch_code called with data: {data}")
        # billing_db_name = data.get('billing_db_name',None)

        # # DB Name Validation
        # if not billing_db_name:
        #     return {"flag":False,"message":"Billing DB Name is required"}
        # killbill_database = DB(billing_db_name, **db_config)

        batch_unique_code = data.get('batch_unique_code', '')
        table_name = data.get('table_name', 'transaction_status')
        logging.info(f"## get_transaction_data_by_batch_code batch_unique_code: {batch_unique_code}, table_name: {table_name}")

        if not batch_unique_code:
            logging.info("## get_transaction_data_by_batch_code No batch_unique_code provided or invalid details")
            return {
                "message": "No batch_unique_code provided or Invalid details",
                "flag": False
            }

        transactions_df = killbill_database.get_data(table_name, {"batch_unique_code": batch_unique_code})
        logging.info(f"## get_transaction_data_by_batch_code transactions_df head: {transactions_df.head() if transactions_df is not None else 'None'}")

        if transactions_df is None or transactions_df.empty:
            logging.info(f"## get_transaction_data_by_batch_code No transactions found for batch_unique_code: {batch_unique_code}")
            return {
                "message": f"No records found for batch_unique_code {batch_unique_code}",
                "flag": False
            }

        # Remove unwanted columns
        transactions_df = transactions_df.drop(columns=["id", "payment_type", "payment_mode"], errors="ignore")

        # Rename columns
        transactions_df = transactions_df.rename(columns={
            "batch_status": "transaction_status",
            "guid": "transaction_id"
        })
        # Extract only DebugInfo from failed_data if it’s a JSON/dict
        if "failed_data" in transactions_df.columns:
            def extract_debug_info(val):
                try:
                    if isinstance(val, str):
                        logging.info(f"## get_transaction_data_by_batch_code extract_debug_info val: {val}")
                        val_stripped = val.strip()
                        if val_stripped.startswith("{") and val_stripped.endswith("}"):
                            try:
                                # Try JSON first
                                val = json.loads(val_stripped)
                            except json.JSONDecodeError:
                                logging.error(f"## get_transaction_data_by_batch_code extract_debug_info JSONDecodeError processing DebugInfo")
                                # Fallback: try Python dict literal
                                val = ast.literal_eval(val_stripped)
                        else:
                            logging.info(f"## get_transaction_data_by_batch_code extract_debug_info not JSON: {val}")
                            # Just return plain string if not a dict
                            return val

                    if isinstance(val, dict):
                        response_text = val.get("ResponseText", "")
                        debug_info = val.get("DebugInfo", "")
                        combined = f"{response_text} - {debug_info}".strip(" -")
                        return combined

                    return ""
                except Exception as e:
                    logging.error(f"## get_transaction_data_by_batch_code extract_debug_info Error processing DebugInfo: {val} as {e}")
                    return ""

            transactions_df["failed_data"] = transactions_df["failed_data"].apply(extract_debug_info)

        desired_order = [
            "account_number",
            "bill_list",
            "transaction_status",
            "bill_amount",
            "credit_card_fee",
            "batch_unique_code",
            "created_by",
            "failed_data"
        ]
        existing_cols = [col for col in desired_order if col in transactions_df.columns]
        transactions_df = transactions_df[existing_cols]
        transactions_data = transactions_df.to_dict(orient="records")
        logging.info(f"## get_transaction_data_by_batch_code Cleaned transactions_data: {transactions_data}")

        return {
            "flag": True,
            "data": transactions_data
        }

    except Exception as e:
        logging.error(f"## get_transaction_data_by_batch_code Error fetching transactions for batch_unique_code {batch_unique_code if 'batch_unique_code' in locals() else 'N/A'}: {e}")
        return {
            "flag": False,
            "message": f"Error fetching transactions ({type(e).__name__}): {str(e)}"
        }



def charge_back_daily_detail_sync(data):
    """
    Fetches ACH Void transaction details (DailyDetail Report) from TRX API,
    enriches them with payment_history and customer_profiles data,
    and stores them in the charge_back_history table.

    Steps:
        1. Prepare TRX payload (Ach - Void)
        2. Call TRX API
        3. Parse nested TRX response
        4. Fetch related payment_history and customer_profiles
        5. Map fields to charge_back_history schema
        6. Insert into DB
    """
    try:
        logging.info(f"### charge_back_daily_detail_sync called with data: {data}")
        start_time = time.time()

        # Extract UI inputs
        from_date = data.get("start_date", "")
        to_date = data.get("end_date", "")
        tenant_name = data.get("tenant_name", "")
        username = data.get("username", "")
        session_id = data.get("session_id", "")
        request_received_at = data.get("request_received_at", "")
        billing_db_name = data.get('billing_db_name',None)

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}

        # ENV vars
        post_url = os.environ.get("post_url", "")
        merchant_key = os.environ.get("merchant_key", "")
        merchant_secret = os.environ.get("merchant_secret", "")
        trx_client_id = os.environ.get("trx_client_id", "")

        missing_env = [v for v, val in [
            ("post_url", post_url),
            ("merchant_key", merchant_key),
            ("merchant_secret", merchant_secret),
            ("trx_client_id", trx_client_id)
        ] if not val]

        if missing_env:
            return {"flag": False, "message": f"Missing required ENV vars: {', '.join(missing_env)}"}

        # Default dates
        if not from_date:
            from_date = datetime.today().strftime("%m/%d/%Y")
        if not to_date:
            to_date = datetime.today().strftime("%m/%d/%Y")

        # DB connection
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # Build TRX payload
        trx_payload = {
            "Message": {
                "Request": {
                    "Detail": {"TranType": "Ach", "TranAction": "Report"},
                    "QueryRequest": {
                        "ReportType": "DailyDetail",
                        "Detail": {
                            "FromDate": from_date,
                            "FromTime": "00:00:00",
                            "ToDate": to_date,
                            "ToTime": "23:59:59",
                            "Client": str(trx_client_id),
                            "TranAction": "Return"
                        }
                    }
                }
            }
        }

        logging.info(f"### TRX payload for charge_back_daily_detail_sync: {trx_payload}")

        # Step 1: Call TRX API
        success, trx_response_or_error = call_trx_api(post_url, merchant_key, merchant_secret, trx_payload)
        if not success:
            message = "Failed to fetch data from TRX"
            error_data = {
                "service_name": "charge_back_daily_detail_sync",
                "error_message": message,
                "error_type": "APIError",
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"{message} | Payload: {trx_payload}",
                "module_name": 'Chargeback Daily Detail',
                "request_received_at": request_received_at,
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": message, "data": {}}

        # Step 2: Parse TRX response structure
        trx_response = trx_response_or_error
        logging.info(f"### TRX response for charge_back_daily_detail_sync: {trx_response}")
        rows = trx_response.get("Message", {}).get("Response", {}).get("QueryResponse", {}).get("Row", [])
        if isinstance(rows, dict):
            rows = [rows]
        elif not isinstance(rows, list):
            rows = []

        if not rows:
            return {"flag": True, "message": "No DailyDetail records found", "data": {}}

        # Step 3: List all ref_guids
        ref_guids = []
        for row in rows:
            reference = row.get("Reference", {})
            ref_guid = reference.get("RefGuid")
            if ref_guid:
                ref_guids.append(ref_guid)

        if not ref_guids:
            return {"flag": True, "message": "No RefGuids found in TRX response", "data": {}}

        # Step 4: Fetch payment_history for ref_guids using get_data
        payment_rows = []
        for ref_guid in ref_guids:
            rows_ph = billing_platform_db.get_data(
                "payment_history",
                {"ref": ref_guid},
                ["ref", "account_number", "amount", "cancel_reason", "status", "category", "bill_id"]
            )
            if rows_ph is not None and not rows_ph.empty:
                payment_rows.extend(rows_ph.to_dict('records'))

        if not payment_rows:
            return {"flag": True, "message": "No payment_history records found for ref_guid(s)", "data": {}}

        # Group payment history by ref_guid
        payment_dict = {}
        for row in payment_rows:
            ref_guid = row.get("ref")
            if ref_guid not in payment_dict:
                payment_dict[ref_guid] = {"account_numbers": set(), "bill_list": [], "rows": []}
            payment_dict[ref_guid]["account_numbers"].add(row.get("account_number"))
            payment_dict[ref_guid]["bill_list"].append(row.get("bill_id"))
            payment_dict[ref_guid]["rows"].append(row)

        # Step 5: Fetch customer_profiles for all account_numbers
        account_numbers = set()
        for ref_data in payment_dict.values():
            account_numbers.update(ref_data["account_numbers"])

        customer_profiles_dict = {}
        for account_number in account_numbers:
            cp_rows = billing_platform_db.get_data(
                "customer_profiles",
                {"account_number": account_number},
                ["sales_person", "email", "customer_name", "amount_due",
                 "tenant_name", "tenant_id", "account_balance"]
            )
            if cp_rows is not None and not cp_rows.empty:
                customer_profiles_dict[account_number] = cp_rows.iloc[0].to_dict()

        # Step 6: Prepare insertable records
        insert_records = []
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        for row in rows:
            reference = row.get("Reference", {})
            ref_guid = reference.get("RefGuid")
            tran_date = row.get("TranDate")
            tran_time = row.get("TranTime")

            event_date = None
            if tran_date and tran_time:
                try:
                    event_date = datetime.strptime(f"{tran_date} {tran_time}", "%m/%d/%Y %H:%M:%S")
                    # Optional: convert to tenant timezone
                    # event_date = convert_to_tenant_timezone(event_date, tenant_name, database)
                except Exception as e:
                    logging.warning(f"## charge_back_daily_detail_sync failed to parse transaction datetime: {e}")

            # Fallback to current time if parsing fails
            event_date = event_date or current_time

            if not ref_guid or ref_guid not in payment_dict:
                continue
            last_four = row.get("Account", {}).get("LastFour")
            ph_data = payment_dict[ref_guid]
            for acc_number in ph_data["account_numbers"]:
                cp = customer_profiles_dict.get(acc_number, {})
                bill_list_values = ph_data.get("bill_list") or []
                try:
                    formatted_bill_list = f"[{','.join(str(int(x)) for x in bill_list_values)}]"
                except Exception as e:
                    logging.error(f"### charge_back_daily_detail_sync error formatting bill_list {bill_list_values}: {e}")
                    formatted_bill_list = "[]"
                insert_records.append({
                    "bill_list": formatted_bill_list,
                    "last_four": last_four,
                    "date": event_date,
                    "ref_guid": ref_guid,
                    "cancel_guid": reference.get("Guid"),
                    "activity": reference.get("RefTranAction"),
                    "amount": sum([float(r.get("amount") or 0.0) for r in ph_data["rows"] if r.get("account_number") == acc_number]),
                    "cancel_reason": ", ".join([str(x) for x in set(r.get("cancel_reason") for r in ph_data["rows"] if r.get("account_number") == acc_number) if x]),
                    "status": ", ".join([str(x) for x in set(r.get("status") for r in ph_data["rows"] if r.get("account_number") == acc_number) if x]),
                    "category": ", ".join([str(x) for x in set(r.get("category") for r in ph_data["rows"] if r.get("account_number") == acc_number) if x]),
                    "account_number": acc_number,
                    "customer_name": cp.get("customer_name", ""),
                    "created_date": current_time,
                    "modified_date": current_time,
                    "tenant_id": cp.get("tenant_id", int(data.get("tenant_id", 0))),
                    "tenant_name": cp.get("tenant_name", tenant_name or "TRX Client"),
                    "created_by": username or "system",
                    "modified_by": username or "system"
                })

        # Step 7: Bulk insert into DB
        if insert_records:
            insert_status = billing_platform_db.insert_data(insert_records,"charge_back_history")
            logging.info(f"### charge_back_history insert_status {insert_status}")

        return {
            "flag": True,
            "message": f"Successfully synced TRX chargeback records",
            "data": {"insert_records": serialize_data(insert_records)}
        }

    except Exception as e:
        logging.exception(f"### charge_back_daily_detail_sync unexpected error: {e}")
        message = "Failed to Sync Charge Back Daily Detail Data"
        try:
            common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
            error_data = {
                "service_name": "charge_back_daily_detail_sync",
                "error_message": message,
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"{message}: {str(e)}",
                "module_name": 'Chargeback Daily Detail',
                "request_received_at": data.get("request_received_at", "")
            }
            common_utils_db.log_error_to_db(error_data, "error_log_table")
        except Exception as log_err:
            logging.error(f"### Failed to log error to DB: {log_err}")
        return {"flag": False, "message": message, "data": {}}


def export_charge_back_exceptions_backup(data):
    """
    Exports chargeback exception details to an S3 bucket.

    Steps:
        1. Fetch records from charge_back_history for the given tenant_id
        2. Apply optional date filtering
        3. Convert to DataFrame and upload to S3
    """
    try:
        logging.info(f"### export_charge_back_exceptions called with data: {data}")
        start_time = time.time()

        # --- Extract Inputs ---
        tenant_id = data.get("tenant_id", None)
        tenant_name = data.get("tenant_name", "")
        mode = os.getenv('ENV', '')
        billing_db_name = data.get('billing_db_name',None)

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}

        if not tenant_id:
            return {"flag": False, "message": "Missing tenant_id", "data": {}}

        # --- Handle UAT Tenant Override ---
        if mode == 'UAT' and str(tenant_id) == '212':
            tenant_name = 'Altaworx'
            tenant_id = '1'

        # --- DB Connections ---
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)

        # --- Parse Dates ---
        start_date_str = data.get("start_date", "")
        end_date_str = data.get("end_date", "")
        start_date = datetime.strptime(start_date_str, "%m/%d/%Y") if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%m/%d/%Y") + timedelta(days=1) if end_date_str else None

        # --- Fetch Data ---
        cbh_records_df = billing_platform_db.get_data(
            "charge_back_history",
            {"tenant_id": str(tenant_id)},
            [
                "bill_list",
                "account_number",
                "cancel_reason",
                "amount",
                "last_four",
                "activity",
                "category",
                "date",
                "ref_guid",
                "customer_name",
                "status"
            ],
            {"id": "DESC"}
        )

        if cbh_records_df is None or cbh_records_df.empty:
            return {"flag": True, "message": "No chargeback exceptions found for export", "data": {}}

        # --- Apply Date Filters ---
        if start_date and end_date:
            cbh_records_df = cbh_records_df[
                (cbh_records_df["date"] >= start_date) & 
                (cbh_records_df["date"] < end_date)
            ]

        if cbh_records_df.empty:
            return {"flag": True, "message": "No records found for the given date range", "data": {}}

        # --- Format and Map Columns ---
        cbh_records_df = cbh_records_df.rename(columns={
            "bill_list": "Bill ID",
            "account_number": "Account Number",
            "cancel_reason": "Cancel Reason",
            "amount": "Amount",
            "last_four": "Payment Method (Last 4)",
            "activity": "Activity",
            "category": "Category",
            "date": "Date",
            "ref_guid": "Reference GUID",
            "customer_name": "Customer Name",
            "status": "Status"
        })

        # --- Clean Nulls ---
        cbh_records_df = cbh_records_df.fillna("")

        # --- Attach Export Meta ---
        data["dfs"] = {"Chargeback Exceptions": cbh_records_df}
        data["module_name"] = "Chargeback Exceptions Export"

        # --- Upload to S3 ---
        export_response = export_to_s3_bucket_(data)
        export_response["time_consumed_secs"] = int(time.time() - start_time)

        return export_response

    except Exception as e:
        logging.exception(f"### export_charge_back_exceptions unexpected error: {e}")
        message = "Failed to export Chargeback Exceptions"
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        error_data = {
            "service_name": "export_charge_back_exceptions",
            "error_message": message,
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"{message}: {str(e)}",
            "module_name": "Chargeback Exceptions",
            "request_received_at": data.get("request_received_at", "")
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message, "data": {}}

def export_charge_back_exceptions_30_12_2025(data):
    """
    Exports chargeback exception details to an S3 bucket.

    Steps:
        1. Fetch records from charge_back_history for the given tenant_id
        2. Apply optional date filtering (+1 day on end_date)
        3. Normalize category field
        4. Convert to DataFrame and upload to S3
    """
    try:
        logging.info(f"### export_charge_back_exceptions called with data: {data}")
        start_time = time.time()

        # --- Extract Inputs ---
        tenant_id = data.get("tenant_id", None)
        tenant_name = data.get("tenant_name", "")
        mode = os.getenv('ENV', '')
        billing_db_name = data.get('billing_db_name',None)

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}

        if not tenant_id:
            return {"flag": False, "message": "Missing tenant_id", "data": {}}

        # --- Handle UAT Tenant Override ---
        if mode == 'UAT' and str(tenant_id) == '212':
            tenant_name = 'Altaworx'
            tenant_id = '1'

        # --- DB Connections ---
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # --- Parse Dates ---
        start_date_str = data.get("start_date", "")
        end_date_str = data.get("end_date", "")
        start_date = datetime.strptime(start_date_str, "%m/%d/%Y") if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%m/%d/%Y") + timedelta(days=1) if end_date_str else None

        tenant_time_zone = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name},["time_zone"]
            )["time_zone"].to_list()[0]
        logging.info(f"## export_chargeback_exceptions **tenant_time_zone {tenant_time_zone}")

        if tenant_time_zone is None:
                raise ValueError("No valid timezone found for tenant.")

        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        # --- Fetch Data ---
        try:
            cbh_records_df = billing_platform_db.get_data(
                "charge_back_history",
                {"tenant_id": str(tenant_id)},
                [
                    "bill_list",
                    "account_number",
                    "cancel_reason",
                    "amount",
                    "last_four",
                    "activity",
                    "category",
                    "date",
                    "ref_guid",
                    "customer_name",
                    "status"
                ]
            )
        except Exception as e:
            logging.info(f"error while fetching data----------{e}")
        logging.info(f'## export_charge_back_exceptions cbh_records_df---------{cbh_records_df}')
        logging.info(f" ## export_charge_back_exceptions columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")
        if cbh_records_df is None or cbh_records_df.empty:
            EXPORT_COLS = [
                "transaction_id",
                "activity_date",
                "method",
                "activity",
                "Amount",
                "cancel_reason",
                "customer_id",
                "customer_name",
                "bill_id",
                "Status"
            ]
            empty_df = pd.DataFrame(columns=EXPORT_COLS)
            data["dfs"] = {"Chargeback Exceptions": empty_df}
            data["module_name"] = "Chargeback Exceptions"
            export_response = export_to_s3_bucket_(data)
            export_response["time_consumed_secs"] = int(time.time() - start_time)
            export_response['message'] = "No records found for the given date range, exported header only"
            return export_response
            # return {"flag": True, "message": "No chargeback exceptions found for export", "data": {}}

        # --- Ensure 'date' is datetime type for filtering ---
        if not pd.api.types.is_datetime64_any_dtype(cbh_records_df["date"]):
            cbh_records_df["date"] = pd.to_datetime(cbh_records_df["date"], errors="coerce")

        # --- Apply Date Filters ---
        if start_date and end_date:
            cbh_records_df = cbh_records_df[
                (cbh_records_df["date"] >= start_date) &
                (cbh_records_df["date"] < end_date)
            ]

        if cbh_records_df.empty:
            return {"flag": True, "message": "No records found for the given date range", "data": {}}

        # --- Normalize Category ---
        cbh_records_df["category"] = cbh_records_df["category"].apply(
            lambda x: "Credit" if isinstance(x, str) and x.lower() == "credit"
            else "ACH" if isinstance(x, str) and x.lower() == "ach"
            else (x.capitalize() if isinstance(x, str) else x)
        )
        logging.info(f"columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")

        #cbh_records_df = convert_timestamp(cbh_records_df, tenant_time_zone)
        cbh_records_df = pd.DataFrame(
            convert_timestamp(cbh_records_df.to_dict(orient="records"), tenant_time_zone)
        )


        # --- Sort by date in descending order ---
        cbh_records_df = cbh_records_df.sort_values(by="date", ascending=False)

        
        # --- Rename Columns for Export ---
        cbh_records_df = cbh_records_df.rename(columns={
            "ref_guid": "transaction_id",
            "date": "activity_date",
            "category": "method",
            "activity": "activity",
            #"last_four": "payment_type",
            "amount": "Amount",
            "cancel_reason": "cancel_reason",
            "account_number": "customer_id",
            "customer_name": "customer_name",
            "bill_list": "bill_id",
            "status": "Status"
        })[
            [
                "transaction_id",
                "activity_date",
                "method",
                "activity",
                #"payment_type",
                "Amount",
                "cancel_reason",
                "customer_id",
                "customer_name",
                "bill_id",
                "Status"
            ]
        ]


        # --- Clean Nulls ---
        cbh_records_df = cbh_records_df.fillna("")
        logging.info(f"columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")

        # --- Format 'Amount' to always have two decimal places ---
        if "Amount" in cbh_records_df.columns:
            cbh_records_df["Amount"] = cbh_records_df["Amount"].apply(
                lambda x: f"{float(x):.2f}" if str(x).strip() not in ["", "None", "nan"] else "0.00"
            )

        # --- Prepare for S3 Export ---
        data["dfs"] = {"Chargeback Exceptions": cbh_records_df}
        data["module_name"] = "Chargeback Exceptions"

        # --- Upload to S3 ---
        export_response = export_to_s3_bucket_(data)
        export_response["time_consumed_secs"] = int(time.time() - start_time)

        return export_response

    except Exception as e:
        logging.info(f"### export_charge_back_exceptions unexpected error: {e}")
        message = "Failed to export Chargeback Exceptions"
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        error_data = {
            "service_name": "export_charge_back_exceptions",
            "error_message": message,
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"{message}: {str(e)}",
            "module_name": "Chargeback Exceptions",
            "request_received_at": data.get("request_received_at", "")
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message, "data": {}}

def export_charge_back_exceptions_backup(data):
    """
    Exports chargeback exception details to an S3 bucket.

    Steps:
        1. Fetch records from charge_back_history for the given tenant_id
        2. Apply optional date filtering (+1 day on end_date)
        3. Normalize category field
        4. Convert to DataFrame and upload to S3
    """
    try:
        logging.info(f"### export_charge_back_exceptions called with data: {data}")
        start_time = time.time()

        # --- Extract Inputs ---
        tenant_id = data.get("tenant_id", None)
        tenant_name = data.get("tenant_name", "")
        mode = os.getenv('ENV', '')
        billing_db_name = data.get('billing_db_name',None)
        tenant_db = data.get("db_name", "")
        role_name = data.get("role_name", "")

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}

        if not tenant_id:
            return {"flag": False, "message": "Missing tenant_id", "data": {}}

        # --- Handle UAT Tenant Override ---
        if mode == 'UAT' and str(tenant_id) == '212':
            tenant_name = 'Altaworx'
            tenant_id = '1'

        # --- DB Connections ---
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_db_conn = DB(tenant_db, **db_config)

        # --- Parse Dates ---
        start_date_str = data.get("start_date", "")
        end_date_str = data.get("end_date", "")
        start_date = datetime.strptime(start_date_str, "%m/%d/%Y") if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%m/%d/%Y") + timedelta(days=1) if end_date_str else None

        tenant_time_zone = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name},["time_zone"]
            )["time_zone"].to_list()[0]
        logging.info(f"## export_chargeback_exceptions **tenant_time_zone {tenant_time_zone}")

        if tenant_time_zone is None:
                raise ValueError("No valid timezone found for tenant.")

        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly
        
        # Customer access restriction
        customer_names = get_customer_names_by_user(
            role_name,
            data.get("username", ""),
            common_utils_database,
            tenant_db_conn
        )

        # If user has no customer access → return empty response
        if customer_names == []:
            return {
                "flag": True,
                "message": "No chargeback exceptions found",
                "header_map": {},
                "data": {"exceptions": []},
                "pages": {"start": data.get("mod_pages", {}).get("start", 0), "end": data.get("mod_pages", {}).get("end", 100), "total": 0}
            }
        # --- Fetch Data ---
        conditions = {"tenant_id": str(tenant_id)}
        # Apply customer filter only if restricted
        if customer_names:
            conditions["customer_name"] = customer_names
        try:
            cbh_records_df = billing_platform_db.get_data(
                "charge_back_history",
                conditions,
                [
                    "bill_list",
                    "account_number",
                    "cancel_reason",
                    "amount",
                    "last_four",
                    "activity",
                    "category",
                    "date",
                    "ref_guid",
                    "customer_name",
                    "status"
                ]
            )
        except Exception as e:
            logging.info(f"error while fetching data----------{e}")
        logging.info(f'## export_charge_back_exceptions cbh_records_df---------{cbh_records_df}')
        logging.info(f" ## export_charge_back_exceptions columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")
        if cbh_records_df is None or cbh_records_df.empty:
            EXPORT_COLS = [
                "transaction_id",
                "activity_date",
                "method",
                "activity",
                "Amount",
                "cancel_reason",
                "customer_id",
                "customer_name",
                "bill_id",
                "Status"
            ]
            empty_df = pd.DataFrame(columns=EXPORT_COLS)
            data["dfs"] = {"Chargeback Exceptions": empty_df}
            data["module_name"] = "Chargeback Exceptions"
            export_response = export_to_s3_bucket_(data)
            export_response["time_consumed_secs"] = int(time.time() - start_time)
            export_response['message'] = "No records found for the given date range, exported header only"
            return export_response
            # return {"flag": True, "message": "No chargeback exceptions found for export", "data": {}}

        # --- Ensure 'date' is datetime type for filtering ---
        if not pd.api.types.is_datetime64_any_dtype(cbh_records_df["date"]):
            cbh_records_df["date"] = pd.to_datetime(cbh_records_df["date"], errors="coerce")

        # --- Apply Date Filters ---
        if start_date and end_date:
            cbh_records_df = cbh_records_df[
                (cbh_records_df["date"] >= start_date) &
                (cbh_records_df["date"] < end_date)
            ]

        if cbh_records_df.empty:
            return {"flag": True, "message": "No records found for the given date range", "data": {}}

        # --- Normalize Category ---
        cbh_records_df["category"] = cbh_records_df["category"].apply(
            lambda x: "Credit" if isinstance(x, str) and x.lower() == "credit"
            else "ACH" if isinstance(x, str) and x.lower() == "ach"
            else (x.capitalize() if isinstance(x, str) else x)
        )
        logging.info(f"columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")

        #cbh_records_df = convert_timestamp(cbh_records_df, tenant_time_zone)
        cbh_records_df = pd.DataFrame(
            convert_timestamp(cbh_records_df.to_dict(orient="records"), tenant_time_zone)
        )


        # --- Sort by date in descending order ---
        cbh_records_df = cbh_records_df.sort_values(by="date", ascending=False)

        
        # --- Rename Columns for Export ---
        cbh_records_df = cbh_records_df.rename(columns={
            "ref_guid": "transaction_id",
            "date": "activity_date",
            "category": "method",
            "activity": "activity",
            #"last_four": "payment_type",
            "amount": "Amount",
            "cancel_reason": "cancel_reason",
            "account_number": "customer_id",
            "customer_name": "customer_name",
            "bill_list": "bill_id",
            "status": "Status"
        })[
            [
                "transaction_id",
                "activity_date",
                "method",
                "activity",
                #"payment_type",
                "Amount",
                "cancel_reason",
                "customer_id",
                "customer_name",
                "bill_id",
                "Status"
            ]
        ]


        # --- Clean Nulls ---
        cbh_records_df = cbh_records_df.fillna("")
        logging.info(f"columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")

        # --- Format 'Amount' to always have two decimal places ---
        if "Amount" in cbh_records_df.columns:
            cbh_records_df["Amount"] = cbh_records_df["Amount"].apply(
                lambda x: f"{float(x):.2f}" if str(x).strip() not in ["", "None", "nan"] else "0.00"
            )

        # --- Prepare for S3 Export ---
        data["dfs"] = {"Chargeback Exceptions": cbh_records_df}
        data["module_name"] = "Chargeback Exceptions"

        # --- Upload to S3 ---
        export_response = export_to_s3_bucket_(data)
        export_response["time_consumed_secs"] = int(time.time() - start_time)

        return export_response

    except Exception as e:
        logging.info(f"### export_charge_back_exceptions unexpected error: {e}")
        message = "Failed to export Chargeback Exceptions"
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        error_data = {
            "service_name": "export_charge_back_exceptions",
            "error_message": message,
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"{message}: {str(e)}",
            "module_name": "Chargeback Exceptions",
            "request_received_at": data.get("request_received_at", "")
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message, "data": {}}

def normalize_customers_from_config(customers):
    if not customers:
        return None

    # Already tuple/list
    if isinstance(customers, (list, tuple)):
        return sorted(set(c.strip() for c in customers if c and str(c).strip()))

    # Tuple-like string → convert safely
    if isinstance(customers, str):
        cleaned = customers.strip()

        try:
            parsed = ast.literal_eval(cleaned)

            if isinstance(parsed, (list, tuple)):
                return sorted(
                    set(str(c).strip() for c in parsed if c and str(c).strip())
                )
        except Exception:
            pass

        # Fallback: CSV-style
        cleaned = cleaned.strip("()")
        return sorted(
            set(
                c.strip().strip("'").strip('"')
                for c in cleaned.split(",")
                if c.strip()
            )
        )

    return None



def export_charge_back_exceptions(data):
    """
    Exports chargeback exception details to an S3 bucket.

    Steps:
        1. Fetch records from charge_back_history for the given tenant_id
        2. Apply optional date filtering (+1 day on end_date)
        3. Normalize category field
        4. Convert to DataFrame and upload to S3
    """
    try:
        logging.info(f"### export_charge_back_exceptions called with data: {data}")
        start_time = time.time()

        # --- Extract Inputs ---
        tenant_id = data.get("tenant_id", None)
        tenant_name = data.get("tenant_name", "")
        mode = os.getenv('ENV', '')
        billing_db_name = data.get('billing_db_name',None)
        role = data.get("role_name", "")
        username = data.get("username", "")

        # DB Name Validation
        if not billing_db_name:
            return {"flag":False,"message":"Billing DB Name is required"}

        if not tenant_id:
            return {"flag": False, "message": "Missing tenant_id", "data": {}}

        # --- Handle UAT Tenant Override ---
        if mode == 'UAT' and str(tenant_id) == '212':
            tenant_name = 'Altaworx'
            tenant_id = '1'

        # --- DB Connections ---
        billing_platform_db = DB(billing_db_name, **db_config)
        common_utils_db = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **common_utils_database_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # --- Parse Dates ---
        start_date_str = data.get("start_date", "")
        end_date_str = data.get("end_date", "")
        start_date = datetime.strptime(start_date_str, "%m/%d/%Y") if start_date_str else None
        end_date = datetime.strptime(end_date_str, "%m/%d/%Y") + timedelta(days=1) if end_date_str else None

        tenant_time_zone = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name},["time_zone"]
            )["time_zone"].to_list()[0]
        logging.info(f"## export_chargeback_exceptions **tenant_time_zone {tenant_time_zone}")

        if tenant_time_zone is None:
                raise ValueError("No valid timezone found for tenant.")

        match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
        if match:
            tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

        # --- Fetch Data ---
        try:
            cbh_records_df = billing_platform_db.get_data(
                "charge_back_history",
                {"tenant_id": str(tenant_id)},
                [
                    "bill_list",
                    "account_number",
                    "cancel_reason",
                    "amount",
                    "last_four",
                    "activity",
                    "category",
                    "date",
                    "ref_guid",
                    "customer_name",
                    "status"
                ]
            )
        except Exception as e:
            logging.info(f"error while fetching data----------{e}")
        logging.info(f'## export_charge_back_exceptions cbh_records_df---------{cbh_records_df}')
        logging.info(f" ## export_charge_back_exceptions columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")
        # ---------- Customer Access ----------
        customer_names = None  # Default → no restriction

        if role not in ("Super Admin", "Partner Admin"):
            config_customers = db_config.get("customers")  # fetch from db_config if defined

            if config_customers:
                customer_names = normalize_customers_from_config(config_customers)

            # If no customers → return empty immediately
            if not customer_names:
                return {
                    "flag": True,
                    "message": "No chargeback exceptions found",
                    "data": {}
                }

        # Apply customer filter if customers are restricted
        if customer_names is not None:
            cbh_records_df = cbh_records_df[
                cbh_records_df["customer_name"].isin(customer_names)
            ]


        if cbh_records_df is None or cbh_records_df.empty:
            EXPORT_COLS = [
                "transaction_id",
                "activity_date",
                "method",
                "activity",
                "Amount",
                "cancel_reason",
                "customer_id",
                "customer_name",
                "bill_id",
                "Status"
            ]
            empty_df = pd.DataFrame(columns=EXPORT_COLS)
            data["dfs"] = {"Chargeback Exceptions": empty_df}
            data["module_name"] = "Chargeback Exceptions"
            export_response = export_to_s3_bucket_(data)
            export_response["time_consumed_secs"] = int(time.time() - start_time)
            export_response['message'] = "No records found for the given date range, exported header only"
            return export_response
            # return {"flag": True, "message": "No chargeback exceptions found for export", "data": {}}

        # --- Ensure 'date' is datetime type for filtering ---
        if not pd.api.types.is_datetime64_any_dtype(cbh_records_df["date"]):
            cbh_records_df["date"] = pd.to_datetime(cbh_records_df["date"], errors="coerce")

        # --- Apply Date Filters ---
        if start_date and end_date:
            cbh_records_df = cbh_records_df[
                (cbh_records_df["date"] >= start_date) &
                (cbh_records_df["date"] < end_date)
            ]

        if cbh_records_df.empty:
            return {"flag": True, "message": "No records found for the given date range", "data": {}}

        # --- Normalize Category ---
        cbh_records_df["category"] = cbh_records_df["category"].apply(
            lambda x: "Credit" if isinstance(x, str) and x.lower() == "credit"
            else "ACH" if isinstance(x, str) and x.lower() == "ach"
            else (x.capitalize() if isinstance(x, str) else x)
        )
        logging.info(f"columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")

        #cbh_records_df = convert_timestamp(cbh_records_df, tenant_time_zone)
        cbh_records_df = pd.DataFrame(
            convert_timestamp(cbh_records_df.to_dict(orient="records"), tenant_time_zone)
        )


        # --- Sort by date in descending order ---
        cbh_records_df = cbh_records_df.sort_values(by="date", ascending=False)

        
        # --- Rename Columns for Export ---
        cbh_records_df = cbh_records_df.rename(columns={
            "ref_guid": "transaction_id",
            "date": "activity_date",
            "category": "method",
            "activity": "activity",
            #"last_four": "payment_type",
            "amount": "Amount",
            "cancel_reason": "cancel_reason",
            "account_number": "customer_id",
            "customer_name": "customer_name",
            "bill_list": "bill_id",
            "status": "Status"
        })[
            [
                "transaction_id",
                "activity_date",
                "method",
                "activity",
                #"payment_type",
                "Amount",
                "cancel_reason",
                "customer_id",
                "customer_name",
                "bill_id",
                "Status"
            ]
        ]


        # --- Clean Nulls ---
        cbh_records_df = cbh_records_df.fillna("")
        logging.info(f"columns of cbh_records_df-----------{cbh_records_df.columns.tolist()}")

        # --- Format 'Amount' to always have two decimal places ---
        if "Amount" in cbh_records_df.columns:
            cbh_records_df["Amount"] = cbh_records_df["Amount"].apply(
                lambda x: f"{float(x):.2f}" if str(x).strip() not in ["", "None", "nan"] else "0.00"
            )

        # --- Prepare for S3 Export ---
        data["dfs"] = {"Chargeback Exceptions": cbh_records_df}
        data["module_name"] = "Chargeback Exceptions"

        # --- Upload to S3 ---
        export_response = export_to_s3_bucket_(data)
        export_response["time_consumed_secs"] = int(time.time() - start_time)

        return export_response

    except Exception as e:
        logging.info(f"### export_charge_back_exceptions unexpected error: {e}")
        message = "Failed to export Chargeback Exceptions"
        common_utils_db = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)
        error_data = {
            "service_name": "export_charge_back_exceptions",
            "error_message": message,
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"{message}: {str(e)}",
            "module_name": "Chargeback Exceptions",
            "request_received_at": data.get("request_received_at", "")
        }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": message, "data": {}}



def get_export_status(data):
    """
    The get_export_status function retrieves the export status of a specific module from a database.
    It queries the export_status table based on the given module name and returns the corresponding status data.
    """
    try:
        logging.info(f'data received for get_export_status-------{data}')
        common_utils_database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **common_utils_database_config)

        # UI Parameter's
        module_name = data.get("module_name",None)
        username=data.get("username",None)
        tenant_id=data.get("tenant_id",None)
        # Export data fetch query
        export_status_data = common_utils_database.get_data('export_status',{"module_name":module_name,"user_name":username,"tenant_id":tenant_id},None).to_dict(orient="records")
        # updating the report status
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        error_data = {
            "service_name": "get_export_status",
            "error_message": str(e),
            "error_type": str(type(e).__name__),
            "users": data.get("username"),
            "session_id": data.get("session_id"),
            "tenant_name": data.get("tenant_name"),
            "comments": f"Failed! While checking export status {module_name}",
            "module_name": "Payments Integration",
            "request_received_at": data.get("request_received_at"),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "export_status_data": []}

