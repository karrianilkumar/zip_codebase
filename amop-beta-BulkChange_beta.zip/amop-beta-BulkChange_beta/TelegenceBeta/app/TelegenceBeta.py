"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
from collections import defaultdict
from decimal import Decimal
import ipaddress
import json
import logging
import os
import ast
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
import psycopg2
from pandas import Timestamp
from datetime import datetime
from dotenv import load_dotenv
from dateutil.relativedelta import relativedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import concurrent.futures
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random

# Database configuration
common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }


'''
Change types Developed for POD19 are:
1. Archive Devices
2. Change Customer Rate Plan    
3. Change Carrier Rate Plan
4. Update Device Status
5. Assign Customer
6. Edit Username and Cost Center
7. Change Phone Number
8. Update PPU Address
9. Change ICCID/IMEI
10. Activate New Service
11. Create Revenue Service
12. Refresh a Line
'''


##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    # Access global db_config variable
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    # Route to appropriate endpoint handler
    if path == "/telegence_bc_archive_devices":
        result = telegence_bc_archive_devices(data)
    elif path == "/telegence_bc_change_customer_rate_plan":
        result = telegence_bc_change_customer_rate_plan(data)
    elif path == "/telegence_bc_change_carrier_rate_plan":
        result = telegence_bc_change_carrier_rate_plan(data)
    elif path== "/telegence_bc_update_device_status":
        result = telegence_bc_update_device_status(data)
    elif path== "/telegence_bc_change_phone_number":
        result = telegence_bc_change_phone_number(data)
    elif path== "/telegence_bc_update_ppu_address":
        result = telegence_bc_update_ppu_address(data)
    elif path== "/telegence_bc_change_iccid_imei":
        result = telegence_bc_change_iccid_imei(data)
    elif path== "/telegence_bc_activate_new_service":
        result = telegence_bc_activate_new_service(data)
    elif path== "/telegence_bc_assign_customer":
        result = telegence_bc_assign_customer(data)
    elif path== "/telegence_bc_update_feature":
        result = telegence_bc_update_feature(data)
    elif path== "/telegence_bc_create_rev_service":
        result = telegence_bc_create_rev_service(data)
    elif path== "/telegence_bc_edit_username_cost_center":
        result = telegence_bc_edit_username_cost_center(data)
    elif path== '/telegence_refresh_a_line':
        result = telegence_refresh_a_line(data)
    elif path== '/telegence_bc_line_sync':
        result = telegence_bc_line_sync(data)
    elif path== '/telegence_bc_reset_voicemail_password':
        result = telegence_bc_reset_voicemail_password(data)
    elif path== "/telegence_bc_private_network_ip":
        result = telegence_bc_private_network_ip(data)
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
    ##carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
    logging.info(f"carrier_details: {carrier_details}")
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url

##Archive devices function 
def telegence_bc_archive_devices(data):
    """
    Archives devices from the system based on the provided MSISDNs.

    This function is typically triggered during a bulk change operation, where a list of SIM cards
    (identified by their ICCIDs) needs to be marked as archived in the system. Archiving a device
    means it is no longer considered active or in use, and its status is updated accordingly
    in relevant tables (e.g., inventory, assignment logs, usage tracking).

    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs to be archived.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.

    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
    """
    logging.info(f"Received data for archiving devices: %s", data)
    start_time = time.time()
    # Validate required fields
    msisdns = data.get("msisdns", [])
    invalid_msisdns = data.get("invalid_msisdns", [])
    tenant_id = data.get("tenant_id", [])
    bulk_change_id = data.get("bulk_change_id", "")
    change_type = data.get("change_type",'')
    created_by=data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    service_provider = data.get("service_provider", "")
    role_name= data.get("role", "")
    service_provider_id = data.get("service_provider_id", "")
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_archiving devices and {tenant_name} time is {now}")
    #database connection
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### telegence_bc_archive_devices and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    # Audit - start
    bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Initiated"
                )
    live_progress_percentage_tracker(database, bulk_change_id,25)
    try:
        bulk_change_requests = database.get_data(
                'sim_management_bulk_change_request',
                {"bulk_change_id": bulk_change_id},
                ['id','subscriber_number']
        )
        ##main login to archive the devices
        # Map ICCID to request ID for fast access
        live_progress_percentage_tracker(database, bulk_change_id,40)
        msisdn_to_request_id = dict(zip(bulk_change_requests["subscriber_number"], bulk_change_requests["id"]))

        # Step 2: Archive valid ICCIDs in inventory
        database.update_dict(
            "sim_management_inventory",
            {"is_active": False,"is_deleted": True},
            and_conditions={"tenant_id": tenant_id},
            in_conditions={"msisdn": msisdns},
        )
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} archived {len(msisdns)} devices in inventory")

        # Prepare logs
        log_entries = []

        # Valid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,70)
        for msisdn in msisdns:
            request_id = msisdn_to_request_id.get(msisdn)
            if request_id:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Archive Device: {msisdn}",
                    "request_text": "Update AMOP",
                    "has_errors": False,
                    "response_status": "PROCESSED",
                    "response_text": "Device archived successfully",
                    "error_text": "",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
                
        #updating bulk change request tables     
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(msisdns),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Device archived successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"subscriber_number": msisdns},
        )
        # Prepare payload for history table update
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "change_type":change_type,
                                    "msisdns":msisdns,
                                    "iccids":[],
                                    "service_provider":service_provider,
                                    "Partner":tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        #api call to update the history table
        try:
            if msisdns:
                logging.info(f"### telegence_bc_archive_devices and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_archive_devices and {tenant_name} Exception in thread: {e}") 
        # Invalid SIMs
        for msisdn in invalid_msisdns:
            request_id = msisdn_to_request_id.get(msisdn)
            log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Archive Device Failed: {msisdn}",
                "request_text": "Update AMOP",
                "has_errors": True,
                "response_status": "ERROR",
                "response_text": "Invalid SIM - could not be processed",
                "error_text": "Invalid MSISDN",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_msisdns),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"subscriber_number": invalid_msisdns},
        )

        #  Step 3: Bulk insert all logs
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} archived {len(msisdns)} devices successfully")


        # Update the status of the bulk change request to PROCESSED
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "status": "PROCESSED",
                    "success": len(msisdns),
                    "processed_date": now
                },
                {'id': bulk_change_id}
            )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Sync To 1.0 Tables"
                )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### telegence_bc_archive_devices and {tenant_name} sync call has started")

            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_bc_archive_devices and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_archive_devices and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} Bulk change request processed successfully.")
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # Attempt to audit the actionn
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_archive_devices",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for archive devices.{bulk_change_id}",
                "request_received_at": now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database,
                 action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### telegence_bc_archive_devices and {tenant_name} Audit logging failed: {e}")
        # Attempt to audit the actionn
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Completed"
                )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### telegence_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )

        return response
    except Exception as e:
        logging.exception(f"telegence_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status telegence_bc_archive_devices: {str(e)}")
        # Update the status of the bulk change request to ERROR
        # Log the error
        error_message = f"Error during bulk change processing for archive status telegence_bc_archive_devices: {str(e)}"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        logging.error(f"### telegence_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status telegence_bc_archive_devices: {str(e)}")
        # Prepare error response
        response = {
            "flag": False,
            "message": "Bulk change request processing failed for telegence_bc_archive_devices.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(msisdns),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log error to database
            error_data = {
                "service_name": "telegence_bc_archive_devices",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for telegence_bc_archive_devices:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_archive_devices and {tenant_name} Exception in logging error data to DB: {e}")
        return response


## Change customer rate plan function
def telegence_bc_change_customer_rate_plan(data):
    """
    Change the customer rate plan for the given devices as part of a bulk change operation.
   
    this function is typically triggered during a bulk change operation where a list of SIM cards needs to have their customer rate plans updated.
    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs used to identify devices.
            -changed_data (dict): Dictionary containing the rate plan changes.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.
 
    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
 
    Returns:
        dict: Result of the operation with flags, messages, and details.
    """
    logging.info(f"### Received data for changing customer rate plan: %s", data)
    # Start timing the function execution
    start_time = time.time()
    # Extract all required fields from input data
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id= data.get("tenant_id", "")
    service_provider = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "")
    provider_parent_name=data.get("parent_provider_name", "")
    username = data.get("username", "")
    change_type=data.get("change_type", "Change Customer Rate Plan")
    source=data.get("source","")
    changed_data = data.get("changed_data", {})
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids=data.get('invalid_ids','')
    # Validate required fields
    customer_rate_plan_name = changed_data.get("customer_rate_plan_name", "")
    customer_rate_pool_name= changed_data.get("customer_rate_pool_name", "")
    effective_date = changed_data.get("effective_date", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_change_customer_rate_plan and {tenant_name} time is {now}")
    try:
        # Connect to main and audit databases
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    parent_tenant_id = None
    try:
        parent_tenant_id=common_utils_database.get_data('tenant',{"id":tenant_id},["parent_tenant_id"])["parent_tenant_id"].to_list()[0]
    except Exception as e:
        logging.exception(f"Exception while fetching parent_tenant_id{e}")
        parent_tenant_id = None
    try:
        # Audit - Start
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Initiated"
        )
        live_progress_percentage_tracker(database, bulk_change_id,25)
        rate_plan_db_id=None
        rate_pool_db_id=None
        plan_mb=None
        # Fetch bulk change request entries for valid ICCIDs
        bulk_change_requests = database.get_data(
            'sim_management_bulk_change_request',
            {"bulk_change_id": bulk_change_id},
            ['id', 'subscriber_number','change_request']
        )
        if bulk_change_requests.empty:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_change_customer_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_change_customer rate plan and {tenant_name} Audit logging failed: {e}")
                return response
        change_request_json = bulk_change_requests.iloc[0]["change_request"]
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        customer_rate_plan_update=change_request_json.get("CustomerRatePlanUpdate","")
        customer_rate_plan_id=customer_rate_plan_update.get("CustomerRatePlanId","")
        customer_rate_pool_id=customer_rate_plan_update.get("CustomerPoolId",None)
        effective_date=customer_rate_plan_update.get("EffectiveDate","")
        customer_name = customer_rate_plan_update.get("customerName", "")
        rate_plan_db_name=None
        rate_pool_db_name=None
        rev_customer_name=None
        rev_customer_id=None
        customer_id=None
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_name","plan_mb"]   
            )
            if not rate_plan_data.empty:
                rate_plan_db_name = rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb = rate_plan_data["plan_mb"].to_list()[0]

        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                rate_pool_db_name = rate_pool_data["name"].to_list()[0]
        bulk_change_requests = bulk_change_requests.rename(columns={'subscriber_number': 'msisdn'})
        update_fields={}
        fields_to_update=[]
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_rate_plan_name"]
            ).to_dict(orient="records")
        # Extract valid MSISDNs
        # Prepare an update dict dynamically
        if customer_rate_plan_id is None:
            update_fields["customer_rate_plan_id"] = None
            update_fields["customer_rate_plan_name"] = None
            update_fields["customer_data_allocation_mb"] = None
        elif str(customer_rate_plan_id).strip() not in ("-1", -2):
            update_fields["customer_rate_plan_id"] = customer_rate_plan_id
            update_fields["customer_rate_plan_name"] = rate_plan_db_name
            fields_to_update.append("customer_rate_plan_id")
            fields_to_update.append("sub_tenant_carrier_rate_plan_name")
            fields_to_update.append("sub_tenant_carrier_rate_plan_name_id")
            if plan_mb is not None:
                update_fields["customer_data_allocation_mb"] = plan_mb
            else:
                update_fields["customer_data_allocation_mb"] = None

        update_fields["modified_by"] = username 

        if not customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(customer_rate_pool_id) not in ("-1", -2):
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id	
            update_fields["customer_rate_pool_name"] = rate_pool_db_name
            fields_to_update.append("customer_rate_pool_id")

        if effective_date:
            update_fields["effective_date"] = effective_date

        if customer_name:  
            update_fields["customer_name"] = customer_name
            rev_data = database.get_data(
                "revcustomer",
                {"customer_name": customer_name, "is_active": True,"tenant_id": tenant_id},
                ["customer_name", "rev_customer_id"]
            )
            if not rev_data.empty:
                rev_customer_name = rev_data["customer_name"].to_list()[0]
                rev_customer_id = rev_data["rev_customer_id"].to_list()[0]
                update_fields["rev_customer_id"] = rev_customer_id
                update_fields["rev_customer_name"] = rev_customer_name
                fields_to_update.append("account_number")
            customer_data = pd.DataFrame()
            if rev_customer_name:
                customer_data=database.get_data(
                    "customers",
                    {"customer_name":rev_customer_name,"is_active": True},
                    ["id","customer_name"]
                )
            if not customer_data.empty:
                customer_id=customer_data["id"].to_list()[0]
                update_fields["customer_id"]=customer_id
                fields_to_update.append("customer_id")
        
        # Update the SIM management inventory with the new rate plan
        live_progress_percentage_tracker(database, bulk_change_id,40)
        if update_fields.items():
            logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Updating SIM management inventory with updated fields: {update_fields}")
            database.update_dict(
            "sim_management_inventory",update_fields,
            and_conditions={"tenant_id":tenant_id,"is_active": True},
            in_conditions={"msisdn": msisdns},
            )
        if not parent_tenant_id  and "customer_rate_plan_name" in update_fields:
            logging.info(f"sub tenant carrier rate plan update {update_fields}")
            if msisdns:
                database.update_dict("sim_management_inventory", 
                                     {
                                         "sub_tenant_carrier_rate_plan_name": update_fields.get("customer_rate_plan_name"),
                                         "sub_tenant_carrier_rate_plan_name_id":update_fields.get("customer_rate_plan_id")
                                      },
                                     in_conditions={"msisdn": msisdns})
                logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} updated customer rate plan for {len(msisdns)} devices in inventory")        
        # Map ICCID to request ID for logging
        msisdn_to_request_id = dict(zip(bulk_change_requests["msisdn"], bulk_change_requests["id"]))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entries = []
 
        # Log valid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,70)
        for msisdn in msisdns:
            request_id = msisdn_to_request_id.get(msisdn)
            log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Change Customer Rate Plan",
                "request_text": "Update AMOP",
                "has_errors": False,
                "response_status": "PROCESSED",
                "response_text": "Changed customer rate plan successfully",
                "error_text": "",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        #update       
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(msisdns),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Changed customer rate plan successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"subscriber_number": msisdns},
        )
        # Prepare payload for history table update
        if msisdns:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":msisdns,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        "fields_updated": fields_to_update,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            #api call to update the history table
            try: 
                logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": [],
                        "msisdns": msisdns,
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Customer Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in action history thread: {e}")
        if invalid_ids:
            logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Invalid MSISDNs found: {invalid_ids}")
            # Log invalid ICCIDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan Failed",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_ids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"id": invalid_ids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        # Update bulk change status to PROCESSED
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "success": len(msisdns),
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Call sync API in separate thread after delay
        # below sync url is used to sync the bulk change table  data with 1.0
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below sync url used to sync the inventory table data with 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Sync To 1.0 Tables"
        )
        try:
            if msisdns:
                data["customername"]= customer_name
                data["CustomerRatePlanId"]= customer_rate_plan_id
                data["customerId"] = rev_customer_id if rev_customer_id else customer_id
                logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call for billing  has started")
                billing_integration_change_rate_plan(data)
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        # Prepare success response
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # audit the auditing log
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            if msisdns and not parent_tenant_id:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "customer_rate_plan_name":update_fields.get('customer_rate_plan_name',''),
                    "changed_data": {
                            "msisdn": msisdns,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_change_customer_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing customer rate plan for devices.{bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")

        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        return response
 
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processingg: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(msisdns),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_bc_change_customer_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
 
##Update Device Status function
def telegence_bc_update_device_status(data):
    """
   Update the device status using the Telegence API.

    This function processes a list of MSISDNs and updates their device status in the Telegence system.
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps MSISDNs to their respective request payloads.
        - Iteratively calls the Telegence API for each MSISDN with retry logic.
        - Updates status in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid MSISDNs or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - msisdns (list): List of MSISDNs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the Telegence API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., SIM status or device status).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_msisdns (list): MSISDNs that failed validation before processing.
            - invalid_ids (list): Request IDs associated with invalid rows.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict: A response object indicating the result of the operation, containing:
            - flag (bool): True if processing completed without unhandled exceptions.
            - message (str): Summary message indicating the result.
            - processed (int): Number of MSISDNs processed.
            - msisdns (list): List of MSISDNs attempted.
            - invalid_msisdns (list): List of MSISDNs skipped due to invalid state.
            - bulk_change_id (str): ID of the bulk change request.
            - error (str, optional): Error message in case of failure.
    """
    logging.info(f"### Received data for updating device status: {data}")
    start_time = time.time()
    # Extract required fields
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    request_received_at=data.get("request_received_at", "")
    change_type = data.get("change_type",'')
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids = data.get("invalid_ids", [])
    request = data.get("changed_data", {}).get("Request", {})
    mode = request.get("mode")
    reason_code = request.get("reasonCode")
    integration_id = data.get("integration_id", 6)

    source=data.get("source","")
    # Extract status values from changed_data
    device_status_id = data.get("device_status_id","")
    provider_parent_name=data.get("parent_provider_name", "")

    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_update_device_status and {tenant_name} time is {now}")
    # Validate bulk_change_id
    successfull_ids = []
    if not bulk_change_id:
        logging.error(f"### telegence_bc_update_device_status and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### telegence_bc_update_device_status and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    live_progress_percentage_tracker(database, bulk_change_id,10)

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    try:
        # Get carrier API credentials and configuration
        provider = provider_parent_name if provider_parent_name else service_provider
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(provider, change_type, common_utils_database)
        #app_id, app_secret = fetch_app_details(database, integration_id)
        #logging.info(f"###telegence_bc_update_device_status and {tenant_name} Fetched App ID {app_id} and Secret {app_secret} for integration ID {integration_id}")
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### telegence_bc_update_device_status and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### telegence_bc_update_device_status and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        ).rename(columns={"subscriber_number": "msisdn"})
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_update_device_status",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response
        device_status_data=pd.DataFrame()
        device_status = None
        ##fetching the status of the device to get updated using id
        if device_status_id:
            device_status_data = database.get_data(
                "device_status",
                {"id": device_status_id, "is_active": True},
                ["id", "display_name"]
            )
        if not device_status_data.empty:
           device_status = device_status_data["display_name"].iloc[0]
           
        live_progress_percentage_tracker(database, bulk_change_id,20)
       
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id}
        ).to_dict(orient="records")
         # Validate input data
        inventory_lookup = {rec["msisdn"]: rec for rec in old_inventory_data}

        if source == "Inventory":
            old_inventory_data = old_inventory_data

        ##fetching the requests ids
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        if PARALLEL_REQUESTS>10:
            logging.info(f"###telegence_bc_update_device_status and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(msisdns)
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Execute API calls in parallel using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(msisdns), BATCH_SIZE):
                batch = msisdns[i:i + BATCH_SIZE]
                futures = {}

                for msisdn in batch:
                    url = f"{carrier_api_url}"
                    #"https://att-status-change-eapi.gw.cloud.att.com/api/v1/status-change"
                    headers = {
                        "accept": "application/json",
                        "content-type": "application/json",
                        "client_id": app_id,
                        "client_secret": app_secret,
                        "source": "product-papi/product",
                        "x-trace-id": "d4f8a2c6-3b9e-4f1c-9e72-5a1b7d2f8e3c",
                        "x-transaction-id": "73c427a4-2482-4e64-8cac-ea4ace577890",
                        "User-Agent": "PostmanRuntime/7.36.1"
                    }
                    def task(msisdn=msisdn, url=url):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_update_device_status and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                                billing_record = inventory_lookup.get(msisdn)

                                if billing_record:
                                    billing_number = billing_record.get("billing_account_number")
                                else:
                                    billing_number = None
                                payload = {
                                    "mode": mode,
                                    "reasonCode": reason_code,
                                    #"effectiveDate":effective_date,it is an optional field
                                    "subscriberNumber": msisdn,
                                    "billingAccountNumber": billing_number
                                }
                                resp = requests.patch(url, json=payload,headers=headers, timeout=60)
                                logging.info(f"### telegence_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                success = 200 <= resp.status_code < 300
                                result = resp.json()
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    status_change_id=result.get("statusChangeId")
                                    successfull_ids.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### telegence_bc_update_device_status and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":json.dumps(result)},
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            database.update_dict(
                                "sim_management_inventory",
                                {"sim_status": device_status, "device_status_id": device_status_id},
                                and_conditions={ "is_active": True},
                                in_conditions={"msisdn": [msisdn]}
                            )
                            record = inventory_lookup.get(msisdn, {})
                            try:
                                status_history={
                                    "iccid": record.get("iccid", None) if record else None,
                                    "sim_management_inventory_id": record.get("id", None)if record else None,
                                    "msisdn": msisdn,
                                    "username": record.get("username", None)if record else None,
                                    "previous_status": record.get("sim_status", None) if record else None,
                                    "current_status": device_status,
                                    "bulk_change_id": bulk_change_id,
                                    "change_event_type": change_type,
                                    "date_of_change": request_received_at,
                                    "tenant_id": tenant_id,
                                    "customer_name": record.get("customer_name", None) if record else None,
                                    "customer_account_number": record.get("account_number", None) if record else None,
                                    "customer_rate_plan": record.get("customer_rate_plan_name", None) if record else None,
                                    "customer_rate_pool": record.get("customer_rate_pool_name", None) if record else None,
                                    "service_provider_display_name": service_provider,
                                    "service_provider_id": record.get("service_provider_id", None) if record else None,
                                    "device_id": record.get("device_id", None) if record else None,
                                    "mobility_device_id": record.get("mobility_device_id", None) if record else None,
                                    "date_of_change": now,
                                    "changed_by": created_by,
                                    "customer_name_with_revio":(f"{record.get('rev_customer_name')} ({record.get('rev_customer_id')})"
                                                if record.get("rev_customer_name") and record.get("rev_customer_id")
                                                else None),
                                    "is_deleted": False,
                                }
                                if status_history:   
                                    logging.info(f"### device_status_history inserting  record data : {status_history}")
                                    inserted_id = database.insert_data(status_history, "device_status_history")
                                    if inserted_id:
                                        device_status_history_id = inserted_id
                                    
                                    #preparing for updating smi_device_detail_history table
                                    status_history.pop("device_id") 
                                    status_history.pop("bulk_change_id")   
                                    status_history["module_name"] = "Bulk Change" 
                                    status_history["is_active"] = record.get("is_active", None) if record else None
                                    status_history["dshid"] =device_status_history_id if device_status_history_id else None

                                    #insert into smi_device_detail_history
                                    logging.info(f"### telegence_bc_update_device_status inserting  record data : {status_history}")
                                    database.insert_data(status_history, "smi_device_detail_history")
                            except Exception as e:
                                ## audit if insert failed history
                                error_message = f"Error during inserting history table: {str(e)}"
                                error_type = type(e).__name__
                                try:
                                    error_data = {
                                        "service_name": "telegence_bc_update_device_status",
                                        "error_message": error_message,
                                        "error_type": error_type,
                                        "users": username,
                                        "tenant_name": tenant_name,
                                        "comments": f"Error while inserting into the history table for ICCID: {msisdn}",
                                        "module_name": "Bulk Change",
                                        "request_received_at": data.get("request_received_at") or now
                                    }
                                    common_utils_database.log_error_to_db(error_data, "error_log_table")
                                except Exception as log_e:
                                    logging.error(f"### telegence_bc_update_device_status and {tenant_name} Exception in logging error data: {log_e}")

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": "Update Telegence Subscriber: Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": json.dumps(result),
                            "error_text": "" if success else json.dumps(result),
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Error processing MSISDN: {e}")

            if INTERVAL and i + BATCH_SIZE < len(msisdns):
                time.sleep(INTERVAL)
        live_progress_percentage_tracker(database, bulk_change_id,75)
        # Handle and log invalid MSISDNs
        #prepare the payload for history table
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "change_type":change_type,
                                    "iccids": [],
                                    "msisdns":successfull_ids,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        #api call to update the history table
        try:
            if successfull_ids:
                logging.info(f"### telegence_bc_update_device_status and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Exception in thread: {e}") 

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": [],
                        "msisdns": successfull_ids,
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Update Device Status",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "sim_status"
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_update_device_status and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Exception in action history thread: {e}")
                            
        if invalid_ids:
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Update Telegence Subscriber: Invalid MSISDN",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(logs, "sim_management_bulk_change_detailed_logs")

        # Mark invalid request IDs as processed
        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids}
            )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # api call to sync the bulk change inventory table data with 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_update_device_status and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### telegence_bc_update_device_status and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        try:
            if successfull_ids:
                data["msisdns"]=successfull_ids
                logging.info(f"### telegence_bc_update_device_status and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_update_device_status and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        try:
            if successfull_ids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "changed_data": {
                            "msisdn": successfull_ids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        response={
            "flag": True,
            "processed": len(msisdns) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # audit the final bulk change log
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_update_device_status",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for updating device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the auditing log
            bulk_change_audit_action(
                    data, common_utils_database,
                    action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### telegence_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### telegence_bc_update_device_status and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "telegence_bc_update_device_status",
                "created_date": data.get("request_received_at") or now,
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### telegence_bc_update_device_status and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        return response

## Change Carrier Rate Plan function
def telegence_bc_change_carrier_rate_plan(data):
    """Change the carrier rate plan for the given devices.
    This function processes a list of MSISDNs and updates their carrier rate plan in the Telegence system.
    It handles bulk requests, updates the database, and logs the results.   
    Args:
        data (dict): Input data containing the following keys:
            - msisdns (list): List of MSISDNs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Telegence API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Recevied data for change carrier rate plan :{data}")
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type",'')
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    integration_id = data.get("integration_id", 6)

    provider_parent_name=data.get("parent_provider_name", "")

    # Validate required fields
    # Initialize for log entries
    log_entries = []
    success_ids = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
            #app_id, app_secret = fetch_app_details(database, integration_id)
            #logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetched App ID {app_id} and Secret {app_secret} for integration ID {integration_id}")
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_change_carrier_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,20)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        carrie_rate_plan=change_request_json.get("RatePlanName","")
        effective_date=change_request_json.get("EffectiveDate","")
        optimization_group=change_request_json.get("OptimizationGroup","")
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        neweffective_date=None
        ## Prepare headers for API call
        headers = {
                "accept": "application/json",
                "content-type": "application/json",
                "client_id": app_id,
                "client_secret": app_secret,
                "source": "product-papi/product",
                "x-trace-id": "d4f8a2c6-3b9e-4f1c-9e72-5a1b7d2f8e3c",
                "x-transaction-id": "73c427a4-2482-4e64-8cac-ea4ace577890",
                "User-Agent": "PostmanRuntime/7.36.1"
            }
        rate_plan_id=None
        optimization_group_id=None
        rate_plan_code=None
        optimization_group_data = pd.DataFrame()
        rate_plan_data=pd.DataFrame()
        # Validate input data for rateplan and optimization
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Validating input data for rate plan and optimization group")
        if carrie_rate_plan:
           rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrie_rate_plan, "is_active": True},
            ["id","friendly_name"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            rate_plan_code=rate_plan_data["friendly_name"].to_list()[0]
        if optimization_group and str(optimization_group) != "-1":
           optimization_group_data = database.get_data(
            "optimization_group",
            {"optimization_group_name": optimization_group, "is_active": True},
            ["id"]
            )
        if not optimization_group_data.empty:
            optimization_group_id = optimization_group_data["id"].to_list()[0]
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Rate plan ID: {rate_plan_id}, Optimization Group ID: {optimization_group_id}, Rate Plan Code: {rate_plan_code}")
        # Prepare an update dict 
        update_fields = {"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": rate_plan_code}       
        if optimization_group_id is not None:
            update_fields["optimization_group_id"] = optimization_group_id
        if effective_date:
           update_fields["effective_date"] = effective_date
           neweffective_date = datetime.fromisoformat(effective_date.replace("Z", "+00:00")).date().isoformat()
           
        update_fields["modified_by"] = username 

        # Validate MSISDNs
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
            ["id","iccid","msisdn","carrier_rate_plan_name","billing_account_number"]
        ).to_dict(orient="records")
        inventory_lookup = {rec["msisdn"]: rec for rec in old_inventory_data}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_change_carrier_rate_plan and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        # if effective_date:
        #    payload["effectiveDate"] = effective_date
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each MSISDN in the batch
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    # Prepare the URL and payload for the API call
                    billing_record = inventory_lookup.get(msisdn)

                    if billing_record:
                        billing_number = billing_record.get("billing_account_number")
                    else:
                        billing_number = None
                    url = f"{carrier_api_url}"
                    payload={
                        "ratePlanCode": carrie_rate_plan,
                        #"effectiveDate": effective_date,
                        "subscriberNumber": msisdn,
                        "billingAccountNumber": billing_number
                    }
                    if neweffective_date:
                        payload["effectiveDate"] = neweffective_date
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    def task(msisdn=msisdn, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                                resp = requests.patch(
                                    url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                success = 200 <= resp.status_code < 300
                                #success = 200
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    success_ids.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            update_data = {
                                "status": status,
                                "has_errors": False,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":json.dumps(result)   
                            }
                        else:
                            update_data = {
                                "status": status,
                                "has_errors": True,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":json.dumps(result)
                            }
                        #update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                            )
                        # Only update inventory if API succeeded
                        if success:
                            database.update_dict(
                                "sim_management_inventory",update_fields,
                                and_conditions={"is_active": True},
                                in_conditions={"msisdn": [msisdn]}
                                )
                        # Constructing the log entry
                        log = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                        "log_entry_description": "Update Telegence Subscriber: Telegence API",
                        "request_text": json.dumps(payload),
                        "has_errors": status == "API_FAILED",
                        "response_status": "PROCESSED" if success else "API_Failed",
                        "response_text": json.dumps(result),
                        "error_text": "" if status == "PROCESSED" else json.dumps(result),
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                        }
            
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log, "sim_management_bulk_change_detailed_logs") 
                        return msisdn
                    
                    # Submit the task to the executor
                    logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Error processing MSISDN: {e}")

              
        if interval and i + batch_size < len(msisdns):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        #preare the payload for history table
        if success_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":success_ids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table API
            try:
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}") 
        # Update the bulk change request status   
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Processed {len(msisdns) - len(remaining)} MSISDNs, {len(remaining)} remaining")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": [],
                        "msisdns": success_ids,
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Carrier Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "carrier_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid MSISDNs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_ids:
            logging.info(f"### Invalid MSISDNs found: {invalid_ids}")
            # Log invalid ICCIDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"id": invalid_ids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        logging.info(f"telegence_bc_change_carrier_rate_palan and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### telegence_bc_change_carrier_rate_plan and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f'### telegence_bc_change_carrier_rate_plan and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            if success_ids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "carrie_rate_plan":carrie_rate_plan,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "changed_data": {
                            "msisdn": success_ids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_change_carrier_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response

## Change Phone Number function  
def telegence_bc_change_phone_number(data):
    """
    Change phone number using the Telegence API.
    This function processes a bulk change request to update phone numbers in the Telegence system.
    Args:
        data (dict): Input data containing the following keys:
            - tenant_name (str): Name of the tenant.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            - changed_data (dict): Data to be sent to the Telegence API.
            - old_msisdn (list): List of old MSISDNs to process.
            - new_msisdn (list): New MSISDNs to set.
            - effective_date (str): Effective date for the change.
            - bulk_change_id (str): ID of the bulk change request.
            - tenant_id (str): ID of the tenant.
            - created_by (str): User who initiated the request.
            - username (str): Username of the user making the request.
            - invalid_msisdns (list): List of invalid MSISDNs, if any.
            - invalid_ids (list): List of invalid IDs, if any.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for changing phone number {data}")
    start_time=time.time()
    tenant_name=data.get("tenant_name","")
    change_type = data.get("change_type",'')
    service_provider=data.get("service_provider","")
    change_type=data.get("change_type","")
    changed_data=data.get("changed_data",{})
    msisdns=data.get("msisdns",[])
    bulk_change_id=data.get("bulk_change_id","")
    tenant_id=data.get("tenant_id")
    source=data.get("source","")
    created_by = data.get("created_by", "")
    username = data.get("username", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    integration_id = data.get("integration_id", 6)
    invalid_ids=data.get('invalid_ids','')
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    tenant_database = data.get("db_name", "")
    provider_parent_name=data.get("parent_provider_name", "")

    #frequency_setting=data.get("frequency_setting",4)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_change_phone_number and {tenant_name} time is {now}")
    logging.info(f"### telegence_bc_change_phone_number are {msisdns}")
    # Validate required fields
    if not bulk_change_id:
        logging.error(f"### telegence_bc_change_phone_number and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    #connect to the database
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} DB connection failed: {e}")
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
    except Exception as e:
        logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Audit logging failed: {e}")
    # Initialize for log entries
    log_entries = []
    successful_msisdns = []
    new_msisdns=[]
    ## current time
    frequency_setting=0
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    tenant_details = common_utils_database.get_data(
      "tenant", {"tenant_name": tenant_name}, ["id","change_phone_number_frequency_setting"]
    )
    if not tenant_details.empty:
        frequency_setting = tenant_details.iloc[0].get("change_phone_number_frequency_setting")

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        #  Fetching carrier API configuration details
        try:
            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            # Fetch carrier API details
            provider = provider_parent_name if provider_parent_name else service_provider
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
            #app_id, app_secret = fetch_app_details(database, integration_id)
            #logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Fetched App ID {app_id} and Secret {app_secret} for integration ID {integration_id}")
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch bulk change rows       
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_change_phone_number",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_change_phone_number and {tenant_name} Audit logging failed: {e}")
                return response
        # Rename columns for consistency 
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Fetched {len(bulk_requests_df)} bulk change requests from the database")
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        # Feching details from inventory table 
        inventory_df = database.get_data(
            "sim_management_inventory",
            {"msisdn": msisdns, "is_active": True, "tenant_id": tenant_id,"service_provider_display_name":service_provider},
            ["msisdn", "billing_account_number", "service_zip_code"]
        )  
        if not inventory_df.empty:
            inventory_records = inventory_df.to_dict(orient='records')
            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Fetched inventory records for MSISDNs from the database")

        else:
            logging.error(f"### telegence_bc_change_phone_number and {tenant_name} No inventory records found for MSISDNs: {msisdns}")
            inventory_records = []
        live_progress_percentage_tracker(database, bulk_change_id,20)
        msisdn_to_details = {
             record["msisdn"]: {
             "billingAccountNumber": record["billing_account_number"],
             "serviceZipCode": record["service_zip_code"]
           }
             for record in inventory_records
           }

        ## Prepare headers for API call
        headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "client_id": app_id,
            "client_secret": app_secret,
            "source": "product-papi/product",
            "x-trace-id": "a49fd114-c14b-11ea-b3de-0242ac130004",
            "x-transaction-id": "73c427a4-2482-4e64-8cac-ea4ace577890",
            "User-Agent": "PostmanRuntime/7.36.1"
        }
        
        # Validate MSISDNs
        remaining = msisdns.copy()
        updated_msisdns = {}
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Validating input data for phone number change")
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {e}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
                ["id","iccid","msisdn",]
            ).to_dict(orient="records")
        
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        valid_msisdns=[]
        blocked_msisdns=[]
        response_data = None
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action=f"Processing With Carrier APIs")
        # Query to get counts per msisdn
        if msisdns:
            placeholders = ",".join(["%s"] * len(msisdns))

            query = f"""
                SELECT req.subscriber_number, COUNT(*) AS processed_count
                FROM public.sim_management_bulk_change_request req
                JOIN public.sim_management_bulk_change bc
                ON req.bulk_change_id = bc.id
                WHERE req.subscriber_number IN ({placeholders})
                AND req.status = %s
                AND req.created_date >= NOW() - INTERVAL '30 days'
                AND bc.change_request_type = %s
                GROUP BY req.subscriber_number
            """

            # Params: expand msisdns list + extra params
            params = msisdns + ["PROCESSED", change_type]

            df = database.execute_query(query, params=params)
            
            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Frequency setting: {frequency_setting}")
            
            if df is None or df.empty:
                # NO MSISDNs have been PROCESSED before in last 30 days
                # So ALL MSISDNs are valid (0 counts)
                valid_msisdns = msisdns.copy()  # ALL MSISDNs are valid
                blocked_msisdns = []
                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} No previous PROCESSED records found. All MSISDNs are valid: {valid_msisdns}")
            else:
                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Query results:\n{df.to_string()}")
                
                # Valid where processed_count <= frequency_setting
                valid_msisdns = df.loc[df["processed_count"] <= frequency_setting, "subscriber_number"].tolist()

                # Blocked where processed_count > frequency_setting
                blocked_msisdns = df.loc[df["processed_count"] > frequency_setting, "subscriber_number"].tolist()
                
                # Find MSISDNs not in query results (these have 0 counts)
                all_msisdns_set = set(msisdns)
                queried_msisdns_set = set(df["subscriber_number"].tolist())
                never_processed_msisdns = list(all_msisdns_set - queried_msisdns_set)
                
                # Add MSISDNs with 0 counts to valid list
                valid_msisdns.extend(never_processed_msisdns)
                
                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Valid MSISDNs: {valid_msisdns}")
                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Blocked MSISDNs: {blocked_msisdns}")
                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Never processed (0 counts): {never_processed_msisdns}")

        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        if valid_msisdns:
            msisdns = valid_msisdns
        else:
            # If no valid MSISDNs (shouldn't happen unless all are blocked)
            logging.warning(f"### telegence_bc_change_phone_number and {tenant_name} No valid MSISDNs to process")
            msisdns = []
            
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                futures = {}
                
                # Process each MSISDN in the batch
                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    url = f"{carrier_api_url}"
                    details = msisdn_to_details.get(msisdn)   
                    payload = {
                        "serviceZipCode": details["serviceZipCode"],
                        "subscriberNumber": msisdn,
                        "billingAccountNumber": details["billingAccountNumber"],
                    }           
                    # Define the task function to be executed in parallel
                    def task(msisdn=msisdn, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        response_data = {}

                        # Retry loop
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                            
                                response = requests.post(url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Response Code: {response.status_code} for MSISDN: {msisdn}")
                                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Response Body: {response.text}")

                                success = 200 <= response.status_code < 300
                                result = response.text
                                status = "PROCESSED" if success else "API_FAILED"

                                if success:
                                    response_data = response.json()
                                    successful_msisdns.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)
                        # If the API call was successful, check the response
                        # Check and extract new MSISDN from response
                        new_msisdn_number = None
                        if response_data:
                            number_change_info = response_data.get("numberChangeInfo", {})
                            if number_change_info.get("status") == "FAILED":
                                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Phone number change failed for {msisdn}: {number_change_info.get('statusMessage', 'Unknown error')}")
                                success = False
                                status = "API_FAILED"
                            else:
                                new_msisdn_number = number_change_info.get("newSubscriberNumber")
                                if new_msisdn_number:
                                    updated_msisdns[msisdn] = new_msisdn_number
                                    new_msisdns.append(new_msisdn_number)
                                    success = True
                                    status = "PROCESSED"
                                    logging.info(f"### telegence_bc_change_phone_number and {tenant_name} MSISDN changed from {msisdn} to {new_msisdn_number} ")

                        # Update request status
                        update_data = {
                            "status": status,
                            "has_errors": not success,
                            "is_processed": True,
                            "processed_date": now,
                            "status_details":result
                        }
                        # Update the request status in the database
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                        )

                        # Update inventory if success
                        if success and new_msisdn_number:
                            update_fields = {"msisdn": new_msisdn_number}
                            update_fields["modified_by"] = username
                            database.update_dict(
                                "sim_management_inventory",
                                update_fields,
                                and_conditions={"is_active": True},
                                in_conditions={"msisdn": [msisdn]},
                            )

                        # Construct and insert log
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": "Update Telegence Change Phone Number: Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        # Insert log into the database
                        database.insert_data(log, "sim_management_bulk_change_log")
                        #  insert the log entries into detailed logs table
                        database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                        return msisdn  # for tracking

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Error processing MSISDN: {e}")

        if interval and i + batch_size < len(msisdns):
            time.sleep(interval)  
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Prepare URL and payload for history table update
        if successful_msisdns:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":successful_msisdns,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update history table
            try:
                logging.info(f"### telegence_bc_change_phone_number and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Exception in thread: {e}") 
            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Processed {len(msisdns) - len(remaining)} MSISDNs, {len(remaining)} remaining")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": [],
                        "msisdns":successful_msisdns,
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Phone Number",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "msisdn",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_change_phone_number and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Exception in action history thread: {e}")
        live_progress_percentage_tracker(database, bulk_change_id,75)
        #handling blocked msisdns
        if blocked_msisdns:
            logging.info(f"### blocked MSISDNs found: {blocked_msisdns}")
            # Log invalid IDs
            for msisdn in blocked_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Chang Phone number",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": f"Change Phone Number can be done only{frequency_setting} times in last 30 days for the same MSISDN",
                    "error_text": "blocked MSISDN",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_msisdns:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":f"Change Phone Number can be done only{frequency_setting} times in last 30 days for the same MSISDN"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": blocked_msisdns},)
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        #handling invalid msisdns
        if invalid_msisdns:
            logging.info(f"### Invalid MSISDNs found: {invalid_msisdns}")
            # Log invalid IDs
            for msisdn in invalid_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Chang Phone number",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_msisdns:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": invalid_msisdns},)
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        logging.info(f"telegence_bc_change_phone_number and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
       
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
                ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### telegence_bc_change_phone_number and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_bc_change_phone_number and {tenant_name} sync call has ended") 
        except Exception as e:
            logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Exception in thread: {e}")
        # Return success
        try:
            if successful_msisdns:      		
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "changed_data": {
                            "msisdn": new_msisdns if new_msisdns else successful_msisdns,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_change_phone_number and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
       ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_change_phone_number",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing phone number for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
 
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_bc_change_phone_number",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_phone_number and {tenant_name} Exception in logging error data to DB: {e}")
        return response
##PPU address update function
def telegence_bc_update_ppu_address(data):
    """
    Bulk update of PPU address using AMLC Telegence API using MSISDN to change_request mapping.

    This function performs the following steps:
        - Extracts necessary metadata and initializes DB connections.
        - Fetches carrier API credentials and limits.
        - Fetches and maps MSISDNs to their payloads and request IDs.
        - Sends PATCH requests to update PPU address using ThreadPoolExecutor with retry logic.
        - Logs responses, updates DB entries, and handles invalid MSISDNs/IDs.
        - Logs audit events before and after processing.

    Args:
        data (dict): Contains keys such as msisdns, bulk_change_id, created_by, service_provider, etc.

    Returns:
        dict: Summary response including processed count and any remaining MSISDNs.
    """
    logging.info(f"### Received data for PPU address update: %s",data)
    start_time = time.time()
    # Extract input metadata
    msisdns = data.get("msisdns", [])
    change_type = data.get("change_type",'')
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids = data.get("invalid_ids", [])
    source=data.get("source","")
    now_dt = datetime.now()
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    integration_id = data.get("integration_id", 6)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    provider_parent_name=data.get("parent_provider_name", "")

    logging.info(f"###def telegence_bc_update_ppu_address and {tenant_name} time is {now}")
    if not bulk_change_id:
        logging.error("### telegence_bc_update_ppu_address and {tenant_name} Missing required fields") 
        return {"flag": False, "message": "bulk_change_id is required"}

    # DB Connections
    try:
        database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### telegence_bc_update_ppu_address and{tenant_name} DB connection error:{e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        # Fetch carrier API details
        provider = provider_parent_name if provider_parent_name else service_provider
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(provider, change_type, common_utils_database)
        #app_id, app_secret = fetch_app_details(database, integration_id)
        #logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Fetched App ID {app_id} and Secret for integration ID {integration_id}")
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### telegence_bc_update_ppu_address and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}
        
    except Exception as e:
        logging.exception(f"### telegence_bc_update_ppu_address and{tenant_name} Audit logging failed after config fetch: {e}")
    live_progress_percentage_tracker(database, bulk_change_id,20)

    if source == "Inventory":
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
            ["id","iccid","msisdn","user_address"]
        ).to_dict(orient="records")
    ## Carrier limits
    successful_msisdns = []
    BATCH_SIZE = carrier_limits.get("batch_size")
    PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
    INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
    RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
    try:
        # Fetch change requests from DB
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        ).rename(columns={"subscriber_number": "msisdn"})
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_update_ppu_address",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_update_ppu_address and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,30)
        # try:
        #     change_request = json.loads(change_request_json)
        # except (TypeError, json.JSONDecodeError):
        #     # handle parsing error
        #     change_request = {}
        if isinstance(change_request_json, str):
           change_request = json.loads(change_request_json)
        user_address = change_request.get("UserAddress", {})
        # Billing Account
        billing_account = user_address.get("billingAccount", {})
        billingaccount_id = billing_account.get("id", "")
        # Related Party
        related_party = user_address.get("relatedParty", {})
        role = related_party.get("role", "")
        first_name = related_party.get("firstName", "")
        last_name = related_party.get("lastName", "")
        # Address
        address = related_party.get("address", {})
        street_number = address.get("streetNumber", "")
        street_direction = address.get("streetDirection", "")
        street_name = address.get("streetName", "")
        street_type = address.get("streetType", "")
        city = address.get("city", "")
        zip_code = address.get("zipCode", "")
        state = address.get("state", "")

        logging.info(f"### telegence_bc_update_ppu_address and{tenant_name} change_request: {change_request}")
        useraddress = change_request.get("UserAddress", {})
        updated_data = {"user_address": json.dumps(useraddress)}
        updated_data["modified_by"] = username 
        ##fetching the change requests
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))

        logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Fetched {len(bulk_requests)} bulk change requests from the database")
        logs = []
        remaining = list(msisdns)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        ##batch processing
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            ## Process each batch of MSISDNs
            for i in range(0, len(msisdns), BATCH_SIZE):
                # Create a batch of MSISDNs
                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Processing batch {i // BATCH_SIZE + 1} with {min(BATCH_SIZE, len(msisdns) - i)} MSISDNs")
                batch = msisdns[i:i + BATCH_SIZE]
                futures = {}
                # Prepare payloads and URLs for each MSISDN in the batch
                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Batch size is {len(batch)}")
                for msisdn in batch:
                    url = f"{carrier_api_url}/{msisdn}"
                    try:
                        # Parse the change request JSON for the MSISDN
                        payload_str=msisdn_to_changerequest.get(msisdn)
                        request_payload = json.loads(payload_str)
                        payload = {
                            "relatedParty": {
                                "role": role,
                                "address": {
                                "unit": {
                                    "unitType": "FL",
                                    "unitValue": "3"
                                },
                                "city": city,
                                "state": state,
                                "zipCode": zip_code,
                                "streetInfo": {
                                    "streetName": street_name,
                                    "streetType": street_type,
                                    "streetNumber": street_number,
                                    "streetDirection": street_direction
                                },
                                "addressLine": [f"{street_number}  {street_name} {street_type}"],
                                },
                                "lastName": last_name,
                                "firstName": first_name
                            },
                            "subscriberNumber": msisdn,
                            "billingAccountNumber": billingaccount_id
                            }
                        headers = {
                            "accept": "application/json",
                            "content-type": "application/json",
                            "client_id": app_id,
                            "client_secret": app_secret,
                            "source": "product-papi/product",
                            "x-trace-id": "a49fd114-c14b-11ea-b3de-0242ac130004",
                            "x-transaction-id": "73c427a4-2482-4e64-8cac-ea4ace577890",
                            "User-Agent": "PostmanRuntime/7.36.1"
                        }
                    except Exception as e:
                        logging.warning(f"### telegence_bc_update_ppu_address and {tenant_name} Invalid JSON for MSISDN {msisdn}: {e}")
                        payload = {}
                    ## Validate payload
                    request_id = msisdn_to_request_id.get(msisdn)
                    def task(msisdn=msisdn, url=url, payload=payload, request_id=request_id):
                        success = False
                        result = ""
                        status = "API_FAILED"

                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Attempt {attempt} - URL: {url}")
                                resp = requests.patch(
                                    url,
                                    json=payload,
                                    headers=headers,
                                    timeout=60
                                )
                                ## Prepare request payloads
                                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Response Code: {resp.status_code} for PPU address update")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successful_msisdns.append(msisdn)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Attempt {attempt} failed for {msisdn}:{e}")
                                time.sleep(RETRY_DELAY)

                        # Update DB request row
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                              "processed_date": now,"status_details":json.dumps(result)},
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory
                        if success:
                            logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Updating inventory for MSISDN: {msisdn}")
                            database.update_dict("sim_management_inventory", updated_data, {
                                "is_active": True,
                                "msisdn": msisdn
                                })

                        # Prepare and insert log
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": "Update PPU Address via Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now_dt,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now_dt,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Error processing MSISDN in thread: {e}")

                if INTERVAL and i + BATCH_SIZE < len(msisdns):
                    time.sleep(INTERVAL)
        logging.info(f"carrier requests are processed successfully")
        if successful_msisdns:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":successful_msisdns,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update device history tables
            try:
                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Exception in thread: {e}") 
            
            if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": [],
                        "msisdns": successful_msisdns,
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Update PPU Address",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "user_address"
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Exception in action history thread: {e}")
                            
        live_progress_percentage_tracker(database, bulk_change_id,80)
                    
        # Handle invalid MSISDNs
        if invalid_ids:
            logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Invalid MSISDNs found: {invalid_ids}")
            # Log invalid IDS
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Invalid MSISDN during PPU address update",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid MSISDN - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now_dt,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now_dt,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(logs, "sim_management_bulk_change_detailed_logs")

        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now,"status_details":"Invalid MSISDN - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids}
            )

        database.update_dict(
            "sim_management_bulk_change",
            {"status": "PROCESSED", "processed_date": now_dt},
            {"id": bulk_change_id}
        )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                    "data": {
                        "access_token": access_token,
                        "data": {
                            "bulk_change_id": bulk_change_id
                        },
                        "db_name": tenant_database,
                        "is_update": True,
                        "module_name": "Bulk Change",
                        "Partner": tenant_name,
                        "path": "/update_bulk_change_tables_10",
                        "request_received_at": now,
                        "role_name": role_name,
                        "tenant_name": tenant_name,
                        "username": username
                    }
                }
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        ##prepare response
        try:
            if successful_msisdns:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "changed_data": {
                            "msisdn": successful_msisdns,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_update_ppu_address and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Exception in thread: {e}")
        response = {
            "flag": True,
            "processed": len(msisdns) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk PPU address update request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # End time calculation
        try:
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_update_ppu_address",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk PPU address update request for devices: {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
             logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        logging.exception(f"### telegence_bc_change_update_ppu_address and {tenant_name} Audit logging failed: {e}")
        error_message = f"Error during bulk PPU address update processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_bc_update_ppu_address",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
             logging.exception(f"### telegence_bc_update_ppu_address and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
     
## create rev service update function
def telegence_bc_create_rev_service(data):
    """
    Create Rev Serivice in Rev.IO for the provided MSISDNs, update inventory,
    and update device_tenant and rev_service_product tables accordingly.
    
    This function handles bulk requests with batching and parallelism, 
    updates the database, logs the results, and performs retries on API failures.

    Args:
        data (dict): Input data containing the following keys:
            - msisdns (list): List of msisdns to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to Rev.IO API.
            - created_by (str): User who initiated the request.
            - tenant_id (str): Tenant ID for DB operations.
            - db_name (str): DB name for tenant.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            - invalid_msisdns (list): msisdns to mark as invalid if required.
            - username (str): Username of the user initiating the request
            - tenant_name (str): Name of the tenant
            - role_name (str): Role of the user
            - access_token (str): Access token for sync API

    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Received data for Create Rev Serivice {data} ")
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    change_type = data.get("change_type",'')
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    successful_msisdns = []
    service_type_id=None
    rev_service_type_id=None
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_create_rev_service and {tenant_name} time is {now}")

    # Check for missing required fields
    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### telegence_bc_create_rev_service and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### telegence_bc_create_rev_service and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch bulk change rows
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        # Validate input data 
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_create_rev_service",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_create_rev_service and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        rev_service_type_id=change_request_json.get("ServiceTypeId","")
        if rev_service_type_id:
            service_type_data=database.get_data(
                    "rev_service_type",
                    {"service_type_id": rev_service_type_id, "is_active": True},
                    ["id"]
                )
            if not service_type_data.empty:
                service_type_id = service_type_data["id"].to_list()[0]
            else:
                service_type_id = None
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} rev_service_type_id is {service_type_id}")

        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[])
        product_id = revproductidlist[0] if revproductidlist else None
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate= change_request_json.get("RateList", [])
        revpackageid=change_request_json.get("RevPackageId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer:
            customer_data=database.get_data(
                "customers",
                {"customer_name":rev_customer,"is_active": True},
                ["id","customer_name"]
            )
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        if device_id:
            update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        bulk_requests = bulk_requests.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = fetch_headers(database,tenant_id,app_id,app_secret)
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Headers prepared for API call{headers}")
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        if rate:
            product_data["rate"] = rate
        if product_id:
            product_data["product_id"] = product_id
        # Validate msisdns
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_create_rev_service and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking msisdns and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of msisdns
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of msisdns
                batch = msisdns[i:i + batch_size]
                # create a dictionary to hold futures
                futures = {}
                logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Processing msisdn: {msisdn}")
                    payload_str = msisdn_to_changerequest.get(msisdn)
                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Payload for MSISDN {msisdn}: {payload_str}")
                    #request_payload = json.loads(payload_str)
                    #extract the create rev service flag
                    #rev_service = request_payload.get("CreateRevService", False)
                    # Build payloads for all APIs
                    rev_api_payload = {
                        "customer_id": rev_customer_id,
                        "provider_id": provider_id,
                        "service_type_id": rev_service_type_id,
                        "number": number,
                        "activated_date": activated_date,
                    }
                   
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    #task function
                    def task(msisdn=msisdn):
                        """
                            - Step 1: Call RevService API with retries
                            - Step 2: Extract RevService ID from API response
                            - Step 3: Insert into rev_service table & update inventory"""
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                       
                        try:                           
                            #  API Call to create the revservice
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Attempt {attempt} - URL: {url}")
                                    
                                    resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Response Code: {resp.status_code} for Create Rev Service")
                                    logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Response Text: {result}")
                                    status = "PROCESSED" if success else "API_Failed"
                                    if success:
                                        try:
                                            response_data = resp.json()
                                            id = response_data.get("id")
                                            successful_msisdns.append(msisdn)
                                        except Exception:
                                            id = None
                                        break
                                except Exception as e:
                                    result = str(e)
                                    status = "API_EXCEPTION"
                                    logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                    time.sleep(RETRY_DELAY)                
                            if success:
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":result},
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number": msisdns},
                                )
                                #inserting values in rev service 
                                rev_data={
                                "rev_customer_id":rev_customer_uuid,
                                "number":msisdn,
                                "rev_service_id":id,
                                "activated_date":activated_date,
                                "is_active":True,
                                "integration_authentication_id":integration_authentication_id,
                                "rev_provider_id":rev_provider_id,
                                "rev_service_type_id":service_type_id,
                                "rev_service_line_status":"PROCESSED",
                                "bulk_change_id":bulk_change_id,
                                }
                                database.insert_data(rev_data,"rev_service")
                                #updating inventory table
                                rev_service_log=database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"tenant_id":tenant_id,"is_active": True},
                                    in_conditions={"msisdn": [msisdn]}
                                )
                            # Inserting logs based on api result
                            rev_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Create Rev.io Service: Rev.io API",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors": status == "PROCESSED",
                                    "response_status": "PROCESSED" if success else "API_Failed",
                                    "response_text": result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                            database.insert_data(rev_log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(rev_log, "sim_management_bulk_change_detailed_logs") 
                            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Rev Service created successfully for MSISDN: {msisdn}")
                            #inserting logs after updating inventory table
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Create Rev.io Service: Update AMOP",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors":False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK" ,
                                    "error_text": "",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log, "sim_management_bulk_change_detailed_logs")
                                logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Inventory updated successfully for MSISDN: {msisdn}")       
                        except Exception as e:
                            logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Unexpected error for msisdn {msisdn}: {str(e)}")
                        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Completed processing for MSISDN: {msisdn}")
                        return msisdn
                    futures[executor.submit(task)] = msisdn
                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Error processing MSISDN in thread: {e}")
        if interval and i + batch_size < len(msisdns):
            time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Processed %d msisdns, %d remaining", len(msisdns) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "change_type":change_type,
                                    "iccids": [],
                                    "msisdns":successful_msisdns,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        # Call sync API for history table
        try:
            if successful_msisdns:
             logging.info(f"### telegence_bc_create_rev_service and {tenant_name} sync call has started for history table")
             threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Exception in thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_ids:
            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Invalid msisdns found: %s", invalid_ids)
            # Log invalid IDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Create Rev Serivice ",
                    "request_text": "Update AMOP",
                    "has_errors": True, 
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_ids:
            database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","is_processed":True,"has_errors":True,"status_details":"Invalid SIM - could not be processed"},
                    and_conditions={"bulk_change_id": bulk_change_id},
                    in_conditions={"id": invalid_ids},
                )
        # Insert log entries into DB
        if log_entries: 
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Bulk Change ID: {bulk_change_id}")
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} Processed %d msisdns, %d remaining", len(msisdns) - len(remaining), len(remaining))
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token, 
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call for inventory table
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### telegence_bc_create_rev_service and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_create_rev_service  and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            audit_data_user_actions = {
                "service_name": "telegence_bc_create_rev_service",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Create Rev Serivice for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_create_rev_service and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response



    
   
##Change ICCID/IMEI function
def telegence_bc_change_iccid_imei(data):
    """
     Update ICCID or IMEI for multiple subscribers using Telegence API.

    This function performs the following steps:
        - Validates required input values.
        - Establishes DB connections.
        - Fetches API credentials and carrier limits.
        - Builds and sends PATCH requests per MSISDN in parallel with retry logic.
        - Updates status in DB and logs results.
        - Handles invalid MSISDNs and triggers sync API.

    Args:
        data (dict): Input dictionary containing:
            - msisdns (list): List of MSISDNs to process.
            - new_iccid (str): New ICCID to assign (if applicable).
            - new_imei (str): New IMEI to assign (if applicable).
            - bulk_change_id (str): Unique ID of the bulk change job.
            - service_provider (str): Carrier/service provider name.
            - change_type (str): Type of operation.
            - created_by (str): User initiating the request.
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant.
            - db_name (str): Database name for the tenant.
            - username (str): Username for error/audit tracking.
            - changed_data (dict): Contains serviceCharacteristic array.
            - invalid_msisdns (list): Optional invalid MSISDNs before processing.
            - request_received_at (str): Optional timestamp.

    Returns:
        dict: Result object with success flag, count, and error info
    """
    logging.info(f"Received data for ICCID/IMEI change{data}")
    start_time = time.time()
    # Extract input data
    msisdns = list(data.get("msisdns", []))
    bulk_change_id = data.get("bulk_change_id")
    tenant_id = data.get("tenant_id","")
    invalid_ids=data.get("invalid_ids","")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name")
    db_name = data.get("db_name", "")
    integration_id = data.get("integration_id", 6)
    invalid_msisdns = data.get("invalid_msisdns", [])
    request_received_at = data.get("request_received_at")
    tenant_database = db_name
    access_token = data.get("access_token", "")
    role_name = data.get("role", "")
    provider_parent_name=data.get("parent_provider_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_change_iccid_imei and {tenant_name} time is {now}")
    logs = []
    processed = 0
    # DB Connections
    try:
        database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### telegence_bc_change_iccid_imei and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    # Audit log - start processing
    try:
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        #logging.exception("### Audit logging failed before PATCH requests")
        logging.error(f"### telegence_bc_change_iccid_imei and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Get carrier config
        provider = provider_parent_name if provider_parent_name else service_provider
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
            provider, change_type, common_utils_database
        )

        #app_id, app_secret = fetch_app_details(database, integration_id)
        #logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Fetched App ID {app_id} and Secret for integration ID {integration_id}")
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        ##fetching carrier url
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch request rows
        request_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "subscriber_number", "change_request"]
        )
        logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Fetched {len(request_df)} records from bulk change request table")
        updated_data={}
        successful_msisdns = []
        # Validate input data
        if not request_df.empty:
            change_request_json = request_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_change_iccid_imei",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_change_iccid_imei and {tenant_name} Audit logging failed: {e}")
                return response
            if isinstance(change_request_json, str):
                change_request_json = json.loads(change_request_json)
            ##fetching the required details
            request_df = request_df.rename(columns={'subscriber_number': 'msisdn'})
            service_chars = change_request_json.get("RevService", {})
            if service_chars:
                ##fetching the customer rate plan and customer rate pool details
                customer_rate_plan_id = service_chars.get("CustomerRatePlan","")
                customer_rate_pool_id = service_chars.get("CustomerRatePool","")
                if customer_rate_plan_id:
                    rate_plan_data = database.get_data(
                        "customerrateplan",
                        {"id": customer_rate_plan_id, "is_active": True},
                        ["rate_plan_name"]
                    )
                    if not rate_plan_data.empty:
                        customer_rate_plan_name = rate_plan_data["rate_plan_name"].to_list()[0]
                        updated_data['customer_rate_plan_name']=customer_rate_plan_name
                        updated_data['customer_rate_plan_id']=customer_rate_plan_id
                if customer_rate_pool_id:
                    rate_plan_data = database.get_data(
                        "customer_rate_pool",
                        {"id": customer_rate_pool_id, "is_active": True},
                        ["name"]
                    )
                    if not rate_plan_data.empty:
                        customer_rate_pool_name = rate_plan_data["name"].to_list()[0]
                        updated_data['customer_rate_pool_name']=customer_rate_pool_name
                        updated_data['customer_rate_pool_id']=customer_rate_pool_id
        # Create mappings
        id_map = dict(zip(request_df["msisdn"], request_df["id"]))
        msisdns_to_change_request = dict(zip(request_df["msisdn"], request_df["change_request"]))
        logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Mapped {len(msisdns_to_change_request)} MSISDNs to change requests")

        # Carrier limits
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        BATCH_SIZE = carrier_limits.get("batch_size", 50)
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests", 10)
        if PARALLEL_REQUESTS>10:
            logging.info(f"###telegence_bc_change_iccid_imei and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        remaining = list(msisdns)

        headers = {
                "accept": "application/json",
                "content-type": "application/json",
                "client_id": app_id,
                "client_secret": app_secret,
                "source": "product-papi/product",
                "x-trace-id": "a49fd114-c14b-11ea-b3de-0242ac130004",
                "x-transaction-id": "73c427a4-2482-4e64-8cac-ea4ace577890",
                "User-Agent": "PostmanRuntime/7.36.1"
            }
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
            ["id","iccid","msisdn","carrier_rate_plan_name","billing_account_number","service_zip_code"]
        ).to_dict(orient="records")
        inventory_lookup = {rec["msisdn"]: rec for rec in old_inventory_data}
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(msisdns), BATCH_SIZE):
                batch = msisdns[i:i + BATCH_SIZE]
                logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Processing batch {i // BATCH_SIZE + 1} with {len(batch)} MSISDNs")
                futures = {}

                for msisdn in batch:
                    payload_str = msisdns_to_change_request.get(msisdn)

                    if not payload_str:
                        logging.warning(f"### telegence_bc_change_iccid_imei and {tenant_name} Skipping MSISDN {msisdn}: missing change_request payload")
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": id_map.get(msisdn),
                            "log_entry_description": f"Missing change_request payload for {msisdn}",
                            "request_text": "N/A",
                            "has_errors": True,
                            "response_status": "ERROR",
                            "response_text": "Missing payload",
                            "error_text": "No change_request found",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        logs.append(log)
                        continue
                    request_payload = json.loads(payload_str)
                    payload_data = request_payload.get("Request")
                    imei = None
                    sim = None
                    eid=None
                    # Get the list of service characteristics
                    service_chars = payload_data.get("serviceCharacteristic", [])
                    # Loop through to find IMEI and sim
                    for char in service_chars:
                        if char.get("name") == "IMEI":
                            imei_1 = char.get("value")
                        elif char.get("name") == "sim":
                            sim_1 = char.get("value")
                    billing_record = inventory_lookup.get(msisdn)
                    if billing_record:
                        billing_number = billing_record.get("billing_account_number")
                        zipcode= billing_record.get("service_zip_code","")
                    else:
                        billing_number = None
                    #service_chars = payload.get("serviceCharacteristic", [])
                    characteristics_dict = {item["name"]: item["value"] for item in service_chars}
                    iccid = characteristics_dict.get("sim","")
                    imei = characteristics_dict.get("IMEI","")
                    updated_data['imei']=imei
                    updated_data['iccid']=iccid
                    logging.info(f"updated_data is {updated_data}")
                    payload = {
                        "billingAccountNumber": billing_number,
                        "subscriberNumber": msisdn,
                        "serviceZipCode": zipcode,
                        "imei": imei_1,
                        "technologyType": "LTE"
                        }
                    if sim:
                        payload["sim"] = sim_1
                    logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Processing MSISDN: {msisdn} with payload: {payload}")
                    url = f"{carrier_api_url}"
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    def task(msisdn=msisdn, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        request_id = id_map.get(msisdn)

                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Attempt {attempt} - URL: {url}")
                                resp = requests.patch(url, json=payload, headers=headers, timeout=30)
                                logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                if 200 <= resp.status_code < 300:
                                    success = True
                                    status = "PROCESSED"
                                    result = resp.text
                                    data_jason=resp.json()
                                    id=data_jason.get("deviceChangeId","")
                                    successful_msisdns.append(msisdn)
                                    break
                                else:
                                    result = resp.text
                                    time.sleep(RETRY_DELAY)
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                time.sleep(RETRY_DELAY)
                        # DB update
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                              "processed_date": now,"status_details":result},
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                        )
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": f"Change {'ICCID' if 'sim' in characteristics_dict else 'IMEI'} via Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                        # Update inventory
                        if success and id: 
                            url=f"{carrier_api_url}/{id}"
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Attempt {attempt} - URL: {url}")
                                    resp = requests.get(url, headers=headers, timeout=30)
                                    logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                    if 200 <= resp.status_code < 300:
                                        success = True
                                        status = "PROCESSED"
                                        result = resp.text
                                        resp_data=resp.json()
                                        eid=resp_data.get("eid","")
                                        successful_msisdns.append(msisdn)
                                        break
                                    else:
                                        result = resp.text
                                        time.sleep(RETRY_DELAY)
                                except Exception as e:
                                    result = str(e)
                                    logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                    time.sleep(RETRY_DELAY)
                            database.update_dict("sim_management_inventory", updated_data, {
                                "is_active": True,
                                "msisdn": msisdn
                            })
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": request_id,
                                "log_entry_description":f"device status using Telegence API",
                                "request_text": json.dumps(payload),
                                "has_errors": not success,
                                "response_status": status,
                                "response_text": result,
                                "error_text": "" if success else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                        processed += 1
                    except Exception as e:
                        logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Error processing MSISDN in thread: {e}")

                if INTERVAL and i + BATCH_SIZE < len(msisdns):

                    time.sleep(INTERVAL)
        live_progress_percentage_tracker(database, bulk_change_id,60)
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "change_type":change_type,
                                    "iccids": [],
                                    "msisdns":successful_msisdns,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        # api call to update device history table
        try:
            if successful_msisdns:
             logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} sync call has started for history table")
             threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}") 
        # Handle invalid MSISDNs
        if invalid_ids:
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Invalid MSISD during ICCID/IMEI change",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid input",
                    "error_text": "Invalid identifier",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","errors":len(invalid_ids),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Invalid input"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids},
            )

        if logs:
            database.insert_data(logs, "sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(logs, "sim_management_bulk_change_detailed_logs")

        # Update bulk change summary
        database.update_dict("sim_management_bulk_change", {
            "status": "PROCESSED",
            "success": processed,
            "processed_date": now
        }, {"id": bulk_change_id})

        # Trigger sync API
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {
                    "bulk_change_id": bulk_change_id
                },
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        # Sync API call for inventory table
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }

        try:
            logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

        except Exception as e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        try:
            if successful_msisdns:
                data["msisdns"]=successful_msisdns
                logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,95)
        logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Bulk ICCID/IMEI change completed in {time.time() - start_time:.2f} seconds | Processed: {processed}")
        total_time = time.time() - start_time
        
        response= {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_change_iccid_imei",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing iccid/imei for devices.{bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### telegence_bc_change_iccid_imei and {tenant_name} Processed {len(msisdns)} MSISDNs, {len(remaining)} remaining")
        return response
    except Exception as e:
        logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Error during bulk change processing: {str(e)}")
        error_type = str(type(e).__name__)
        error_message = f"Error during bulk change processing for change ICCID?IMEI: {str(e)}"
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns, 
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            error_data = {
                "service_name": "Bulk ICCID/IMEI Processor",
                "created_date": request_received_at or now,
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk ICCID/IMEI change for: {msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": request_received_at or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.exception(f"### telegence_bc_change_iccid_imei and {tenant_name} Exception in logging error data to DB: {e}")
        return response
  

##Edit username or cost center function
def telegence_bc_edit_username_cost_center(data):
    """Edits the username or cost center associated with devices in bulk.
    
    This function processes a bulk change request to update username and/or cost center
    information for multiple devices. It handles both devices with and without Rev.io
    service IDs, making appropriate API calls for Rev.io integrated devices and direct
    database updates for others.
    
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs to process
            - bulk_change_id (str): ID of the bulk change request
            - created_by (str): User who initiated the request  
            - service_provider (str): Service provider name
            - service_provider_id (str): Service provider identifier
            - change_type (str): Type of change being made
            - tenant_id (str): Tenant identifier
            - invalid_iccids (list): List of invalid ICCIDs that cannot be processed

    Returns:
        dict: Response object with keys:
            - flag (bool): Indicates success or failure of the bulk change
            - processed (int): Number of successfully processed records
            - remaining (int): Number of records remaining to process
            - message (str): Human-readable status message
            - iccids (list): Original list of ICCIDs processed
            - invalid_iccids (list): List of invalid ICCIDs encountered
            - bulk_change_id (str): ID of the bulk change operation
"""

    logging.info(f"### Recevied data for telegence_bc_edit_usename_cost_center :{data}")
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    change_type = data.get("change_type",'')
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username1= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    provider_parent_name=data.get("parent_provider_name", "")
    # Validate required fields
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_edit_usename_cost_center",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,20)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
           username=change_request_json.get("ContactName", "")
           cost_center=change_request_json.get("CostCenter1", "") 
        logging.info(f"### telegence_bc_edit_usename_cost_center username:{username} cost_center:{cost_center}")
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        ## Prepare headers for API call
        headers = fetch_headers(database, tenant_id, app_id, app_secret)
        headers["Content-Type"] = "application/json-patch+json"
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Final headers: {headers}")
        # Prepare an update dict 
        rev_data=pd.DataFrame()
        revid=None
        update_fields = {}
        successfull_ids = []
        if username:
           update_fields["username"] = username
        if cost_center:
            update_fields["cost_center"]=cost_center
        # Validate MSISDNs
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
                ["id","iccid","msisdn","username","cost_center"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_edit_usename_cost_center and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        costcenter_labels = ["CostCenter1", "CostCenter2", "CostCenter3"]
        
        # Fetch all rev_service_id data for all MSISDNs 
        logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Fetching rev_service_id data for all MSISDNs")
        
        # Get rev_service_id for all MSISDNs in one query
        all_rev_data = database.get_data(
            "rev_service",
            {"number": msisdns, "is_active": True},
            ["number", "rev_service_id"]
        )
        
        # Create a mapping dictionary: msisdn -> rev_service_id
        msisdn_to_revid = {}
        if not all_rev_data.empty:
            msisdn_to_revid = dict(zip(all_rev_data["number"], all_rev_data["rev_service_id"]))
        
        logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Found {len(msisdn_to_revid)} rev_service_id mappings out of {len(msisdns)} MSISDNs")
       
        
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each MSISDN in the batch
                logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    # Get revid from the mapping dictionary instead of querying DB for each MSISDN
                    revid = msisdn_to_revid.get(msisdn)
                    if not revid:
                        logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} No active RevService found for MSISDN: {msisdn}")
                    
                    url = f"{carrier_api_url}/{revid}"
                    def task(msisdn=msisdn):  
                        payload = []
                        # thread_db = DB(tenant_database, **db_config)
                        success = False
                        result = ""
                        status = "API_FAILED"
                        username_index = None
                        costcenter_index = None
                        
                        # Get revid from the mapping dictionary (already have it from above)
                        revid = msisdn_to_revid.get(msisdn)
                        
                        if revid:
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                                    resp = requests.get(
                                        url, headers=headers, timeout=60)
                                    logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Response Text: {result}")
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        response_data = resp.json()
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(f"### telegence_bc_edit_username_cost_center and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                    time.sleep(RETRY_DELAY)
                            if success:
                                label_to_index = {f["label"]: i for i, f in enumerate(response_data["fields"])}
                                username_index = label_to_index.get("User Name")
                                #costcenter_index = next((label_to_index[label] for label in costcenter_labels if label in label_to_index), None)
                                costcenter_index = [
                                        index for label, index in label_to_index.items() if label.startswith("CostCenter")
                                    ]
                                logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Username index: {username_index}, Cost Center index: {costcenter_index} for MSISDN: {msisdn}")
                                    
                            #update the request status
                            if username_index  or costcenter_index:
                                if username_index:
                                    payload.append({
                                        "op": "replace",
                                        "path": f"/fields/{username_index}/value",
                                        "value": username
                                    })

                                if costcenter_index:
                                    payload.append({
                                        "op": "replace",
                                        "path": f"/fields/{costcenter_index}/value",
                                        "value": cost_center
                                    })

                                logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} API Payload: {payload}, URL: {url}")

                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        get_resp = requests.patch(url,json=payload, headers=headers, timeout=60)
                                        api_success = 200 <= get_resp.status_code < 300
                                        api_result = get_resp.text
                                        logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Response Code: {get_resp.status_code}")
                                        logging.info(f"### telegence_bc_edit_username_cost_center and {tenant_name} Response Text: {api_result}")
                                        status = "PROCESSED" if api_success else "API_FAILED"
                                        if api_success:
                                            response_data = get_resp.json()
                                            successfull_ids.append(msisdn)
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        time.sleep(RETRY_DELAY)
                                if api_success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result, 
                                        "modified_by":username1

                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result 
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number":[msisdn]},
                                    )             
                                    #inserting values into revservice product table 
                                rev_service_log=database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"is_active": True},
                                    in_conditions={"msisdn": [msisdn]}
                                )
                                #constracting logs 
                                log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Edit Username/Cost Center via Telegence API",
                                        "request_text": json.dumps(payload),
                                        "has_errors": status == "API_FAILED",
                                        "response_status": "PROCESSED" if api_success else "API_Failed",
                                        "response_text": api_result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                
                                if log:
                                    database.insert_data(log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                                logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Inserting log for Edit Username/Cost Center: {log}") 
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Update AMOP",
                                        "request_text": json.dumps(payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log, "sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                rev_service_log=database.update_dict(
                                            "sim_management_inventory",update_fields,
                                            and_conditions={"is_active": True},
                                            in_conditions={"msisdn": [msisdn]}
                                        )
                                successfull_ids.append(msisdn)

                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number":[msisdn]},
                                    )

                                    #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Edit Username/Cost Center via Telegence API",
                                        "request_text": "Update AMOP",
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log, "sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        else:
                            rev_service_log=database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"is_active": True},
                                    in_conditions={"msisdn": [msisdn]}
                                )
                            successfull_ids.append(msisdn)
                            logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} No RevService ID found for MSISDN: {msisdn},update_fields: {update_fields}")

                            database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number": [msisdn]},
                                    )

                            #constracting logs
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Update AMOP",
                                    "request_text": "Edit Username/Cost Center processed",
                                    "has_errors": False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK",
                                    "error_text": "" ,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log, "sim_management_bulk_change_detailed_logs")
                                logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        return msisdn


                    # Submit the task to the executor
                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Error processing MSISDN: {e}")

              
        if interval and i + batch_size < len(msisdns):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Processed {len(msisdns) - len(remaining)} MSISDNs, {len(remaining)} remaining")
        ## Handle invalid MSISDNs
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":successfull_ids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the API to update device history tables
            try:
                
                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} sync call has started for history table")
                    threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Exception in thread: {e}") 

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Action history URL: {action_history_url}")
            
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username1,
                        "path": "/sim_management_action_history_update",
                        "iccids": [],
                        "msisdns": successfull_ids,
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Edit Username/Cost Center",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "username" if username else "cost_center" ,
                    
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Exception in action history thread: {e}")
    
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_ids:
            logging.info(f"### Invalid MSISDNs found: {invalid_ids}")
            # Log invalid ICCIDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"id": invalid_ids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        logging.info(f"telegence_bc_edit_usename_cost_center and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync call for inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### telegence_bc_edit_usename_cost_center and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f'### telegence_bc_edit_usename_cost_center and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            if successfull_ids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "changed_data": {
                            "msisdn": successfull_ids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_edit_usename_cost_center",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                    data, common_utils_database,
                    action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_edit_usename_cost_center and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
## Activate new service function
def telegence_bc_activate_new_service(data):
    """Activate a new service for the given devices.
       this function performs the following steps:
         - Validates required input values.
            - Establishes DB connections.
            - Fetches API credentials and carrier limits.
            - Builds and sends POST requests per ICCID in parallel with retry logic.
            - Updates status in DB and logs results.
            - Handles invalid ICCIDs and triggers sync API.
    Args:
        data (dict): Input dictionary containing:
            - iccids (list): List of ICCIDs to process.
            - bulk_change_id (str): Unique ID of the bulk change job.
            - changed_data (dict): Contains serviceCharacteristic array.
            - service_provider (str): Carrier/service provider name.
            - change_type (str): Type of operation.
            - created_by (str): User initiating the request.
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant.
            - db_name (str): Database name for the tenant.
            - username (str): Username for error/audit tracking.
            - customer_name (str): Name of the customer.
            - customer_id (str): ID of the customer.
            - role_name (str): Role name for auditing purposes.
            - invalid_iccids (list): Optional invalid ICCIDs before processing.

    Returns:    
        dict: Result object with success flag, count, and error info
    """
    logging.info(f"### Received data for Activate New Service: {data}")
    iccids = data.get("iccids", [])
    #imei=data.get("imei")
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    role = data.get("role_name", "")
    invalid_ids= data.get("invalid_ids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    access_token=data.get("access_token", "")
    integration_id=data.get("integration_id", 6)
    customer_name = data.get("customer_name", "")
    customer_id = data.get("customer_id", "")
    service_provider_id=data.get("service_provider_id",None)
    provider_parent_name=data.get("parent_provider_name", "")
    iccid_ip_map=data.get("iccid_ip_map",{})
    ##start time for processing
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_activate_new_service and {tenant_name} time is {now}")
    start_time=time.time()
    log_entries=[]
    logging.info("Activate new service function called")
    #validating inputs
    required_fields = [ "bulk_change_id", "service_provider", "change_type","iccids"]
    missing = [field for field in required_fields if not data.get(field)]

    if missing:
       return {
        "flag": False,
        "message": f"Missing required fields: {', '.join(missing)}"
    }
    tenant_database = data.get("db_name", "")
    # DB setup
    try: 
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
    except Exception as e:
        logging.exception(f"###telegence_bc_activate_new_service and {tenant_name} Audit logging failed while inserting logs: {e}")

    try:
        # Carrier API details
        try:
            # Get carrier API URL and limits
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
            #app_id, app_secret = fetch_app_details(database, integration_id)
            #logging.info(f"### telegence_bc_activate_new_service and {tenant_name} Fetched App ID {app_id} and Secret for integration ID {integration_id}")
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
       
        # Fetch bulk change rows
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request"]
        )
        rate_plan_name=None
        rate_plan_code=None
        rate_plan_data=pd.DataFrame()
        carrier_rate_plan_data=pd.DataFrame()
        live_progress_percentage_tracker(database, bulk_change_id,20)        # Validate input data
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_activate_new_service",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_activate_new_service and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,25)
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request
        characteristics = change_request_json.get("TelegenceActivationRequest", {}).get("service", {}).get("serviceCharacteristic", [])
        characteristics_dict = {item["name"]: item["value"] for item in characteristics}
        carrier_rate_code = characteristics_dict.get("singleUserCode")
        servicezipcode=characteristics_dict.get("serviceZipCode")
        customer_rate_plan_id = change_request_json.get("CustomerRatePlan")
        billing_account = change_request_json.get("TelegenceActivationRequest", {}).get("billingAccount")
        root = change_request_json.get("TelegenceActivationRequest", {})

        # Billing Account
        billing_account_id = root.get("billingAccount", {}).get("id", "")

        # Related Party (Subscriber)
        related_party = root.get("relatedParty", [])
        subscriber_party = related_party[0] if related_party else {}

        first_name = subscriber_party.get("firstName", "")
        last_name = subscriber_party.get("lastName", "")

        # Address
        address = subscriber_party.get("address", {})
        street_number = address.get("streetNumber", "")
        street_direction = address.get("streetDirection", "")
        street_name = address.get("streetName", "")
        street_type = address.get("streetType", "")
        city = address.get("city", "")
        state = address.get("state", "")
        zip_code = address.get("zipCode", "")

        # Service
        service = root.get("service", {})

        subscriber_number = service.get("subscriberNumber", "")
        status = service.get("status", "")

        # Service Characteristics (list → dict)
        service_characteristics = {
            item.get("name"): item.get("value")
            for item in service.get("serviceCharacteristic", [])
        }
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Extracted service characteristics: {service_characteristics}")
        #service_zip_code = service_characteristics.get("serviceZipCode", "")
        price_plan_code = service_characteristics.get("singleUserCode", "")
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Extracted price plan code: {price_plan_code}")
        equipment_type = service_characteristics.get("equipmentType", "")
        device_technology_type = service_characteristics.get("deviceTechnologyType", "")
        #imei = service_characteristics.get("IMEI", "")
        #sim = service_characteristics.get("sim", "")

        # EXTRACT FEATURE CODES (offeringCode1, offeringCode2, etc.)
        feature_codes_list = []
        for item in characteristics:
            if item.get("name", "").startswith("offeringCode"):
                feature_code = item.get("value")
                if feature_code:
                    cleaned_code = feature_code.strip()
                    if cleaned_code and cleaned_code not in feature_codes_list:
                        feature_codes_list.append(cleaned_code)

        # Convert to comma-separated string
        if feature_codes_list:
            telegence_features = ",".join(feature_codes_list)
            logging.info(
                f"###telegence_bc_activate_new_service and {tenant_name} Extracted feature codes: {telegence_features}"
            )
        else:
            telegence_features = None
            logging.info(
                f"###telegence_bc_activate_new_service and {tenant_name} No feature codes found"
            )
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} and customer_rate_plan_id is {customer_rate_plan_id} and billing_account is {billing_account}")
        if billing_account and "id" in billing_account:
            billing_account_id = billing_account["id"]
        else:
            billing_account_id = None
        ##fetching the foundation account number details
        foundation_account_number=None
        try:
            foundation_account_number=database.get_data('telegence_device',{"billing_account_number":billing_account_id},["foundation_account_number"])["foundation_account_number"].to_list()[0]
        except Exception as e:
            logging.info(f"Exception while fetching the account number{e}")
            foundation_account_number=None
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} foundation_account_number is {foundation_account_number} and billing_account_id is {billing_account_id}")
        # Validate tenant name and get parent tenant ID
        parent_tenant_id = None
        try:
            parent_tenant_id=common_utils_database.get_data('tenant',{"id":tenant_id},["parent_tenant_id"])["parent_tenant_id"].to_list()[0]
        except Exception as e:
            logging.exception(f"Exception while fetching parent_tenant_id{e}")
            parent_tenant_id = None
        # Fetch customer rate plan details
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
        if not rate_plan_data.empty:
            rate_plan_code = rate_plan_data["rate_plan_code"].to_list()[0]
            rate_plan_name = rate_plan_data["rate_plan_name"].to_list()[0]
        carrier_rate_plan_name=None
        carrier_rate_plan_id=None
        if carrier_rate_code:
           carrier_rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrier_rate_code, "is_active": True},
            ["id","friendly_name"]
            )
        if not carrier_rate_plan_data.empty:
            carrier_rate_plan_id = carrier_rate_plan_data["id"].to_list()[0]
            carrier_rate_plan_name=carrier_rate_plan_data["friendly_name"].to_list()[0]
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_requestid=dict(zip(bulk_requests.iccid,bulk_requests.id))
        iccid_to_changerequest=dict(zip(bulk_requests.iccid,bulk_requests.change_request))
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Fetched {iccid_to_changerequest} bulk change requests from the database for activate new service")
        live_progress_percentage_tracker(database, bulk_change_id,30)
        successful_iccids=[]

        # Prepare headers for API request
        headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "client_id": app_id,
            "client_secret": app_secret,
            "source": "product-papi/product",
            "x-trace-id": "a49fd114-c14b-11ea-b3de-0242ac130004",
            "x-transaction-id": "73c427a4-2482-4e64-8cac-ea4ace577890",
            "User-Agent": "PostmanRuntime/7.36.1"
        }
        remaing_iccids=iccids.copy()
        logs=[]
        # Prepare data for insert
        inventory_data = {}
        if carrier_rate_plan_id:
            inventory_data["carrier_rate_plan_id"] = carrier_rate_plan_id
        if carrier_rate_plan_name :
            inventory_data["carrier_rate_plan_name"] = carrier_rate_plan_name
        if customer_rate_plan_id :
            inventory_data["customer_rate_plan_id"] = customer_rate_plan_id
        if rate_plan_name :
            inventory_data["customer_rate_plan_name"] = rate_plan_name
        if servicezipcode:
            inventory_data["service_zip_code"]=servicezipcode
        if telegence_features:
            inventory_data["telegence_features"] = telegence_features    
        
        # ip_details={}
        # sp_data = database.get_data(
        #             "service_provider_apn_pdp_ip",
        #             {"service_provider": service_provider},
        #             ["apn", "pdp", "ip_text", "ip_version", "service_provider"]
        #             )
        # if not sp_data.empty:
        #     logging.info(f"### telegence_bc_activate_new_service and {tenant_name} Fetched APN/PDP/IP details for service provider: {service_provider}")
        #     for _, row in sp_data.iterrows():
        #         ip_range = row['ip_text']  # This should be in the format "172.30.0.0 - 172.30.0.255"
        #         apn = row['apn']
        #         pdp = row['pdp']  
        #         # Add the range and corresponding APN/PDP to the dictionary
        #         ip_details[ip_range] = {"apn": apn, "pdp": pdp}
       # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f" ###telegence_bc_activate_new_service and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        ## Retry settings
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} max retires{MAX_RETRIES}")
        logs = []
        remaining = list(iccids)
        subscriber_number=None
        sim_status=None
        device_status_id=None
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        integration_id=data.get('integration_id',None)
        device_status_data=database.get_data("device_status",{"integration_id":integration_id},["id","display_name"])
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process ICCIDs in batches and in parallel
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for iccid in batch:
                    current_iccid = iccid
                    ip_address = iccid_ip_map.get(current_iccid, None)
                    #apn, pdp = find_apn_pdp(ip_address, ip_details)
                    logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} current_iccid is {current_iccid}")
                    # Step 1: Prepare the API URL and payload
                    url = f"{carrier_api_url}"
                    logging.info(f" ###telegence_bc_activate_new_service and {tenant_name}Processing iccid_to_changerequest for iccid {iccid} and {iccid_to_changerequest}")
                    payload_str=iccid_to_changerequest.get(iccid)
                    logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} Processing ICCID: {iccid} with payload: {payload_str}")
                    # Step 2: Parse the payload string into a dictionary
                    request_payload = json.loads(payload_str)
                    logging.info(f"request_payload is {request_payload} ")
                    service_chars = request_payload.get("TelegenceActivationRequest", {}).get("service", {}).get("serviceCharacteristic", [])
                    imei = None
                    sim = None
                    # Loop through each characteristic to find IMEI and SIM
                    for char in service_chars:
                        if char.get("name") == "IMEI":
                            imei = char.get("value")
                        elif char.get("name") == "sim":
                            sim = char.get("value")
                    #Step 3: Extract the 'Request' part
                    #payload_data = request_payload.get("TelegenceActivationRequest")
                    # if apn and pdp:
                    #     # Append the APN and PDP details to the serviceCharacteristic list
                    #     payload_data['service']['serviceCharacteristic'].append({
                    #         "name": "packetDataProfile", 
                    #         "value": pdp
                    #     })
                    #     payload_data['service']['serviceCharacteristic'].append({
                    #         "name": "accessPointName", 
                    #         "value": apn
                    #     })
                    payload_data={
                        "foundationAccountNumber": foundation_account_number,
                        "billingAccountNumber": billing_account_id,
                        "relatedParty": [
                            {
                            "role": "subscriber",
                            "firstName": first_name,
                            "lastName": last_name,
                            "address": {
                                "addressLine1": f"{street_number},{street_name}",
                                "addressLine2": "",
                                "streetNumber": street_number,
                                "streetDirection": street_direction,
                                "streetName": street_name,
                                "city": city,
                                "state": state,
                                "zipCode": zip_code,
                                "levelType": "FL",
                                "levelValue": "3"
                            }
                            }
                        ],
                        "ratePlanCode": price_plan_code,
                        "serviceZipCode": servicezipcode,
                        "imei": imei,
                        "sim": sim,
                        "technologyType": "LTE"
                    }
                    if telegence_features:
                        payload_data["featureCode"] = telegence_features
                    logging.info(f"Payload is {payload_data} ")
                    telegence_payload=payload_data
                    ##task for activate new service
                    def task(iccid=current_iccid, url=url, telegence_payload=telegence_payload):
                        """
                        Task to Activate New Service:
                        1. POST activation request with retries
                        2. Poll GET for final status/data with retries
                        3. Update DB, log, inventory
                        """ 
                        logging.info(f"task started for iccid{iccid}")
                        success = False
                        api_success=False
                        result = ""
                        status = "API_FAILED"
                        id=None
                        data_json={}
                        subscriber_number = None
                        sim_status = None
                        billing_account_id = None
                        imei_api = None
                        sim = None
                        GET_API_RETRIES=10
                        ##Activation API 
                        for attempt in range(1, GET_API_RETRIES + 1):
                            try:
                                logging.info(f"Attempt {attempt} - URL: {url}")
                                logging.info(
                                    f"url={url}, telegence_payload={telegence_payload!r}, headers={headers}"
                                )
                                resp = requests.post(
                                    url, json=telegence_payload, headers=headers, timeout=60)
                                if resp.status_code == 200:
                                    # Success—no need to retry
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(
                                    f"Attempt {attempt} failed: {result}")
                                time.sleep(RETRY_DELAY)
                        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} Response Code: {resp.status_code}")
                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Response TEXT: {resp.text}")
                        success = 200 <= resp.status_code < 300
                        result = resp.text
                        pending_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_requestid.get(iccid),
                            "log_entry_description": "Update Telegence Subscriber: Telegence API",
                            "request_text": json.dumps(telegence_payload),
                            "has_errors": status == "PENDING",
                            "response_status": "PENDING" if success else "API_Failed",
                            "response_text": json.dumps(result),
                            "error_text": "" if status == "PROCESSED" else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
        
                        if pending_log:
                            database.insert_data(pending_log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(pending_log, "sim_management_bulk_change_detailed_logs") 
                        status = "PROCESSED" if success else "API_FAILED"
                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} status is {status}")
                        if success:
                            response_data = resp.json()
                            if isinstance(response_data, dict):
                                id = response_data.get("serviceActivation", {}).get("id", "")  
                        #connecting carrier Api again to get the subscriber number and sim status
                        if success and id:
                            try:
                                logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Waiting 2 seconds before second API for {iccid}")
                                time.sleep(20)
                                api_url = f"{url}/{id}"
                                api_success = False
                                headers_1 = {
                                        "accept": "application/json",
                                        "client_id": app_id,
                                        "client_secret": app_secret,
                                        "User-Agent": "PostmanRuntime/7.36.1"
                                    }
                                logging.info(f"get api url is {api_url} and headers_1 is {headers_1} ")
                                ##attempting here when status is not found
                                for attempt in range(1, MAX_RETRIES + 1):
                                    logging.info(f"[{iccid}] Poll attempt #{attempt}")
                                    try:
                                        resp = requests.get(api_url, headers=headers_1, timeout=60)
                                        data_json = resp.json()
                                        logging.info(f"[{iccid}] ###telegence_bc_activate_new_service and {tenant_name} GET response data: {data_json}")

                                        if isinstance(data_json, dict) and data_json:
                                            #svc = data_json[0].get("status", {})
                                            sim_status = data_json.get("status", "")
                                            logging.info(f"[{iccid}] sim_status is {sim_status} ")

                                            ##Based on the sim status will be triggerd
                                            if sim_status == "Rejected":
                                                ##Rejected sim will be automatically stopped
                                                api_success=False
                                                logging.error(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Service rejected; stopping polling")
                                                break
                                            if sim_status == "Error":
                                                ##Rejected sim will be automatically stopped
                                                api_success=False
                                                logging.error(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Service failed; stopping polling")
                                                break

                                            elif not sim_status:
                                                ##sim is in progress API will be trigged after 2 mins
                                                api_success=False
                                                logging.info(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Empty status, retry in 2 mins")
                                                time.sleep(60)
                                                continue

                                            elif sim_status in ("Active", "Pending"):
                                                ##sim got Activated 
                                                if sim_status == "Pending":
                                                    sim_status = "Active"
                                                subscriber_number = data_json.get("subscriberNumber")
                                                billing_account_id = data_json.get("billingAccountNumber")
                                                imei_api = data_json.get("imei")
                                                if subscriber_number and billing_account_id and imei_api:
                                                    api_success = True
                                                    if "display_name" in device_status_data.columns and "id" in device_status_data.columns:
                                                        matches = device_status_data.loc[
                                                            device_status_data["display_name"] == sim_status,
                                                            "id"
                                                        ]
                                                        if not matches.empty:
                                                            device_status_id = matches.iloc[0]
                                                            device_status_id=int(device_status_id)
                                                    logging.info(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} All required data found; stopping polling and device_status_id {device_status_id}")
                                                    break
                                                else:
                                                    logging.info(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Active but missing fields, retry in 2 mins")
                                                    time.sleep(60)
                                                    continue
                                            else:
                                                logging.info(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} Active but missing fields, retry in 2 mins")
                                                time.sleep(60)
                                                continue
                                        else:
                                            logging.info(f"[{iccid}] ###telegence_bc_activate_new_service and {tenant_name} Unexpected GET response; retry in 2 mins")
                                            time.sleep(60)

                                    except Exception as e:
                                        logging.warning(f"[{iccid}]###telegence_bc_activate_new_service and {tenant_name} GET attempt {attempt} failed: {e}")
                                        time.sleep(60)
                                ##based on the api_success or failure the API will be triggered
                                if api_success:
                                    status = "PROCESSED"
                                    success = True
                                else:
                                    status = "API_FAILED"
                                    success = False
                            except Exception as e:
                                success = False
                                status = "API_EXCEPTION"
                                logging.error(f"###telegence_bc_activate_new_service and {tenant_name} Second API failed for {iccid}: {e}")

                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} api_result for {iccid}: {data_json}")
                        
                        if success and subscriber_number:
                            update_data = {
                            "status": status,
                            "has_errors": False,
                            "is_processed": True,
                            "processed_date": now,
                            "subscriber_number":subscriber_number,
                            "status_details":json.dumps(data_json) 
                            }
                        else:
                            update_data = {
                            "status": status,
                            "has_errors": True,
                            "is_processed": True,
                            "processed_date": now,
                            "status_details":json.dumps(data_json) 
                            }
                        try:
                            if success and subscriber_number:
                                update_data['status_details']=json.dumps(data_json)
                            else:
                                error_msg = data_json.get("service", {}).get("error", "")
                                update_data['status_details'] = f"Telegence: Device Activation rejected for SIM: {iccid} — {error_msg}"
                        except Exception as e:
                            logging.exception(f"###telegence_bc_activate_new_service and {tenant_name} Exception occured while storing status details{e}")
                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} update_data is {update_data}")
                    #update the request status
                        database.update_dict(
                        "sim_management_bulk_change_request",
                        update_data,
                        and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id},
                        )
                       
                        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} success in activation {success} and  subscribernumber {subscriber_number}")
                        # Only update inventory if API succeeded
                        if success and subscriber_number:
                            try:
                                successful_iccids.append(iccid)
                            except Exception as e:
                                logging.exception(f"Failed to append the iccid")
                            inventory_data['date_activated']=now
                            inventory_data['modified_by']=created_by
                            if tenant_id and parent_tenant_id:
                                # Insert for parent tenant
                                parent_inventory = inventory_data.copy()
                                parent_inventory.update({
                                    "iccid": iccid,
                                    "msisdn": subscriber_number,
                                    "imei": imei_api,
                                    "billing_account_number": billing_account_id,
                                    "tenant_id": parent_tenant_id,
                                    "is_active": True,
                                    "is_deleted":False,
                                    "tenant_is_active":True,
                                    "tenant_is_deleted":False,
                                    "service_provider_is_active":True,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "service_provider_display_name": service_provider,
                                    "sim_status": sim_status,
                                    "service_provider_id":service_provider_id,
                                    "device_status_id":device_status_id,
                                    "foundation_account_number":foundation_account_number,
                                    "sub_tenant_carrier_rate_plan_name": rate_plan_name,
                                    "sub_tenant_carrier_rate_plan_name_id":customer_rate_plan_id,
                                })
                                database.insert_data(parent_inventory, "sim_management_inventory")
                            ###insert for actual tenanta
                            inventory_data.update({
                                    "iccid": iccid,
                                        "msisdn": subscriber_number,
                                        "imei": imei_api,
                                        "billing_account_number": billing_account_id,
                                        "tenant_id": tenant_id,
                                        "is_active": True,
                                        "is_deleted":False,
                                        "tenant_is_active":True,
                                        "tenant_is_deleted":False,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "service_provider_display_name": service_provider,                               
                                        "sim_status": sim_status,
                                        "service_provider_id":service_provider_id,
                                        "device_status_id":device_status_id,
                                        "foundation_account_number":foundation_account_number,
                                        "service_provider_is_active":True
                                    
                                    })
                            database.insert_data(inventory_data,"sim_management_inventory")
                        # Constructing the log entry for GET API
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_requestid.get(iccid),
                            "log_entry_description": "Update Telegence Subscriber: Telegence API",
                            "request_text": json.dumps(telegence_payload),
                            "has_errors": status == "API_FAILED",
                            "response_status": "PROCESSED" if success else "API_Failed",
                            "response_text":json.dumps(data_json) if data_json else "Unable to Process the Activation",
                            "error_text": "" ,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
            
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log, "sim_management_bulk_change_detailed_logs") 
                        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} current iccid processing is : {iccid}")
                        return iccid
                    futures[executor.submit(task)] = current_iccid
                # Then process results as they complete
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} removing the iccid {iccid}")
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"###telegence_bc_activate_new_service and {tenant_name} Error processing ICCID")


        # After processing a batch, pause before the next batch if more ICCIDs remain 
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
        live_progress_percentage_tracker(database, bulk_change_id,80)
        #preare the payload for history table
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "change_type":change_type,
                                    "iccids": successful_iccids,
                                    "msisdns":[],
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        # Call the history table API
        try:
            if successful_iccids:
             logging.info(f"### telegence_bc_activate_new_service and {tenant_name} sync call has started for history table")
             threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### telegence_bc_activate_new_service and {tenant_name} Exception in thread: {e}") 
      
        #  Update the status of the bulk change request
        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} bulk_change_id{bulk_change_id} and time is now{now}")
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "status": "PROCESSED",
                    "processed_date": now
                },
                {'id': bulk_change_id}
            )
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} proccessed %d iccids,%d remaining",len(iccids) - len(remaing_iccids), len(remaing_iccids))
        
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f" ###telegence_bc_activate_new_service and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaing_iccids), "remaining": len(remaing_iccids),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_ids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        '''
        SYNC CALL for Activate New Service
        '''
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'###telegence_bc_activate_new_service and {tenant_name} sync call has started for telegence_bc_activate_new_service')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f'###telegence_bc_activate_new_service and {tenant_name} sync call has ended')
        except Exception as e:
            logging.exception(f"Exception in thread is {e}")
        # Return success
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Total time taken for processing: %s seconds", time.time() - start_time)
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,95)
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_ids,
            "bulk_change_id": bulk_change_id
        }

        # Attempt to audit the action
        try:
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_activate_new_service",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for  devices.{bulk_change_id}",
                "request_received_at": now,
            }
        
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        '''
        Assign Customer logic to assign the customers when activation is happened
        '''
        ##function to call the assign customer logic
        try:
           logging.info(f"###telegence_bc_activate_new_service and {tenant_name} Successfull iccids are {successful_iccids}")
           # Check if customer_id and customer_name are present
           if customer_id and customer_name and successful_iccids:
                logging.info(f"### Calling assign customer logic for bulk change request: {bulk_change_id} and successful iccids {successful_iccids}")
                telegence_bulk_change_assign_customer_wrapper(data,database,common_utils_database,now,successful_iccids,tenant_id)
                logging.info(f"### Assign customer logic completed for bulk change request: {bulk_change_id}")
        except Exception as e:
            logging.exception(f" ###telegence_bc_activate_new_service and {tenant_name} Exception while doing the assign customer logic")
        ##return the response
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"###telegence_bc_activate_new_service and {tenant_name} Error during bulk change processing: %s", str(e))
        error_message = f"###telegence_bc_activate_new_service and {tenant_name} during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "invalid_msisdns": invalid_ids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
 
        return response
    
def telegence_bulk_change_assign_customer_wrapper(data, database, common_utils_database, now,successful_iccids,tenant_id):
    
    """
    Handles the 'Assign Customer' bulk change operation by preparing request data 
    and invoking the SIM management API to sync changes.

    Args:
        data (dict): Input data for the operation (may include context or parameters).
        database (object): Database connection or handler object.
        common_utils_database (module/object): Common utilities for database operations.
        bulk_change_id_activate_new (str/int): Identifier for the bulk change operation context.
        access_token (str): Access token used for authentication with the API.
        iccids (list): List of ICCIDs to process in the bulk change.
        role_name (str): Role of the user initiating the request.
        tenant_name (str): Name of the tenant performing the operation.

    Process:
        - Constructs a request payload including change data and metadata.
        - Logs each step and relevant values for observability.
        - Makes a POST request to the SIM management API for bulk update.
        - Parses the response and handles any errors gracefully.
        - Extracts and logs the `bulk_change_id` from the API response.

    Returns:
        None. (Side-effects include API calls and logs; `bulk_change_id` is printed and logged.)
    """
    logging.info(f"Request Data for wrapper function is {data}")
    
    iccids = data.get("iccids", [])
    bulk_change_id_new = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    username= data.get("username", "")
    role_name = data.get("role_name", "")
    tenant_name = data.get("tenant_name", "")
    access_token=data.get("access_token", "")
    customer_id= data.get("customer_id", "")
    customer_name= data.get("customer_name", "")
    effective_date = data.get("effective_date", None)
    request_received_at = data.get("request_received_at","")
    request_data={}
    changed_data={}
    tenant_database=data.get('db_name','')
    logging.info(f"API call flag is false {bulk_change_id_new}")
    request_data['tenant_name']=tenant_name
    request_data["path"]="/update_bulk_change_data"
    request_data["switch_user_2_0"]=True
    request_data["role_name"] = role_name
    request_data["request_received_at"]=request_received_at
    request_data["access_token"] = access_token
    request_data["bulk_change_20"] = True
    request_data["db_name"]=tenant_database
    request_data["sessionID"]=None
    logging.info(f"adding service provider {service_provider}")
    request_data["service_provider"]=service_provider
    successful_msisdns = []

    try:
        msisdn_df = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": successful_iccids,"tenant_id": tenant_id,"service_provider_display_name":service_provider},
            ["msisdn"]
        )
        if not msisdn_df.empty:
            successful_msisdns = msisdn_df["msisdn"].tolist()
            logging.info(f"###telegence_bulk_change_assign_customer_wrapper Successfully got the msisdn list {successful_iccids}")
    except Exception as e:
        logging.exception(f"###telegence_bulk_change_assign_customer_wrapper and {tenant_name} Exception while getting the msisdn list")

    request_data["change_type"]="Assign Customer"
    request_data["created_by"]=created_by
    request_data["iccids"]=successful_msisdns
    changed_data["Number"]=""
    changed_data["ICCID"]=""
    changed_data["CreateRevService"]=False
    changed_data["IntegrationAuthenticationId"]=""
    changed_data["AddCarrierRatePlan"]=False
    changed_data["CarrierRatePlan"]=None
    changed_data["CommPlan"]=""
    changed_data["UseAgentAccount"]=False
    changed_data["JasperDeviceID"]=""
    changed_data["SiteId"]=None
    changed_data["AddCustomerRatePlan"]=False
    changed_data["CustomerRatePlan"]=None
    changed_data["CustomerRatePool"]=None
    changed_data["DeviceId"]=None
    changed_data["RevCustomerId"]=f'{customer_name} -- {customer_id}'
    changed_data["ProviderId"]=""
    changed_data["ServiceTypeId"]=""
    changed_data["RevProductId"]=[]
    changed_data["RevPackageId"]=""
    changed_data["RateList"]=[]
    changed_data["Prorate"]=False
    changed_data["useCarrierActivation"]=False
    changed_data["Description"]=""
    changed_data["EffectiveDate"]=effective_date
    changed_data["ActivatedDate"]=None
    changed_data["UsagePlanGroupId"]=None
    request_data["changed_data"]=changed_data
    # request_data=json.dumps(request_data)
    logging.info(f"final request data got is {bulk_change_id_new} {request_data}")

    try:
        try:
            '''
            This code is used to call the run db script using API Call so that the sync will be called
            '''
            fn_call=False
            # Prepare the API URL and payload
            api_url=os.environ["SIMMANAGEMENTREQUESTURL"]
            api_payload = {"data": request_data}
            logging.info(f"### request data here is {request_data}")
            logging.info(f"### BULK Change  API Payload is :{api_payload}")

            response = requests.post(api_url, json=api_payload)
            response_json = response.json()
            # Parse the inner body string (if needed)
            body = response_json.get("body")
            if isinstance(body, str):
                response_json = json.loads(body)
            else:
                response_json = body  # if it's already a dict

            logging.info(f"### BULK Change  API response: {response_json}")

            if response.status_code in (200, 504):
                current_timestamp = now
                logging.info(f" Update bulk Change data API call successful. Data sync completed at {current_timestamp}")
            else:
                logging.error(f"Update bulk Change data API sync call failed with status code: {response.status_code} and sync message is: {response.text}")

            # Extract bulk_change_id
            bulk_change_id = response_json.get("bulkchange_id", {}).get("id")
            request_data=response_json.get('data')
        except Exception as exception:
            logging.error(f"###run_db_script Error occurred while calling the sync API: {exception}")
            bulk_change_id = None
            request_data={}
        # Check if bulk_change_id is found in the response
        if bulk_change_id is None:
            fn_call=False
            logging.info(f"bulk_change_id not found in response.This is some issue in the update bulk change data")
        else:
            fn_call=True
            logging.info(f"bulk_change_id: {bulk_change_id}")
        logging.info(f"update_bulk_change_data response is {bulk_change_id} and bulk change if for assign customer is {bulk_change_id}")
        logging.info(f"return dict is {bulk_change_id}")
        # If bulk_change_id is found, proceed with the API call
        if fn_call:
            try:
                # Prepare the API URL and payload for the bulk change processor for assign customer
                api_url = os.environ["BULKCHANGEREQUESTURL"]
                
                api_payload = {
                            "data": {
                            "bulk_change_id": bulk_change_id,
                            "db_name": tenant_database,
                            "path": "/bulk_change_processor",
                            "request_received_at": now,
                            "role_name": role_name,
                            "tenant_name": tenant_name,
                            "service_provider": service_provider,
                            "iccids": successful_iccids,
                            "change_type": "Assign Customer",
                            "access_token": access_token,

                            }
                        }
                #call the API to process the bulk change request
                response = requests.post(api_url, json=api_payload)
                response_json = response.json()
                logging.info(f"bulk Change processor API response: {response_json}")
                if response.status_code in (200, 504):
                    current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    logging.info(f" bulk Change proccessor data API call successful with response{response.text}. Data proccess completed at {current_timestamp}")
                else:
                    logging.error(f"bulk Change proccessor data API  call failed with status code: {response.status_code} and  message is: {response.text}")

            except Exception as e:
                logging.error(f"Error in telegence_bc_assign_customer_wrapper: {e}")
            response = {
                "flag": True,
                "message": response.text,
                "iccids": iccids,
                "bulk_change_id": bulk_change_id
            }
        try:
            end_time = time.time()
            time_consumed = end_time - now 
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_assign_customer_wrapper",
                "created_by": username,
                "status": response,
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for  devices.{bulk_change_id}",
                "request_received_at": now,
            }
        
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
             
    except Exception as e:
        logging.error(f"Error in update_bulk_change_data: {e}")
        logging.exception(f"### Error during bulk change processing: %s", str(e))
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "bulk_change_id": bulk_change_id
        }
       
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
        return response
    
    

## Assign customer function
def decode_password(encoded_pwd: str) -> str:
    """
    Decode the stored password. Replace with your actual decode logic.
    """
    # Example: if it was base64-encoded in the DB:
    return base64.b64decode(encoded_pwd).decode("utf-8")

def decode_token(encoded_token: str) -> str:
    """
    Decode the stored token_value. Replace with your actual decode logic.
    """
    return base64.b64decode(encoded_token).decode("utf-8")

def fetch_headers(database,tenant_id,app_id,app_secret):
    """Fetch and prepare headers for Telegence API requests.
    This function retrieves the necessary authentication details from the database,
    decodes them, and constructs the headers required for API requests.
    Args:

        database (object): Database connection or handler object.
        tenant_id (int): The tenant ID to fetch the integration authentication details.
    Returns:
        dict: Headers containing 'Authorization' and 'Ocp-Apim-Subscription-Key'.
    """
    try:
        rev_io_data_query=f'''SELECT username,password,token_value FROM public.integration_authentication
        where integration_id in (select id from integration where name='Rev.IO'
        ) and tenant_id={tenant_id}'''
        rev_io_dataframe=database.execute_query(rev_io_data_query,True)
        revio_username = rev_io_dataframe["username"].to_list()[0]
        encoded_pwd = rev_io_dataframe["password"].to_list()[0]
        encoded_token = rev_io_dataframe["token_value"].to_list()[0]
        password = decode_password(encoded_pwd)
        token_value = decode_token(encoded_token)
        # 3. Re-encode username:password into Basic
        user_pass = f"{revio_username}:{password}"
        # base64 encode
        b64 = base64.b64encode(user_pass.encode("utf-8")).decode("utf-8")
        rev_app_id = f"Basic {b64}"

        # 4. app_secret is the decoded token_value
        rev_app_secret = token_value

        headers = {
            "Authorization": rev_app_id,
            "Ocp-Apim-Subscription-Key": rev_app_secret,
        }  

        return headers
    except Exception as e:
        logging.error(f"### fetch_headers Error occurred while fetching headers: {e}")
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }  
        return headers


def decode_base64(encoded_str: str) -> bytes:
    try:
        return base64.b64decode(encoded_str)
    except Exception as e:
        logging.error(f"Base64 decoding failed: {e}")
        return None

def bytes_to_str_safe(b: bytes, encodings=('utf-8','latin-1')) -> str:
    if b is None:
        return None
    for enc in encodings:
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    # fallback: represent as hex so you can see the raw bytes
    return b.hex()

def fetch_app_details(database, integration_id):
    try:
        query = f"""SELECT username, password 
                    FROM public.integration_authentication
                    WHERE integration_id = {integration_id}"""
        df = database.execute_query(query, True)
        app_id = df["username"].to_list()[0]
        encoded_app_secret = df["password"].to_list()[0]
        raw_app_secret = decode_base64(encoded_app_secret)
        app_secret = bytes_to_str_safe(raw_app_secret)
        return app_id, app_secret

    except Exception as e:
        logging.error(f"### fetch_app_details Error occurred while fetching headers: {e}")
        return None, None
def ip_to_int(ip):
    return int(ipaddress.IPv4Address(ip))
# Function to find APN and PDP for a given IP address
def find_apn_pdp(ip_address, ip_details):
    try:
        logging.info(f"Checking IP: {ip_address}")
        
        # Iterate over the ip_details dictionary to check the IP ranges
        for ip_range, details in ip_details.items():
            apn = details["apn"]
            pdp = details["pdp"]
            
            # Split the range into start and end IPs
            ip_start, ip_end = ip_range.split(' - ')
            
            # Convert the start and end IP range into integer format
            ip_start_int = ip_to_int(ip_start)
            ip_end_int = ip_to_int(ip_end)
            
            # Convert the input IP address to integer format
            ip_address_int = ip_to_int(ip_address)
            
            # Check if the input IP address falls within the range
            if ip_start_int <= ip_address_int <= ip_end_int:
                logging.info(f"IP {ip_address} found in range {ip_range} - APN: {apn}, PDP: {pdp}")
                return apn, pdp
        
        # If IP is not found in any range
        logging.info(f"IP {ip_address} not found in any range")
        return None, None

    except Exception as e:
        logging.error(f"Error occurred while checking IP {ip_address} - {e}")
        return None, None


## Assign customer function
def telegence_bc_assign_customer(data):
    """Assign a customer to the selected devices or services.
    This function processes a list of iccids and assign a customer account with the iccids in the Telegence system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - ICCIDs (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Telegence API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for assign customer: %s", data)
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    if msisdns:
        msisdns = list(set(msisdns))
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    invalid_msisdns=data.get("invalid_msisdns",[])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    source=data.get("source","")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    provider_parent_name=data.get("parent_provider_name", "")
    # Initialize for log entries
    log_entries = []
    rev_service_type_id=None
    service_type_id=None
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###telegence_bc_assign_customer and {tenant_name} time is {now}")

    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### telegence_bc_assign_customer and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
            logging.info(f"### telegence_bc_assign_customer and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}


        # Fetch bulk change rows
       
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request","subscriber_number"]
        )
        # Validate input data 
       
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            # Rename column
            bulk_requests = bulk_requests.rename(columns={"subscriber_number": "msisdn"})
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_assign_customer",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        logging.info(f"change_request_json is {change_request_json}")
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        rev_service_type_id=change_request_json.get("ServiceTypeId","")
        if rev_service_type_id:
            service_type_data=database.get_data(
                    "rev_service_type",
                    {"service_type_id": rev_service_type_id, "is_active": True},
                    ["id"]
                )
            if not service_type_data.empty:
                service_type_id = service_type_data["id"].to_list()[0]
            else:
                service_type_id = None
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} service_type_id is {service_type_id}")
        effective_date=change_request_json.get("EffectiveDate","")
        generate_proration=change_request_json.get("Prorate",None)
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[])
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate_list= change_request_json.get("RateList", [])
        revpackageid=change_request_json.get("RevPackageId", None)
        site_id=change_request_json.get("SiteId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
        plan_mb=None
        customer_data=pd.DataFrame()
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name","plan_mb"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb=rate_plan_data["plan_mb"].to_list()[0]
        if customer_rate_pool_id and customer_rate_pool_id != "No options":
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer or site_id:
            if rev_customer:
                # Use rev_customer if provided
                customer_data = database.get_data(
                    "customers",
                    {"customer_name": rev_customer, "is_active": True,"tenant_id": tenant_id},
                    ["id", "customer_name"]
                )
            elif site_id:
                # Fallback: use site_id as customer_name when rev_customer is absent
                customer_data = database.get_data(
                    "customers",
                    {"id": site_id, "is_active": True,"tenant_id": tenant_id},
                    ["id", "customer_name"]
                )
                if not customer_data.empty:
                    customer_name=customer_data["customer_name"].to_list()[0]
                    rev_dataframe = database.get_data(
                        "revcustomer",
                        {"customer_name": customer_name, "is_active": True,"tenant_id": tenant_id},
                        ["customer_name", "rev_customer_id","id"]
                    )
                    if not rev_dataframe.empty:
                        rev_customer = rev_dataframe["customer_name"].to_list()[0]
                        rev_customer_uuid = rev_dataframe["id"].to_list()[0]
                        rev_customer_id = rev_dataframe["rev_customer_id"].to_list()[0]

            else:
                customer_data = pd.DataFrame()
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {}
        fields_to_update = []
        if customer_rate_plan_id and customer_rate_plan:
            update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
            fields_to_update.extend(["customer_rate_plan_id","sub_tenant_carrier_rate_plan_name","sub_tenant_carrier_rate_plan_name_id"])
        if not customer_rate_pool_id or str(customer_rate_pool_id)=="" :
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(customer_rate_pool_id) != "-1":  
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
            fields_to_update.extend(["customer_rate_pool_id"])
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
            update_fields["account_number"]=rev_customer_id
            fields_to_update.extend(["account_number"])
        if effective_date:
            update_fields["effective_date"] = effective_date
        update_fields["modified_by"] = username 
        
        if plan_mb is not None:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        # if device_id:
        #     update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        if customer_id:
            fields_to_update.extend(["customer_id"])
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = fetch_headers(database,tenant_id,app_id,app_secret)
        logging.info(f"###telegence_bc_assign_customer and {tenant_name} Headers prepared for API call{headers}")
        # headers = {
        #     "Authorization": app_id,
        #     "Ocp-Apim-Subscription-Key": app_secret,
        # }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        # Validate iccids
        remaining = msisdns.copy()
        logs = []
        successful_msisdns = []
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"###telegence_bc_assign_customer and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_name"]
            ).to_dict(orient="records")
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking msisdn and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of ICCIDs
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of iccids
                batch = msisdns[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f"### telegence_bc_assign_customer and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for msisdn in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Processing ICCID: {msisdn}")
                    #task function
                    def task(msisdn=msisdn):
                        """ 1. If CreateRevService is True:
                            - Step 1: Call API to create RevService (POST with retries)
                            - Step 2: On success, extract RevService ID from response
                            - Step 3: Use RevService ID to create Service Product (POST)
                        
                           2. If CreateRevService is False:
                            - Skip RevService creation and directly insert into DB"""
                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Task started for MSISDN: {msisdn}")
                        payload_str = msisdn_to_changerequest.get(msisdn)
                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Payload for MSISDN {msisdn}: {payload_str}")
                        request_payload = json.loads(payload_str)
                        service_number=request_payload.get('Number')
                        iccid_from_request=request_payload.get('ICCID')
                        #extract the create rev service flag
                        rev_service = request_payload.get("CreateRevService", False)
                        # Build payloads for all APIs
                        rev_api_payload = {
                            "customer_id": rev_customer_id,
                            "provider_id": provider_id,
                            "number2":iccid_from_request,
                            "service_type_id": rev_service_type_id,
                            "number": service_number,
                            "activated_date": activated_date,

                        }
                        product_api_payload={
                            "CustomerId": rev_customer_id,
                            "service_type_id": rev_service_type_id,
                            "number": service_number,
                            "effective_date": effective_date,
                            "activated_date": activated_date,
                            }
                        if revpackageid:
                            product_api_payload.update({"revpackageid": revpackageid})
                        else:
                            product_api_payload.update({"RevProductIdList": revproductidlist,"RateList": rate_list,"UsagePlanGroupId": usageplangroupid})
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                        productid = None
                        rev_service_log=False
                        try:
                            if rev_service:
                                # Step 1:  First API Call to create the revservice
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        logging.info(f"###telegence_bc_assign_customer and {tenant_name} Attempt {attempt} - URL: {url}, Payload: {rev_api_payload}")
                                        
                                        resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                        success = 200 <= resp.status_code < 300
                                        result = resp.text
                                        logging.info(f"###telegence_bc_assign_customer and {tenant_name} Response Code: {resp.status_code}")
                                        logging.info(f"###telegence_bc_assign_customer and {tenant_name} Response Text: {result}")
                                        status = "PROCESSED" if success else "API_Failed"
                                        if success:
                                            try:
                                                response_data = resp.json()
                                                id = response_data.get("id")
                                                successful_msisdns.append(msisdn)
                                            except Exception:
                                                id = None
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Exception in API call: {e}")
                                        time.sleep(RETRY_DELAY) 
                                if success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result    
                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number": [msisdn]},
                                    )             
                                if success:  
                                    #inserting values in rev service 
                                    rev_data={
                                    "rev_customer_id":rev_customer_uuid,
                                    "number":service_number,
                                    "rev_service_id":id,
                                    "activated_date":activated_date,
                                    "is_active":True,
                                    "integration_authentication_id":integration_authentication_id,
                                    "rev_provider_id":rev_provider_id,
                                    "rev_service_type_id":service_type_id
                                    }
                                    rev_insert_id=database.insert_data(rev_data,"rev_service")
                                    if rev_insert_id:
                                        update_fields["rev_service_id"]=rev_insert_id
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} update_fields: {update_fields}")
                                    #updating inventory table
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"msisdn": [msisdn]}
                                    )
                                # Inserting logs based on api result
                                rev_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Create Rev.io Service: Rev.io API",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": status == "PROCESSED",
                                        "response_status": "PROCESSED" if success else "API_Failed",
                                        "response_text": result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                database.insert_data(rev_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(rev_log,"sim_management_bulk_change_detailed_logs") 
                                logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for rev service creation: {rev_log}")
                                #inserting logs after updating inventory table
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                                # Step 2:  Second API Call
                                logging.info(f"### telegence_bc_assign_customer and {tenant_name} Creating Rev.io Service Product for ICCID: {msisdn} with ID: {id}")
                                if id:
                                    # Multiple API calls for each product & rate
                                    for product_id, rate in zip(revproductidlist, rate_list):
                                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Creating product_id {product_id} with rate {rate} for service_id {id}")
                                        if not product_id:
                                            continue  # Skip invalid product IDs

                                        # Build payload for each product
                                        product_api_payload_single = {
                                            "CustomerId": rev_customer_id,
                                            "service_type_id": rev_service_type_id,
                                            "number": service_number,
                                            "effective_date": effective_date,
                                            "activated_date": activated_date,
                                            "product_id": product_id,
                                            "rate": rate,
                                            "service_id": id
                                        }
                                        if generate_proration:
                                            product_api_payload_single["generate_proration"] = str(generate_proration).lower()  # "true" or "false"

                                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Product API Payload: {product_api_payload_single}, URL: {alternative_api_url}")

                                        for attempt in range(1, MAX_RETRIES + 1):
                                            try:
                                                get_resp = requests.post(alternative_api_url, json=product_api_payload_single, headers=headers, timeout=60)
                                                api_success = 200 <= get_resp.status_code < 300
                                                api_result = get_resp.text
                                                logging.info(f"### Response Code: {get_resp.status_code}")
                                                logging.info(f"### Response Text: {api_result}")

                                                if api_success:
                                                    response_data = get_resp.json()
                                                    productid = response_data.get("id")
                                                    break
                                            except Exception as e:
                                                logging.info(f"API exception on attempt {attempt}: {str(e)}")
                                                time.sleep(RETRY_DELAY)

                                        if api_success:
                                            product_record = {
                                                "service_product_id": productid,
                                                "customer_id": rev_customer_id,
                                                "service_id": id,
                                                "description": description,
                                                "activated_date": activated_date,
                                                "status": "ACTIVE",
                                                "created_by": created_by,
                                                "created_date": now,
                                                "is_active": True,
                                                "is_deleted": False,
                                                "integration_authentication_id": integration_authentication_id,
                                                "product_id": product_id,
                                                "rate": rate
                                            }

                                            database.insert_data(product_record, "rev_service_product")
                                            logging.info(f"Inserted rev_service_product with product_id {product_id}, rate {rate} for tenant {tenant_name}")
                                        #constracting logs 
                                        log = {
                                                "bulk_change_id": bulk_change_id,
                                                "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                                "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                                "request_text": json.dumps(product_api_payload_single),
                                                "has_errors": status == "API_FAILED",
                                                "response_status": "PROCESSED" if api_success else "API_Failed",
                                                "response_text": api_result,
                                                "error_text": "" if status == "PROCESSED" else result,
                                                "processed_date": now,
                                                "processed_by": created_by,
                                                "created_by": created_by,
                                                "created_date": now,
                                                "is_deleted": False,
                                                "is_active": True
                                            }
                        
                                        if log:
                                            database.insert_data(log,"sim_management_bulk_change_log")
                                            #  insert the log entries into detailed logs table
                                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                                                                        
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for rev service product creation: {product_data} and update fields are {update_fields}")
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"msisdn": [msisdn]}
                                    )
                                    try:
                                        # Preparing fields for sub-tenant update
                                        sub_tenant_update = {}
                                        if "customer_rate_plan_name" in update_fields and "customer_rate_plan_id" in update_fields:
                                            sub_tenant_update["sub_tenant_carrier_rate_plan_name"] = update_fields["customer_rate_plan_name"]
                                            sub_tenant_update["sub_tenant_customer_rate_plan_name"] = update_fields["customer_rate_plan_id"]
                                            sub_tenant_update["sub_tenant_carrier_rate_plan_name_id"] = update_fields["customer_rate_plan_id"]
                                            database.update_dict(
                                                "sim_management_inventory",
                                                sub_tenant_update,
                                                and_conditions={"is_active": True},
                                                in_conditions={"msisdn": [msisdn]},
                                            )
                                    except Exception as e:
                                        logging.exception("Error updating sub-tenant rate plan fields for SIM management inventory")
                                    
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for product creation: {log}") 
                                    if rev_service_log:
                                        data_log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                            "log_entry_description": "Create Rev.io Service: Update AMOP",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors":False,
                                            "response_status": "PROCESSED",
                                            "response_text": "OK" ,
                                            "error_text": "",
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                                        database.insert_data(data_log,"sim_management_bulk_change_log")
                                        #  insert the log entries into detailed logs table
                                        database.insert_data(data_log, "sim_management_bulk_change_detailed_logs")
                                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                #if createrevservice flag false then directly updating values into table
                                rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"msisdn": [msisdn]}
                                    )
                                try:
                                    # Preparing fields for sub-tenant update
                                    sub_tenant_update = {}
                                    if "customer_rate_plan_name" in update_fields and "customer_rate_plan_id" in update_fields:
                                        sub_tenant_update["sub_tenant_carrier_rate_plan_name"] = update_fields["customer_rate_plan_name"]
                                        sub_tenant_update["sub_tenant_customer_rate_plan_name"] = update_fields["customer_rate_plan_id"]
                                        sub_tenant_update["sub_tenant_carrier_rate_plan_name_id"] = update_fields["customer_rate_plan_id"]
                                        database.update_dict(
                                            "sim_management_inventory",
                                            sub_tenant_update,
                                            and_conditions={"is_active": True},
                                            in_conditions={"msisdn": [msisdn]},
                                        )
                                except Exception as e:
                                    logging.exception("Error updating sub-tenant rate plan fields for SIM management inventory")
                                successful_msisdns.append(msisdn)
                                database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK" },
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"subscriber_number": [msisdn]},
                                    )

                                #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")

                        except Exception as e:
                            logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Unexpected error for msisdn {msisdn}: {str(e)}")
                        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Completed processing msisdn: {msisdn}, Success: {success}, ID: {id}, Product ID: {productid}")
                        return msisdn
                    futures[executor.submit(task)] = msisdn
                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.error(f"### telegence_bc_assign_customer and {tenant_name} Error processing msisdn: {e}")
        if interval and i + batch_size < len(msisdns):
            time.sleep(interval)
       
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Processed %d iccids, %d remaining", len(msisdns) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        if successful_msisdns:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":successful_msisdns,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        "fields_updated": fields_to_update,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table update API
            try:
                logging.info(f"### telegence_bc_assign_customer and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "msisdns": successful_msisdns,
                        "iccids": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Assign Customer",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_assign_customer and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Exception in action history thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_msisdns:
            logging.info(f"### telegence_bc_assign_customer and {tenant_name} Invalid misdns found: {invalid_iccids}")
            # Log invalid IDs
            for msisdn in invalid_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Assign customer ",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_msisdns:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": invalid_msisdns},
            )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f"### telegence_bc_assign_customer and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdn": msisdns, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below syncs url is used to sync the 1.0 inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_assign_customer and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### telegence_bc_assign_customer and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        try:
            if successful_msisdns:
                data["msisdns"]=successful_msisdns
                data["CustomerRatePlanId"]=customer_rate_plan
                logging.info(f"### telegence_bc_assign_customer and {tenant_name} sync call for billing  has started with {data}")
                #billing_platform_bulk_change_20_sync(data)
                billing_integration_new(data)
        except Exception as e:
            logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
       
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Assign customer for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.warning(f"### telegence_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Error during bulk change processing: {e}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_assign_customer and {tenant_name} Logging error to DB failed: {e}")
 
        return response
     

def telegence_bc_update_feature(data):
    """ Update Telegence update Features
    This function processes a bulk change request to update Telegence  features.
    It validates inputs, connects to the database, fetches carrier API details,
    processes each MSISDN in batches, and updates the database accordingly.
    """
    logging.info(f"###telegence_bc_update_feature Request Data Recieved is: {data}")
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    integration_id=data.get("integration_id", 6)
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    overwrite=data.get("overwrite",False)
    provider_parent_name=data.get("parent_provider_name", "")
    ## Extracting fields from changed_data
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # Basic validation
    if not bulk_change_id:
        logging.error("Missing required fields: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
    except Exception as e:
        logging.exception(f"### Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
            #app_id, app_secret = fetch_app_details(database, integration_id)
            #logging.info(f"### telegence_bc_update_feature and {tenant_name} Fetched App ID {app_id} and Secret for integration ID {integration_id}")
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        live_progress_percentage_tracker(database, bulk_change_id,20)
        logging.info(f'### carrier_api_url: {carrier_api_url}, carrier_limits: {carrier_limits}')
        # Fetch bulk change rows
        add_codes = []
        remove_codes=[]
        successful_ids = []
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
           if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_update_feature",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_update_feature and {tenant_name} Audit logging failed: {e}")
                return response
        logging.info(f'###telegence_bc_update_feature change_request_json is {change_request_json}')
        for item in change_request_json.get("serviceCharacteristic", []):
            if item.get("name") == "addOfferingCode":
                add_codes.extend(item.get("value", []))
            elif item.get("name") == "removeOfferingCode":
                remove_codes.extend(item.get("value", []))
        logging.info(f"###telegence_bc_update_feature offering codes added are {add_codes}")
        logging.info(f"###telegence_bc_update_feature offering codes removed are {remove_codes}")

        filtered_remove_features = [f for f in remove_codes if f not in add_codes]
        logging.info(f"###telegence_bc_update_feature filtered offering codes to remove are {filtered_remove_features}")
        ## Prepare headers for API call
        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "page-size": "100",
            "current-page": "0",
            "Content-Type": "application/json"
        }

        # Validate MSISDNs
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
                ["id","iccid","msisdn","username","telegence_features"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        ##adding validation to not add more parallel requests
        if parallel_requests>10:
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"###telegence_bc_update_feature Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each MSISDN in the batch
                logging.info(f"###telegence_bc_update_feature Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    # Prepare the URL and payload for the API call
                    url = f"{carrier_api_url}/{msisdn}"
                    def task(msisdn=msisdn, url=url, add_codes=add_codes,remove_codes=remove_codes):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        any_api_succeeded = False
                        last_error_message = ""
                        ###overwrite function to fetch the offering codes and then removing them 
                        if overwrite:
                            logging.info(f"###telegence_bc_update_feature overwrite feature initiated for msisdn:{msisdn}")
                            overwrite_codes = []
                            get_response = requests.get(url, headers=headers, timeout=60)
                            logging.info(f"###telegence_bc_update_feature Get Response for overwrite {get_response.status_code} and {get_response.text}")
                            if get_response.status_code == 200:
                                data = get_response.json()
                                # Extract serviceCharacteristic list
                                svc_chars = data.get("serviceCharacteristic", [])
                                # Use regex to find names that match offeringCode followed by a digit
                                pattern = re.compile(r"^offeringCode\d+$")
                                for item in svc_chars:
                                    name = item.get("name", "")
                                    if pattern.match(name):
                                        value = item.get("value")
                                        if value:
                                            overwrite_codes.append(value)
                                logging.info(f"###telegence_bc_update_feature overwrite codes are {overwrite}")
                                ##removing the offering codes one by one
                                for offercode in overwrite_codes:
                                    payload = {
                                        "serviceCharacteristic": [
                                            {
                                                "name": "removeOfferingCode",
                                                "value": offercode
                                            }
                                        ]
                                    }
                                    for attempt in range(1, MAX_RETRIES + 1):
                                        try:
                                            logging.info(f"Attempt {attempt} - URL: {url}")
                                            resp = requests.patch(
                                                url, json=payload, headers=headers, timeout=60)
                                            logging.info(f"###telegence_bc_update_feature Response Code for remove API in overwrite feature for offercode{offercode}: {resp.status_code}")
                                            success = 200 <= resp.status_code < 300
                                            result = resp.text
                                            status = "PROCESSED" if success else "API_FAILED"
                                            if success:
                                                break
                                        except Exception as e:
                                            result = str(e)
                                            logging.warning(
                                                f"Attempt {attempt} failed: {result}")
                                            time.sleep(RETRY_DELAY)
                                    ##updating inventory block
                                    try:
                                        if success:
                                            successful_ids.append(msisdn)
                                            update_telegence_features(database, msisdn, offercode, "remove")
                                            any_api_succeeded = True
                                            logging.info("Successfully removed offering code %s for msisdn %s", offercode, msisdn)
                                    except Exception as e:
                                        logging.exception("Failed to  remove offering code %s for msisdn %s", offercode, msisdn)
                                    # Constructing the log entry
                                    remove_feature_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": f"Update Telegence Subscriber: Telegence API OverWrite Feature Code:{offercode}",
                                    "request_text": json.dumps(payload),
                                    "has_errors": status == "API_FAILED",
                                    "response_status": "PROCESSED" if success else "API_Failed",
                                    "response_text": result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                    }
                                    ##inserting the remove feature logs
                                    if remove_feature_log:
                                        database.insert_data(remove_feature_log,"sim_management_bulk_change_log")
                                        #  insert the log entries into detailed logs table
                                        database.insert_data(remove_feature_log, "sim_management_bulk_change_detailed_logs")
                            else:
                                    logging.info("Sim Not Found or error response")
                                    # Constructing the log entry
                                    get_response_fail_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                        "log_entry_description": "Update Telegence Subscriber: OverWrite Feature fetch failed",
                                        "request_text": None,
                                        "has_errors": True,
                                        "response_status": f"GET_FAILED_{get_response.status_code}",
                                        "response_text": get_response.text,
                                        "error_text": get_response.text,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    ##inserting the remove feature logs
                                    if get_response_fail_log:
                                        database.insert_data(get_response_fail_log,"sim_management_bulk_change_log")
                                        #  insert the log entries into detailed logs table
                                        database.insert_data(get_response_fail_log, "sim_management_bulk_change_detailed_logs")
                        logging.info(f"###telegence_bc_update_feature feature code addition initiated")

                        ###add feature codes block
                        for offercode in add_codes:
                            ##payload construction for each offering code
                            payload = {
                                "serviceCharacteristic": [
                                    {
                                        "name": "addOfferingCode",
                                        "value": offercode
                                    }
                                ]
                            }
                            ###processing the API
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"Attempt {attempt} - URL: {url}")
                                    resp = requests.patch(
                                        url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"###telegence_bc_update_feature Response Code for addition API for offercode{offercode}: {resp.status_code}")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(
                                        f"Attempt {attempt} failed: {result}")
                                    time.sleep(RETRY_DELAY)
                            ##updating inventory block
                            try:
                                if success:
                                    successful_ids.append(msisdn)
                                    update_telegence_features(database, msisdn, offercode, "add")
                                    any_api_succeeded = True
                                    logging.exception("Successfully added offering code %s for msisdn %s", offercode, msisdn)
                            except Exception as e:
                                logging.exception("Failed to add offering code %s for msisdn %s", offercode, msisdn)
                            # Constructing the log entry for
                            add_feature_code_log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                "log_entry_description": f"Update Telegence Subscriber: Telegence API Add Feature Code: {offercode}",
                                "request_text": json.dumps(payload),
                                "has_errors": status == "API_FAILED",
                                "response_status": "PROCESSED" if success else "API_Failed",
                                "response_text": result,
                                "error_text": "" if status == "PROCESSED" else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                                }
                            ###add feature logs
                            if add_feature_code_log:
                                database.insert_data(add_feature_code_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(add_feature_code_log, "sim_management_bulk_change_detailed_logs")
                        logging.info(f"###telegence_bc_update_feature feature code remove initiated")
                        ##removing the codes
                        # for offercode in remove_codes:
                        for offercode in filtered_remove_features:
                            payload = {
                                "serviceCharacteristic": [
                                    {
                                        "name": "removeOfferingCode",
                                        "value": offercode
                                    }
                                ]
                            }
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"Attempt {attempt} - URL: {url}")
                                    resp = requests.patch(
                                        url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"###telegence_bc_update_feature Response Code for remove API for offercode{offercode}: {resp.status_code}")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(
                                        f"Attempt {attempt} failed: {result}")
                                    time.sleep(RETRY_DELAY)
                            ##updating inventory block
                            try:
                                if success:
                                    update_telegence_features(database, msisdn, offercode, "remove")
                                    any_api_succeeded = True
                                    logging.info("Successfully removed offering code %s for msisdn %s", offercode, msisdn)
                            except Exception as e:
                                logging.exception("Failed to remove offering code %s for msisdn %s", offercode, msisdn)
                            # Constructing the log entry
                            remove_feature_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": f"Update Telegence Subscriber: Telegence API Remove Feature Code:{offercode}",
                            "request_text": json.dumps(payload),
                            "has_errors": status == "API_FAILED",
                            "response_status": "PROCESSED" if success else "API_Failed",
                            "response_text": result,
                            "error_text": "" if status == "PROCESSED" else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                            }
                            ##inserting the remove feature logs
                            if remove_feature_log:
                                database.insert_data(remove_feature_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(remove_feature_log, "sim_management_bulk_change_detailed_logs") 
                        
                        # update_data = {
                        #     "status": "PROCESSED",
                        #     "has_errors": False,
                        #     "is_processed": True,
                        #     "processed_date": now,
                        #     "status_details":result
                        # }
                        # #update the request status
                        # database.update_dict(
                        #     "sim_management_bulk_change_request",
                        #     update_data,
                        #     and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                        #     )
                        # return msisdn
                        # Track if ANY API call was successful for this MSISDN
                        if any_api_succeeded:
                            update_data = {
                                "status": "PROCESSED",
                                "has_errors": False,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details": result
                            }
                        else:
                            # Only if NO API succeeded at all
                            update_data = {
                                "status": "API_FAILED", 
                                "has_errors": True,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details": result
                            }
                        
                        # Update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                        )
                        return msisdn
                    
                    # Submit the task to the executor
                    logging.info(f"Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"Error processing MSISDN")     
        if interval and i + batch_size < len(msisdns):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status 
        if successful_ids:  
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":successful_ids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API
            try:
                logging.info(f"### telegence_bc_update_feature and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_update_feature and {tenant_name} Exception in thread: {e}") 
        logging.info("Processed %d MSISDNs, %d remaining", len(msisdns) - len(remaining), len(remaining))

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": [],
                        "msisdns": successful_ids,
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Update Features",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "telegence_features",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_update_feature and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_update_feature and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid MSISDNs
        if invalid_ids:
            logging.info(f"### Invalid MSISDNs found: {invalid_ids}")
            # Log invalid ICCIDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update feature codes",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,
                        "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids},
            )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        logging.info(f"### Inserted %d log entries for bulk change request", len(log_entries))
        logging.info("Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API call for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info('sync call has started for telegence_bc_update_feature')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,60)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info('sync call has ended')
        except Exception as e:
            logging.exception(f"Exception in thread is {e}")
        # Return success
        logging.info("Bulk change request processed successfully.")
        logging.info("Total time taken for processing: %s seconds", time.time() - start_time)
        ##auditing the sync completion
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        # Attempt to audit the action
        try:
            if successful_ids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "changed_data": {
                            "msisdn": successful_ids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_update_feature",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing feature codes for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### Error during bulk change processing: %s", str(e))
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
 
        return response


def update_telegence_features(database, msisdn, offering_code, operation):
    """
    Update a single offering code in the telegence_features field.
    
    :param database: DB helper with get_data and update_dict methods
    :param msisdn: phone number identifier (string)
    :param offering_code: code to add or remove (string)
    :param operation: either 'add' or 'remove'
    """
    try:
        logging.info(f"##telegence_bc_update_feature update query check for offering code {offering_code} and msisdn {msisdn}")
        # Fetch current comma-separated feature string
        row = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdn},
            ["telegence_features"]
        )
        features_str = row["telegence_features"].to_list()[0]

        # Convert to list safely: split on commas & trim whitespace :contentReference[oaicite:1]{index=1}
        existing = [x.strip() for x in features_str.split(",")] if features_str else []

        # Modify list based on operation
        if operation == 'add':
            if offering_code not in existing:
                existing.append(offering_code)
        elif operation == 'remove':
            if offering_code in existing:
                existing.remove(offering_code)
        else:
            logging.info("Failed to do the add or remove operations")
        # Rebuild comma-separated string & update DB
        updated_features = ",".join(existing)
        database.update_dict(
            "sim_management_inventory",
            {"telegence_features": updated_features},
            and_conditions={"is_active": True, "msisdn": msisdn}
        )
        logging.info(f"##telegence_bc_update_feature updated offering codes are {updated_features} and msisdn {msisdn}")
        return updated_features
    except Exception as e:
        logging.exception(f"Failed to Add or Remove Feature codes")
        return []


##SYNC API call function
def call_sync_api(api_url, api_payload):
    '''
    Call the sync API with the provided URL and payload.
    This function is designed to be run in a separate thread after a delay.
    '''
    try:
        # Make the API call
        logging.info(f"### Calling sync API: {api_url} with payload: {api_payload}")
        response = requests.post(api_url, json=api_payload)
        if response.status_code == 200:
            logging.info("Bulk Change API call successful. Data sync call successfully done.")
        else:
            logging.error(f"API call failed with status code: {response.status_code}")
    except Exception as e:
        logging.error(f"Error making API call: {e}")

## Function to audit user actions in bulk change processing
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
   
    request_received_at = data.get("request_received_at", "") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
        logging.info("User action audited successfully.")
    except Exception as e:
        logging.exception(f"### Error logging user actions: {e}")


def live_progress_percentage_tracker(database, bulk_change_id,progress_percent):
    """
    Updates the live_progress_percentage column in sim_management_bulk_change_request table.
    """
    try:
        update_fields={}
        #updating sync status when progress percentage reached 100
        if progress_percent==100:
            update_fields["live_progress_percentage"]=progress_percent
            update_fields["progress"]="Sync Completed"
        else:
            update_fields["live_progress_percentage"]=progress_percent

        database.update_dict(
            "sim_management_bulk_change",
            update_fields,
            and_conditions={"id": bulk_change_id}
        )
        return True
    except Exception as e:
        logging.error(f"Error updating live progress: {e}")
        return False


   
##Refresh API
def telegence_refresh_a_line(data):
    """
    Bulk Refresh using AMLC Telegence API using MSISDN to change_request mapping.

    This function performs the following steps:
        - Extracts necessary metadata and initializes DB connections.
        - Fetches carrier API credentials and limits.
        - Fetches and maps MSISDNs to their payloads and request IDs.
        - Sends PATCH requests to update PPU address using ThreadPoolExecutor with retry logic.
        - Logs responses, updates DB entries, and handles invalid MSISDNs/IDs.
        - Logs audit events before and after processing.

    Args:
        data (dict): Contains keys such as msisdns, bulk_change_id, created_by, service_provider, etc.

    Returns:
        dict: Summary response including processed count and any remaining MSISDNs.
    """
    logging.info(f"### Received data for telegence_refresh_a_line: %s",data)
    start_time = time.time()
    # Extract input metadata
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids = data.get("invalid_ids", [])
    now_dt = datetime.now()
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    integration_id=data.get("integration_id", "")
    integration_id=data.get("integration_id", 6)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    source=data.get("source","")
    device_status_id=None
    provider_parent_name=data.get("parent_provider_name", "")
    logging.info(f"###def telegence_refresh_a_line and {tenant_name} time is {now}")
    if not bulk_change_id:
        logging.error(f"### telegence_refresh_a_line and {tenant_name} Missing required fields") 
        return {"flag": False, "message": "bulk_change_id is required"}

    # DB Connections
    try:
        database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### telegence_refresh_a_line and{tenant_name} DB connection error:{e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,10)
    try:
        # Fetch carrier API details
        provider = provider_parent_name if provider_parent_name else service_provider
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(provider, change_type, common_utils_database)
        # app_id, app_secret = fetch_app_details(database, integration_id)
        # logging.info(f"### telegence_refresh_a_line and {tenant_name} Fetched App ID {app_id} and Secret for integration ID {integration_id}")
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### telegence_refresh_a_line and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}
        
    except Exception as e:
        logging.exception(f"### telegence_refresh_a_line and{tenant_name} Audit logging failed after config fetch: {e}")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    ## Carrier limits
    BATCH_SIZE = carrier_limits.get("batch_size")
    PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
    if PARALLEL_REQUESTS>10:
        logging.info(f"###telegence_refresh_a_line and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
    INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
    RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
    try:
        # Fetch change requests from DB
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        ).rename(columns={"subscriber_number": "msisdn"})
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_refresh_a_line",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_refresh_a_line and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,30)
        try:
            change_request = json.loads(change_request_json)
        except (TypeError, json.JSONDecodeError):
            # handle parsing error
            change_request = {}
        logging.info(f"### telegence_refresh_a_line and{tenant_name} change_request: {change_request}")
        ##fetching the change requests
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))

        logging.info(f"### telegence_refresh_a_line and {tenant_name} Fetched {len(bulk_requests)} bulk change requests from the database")
        logs = []
        successful_ids = []
        remaining = list(msisdns)
        rate_plan_data= pd.DataFrame()
        device_status_data = pd.DataFrame()
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        ##batch processing
        device_status_data=database.get_data("device_status",{"integration_id":integration_id},["id","display_name"])
        rate_plan_data = database.get_data(
        "carrier_rate_plan",
        {"is_active": True},
        ["rate_plan_code", "id", "friendly_name"]
        )
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id}
        ).to_dict(orient="records")
        changed_data = []
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            ## Process each batch of MSISDNs
            for i in range(0, len(msisdns), BATCH_SIZE):
                # Create a batch of MSISDNs
                logging.info(f"### telegence_refresh_a_line and {tenant_name} Processing batch {i // BATCH_SIZE + 1} with {min(BATCH_SIZE, len(msisdns) - i)} MSISDNs")
                batch = msisdns[i:i + BATCH_SIZE]
                futures = {}
                # Prepare payloads and URLs for each MSISDN in the batch
                logging.info(f"### telegence_refresh_a_line and {tenant_name} Batch size is {len(batch)}")
                for msisdn in batch:
                    url = f"{carrier_api_url}/{msisdn}"
                    try:
                        # Parse the change request JSON for the MSISDN
                        payload_str=msisdn_to_changerequest.get(msisdn)
                        request_payload = json.loads(payload_str)
                        payload = request_payload.get("RefreshLine")
                    except Exception as e:
                        logging.warning(f"### telegence_refresh_a_lin and {tenant_name} Invalid JSON for MSISDN {msisdn}: {e}")
                        payload = {}
                    ## Validate payload
                    request_id = msisdn_to_request_id.get(msisdn)
                    def task(msisdn=msisdn, url=url, payload=payload, request_id=request_id):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        sim = None
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_refresh_a_line and {tenant_name} Attempt {attempt} - URL: {url}")
                                resp = requests.get(
                                    url,
                                    headers={"app-id": app_id, "app-secret": app_secret, "Content-Type": "application/json"},
                                    timeout=60
                                )
                                ## Prepare request payloads
                                logging.info(f"### telegence_refresh_a_line and {tenant_name} Response Code: {resp.status_code} for refresh line")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                   response_data= resp.json()
                                   logging.info(f"### telegence_refresh_a_line and {tenant_name} Response Data: {json.dumps(response_data)} for MSISDN: {msisdn}")
                                   break
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### telegence_refresh_a_line and {tenant_name} Attempt {attempt} failed for {msisdn}:{e}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            characteristics = {item["name"]: item["value"] for item in response_data.get("serviceCharacteristic", [])}
                            sim = characteristics.get("sim") 
                        if sim:
                            for characteristic in payload.get("serviceCharacteristic", []):
                                if characteristic.get("name") == "sim":
                                    characteristic["value"] = sim
                                    break
                            logging.info(f"### telegence_refresh_a_line and {tenant_name} Updated payload with SIM: {sim} for MSISDN: {msisdn}")
                            logging.info(f"### telegence_refresh_a_line and {tenant_name} Payload for MSISDN {msisdn}: {json.dumps(payload)}")
                            # Prepare the final payload for PATCH request
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### telegence_refresh_a_line and {tenant_name} Attempt {attempt} - URL: {url}")
                                    resp = requests.patch(
                                        url,
                                        json=payload,
                                        headers={"app-id": app_id, "app-secret": app_secret, "Content-Type": "application/json"},
                                        timeout=60
                                    )
                                    ## Prepare request payloads
                                    logging.info(f"### telegence_refresh_a_line and {tenant_name} Response Code: {resp.status_code} for PPU address update")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        response_data= resp.json()
                                        successful_ids.append(msisdn)
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.exception(f"### telegence_refresh_a_line and {tenant_name} Attempt {attempt} failed for {msisdn}:{e}")
                                    time.sleep(RETRY_DELAY)

                            # Update DB request row
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": status, "has_errors": not success, "is_processed": True,
                                "processed_date": now,"status_details":result},
                                and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                            )

                            # Update inventory
                            if success:
                                # Extract characteristics and update inventory
                                rate_plan_id = None
                                rate_plan_code = None

                                logging.info(f"### telegence_refresh_a_line and {tenant_name} extracting characteristics for MSISDN: {msisdn}")
                                characteristics = {item["name"]: item["value"] for item in response_data.get("serviceCharacteristic", [])}
                                sim = characteristics.get("sim")
                                effective_date = characteristics.get("effectiveDate")
                                single_user_code = characteristics.get("singleUserCode")
                                service_zip_code = characteristics.get("serviceZipCode")
                                effective_date = characteristics.get("effectiveDate")
                                billing_account_number = characteristics.get("billingAccountNumber")
                                contact_name = characteristics.get("contactName")
                                nw_imei = characteristics.get("BLIMEI")
                                next_bill_cycle_date = characteristics.get("nextBillCycleDate")
                                status = response_data.get("status", "")
                                if status.lower() == "reserved":
                                    status = "Active"
                                offering_codes = [
                                        value for key, value in characteristics.items()
                                        if key.startswith("offeringCode") and value
                                    ]
                                offering_codes_str = ",".join(offering_codes) if offering_codes else ""
                                if "rate_plan_code" in rate_plan_data.columns and "id" in rate_plan_data.columns:
                                        matches = rate_plan_data.loc[
                                            (rate_plan_data["rate_plan_code"] == single_user_code),
                                            ["id", "rate_plan_code"]
                                        ]

                                        if not matches.empty:
                                            rate_plan_id = matches["id"].to_list()[0]
                                            rate_plan_code = matches["rate_plan_code"].to_list()[0]
                                        else:
                                            logging.warning(
                                                f"### telegence_refresh_a_line and {tenant_name}Rate plan not found for code: {single_user_code}"
                                            )
                                            rate_plan_id = None
                                            rate_plan_code = None
                                if "display_name" in device_status_data.columns and "id" in device_status_data.columns:
                                        matches = device_status_data.loc[
                                            device_status_data["display_name"] == status,
                                            "id"
                                        ]
                                        if not matches.empty:
                                            device_status_id = matches.iloc[0]
                                            device_status_id=int(device_status_id)
                                logging.info(f"###telegence_refresh_a_line and {tenant_name} All required data found; stopping polling and device_status_id {device_status_id}")
                                                 

                                #update the inventory
                                updated_data = {"effective_date": effective_date,"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": rate_plan_code,
                                                "service_zip_code": service_zip_code,"billing_account_number": billing_account_number,
                                                "username": contact_name,"iccid": sim,"imei": nw_imei,"next_bill_cycle_date": next_bill_cycle_date,
                                                "telegence_features": offering_codes_str,"sim_status": status,"device_status_id": device_status_id,
                                                } 
                                
                                old_record = next((item for item in old_inventory_data if item.get("iccid") == sim), {})
                                exclude_fields = ["iccid"]  
                                keys_to_check = [key for key in updated_data.keys() if key not in exclude_fields]
                                to_update, field_changes = build_detailed_update_dict(updated_data, old_record, keys_to_check)
                                if to_update:
                                    # Include the ID for update
                                    #to_update["id"] = old_record["id"]
                                    to_update["modified_by"] = username
                                    updated = database.update_dict("sim_management_inventory", to_update, {
                                    "is_active": True,
                                    "msisdn": msisdn,"service_provider_display_name":service_provider,
                                    })    
                                # Store field changes for batch processing
                                if field_changes:
                                    changed_data.append({
                                        "field_changes": field_changes, 
                                        "id": old_record["id"],
                                        "iccid": sim,
                                        "msisdn": msisdn
                                    }) 
                                # database.update_dict("sim_management_inventory", updated_data, {
                                #     "is_active": True,
                                #     "msisdn": msisdn,"tenant_id": tenant_id,"service_provider_display_name":service_provider,
                                #     })
                                    
                            # Prepare and insert log
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": request_id,
                                "log_entry_description": "Refresh A Line via Telegence API",
                                "request_text": json.dumps(payload),
                                "has_errors": not success,
                                "response_status": status,
                                "response_text": result,
                                "error_text": "" if success else result,
                                "processed_date": now_dt,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now_dt,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            inventory_success = updated is True or updated is None
                            
                            inventory_log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": request_id,
                                "log_entry_description": "Update AMOP",
                                "request_text": None,
                                "has_errors": not inventory_success,
                                "response_status": "PROCESSED" if inventory_success else "ERROR",
                                "response_text": "inventory updated successfully" if inventory_success else "inventory update failed",
                                "error_text": "" if inventory_success else "Inventory update failed",
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }

                            if inventory_log:
                                database.insert_data(inventory_log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(inventory_log,"sim_management_bulk_change_detailed_logs")   
                        else:
                            logging.error(f"### telegence_refresh_a_line and {tenant_name} SIM not found in response for MSISDN: {msisdn}")
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": request_id,
                                "log_entry_description": "Refresh A Line via Telegence API",
                                "request_text": json.dumps(payload),
                                "has_errors": not success,
                                "response_status": status,
                                "response_text": f"SIM not found in response for MSISDN: {msisdn}",
                                "error_text": "" if success else result,
                                "processed_date": now_dt,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now_dt,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            # Update sim_management_bulk_change_request table row
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": status, "has_errors": not success, "is_processed": True,
                                "processed_date": now,"status_details":result},
                                and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                            )      
                                
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_refresh_a_line and {tenant_name} Error processing MSISDN in thread: {e}")

        if INTERVAL and i + BATCH_SIZE < len(msisdns):
            time.sleep(INTERVAL)
        logging.info(f"carrier requests are processed successfully")
        live_progress_percentage_tracker(database, bulk_change_id,70)
        # Prepare history table update
        if successful_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":successful_ids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API  
            try:
                logging.info(f"### telegence_refresh_a_line and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_refresh_a_line and {tenant_name} Exception in thread: {e}")  
        if source == "Inventory" and changed_data:
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            # Use json.dumps with default=str for the entire payload
            action_history_payload = json.loads(json.dumps({
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": [],
                    "msisdns": successful_ids,
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Refresh A Line",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_data": changed_data
                }
            }, default=str))
            # API call to update action history
            try:
                logging.info(f"###  telegence_refresh_a_line and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"###  telegence_refresh_a_line and {tenant_name} Exception in action history thread: {e}")
                        
            # Handle invalid MSISDNs
        if invalid_ids:
            logging.info(f"### telegence_refresh_a_line and {tenant_name} Invalid MSISDNs found: {invalid_ids}")
            # Log invalid IDS
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Invalid MSISDN during refresh",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid MSISDN - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now_dt,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now_dt,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(logs,"sim_management_bulk_change_detailed_logs")

        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now,"status_details":"Invalid MSISDN - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids}
            )

        database.update_dict(
            "sim_management_bulk_change",
            {"status": "PROCESSED", "processed_date": now_dt},
            {"id": bulk_change_id}
        )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                    "data": {
                        "access_token": access_token,
                        "data": {
                            "bulk_change_id": bulk_change_id
                        },
                        "db_name": tenant_database,
                        "is_update": True,
                        "module_name": "Bulk Change",
                        "Partner": tenant_name,
                        "path": "/update_bulk_change_tables_10",
                        "request_received_at": now,
                        "role_name": role_name,
                        "tenant_name": tenant_name,
                        "username": username
                    }
                }
        #sync api call used to sync the inventory data to 1.0 tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_refresh_a_line and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### telegence_refresh_a_line and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### telegence_refresh_a_line and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        ##prepare response
        try:
            if successful_ids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "changed_data": {
                            "msisdn": successful_ids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        response = {
            "flag": True,
            "processed": len(msisdns) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk Refresh request processed successfully.",
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        # End time calculation
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_refresh_a_line",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed refresh a line update request for devices: {msisdns} with bulk_change_id: {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
             logging.exception(f"### telegence_refresh_a_line and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        logging.exception(f"### telegence_refresh_a_line and {tenant_name} Audit logging failed: {e}")
        error_message = f"Error during refreshing line processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_refresh_a_line",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns} with bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
             logging.exception(f"### telegence_refresh_a_line and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
    
   

def telegence_bc_line_sync(data):
    """
    Sync SIM inventory and bulk change requests with the ciscojasper API.

    This function processes a list of ICCIDs for a given bulk change operation
    and updates their details by calling the carrier's ciscojasper API. It includes
    retry logic, database updates, inventory synchronization, error handling,
    and audit logging.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains request payload and UpdateStatus information.
            - service_provider (str): Name of the carrier/service provider.
            - change_type (str): Type of update (e.g., SIM/device status).
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant (for logs/audit).
            - db_name (str): Tenant-specific database name.
            - service_provider_id (str): Identifier for the service provider.
            - invalid_iccids (list): ICCIDs that failed validation before processing.

    Returns:
        dict: Response object summarizing the processing result:
            - flag (bool): True if operation completed without unhandled errors.
            - message (str): Summary of result (success or failure).
            - processed (int): Number of ICCIDs successfully processed.
            - remaining (int): Number of ICCIDs not processed.
            - iccids (list): List of ICCIDs attempted.
            - invalid_iccids (list): ICCIDs skipped due to invalid input.
            - bulk_change_id (str): Bulk change request ID.
            - error (str, optional): Error message if processing failed.
    """
    logging.info(f"### Received data for line sync: {data}")
    start_time = time.time()
    # Extract required fields
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    invalid_ids = data.get("invalid_ids", [])
    integration_id=data.get("integration_id", 6)
    provider_parent_name=data.get("parent_provider_name", "")

    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_line_sync and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### telegence_bc_line_sync and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### telegence_bc_line_sync and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        provider = provider_parent_name if provider_parent_name else service_provider
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(provider, change_type, common_utils_database)   
        # app_id, app_secret = fetch_app_details(database, integration_id)
        # logging.info(f"### telegence_bc_line_sync and {tenant_name} Fetched App ID {app_id} and Secret for integration ID {integration_id}")
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### telegence_bc_line_sync and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### telegence_bc_line_sync and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number" ]
        ).rename(columns={"subscriber_number": "msisdn"})
        
        # Debug logging for bulk requests
        logging.info(f"### Bulk requests data: {bulk_requests_df.to_dict('records')}")
        
        if bulk_requests_df.empty:
            message=f"Bulk Change Request data is empty"
            response={"flag":False,"message":message}
            error_update_data={"errors":len(msisdns),"status":"ERROR"}
            database.update_dict(
                    "sim_management_bulk_change",
                    error_update_data,
                    and_conditions={"id": bulk_change_id},
                    )
            # Attempt to audit the action
            try:
                end_time = time.time()
                time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                time_consumed = int(round(time_consumed))
                audit_data_user_actions = {
                    "service_name": "telegence_bc_line_sync",
                    "created_by": username,
                    "status": json.dumps(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": message,
                    "request_received_at": now,
                }
            
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### telegence_bc_line_sync and {tenant_name} Audit logging failed: {e}")
            return response
        
        # Handle empty MSISDNs in bulk requests (for new MSISDNs not in inventory)
        # This happens when bulk change requests are created for new MSISDNs
        logging.info(f"### Before fixing empty MSISDNs: {bulk_requests_df.to_dict('records')}")
        
        # Check if we have empty MSISDNs that need to be fixed
        empty_msisdn_indices = bulk_requests_df.index[bulk_requests_df['msisdn'].isna() | (bulk_requests_df['msisdn'].astype(str).str.strip() == '')].tolist()
        
        if empty_msisdn_indices:
            logging.info(f"### Found {len(empty_msisdn_indices)} bulk requests with empty MSISDNs")
            
            # Check if we have matching MSISDNs to assign
            if len(empty_msisdn_indices) <= len(msisdns):
                for idx, request_idx in enumerate(empty_msisdn_indices):
                    if idx < len(msisdns):
                        msisdn_to_assign = msisdns[idx]
                        request_id = bulk_requests_df.iloc[request_idx]['id']
                        
                        # Update in database
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"subscriber_number": msisdn_to_assign},
                            and_conditions={"id": request_id, "bulk_change_id": bulk_change_id}
                        )
                        
                        # Update in dataframe
                        bulk_requests_df.at[request_idx, 'msisdn'] = msisdn_to_assign
                        logging.info(f"### Fixed request ID {request_id}: assigned MSISDN {msisdn_to_assign}")
                    else:
                        logging.warning(f"### Not enough MSISDNs to assign to all empty requests")
                        break
            else:
                logging.warning(f"### More empty requests ({len(empty_msisdn_indices)}) than MSISDNs ({len(msisdns)})")
        
        # Filter out any remaining empty MSISDNs (shouldn't happen after fix, but just in case)
        bulk_requests_df = bulk_requests_df[~bulk_requests_df['msisdn'].isna() & (bulk_requests_df['msisdn'].astype(str).str.strip() != '')]
        
        logging.info(f"### After fixing empty MSISDNs: {bulk_requests_df.to_dict('records')}")
        
        # Check if we have any valid requests left
        if bulk_requests_df.empty:
            logging.error(f"### No valid bulk requests after fixing empty MSISDNs")
            message = "No valid bulk change requests found after fixing empty MSISDNs"
            response = {"flag": False, "message": message}
            error_update_data = {"errors": len(msisdns), "status": "ERROR"}
            database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
            )
            return response
        
        # Create MSISDN to request ID mapping
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        logging.info(f"### MSISDN to request ID mapping: {msisdn_to_request_id}")
        
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "msisdn": msisdns, "tenant_id": tenant_id}
        ).to_dict(orient="records")
        inventory_lookup = {rec["msisdn"]: rec for rec in old_inventory_data}
        # CREATE A SET OF EXISTING MSISDNS FOR QUICK LOOKUP
        existing_msisdns = {item["msisdn"] for item in old_inventory_data}
        new_msisdns = [msisdn for msisdn in msisdns if msisdn not in existing_msisdns]
        existing_msisdns_list = [msisdn for msisdn in msisdns if msisdn in existing_msisdns]

        logging.info(f"### telegence_bc_line_sync and {tenant_name} Found {len(existing_msisdns_list)} existing MSISDNs and {len(new_msisdns)} new MSISDNs")
        
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        
        if PARALLEL_REQUESTS > 10:
            logging.info(f"### telegence_bc_line_sync and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS = 10
        
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        changed_data = []
        remaining = list(msisdns)
        
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(msisdns), BATCH_SIZE):
                batch = msisdns[i:i + BATCH_SIZE]
                futures = {}

                for msisdn in batch:
                    url = f"{carrier_api_url}"   
                    ## Prepare headers for API call
                    headers = {
                        "accept": "application/json",
                        "content-type": "application/json",
                        "client_id": app_id,
                        "client_secret": app_secret,
                        "source": "product-papi/product",
                        "x-trace-id": "a49fd114-c14b-11ea-b3de-0242ac130004",
                        "x-transaction-id": "73c427a4-2482-4e64-8cac-ea4ace577890",
                        "User-Agent": "PostmanRuntime/7.36.1"
                    }
                    billing_record = inventory_lookup.get(msisdn)

                    if billing_record:
                        billing_number = billing_record.get("billing_account_number")
                    else:
                        billing_number = None
                    logging.info(f"### Billing number for MSISDN {msisdn}: {billing_number}")
                    def task(msisdn=msisdn, url=url):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        updated = None
                        inserted = None
                        is_new_msisdn = msisdn in new_msisdns  # Check if this is a new MSISDN
                        payload={
                        "subscriberNumber": msisdn,
                        "billingAccountNumber": billing_number
                        }
                        logging.info(f"### Prepared payload for MSISDN {msisdn}: {payload}")
                        # Get the request ID - handle both cases (existing mapping or direct lookup)
                        request_id = msisdn_to_request_id.get(msisdn)
                        
                        # If request ID not found in mapping, try to find it directly
                        if not request_id:
                            request_result = database.get_data(
                                "sim_management_bulk_change_request",
                                {"bulk_change_id": bulk_change_id, "subscriber_number": msisdn},
                                ["id"]
                            )
                            if not request_result.empty:
                                request_id = request_result.iloc[0]['id']
                                # Update the mapping for future reference
                                msisdn_to_request_id[msisdn] = request_id
                            else:
                                logging.warning(f"### No request ID found for MSISDN: {msisdn}")
                        
                        logging.info(f"### Processing MSISDN: {msisdn}, Request ID: {request_id}")
                        
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_line_sync and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url} and Payload: {payload}")
                                resp = requests.post(url, 
                                    headers=headers,json=payload, timeout=60)
                                logging.info(f"### telegence_bc_line_sync and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                
                                # Validate API response
                                if success:
                                    try:
                                        api_data = resp.json()
                                        if not api_data.get("subscriber", {}).get("subscriberNumber"):
                                            logging.warning(f"### Missing subscriberNumber in API response for {msisdn}")
                                            success = False
                                            result = "Invalid API response: missing subscriberNumber"
                                        else:
                                            break
                                    except json.JSONDecodeError as e:
                                        logging.error(f"### JSON decode error for {msisdn}: {e}")
                                        success = False
                                        result = f"Invalid JSON response: {resp.text[:500]}"
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### telegence_bc_line_sync and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB if we have a request ID
                        if request_id:
                            update_success = database.update_dict(
                                "sim_management_bulk_change_request",
                                {
                                    "status": status, 
                                    "has_errors": not success, 
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details": resp.text if success else result
                                },
                                and_conditions={
                                    "id": request_id, 
                                    "bulk_change_id": bulk_change_id
                                }
                            )
                            logging.info(f"### Update status for {msisdn} (Request ID: {request_id}): {update_success} rows updated")
                        else:
                            logging.warning(f"### Could not update request status for {msisdn} - no request ID found")

                        # Update inventory if successful
                        if success:
                            api_data = resp.json()
                            logging.info(f"### API data for MSISDN {msisdn}: {api_data}")
                            # Extract serviceCharacteristic into a dict {name: value}
                            # characteristics = {
                            #     item.get("name"): item.get("value")
                            #     for item in api_data.get("serviceCharacteristic", [])
                            # }
                            # Ensure api_data is a dict
                            subscriber = api_data.get("subscriber") or {}
                            # Subscriber Status
                            subscriber_status_obj = subscriber.get("subscriberStatus") or {}
                            status_code = subscriber_status_obj.get("subscriberStatus", "")
                            status_map = {
                                "A": "Active",
                                "C": "Cancelled",
                                "S": "Suspended",
                                "D": "Deactivated"
                            }
                            subscriber_status = status_map.get(status_code, "Unknown")
                            # Subscriber Number
                            subscriber_number = subscriber.get("subscriberNumber", "")
                            contact_info = subscriber.get("contactInformation") or {}
                            # Name
                            name_info = contact_info.get("name") or {}
                            first_name = name_info.get("firstName", "")
                            last_name = name_info.get("lastName", "")
                            # PPU Address
                            ppu = contact_info.get("ppuAddress") or {}
                            ppuaddress = {
                                "addressLine1": ppu.get("addressLine1", ""),
                                "city": ppu.get("city", ""),
                                "state": ppu.get("state", ""),
                                "zipCode": ppu.get("zipCode", "")
                            }
                            price_plan = api_data.get("pricePlan") or {}
                            price_plan_code = price_plan.get("pricePlanCode", "")
                            description = price_plan.get("description", "")
                            device = subscriber.get("device") or {}
                            biller_device = device.get("billerDevice") or {}
                            imei = biller_device.get("imei", "")
                            sim = biller_device.get("sim", "")
                            account = api_data.get("account") or {}
                            ban = account.get("billingAccountNumber", "")
                            next_bill_date = account.get("nextBillCycleDate", "")
                            service_activation = api_data.get("serviceActivationDate") or {}
                            date_activated = service_activation.get("effectiveDate", "")                           
                            if is_new_msisdn:
                                # INSERT new MSISDN - create full record
                                try:
                                    to_insert = {
                                        "iccid": sim,
                                        "imsi": None, 
                                        "msisdn": subscriber_number,
                                        "imei": imei,  
                                        "sim_status": subscriber_status,
                                        "carrier_rate_plan_name": description,
                                        "date_activated": date_activated,
                                        #"account_number": characteristics.get("billingAccountNumber"),
                                        "date_added": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                        #"effective_date": effective_date_value,
                                        "username": first_name + " " + last_name,
                                        "rate_plan_soc": price_plan_code,
                                        "rate_plan_soc_description":description,
                                        "billing_account_number": ban,
                                        "billing_cycle_end_date": next_bill_date,
                                        "tenant_id": tenant_id,
                                        "created_by": username,
                                        "created_date": now,
                                        "is_active": True,
                                        "is_deleted": False,
                                        "tenant_is_active": True,
                                        "tenant_is_deleted": False,
                                        "service_provider_is_active": True,
                                        "service_provider_display_name": service_provider,
                                        "service_provider_id": service_provider_id
                                    }
                                    
                                    # Convert empty strings to None for database
                                    for key, value in to_insert.items():
                                        if value == "":
                                            to_insert[key] = None
                                    
                                    inserted_id = database.insert_data(to_insert, "sim_management_inventory")
                                    if inserted_id:
                                        inserted = True
                                        logging.info(f"### telegence_bc_line_sync and {tenant_name} Inserted new MSISDN: {msisdn} with ID: {inserted_id}")
                                        
                                        # For new MSISDNs, all fields are considered as changes
                                        field_changes = {}
                                        for field, new_value in to_insert.items():
                                            if field not in ["id", "created_date", "modified_by", "tenant_id", "created_by", "is_active", "is_deleted"]:
                                                field_changes[field] = {
                                                    "old_value": None,
                                                    "new_value": new_value
                                                }
                                        
                                        if field_changes:
                                            changed_data.append({
                                                "field_changes": field_changes, 
                                                "id": inserted_id,
                                                "iccid": sim,
                                                "msisdn": api_data.get("subscriberNumber"),
                                                "old_record": {}  # Empty for new MSISDN
                                            })
                                except Exception as insert_error:
                                    logging.error(f"### telegence_bc_line_sync and {tenant_name} Failed to insert new MSISDN {msisdn}: {insert_error}")
                                    inserted = False
                                    
                            else:
                                # UPDATE existing MSISDN - use original update structure
                                old_record = next((item for item in old_inventory_data if item.get("msisdn") == subscriber_number), {})
                                logging.info(f"### Old inventory record for {msisdn}: {old_record}")
                                
                                if old_record:
                                    # Original update structure
                                    to_update = {
                                        #"effective_date": ,
                                        "username": first_name + " " + last_name,
                                        "msisdn": subscriber_number,
                                        "sim_status": subscriber_status,
                                        "msisdn": subscriber_number,
                                        "date_activated": date_activated,
                                        "rate_plan_soc": price_plan_code,
                                        "rate_plan_soc_description": description,
                                        "billing_account_number": ban,
                                        "modified_by": username,
                                        "billing_cycle_end_date": next_bill_date,
                                        "imei": imei,
                                    }
                                    
                                    # Convert empty strings to None for database
                                    for key, value in to_update.items():
                                        if value == "":
                                            to_update[key] = None
                                    
                                    exclude_fields = ["msisdn"]  
                                    keys_to_check = [key for key in to_update.keys() if key not in exclude_fields]
                                    to_update, field_changes = build_detailed_update_dict(to_update, old_record, keys_to_check)
                                    
                                    logging.info(f"### Field changes detected for {msisdn}: {field_changes}")
                                    
                                    if to_update:
                                        # Include the ID for update
                                        to_update["id"] = old_record["id"]
                                        to_update["modified_by"] = username
                                        
                                        # Remove empty strings from to_update to prevent database errors
                                        for key, value in list(to_update.items()):
                                            if value == "":
                                                to_update[key] = None
                                        
                                        updated = database.update_dict(
                                            "sim_management_inventory",
                                            values=to_update,
                                            and_conditions={"id": old_record["id"]},
                                        )
                                        
                                    # Store field changes for batch processing
                                    if field_changes:
                                        changed_data.append({
                                            "field_changes": field_changes, 
                                            "id": old_record["id"],
                                            "iccid": sim,
                                            "msisdn": subscriber_number,
                                            "old_record": old_record  # Add the old data for history
                                        })

                            # Add to successful IDs
                            successfull_ids.append(msisdn)

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": "Update telegence Subscriber: telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            # insert the log entries into detailed logs table
                            database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                            
                        # Prepare inventory log entry based on operation type
                        inventory_success = updated if not is_new_msisdn else inserted
                        operation_type = "Inserted" if is_new_msisdn else "Updated"
                        
                        inventory_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": f"{operation_type} Inventory Record",
                            "request_text": None,
                            "has_errors": not inventory_success,
                            "response_status": "PROCESSED" if inventory_success else "ERROR",
                            "response_text": f"Inventory {operation_type.lower()} successfully" if inventory_success else f"Inventory {operation_type.lower()} failed",
                            "error_text": "" if inventory_success else f"Inventory {operation_type.lower()} failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }

                        if inventory_log:
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")
                            # insert the log entries into detailed logs table
                            database.insert_data(inventory_log, "sim_management_bulk_change_detailed_logs")   
                            
                        return msisdn

                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        if msisdn in remaining:
                            remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_line_sync and {tenant_name} Error processing MSISDN: {e}")

                if INTERVAL and i + BATCH_SIZE < len(msisdns):
                    time.sleep(INTERVAL)
                
        # Handle and log invalid MSISDNs
        # prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username": username,
                                        "path": "/update_device_history_tables",
                                        "change_type": change_type,
                                        "iccids": [],
                                        "msisdns": successfull_ids,
                                        "service_provider": service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # api call to update the history table
            try:
                logging.info(f"### telegence_bc_line_sync and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_line_sync and {tenant_name} Exception in thread: {e}")

        if source == "Inventory" and changed_data:
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            
            # Use json.dumps with default=str for the entire payload
            action_history_payload = json.loads(json.dumps({
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": [],
                    "msisdns": successfull_ids,
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Line Sync",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_data": changed_data
                }
            }, default=str))
            # API call to update action history
            try:
                logging.info(f"###  telegence_bc_line_sync and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"###  telegence_bc_line_sync and {tenant_name} Exception in action history thread: {e}")
                
        # Handle and log invalid ICCIDs
        if invalid_ids:
            for request_id in invalid_ids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Update telegence Subscriber: Invalid MSISDN",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs, "sim_management_bulk_change_log")
            # insert the log entries into detailed logs table
            database.insert_data(logs, "sim_management_bulk_change_detailed_logs")

        # Mark invalid request IDs as processed
        if invalid_ids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"id": invalid_ids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        # sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # sync api to update the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### telegence_bc_line_sync and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id, 80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### telegence_bc_line_sync and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### telegence_bc_line_sync and {tenant_name} Exception in thread: {e}")
            
        # Return success
        logging.info(f"### telegence_bc_line_sync and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        
        # Prepare response
        response = {
            "flag": True,
            "processed": len(msisdns) - len(remaining),
            "remaining": len(remaining),
            "message": f"Bulk change request processed successfully. {len(new_msisdns)} new MSISDNs inserted, {len(existing_msisdns_list)} existing MSISDNs updated.",
            "msisdns": msisdns,
            "invalid_iccids": invalid_msisdns,
            "bulk_change_id": bulk_change_id,
            "new_msisdns_inserted": len(new_msisdns),
            "existing_msisdns_updated": len(existing_msisdns_list)
        }
       
        live_progress_percentage_tracker(database, bulk_change_id, 95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_line_sync",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for line sync. {len(new_msisdns)} new MSISDNs inserted, {len(existing_msisdns_list)} existing MSISDNs updated. Bulk Change ID: {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ## auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### telegence_bc_line_sync and {tenant_name} Audit logging failed: {e}")
            
        ## final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id, 100)
        
        # Prepare success response
        logging.info(f"### telegence_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### telegence_bc_line_sync and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data = {"errors": len(remaining), "status": "ERROR", "status_details": "Something went wrong while processing!"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "telegence_bc_line_sync",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### telegence_bc_line_sync and {tenant_name} Exception in logging error data to DB: {log_e}")
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_iccids": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        return response
    

def build_detailed_update_dict(api_record, inventory_row, keys_to_check):
    """
    Build update dictionary with detailed field-level change tracking
   
    Args:
        api_record (dict): Data from carrier API
        inventory_row (pd.Series): Current inventory data
        keys_to_check (list): Fields to compare
   
    Returns:
        tuple: (to_update_dict, field_changes_list)
    """
    to_update = {}
    field_changes = []
   
    for key in keys_to_check:
        api_value = api_record.get(key)
        current_value = inventory_row.get(key)
       
        # Handle different data types and None values
        if pd.isna(current_value) or current_value is None:
            current_value = ""
        if pd.isna(api_value) or api_value is None:
            api_value = ""
           
        # Convert to string for comparison
        str_current = str(current_value).strip() if current_value is not None else ""
        str_api = str(api_value).strip() if api_value is not None else ""
       
        if str_current != str_api:
            to_update[key] = api_value
            field_changes.append({
                'field': key,
                'previous_value': str_current,
                'current_value': str_api
            })
            logging.info(f"### Field changed: {key}, From: '{str_current}', To: '{str_api}'")
   
    return to_update, field_changes
 

# Reset Voicemail Password
def telegence_bc_reset_voicemail_password(data):
    """Reset voicemail password for the given devices.
    This function processes a list of MSISDNs and resets their voicemail password in the Telegence system.
    It handles bulk requests, updates the database, and logs the results.
    
    Args:
        data (dict): Input data containing the following keys:
            - msisdn (list): List of MSISDNs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Telegence API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Received data for reset voicemail password :{data}")
    start_time = time.time()
    
    # Required inputs 
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids = data.get("invalid_ids", [])
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    provider_parent_name = data.get("parent_provider_name", "")
    changed_data = data.get("changed_data", {})

    # Initialize remaining MSISDNs
    remaining = msisdns.copy()

    # Validate required fields
    log_entries = []
    success_ids = []
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} time is {now}")
    
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### telegence_bc_reset_voicemail_password and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    
    # Connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    
    try:
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id, 10)
    except Exception as e:
        logging.error(f"### telegence_bc_reset_voicemail_password and {tenant_name} Audit logging failed: {e}")
    
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                 service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        
        logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        
        # Get PIN from changed_data
        service_characteristics = changed_data.get("serviceCharacteristic", [])
        billingAccount= changed_data.get("billingAccount", {})
        billing_account_number= billingAccount.get("id", "")

        # Extract new PIN from service characteristics
        new_pin = ""
        for char in service_characteristics:
            if char.get("name") == "newPin":
                new_pin = char.get("value", "")
                break
        
        # Fetch bulk change rows to get request IDs
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number"]
        )
        if bulk_requests_df.empty:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_reset_voicemail_password",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### telegence_bc_reset_voicemail_password and {tenant_name} Audit logging failed: {e}")
                return response
        
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        
        ## Prepare headers for API call
        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "Content-Type": "application/json"
        }
        
        # Validate input data
        logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Validating input data for voicemail password reset")
        #logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Found {len(msisdn_to_billing_account)} billing accounts for {len(msisdns)} MSISDNs")
        
        # Carrier limits 
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### telegence_bc_reset_voicemail_password and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier details"}
        
        batch_size = carrier_limits.get("batch_size", 100)
        parallel_requests = carrier_limits.get("parallel_requests", 10)
        if parallel_requests > 10:
            logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests = 10
        interval = carrier_limits.get("interval_minutes", 0) * 60
        logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        
        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of MSISDNs
                batch = msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each MSISDN in the batch
                logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                
                for msisdn in batch:
                    bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
                    
                    def task(msisdn=msisdn):  
                        # Construct URL inside task
                        url = f"{carrier_api_url}/{msisdn}"
                        
                        # Construct payload inside task
                        payload = {
                            "requestType": "resetVoicemailPassword",
                            "billingAccount": {
                                "id": billing_account_number
                            },
                            "serviceCharacteristic": [
                                {
                                    "name": "newPin",
                                    "value": new_pin if new_pin else ""
                                }
                            ]
                        }
                        
                        success = False
                        result = ""
                        status = "API_FAILED"
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Attempting {attempt} for MSISDN: {msisdn} with URL: {url}")
                                logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Payload: {json.dumps(payload)}")
                                resp = requests.patch(
                                    url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                
                                # Check for success status codes
                                if resp.status_code == 200:
                                    success = True
                                    result = resp.text
                                    status = "PROCESSED"
                                    success_ids.append(msisdn)
                                    break
                                elif resp.status_code in [403, 404, 500, 503]:
                                    result = f"API Error {resp.status_code}: {resp.text}"
                                    logging.warning(f"### telegence_bc_reset_voicemail_password and {tenant_name} API Error {resp.status_code} for MSISDN: {msisdn}: {result}")
                                    break
                                else:
                                    result = f"Unexpected status {resp.status_code}: {resp.text}"
                                    logging.warning(f"### telegence_bc_reset_voicemail_password and {tenant_name} Unexpected status {resp.status_code} for MSISDN: {msisdn}")
                                    
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### telegence_bc_reset_voicemail_password and {tenant_name} Attempt {attempt} failed for MSISDN: {msisdn}: {result}")
                                if attempt < MAX_RETRIES:
                                    time.sleep(RETRY_DELAY)
                        
                        if success:
                            update_data = {
                                "status": status,
                                "has_errors": False,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details": result   
                            }
                        else:
                            update_data = {
                                "status": status,
                                "has_errors": True,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details": result
                            }
                        
                        # Update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                        )
                        
                        # Constructing the log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": "Reset Voicemail Password: Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": "PROCESSED" if success else "API_FAILED",
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
            
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs") 
                        return msisdn
                    
                    # Submit the task to the executor
                    logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                # Wait for all tasks in current batch to complete
                # Update the remaining list by removing successfully processed MSISDNs
                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        msisdn = fut.result()
                        if msisdn in remaining:
                            remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_reset_voicemail_password and {tenant_name} Error processing MSISDN: {e}")

        # Sleep between batches if interval is set
        if interval and i + batch_size < len(msisdns):
            time.sleep(interval)
        
        # Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Handle invalid MSISDNs
        live_progress_percentage_tracker(database, bulk_change_id, 75)
        if invalid_msisdns:
            logging.info(f"### Invalid MSISDNs found: {invalid_msisdns}")
            
            # Convert invalid MSISDNs to request IDs
            invalid_request_ids = []
            for msisdn in invalid_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                if request_id:
                    invalid_request_ids.append(request_id)
                    logging.info(f"### Mapped MSISDN {msisdn} to request ID {request_id}")
                else:
                    logging.warning(f"### No request ID found for invalid MSISDN: {msisdn}")
            
            # Log invalid MSISDNs
            for msisdn in invalid_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id or msisdn,  
                    "log_entry_description": "Reset voicemail password",
                    "request_text": "Reset Voicemail Password",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid MSISDN - could not be processed",
                    "error_text": "Invalid MSISDN",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
            
            # Update database
            if invalid_request_ids:
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {
                        "status": "ERROR",
                        "is_processed": True,
                        "has_errors": True,
                        "processed_date": now,
                        "status_details": "Invalid MSISDN - could not be processed"
                    },
                    and_conditions={"bulk_change_id": bulk_change_id},
                    in_conditions={"id": invalid_request_ids},  # Use request IDs here
                )
                logging.info(f"### Updated {len(invalid_request_ids)} invalid MSISDN records in database")
            else:
                logging.warning("### No valid request IDs found for invalid MSISDNs, skipping database update")
            
            # Insert log entries into DB
            if log_entries:
                database.insert_data(log_entries, "sim_management_bulk_change_log")
                #  insert the log entries into detailed logs table
                database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
                logging.info(f"telegence_bc_reset_voicemail_password and {tenant_name} Inserted {len(log_entries)} log entries for invalid MSISDNs")
        
        logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        
        response = {
            "flag": True, 
            "processed": len(msisdns) - len(remaining), 
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "msisdns": msisdns, 
            "invalid_msisdns": invalid_msisdns, 
            "bulk_change_id": bulk_change_id
        }
        
        # Sync APIs
        live_progress_percentage_tracker(database, bulk_change_id, 80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {
                    "bulk_change_id": bulk_change_id
                },
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        
        # Sync API for 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
            "data": {
                "access_token": access_token,
                "key_name": "telegence_bulkchange_sync",
                "path": "/bulk_change_sync_10_updated",
                "tenant_name": tenant_name,
                "bulk_change_id": bulk_change_id
            }
        }
        
        try:
            logging.info(f'### telegence_bc_reset_voicemail_password and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id, 90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f'### telegence_bc_reset_voicemail_password and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### telegence_bc_reset_voicemail_password and {tenant_name} Exception in thread: {e}")
        
        # Return success
        logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_reset_voicemail_password and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        
        ##auditing the sync completion
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Auditing"
        )
        live_progress_percentage_tracker(database, bulk_change_id, 95)
        
        # Attempt to audit the action
        try:
            end_time = time.time()
            time_consumed = end_time - start_time
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_reset_voicemail_password",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for resetting voicemail password for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### telegence_bc_reset_voicemail_password and {tenant_name} Audit logging failed: {e}")
        
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Completed"
        )
        live_progress_percentage_tracker(database, bulk_change_id, 100)
        return response
        
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_reset_voicemail_password and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        
        # Update error status
        remaining_count = len(msisdns)  
        error_update_data = {"errors": remaining_count, "status": "ERROR"}
        database.update_dict(
            "sim_management_bulk_change",
            error_update_data,
            and_conditions={"bulk_change_id": bulk_change_id},
        )
        
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_reset_voicemail_password and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
    


def billing_platform_bulk_change_20_sync(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    use_carrier_activation=data.get("use_carrier_activation")


    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}

        path_map = {
            "Update Device Status": "/bulk_update_device_status",
            "Change Customer Rate Plan": "/bulk_update_customer_rate_plan_service_line_creation",
            "Assign Customer": "/bulk_update_assign_customer_service_line_creation",
            "Change ICCID/IMEI": "/bulk_update_iccid_imei_service_line_creation"
        }
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        billing_flag=False
        billing_platform_flag=common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["billing_platform_flag"]
        )
        if not billing_platform_flag.empty:
            billing_flag = bool(billing_platform_flag.iloc[0]["billing_platform_flag"])
       
        if change_type in path_map:
            logging.info(f"Processing change request type: {change_type}")

            path = path_map[change_type]
            data['path'] = path
        columns = [
                "iccid",
                "subscriber_number",
                "m2m_id",
                "bulk_change_id",
                "tenant_name",
                "created_by",
                "processed_by",
                "status",
                "device_id",
                "is_active",
                "is_deleted",
                "change_request",
                "id"
            ]
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            columns
        )
        bulk_change_requests = []
        if not request_data.empty:
            bulk_change_requests = request_data.to_dict(orient="records")
        for rec in bulk_change_requests:
            rec["device_change_request_id"] = rec["iccid"]
        change_columns = [
            "service_provider",
            "change_request_type_id",
            "change_request_type",
            "service_provider_id",
            "modified_by",
            "status",
            "uploaded",
            "is_active",
            "is_deleted",
            "created_by",
            "processed_by",
            "tenant_id",
            "id_10"
        ]
        change_data = database.get_data(
            "sim_management_bulk_change",
            {"id": bulk_change_id,"status":"PROCESSED"},
            change_columns
        )
        bulk_change_records = []
        if not change_data.empty:
            bulk_change_records = change_data.to_dict(orient="records")
        
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
                "path":path,
                "data": {
                    "tenant_name":tenant_name,
                    "username": username,
                    "firstLastName": username,
                    "path": path,
                    "role_name": role_name,
                    "module_name": "Bulk Change",
                    "mod_pages": {
                    "start": 0,
                    "end": 100
                    },
                    "access_token": access_token,
                    "db_name": db_name,
                    "sessionID": None,
                    "request_received_at": now,
                    "Partner": tenant_name,
                    "service_provider_id":service_provider_id,
                    "bulkchange_id": bulk_change_id,
                    "data": {
                    "sim_management_bulk_change": bulk_change_records,         
                    "sim_management_bulk_change_request": bulk_change_requests
                    },
                    "bulk_chnage_id_20": bulk_change_id,
                    "use_carrier_activation": use_carrier_activation,
                    "carrier_api_status": True,
                    "billing_platform_flag": billing_flag
                }
                }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": data.get("Partner",""),
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "Sim Management",
                "request_received_at": data.get("request_received_at",""),
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": data.get("username",""),
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}
    
def update_for_partner_to_provider(data, primary_key):
    """
    Updates inventory data for a partner becoming a provider.
    Supports multiple MSISDNs/ICCID, source DBs, and target DBs.

    Parameters:
        data (dict): Input data including db info, changed_data, target_details, etc.
        primary_key (str): Either 'msisdn' or 'iccid'.

    Returns:
        dict: Response dict with 'flag' and 'message'.
    """
    logging.info(f"### Starting update_for_partner_to_provider with data: {data}")
    start_time = time.time()
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    changed_data = data.get('changed_data', [])
    change_type = data.get('change_event_type')
    provider_parent_name = data.get('provider_parent_name')
    db_name = data.get('db_name', '')
    tenant_id = data.get('tenant_id', '')
    carrie_rate_plan=data.get('carrie_rate_plan','')
    customer_rate_plan_name=data.get('customer_rate_plan_name','')
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    bulk_change_id = data.get("bulk_change_id")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    service_provider= data.get("service_provider","")
    column_map = {
        "Update PPU address": ["user_address", "modified_by"],
        "Update Features": ["telegence_features", "modified_by"],
        "Change Phone Number": ["msisdn", "modified_by"],
        "Change Carrier Rate Plan": ["modified_by"],
        "Update Device Status": ["sim_status", "modified_by"],
        "Change Customer Rate Plan": ["modified_by"],
        "Archive": ["is_active", "is_deleted"],
        "Change ICCID/IMEI":["imei","iccid","modified_by"],
        "Edit Username/Cost Center": ["username", "cost_center", "modified_by"],
        "Activate New Service":["iccid","msisdn","imei","billing_account_number","tenant_id",
                                "is_active","is_deleted","tenant_is_active","tenant_is_deleted",
                                "service_provider_is_active","created_by","created_date",
                                "service_provider_display_name","sim_status","service_provider_id",
                                "device_status_id","foundation_account_number","modified_by"],
        "Refresh A Line": ["modified_by", "effective_date", "carrier_rate_plan_id", 
                           "carrier_rate_plan_name", "service_zip_code", "billing_account_number", 
                           "username", "iccid", "imei", "next_bill_cycle_date", "telegence_features"]
    }
    if not changed_data or not primary_key:
        logging.error("### changed_data or primary_key is missing.")
        message=f"changed_data or primary_key is missing for bulk change id {bulk_change_id}."
        response={"flag":False,"message":message}
        #return {"flag": False, "message": "changed_data or primary_key is missing."}
        try:
                end_time = time.time()
                time_consumed = end_time - start_time
                time_consumed = int(round(time_consumed))
                audit_data_user_actions = {
                    "service_name": "update_for_partner_to_provider",
                    "created_by": username,
                    "status": json.dumps(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": message,
                    "request_received_at": now,
                }
            
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"###update_for_partner_to_provider and {tenant_name} Audit logging failed: {e}")
        return response

    try:
        # DB connections
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_db = DB(db_name, **db_config)
    except Exception as e:
        logging.exception("### Failed to connect to databases")
        return {"flag": False, "message": "Database connection error"}

    try:
        if isinstance(changed_data, dict):
            changed_data = [changed_data]

        # Flatten primary key values
        key_values = list(set(
            str(v)
            for entry in changed_data
            if primary_key in entry
            for v in (entry[primary_key] if isinstance(entry[primary_key], list) else [entry[primary_key]])
        ))
        logging.info(f"### Normalized key_values: {key_values}")

        # if not key_values:
        #     return {"flag": False, "message": f"No valid {primary_key} values provided."}
        if not key_values:
                message=f"No valid {primary_key} values provided for bulk change id {bulk_change_id}."
                response={"flag":False,"message":message}
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "update_for_partner_to_provider",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###update_for_partner_to_provider and {tenant_name} Audit logging failed: {e}")
                return response

        # Fetch source  and target details
        details_df = tenant_db.get_data(
            "sim_management_inventory",
            {"is_active": True, primary_key: key_values, "tenant_id": tenant_id,"service_provider_display_name": service_provider},
            ["source_id", "source_db", "target_details", primary_key]
        )
        # Build details map
        details_map = {}
        if not details_df.empty:
            details_map = {
                row[primary_key]: {
                    "source_id": row["source_id"],
                    "source_db": row["source_db"],
                    "target_details": row["target_details"]
                }
                for _, row in details_df.iterrows()
            }
        logging.info(f"### details_map: {details_map}")        
        source_db_map = defaultdict(list)
        for key_val in key_values:
            if key_val in details_map and details_map[key_val].get("source_db"):
                source_db_map[details_map[key_val]["source_db"]].append(key_val)
        # Get DB configs for all involved DBs
        dbconfig_details=common_utils_database.get_data(
            "tenant",
            {"is_active":True,"db_config":"not Null","parent_tenant_id":"Null"},
            ["db_name","db_config","tenant_name"]
        )
        # handling multi rds configs
        dbname_config_mapping=dict(zip(dbconfig_details.db_name ,dbconfig_details.db_config))
        dbname_tenant_mapping = dict(zip(dbconfig_details.db_name, dbconfig_details.tenant_name))
        db_config_per_db = {
            db_name: {
                "host": conf.get("hostname") or conf.get("host"),
                "port": conf.get("port"),
                "user": conf.get("user"),
                "password": conf.get("password"),
                "multi_schema":False
            }
            for db_name, conf in dbname_config_mapping.items()
        }
        # enter if block if source dbs are present
        if source_db_map:
            def update_source_db(source_db, msisdn_list):
                db_config = db_config_per_db.get(source_db)
                logging.info(f"### Updating source DB: {source_db} for keys: {msisdn_list} with config: {db_config} and {carrie_rate_plan}")
                db_instance = DB(source_db, **db_config)
                records_to_update = []
                for key_val in msisdn_list:
                    record_data = [rec for rec in changed_data if key_val in (rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]])]
                    ##fetching the changed data for source db update
                    record_data = fetching_the_changed_data(
                        record_data,
                        db_instance,
                        column_map,
                        change_type,
                        provider_parent_name,
                        tenant_db,
                        primary_key,
                        tenant_id,
                        common_utils_database,
                        username,
                        source_db,carrie_rate_plan
                    )
                    ## preparing the data for source db update
                    for rec in record_data:
                        records_to_update.append({primary_key: key_val, **{k:v for k,v in rec.items() if k != primary_key}})
                ## bulk update or insert into source db
                if records_to_update and change_type != "Activate New Service":
                    db_instance.bulk_update_data("sim_management_inventory", records_to_update, search_column=primary_key)
                    logging.info(f"Updated source DB {source_db}, rows: {records_to_update}")
                else:
                    ## for activate new service inserting the records
                    db_instance.insert_data(records_to_update, "sim_management_inventory")
                    logging.info(f"Inserted into source DB {source_db}, rows: {records_to_update}")
                # Trigger sync API for source DB
                try:
                    api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
                    call_data_sync_for_source = {
                            "data": {
                            "key_name": "m2m_inventory_live_sync_from_20",
                            "path": "/lambda_sync_jobs_",
                            "tenant_db_name": source_db,
                            "service_provider_name": provider_parent_name,
                            "msisdn_list": msisdn_list,
                            "target_tenant_id":tenant_id,
                            "target_tenant_name":tenant_name,
                            "pbp_flag":True,
                            "primary_key":primary_key
                            }
                    }
                    logging.info(f"### Scheduling additional sync API call  with payload: {call_data_sync_for_source}")
                    threading.Timer(1.0, call_sync_api, args=(api_sync_url, call_data_sync_for_source)).start()
                    logging.info(f"### Source DB API call scheduled for DB: {source_db}")
                except Exception as e:
                    logging.exception(f"### Exception during source DB API trigger: {e}")

            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures = [executor.submit(update_source_db, db_name, msisdn_list) for db_name, msisdn_list in source_db_map.items()]
                for future in concurrent.futures.as_completed(futures):
                    future.result()
        per_db_changed = defaultdict(list)
        for key_val, details in details_map.items():
            target_list = details.get("target_details") or []            
            if target_list:  # Only include if target_details exist
                for target_map in target_list:
                    if isinstance(target_map, dict):
                        for db_name, target_id in target_map.items():
                            per_db_changed[db_name].append({
                                primary_key: key_val,
                                "targetid": target_id  
                            })
        logging.info(f"### per_db_changed: {dict(per_db_changed)}") 
        futures = {}  # ✅ MUST be defined upfront
        target_id=None
        # Update target DBs       
        if per_db_changed:   
            changed_lookup = {}
            for rec in changed_data:
                vals = rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]]
                for v in vals:
                    changed_lookup[str(v).strip()] = rec
            # Determine required columns
            required_columns = column_map.get(change_type, [])
            required_columns = [primary_key] + required_columns 
            key_values = list(changed_lookup.keys())
            if not key_values:
                logging.warning(f"### No valid {primary_key} values in changed_data")
                return []
            # Fetch inventory data from target_database
            inventory_df = tenant_db.get_data(
                "sim_management_inventory",
                {primary_key: key_values,"tenant_id":tenant_id, "is_active": True},
                required_columns
            )     
            if customer_rate_plan_name:
                customer_rate_plan_data=tenant_db.get_data('customerrateplan',{'rate_plan_name':customer_rate_plan_name,"tenant_id":tenant_id,"is_active":True})
                if customer_rate_plan_data.empty:
                    customer_rate_plan_data=None
                else:
                    customer_rate_plan_data=customer_rate_plan_data.to_dict(orient='records')[0]
            else:
                customer_rate_plan_data=None
            tenant_data = common_utils_database.get_data(
                "tenant",
                {"is_active": True},
                ["id", "parent_tenant_id"]
            )
            def update_target_db(db_name, changed_list):
                db_config = db_config_per_db.get(db_name)
                target_db = DB(db_name, **db_config)
                if per_db_changed:
                    target_ids=per_db_changed[db_name]
                    if target_ids:
                        target_id = per_db_changed[db_name][0]["targetid"]
                logging.info(f"target_id is {target_id} and db_name is {db_name}")
                updated_data = fetching_the_changed_data_source_to_target_updates(
                    changed_list,
                    target_db,
                    change_type,
                    primary_key,
                    inventory_df,
                    changed_lookup,
                    required_columns,db_name,
                    target_id,customer_rate_plan_name,
                    common_utils_database,
                    username,customer_rate_plan_data,tenant_data
                )
                if updated_data:
                    updated_rows =target_db.bulk_update_data(
                        "sim_management_inventory",
                        updated_data,
                        search_column=primary_key
                    )
                    logging.info(f"Updated target DB {db_name}, rows: {len(updated_data)},updated_rows :{updated_rows }")
            # Run updates concurrently per target DB
            with concurrent.futures.ThreadPoolExecutor() as executor:
                for db_name, data_list in per_db_changed.items():
                    logging.info(
                        f"Scheduling update for target DB: {db_name} with {len(data_list)} records"
                    )
                    future = executor.submit(update_target_db, db_name, data_list)
                    futures[future] = db_name
                logging.info(f"Futures is  {futures} with {db_name} db_name")

                for future in concurrent.futures.as_completed(futures):
                    db_name = futures[future]
                    try:
                        future.result()
                        logging.info(f"Successfully updated target DB: {db_name}")
                    except Exception:
                        logging.exception(f"Error updating target DB: {db_name}")
        try:
            # Prefer source DBs if any exist
            if source_db_map:
                db_list = list(source_db_map.keys())
            else:
                # fallback to target DBs
                db_list = list(per_db_changed.keys())
                for db_name in db_list:
                    tenant_for_api = dbname_tenant_mapping.get(db_name)
                    logging.info(f"### Preparing API for DB: {db_name}, tenant: {tenant_for_api}")

                    # Main API payload
                    api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
                    api_payload = {
                        "data": {
                            "access_token": access_token,
                            "data": {"bulk_change_id": bulk_change_id},
                            "db_name": db_name,
                            "is_update": True,
                            "module_name": "Bulk Change",
                            "Partner": tenant_name,
                            "path": "/update_bulk_change_tables_10",
                            "request_received_at": now,
                            "role_name": role_name,
                            "tenant_name": tenant_for_api,
                            "username": username
                        }
                    }

                    # Sync API payload
                    api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
                    api_sync_payload = {
                        "data": {
                            "access_token": access_token,
                            "key_name": "telegence_bulkchange_sync",
                            "path": "/bulk_change_sync_10_updated",
                            "tenant_name": tenant_for_api,
                            "bulk_change_id": bulk_change_id
                        }
                    }
                    if change_type == "Activate New Service":
                        # Additional data sync payload
                        data_sync = {
                            "data": {
                                "data": {
                                    "key_name": "verizon_inventory",
                                    "path": "/lambda_sync_jobs_",
                                    "tenant_name": tenant_for_api
                                }
                            }
                        }
                        logging.info(f"### Scheduling additional sync API call for Activate New Service to {api_sync_url} with payload: {data_sync}")
                        threading.Timer(10.0, call_sync_api, args=(api_sync_url, data_sync)).start()
                    # Trigger both APIs (10s delay)
                    threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
                    threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
        except Exception as e:
            logging.exception(f"### Exception during API trigger: {e}")
        
        response = {"flag": True, "message": "Inventory data update executed successfully"}
        try:
            audit_data = {
                "service_name": "update_for_partner_to_provider",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully executed inventory update, data: {json.dumps(data)}",
                "request_received_at": request_received_at
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception in auditing: {e}")

        return response

    except Exception as e:
        logging.error(f"### Exception: {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "update_for_partner_to_provider",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"Failed executing inventory update, data: {json.dumps(data)}",
                "module_name": "Partner Becoming Provider",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error executing inventory data update: {e}"}

def fetching_the_changed_data_source_to_target_updates(changed_data, target_database, 
                              change_type,primary_key,inventory_df,
                              changed_lookup,required_columns,db_name,target_id,customer_rate_plan_name,
                              common_utils_database,
                                username,customer_rate_plan_data,tenant_data):
    """
    Fetches inventory data from target_database and rebuilds changed_data with required fields.
    Optimized for bulk/threaded updates.

    Parameters:
        changed_data (list[dict]): List of changed records.
        source_database (DB): Source database connection.
        change_column_map (dict): Columns to fetch for each change_type.
        change_type (str): Type of change event.
        parent_provider_name (str): Provider name.
        target_database (DB): Target database connection.
        map_id_field (str): Field name to map source/target ID ('source_id'/'target_id').
        primary_key (str): Primary key to fetch data by ('id', 'msisdn', 'iccid').

    Returns:
        list[dict]: Updated changed_data with mapped IDs and required fields.
    """
    logging.info(f"### fetching_the_changed_data called target_id {target_id} for change_type:{db_name}db_name: {change_type}, primary_key: {primary_key}")

    if not changed_data:
        return []
    integration_id = None
    target_carrier_rate_plan_id=None
    target_carrier_rate_plan_name=None
    parent_tenant_id=None
    integration_df = target_database.get_data(
        'sim_management_inventory', {'id': target_id}, ['integration_id','service_provider_display_name','tenant_id','service_provider_id']
    )
    if not integration_df.empty:
        integration_id = int(integration_df.iloc[0]["integration_id"])
        service_provider = integration_df.iloc[0]["service_provider_display_name"]
        tenant_id = int(integration_df.iloc[0]["tenant_id"])
        service_provider_id = int(integration_df.iloc[0]["service_provider_id"])
    else:
        integration_id = None
        service_provider = None
        tenant_id=None
    if tenant_id:
        # Filter the row for the given tenant_id
        tenant_row = tenant_data[tenant_data["id"] == tenant_id]
        if not tenant_row.empty:
            parent_tenant_id = tenant_row["parent_tenant_id"].iloc[0]
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
        else:
            parent_tenant_id=None
    logging.info(f"fetching_the_changed_data_source_to_target_updates parent_tenant_id {parent_tenant_id}")
    if change_type in ('Change Customer Rate Plan') and not parent_tenant_id: 
        if not parent_tenant_id:
            carrier_rate_plan_df = target_database.get_data(
                "carrier_rate_plan",
                {"friendly_name": customer_rate_plan_name, "is_active": True},
                ["id"]
            )
            logging.info(f"fetching_the_changed_data_source_to_target_updates customer rate plan to carrier rate plan flow")
            if not carrier_rate_plan_df.empty:
                target_carrier_rate_plan_id=carrier_rate_plan_df['id'].to_list()[0]
                target_carrier_rate_plan_name=customer_rate_plan_name
            else:
                carrier_rate_plan_payload = {
                    "rate_plan_code": customer_rate_plan_data["rate_plan_code"],
                    "friendly_name": customer_rate_plan_data["rate_plan_name"],
                    "service_provider": service_provider,
                    "service_provider_id": service_provider_id,
                    "base_rate": customer_rate_plan_data["base_rate"],
                    "plan_mb": customer_rate_plan_data["plan_mb"],
                    "overage_rate_cost": customer_rate_plan_data["overage_rate_cost"],
                    "surcharge_3g": customer_rate_plan_data["surcharge_3g"],
                    "rate_charge_amt": customer_rate_plan_data["rate_charge_amt"],
                    "display_rate": customer_rate_plan_data["display_rate"],
                    "base_rate_per_mb": customer_rate_plan_data["base_rate_per_mb"],
                    "data_per_overage_charge": customer_rate_plan_data["data_per_overage_charge"],
                    "is_active": customer_rate_plan_data["is_active"],
                    "is_deleted": customer_rate_plan_data["is_deleted"],
                    "created_by": username,
                    "modified_by": username,
                    "allows_sim_pooling": customer_rate_plan_data["allows_sim_pooling"],
                    "rate_plan_short_name": customer_rate_plan_data["soc_code"],
                    "assigned":False,
                    "source_id":customer_rate_plan_data["id"],
                    "is_retired":False,   
                }
                target_carrier_rate_plan_id=target_database.insert_data(carrier_rate_plan_payload,
                            'carrier_rate_plan'
                        )
                target_carrier_rate_plan_name=customer_rate_plan_name

            
    logging.info(f"### fetching_the_changed_data called for {target_id} target_id change_type {integration_id} and service_provider is {service_provider}")
    rate_plan_map = {}
    if change_type in ('Change Carrier Rate Plan', 'Refresh A Line'):
        carrier_rate_plan_df = target_database.get_data(
            "carrier_rate_plan",
            {"service_provider": service_provider, "is_active": True},
            ["id", "rate_plan_short_name"]
        )
        if isinstance(carrier_rate_plan_df, pd.DataFrame) and not carrier_rate_plan_df.empty:
            rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()}
    # Device status mapping
    device_status_map = {}
    if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and integration_id:
        device_status_df = target_database.get_data(
            "device_status",
            {"integration_id": integration_id,"is_active":True},
            ["id", "status", "description", "display_name"]
        )
        for _, row in device_status_df.iterrows():
            for col in ["status", "description", "display_name"]:
                val = row.get(col)
                if val:
                    device_status_map[val.lower()] = row["id"]
    # Rebuild changed_data with required fields
    updated_data = []
    for _, row in inventory_df.iterrows():
        key_val = str(row[primary_key]).strip()
        entry = changed_lookup.get(key_val)
        if not entry:
            continue

        # Carrier rate plan mapping
        plan_name = row.get("carrier_rate_plan_name")
        new_entry = {}
        if change_type in ('Change Customer Rate Plan') and not parent_tenant_id: 
            if target_carrier_rate_plan_id:
                new_entry["carrier_rate_plan_id"] = target_carrier_rate_plan_id
                new_entry["carrier_rate_plan_name"] = target_carrier_rate_plan_name
        elif change_type in ('Change Customer Rate Plan') and  parent_tenant_id: 
            new_entry["sub_tenant_carrier_rate_plan_name"] = customer_rate_plan_name
            if plan_name:
                if plan_name in rate_plan_map:
                    new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
                    new_entry["carrier_rate_plan_name"] = plan_name
        else:
            if plan_name:
                if plan_name in rate_plan_map:
                    new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
                    new_entry["carrier_rate_plan_name"] = plan_name
        # Device status mapping
        if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and "sim_status" in row:
            sim_status_val = str(row["sim_status"]).lower()
            if sim_status_val in device_status_map:
                new_entry["device_status_id"] = device_status_map[sim_status_val]
        # Build new entry with required columns
        for col in required_columns:
            if col in row and col not in new_entry:
                new_entry[col] = row[col]
        # Add modified_by if exists
        if "modified_by" in row:
            new_entry["modified_by"] = row["modified_by"]

        updated_data.append(new_entry)

    logging.info(f"### fetched {updated_data} records in fetching_the_changed_data")
    return updated_data


def fetching_the_changed_data(changed_data, source_database, change_column_map,
                              change_type, parent_provider_name, target_database,
                              primary_key,tenant_id,common_utils_database,username,source_db,carrie_rate_plan):
    """
    Fetches inventory data from target_database and rebuilds changed_data with required fields.
    Optimized for bulk/threaded updates.

    Parameters:
        changed_data (list[dict]): List of changed records.
        source_database (DB): Source database connection.
        change_column_map (dict): Columns to fetch for each change_type.
        change_type (str): Type of change event.
        parent_provider_name (str): Provider name.
        target_database (DB): Target database connection.
        map_id_field (str): Field name to map source/target ID ('source_id'/'target_id').
        primary_key (str): Primary key to fetch data by ('id', 'msisdn', 'iccid').

    Returns:
        list[dict]: Updated changed_data with mapped IDs and required fields.
    """
    logging.info(f"### fetching_the_changed_data called for change_type: {change_type}, primary_key: {primary_key} and carrie_rate_plan  {carrie_rate_plan}")
    source_customer_rate_plan_insertion_id=None
    try:
        if not changed_data:
            return []
        parent_tenant_id=None
        parent_tenant_dataframe=common_utils_database.get_data('tenant',{'id':tenant_id},['parent_tenant_id'])
        if not parent_tenant_dataframe.empty:
            parent_tenant_id=parent_tenant_dataframe['parent_tenant_id'].to_list()[0]
        integration_id = None
        integration_df = source_database.get_data(
            'serviceprovider', {'service_provider_name': parent_provider_name}, ['integration_id','id']
        )
        if not integration_df.empty:
            integration_id = int(integration_df['integration_id'].iloc[0])
            parent_service_provider_id = int(integration_df['id'].iloc[0])
        changed_lookup = {}
        for rec in changed_data:
            vals = rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]]
            for v in vals:
                changed_lookup[str(v).strip()] = rec
        # Determine required columns
        required_columns = change_column_map.get(change_type, [])
        required_columns = [primary_key] + required_columns 
        key_values = list(changed_lookup.keys())
        if not key_values:
            logging.warning(f"### No valid {primary_key} values in changed_data")
            return []
        # Fetch inventory data from target_database
        inventory_df = target_database.get_data(
            "sim_management_inventory",
            {primary_key: key_values,"tenant_id":tenant_id, "is_active": True},
            required_columns
        )
        rate_plan_map = {}
        if change_type in ('Change Carrier Rate Plan') and not parent_tenant_id:
            logging.info(f"fetching_the_changed_data carrire_rate_plan_name is {carrie_rate_plan}")
            source_tenant_id=common_utils_database.get_data('tenant',{'db_name':source_db,'parent_tenant_id':'Null'},['id'])['id'].to_list()[0]
            carrier_rate_plan_data=target_database.get_data('carrier_rate_plan',{'rate_plan_code':carrie_rate_plan})
            # If not found using friendly_name, try with rate_plan_short_name
            if carrier_rate_plan_data.empty:
                carrier_rate_plan_data = target_database.get_data(
                    'carrier_rate_plan',
                    {'friendly_name': carrie_rate_plan}
                )

            # Proceed only if data is found
            if not carrier_rate_plan_data.empty:
                row = carrier_rate_plan_data.iloc[0]
                # ✅ Take friendly_name from carrier_rate_plan table
                friendly_name = row.get("friendly_name")
                customer_rate_plan_data=source_database.get_data('customerrateplan',{'rate_plan_name':friendly_name,'tenant_id':source_tenant_id},['id','rate_plan_name'])
                if not customer_rate_plan_data.empty:
                    source_customer_rate_plan_insertion_id=customer_rate_plan_data['id'].to_list()[0]
                    source_customer_rate_plan=customer_rate_plan_data['rate_plan_name'].to_list()[0]
                else:
                    customer_rate_plan_payload = {
                        "tenant_id": int(source_tenant_id),
                        "rate_plan_name": row["friendly_name"],
                        "rate_plan_code": row["rate_plan_code"],
                        "service_provider_name":parent_provider_name,
                        "service_provider_id":parent_service_provider_id,
                        "base_rate": clean_value(row["base_rate"]),
                        "sms_rate": clean_value(row["base_rate"]),
                        "plan_mb": clean_value(row["plan_mb"]),
                        "overage_rate_cost": clean_value(row["overage_rate_cost"]),
                        "surcharge_3g": clean_value(row["surcharge_3g"]),
                        "created_by": username,
                        "modified_by": username,
                        "rate_charge_amt": clean_value(row["rate_charge_amt"]),
                        "display_rate": clean_value(row["display_rate"]),
                        "base_rate_per_mb": clean_value(row["base_rate_per_mb"]),
                        "is_active": True,
                        "is_deleted": False,
                        "soc_code": row["rate_plan_short_name"],
                        "service_provider_id": int(row["service_provider_id"]),
                        "data_per_overage_charge": clean_value(row["data_per_overage_charge"]),
                        "allows_sim_pooling": bool(row["allows_sim_pooling"]),
                        "pbp_flag": True
                    }
                    source_customer_rate_plan_insertion_id=source_database.insert_data(customer_rate_plan_payload,
                        'customerrateplan'
                    )
                    source_customer_rate_plan=customer_rate_plan_payload.get('rate_plan_name','')
        if change_type in ('Refresh A Line'):
            carrier_rate_plan_df = source_database.get_data(
                "carrier_rate_plan",
                {"service_provider": parent_provider_name, "is_active": True},
                ["id", "rate_plan_short_name"]
            )
            if isinstance(carrier_rate_plan_df, pd.DataFrame) and not carrier_rate_plan_df.empty:
                rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()}
        # Device status mapping
        device_status_map = {}
        if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and integration_id:
            device_status_df = source_database.get_data(
                "device_status",
                {"integration_id": integration_id},
                ["id", "status", "description", "display_name"]
            )
            for _, row in device_status_df.iterrows():
                for col in ["status", "description", "display_name"]:
                    val = row.get(col)
                    if val:
                        device_status_map[val.lower()] = row["id"]
        # Rebuild changed_data with required fields
        updated_data = []
        for _, row in inventory_df.iterrows():
            key_val = str(row[primary_key]).strip()
            entry = changed_lookup.get(key_val)
            if not entry:
                continue
            new_entry = {}
            if change_type in ('Refresh A Line'):
                # Carrier rate plan mapping
                plan_name = row.get("carrier_rate_plan_name")
                if plan_name:
                    if plan_name in rate_plan_map:
                        new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
                    new_entry["carrier_rate_plan_name"] = plan_name
            if change_type in ('Change Carrier Rate Plan') and not parent_tenant_id:
                if source_customer_rate_plan_insertion_id:
                    new_entry["customer_rate_plan_id"] = source_customer_rate_plan_insertion_id
                    new_entry["customer_rate_plan_name"] = source_customer_rate_plan
                    logging.info(f"source_customer_rate_plan {source_customer_rate_plan} and source_customer_rate_plan_insertion_id {source_customer_rate_plan_insertion_id}")
            # Device status mapping
            if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and "sim_status" in row:
                sim_status_val = str(row["sim_status"]).lower()
                if sim_status_val in device_status_map:
                    new_entry["device_status_id"] = device_status_map[sim_status_val]
            # Build new entry with required columns
            for col in required_columns:
                if col in row and col not in new_entry:
                    new_entry[col] = row[col]
            # Add modified_by if exists
            if "modified_by" in row:
                new_entry["modified_by"] = row["modified_by"]

            updated_data.append(new_entry)

        logging.info(f"### fetched {updated_data} records in fetching_the_changed_data")
        return updated_data
    except Exception as e:
        logging.exception(f"### Exception in fetching_the_changed_data: {e}")
        return []

def clean_value(val):
    if isinstance(val, (np.bool_,)):
        return bool(val)
    if isinstance(val, (np.integer,)):
        return int(val)
    if isinstance(val, (np.floating,)):
        return float(val)
    return val

def telegence_bc_private_network_ip(data):
    """
    Change Private Network IP Address for Telegence Devices.

    This function processes bulk change requests to update the private network IP address 
    for Telegence devices. It interacts with the Verizon Carrier API, handles retries, 
    logs all actions, updates the inventory and bulk change tables, and performs synchronization 
    with 1.0 and module management systems. The function also supports progress tracking, 
    audit logging, and error handling for invalid ICCIDs or failed API calls.
    
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - created_by (str): Username of the user who initiated the request.
            - service_provider (str): Name of the carrier (Telegence in this case).
            - change_type (str): Type of bulk change being performed (Private Network IP Change).
            - tenant_id (str): Unique identifier of the tenant.
            - tenant_name (str): Name of the tenant.

    Returns:
        dict: A dictionary containing the result of the bulk change operation with the following keys:
            - flag (bool): True if processing was successful, False otherwise.
            - message (str): Summary of the operation result.
    """
    logging.info(f"### Recevied data for telegence_private_network_ip :{data}")
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    iccid_ip_map=data.get("iccid_ip_map",{})		

    # Initialize for log entries
    log_entries = []
    succesful_msisdns=[]
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### telegence_bc_private_network_ip and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### telegence_bc_private_network_ip and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### telegence_bc_private_network_ip and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "telegence_bc_private_network_ip",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###telegence_bc_private_network_ip and {tenant_name} Audit logging failed: {e}")
                return response
            live_progress_percentage_tracker(database, bulk_change_id,20)

        # Map msisdns to request IDs
        if isinstance(change_request_json, str):
            change_request_json = json.loads(change_request_json)

        # Extract IP address from the correct nested structure
        try:
            # Get the changedData section
            changed_data = change_request_json.get("changedData", {})
            logging.info(f"### telegence_bc_private_network_ip and {tenant_name} changed_data: {changed_data}")
            # Get the subscriber array
            subscribers = changed_data.get("subscriber", [])
            
            # if subscribers:
            #     # Get the first subscriber's ipAddressRecord
            #     ip_address_record = subscribers[0].get("ipAddressRecord", {})
            #     ip_address = ip_address_record.get("ipAddress", "")
            # else:
            #     ip_address = ""
                
            # if ip_address:
            #     update_fields = {"ip_address": ip_address}
            # else:
            #     logging.error("### telegence_bc_private_network_ip Ip address is missing in change request data")
                
        except Exception as e:
            logging.error(f"### telegence_bc_private_network_ip and {tenant_name} Error parsing change request data: {e}")
            return {"flag": False, "message": f"Error parsing change request data: {str(e)}"}   
        bulk_requests_df = bulk_requests_df.rename(columns={'subscriber_number': 'msisdn'})
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))
        msisdn_to_changerequest = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.change_request))
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### telegence_bc_private_network_ip and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "msisdn": msisdns,"tenant_id": tenant_id},
                ["id","iccid","msisdn", "ip_address"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###telegence_bc_private_network_ip and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        remaining = list(msisdns) 
        # Get access token and session ID
        logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Fetching access token and session ID")

        #constracting header 
        headers = {
            "app-id": app_id,
            "app-secret": app_secret,
            "Content-Type": "application/json"
        }
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")

        # Chunking msisdns and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of msisdns
                batch = msisdns[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each msisdn in the batch
                logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} msisdns")
                for msisdn in batch:
                    # Prepare the URL and payload for the API call
                    def task(msisdn=msisdn): 
                        result = "" 
                        success = False
                        result = ""
                        status = "API_FAILED"
                        url = f"{carrier_api_url}"
                        #payload=msisdn_to_changerequest.get(msisdn)
                        payload_str = msisdn_to_changerequest.get(msisdn)
                        # Handle both JSON string or dict
                        if isinstance(payload_str, str):
                            request_payload = json.loads(payload_str)
                        else:
                            request_payload = payload_str
                        payload = request_payload.get("changedData", {})
                        # Add indicators
                        payload["lteIndicator"] = True
                        payload["defaultAPNIndicator"] = True
                        if iccid_ip_map:
                            ip_address=iccid_ip_map.get(msisdn,"") 
                        else:
                            ip_address="" 
                        if ip_address : 
                            update_fields = {"ip_address":ip_address}
                        # Update subscriberNumber safely
                        try:
                            subscribers = payload.get("subscriber", [])
                            if subscribers and isinstance(subscribers, list):
                                subscribers[0]["subscriberNumber"] = msisdn
                                # Get ipAddressRecord for the first subscriber
                                ip_record = subscribers[0].get("ipAddressRecord", {})
                                if isinstance(ip_record, dict):
                                    ip_record["ipAddressType"] = "IPv4" # for testing purpose we are hardcoding the value
                                    ip_record["ipAddressCode"] = "T01"  # for testing purpose we are hardcoding the value
                                    ip_record["ipAddress"] = ip_address
                                else:
                                    logging.warning(f"### No ipAddressRecord found for {msisdn}")
                            else:
                                logging.warning(f"### No subscriber list found for {msisdn}")
                        except Exception as e:
                            logging.error(f"### Failed adding subscriberNumber for {msisdn}: {e}")
                        # Making the API call with retries        
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Attempting {attempt} for msisdn: {msisdn} with URL: {url}")
                                logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Payload for msisdn {msisdn}: {json.dumps(payload)}")
                                resp = requests.post(
                                    url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Response Code: {resp.status_code} for msisdn: {msisdn}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                # status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    response_json = resp.json()
                                    message = response_json.get("message", "")
                                    batch_id = None
                                    match = re.search(r"batch-id:\s*([\w-]+)", message, re.IGNORECASE)
                                    if match:
                                        batch_id = match.group(1)
                                    logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Success for msisdn: {msisdn} with batch ID: {batch_id} in response{response_json}")
                                    break
                                else:
                                    logging.warning(f"### telegence_bc_private_network_ip and {tenant_name} Attempt {attempt} failed for msisdn: {msisdn} with status code {resp.status_code} and response: {resp.text}") 
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### telegence_bc_private_network_ip and {tenant_name} Attempt {attempt} failed for msisdns: {msisdn}: {result}")
                                time.sleep(RETRY_DELAY)
                        # for callback url processing   
                        update_data = {
                            "status": status,
                            "has_errors": not success,
                            "is_processed":  True,
                            "processed_date": now,
                            "status_details":result   
                        }

                        #update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                            )                        
                        # Constructing the log entry
                        log = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                        "log_entry_description": "Update Telegence Subscriber: Telegence API",
                        "request_text": json.dumps(payload),
                        "has_errors": status == "API_FAILED",
                        "response_status": "PROCESSED" if success else "API_FAILED",
                        "response_text": result,
                        "error_text": "" if status == "PROCESSED" else result,
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                        }
            
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")      
                        if success and batch_id:
                            api_success = False
                            api_result = ""
                            api_status = "API_FAILED"
                            url = f"{alternative_api_url}"
                            headers["batch-id"] = batch_id
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Attempting {attempt} for msisdn: {msisdn} with URL: {url}")
                                    resp = requests.get(
                                        url,headers=headers, timeout=60)
                                    logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Response Code: {resp.status_code} for msisdn: {msisdn}")
                                    api_success = 200 <= resp.status_code < 300
                                    api_result = resp.text
                                    api_status = "PROCESSED" if api_success else "API_FAILED"
                                    if api_success:
                                        break
                                    else:
                                        logging.warning(f"### telegence_bc_private_network_ip and {tenant_name} Attempt {attempt} failed for msisdn: {msisdn} with status code {resp.status_code} and response: {resp.text}") 
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(f"### telegence_bc_private_network_ip and {tenant_name} Attempt {attempt} failed for msisdns: {msisdn}: {result}")
                                    time.sleep(RETRY_DELAY)   
                            if not api_success :
                                result = api_result
                                api_status = "API_FAILED"
                            # preparing update data to update into bulk change request table    
                            update_data = {
                                "status": api_status,
                                "has_errors": not api_success,
                                "is_processed":  True,
                                "processed_date": now,
                                "status_details":result   
                            }

                            #update the request status
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                update_data,
                                and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id},
                                )                        
                            # Constructing the log entry
                            log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                            "log_entry_description": "Update Telegence Subscriber: Telegence API",
                            "request_text": json.dumps(payload),
                            "has_errors": api_status == "API_FAILED",
                            "response_status": "PROCESSED" if api_success else "API_FAILED",
                            "response_text": result,
                            "error_text": "" if status == "PROCESSED" else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                            }
                
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs") 
                            # updating inventory table    
                            if api_success:    
                                inventory_flag =database.update_dict(
                                            "sim_management_inventory", update_fields,
                                            and_conditions={"tenant_id": tenant_id, "is_active": True},
                                            in_conditions={"msisdn": [msisdn]}
                                        )
                                # Constructing the log entry
                                log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                "log_entry_description": "Update Telegence Subscriber: Update Inventory",
                                "request_text": json.dumps('ip'),
                                "has_errors":not inventory_flag,
                                "response_status": "PROCESSED" if inventory_flag else "Inventory failed",
                                "response_text": "Inventory update successful" if inventory_flag else "Inventory update failed",
                                "error_text": "" if inventory_flag else "Inventory update failed",
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                                }
                    
                                if log:
                                    database.insert_data(log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                                          
                        return msisdn
                    
                    # Submit the task to the executor
                    logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Submitting task for MSISDN: {msisdn}")
                    futures[executor.submit(task)] = msisdn

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### telegence_bc_private_network_ip and {tenant_name} Error processing msisdns: {e}")

              
        if interval and i + batch_size < len(msisdns):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # preparing the payload for history table update
        if succesful_msisdns:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "msisdns": succesful_msisdns,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API  
            try:
                logging.info(f"### telegence_bc_private_network_ip and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### telegence_bc_private_network_ip and {tenant_name} Exception in thread: {e}")  
            
        # Update the bulk change request status   
        logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Processed {len(msisdns) - len(remaining)} msisdns, {len(remaining)} remaining")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "msisdns": succesful_msisdns,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": change_type,
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "ip_address",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### telegence_bc_private_network_ip and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### telegence_bc_private_network_ip and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid msisdns
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_msisdns:
            logging.info(f"### Invalid msisdns found: {invalid_msisdns}")
            # Log invalid msisdns
            for msisdn in invalid_msisdns:
                request_id = msisdn_to_request_id.get(msisdn)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update private network ip ",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"msisdn": invalid_msisdns},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries, "sim_management_bulk_change_detailed_logs")
        logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API URL and payload are used to sync inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### telegence_bc_private_network_ip and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f'### telegence_bc_private_network_ip and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### telegence_bc_private_network_ip and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### telegence_bc_private_network_ip and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "telegence_bc_private_network_ip",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for private network ip for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### telegence_bc_private_network_ip and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### telegence_bc_private_network_ip and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "telegence_bc_private_network_ip",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdn}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### telegence_bc_private_network_ip and {tenant_name} Exception in logging error data to DB: {e}")
        return response



def billing_integration_new(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    #revcustomername = data.get("changed_data",{}).get("RevCustomerId", "")
    customerrateplan = data.get("CustomerRatePlanId", "")


    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            ["change_request"]
        )
        bulk_change_requests = {}
        customer_name=None
        if not request_data.empty:
            bulk_change_requests = request_data.iloc[0]["change_request"]
        if isinstance(bulk_change_requests, str):
           bulk_change_requests = json.loads(bulk_change_requests)
        logging.info(f"change_request_json is {bulk_change_requests}")
        #Extract relevant fields from the change request 
        rev_customer_id=bulk_change_requests.get("RevCustomerId","")  
        customer_data=database.get_data(
                "revcustomer",
                {"rev_customer_id":rev_customer_id,"is_active": True},
                ["customer_name"]
            )
        if not customer_data.empty:
            customer_name=customer_data["customer_name"].to_list()[0]
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
            "tenant_name": tenant_name,
            "path": "/bulk_update_assign_customer_service_line_creation",
            "role_name": role_name,
            "request_received_at": now,
            "access_token": access_token,
            "db_name": db_name,
            "sessionID": None,
            "service_provider": service_provider,
            "change_type": change_type,
            "created_by": created_by,
            "iccids": iccids,
            "msisdns":msisdns,
            "RevCustomerName": customer_name,
            "CustomerRatePlanName": customerrateplan,
            "changed_data": bulk_change_requests,         
            }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": tenant_name,
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "bulk Change",
                "request_received_at": now,
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": username,
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}

def billing_integration_change_rate_plan(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data    
    """
    logging.info(f"billing_integration_change_rate_plan in telegence function is called with data: {data}")
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    customerrateplan = data.get("CustomerRatePlanId", "")
    use_carrier_activation=data.get("use_carrier_activation")
    sessionid=data.get("sessionID","")
    customerid=data.get("customerId","")
    customer_name=data.get("customer_name","")
    #efdate=data.get("effective_date","")
    changed_data=data.get("changed_data",{})
    efdate=changed_data.get("effective_date","")
    try:

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}   
        billing_flag=False
        billing_platform_flag=common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["billing_platform_flag"]
        )
        if not billing_platform_flag.empty:
            billing_flag = bool(billing_platform_flag.iloc[0]["billing_platform_flag"])
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
            "tenant_id": tenant_id,
            "tenant_name": tenant_name,
            "username": username,
            "firstLastName": created_by,
            "path": "/bulk_update_customer_rate_plan_service_line_creation",
            "role_name": role_name,
            "module_name": "Bulk Change",
            "mod_pages": {
                "start": 0,
                "end": 100
            },
            "access_token": access_token,
            "db_name": db_name,
            "sessionID": sessionid,
            "request_received_at":now,
            "Partner": tenant_name,
            "service_provider_id": service_provider_id,
            "service_provider": service_provider,
            "EffectiveDate": efdate,
            "customername": customer_name,
            "bulkchange_id": bulk_change_id,
            "bulk_chnage_id_20":bulk_change_id,
            "use_carrier_activation": use_carrier_activation,
            "carrier_api_status": True,
            "billing_platform_flag":billing_flag,
            "modified_by": username,
            "created_by": created_by,
            "iccids": iccids,
            "msisdns": msisdns,
            "customerId":customerid,
            "CustomerRatePlanId":customerrateplan
            }         
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "billing_integration_change_rate_plan",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": tenant_name,
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "bulk Change",
                "request_received_at": now,
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for billing_integration_change_rate_plan")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": username,
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}
