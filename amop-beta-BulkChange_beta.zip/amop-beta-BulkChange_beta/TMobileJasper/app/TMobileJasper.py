"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
from collections import defaultdict
import concurrent
from decimal import Decimal
import json
import logging
import os
import requests
import os
import base64
import pandas as pd
from common_utils.db_utils import DB
from pandas import Timestamp
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import threading
from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# Database configuration
common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }





##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler

    db_config_details = None
    # 1. Try to extract encoded config
    # Access global db_config variable
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }

    if path == "/tmobilejasper_bc_archive_devices":
        result = tmobilejasper_bc_archive_devices(data)
    elif path == "/tmobilejasper_bc_change_customer_rate_plan":
        result = tmobilejasper_bc_change_customer_rate_plan(data)
    elif path == "/tmobilejasper_bc_change_carrier_rate_plan":
        result = tmobilejasper_bc_change_carrier_rate_plan(data)
    elif path== "/tmobilejasper_bc_update_device_status":
        result = tmobilejasper_bc_update_device_status(data)
    elif path== "/tmobilejasper_bc_edit_username_cost_center":
        result = tmobilejasper_bc_edit_username_cost_center(data)
    elif path=="/tmobilejasper_bc_create_rev_service(data)":
        result = tmobilejasper_bc_create_rev_service(data)
    elif path== "/tmobilejasper_bc_assign_customer":
        result = tmobilejasper_bc_assign_customer(data)
    elif path== "/tmobilejasper_bc_line_sync":
        result = tmobilejasper_bc_line_sync(data)
    elif path== "/tmobilejasper_bc_send_sms":
        result = tmobilejasper_bc_send_sms(data)
    elif path== "/tmobilejasper_bc_private_network_ip":
        result = tmobilejasper_bc_private_network_ip(data) 
    elif path == "/tmobilejasper_bc_change_communication_plan":
        result = tmobilejasper_bc_change_communication_plan(data)       
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
    ##carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
    logging.info(f"carrier_details: {carrier_details}")
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url

##Archive devices function 
def tmobilejasper_bc_archive_devices(data):
    """
    Archives devices from the system based on the provided ICCIDs.

    This function is typically triggered during a bulk change operation, where a list of SIM cards
    (identified by their ICCIDs) needs to be marked as archived in the system. Archiving a device
    means it is no longer considered active or in use, and its status is updated accordingly
    in relevant tables (e.g., inventory, assignment logs, usage tracking).

    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs to be archived.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.

    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
    """
    logging.info(f"### Received data for archiving devices: %s", data)
    start_time = time.time()
    # Validate required fields
    iccids = data.get("iccids", [])
    invalid_iccids = data.get("invalid_iccids", [])
    tenant_id = data.get("tenant_id", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by=data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    service_provider = data.get("service_provider", "")
    role_name= data.get("role", "")
    service_provider_id = data.get("service_provider_id", "")
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### tmobilejasper_bc_archiving devices and {tenant_name} time is {now}")
    #database connection
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_archive_devices and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    # Audit - start
    bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Initiated"
                )
    live_progress_percentage_tracker(database, bulk_change_id,25)
    try:
        bulk_change_requests = database.get_data(
                'sim_management_bulk_change_request',
                {"bulk_change_id": bulk_change_id},
                ['id', 'iccid','subscriber_number']
        )
        if bulk_change_requests.empty:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_archive_devices",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### tmobilejasper_bc_archive_devices rate plan and {tenant_name} Audit logging failed: {e}")
                return response
        ##main login to archive the devices
        # Map ICCID to request ID for fast access
        live_progress_percentage_tracker(database, bulk_change_id,40)
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        msisdn_to_request_id = dict(zip(bulk_change_requests["subscriber_number"], bulk_change_requests["id"]))

        # Archive valid ICCIDs in inventory
        logs_data=[]
        if iccids:
            inventory_update = database.update_dict(
                "sim_management_inventory",
                {"is_active": False, "is_deleted": True},
                and_conditions={"tenant_id": tenant_id, "service_provider_id": service_provider_id},
                in_conditions={"iccid": iccids},
            )
            logging.info(f"### tmobilejasper_bc_archive_devices inventory_update : {inventory_update}and tenant_id:{tenant_id} and service_provider_id:{service_provider_id} and iccids:{iccids} ")
            logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} Inventory update status: {inventory_update}")
            if inventory_update:  # If update failed
                logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} Archived {len(iccids)} devices in inventory")
            else:  
                logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} Error updating inventory for ICCIDs: {iccids}")
                for iccid in iccids:
                    request_id = iccid_to_request_id.get(iccid)
                    if request_id:
                        logs_data.append({
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": f"Archive Device Failed: {iccid}",
                            "request_text": "Update AMOP",
                            "has_errors": True,
                            "response_status": "ERROR",
                            "response_text": "Failed to archive device",
                            "error_text": "inventory update failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        })
                if logs_data:
                    database.insert_data(logs_data,"sim_management_bulk_change_log")
                    #  insert the log entries into detailed logs table
                    database.insert_data(logs_data,"sim_management_bulk_change_detailed_logs")
            
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","errors": len(iccids),"is_processed": True,"has_errors": True,"processed_date": now,"status_details":"Failed to archive device"},
                    and_conditions={"bulk_change_id": bulk_change_id},in_conditions={"iccid": iccids},)
            
            # Also update main bulk change record
                database.update_dict(
                    "sim_management_bulk_change",
                    {"status": "ERROR","errors": len(iccids),"processed_date": now},and_conditions={"bulk_change_id": bulk_change_id},
                )
                return {"flag": False,"message": "Inventory update failed","bulk_change_id": bulk_change_id}

        # Prepare logs
        log_entries = []
        invalid_log_entries = []
        # Valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            if request_id:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Archive Device: {iccid}",
                    "request_text": "Update AMOP",
                    "has_errors": False,
                    "response_status": "PROCESSED",
                    "response_text": "Device archived successfully",
                    "error_text": "",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        #updating bulk change request tables     
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len([iccids]),
             "is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Device archived successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Prepare payload for history table update
        if iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids":iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_archive_devices and {tenant_name} Exception in thread: {e}")
            # Invalid SIMs
        live_progress_percentage_tracker(database, bulk_change_id,70)

        for iccid in invalid_iccids:
            request_id = iccid_to_request_id.get(iccid) or msisdn_to_request_id.get(iccid)
            invalid_log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Archive Device Failed: {iccid}",
                "request_text": "Update AMOP",
                "has_errors": True,
                "response_status": "ERROR",
                "response_text": "Invalid SIM - could not be processed",
                "error_text": "Invalid ICCID",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"subscriber_number": invalid_iccids},
        )
        #  Bulk insert all logs
        if invalid_log_entries:
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} archived {len(iccids)} devices successfully")


        # Update the status of the bulk change request to PROCESSED
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "status": "PROCESSED",
                    "success": len(iccids),
                    "processed_date": now
                },
                {'id': bulk_change_id}
            )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below sync url and payload used to sync the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "tmobilejasper_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} sync call has started")

            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} sync call has ended")
            bulk_change_audit_action(data, common_utils_database,
                 action=f"Sync To 1.0 Tables"
                )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_archive_devices and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # Attempt to audit the actionn
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_archive_devices",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for archive devices.{bulk_change_id}",
                "request_received_at": now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database,
                 action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_archive_devices and {tenant_name} Audit logging failed: {e}")
        # Attempt to audit the actionn
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Completed"
                )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### tmobilejasper_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )

        return response
    except Exception as e:
        logging.exception(f"tmobilejasper_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status tmobilejasper_bc_archive_devices: {str(e)}")
        # Update the status of the bulk change request to ERROR
        # Log the error
        error_message = f"Error during bulk change processing for archive status: {str(e)}"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        logging.error(f"### tmobilejasper_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status tmobilejasper_bc_archive_devices: {str(e)}")
        # Prepare error response
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log error to database
            error_data = {
                "service_name": "tmobilejasper_bc_archive_devices",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for tmobilejasper_bc_archive_devices:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_archive_devices and {tenant_name} Exception in logging error data to DB: {e}")
        return response


## Change customer rate plan function
def tmobilejasper_bc_change_customer_rate_plan(data):
    """
    Change the customer rate plan for the given devices as part of a bulk change operation.
   
    this function is typically triggered during a bulk change operation where a list of SIM cards needs to have their customer rate plans updated.
    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs used to identify devices.
            -changed_data (dict): Dictionary containing the rate plan changes.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
        dict: Result of the operation with flags, messages, and details.
        
    """
    logging.info(f"### Received data for changing customer rate plan: %s", data)
    # Start timing the function execution
    start_time = time.time()
    # Extract all required fields from input data
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id= data.get("tenant_id", "")
    source=data.get("source","")
    service_provider = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "")
    username = data.get("username", "")
    invalid_iccids = data.get("invalid_iccids", [])
    parent_tenant_id=data.get('parent_tenant_id',None)
    # Validate required fields
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} time is {now}")
    try:
        # Connect to main and audit databases
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    parent_tenant_id = None
    try:
        parent_tenant_id=common_utils_database.get_data('tenant',{"id":tenant_id},["parent_tenant_id"])["parent_tenant_id"].to_list()[0]
    except Exception as e:
        logging.exception(f"Exception while fetching parent_tenant_id{e}")
        parent_tenant_id = None
    try:
        # Audit - Start
        bulk_change_audit_action(
            data, common_utils_database,
            action="Bulk Change Process Initiated"
        )
        live_progress_percentage_tracker(database, bulk_change_id,20)
        
        # Fetch bulk change request entries for valid ICCIDs
        bulk_change_requests = database.get_data(
            'sim_management_bulk_change_request',
            {"bulk_change_id": bulk_change_id},
            ['id', 'iccid','change_request']
        )
        if not bulk_change_requests.empty:
            change_request_json = bulk_change_requests.iloc[0]["change_request"]
            if not change_request_json:
                message="Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_change_customer_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"###tmobilejasper_bc_change_customer_rate_plan and tenant name : {tenant_name} Audit logging failed: {e}")
                return response
            
        live_progress_percentage_tracker(database, bulk_change_id,25)
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        customer_rate_plan_update=change_request_json.get("CustomerRatePlanUpdate","")
        customer_rate_plan_id=customer_rate_plan_update.get("CustomerRatePlanId","")
        customer_rate_pool_id=customer_rate_plan_update.get("CustomerPoolId","")
        effective_date=customer_rate_plan_update.get("EffectiveDate","")
        customer_name = customer_rate_plan_update.get("customerName", "")
        rate_plan_db_name=None
        rate_pool_db_name=None
        plan_mb=None
        rev_customer_name=None
        rev_customer_id=None
        customer_id=None
        # Validate input data
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_name","plan_mb"]   
            )
            if not rate_plan_data.empty:
                rate_plan_db_name = rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb = rate_plan_data["plan_mb"].to_list()[0]

        if customer_rate_pool_id and str(customer_rate_pool_id)!="-1":
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                rate_pool_db_name = rate_pool_data["name"].to_list()[0]
        
        update_fields={}
        fields_to_update = []
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_rate_plan_name"]
            ).to_dict(orient="records")
        # Extract valid ICCIDs
        # Prepare an update dict dynamically
        if customer_rate_plan_id is None:
            update_fields["customer_rate_plan_id"] = None
            update_fields["customer_rate_plan_name"] = None
        elif str(customer_rate_plan_id).strip() not in ("-1", -2,"-2"):
            update_fields["customer_rate_plan_id"] = customer_rate_plan_id
            update_fields["customer_rate_plan_name"] = rate_plan_db_name
            fields_to_update.extend([
                    "customer_rate_plan_id",
                    "sub_tenant_carrier_rate_plan_name",
                    "sub_tenant_carrier_rate_plan_name_id"
                ])
        if not customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(customer_rate_pool_id).strip() not in ("-1", -2,"-2"):
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id	
            update_fields["customer_rate_pool_name"] = rate_pool_db_name
            fields_to_update.append("customer_rate_pool_id")

        if effective_date:
            update_fields["effective_date"] = effective_date
        if customer_name:  
            update_fields["customer_name"] = customer_name
            rev_data = database.get_data(
                "revcustomer",
                {"customer_name": customer_name, "is_active": True,"tenant_id": tenant_id},
                ["customer_name", "rev_customer_id"]
            )
            if not rev_data.empty:
                rev_customer_name = rev_data["customer_name"].to_list()[0]
                rev_customer_id = rev_data["rev_customer_id"].to_list()[0]
                update_fields["rev_customer_id"] = rev_customer_id
                update_fields["rev_customer_name"] = rev_customer_name
                fields_to_update.append("account_number")
            customer_data = pd.DataFrame()
            if rev_customer_name:
                customer_data=database.get_data(
                    "customers",
                    {"customer_name":rev_customer_name,"is_active": True},
                    ["id","customer_name"]
                )
            if not customer_data.empty:
                customer_id=customer_data["id"].to_list()[0]
                update_fields["customer_id"]=customer_id
                fields_to_update.append("customer_id")
        if plan_mb is not None:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
        update_fields["modified_by"] = username 

        # Map ICCID to request ID for logging
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        log_entries = []
        invalid_log_entries=[]
        inventory_update = False # defulat 
        live_progress_percentage_tracker(database, bulk_change_id,40)
        
        # Update the SIM management inventory with the new rate plan
        if iccids:
            logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and tenant name : {tenant_name} Updating SIM management inventory with updated fields: {update_fields}")
            inventory_update =  database.update_dict(
            "sim_management_inventory",update_fields,
            and_conditions={"tenant_id":tenant_id,"is_active": True, "service_provider_id": service_provider_id},
            in_conditions={"iccid": iccids},
            
            )
            if not parent_tenant_id  and "customer_rate_plan_name" in update_fields:
                logging.info(f"sub tenant carrier rate plan update {update_fields}")
                if iccids:
                    database.update_dict("sim_management_inventory", 
                                        {
                                            "sub_tenant_carrier_rate_plan_name": update_fields.get("customer_rate_plan_name"),
                                            "sub_tenant_carrier_rate_plan_name_id":update_fields.get("customer_rate_plan_id")
                                        },in_conditions={"iccid": iccids})
                    logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} updated customer rate plan for {len(iccids)} devices in inventory") 
            logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Inventory update status: {inventory_update}")
            if inventory_update:  # success case
                logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} customer rate plan updated for {len(iccids)} devices in inventory")
            else:    # failure case 
                logging.info(f"### tmobilejasper_bc_change_customer_rate_planive_devices and {tenant_name} Error updating inventory for ICCIDs: {iccids}")
                for iccid in iccids:
                    request_id = iccid_to_request_id.get(iccid)
                    if request_id:
                        log_entries.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": request_id,
                        "log_entry_description": f"Change Customer Rate Plan for iccid : {iccid} failed",
                        "request_text": "Update AMOP",
                        "has_errors": not inventory_update,
                        "response_status": "ERROR",
                        "response_text":  "Customer Rate plan is not updated",
                        "error_text": "Rate plan not found or inactive",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                    })
                if log_entries:
                    database.insert_data(log_entries,"sim_management_bulk_change_log")
                    #  insert the log entries into detailed logs table
                    database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
            
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","errors": len(iccids),"is_processed": True,"has_errors": True,"processed_date": now,"status_details":"Customer Rate plan is not updated"},
                    and_conditions={"bulk_change_id": bulk_change_id},in_conditions={"iccid": iccids},)
            
            # Also update main bulk change record
                database.update_dict(
                    "sim_management_bulk_change",
                    {"status": "ERROR","errors": len(iccids),"processed_date": now},and_conditions={"bulk_change_id": bulk_change_id},
                )
                return {"flag": False,"message": "Inventory update failed","bulk_change_id": bulk_change_id}
                
            
        # Log valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Change Customer Rate Plan for iccid : {iccid} successful",
                "request_text": "Update AMOP",
                "has_errors": False,
                "response_status": "PROCESSED",
                "response_text": "Updated Customer Rate Plan Succesfully",
                "error_text": "",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        #update       
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now , "status_details":"OK" },
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Prepare payload for history table update
        if iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        "fields_updated": fields_to_update,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            #api call to update the history table
            try:
                logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Customer Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### tmobilejasper_bc_change_customer_rate_plann and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Exception in action history thread: {e}")
            
        live_progress_percentage_tracker(database, bulk_change_id,70)    
            
        if invalid_iccids:
            logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                invalid_log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan Failed",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid ICCID - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now , "status_details":"Invalid ICCID - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        if invalid_log_entries : 
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_detailed_logs")
            
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        # Update bulk change status to PROCESSED
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "success": len(iccids),
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call to update the 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "tmobilejasper_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action="Sync To 1.0 Tables"
        )
        try:
            if iccids:
                data["customername"]= customer_name
                data["CustomerRatePlanId"]= customer_rate_plan_id
                data["customerId"] = rev_customer_id if rev_customer_id else customer_id
                logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call for billing  has started")
                billing_integration_change_rate_plan(data)
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_customer_rate_plan: Exception while scheduling sync call for tenant '{tenant_name}': {e}")

        # Return success
        logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        # Prepare success response
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_change_customer_rate_plan",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing customer rate plan for devices : {bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        return response
 
    except Exception as e:
        # Main exception block
        logging.exception(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = "Error during bulk change processing"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "tmobilejasper_bc_change_customer_rate_plan",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": now,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_customer_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response


##Update Device Status function
def tmobilejasper_bc_update_device_status(data):
    """
   Update the device status using the TMobileJasper API.

    This function processes a list of ICCIDs and updates their device status in the TMobileJasper system.
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps ICCIDs to their respective request payloads.
        - Iteratively calls the TMobileJasper API for each ICCID with retry logic.
        - Updates status in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid ICCIDs or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - msisdns (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the TMobileJasper API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., SIM status or device status).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_msisdns (list): ICCIDs that failed validation before processing.
            - invalid_ids (list): Request IDs associated with invalid rows.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict: A response object indicating the result of the operation, containing:
            - flag (bool): True if processing completed without unhandled exceptions.
            - message (str): Summary message indicating the result.
            - processed (int): Number of ICCIDs processed.
            - msisdns (list): List of ICCIDs attempted.
            - invalid_msisdns (list): List of ICCIDs skipped due to invalid state.
            - bulk_change_id (str): ID of the bulk change request.
            - error (str, optional): Error message in case of failure.
    """
    logging.info(f"### tmobilejasper_bc_update_device_status Received data : {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    request_received_at=data.get("request_received_at", "")
    service_provider_id = data.get("service_provider_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    UpdateStatus= data.get("changed_data", {}).get("UpdateStatus", {})
    provider_parent_name=data.get("parent_provider_name", "")
   
    # Extract status values from changed_data
    device_status_id = data.get("device_status_id","")
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### tmobilejasper_bc_update_device_status and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### tmobilejasper_bc_update_device_status and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_update_device_status and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        provider = provider_parent_name if provider_parent_name else service_provider
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### tmobilejasper_bc_update_device_status and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### tmobilejasper_bc_update_device_status and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json=bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_update_device_status",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### tmobilejasper_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response
        # Extract update status from change_request_json
         
        if isinstance(change_request_json, str):             
           change_request_json = json.loads(change_request_json)  
        UpdateStatus = change_request_json.get("UpdateStatus", "") 
        logging.info(f"### tmobilejasper_bc_update_device_status and {tenant_name} Update status: {UpdateStatus}")
        device_status_data=pd.DataFrame()
        device_status = None
        ##fetching the status of the device to get updated using id
        if device_status_id:
            device_status_data = database.get_data(
                "device_status",
                {"id": device_status_id, "is_active": True},
                ["id", "display_name"]
            )
        if not device_status_data.empty:
           device_status = device_status_data["display_name"].iloc[0]

        
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": iccids,"tenant_id": tenant_id}
        ).to_dict(orient="records")
        # Validate input data
        inventory_lookup = {rec["iccid"]: rec for rec in old_inventory_data}

        if source == "Inventory":
            old_inventory_data = old_inventory_data

        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        if PARALLEL_REQUESTS>10:
           logging.info(f"### tmobilejasper_bc_update_device_status and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(iccids)
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}/{iccid}"
                    
                    payload={"status": UpdateStatus}                 

                    def task(iccid=iccid, url=url, payload=payload):
                        # Initialize tracking variables
                        success = False
                        result = ""
                        status = "API_FAILED"
                         # Retry loop with maximum attempts
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### tmobilejasper_bc_update_device_status and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                # Make PUT request to update device status
                                resp = requests.put(url, json=payload, 
                                    headers={
                                                "Authorization": app_id,
                                                "Content-Type": "application/json"
                                            }, timeout=60)
                                logging.info(f"### tmobilejasper_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                # Determine success based on HTTP status code
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                # If successful, add ICCID to success list and exit retry loop
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### tmobilejasper_bc_update_device_status and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":resp.text},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            database.update_dict(
                                "sim_management_inventory",
                                {
                                    "sim_status": device_status,
                                    "modified_by": username,
                                    "device_status_id": device_status_id if device_status_id else None
                                },
                                and_conditions={"tenant_id": tenant_id,"service_provider_id": service_provider_id, "is_active": True},
                                in_conditions={"iccid": [iccid]}
                            )
                            record = inventory_lookup.get(iccid, {})
                            try:

                                status_history={
                                    "iccid": iccid,
                                    "sim_management_inventory_id": record.get("id", None)if record else None,
                                    "msisdn": record.get("msisdn", None)if record else None,
                                    "username": record.get("username", None)if record else None,
                                    "previous_status": record.get("sim_status", None) if record else None,
                                    "current_status": UpdateStatus,
                                    "bulk_change_id": bulk_change_id,
                                    "change_event_type": change_type,
                                    "date_of_change": request_received_at,
                                    "tenant_id": tenant_id,
                                    "customer_name": record.get("customer_name", None) if record else None,
                                    "customer_account_number": record.get("account_number", None) if record else None,
                                    "customer_rate_plan": record.get("customer_rate_plan_name", None) if record else None,
                                    "customer_rate_pool": record.get("customer_rate_pool_name", None) if record else None,
                                    "service_provider_display_name": service_provider,
                                    "service_provider_id": record.get("service_provider_id", None) if record else None,
                                    "device_id": record.get("device_id", None) if record else None,
                                    "mobility_device_id": record.get("mobility_device_id", None) if record else None,
                                    "date_of_change": now,
                                    "changed_by": created_by,
                                    "customer_name_with_revio":(f"{record.get('rev_customer_name')} ({record.get('rev_customer_id')})"
                                                if record.get("rev_customer_name") and record.get("rev_customer_id")
                                                else None),
                                    "is_deleted": False,
                                }
                                if status_history:   
                                    logging.info(f"### device_status_history inserting  record data : {status_history}")
                                    inserted_id = database.insert_data(status_history, "device_status_history")
                                    if inserted_id:
                                        device_status_history_id = inserted_id
                                    
                                    #preparing for updating smi_device_detail_history table
                                    status_history.pop("device_id") 
                                    status_history.pop("bulk_change_id")   
                                    status_history["module_name"] = "Bulk Change" 
                                    status_history["is_active"] = record.get("is_active", None) if record else None
                                    status_history["dshid"] =device_status_history_id if device_status_history_id else None

                                    #insert into smi_device_detail_history
                                    logging.info(f"### TMobileJasper_bc_update_device_status inserting  record data : {status_history}")
                                    database.insert_data(status_history, "smi_device_detail_history")
                            except Exception as e:
                                ## audit if insert failed history
                                error_message = f"Error during inserting history table: {str(e)}"
                                error_type = type(e).__name__
                                try:
                                    error_data = {
                                        "service_name": "TMobileJasper_bc_update_device_status",
                                        "error_message": error_message,
                                        "error_type": error_type,
                                        "users": username,
                                        "tenant_name": tenant_name,
                                        "comments": f"Error while inserting into the history table for ICCID: {iccid}",
                                        "module_name": "Bulk Change",
                                        "request_received_at": data.get("request_received_at") or now
                                    }
                                    common_utils_database.log_error_to_db(error_data, "error_log_table")
                                except Exception as log_e:
                                    logging.error(f"### TMobileJasper_bc_update_device_status and {tenant_name} Exception in logging error data: {log_e}")
                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update TMobileJasper Subscriber: TMobileJasper API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### TMobileJasper_bc_update_device_status and {tenant_name} Error processing ICCID: {e}")

        if INTERVAL and i + BATCH_SIZE < len(iccids):
                time.sleep(INTERVAL)
        #prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successfull_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### tmobileJasper_bc_update_device_status and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobileJasper_bc_update_device_status and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            action_history_payload = {
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": successfull_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Update Device Status",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_field": "sim_status"
                }
            }
            
            # API call to update action history
            try:
                logging.info(f"### TMobileJasper_bc_update_device_status and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"### TMobileJasper_bc_update_device_status and {tenant_name} Exception in action history thread: {e}")
    # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update TMobileJasper Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(logs,"sim_management_bulk_change_detailed_logs")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "tmobileJasper_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### TMobileJasper_bc_update_device_status and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### TMobileJasper_bc_update_device_status and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### TMobileJasper_bc_update_device_status and {tenant_name} Exception in thread: {e}")

        try:
            if successfull_ids:
                data["iccids"]=successfull_ids
                logging.info(f"### TMobileJasper_bc_update_device_status and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### TMobileJasper_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        # Return success
        try:
            if successfull_ids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "changed_data": {
                            "iccid": successfull_ids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="iccid"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### TMobileJasper_bc_update_device_status and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### TMobileJasper_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        logging.info(f"### TMobileJasper_bc_update_device_status and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### TMobileJasper_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "TMobileJasper_bc_update_device_status",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for updating device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### TMobileJasper_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### TMobileJasper_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### TMobileJasper_bc_update_device_status and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "TMobileJasper_bc_update_device_status",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### TMobileJasper_bc_update_device_status and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response
    

    
## Change Carrier Rate Plan function
def tmobilejasper_bc_change_carrier_rate_plan(data):
    """Change the carrier rate plan for the given devices.
    This function processes a list of iccids and updates their carrier rate plan in the pod19 system.
    It handles bulk requests, updates the database, and logs the results.   
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDS to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the pod19 API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan Recevied data :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    service_provider_id = data.get("service_provider_id", "")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    provider_parent_name=data.get("parent_provider_name", "")
    # Initialize for log entries
    log_entries = []
    success_iccids = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR","status_details":"Processing Invalid Sim"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_change_carrier_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
                
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        carrier_rate_plan_update=change_request_json.get("CarrierRatePlanUpdate","")
        carrie_rate_plan=carrier_rate_plan_update.get("CarrierRatePlan","")
        effective_date=carrier_rate_plan_update.get("EffectiveDate","")
        communication_plan = carrier_rate_plan_update.get("CommPlan","")

        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        ## Prepare headers for API call
        rate_plan_id=None
        rate_plan_code=None
        fields_to_update = []
        # Validate input data for rateplan and optimization
        logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Validating input data for rate plan and optimization group")
        if carrie_rate_plan:
           rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrie_rate_plan, "is_active": True},
            ["id","rate_plan_code"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            rate_plan_code=rate_plan_data["rate_plan_code"].to_list()[0]
        logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Rate plan ID: {rate_plan_id} Rate Plan Code: {rate_plan_code}")
        # Prepare an update dict 
        if carrie_rate_plan:
           update_fields = {"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": carrie_rate_plan}  
           fields_to_update.extend(["rate_plan","carrier_rate_plan_id"])      
     
        if effective_date:
           update_fields["effective_date"] = effective_date
        if communication_plan:
           update_fields["communication_plan"] = communication_plan
           fields_to_update.extend(["communication_plan","sub_tenant_communication_plan","sub_tenant_communication_plan_id"])


        update_fields["modified_by"] = username 
        # Validate iccids
        remaining = iccids.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","carrier_rate_plan_name"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        remaining = list(iccids) 

        #constracting header 
        headers = {
            "Authorization": app_id,
            "Content-Type": "application/json"
        }
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)

        # Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each iccid in the batch
                logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} iccids")
                for iccid in batch:
                    # Prepare the URL and payload for the API call
                    url = f"{carrier_api_url}/{iccid}"
                    payload = {
                            "ratePlan": carrie_rate_plan,   
                              }
                
                    def task(iccid=iccid, url=url, payload=payload):
                            # Initialize tracking variables 
                            success = False
                            result = ""
                            status = "API_FAILED"
                            # Retry loop with maximum attempts
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                    # Make API request with timeout
                                    resp = requests.put(
                                        url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                    # Determine success based on HTTP status code
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "PROCESSED" if success else "API_FAILED"
                                    if success:
                                        success_iccids.append(iccid)
                                        break
                                except Exception as e:
                                    # Handle any exceptions during API call
                                    result = str(e)
                                    logging.warning(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Attempt {attempt} failed for iccids: {iccid}: {result}")
                                    time.sleep(RETRY_DELAY)
                            # Prepare update data based on final outcome
                            if success:
                                update_data = {
                                    "status": status,
                                    "has_errors": False,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":result 
                                }
                            else:
                                update_data = {
                                    "status": status,
                                    "has_errors": True,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":result
                                }
                            #update the request status
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                update_data,
                                and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id},
                                )
                            # Only update inventory if API succeeded
                            if success:
                                database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"tenant_id":tenant_id,"service_provider_id": service_provider_id,"is_active": True},
                                    in_conditions={"iccid": [iccid]}
                                    )
                            # Constructing the log entry
                            log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update TMobileJasper Subscriber: TMobileJasper API",
                            "request_text": json.dumps(payload),
                            "has_errors": status == "API_FAILED",
                            "response_status": "PROCESSED" if success else "API_Failed",
                            "response_text": result,
                            "error_text": "" if status == "PROCESSED" else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                            }
                
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs") 
                            return iccid
                        
                    # Submit the task to the executor
                    logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Submitting task for ICCID: {iccid}")
                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Error processing ICCIDS: {e}")

              
        if interval and i + batch_size < len(iccids):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
         #preare the payload for history table
        if success_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": success_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        "fields_updated": fields_to_update,
                                        }
                                    }
        
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table API
            try:
                logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        # Update the bulk change request status   
        logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Processed {len(iccids) - len(remaining)} iccids, {len(remaining)} remaining")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": success_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Carrier Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "carrier_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "TMobileJasper_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info('### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} sync call has started')
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info('### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} sync call has ended')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        try:
            if success_iccids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "changed_data": {
                            "iccid": success_iccids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="iccid"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_change_carrier_rate_plan",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
         
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "tmobilejasper_bc_change_carrier_rate_plan",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_carrier_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response



# ##Edit username or cost center function
def tmobilejasper_bc_edit_username_cost_center(data):
    """
    Edits the username or cost center associated with devices in bulk.
    
    This function processes a bulk change request to update username and/or cost center
    information for multiple devices. It handles both devices with and without Rev.io
    service IDs, making appropriate API calls for Rev.io integrated devices and direct
    database updates for others.
    
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs to process
            - bulk_change_id (str): ID of the bulk change request
            - created_by (str): User who initiated the request  
            - service_provider (str): Service provider name
            - service_provider_id (str): Service provider identifier
            - change_type (str): Type of change being made
            - tenant_id (str): Tenant identifier
            - invalid_iccids (list): List of invalid ICCIDs that cannot be processed

    Returns:
        dict: Response object with keys:
            - flag (bool): Indicates success or failure of the bulk change
            - processed (int): Number of successfully processed records
            - remaining (int): Number of records remaining to process
            - message (str): Human-readable status message
            - iccids (list): Original list of ICCIDs processed
            - invalid_iccids (list): List of invalid ICCIDs encountered
            - bulk_change_id (str): ID of the bulk change operation
    """

    logging.info(f"### Recevied data for tmobilejasper_bc_edit_username_cost_center :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    service_provider_id = data.get("service_provider_id", "")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    username1= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    provider_parent_name=data.get("parent_provider_name", "")
    # Validate required fields
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request","subscriber_number"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_edit_username_cost_center",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,20)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
           username=change_request_json.get("ContactName", "")
           cost_center=change_request_json.get("CostCenter1", "") 
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))

        msisdns = bulk_requests_df["msisdn"].tolist()
        headers = fetch_headers(database, tenant_id, app_id, app_secret)
        headers["Content-Type"] = "application/json-patch+json"
        logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Final headers: {headers}")
        ## Prepare headers for API call
        # headers = {
        #     "Authorization": app_id,
        #     "Ocp-Apim-Subscription-Key": app_secret,
        #     "Content-Type": "application/json-patch+json"
        # }
        
        # Prepare an update dict 
        rev_data=pd.DataFrame()
        revid=None
        update_fields = {}
        successfull_iccids = []
        if username:
           update_fields["username"] = username
        if cost_center:
            update_fields["cost_center"]=cost_center
        # Validate MSISDNs
        rev_data = database.get_data(
                            "rev_service",
                            {"number": iccids, "is_active": True},
                            ["number","rev_service_id"]
                          )
        #rev_series = rev_data.set_index("number")["rev_service_id"]
        # Align column name for merging
        rev_data = rev_data.rename(columns={"number": "iccid"}).drop_duplicates(subset=["iccid"], keep="last")
        #  Merge msisdns with rev_service
        df = bulk_requests_df[["iccid"]].merge(rev_data, on="iccid", how="left")
        with_revid = df[df["rev_service_id"].notnull()]
        without_revid = df[df["rev_service_id"].isnull()]
        rev_iccids=with_revid["iccid"].tolist()
        remaining = list(rev_iccids)        
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","username","cost_center"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        # costcenter_labels = ["CostCenter1", "CostCenter2", "CostCenter3"]
        rev_map = dict(zip(with_revid["iccid"], with_revid["rev_service_id"]))
        nonrev_iccids = without_revid["iccid"].tolist()
        if nonrev_iccids:
            # 1. Bulk update sim_management_inventory (all missing iccids in one query)
            rev_service_log = database.update_dict(
                "sim_management_inventory",
                update_fields,
                and_conditions={"is_active": True, "service_provider_id": service_provider_id},
                in_conditions={"iccid": nonrev_iccids}  # bulk update
            )
            successfull_iccids.extend(nonrev_iccids)

            # 2. Bulk update sim_management_bulk_change_request
            database.update_dict(
                "sim_management_bulk_change_request",
                {
                    "status": "PROCESSED",
                    "is_processed": True,
                    "has_errors": False,
                    "processed_date": now,
                    "status_details":"OK",
                }, 
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": nonrev_iccids},
            )

            # 3. Loop only for logs
            data_log=[]
            if rev_service_log:
                for iccid in nonrev_iccids:
                    data_log.append( {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update AMOP",
                        "request_text": "Edit Username/Cost Center processed",
                        "has_errors": False,
                        "response_status": "PROCESSED",
                        "response_text": "OK",
                        "error_text": "",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True,
                    })
                database.insert_data(data_log, "sim_management_bulk_change_log")
                #  insert the log entries into detailed logs table
                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
            else:
                for iccid in nonrev_iccids:
                    data_log.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update AMOP",
                        "request_text": "Edit Username/Cost Center processed",
                        "has_errors": True,
                        "response_status": "ERROR",
                        "response_text": "Failed to update inventory",
                        "error_text": "",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True,
                    })
                database.insert_data(data_log, "sim_management_bulk_change_log")
                #  insert the log entries into detailed logs table
                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
        
            logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
        # Chunking ICCIDs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(rev_iccids), batch_size):
                # Create a batch of ICCIDs
                batch = rev_iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each ICCID in the batch
                logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    # Prepare the URL and payload for the API call
                    
                    revid = rev_map.get(iccid)
                    if revid is not None:
                        revid = int(float(revid))
                        url = f"{carrier_api_url}/{revid}"
                    payload = []
                    def task(iccid=iccid, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        username_index = None
                        costcenter_index = None
                        
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.get(
                                    url, headers=headers, timeout=60)
                                logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Response Text: {result}")
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    response_data = resp.json()
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            label_to_index = {f["label"]: i for i, f in enumerate(response_data["fields"])}
                            username_index = label_to_index.get("User Name")
                            #costcenter_index = next((label_to_index[label] for label in costcenter_labels if label in label_to_index), None)
                            costcenter_index = [
                                    index for label, index in label_to_index.items() if label.startswith("CostCenter")
                                ]
                            logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Username index: {username_index}, Cost Center index: {costcenter_index} for ICCID: {iccid}")
                                
                        #update the request status
                        if username_index  or costcenter_index:
                            if username_index:
                                payload.append({
                                    "op": "replace",
                                    "path": f"/fields/{username_index}/value",
                                    "value": username
                                })

                            if costcenter_index:
                                payload.append({
                                    "op": "replace",
                                    "path": f"/fields/{costcenter_index}/value",
                                    "value": cost_center
                                })

                            logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} API Payload: {payload}, URL: {url}")

                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    get_resp = requests.patch(url,json=payload, headers=headers, timeout=60)
                                    api_success = 200 <= get_resp.status_code < 300
                                    api_result = get_resp.text
                                    logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Response Code: {get_resp.status_code}")
                                    logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Response Text: {api_result}")
                                    status = "PROCESSED" if api_success else "API_FAILED"
                                    
                                    if api_success:
                                        response_data = get_resp.json()
                                        successfull_iccids.append(iccid)
                                    
                                        break
                                except Exception as e:
                                    result = str(e)
                                    status = "API_EXCEPTION"
                                    time.sleep(RETRY_DELAY)

                            if api_success:
                                update_data = {
                                    "status": status,
                                    "has_errors": False,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":" Edit Username/Cost Center via TmobileJasper API" 
                                }
                            else:
                                update_data = {
                                    "status": status,
                                    "has_errors": True,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":"Edit Username/Cost Center via TmobileJasper API"
                                }  
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                update_data,
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"iccid":[iccid]},
                                )             
                                #inserting values into revservice product table 
                            rev_service_log=database.update_dict(
                                "sim_management_inventory",update_fields,
                                and_conditions={"service_provider_id": service_provider_id,"is_active": True},
                                in_conditions={"iccid": [iccid]}
                            )
                            #constracting logs 
                            log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Edit Username/Cost Center via TmobileJasper API",
                                    "request_text": json.dumps(payload),
                                    "has_errors": status == "API_FAILED",
                                    "response_status": "PROCESSED" if api_success else "API_Failed",
                                    "response_text": api_result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
            
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Inserting log for Edit Username/Cost Center: {log}") 
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Update AMOP",
                                    "request_text": json.dumps(payload),
                                    "has_errors":False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK" ,
                                    "error_text": "",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        else:
                            rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"service_provider_id": service_provider_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                            successfull_iccids.append(iccid)
                                
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"iccid":[iccid]},
                                )

                                #constracting logs
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Edit Username/Cost Center via TmobileJasper API",
                                    "request_text": "Update AMOP",
                                    "has_errors": False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK",
                                    "error_text": "" ,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        return iccid


                    # Submit the task to the executor
                    logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Submitting task for ICCID: {iccid}")
                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Error processing ICCID: {e}")

              
        if interval and i + batch_size < len(rev_iccids):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Processed {len(iccids) - len(remaining)} ICCIDS, {len(remaining)} remaining")
        ## Handle invalid MSISDNs
        #api call to upadte the history tables
        if successfull_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": [],
                                        "msisdns":successfull_iccids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the API to update device history tables
            try:
                logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username1,
                        "path": "/sim_management_action_history_update",
                        "iccids": successfull_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Edit Username/Cost Center",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "username" if username else "cost_center",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"tmobilejasper_bc_edit_username_cost_center and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #suny url to update inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "tmobilejasper_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### tmobilejasper_bc_edit_username_cost_center and {tenant_name} sync call has started')
            
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f'### tmobilejasper_bc_edit_username_cost_center and {tenant_name} sync call has ended')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_edit_username_cost_center",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                    data, common_utils_database,
                    action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_edit_username_cost_center and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
        
 
    
def decode_password(encoded_pwd: str) -> str:
    """
    Decode the stored password. Replace with your actual decode logic.
    """
    # Example: if it was base64-encoded in the DB:
    return base64.b64decode(encoded_pwd).decode("utf-8")

def decode_token(encoded_token: str) -> str:
    """
    Decode the stored token_value. Replace with your actual decode logic.
    """
    return base64.b64decode(encoded_token).decode("utf-8")

def fetch_headers(database,tenant_id,app_id,app_secret):
    """Fetch and prepare headers for Telegence API requests.
    This function retrieves the necessary authentication details from the database,
    decodes them, and constructs the headers required for API requests.
    Args:

        database (object): Database connection or handler object.
        tenant_id (int): The tenant ID to fetch the integration authentication details.
    Returns:
        dict: Headers containing 'Authorization' and 'Ocp-Apim-Subscription-Key'.
    """
    try:
        rev_io_data_query=f'''SELECT username,password,token_value FROM public.integration_authentication
        where integration_id in (select id from integration where name='Rev.IO'
        ) and tenant_id={tenant_id}'''
        rev_io_dataframe=database.execute_query(rev_io_data_query,True)
        revio_username = rev_io_dataframe["username"].to_list()[0]
        encoded_pwd = rev_io_dataframe["password"].to_list()[0]
        encoded_token = rev_io_dataframe["token_value"].to_list()[0]
        password = decode_password(encoded_pwd)
        token_value = decode_token(encoded_token)
        # 3. Re-encode username:password into Basic
        user_pass = f"{revio_username}:{password}"
        # base64 encode
        b64 = base64.b64encode(user_pass.encode("utf-8")).decode("utf-8")
        rev_app_id = f"Basic {b64}"

        # 4. app_secret is the decoded token_value
        rev_app_secret = token_value

        headers = {
            "Authorization": rev_app_id,
            "Ocp-Apim-Subscription-Key": rev_app_secret,
        }  

        return headers
    except Exception as e:
        logging.error(f"### fetch_headers Error occurred while fetching headers: {e}")
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }  
        return headers

## Assign customer function
def tmobilejasper_bc_assign_customer(data):
    """Assign a customer to the selected devices or services.
    This function processes a list of iccids and assign a customer account with the iccids in the Verizon system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - ICCIDs (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Verizon API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for assign customer: %s", data)
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    if iccids:
        iccids = list(set(iccids))
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    source=data.get("source","")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    provider_parent_name=data.get("parent_provider_name", "")
    parent_tenant_id=data.get('parent_tenant_id',None)
    # Initialize for log entries
    log_entries = []
    rev_service_type_id=None
    service_type_id=None
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} time is {now}")

    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_assign_customer and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        logging.exception(f"### tmobilejasper_bc_assign_customer and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
            logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}


        # Fetch bulk change rows
       
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request"]
        )
        # Validate input data 
       
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_assign_customer",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###tmobilejasper_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        logging.info(f"change_request_json is {change_request_json}")
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        rev_service_type_id=change_request_json.get("ServiceTypeId","")
        if rev_service_type_id:
            service_type_data=database.get_data(
                    "rev_service_type",
                    {"service_type_id": rev_service_type_id, "is_active": True},
                    ["id"]
                )
            if not service_type_data.empty:
                service_type_id = service_type_data["id"].to_list()[0]
            else:
                service_type_id = None
        logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} service_type_id is {service_type_id}")
        effective_date=change_request_json.get("EffectiveDate","")
        generate_proration=change_request_json.get("Prorate",None)
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[])
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate_list= change_request_json.get("RateList", [])
        revpackageid=change_request_json.get("RevPackageId", None)
        site_id=change_request_json.get("SiteId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
        plan_mb=None
        customer_data=pd.DataFrame()
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name","plan_mb"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb=rate_plan_data["plan_mb"].to_list()[0]
        if customer_rate_pool_id and customer_rate_pool_id != "No options":
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer or site_id:
            if rev_customer:
                # Use rev_customer if provided
                customer_data = database.get_data(
                    "customers",
                    {"customer_name": rev_customer, "is_active": True,"tenant_id": tenant_id},
                    ["id", "customer_name"]
                )
            elif site_id:
                # Fallback: use site_id as customer_name when rev_customer is absent
                customer_data = database.get_data(
                    "customers",
                    {"id": site_id, "is_active": True,"tenant_id": tenant_id},
                    ["id", "customer_name"]
                )
                if not customer_data.empty:
                    customer_name=customer_data["customer_name"].to_list()[0]
                    rev_dataframe = database.get_data(
                        "revcustomer",
                        {"customer_name": customer_name, "is_active": True,"tenant_id": tenant_id},
                        ["customer_name", "rev_customer_id","id"]
                    )
                    if not rev_dataframe.empty:
                        rev_customer = rev_dataframe["customer_name"].to_list()[0]
                        rev_customer_uuid = rev_dataframe["id"].to_list()[0]
                        rev_customer_id = rev_dataframe["rev_customer_id"].to_list()[0]

            else:
                customer_data = pd.DataFrame()
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields ={}
        fields_to_update = []
        if customer_rate_plan_id and customer_rate_plan:
            update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
            fields_to_update.extend([
                    "customer_rate_plan_id",
                    "sub_tenant_carrier_rate_plan_name",
                    "sub_tenant_carrier_rate_plan_name_id"
                ])
        update_fields["modified_by"] = username 
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
            fields_to_update.append("customer_rate_pool_id")      
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
            fields_to_update.append("account_number")
        if effective_date:
            update_fields["effective_date"] = effective_date
        if plan_mb is not None:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        # if device_id:
        #     update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        if customer_id:
            fields_to_update.append("customer_id")
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_request_id = dict(zip(bulk_requests.iccid, bulk_requests.id))
        iccid_to_changerequest = dict(zip(bulk_requests.iccid, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = fetch_headers(database,tenant_id,app_id,app_secret)
        logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} Headers prepared for API call{headers}")
        # headers = {
        #     "Authorization": app_id,
        #     "Ocp-Apim-Subscription-Key": app_secret,
        # }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        # Validate iccids
        remaining = iccids.copy()
        logs = []
        successful_iccids = []
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"###tmobilejasper_bc_assign_customer and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_name"]
            ).to_dict(orient="records")
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of ICCIDs
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} Processing ICCID: {iccid}")
                    
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    #task function
                    def task(iccid=iccid):
                        """ 1. If CreateRevService is True:
                            - Step 1: Call API to create RevService (POST with retries)
                            - Step 2: On success, extract RevService ID from response
                            - Step 3: Use RevService ID to create Service Product (POST)
                        
                           2. If CreateRevService is False:
                            - Skip RevService creation and directly insert into DB"""
                        logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} Started processing ICCID: {iccid}")
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                        productid = None
                        rev_service_log=False
                        payload_str = iccid_to_changerequest.get(iccid)
                        logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} Payload for ICCID {iccid}: {payload_str}")
                        request_payload = json.loads(payload_str)
                        service_number=request_payload.get('Number')
                        iccid_from_request=request_payload.get('ICCID')
                        #extract the create rev service flag
                        rev_service = request_payload.get("CreateRevService", False)
                        # Build payloads for all APIs
                        rev_api_payload = {
                            "customer_id": rev_customer_id,
                            "provider_id": provider_id,
                            "number2":iccid_from_request,
                            "service_type_id": rev_service_type_id,
                            "number": service_number,
                            "activated_date": activated_date,

                        }
                        product_api_payload={
                            "CustomerId": rev_customer_id,
                            "service_type_id": rev_service_type_id,
                            "number": service_number,
                            "effective_date": effective_date,
                            "activated_date": activated_date,
                            }
                        if revpackageid:
                            product_api_payload.update({"revpackageid": revpackageid})
                        else:
                            product_api_payload.update({"RevProductIdList": revproductidlist,"RateList": rate_list,"UsagePlanGroupId": usageplangroupid})
                        try:
                            if rev_service:
                                # Step 1:  First API Call to create the revservice
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} Attempt {attempt} - URL: {url}, Payload: {rev_api_payload}")
                                        
                                        resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                        success = 200 <= resp.status_code < 300
                                        result = resp.text
                                        logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} Response Code: {resp.status_code}")
                                        logging.info(f"###tmobilejasper_bc_assign_customer and {tenant_name} Response Text: {result}")
                                        status = "PROCESSED" if success else "API_Failed"
                                        if success:
                                            try:
                                                response_data = resp.json()
                                                id = response_data.get("id")
                                                successful_iccids.append(iccid)
                                            except Exception:
                                                id = None
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        logging.exception(f"### tmobilejasper_bc_assign_customer and {tenant_name} Exception in API call: {e}")
                                        time.sleep(RETRY_DELAY) 
                                if success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result    
                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"iccid": [iccid]},
                                    )             
                                if success:  
                                    #inserting values in rev service 
                                    rev_data={
                                    "rev_customer_id":rev_customer_uuid,
                                    "number":service_number,
                                    "rev_service_id":id,
                                    "activated_date":activated_date,
                                    "is_active":True,
                                    "integration_authentication_id":integration_authentication_id,
                                    "rev_provider_id":rev_provider_id,
                                    "rev_service_type_id":service_type_id
                                    }
                                    rev_insert_id=database.insert_data(rev_data,"rev_service")
                                    if rev_insert_id:
                                        update_fields["rev_service_id"]=rev_insert_id
                                    logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} update_fields: {update_fields}")
                                    #updating inventory table
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                # Inserting logs based on api result
                                rev_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Rev.io API",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": status == "PROCESSED",
                                        "response_status": "PROCESSED" if success else "API_Failed",
                                        "response_text": result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                database.insert_data(rev_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(rev_log,"sim_management_bulk_change_detailed_logs") 
                                logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Inserting log for rev service creation: {rev_log}")
                                #inserting logs after updating inventory table
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                                # Step 2:  Second API Call
                                logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Creating Rev.io Service Product for ICCID: {iccid} with ID: {id}")
                                if id:
                                    # Multiple API calls for each product & rate
                                    for product_id, rate in zip(revproductidlist, rate_list):
                                        logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Creating product_id {product_id} with rate {rate} for service_id {id}")
                                        if not product_id:
                                            continue  # Skip invalid product IDs

                                        # Build payload for each product
                                        product_api_payload_single = {
                                            "CustomerId": rev_customer_id,
                                            "service_type_id": rev_service_type_id,
                                            "number": service_number,
                                            "effective_date": effective_date,
                                            "activated_date": activated_date,
                                            "product_id": product_id,
                                            "rate": rate,
                                            "service_id": id
                                        }
                                        if generate_proration:
                                            product_api_payload_single["generate_proration"] = str(generate_proration).lower()  # "true" or "false"

                                        logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Product API Payload: {product_api_payload_single}, URL: {alternative_api_url}")

                                        for attempt in range(1, MAX_RETRIES + 1):
                                            try:
                                                get_resp = requests.post(alternative_api_url, json=product_api_payload_single, headers=headers, timeout=60)
                                                api_success = 200 <= get_resp.status_code < 300
                                                api_result = get_resp.text
                                                logging.info(f"### Response Code: {get_resp.status_code}")
                                                logging.info(f"### Response Text: {api_result}")

                                                if api_success:
                                                    response_data = get_resp.json()
                                                    productid = response_data.get("id")
                                                    break
                                            except Exception as e:
                                                logging.info(f"API exception on attempt {attempt}: {str(e)}")
                                                time.sleep(RETRY_DELAY)

                                        if api_success:
                                            product_record = {
                                                "service_product_id": productid,
                                                "customer_id": rev_customer_id,
                                                "service_id": id,
                                                "description": description,
                                                "activated_date": activated_date,
                                                "status": "ACTIVE",
                                                "created_by": created_by,
                                                "created_date": now,
                                                "is_active": True,
                                                "is_deleted": False,
                                                "integration_authentication_id": integration_authentication_id,
                                                "product_id": product_id,
                                                "rate": rate
                                            }

                                            database.insert_data(product_record, "rev_service_product")
                                            logging.info(f"Inserted rev_service_product with product_id {product_id}, rate {rate} for tenant {tenant_name}")
                                        #constracting logs 
                                        log = {
                                                "bulk_change_id": bulk_change_id,
                                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                                "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                                "request_text": json.dumps(product_api_payload_single),
                                                "has_errors": status == "API_FAILED",
                                                "response_status": "PROCESSED" if api_success else "API_Failed",
                                                "response_text": api_result,
                                                "error_text": "" if status == "PROCESSED" else result,
                                                "processed_date": now,
                                                "processed_by": created_by,
                                                "created_by": created_by,
                                                "created_date": now,
                                                "is_deleted": False,
                                                "is_active": True
                                            }
                        
                                        if log:
                                            database.insert_data(log,"sim_management_bulk_change_log")
                                            #  insert the log entries into detailed logs table
                                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                                                                        
                                    logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Inserting log for rev service product creation: {product_data} and update fields are {update_fields}")
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                    try:
                                        # Preparing fields for sub-tenant update
                                        sub_tenant_update = {}
                                        if "customer_rate_plan_name" in update_fields and "customer_rate_plan_id" in update_fields and not parent_tenant_id:
                                            sub_tenant_update["sub_tenant_carrier_rate_plan_name"] = update_fields["customer_rate_plan_name"]
                                            sub_tenant_update["sub_tenant_customer_rate_plan_name"] = update_fields["customer_rate_plan_id"]
                                            sub_tenant_update["sub_tenant_carrier_rate_plan_name_id"] = update_fields["customer_rate_plan_id"]
                                            database.update_dict(
                                                "sim_management_inventory",
                                                sub_tenant_update,
                                                and_conditions={"is_active": True},
                                                in_conditions={"iccid": [iccid]},
                                            )
                                    except Exception as e:
                                        logging.exception("Error updating sub-tenant rate plan fields for SIM management inventory")
                                    
                                    logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Inserting log for product creation: {log}") 
                                    if rev_service_log:
                                        data_log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service: Update AMOP",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors":False,
                                            "response_status": "PROCESSED",
                                            "response_text": "OK" ,
                                            "error_text": "",
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                                        database.insert_data(data_log,"sim_management_bulk_change_log")
                                        #  insert the log entries into detailed logs table
                                        database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                        logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                #if createrevservice flag false then directly updating values into table
                                rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                try:
                                    # Preparing fields for sub-tenant update
                                    sub_tenant_update = {}
                                    if "customer_rate_plan_name" in update_fields and "customer_rate_plan_id" in update_fields and not parent_tenant_id:
                                        sub_tenant_update["sub_tenant_carrier_rate_plan_name"] = update_fields["customer_rate_plan_name"]
                                        sub_tenant_update["sub_tenant_carrier_rate_plan_name_id"] = update_fields["customer_rate_plan_id"]
                                        database.update_dict(
                                            "sim_management_inventory",
                                            sub_tenant_update,
                                            and_conditions={"is_active": True},
                                            in_conditions={"iccid": [iccid]},
                                        )
                                except Exception as e:
                                    logging.exception("Error updating sub-tenant rate plan fields for SIM management inventory")
                                successful_iccids.append(iccid)
                                database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK" },
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": [iccid]},
                                    )

                                #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")

                        except Exception as e:
                            logging.exception(f"### tmobilejasper_bc_assign_customer and {tenant_name} Unexpected error for ICCID {iccid}: {str(e)}")
                        logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Completed processing ICCID: {iccid}, Success: {success}, ID: {id}, Product ID: {productid}")
                        return iccid
                    futures[executor.submit(task)] = iccid
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.error(f"### tmobilejasper_bc_assign_customer and {tenant_name} Error processing iccid: {e}")
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
       
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        #logging.info("Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        if successful_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successful_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        "fields_updated": fields_to_update,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table update API
            try:
                logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_assign_customer and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": successful_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Assign Customer",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### tmobilejasper_bc_assign_customerr and {tenant_name} Exception in action history thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Invalid iccids found: {invalid_iccids}")
            # Log invalid IDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Assign customer ",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids},
            )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below syncs url is used to sync the 1.0 inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "TMobileJasper_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_assign_customer and {tenant_name} Exception in thread: {e}")

        try:
            if successful_iccids:
                data["iccids"]=successful_iccids
                data["CustomerRatePlanId"]=customer_rate_plan

                logging.info(f"### tmobilejasper_bc_assign_customer and {tenant_name} sync call for billing  has started")
                billing_integrtion_new(data)
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
       
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_assign_customer",
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Assign customer for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.warning(f"### tmobilejasper_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### tmobilejasper_bc_assign_customer and {tenant_name} Error during bulk change processing: {e}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "tmobilejasper_bc_assign_customer",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_assign_customer and {tenant_name} Logging error to DB failed: {e}")
 
        return response
  

## create rev service update function
def tmobilejasper_bc_create_rev_service(data):
    """
    Create Rev Serivice in Rev.IO for the provided MSISDNs, update inventory,
    and update device_tenant and rev_service_product tables accordingly.
    
    This function handles bulk requests with batching and parallelism, 
    updates the database, logs the results, and performs retries on API failures.

    Args:
        data (dict): Input data containing the following keys:
            - msisdns (list): List of msisdns to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to Rev.IO API.
            - created_by (str): User who initiated the request.
            - tenant_id (str): Tenant ID for DB operations.
            - db_name (str): DB name for tenant.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            - invalid_msisdns (list): msisdns to mark as invalid if required.
            - username (str): Username of the user initiating the request
            - tenant_name (str): Name of the tenant
            - role_name (str): Role of the user
            - access_token (str): Access token for sync API

    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Received data for Create Rev Serivice {data} ")
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    successful_msisdns = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### TMobileJasper_bc_create_rev_service and {tenant_name} time is {now}")

    # Check for missing required fields
    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### TMobileJasper_bc_create_rev_service and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### TMobileJasper_bc_create_rev_service and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### TMobileJasper_bc_create_rev_service and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch bulk change rows
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        # Validate input data 
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "TMobileJasper_bc_create_rev_service",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### TMobileJasper_bc_create_rev_service and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        service_type_id=change_request_json.get("ServiceTypeId","")
        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[])
        product_id = revproductidlist[0] if revproductidlist else None
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate= change_request_json.get("RateList", [])
        revpackageid=change_request_json.get("RevPackageId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer:
            customer_data=database.get_data(
                "customers",
                {"customer_name":rev_customer,"is_active": True},
                ["id","customer_name"]
            )
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        if device_id:
            update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        bulk_requests = bulk_requests.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        if rate:
            product_data["rate"] = rate
        if product_id:
            product_data["product_id"] = product_id
        # Validate msisdns
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"### TMobileJasper_bc_create_rev_service and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### TMobileJasper_bc_create_rev_service and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking msisdns and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of msisdns
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of msisdns
                batch = msisdns[i:i + batch_size]
                # create a dictionary to hold futures
                futures = {}
                logging.info(f"### TMobileJasper_bc_create_rev_service and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"### TMobileJasper_bc_create_rev_service and {tenant_name} Processing msisdn: {msisdn}")
                    payload_str = msisdn_to_changerequest.get(msisdn)
                    logging.info(f"### TMobileJasper_bc_create_rev_service and {tenant_name} Payload for MSISDN {msisdn}: {payload_str}")
                    
                    # Build payloads for all APIs
                    rev_api_payload = {
                        "customer_id": rev_customer_id,
                        "provider_id": provider_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "activated_date": activated_date,
                    }
                   
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    #task function
                    def task(msisdn=msisdn):
                        """
                            - Step 1: Call RevService API with retries
                            - Step 2: Extract RevService ID from API response
                            - Step 3: Insert into rev_service table & update inventory"""
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                       
                        try:                           
                            #  API Call to create the revservice
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Attempt {attempt} - URL: {url}")
                                    
                                    resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Response Code: {resp.status_code} for Create Rev Service")
                                    logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Response Text: {result}")
                                    status = "PROCESSED" if success else "API_Failed"
                                    if success:
                                        try:
                                            response_data = resp.json()
                                            id = response_data.get("id")
                                            successful_msisdns.append(msisdn)
                                        except Exception:
                                            id = None
                                        break
                                except Exception as e:
                                    result = str(e)
                                    status = "API_EXCEPTION"
                                    logging.exception(f"### pod19_bc_create_rev_service and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                    time.sleep(RETRY_DELAY)                
                            if success:
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":result},
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number": msisdns},
                                )
                                #inserting values in rev service 
                                rev_data={
                                "rev_customer_id":rev_customer_uuid,
                                "number":msisdn,
                                "rev_service_id":id,
                                "activated_date":activated_date,
                                "is_active":True,
                                "integration_authentication_id":integration_authentication_id,
                                "rev_provider_id":rev_provider_id,
                                "rev_service_type_id":service_type_id,
                                "rev_service_line_status":"PROCESSED",
                                "bulk_change_id":bulk_change_id,
                                }
                                rev_insert_id=database.insert_data(rev_data,"rev_service")
                                if rev_insert_id:
                                    update_fields["rev_service_id"]=rev_insert_id
                                #updating inventory table
                                rev_service_log=database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"tenant_id":tenant_id,"is_active": True},
                                    in_conditions={"msisdn": [msisdn]}
                                )
                            # Inserting logs based on api result
                            rev_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Create Rev.io Service: Rev.io API",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors": status == "PROCESSED",
                                    "response_status": "PROCESSED" if success else "API_Failed",
                                    "response_text": result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                            database.insert_data(rev_log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(rev_log,"sim_management_bulk_change_detailed_logs") 
                            logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Rev Service created successfully for MSISDN: {msisdn}")
                            #inserting logs after updating inventory table
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Create Rev.io Service: Update AMOP",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors":False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK" ,
                                    "error_text": "",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Inventory updated successfully for MSISDN: {msisdn}")       
                        except Exception as e:
                            logging.exception(f"### pod19_bc_create_rev_service and {tenant_name} Unexpected error for msisdn {msisdn}: {str(e)}")
                        logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Completed processing for MSISDN: {msisdn}")
                        return msisdn
                    futures[executor.submit(task)] = msisdn
                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### pod19_bc_create_rev_service and {tenant_name} Error processing MSISDN in thread: {e}")
        if interval and i + batch_size < len(msisdns):
            time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Processed %d msisdns, %d remaining", len(msisdns) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":successful_msisdns,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        # Call sync API for history table
        try:
            logging.info(f"### pod19_bc_create_rev_service and {tenant_name} sync call has started for history table")
            threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### pod19_bc_create_rev_service and {tenant_name} Exception in thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_ids:
            logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Invalid msisdns found: %s", invalid_ids)
            # Log invalid IDs
            for request_id in invalid_ids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Create Rev Serivice ",
                    "request_text": "Update AMOP",
                    "has_errors": True, 
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_ids:
            database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","is_processed":True,"has_errors":True,"status_details":"Invalid SIM - could not be processed"},
                    and_conditions={"bulk_change_id": bulk_change_id},
                    in_conditions={"id": invalid_ids},
                )
        # Insert log entries into DB
        if log_entries: 
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Bulk Change ID: {bulk_change_id}")
        logging.info(f"### pod19_bc_create_rev_service and {tenant_name} Processed %d msisdns, %d remaining", len(msisdns) - len(remaining), len(remaining))
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token, 
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call for inventory table
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "pod19_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### pod19_bc_create_rev_service and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### pod19_bc_create_rev_service and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### pod19_bc_create_rev_service  and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            audit_data_user_actions = {
                "service_name": "pod19_bc_create_rev_service",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Create Rev Serivice for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### pod19_bc_create_rev_service and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### pod19_bc_create_rev_service and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### pod19_bc_create_rev_service and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response


##Update Line Sync function
def tmobilejasper_bc_line_sync(data):
    """
    Sync SIM inventory and bulk change requests with the tmobilejasper API.

    This function processes a list of ICCIDs for a given bulk change operation
    and updates their details by calling the carrier's tmobilejasper API. It includes
    retry logic, database updates, inventory synchronization, error handling,
    and audit logging.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains request payload and UpdateStatus information.
            - service_provider (str): Name of the carrier/service provider.
            - change_type (str): Type of update (e.g., SIM/device status).
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant (for logs/audit).
            - db_name (str): Tenant-specific database name.
            - service_provider_id (str): Identifier for the service provider.
            - invalid_iccids (list): ICCIDs that failed validation before processing.

    Returns:
        dict: Response object summarizing the processing result:
            - flag (bool): True if operation completed without unhandled errors.
            - message (str): Summary of result (success or failure).
            - processed (int): Number of ICCIDs successfully processed.
            - remaining (int): Number of ICCIDs not processed.
            - iccids (list): List of ICCIDs attempted.
            - invalid_iccids (list): ICCIDs skipped due to invalid input.
            - bulk_change_id (str): Bulk change request ID.
            - error (str, optional): Error message if processing failed.
    """
    logging.info(f"### Received data for line sync: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source = data.get("source", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    provider_parent_name = data.get("parent_provider_name", "")
    
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### tmobilejasper_bc_line_sync and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    
    tenant_database = data.get("db_name", "")
    access_token = data.get("access_token", "")
    role_name = data.get("role_name", "")
    
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_line_sync and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id, 20)
    
    try:
        # Get carrier API credentials and configuration
        provider = provider_parent_name if provider_parent_name else service_provider
        logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
        carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
            provider, change_type, common_utils_database
        )
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### tmobilejasper_bc_line_sync and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid"]
        ).rename(columns={"iccid": "iccid"})
        
        if bulk_requests_df.empty:
            message = f"Bulk Change Request data is empty"
            response = {"flag": False, "message": message}
            error_update_data = {"errors": len(iccids), "status": "ERROR"}
            database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
            )
            
            # Attempt to audit the action
            try:
                end_time = time.time()
                time_consumed = end_time - start_time
                time_consumed = int(round(time_consumed))
                audit_data_user_actions = {
                    "service_name": "tmobilejasper_bc_line_sync",
                    "created_by": username,
                    "status": json.dumps(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": message,
                    "request_received_at": now,
                }
            
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### tmobilejasper_bc_line_sync and {tenant_name} Audit logging failed: {e}")
            return response
        
        # Fetch existing inventory data
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": iccids, "tenant_id": tenant_id}
        ).to_dict(orient="records")

        # CREATE A SET OF EXISTING ICCIDS
        existing_iccids = {item["iccid"] for item in old_inventory_data}
        new_iccids = [iccid for iccid in iccids if iccid not in existing_iccids]
        existing_iccids_list = [iccid for iccid in iccids if iccid in existing_iccids]

        logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Found {len(existing_iccids_list)} existing ICCIDs and {len(new_iccids)} new ICCIDs")

        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        
        if PARALLEL_REQUESTS > 10:
            logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS = 10
        
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        changed_data = []
        remaining = list(iccids)
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}/{iccid}"                

                    def task(iccid=iccid, url=url):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        updated = None
                        inserted = None
                        is_new_iccid = iccid in new_iccids  # Check if this is a new ICCID
                        
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.get(url, 
                                    headers={
                                        "Authorization": app_id,
                                        "Content-Type": "application/json"
                                    }, timeout=60)
                                logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### tmobilejasper_bc_line_sync and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                            "processed_date": now, "status_details": resp.text if success else result},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            api_data = resp.json()
                            
                            if is_new_iccid:
                                # INSERT new ICCID - create full record
                                try:
                                    to_insert = {
                                        "iccid": api_data.get("iccid"),
                                        "imsi": api_data.get("imsi"),
                                        "msisdn": api_data.get("msisdn"),
                                        "imei": api_data.get("imei", ""),   
                                        "sim_status": api_data.get("status"),
                                        "carrier_rate_plan_name": api_data.get("ratePlan"),
                                        "date_activated": api_data.get("dateActivated"),
                                        "date_added": api_data.get("dateAdded"),
                                        "account_number": api_data.get("accountId"),
                                        "modified_by": username,
                                        "tenant_id": tenant_id,
                                        "created_by": username,
                                        "created_date": now,
                                        "is_active": True,
                                        "is_deleted": False,
                                        "tenant_is_active": True,
                                        "tenant_is_deleted": False,
                                        "service_provider_is_active": True,
                                        "service_provider_display_name": service_provider,
                                        "service_provider_id": service_provider_id
                                    }
                                    
                                    inserted_id = database.insert_data(to_insert, "sim_management_inventory")
                                    if inserted_id:
                                        inserted = True
                                        logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Inserted new ICCID: {iccid} with ID: {inserted_id}")
                                        
                                        # For new ICCIDs, all fields are considered as changes
                                        field_changes = {}
                                        for field, new_value in to_insert.items():
                                            if field not in ["id", "created_date", "modified_by", "tenant_id", "created_by", "is_active", "is_deleted"]:
                                                field_changes[field] = {
                                                    "old_value": None,
                                                    "new_value": new_value
                                                }
                                        
                                        if field_changes:
                                            changed_data.append({
                                                "field_changes": field_changes, 
                                                "id": inserted_id,
                                                "iccid": api_data.get("iccid"),
                                                "msisdn": api_data.get("msisdn"),
                                                "old_record": {}  # Empty for new ICCID
                                            })
                                except Exception as insert_error:
                                    logging.error(f"### tmobilejasper_bc_line_sync and {tenant_name} Failed to insert new ICCID {iccid}: {insert_error}")
                                    inserted = False
                                    
                            else:
                                # UPDATE existing ICCID
                                old_record = next((item for item in old_inventory_data if item.get("iccid") == api_data.get("iccid")), {})
                                
                                if old_record:
                                    # Original update structure
                                    to_update = {
                                        "iccid": api_data.get("iccid"),
                                        "imsi": api_data.get("imsi"),
                                        "msisdn": api_data.get("msisdn"),
                                        "imei": api_data.get("imei", ""),   
                                        "sim_status": api_data.get("status"),
                                        "carrier_rate_plan_name": api_data.get("ratePlan"),
                                        "date_activated": api_data.get("dateActivated"),
                                        "date_added": api_data.get("dateAdded"),
                                        "account_number": api_data.get("accountId"),
                                        "modified_by": username,

                                    }
                                 
                                    exclude_fields = ["iccid"]  
                                    keys_to_check = [key for key in to_update.keys() if key not in exclude_fields]
                                    to_update, field_changes = build_detailed_update_dict(to_update, old_record, keys_to_check)
                                    
                                    if to_update:
                                        # Include the ID for update
                                        # to_update["id"] = old_record["id"]
                                        to_update["modified_by"] = username
                                        updated = database.update_dict(
                                            "sim_management_inventory",
                                            values=to_update,
                                            and_conditions={"id": old_record["id"]},
                                        )
                                    
                                    # Store field changes for batch processing
                                    if field_changes:
                                        changed_data.append({
                                            "field_changes": field_changes, 
                                            "id": old_record["id"],
                                            "iccid": api_data.get("iccid"),
                                            "msisdn": api_data.get("msisdn"),
                                            "old_record": old_record  # Add the old data for history
                                        })

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update tmobilejasper Subscriber: tmobilejasper API",
                            "request_text": None,
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            # Insert the log entries into detailed logs table
                            database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                            
                        # Prepare inventory log entry based on operation type
                        inventory_success = updated if not is_new_iccid else inserted
                        operation_type = "Inserted" if is_new_iccid else "Updated"
                        
                        inventory_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": f"{operation_type} Inventory Record",
                            "request_text": None,
                            "has_errors": not inventory_success,
                            "response_status": "PROCESSED" if inventory_success else "ERROR",
                            "response_text": f"Inventory {operation_type.lower()} successfully" if inventory_success else f"Inventory {operation_type.lower()} failed",
                            "error_text": "" if inventory_success else f"Inventory {operation_type.lower()} failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }

                        if inventory_log:
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")
                            # Insert the log entries into detailed logs table
                            database.insert_data(inventory_log, "sim_management_bulk_change_detailed_logs")   
                            
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### tmobilejasper_bc_line_sync and {tenant_name} Error processing ICCID: {e}")

                if INTERVAL and i + BATCH_SIZE < len(iccids):
                    time.sleep(INTERVAL)
        
        # Handle and log invalid ICCIDs
        # Prepare the payload for history table
        if successfull_ids:
            url_history_table = os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                "data": {
                    "tenant_name": tenant_name,
                    "username": username,
                    "path": "/update_device_history_tables",
                    "change_type": change_type,
                    "iccids": successfull_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                }
            }
            # API call to update the history table
            try:
                logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_line_sync and {tenant_name} Exception in thread: {e}")

        if source == "Inventory" and changed_data:
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            
            # Use json.dumps with default=str for the entire payload
            action_history_payload = json.loads(json.dumps({
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": successfull_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Line Sync",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_data": changed_data
                }
            }, default=str))
            # API call to update action history
            try:
                logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_line_sync and {tenant_name} Exception in action history thread: {e}")
                
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update tmobilejasper Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs, "sim_management_bulk_change_log")
            # Insert the log entries into detailed logs table
            database.insert_data(logs, "sim_management_bulk_change_detailed_logs")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        # Sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {
                    "bulk_change_id": bulk_change_id
                },
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        
        # Sync API to update the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
            "data": {
                "access_token": access_token,
                "key_name": "tmobilejasper_bulkchange_sync",
                "path": "/bulk_change_sync_10_updated",
                "tenant_name": tenant_name,
                "bulk_change_id": bulk_change_id
            }
        }
        
        try:
            logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id, 80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_line_sync and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response = {
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": f"Bulk change request processed successfully. {len(new_iccids)} new ICCIDs inserted, {len(existing_iccids_list)} existing ICCIDs updated.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id,
            "new_iccids_inserted": len(new_iccids),
            "existing_iccids_updated": len(existing_iccids_list)
        }
       
        live_progress_percentage_tracker(database, bulk_change_id, 95)
        
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_line_sync",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for line sync. {len(new_iccids)} new ICCIDs inserted, {len(existing_iccids_list)} existing ICCIDs updated. Bulk Change ID: {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            
            # Auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_line_sync and {tenant_name} Audit logging failed: {e}")
        
        # Final auditing the success log
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Completed"
        )
        live_progress_percentage_tracker(database, bulk_change_id, 100)
        
        # Prepare success response
        logging.info(f"### tmobilejasper_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### tmobilejasper_bc_line_sync and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data = {"errors": len(remaining), "status": "ERROR", "status_details": "Something went wrong while processing!"}
        
        database.update_dict(
            "sim_management_bulk_change",
            error_update_data,
            and_conditions={"id": bulk_change_id},
        )
        
        # Prepare error response
        try:
            error_data = {
                "service_name": "tmobilejasper_bc_line_sync",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### tmobilejasper_bc_line_sync and {tenant_name} Exception in logging error data to DB: {log_e}")
        
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response

##Private Network IP function
def tmobilejasper_bc_private_network_ip(data):
    """
    Assign Private Network IPs for multiple SIMs under T-Mobile Jasper service provider.

    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs (SIMs) to process.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - changed_data (dict or str): Payload to be sent to Cisco Jasper API 
              containing 'ipv6Address'/'ipv4Address', 'apn', and 'pdpId'.
            - created_by (str): User who initiated the bulk change.
            - service_provider (str): Name of the carrier (e.g., "T-Mobile Jasper").
            - change_type (str): Type of change being performed (e.g., "Private Network IP").

    Returns:
        dict: Summary of the operation containing:
            - flag (bool): Indicates success (True) or failure (False) of the process.
            - message (str): Summary message describing the operation result.

    """
    logging.info(f"### Received data for assign private network ip :{data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
   
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###tmobilejasper_bc_private_network_ip and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_private_network_ip and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            raw_change_request_json=bulk_requests_df.iloc[0]["change_request"]
            if not raw_change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_private_network_ip",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Audit logging failed: {e}")
                return response
            
        # Extract Ip address, APN, and protocol ID from change_request 
        if isinstance(raw_change_request_json, str):             
           change_request_json = json.loads(raw_change_request_json)   
        change_request_json = change_request_json.get("changedData", {})          
        if isinstance(change_request_json, str):             
           change_request_json = json.loads(change_request_json)    
        ip_address= change_request_json.get("ipv6Address") or change_request_json.get("ipv4Address","")
        # Validate mandatory ip address
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","ip_address"]
            ).to_dict(orient="records")

        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        iccid_to_changerequest = dict(zip(bulk_requests_df.iccid, bulk_requests_df.change_request))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        if PARALLEL_REQUESTS>10:
           logging.info(f"###tmobilejasper_bc_private_network_ip and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(iccids)
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}
                for iccid in batch:
                    url = f"{carrier_api_url}/{iccid}"                
                    payload_str=iccid_to_changerequest.get(iccid)
                    request_payload = json.loads(payload_str)
                    payload = request_payload.get("changedData", {})
                    logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Payload for ICCID {iccid}: {payload}")                                                        
                    def task(iccid=iccid, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        resp = None
                        # carrier API call with retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.put(url, json=payload, 
                                headers={
                                            "Authorization": app_id,
                                            "Content-Type": "application/json"
                                        }, timeout=60)
                                logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":resp.text},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )
                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Assign private network ip: ciscojasper API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        # Update inventory if successful
                        if success:
                            inventory_flag = database.update_dict(
                                "sim_management_inventory",
                                {
                                    "ip_address":ip_address                                 },
                                and_conditions={"tenant_id": tenant_id,"service_provider_id": service_provider_id, "is_active": True},
                                in_conditions={"iccid": [iccid]}
                            )
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Amop",
                                "request_text": json.dumps({"ipaddress": ip_address}),
                                "has_errors": not inventory_flag,
                                "response_status": "PROCESSED" if inventory_flag else "ERROR",
                                "response_text": "Inventory updated successfully." if inventory_flag else "Inventory update failed.",
                                "error_text": "" if inventory_flag else "Failed to update inventory.",
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Error processing ICCID: {e}")

            if INTERVAL and i + BATCH_SIZE < len(iccids):
                time.sleep(INTERVAL)
        # Handle and log invalid ICCIDs
        #prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successfull_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": successfull_ids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Update Device Status",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "ipaddress",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Exception in action history thread: {e}")
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Assign private network ip: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(logs,"sim_management_bulk_change_detailed_logs")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )
        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )
        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "tmobilejasper_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Exception in thread: {e}")

        try:
            if successfull_ids:
                data["iccids"]=successfull_ids
                logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_private_network_ip",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for assigining pnip address for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR","status_details":"Processing Invalid Sim"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "tmobilejasper_bc_private_network_ip",
                "created_date": data.get("request_received_at") or now,
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### tmobilejasper_bc_private_network_ip and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response

### To update Communication Plan 
def tmobilejasper_bc_change_communication_plan(data):
    """
   Update the Communication Plan using the T-Mobile Jasper API.

    This function processes a list of Iccids and updates their Communication plan in the T-Mobile Jasper system.
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps Iccids to their respective request payloads.
        - Iteratively calls the T-Mobile Jasper API for each Iccid with retry logic.
        - Updates Communication plan in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid Iccids or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of iccids to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the T-Mobile Jasper API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., Communication plan).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_iccids (list): iccids that failed validation before processing.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict: A response object indicating the result of the operation, containing:
            - flag (bool): True if processing completed without unhandled exceptions.
            - message (str): Summary message indicating the result.
            - processed (int): Number of iccids processed.
            - iccids (list): List of iccids attempted.
            - invalid_iccids (list): List of iccids skipped due to invalid state.
            - bulk_change_id (str): ID of the bulk change request.
            - error (str, optional): Error message in case of failure.
    """
    logging.info(f"### Received data for updating communication plan: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    change_type = data.get("change_type",'')
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    provider_parent_name=data.get("parent_provider_name", "")
   
    # Extract comm_plan_id value from changed_data
    comm_plan_id = data.get("comm_plan_id","")
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###tmobilejasper_bc_change_communication_plan and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        provider = provider_parent_name if provider_parent_name else service_provider
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")

        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        ).rename(columns={"iccid": "iccid"})
        if not bulk_requests_df.empty:
            change_request_json=bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_change_communication_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Audit logging failed: {e}")
                return response
        # Extract update communication_id from change_request_json
        if isinstance(change_request_json, str):             
           change_request_json = json.loads(change_request_json)  
        comm_plan_id = change_request_json.get("Comm_plan_id", "") 
        comm_plan_data = pd.DataFrame()
        comm_plan_name = None
        ##fetching the communication plan name of the device to get updated using comm_plan_id
        if comm_plan_id :
            comm_plan_data = database.get_data(
                "sim_management_communication_plan",
                {"id": comm_plan_id,"service_provider_name": service_provider, "is_active": True},
                ["communication_plan_name"]
            )
            if not comm_plan_data.empty:
                comm_plan_name = comm_plan_data["communication_plan_name"].iloc[0]
                logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} communication plan: {comm_plan_name}")
            else:
                logging.error(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} No communication plan found for id: {comm_plan_id}")    
        else : 
            logging.error(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Missing communication plan id in request")        
            
        # Fetch ALL columns only once
        device_info_df = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": iccids, "tenant_id": tenant_id}
        )

        # old inventory → select only required 4 columns
        required_cols = ["id", "iccid", "msisdn", "communication_plan"]
        old_inventory_data = (
            device_info_df[required_cols]
            .to_dict(orient="records")
        ) 
        logging.info(f"### tmobilejasper_bc_change_communication_plan old_inventory_data : {old_inventory_data}")     

        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        if PARALLEL_REQUESTS>10:
           logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        remaining = list(iccids)
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}/{iccid}"
                    payload={"communicationPlan": comm_plan_name}                 

                    def task(iccid=iccid, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.put(url, json=payload, 
                        headers={
                                    "Authorization": app_id,
                                    "Content-Type": "application/json"
                                }, timeout=60)
                                logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":resp.text},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )
                        # Update inventory if successful
                        if success:
                            database.update_dict(
                                "sim_management_inventory",
                                {
                                    "communication_plan": comm_plan_name,
                                    "communication_plan_id": comm_plan_id,
                                    "modified_by":username,
                                },
                                and_conditions={"service_provider_id": service_provider_id, "is_active": True,"tenant_id": tenant_id},
                                in_conditions={"iccid": [iccid]}
                            )
                            logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Updated inventory for ICCID: {iccid}, communication_plan : {comm_plan_name},service_provider_id: {service_provider_id}")
                            logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} iccids are {[iccid]}")

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update T-Mobile Jasper Subscriber: T-Mobile Jasper API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Error processing ICCID: {e}")

            if INTERVAL and i + BATCH_SIZE < len(iccids):
                time.sleep(INTERVAL)
        #prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": successfull_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": successfull_ids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Update Device Status",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "communication_plan",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Exception in action history thread: {e}")
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update T-Mobile Jasper Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(logs,"sim_management_bulk_change_detailed_logs")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "tmobilejasper_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Exception in thread: {e}")     
        
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_change_communication_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for update device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR","status_details":"Processing Invalid Sim"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "tmobilejasper_bc_change_communication_plan",
                "created_date": data.get("request_received_at") or now,
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### tmobilejasper_bc_change_communication_plan and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response


def build_detailed_update_dict(api_record, inventory_row, keys_to_check):
    """
    Build update dictionary with detailed field-level change tracking
   
    Args:
        api_record (dict): Data from carrier API
        inventory_row (pd.Series): Current inventory data
        keys_to_check (list): Fields to compare
   
    Returns:
        tuple: (to_update_dict, field_changes_list)
    """
    to_update = {}
    field_changes = []
   
    for key in keys_to_check:
        api_value = api_record.get(key)
        current_value = inventory_row.get(key)
       
        # Handle different data types and None values
        if pd.isna(current_value) or current_value is None:
            current_value = ""
        if pd.isna(api_value) or api_value is None:
            api_value = ""
           
        # Convert to string for comparison
        str_current = str(current_value).strip() if current_value is not None else ""
        str_api = str(api_value).strip() if api_value is not None else ""
       
        if str_current != str_api:
            to_update[key] = api_value
            field_changes.append({
                'field': key,
                'previous_value': str_current,
                'current_value': str_api
            })
            logging.info(f"### Field changed: {key}, From: '{str_current}', To: '{str_api}'")
   
    return to_update, field_changes


def tmobilejasper_bc_send_sms(data):
    """Send SMS messages to tmobilejasper-connected devices and check delivery status.
    This function processes a list of iccids, sends SMS messages via Tmobilejasper API,
    and immediately checks the message status using the returned SMS Message ID.
    It handles bulk requests, updates the database, and logs the results.
    
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDS to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Tmobilejasper API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Received data for send SMS :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    service_provider_id = data.get("service_provider_id", "")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    
    # Extract SMS message text directly from changed_data
    changed_data = data.get("changed_data", {})
    message_text = changed_data.get("messageText", "")
    
    # Initialize for log entries
    log_entries = []
    success_iccids = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} time is {now}")
    
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### tmobilejasper_bc_send_sms and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    
    # Validate mandatory message text
    if not message_text:
        logging.error(f"### tmobilejasper_bc_send_sms and {tenant_name} Message text is required for sending SMS")
        return {"flag": False, "message": "Message text is required for sending SMS"}
    
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    
    try:
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id, 10)
    except Exception as e:
        logging.error(f"### tmobilejasper_bc_send_sms and {tenant_name} Audit logging failed: {e}")
    
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message = f"Bulk Change Request data is empty"
                response = {"flag": False, "message": message}
                error_update_data = {"errors": len(iccids), "status": "ERROR"}
                database.update_dict(
                    "sim_management_bulk_change",
                    error_update_data,
                    and_conditions={"id": bulk_change_id},
                )
                live_progress_percentage_tracker(database, bulk_change_id, 100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "tmobilejasper_bc_send_sms",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### tmobilejasper_bc_send_sms and {tenant_name} Audit logging failed: {e}")
                return response
            live_progress_percentage_tracker(database, bulk_change_id, 20)
        
        # Map iccids to request IDs
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        
        # Prepare SMS payload 
        payload = {
            "messageText": message_text
        }
        
        # Carrier limits
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### tmobilejasper_bc_send_sms and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": "Invalid carrier details"}
        
        batch_size = carrier_limits.get("batch_size", 100)
        parallel_requests = carrier_limits.get("parallel_requests", 10)
        if parallel_requests > 10:
            logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests = 10
        interval = carrier_limits.get("interval_minutes", 0) * 60
        logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        remaining = list(iccids)
        
        # Construct headers for Jasper API
        headers = {
            "Authorization": f"{app_id}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        
        # Chunking iccids and processing each batch in parallel using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each iccid in the batch
                logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} iccids")
                
                for iccid in batch:
                    def task(iccid=iccid):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        sms_message_id = None
                        
                        # Prepare the URL for POST API call
                        post_url = f"{carrier_api_url}/devices/{iccid}/smsMessages"
                        
                        # FIRST API CALL: POST - Send SMS
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Attempting POST {attempt} for iccid: {iccid} with URL: {post_url}")
                                
                                # STEP 1: POST - Send SMS
                                post_resp = requests.post(
                                    post_url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} POST Response Code: {post_resp.status_code} for iccid: {iccid}")
                                
                                if 200 <= post_resp.status_code < 300:
                                    # Extract SMS Message ID from POST response
                                    post_response_data = post_resp.json()
                                    sms_message_id = post_response_data.get("smsMessageId")
                                    
                                    if sms_message_id:
                                        result = f"SMS sent successfully. Message ID: {sms_message_id}"
                                        success = True
                                        status = "POST_SUCCESS"
                                        break
                                    else:
                                        result = f"SMS sent but no Message ID returned. Response: {post_resp.text}"
                                else:
                                    result = f"POST API Error: {post_resp.status_code} - {post_resp.text}"
                                    logging.warning(f"### tmobilejasper_bc_send_sms and {tenant_name} POST Attempt {attempt} failed for iccid: {iccid}: {result}")
                                    
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### tmobilejasper_bc_send_sms and {tenant_name} POST Attempt {attempt} failed for iccid: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)
                        
                        # If POST failed, update status and return
                        if not success:
                            update_data = {
                                "status": status,
                                "has_errors": True,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details": result
                            }
                            
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                update_data,
                                and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id},
                            )
                            
                            # Log POST failure
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Send SMS: POST to Tmobilejasper API",
                                "request_text": json.dumps(payload),
                                "has_errors": True,
                                "response_status": "POST_Failed",
                                "response_text": result,
                                "error_text": result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            
                            return iccid
                        
                        # SECOND API CALL: GET - Check SMS Status (only if POST succeeded)
                        get_success = False
                        get_result = ""
                        get_status = "GET_FAILED"
                        
                        get_url = f"{carrier_api_url}/smsMessages/{sms_message_id}"
                        logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Checking SMS status with GET URL: {get_url}")
                        
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Attempting GET {attempt} for Message ID: {sms_message_id} with URL: {get_url}")
                                
                                # STEP 2: GET - Check SMS Status
                                get_resp = requests.get(get_url, headers=headers, timeout=30)
                                logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} GET Response Code: {get_resp.status_code} for Message ID: {sms_message_id}")
                                
                                if 200 <= get_resp.status_code < 300:
                                    get_response_data = get_resp.json()
                                    sms_status = get_response_data.get("status", "")
                                    get_result = f"SMS status checked. Message ID: {sms_message_id}, Status: {sms_status}"
                                    get_success = True
                                    get_status = "PROCESSED"
                                    success_iccids.append(iccid)
                                    break
                                else:
                                    get_result = f"GET API Error: {get_resp.status_code} - {get_resp.text}"
                                    logging.warning(f"### tmobilejasper_bc_send_sms and {tenant_name} GET Attempt {attempt} failed for Message ID: {sms_message_id}: {get_result}")
                                    
                            except Exception as e:
                                get_result = str(e)
                                logging.warning(f"### tmobilejasper_bc_send_sms and {tenant_name} GET Attempt {attempt} failed for Message ID: {sms_message_id}: {get_result}")
                                time.sleep(RETRY_DELAY)
                        
                        # Update the request status after both API calls
                        final_status = get_status if get_success else "GET_FAILED"
                        final_result = f"{result}. {get_result}" if get_success else f"{result}. GET failed: {get_result}"
                        
                        update_data = {
                            "status": final_status,
                            "has_errors": not get_success,
                            "is_processed": True,
                            "processed_date": now,
                            "status_details": final_result
                        }
                        
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id},
                        )
                        
                        # Constructing the final log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Send SMS: Tmobilejasper API",
                            "request_text": json.dumps(payload),
                            "has_errors": not get_success,
                            "response_status": final_status,
                            "response_text": final_result,
                            "error_text": "" if get_success else get_result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        
                        return iccid
                    
                    # Submit the task to the executor
                    logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Submitting task for ICCID: {iccid}")
                    futures[executor.submit(task)] = iccid
                
                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        if iccid in remaining:
                            remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### tmobilejasper_bc_send_sms and {tenant_name} Error processing ICCID: {e}")
                
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
        
        # Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status
        logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Processed {len(iccids) - len(remaining)} iccids, {len(remaining)} remaining")
        
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id, 75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Send SMS",
                    "request_text": "Send SMS via Tmobilejasper API",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                 "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids},
            )
        
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries, "sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        
        logging.info(f"### pod19_bc_send_sms and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### pod19_bc_send_sms and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        
        response = {"flag": True, "processed": len(iccids) - len(remaining), "remaining": len(remaining),
                   "message": "Bulk SMS request processed successfully.",
                   "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        
        # Call sync API in separate thread
        live_progress_percentage_tracker(database, bulk_change_id, 80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {
                    "bulk_change_id": bulk_change_id
                },
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
            "data": {
                "access_token": access_token,
                "key_name": "tmobilejasper_bulkchange_sync",
                "path": "/bulk_change_sync_10_updated",
                "tenant_name": tenant_name,
                "bulk_change_id": bulk_change_id
            }
        }
        
        try:
            logging.info(f'### tmobilejasper_bc_send_sms and {tenant_name} sync call has started')
            live_progress_percentage_tracker(database, bulk_change_id, 90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f'### tmobilejasper_bc_send_sms and {tenant_name} sync call has ended')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_send_sms and {tenant_name} Exception in thread: {e}")
        
        # Return success
        logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Bulk SMS request processed successfully.")
        logging.info(f"### tmobilejasper_bc_send_sms and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        
        live_progress_percentage_tracker(database, bulk_change_id, 95)
        
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "tmobilejasper_bc_send_sms",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk SMS request for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_send_sms and {tenant_name} Audit logging failed: {e}")
        
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Completed"
        )
        
        live_progress_percentage_tracker(database, bulk_change_id, 100)
        return response
        
    except Exception as e:
        # Main exception block
        logging.exception(f"### tmobilejasper_bc_send_sms and {tenant_name} Error during bulk SMS processing: {str(e)}")
        error_message = f"Error during bulk SMS processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk SMS request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data = {"errors": len(remaining), "status": "ERROR"}
        database.update_dict(
            "sim_management_bulk_change",
            error_update_data,
            and_conditions={"id": bulk_change_id},
        )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "tmobilejasper_bc_send_sms",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk SMS request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### tmobilejasper_bc_send_sms and {tenant_name} Exception in logging error data to DB: {e}")
        
        return response


def billing_platform_bulk_change_20_sync(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    customername= data.get("customername","")
    use_carrier_activation=data.get("use_carrier_activation")


    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}

        path_map = {
            "Update Device Status": "/bulk_update_device_status",
            "Change Customer Rate Plan": "/bulk_update_customer_rate_plan_service_line_creation",
            "Assign Customer": "/bulk_update_assign_customer_service_line_creation",
            "Change ICCID/IMEI": "/bulk_update_iccid_imei_service_line_creation"
        }
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        billing_flag=False
        billing_platform_flag=common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["billing_platform_flag"]
        )
        if not billing_platform_flag.empty:
            billing_flag=billing_platform_flag.iloc[0]["billing_platform_flag"]
        
        if change_type in path_map:
            logging.info(f"Processing change request type: {change_type}")

            path = path_map[change_type]
            data['path'] = path
        columns = [
                "iccid",
                "subscriber_number",
                "m2m_id",
                "bulk_change_id",
                "tenant_name",
                "created_by",
                "processed_by",
                "status",
                "device_id",
                "is_active",
                "is_deleted",
                "change_request",
                "id"
            ]
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            columns
        )
        bulk_change_requests = []
        if not request_data.empty:
            bulk_change_requests = request_data.to_dict(orient="records")
        for rec in bulk_change_requests:
            rec["device_change_request_id"] = rec["iccid"]
        change_columns = [
            "service_provider",
            "change_request_type_id",
            "change_request_type",
            "service_provider_id",
            "modified_by",
            "status",
            "uploaded",
            "is_active",
            "is_deleted",
            "created_by",
            "processed_by",
            "tenant_id",
            "id_10"
        ]
        change_data = database.get_data(
            "sim_management_bulk_change",
            {"id": bulk_change_id,"status":"PROCESSED"},
            change_columns
        )
        bulk_change_records = []
        if not change_data.empty:
            bulk_change_records = change_data.to_dict(orient="records")
        
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
                "path":path,
                "data": {
                    "tenant_name":tenant_name,
                    "username": username,
                    "firstLastName": username,
                    "path": path,
                    "role_name": role_name,
                    "module_name": "Bulk Change",
                    "mod_pages": {
                    "start": 0,
                    "end": 100
                    },
                    "access_token": access_token,
                    "db_name": db_name,
                    "sessionID": None,
                    "request_received_at": now,
                    "Partner": tenant_name,
                    "service_provider_id":service_provider_id,
                    "bulkchange_id": bulk_change_id,
                    "customername": customername,
                    "data": {
                    "sim_management_bulk_change": bulk_change_records,         
                    "sim_management_bulk_change_request": bulk_change_requests
                    },
                    "bulk_chnage_id_20": bulk_change_id,
                    "use_carrier_activation": use_carrier_activation,
                    "carrier_api_status": True,
                    "billing_platform_flag": billing_flag
                }
                }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": data.get("Partner",""),
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "Sim Management",
                "request_received_at": data.get("request_received_at",""),
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": data.get("username",""),
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}




##SYNC API call function
def call_sync_api(api_url, api_payload):
    '''
    Call the sync API with the provided URL and payload.
    This function is designed to be run in a separate thread after a delay.
    '''
    try:
        # Make the API call
        logging.info(f"### Calling sync API: {api_url} with payload: {api_payload}")
        response = requests.post(api_url, json=api_payload)
        if response.status_code == 200:
            logging.info("Bulk Change API call successful. Data sync call successfully done.")
        else:
            logging.error(f"API call failed with status code: {response.status_code}")
    except Exception as e:
        logging.error(f"Error making API call: {e}")

## Function to audit user actions in bulk change processing
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
   
    request_received_at = data.get("request_received_at", "") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
        logging.info("User action audited successfully.")
    except Exception as e:
        logging.exception(f"### Error logging user actions: {e}")


def live_progress_percentage_tracker(database, bulk_change_id,progress_percent):
    """
    Updates the live_progress_percentage column in sim_management_bulk_change_request table.
    """
    try:
        update_fields={}
        #updating sync status when progress percentage reached 100
        if progress_percent==100:
            update_fields["live_progress_percentage"]=progress_percent
            update_fields["progress"]="Sync Completed"
        else:
            update_fields["live_progress_percentage"]=progress_percent

        database.update_dict(
            "sim_management_bulk_change",
            update_fields,
            and_conditions={"id": bulk_change_id}
        )
        return True
    except Exception as e:
        logging.error(f"Error updating live progress: {e}")
        return False

def update_for_partner_to_provider(data, primary_key):
    """
    Updates inventory data for a partner becoming a provider.
    Supports multiple MSISDNs/ICCID, source DBs, and target DBs.

    Parameters:
        data (dict): Input data including db info, changed_data, target_details, etc.
        primary_key (str): Either 'msisdn' or 'iccid'.

    Returns:
        dict: Response dict with 'flag' and 'message'.
    """
    logging.info(f"### Starting update_for_partner_to_provider with data: {data}")
    start_time = time.time()
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    changed_data = data.get('changed_data', [])
    change_type = data.get('change_event_type')
    provider_parent_name = data.get('provider_parent_name')
    db_name = data.get('db_name', '')
    tenant_id = data.get('tenant_id', '')
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    bulk_change_id = data.get("bulk_change_id")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    service_provider= data.get("service_provider","")
    column_map = {
        "Update PPU address": ["user_address", "modified_by"],
        "Update Features": ["telegence_features", "modified_by"],
        "Change Phone Number": ["msisdn", "modified_by"],
        "Change Carrier Rate Plan": ["carrier_rate_plan_name", "modified_by"],
        "Update Device Status": ["sim_status", "modified_by"],
        "Archive": ["is_active", "is_deleted"],
        "Change ICCID/IMEI":["imei","iccid","modified_by"],
        "Edit Username/Cost Center": ["username", "cost_center", "modified_by"],
        "Activate New Service":["iccid","msisdn","imei","billing_account_number","tenant_id",
                                "is_active","is_deleted","tenant_is_active","tenant_is_deleted",
                                "service_provider_is_active","created_by","created_date",
                                "service_provider_display_name","sim_status","service_provider_id",
                                "device_status_id","foundation_account_number","modified_by"],
        "Refresh A Line": ["modified_by", "effective_date", "carrier_rate_plan_id", 
                           "carrier_rate_plan_name", "service_zip_code", "billing_account_number", 
                           "username", "iccid", "imei", "next_bill_cycle_date", "telegence_features"]
    }
    if not changed_data or not primary_key:
        logging.error("### changed_data or primary_key is missing.")
        message=f"changed_data or primary_key is missing for bulk change id {bulk_change_id}."
        response={"flag":False,"message":message}
        #return {"flag": False, "message": "changed_data or primary_key is missing."}
        try:
                end_time = time.time()
                time_consumed = end_time - start_time
                time_consumed = int(round(time_consumed))
                audit_data_user_actions = {
                    "service_name": "update_for_partner_to_provider",
                    "created_by": username,
                    "status": json.dumps(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": message,
                    "request_received_at": now,
                }
            
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"###update_for_partner_to_provider and {tenant_name} Audit logging failed: {e}")
        return response

    try:
        # DB connections
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_db = DB(db_name, **db_config)
    except Exception as e:
        logging.exception("### Failed to connect to databases")
        return {"flag": False, "message": "Database connection error"}

    try:
        if isinstance(changed_data, dict):
            changed_data = [changed_data]

        # Flatten primary key values
        key_values = list(set(
            str(v)
            for entry in changed_data
            if primary_key in entry
            for v in (entry[primary_key] if isinstance(entry[primary_key], list) else [entry[primary_key]])
        ))
        logging.info(f"### Normalized key_values: {key_values}")

        # if not key_values:
        #     return {"flag": False, "message": f"No valid {primary_key} values provided."}
        if not key_values:
                message=f"No valid {primary_key} values provided for bulk change id {bulk_change_id}."
                response={"flag":False,"message":message}
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "update_for_partner_to_provider",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###update_for_partner_to_provider and {tenant_name} Audit logging failed: {e}")
                return response

        # Fetch source  and target details
        details_df = tenant_db.get_data(
            "sim_management_inventory",
            {"is_active": True, primary_key: key_values, "tenant_id": tenant_id,"service_provider_display_name": service_provider},
            ["source_id", "source_db", "target_details", primary_key]
        )
        # Build details map
        details_map = {}
        if not details_df.empty:
            details_map = {
                row[primary_key]: {
                    "source_id": row["source_id"],
                    "source_db": row["source_db"],
                    "target_details": row["target_details"]
                }
                for _, row in details_df.iterrows()
            }
        logging.info(f"### details_map: {details_map}")        
        source_db_map = defaultdict(list)
        for key_val in key_values:
            if key_val in details_map and details_map[key_val].get("source_db"):
                source_db_map[details_map[key_val]["source_db"]].append(key_val)
        # Get DB configs for all involved DBs
        dbconfig_details=common_utils_database.get_data(
            "tenant",
            {"is_active":True,"db_config":"not Null","parent_tenant_id":"Null"},
            ["db_name","db_config","tenant_name"]
        )
        # handling multi rds configs
        dbname_config_mapping=dict(zip(dbconfig_details.db_name ,dbconfig_details.db_config))
        dbname_tenant_mapping = dict(zip(dbconfig_details.db_name, dbconfig_details.tenant_name))
        db_config_per_db = {
            db_name: {
                "host": conf.get("hostname") or conf.get("host"),
                "port": conf.get("port"),
                "user": conf.get("user"),
                "password": conf.get("password"),
                "multi_schema":False
            }
            for db_name, conf in dbname_config_mapping.items()
        }
        # enter if block if source dbs are present
        if source_db_map:
            def update_source_db(source_db, msisdn_list):
                db_config = db_config_per_db.get(source_db)
                logging.info(f"### Updating source DB: {source_db} for keys: {msisdn_list} with config: {db_config}")
                db_instance = DB(source_db, **db_config)
                records_to_update = []
                for key_val in msisdn_list:
                    record_data = [rec for rec in changed_data if key_val in (rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]])]
                    record_data = fetching_the_changed_data(
                        record_data,
                        db_instance,
                        column_map,
                        change_type,
                        provider_parent_name,
                        tenant_db,
                        primary_key,
                        tenant_id
                    )
                    for rec in record_data:
                        records_to_update.append({primary_key: key_val, **{k:v for k,v in rec.items() if k != primary_key}})

                if records_to_update and change_type != "Activate New Service":
                    db_instance.bulk_update_data("sim_management_inventory", records_to_update, search_column=primary_key)
                    logging.info(f"Updated source DB {source_db}, rows: {records_to_update}")
                else:
                    db_instance.insert_data(records_to_update, "sim_management_inventory")
                    logging.info(f"Inserted into source DB {source_db}, rows: {records_to_update}")
                # Trigger sync API for source DB
                try:
                    api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
                    call_data_sync_for_source = {
                            "data": {
                            "key_name": "m2m_inventory_live_sync_from_20",
                            "path": "/lambda_sync_jobs_",
                            "tenant_db_name": source_db,
                            "service_provider_name": provider_parent_name,
                            "msisdn_list": msisdn_list,
                            "target_tenant_id":tenant_id,
                            "target_tenant_name":tenant_name,
                            "pbp_flag":True,
                            "primary_key":primary_key
                            }
                    }
                    logging.info(f"### Scheduling additional sync API call  with payload: {call_data_sync_for_source}")
                    threading.Timer(1.0, call_sync_api, args=(api_sync_url, call_data_sync_for_source)).start()
                    logging.info(f"### Source DB API call scheduled for DB: {source_db}")
                except Exception as e:
                    logging.exception(f"### Exception during source DB API trigger: {e}")

            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures = [executor.submit(update_source_db, db_name, msisdn_list) for db_name, msisdn_list in source_db_map.items()]
                for future in concurrent.futures.as_completed(futures):
                    future.result()
        per_db_changed = defaultdict(list)
        for key_val, details in details_map.items():
            target_list = details.get("target_details") or []            
            if target_list:  # Only include if target_details exist
                for target_map in target_list:
                    if isinstance(target_map, dict):
                        for db_name, target_id in target_map.items():
                            per_db_changed[db_name].append({
                                primary_key: key_val,
                                "targetid": target_id  
                            })
        logging.info(f"### per_db_changed: {dict(per_db_changed)}") 
        futures = {}  # ✅ MUST be defined upfront
        target_id=None
        # Update target DBs       
        if per_db_changed:   
            changed_lookup = {}
            for rec in changed_data:
                vals = rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]]
                for v in vals:
                    changed_lookup[str(v).strip()] = rec
            # Determine required columns
            required_columns = column_map.get(change_type, [])
            required_columns = [primary_key] + required_columns 
            key_values = list(changed_lookup.keys())
            if not key_values:
                logging.warning(f"### No valid {primary_key} values in changed_data")
                return []
            # Fetch inventory data from target_database
            inventory_df = tenant_db.get_data(
                "sim_management_inventory",
                {primary_key: key_values,"tenant_id":tenant_id, "is_active": True},
                required_columns
            )     
            def update_target_db(db_name, changed_list):
                db_config = db_config_per_db.get(db_name)
                target_db = DB(db_name, **db_config)
                if per_db_changed:
                    target_ids=per_db_changed[db_name]
                    if target_ids:
                        target_id = per_db_changed[db_name][0]["targetid"]
                logging.info(f"target_id is {target_id} and db_name is {db_name}")
                updated_data = fetching_the_changed_data_source_to_target_updates(
                    changed_list,
                    target_db,
                    change_type,
                    primary_key,
                    inventory_df,
                    changed_lookup,
                    required_columns,db_name,target_id
                )
                if updated_data:
                    updated_rows =target_db.bulk_update_data(
                        "sim_management_inventory",
                        updated_data,
                        search_column=primary_key
                    )
                    logging.info(f"Updated target DB {db_name}, rows: {len(updated_data)},updated_rows :{updated_rows }")
            # Run updates concurrently per target DB
            with concurrent.futures.ThreadPoolExecutor() as executor:
                for db_name, data_list in per_db_changed.items():
                    logging.info(
                        f"Scheduling update for target DB: {db_name} with {len(data_list)} records"
                    )
                    future = executor.submit(update_target_db, db_name, data_list)
                    futures[future] = db_name
                logging.info(f"Futures is  {futures} with {db_name} db_name")

                for future in concurrent.futures.as_completed(futures):
                    db_name = futures[future]
                    try:
                        future.result()
                        logging.info(f"Successfully updated target DB: {db_name}")
                    except Exception:
                        logging.exception(f"Error updating target DB: {db_name}")
        try:
            # Prefer source DBs if any exist
            if source_db_map:
                db_list = list(source_db_map.keys())
            else:
                # fallback to target DBs
                db_list = list(per_db_changed.keys())
                for db_name in db_list:
                    tenant_for_api = dbname_tenant_mapping.get(db_name)
                    logging.info(f"### Preparing API for DB: {db_name}, tenant: {tenant_for_api}")

                    # Main API payload
                    api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
                    api_payload = {
                        "data": {
                            "access_token": access_token,
                            "data": {"bulk_change_id": bulk_change_id},
                            "db_name": db_name,
                            "is_update": True,
                            "module_name": "Bulk Change",
                            "Partner": tenant_name,
                            "path": "/update_bulk_change_tables_10",
                            "request_received_at": now,
                            "role_name": role_name,
                            "tenant_name": tenant_for_api,
                            "username": username
                        }
                    }

                    # Sync API payload
                    api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
                    api_sync_payload = {
                        "data": {
                            "access_token": access_token,
                            "key_name": "telegence_bulkchange_sync",
                            "path": "/bulk_change_sync_10_updated",
                            "tenant_name": tenant_for_api,
                            "bulk_change_id": bulk_change_id
                        }
                    }
                    if change_type == "Activate New Service":
                        # Additional data sync payload
                        data_sync = {
                            "data": {
                                "data": {
                                    "key_name": "verizon_inventory",
                                    "path": "/lambda_sync_jobs_",
                                    "tenant_name": tenant_for_api
                                }
                            }
                        }
                        logging.info(f"### Scheduling additional sync API call for Activate New Service to {api_sync_url} with payload: {data_sync}")
                        threading.Timer(10.0, call_sync_api, args=(api_sync_url, data_sync)).start()
                    # Trigger both APIs (10s delay)
                    threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
                    threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()


        except Exception as e:
            logging.exception(f"### Exception during API trigger: {e}")
        
        response = {"flag": True, "message": "Inventory data update executed successfully"}
        try:
            audit_data = {
                "service_name": "update_for_partner_to_provider",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully executed inventory update, data: {json.dumps(data)}",
                "request_received_at": request_received_at
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception in auditing: {e}")

        return response

    except Exception as e:
        logging.error(f"### Exception: {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "update_for_partner_to_provider",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"Failed executing inventory update, data: {json.dumps(data)}",
                "module_name": "Partner Becoming Provider",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error executing inventory data update: {e}"}

def fetching_the_changed_data_source_to_target_updates(changed_data, target_database, 
                              change_type,primary_key,inventory_df,
                              changed_lookup,required_columns,db_name,target_id):
    """
    Fetches inventory data from target_database and rebuilds changed_data with required fields.
    Optimized for bulk/threaded updates.

    Parameters:
        changed_data (list[dict]): List of changed records.
        source_database (DB): Source database connection.
        change_column_map (dict): Columns to fetch for each change_type.
        change_type (str): Type of change event.
        parent_provider_name (str): Provider name.
        target_database (DB): Target database connection.
        map_id_field (str): Field name to map source/target ID ('source_id'/'target_id').
        primary_key (str): Primary key to fetch data by ('id', 'msisdn', 'iccid').

    Returns:
        list[dict]: Updated changed_data with mapped IDs and required fields.
    """
    logging.info(f"### fetching_the_changed_data called target_id {target_id} for change_type:{db_name}db_name: {change_type}, primary_key: {primary_key}")

    if not changed_data:
        return []
    integration_id = None
    integration_df = target_database.get_data(
        'sim_management_inventory', {'id': target_id}, ['integration_id','service_provider_display_name']
    )
    if not integration_df.empty:
        integration_id = int(integration_df.iloc[0]["integration_id"])
        service_provider = integration_df.iloc[0]["service_provider_display_name"]
    else:
        integration_id = None
        service_provider = None
    logging.info(f"### fetching_the_changed_data called for {target_id} target_id change_type {integration_id} and service_provider is {service_provider}")
    rate_plan_map = {}
    if change_type in ('Change Carrier Rate Plan', 'Refresh A Line'):
        carrier_rate_plan_df = target_database.get_data(
            "carrier_rate_plan",
            {"service_provider": service_provider, "is_active": True},
            ["id", "rate_plan_short_name"]
        )
        if isinstance(carrier_rate_plan_df, pd.DataFrame) and not carrier_rate_plan_df.empty:
            rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()}
    # Device status mapping
    device_status_map = {}
    if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and integration_id:
        device_status_df = target_database.get_data(
            "device_status",
            {"integration_id": integration_id,'is_active':True},
            ["id", "status", "description", "display_name"]
        )
        for _, row in device_status_df.iterrows():
            for col in ["status", "description", "display_name"]:
                val = row.get(col)
                if val:
                    device_status_map[val.lower()] = row["id"]
    # Rebuild changed_data with required fields
    updated_data = []
    for _, row in inventory_df.iterrows():
        key_val = str(row[primary_key]).strip()
        entry = changed_lookup.get(key_val)
        if not entry:
            continue

        # Carrier rate plan mapping
        plan_name = row.get("carrier_rate_plan_name")
        new_entry = {}
        if plan_name:
            if plan_name in rate_plan_map:
                new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
            new_entry["carrier_rate_plan_name"] = plan_name

        # Device status mapping
        if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and "sim_status" in row:
            sim_status_val = str(row["sim_status"]).lower()
            if sim_status_val in device_status_map:
                new_entry["device_status_id"] = device_status_map[sim_status_val]
        # Build new entry with required columns
        for col in required_columns:
            if col in row and col not in new_entry:
                new_entry[col] = row[col]
        # Add modified_by if exists
        if "modified_by" in row:
            new_entry["modified_by"] = row["modified_by"]

        updated_data.append(new_entry)

    logging.info(f"### fetched {updated_data} records in fetching_the_changed_data")
    return updated_data


def fetching_the_changed_data(changed_data, source_database, change_column_map,
                              change_type, parent_provider_name, target_database,
                              primary_key,tenant_id):
    """
    Fetches inventory data from target_database and rebuilds changed_data with required fields.
    Optimized for bulk/threaded updates.

    Parameters:
        changed_data (list[dict]): List of changed records.
        source_database (DB): Source database connection.
        change_column_map (dict): Columns to fetch for each change_type.
        change_type (str): Type of change event.
        parent_provider_name (str): Provider name.
        target_database (DB): Target database connection.
        map_id_field (str): Field name to map source/target ID ('source_id'/'target_id').
        primary_key (str): Primary key to fetch data by ('id', 'msisdn', 'iccid').

    Returns:
        list[dict]: Updated changed_data with mapped IDs and required fields.
    """
    logging.info(f"### fetching_the_changed_data called for change_type: {change_type}, primary_key: {primary_key}")

    if not changed_data:
        return []
    integration_id = None
    integration_df = source_database.get_data(
        'serviceprovider', {'service_provider_name': parent_provider_name}, ['integration_id']
    )
    if not integration_df.empty:
        integration_id = int(integration_df['integration_id'].iloc[0])
    changed_lookup = {}
    for rec in changed_data:
        vals = rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]]
        for v in vals:
            changed_lookup[str(v).strip()] = rec
    # Determine required columns
    required_columns = change_column_map.get(change_type, [])
    required_columns = [primary_key] + required_columns 
    key_values = list(changed_lookup.keys())
    if not key_values:
        logging.warning(f"### No valid {primary_key} values in changed_data")
        return []
    # Fetch inventory data from target_database
    inventory_df = target_database.get_data(
        "sim_management_inventory",
        {primary_key: key_values,"tenant_id":tenant_id, "is_active": True},
        required_columns
    )
    rate_plan_map = {}
    if change_type in ('Change Carrier Rate Plan', 'Refresh A Line'):
        carrier_rate_plan_df = source_database.get_data(
            "carrier_rate_plan",
            {"service_provider": parent_provider_name, "is_active": True},
            ["id", "rate_plan_short_name"]
        )
        if isinstance(carrier_rate_plan_df, pd.DataFrame) and not carrier_rate_plan_df.empty:
            rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()}
    # Device status mapping
    device_status_map = {}
    if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and integration_id:
        device_status_df = source_database.get_data(
            "device_status",
            {"integration_id": integration_id},
            ["id", "status", "description", "display_name"]
        )
        for _, row in device_status_df.iterrows():
            for col in ["status", "description", "display_name"]:
                val = row.get(col)
                if val:
                    device_status_map[val.lower()] = row["id"]
    # Rebuild changed_data with required fields
    updated_data = []
    for _, row in inventory_df.iterrows():
        key_val = str(row[primary_key]).strip()
        entry = changed_lookup.get(key_val)
        if not entry:
            continue

        # Carrier rate plan mapping
        plan_name = row.get("carrier_rate_plan_name")
        new_entry = {}
        if plan_name:
            if plan_name in rate_plan_map:
                new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
            new_entry["carrier_rate_plan_name"] = plan_name

        # Device status mapping
        if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and "sim_status" in row:
            sim_status_val = str(row["sim_status"]).lower()
            if sim_status_val in device_status_map:
                new_entry["device_status_id"] = device_status_map[sim_status_val]
        # Build new entry with required columns
        for col in required_columns:
            if col in row and col not in new_entry:
                new_entry[col] = row[col]
        # Add modified_by if exists
        if "modified_by" in row:
            new_entry["modified_by"] = row["modified_by"]

        updated_data.append(new_entry)

    logging.info(f"### fetched {updated_data} records in fetching_the_changed_data")
    return updated_data

def billing_integrtion_new(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    #revcustomername = data.get("changed_data",{}).get("RevCustomerId", "")
    #customerrateplan = data.get("changed_data",{}).get("CustomerRatePlanId", "")
    customerrateplan = data.get("CustomerRatePlanId", "")




    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            ["change_request"]
        )
        bulk_change_requests = {}
        if not request_data.empty:
            bulk_change_requests = request_data.iloc[0]["change_request"]
        if isinstance(bulk_change_requests, str):
           bulk_change_requests = json.loads(bulk_change_requests)
        logging.info(f"change_request_json is {bulk_change_requests}")
        #Extract relevant fields from the change request 
        rev_customer_id = bulk_change_requests.get("RevCustomerId", "")
        if not rev_customer_id:
            rev_customer_id = bulk_change_requests.get("customerId", "")
        logging.info("Using rev_customer_id: %s", rev_customer_id)

        # First check the rev_customer table
        rev_customer_data = database.get_data(
            "rev_customer",                         # assuming table name
            {"rev_customer_id": rev_customer_id, "is_active": True},
            ["customer_name"]
        )
        if isinstance(rev_customer_data, pd.DataFrame) and not rev_customer_data.empty:
            customer_name = rev_customer_data["customer_name"].iloc[0]
            logging.info("Found customer_name in rev_customer: %s", customer_name)
        else:
            # fallback to customers table
            customer_data = database.get_data(
                "customers",
                {"id": rev_customer_id, "is_active": True},
                ["customer_name"]
            )
            if not customer_data.empty:
                customer_name = customer_data["customer_name"].to_list()[0]
                logging.info("Found customer_name in customers: %s", customer_name)
            else:
                customer_name = None
                logging.info("No active customer found for id: %s", rev_customer_id)
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
            "tenant_name": tenant_name,
            "path": "/bulk_update_assign_customer_service_line_creation",
            "role_name": role_name,
            "request_received_at": now,
            "access_token": access_token,
            "db_name": db_name,
            "sessionID": None,
            "service_provider": service_provider,
            "change_type": change_type,
            "created_by": created_by,
            "iccids": iccids,
            "RevCustomerName": customer_name,
            "CustomerRatePlanName": customerrateplan,
            "changed_data": bulk_change_requests,         
            }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": tenant_name,
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "bulk Change",
                "request_received_at": now,
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": username,
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}

def billing_integration_change_rate_plan(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data    
    """
    logging.info(f"billing_integration_change_rate_plan in telegence function is called with data: {data}")
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    customerrateplan = data.get("CustomerRatePlanId", "")
    use_carrier_activation=data.get("use_carrier_activation")
    sessionid=data.get("sessionID","")
    customerid=data.get("customerId","")
    customer_name=data.get("customer_name","")
    #efdate=data.get("effective_date","")
    changed_data=data.get("changed_data",{})
    efdate=changed_data.get("effective_date","")
    try:

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}   
        billing_flag=False
        billing_platform_flag=common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["billing_platform_flag"]
        )
        if not billing_platform_flag.empty:
            billing_flag = bool(billing_platform_flag.iloc[0]["billing_platform_flag"])
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
            "tenant_id": tenant_id,
            "tenant_name": tenant_name,
            "username": username,
            "firstLastName": created_by,
            "path": "/bulk_update_customer_rate_plan_service_line_creation",
            "role_name": role_name,
            "module_name": "Bulk Change",
            "mod_pages": {
                "start": 0,
                "end": 100
            },
            "access_token": access_token,
            "db_name": db_name,
            "sessionID": sessionid,
            "request_received_at":now,
            "Partner": tenant_name,
            "service_provider_id": service_provider_id,
            "service_provider": service_provider,
            "EffectiveDate": efdate,
            "customername": customer_name,
            "bulkchange_id": bulk_change_id,
            "bulk_chnage_id_20":bulk_change_id,
            "use_carrier_activation": use_carrier_activation,
            "carrier_api_status": True,
            "billing_platform_flag":billing_flag,
            "modified_by": username,
            "created_by": created_by,
            "iccids": iccids,
            "msisdns": msisdns,
            "customerId":customerid,
            "CustomerRatePlanId":customerrateplan
            }         
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "billing_integration_change_rate_plan",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": tenant_name,
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "bulk Change",
                "request_received_at": now,
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for billing_integration_change_rate_plan")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": username,
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}

