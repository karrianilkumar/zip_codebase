"""
@Author1 : Srikanth Rekkala
Created Date: 24-02-2026
"""
# Importing the necessary Libraries
import json
import logging
import os
import ast
import os
import pandas as pd
from common_utils.db_utils import DB
from common_utils.timezone_conversion import fetch_tenant_timezone
from pandas import Timestamp
from datetime import datetime
import time
import base64
from pytz import timezone
import base64
import json
import requests
import time, random
import paramiko
from cryptography.fernet import Fernet

# Database configuration
common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }


##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    # Access global db_config variable
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    # Route to appropriate endpoint handler
    if path == "/process_single_sftp_file":
        result = process_single_sftp_file(data)
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object

def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at','date']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict

def upload_file_to_sftp(local_file_path, sftp_config):
    """
    Uploads a file to SFTP using config from DB record
    """

    transport = None
    sftp = None

    try:
        # DB Connection 
        common_utils_database = DB(
            os.environ['COMMON_UTILS_DATABASE'],
            **common_utils_database_config
        )

        sftp_host = sftp_config.get("sftp_host")
        sftp_port = int(sftp_config.get("sftp_port", 22))
        sftp_username = sftp_config.get("sftp_username")
        sftp_password = sftp_config.get("sftp_password")  # decrypt if needed
        remote_directory = sftp_config.get("remote_directory")
        record_id = sftp_config.get("id")

        if not all([sftp_host, sftp_username, remote_directory]):
            return {"flag": False, "message": "Incomplete SFTP configuration"}

        # Connect
        transport = paramiko.Transport((sftp_host, sftp_port))
        transport.connect(username=sftp_username, password=sftp_password)
        sftp = paramiko.SFTPClient.from_transport(transport)

        # Ensure remote directory exists
        try:
            sftp.chdir(remote_directory)
        except IOError:
            sftp.mkdir(remote_directory)
            sftp.chdir(remote_directory)

        filename = os.path.basename(local_file_path)
        remote_path = os.path.join(remote_directory, filename)

        # Upload file
        sftp.put(local_file_path, remote_path)

        logging.info(f"File uploaded successfully to {remote_path}")

        # Update last_run_timestamp AFTER successful upload
        common_utils_database.update_dict(
            "sftp_file_placements_table",
            {"last_run_timestamp": datetime.now()},
            {"id": record_id}
        )

        return {"flag": True, "message": "File uploaded successfully"}

    except Exception as e:
        logging.error(f"SFTP Upload failed: {e}")
        return {"flag": False, "message": str(e)}

    finally:
        # Always close connections safely
        if sftp:
            sftp.close()
        if transport:
            transport.close()

def process_single_sftp_file(record):
    """
    Process a single SFTP file placement record.

    This function performs the complete workflow for an individual report:
    
    1. Determines the runtime environment (e.g., beta) and adjusts the tenant database name if required.
    2. Prepares a payload using tenant and report configuration details.
    3. Identifies the appropriate report export function based on the report type (unique_name).
    4. Generates the report file.
    5. Uploads the generated file to the configured SFTP destination.
    
    Args:
        record (dict): A single active SFTP configuration record from 
                       'sftp_file_placements_table'. This includes tenant details,
                       report type (unique_name), SFTP configuration, and metadata.

    Returns:
        dict: {
            "flag": bool,      # Indicates success or failure
            "message": str,    # Status or error message
            ...                # Additional response details (e.g., upload result)
        }

    Raises:
        Exception: Any unexpected error is logged and returned as a failure response.
    """
    logging.info(f'## process_single_sftp_file called with data {record}')
    try:
        # Start time to tract the action
        start_time = time.time()

        # Check environment mode
        mode = os.getenv("ENV","")
        logging.info(f'## process_single_sftp_file mode {mode}')
        unique_name = record.get("unique_name")
        # Handle _beta suffix for db_name if in beta environment
        db_name = record.get("tenant_db_name")
        if mode and mode.lower() == 'beta' and db_name:
            db_name += '_beta'
        try:
            # Create DB connection for common_utils_database
            common_utils_db = DB(os.environ['COMMON_UTILS_DATABASE'], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### DB connection error: %s", e)
            return {"flag": False, "message": "DB connection failed", "details": str(e)}

        # Encrypted Password 
        encrypted_pwd = record.get("sftp_encrypted_password")
        if isinstance(encrypted_pwd, str):
            # Remove outer quotes if any
            encrypted_pwd = encrypted_pwd.strip('"')

            # If it starts with b' and ends with ', remove them
            if encrypted_pwd.startswith("b'") and encrypted_pwd.endswith("'"):
                encrypted_pwd = encrypted_pwd[2:-1]

            # Convert to real bytes
            encrypted_pwd = encrypted_pwd.encode()
        try:
            decrypted_pwd = decrypt_password(encrypted_pwd)
            record["sftp_password"] = decrypted_pwd
        except Exception as e:
            logging.error(f"Failed to decrypt SFTP password with error {e}")
            return {"flag": False, "message": "Invalid encrypted password"}
        
        payload = {
            "tenant_id": record.get("tenant_id"),
            "tenant_name": record.get("tenant_name"),
            "username": record.get("created_by") or "System",
            "db_name": db_name,
            "selected_date_time": datetime.now().strftime("%Y-%m-%d"),
            "sftp_config": record
        }
        payload = serialize_data(payload)
        payload["common_utils_db"] =  common_utils_db  # Pass common_utils_db to the payload

        FUNCTION_MAP = {
            "New Usage By Line Report": new_usage_by_line_report_export,
            "Daily Usage Report": daily_usage_report_export
        }

        function = FUNCTION_MAP.get(unique_name)

        if not function:
            return {"flag": False, "message": "Unknown report type"}

        # Step 1: Generate Report
        export_response = function(payload)

        if not export_response.get("flag"):
            return export_response

        # Step 2: Get file path from response
        local_file_path = export_response.get("file_path")

        if not local_file_path:
            return {"flag": False, "message": "File path not returned from export"}

        # Step 3: Upload to SFTP
        upload_response = upload_file_to_sftp(local_file_path, record)

        # Audit 
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        audit_data_user_actions = {
            "service_name": "process_single_sftp_file",
            "created_by": "System",
            "status": True,
            "time_consumed_secs": time_consumed,
            "comments": json.dumps(upload_response),
            "module_name": "SFTP File Placements"
        }
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")
        return upload_response

    except Exception as e:
        logging.error(f"## process_single_sftp_file Error processing record {record.get('id')}: {e}")
        error_message = str(e)
        error_type = type(e).__name__
        error_data = {
            "service_name": "process_single_sftp_file",
            "error_message": error_message,
            "error_type": error_type,
            "users": "System",
            "comments": f"Error While Processing the SFTP File",
            "module_name": "Bulk Change"
            }
        common_utils_db.log_error_to_db(error_data, "error_log_table")
        return {"flag": False, "message": str(e)}

def get_sftp_file_placements_data(data):
    try:
        logging.info("### get_sftp_file_placements_data START")

        common_utils_database = DB(
            os.environ['COMMON_UTILS_DATABASE'],
            **common_utils_database_config
        )

        # query
        query = """
            SELECT *
            FROM sftp_file_placements_table
        """

        df = common_utils_database.execute_query(query, True)

        if df is None or df.empty:
            return {
                "flag": True,
                "message": "No records found",
                "data": {"sftp_data": []}
            }

        df_dict = df.to_dict(orient="records")

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": {
                "sftp_data": serialize_data(df_dict)
            }
        }

        return response

    except Exception as e:
        logging.error("### get_sftp_file_placements_data ERROR")
        logging.error(str(e))
        return {
            "flag": False,
            "message": "Failed to fetch SFTP details"
        }


def new_usage_by_line_report_export(data):
    """
        Generates and exports the New Usage By Line Report for a tenant.

        This function retrieves usage-by-line data based on the tenant's
        cross-provider optimization setting and billing cycle configuration.
        It dynamically pivots billing cycle usage into separate MB Usage columns,
        generates an Excel report, stores audit logs, and returns file metadata.

        Behavior:
            - If cross-provider optimization is OFF:
                Fetches latest active billing cycles per provider and retrieves
                usage data from vw_usage_by_line_report_v20.
            - If cross-provider optimization is ON:
                Retrieves usage data from stored procedures:
                    - usp_report_customer_usage_by_line
                    - usp_report_customer_historyusagebyline_rmf
            - Dynamically creates MB Usage columns per billing cycle.
            - Replaces null or zero usage values with blank.
            - If no records exist, generates a header-only Excel file.
            - Logs audit entries on successful export.
            - Logs errors into error_log_table on failure.

        Args:
            data (dict): Input payload containing:
                - tenant_name (str): Tenant name
                - db_name (str): Tenant database name
                - service_provider (str, optional)
                - billing_cycle_period (list, optional)
                - username (str, optional)
                - session_id (str, optional)
    """
    logging.info(f'## new_usage_by_line_report_export Function called with data {data}')
    
    # Start Time
    start_time = time.time()

    # Payload Parameter's
    tenant_name = data.get('tenant_name', '')
    service_provider = data.get("service_provider", "")
    billing_cycle_period = data.get("billing_cycle_period", [])
    tenant_database_name = data.get("db_name", "")

    # DB Connections
    try:
        common_utils_database = data.get('common_utils_db')
        tenant_database = DB(tenant_database_name, **db_config)
    except Exception as e:
        logging.info(f'## Failed to connect data base with error as {e}')
        return {'flag':False, 'message':'Failed to Connect to Database'}
    
    try:
        # Tenant Data Query
        tenant_id = common_utils_database.get_data("tenant", {"tenant_name": tenant_name}, ["id"])["id"].to_list()[0]
        
        # Check cross-provider optimization setting
        cross_provider = tenant_database.get_data(
            "optimization_setting",
            {"tenant_id": tenant_id},
            ["optino_cross_providercustomer_optimization"]
        ).iloc[0, 0]

        logging.info(f"## new_usage_by_line_report_export cross_provider {cross_provider}")

        # Dataframe Defining
        data_frame = pd.DataFrame()
        
        if not cross_provider:  # Cross provider OFF Case
            logging.info("## new_usage_by_line_report_export Cross provider optimization OFF - using billing cycles query")
            
            # Fetch all current billing cycles for all service providers
            billing_cycles_query = """
                SELECT 
                    service_provider,
                    MAX(billing_cycle_end_date) AS latest_billing_cycle_end_date
                FROM billing_period where is_active=true
                GROUP BY service_provider
            """
            billing_cycles_df = tenant_database.execute_query(billing_cycles_query, True)
            
            # Bill Cycles Empty Case
            if not billing_cycles_df.empty:
                values_placeholders = ", ".join(["(%s, %s)"] * len(billing_cycles_df))
                values_params = []
                for _, row in billing_cycles_df.iterrows():
                    values_params.extend([row['service_provider'], row['latest_billing_cycle_end_date']])
                
                secondary_data = f"""
                    WITH provider_cycles(service_provider, billing_cycle_end_date) AS (
                        VALUES {values_placeholders}
                    )
                    SELECT
                        CASE
                            WHEN
                                u.billing_cycle_end_date::time = TIME '00:00:00'
                                AND EXTRACT(YEAR FROM u.billing_cycle_end_date) <= 2025
                            THEN
                                u.billing_cycle_end_date
                                    - INTERVAL '1 day'
                                    + INTERVAL '23 hours 59 minutes 59 seconds'
                            ELSE
                                u.billing_cycle_end_date
                        END AS billing_cycle_end_date,
                        u.service_provider_display_name AS service_provider,
                        u.iccid,
                        u.msisdn,
                        u.foundation_account_number,
                        u.billing_account_number,
                        u.customer_rate_pool_name AS customer_pool,
                        u.customer_name,
                        u.username,
                        u.carrier_rate_plan,
                        u.rate_plan_name AS customer_rate_plan,
                        u.data_usage_mb,
                        u.sms_usage,
                        u.status_display_name AS sim_status,
                        u.date_activated,
                        u.cost_center,
                        u.ip_address
                    FROM public.vw_usage_by_line_report_v20 u
                    JOIN provider_cycles pc
                        ON u.service_provider_display_name = pc.service_provider
                    AND u.billing_cycle_end_date = pc.billing_cycle_end_date
                    WHERE u.tenant_id = %s AND service_provider_is_active = true 
                """
                params = values_params + [tenant_id]
                
                # Query Execution
                secondary_rows = tenant_database.execute_query(secondary_data, params=params)

                # Data conversion to Dataframe
                if secondary_rows is None or secondary_rows.empty:
                    df_secondary = pd.DataFrame()
                else:
                    df_secondary = secondary_rows
                
                if not df_secondary.empty:
                    # Data processing logic (pivot, merge, formatting)
                    df_secondary['billing_cycle_end_date'] = pd.to_datetime(df_secondary['billing_cycle_end_date'])
                    unique_cycles = sorted(df_secondary['billing_cycle_end_date'].unique())
                    
                    df_secondary['msisdn'] = df_secondary['msisdn'].fillna('')
                    
                    # Base columns
                    base_columns = ['service_provider', 'iccid', 'msisdn', 'foundation_account_number', 
                                'billing_account_number', 'customer_pool', 'customer_name', 
                                'username', 'carrier_rate_plan', 'customer_rate_plan', 
                                'sms_usage', 'sim_status', 'date_activated', 'cost_center', 'ip_address']
                    
                    df_base = df_secondary.drop_duplicates(subset=['iccid','msisdn','service_provider'])[base_columns].copy()
                    
                    # Pivot for MB Usage
                    df_pivot_usage = df_secondary.pivot_table(
                        index=['iccid', 'msisdn', 'service_provider'],
                        columns='billing_cycle_end_date',
                        values='data_usage_mb',
                        aggfunc='first'
                    ).reset_index()
                    
                    # Rename columns
                    usage_columns = {}
                    for cycle in unique_cycles:
                        cycle_str = cycle.strftime("%m/%d/%y")
                        usage_columns[cycle] = f"{cycle_str} MB Usage"
                    
                    df_pivot_usage = df_pivot_usage.rename(columns=usage_columns)
                    
                    # Merge and reorder
                    data_frame = df_base.merge(df_pivot_usage, on=['iccid','msisdn','service_provider'], how='left')
                    mb_cols = [col for col in data_frame.columns if 'MB Usage' in col]
                    reordered_cols = [c for c in base_columns if c not in ['sms_usage', 'sim_status']] + mb_cols + ['sms_usage', 'sim_status', 'date_activated']
                    data_frame = data_frame[reordered_cols]
                    
                    # Format MB Usage columns (replace 0/NaN with empty)
                    for col in mb_cols:
                        data_frame[col] = data_frame[col].fillna('')
        
        else:  # Cross provider ON
            logging.info("## new_usage_by_line_report_export Cross provider optimization ON")
            if not billing_cycle_period:
                query_main = """
                    select
                        service_provider_display_name,
                        customer_cycle_end_date,
                        iccid,msisdn,
                        foundation_account_number,
                        billing_account_number,
                        customer_rate_pool_name,
                        customer_name,
                        customer_id,
                        username,
                        carrier_rate_plan,
                        rate_plan_name,
                        data_usage_mb,
                        sms_usage,
                        status_display_name,
                        date_activated
                    from usp_report_customer_usage_by_line
                    WHERE tenant_id = %s and is_active=True
                """
                params = [tenant_id]
                df_result = tenant_database.execute_query(query_main, params=params)
                if df_result is None or df_result.empty:
                    data_frame = pd.DataFrame()
                else:
                    data_frame = df_result
            else:
                query_main = """
                select
                    service_provider_display_name,
                    customer_cycle_end_date,
                    iccid,
                    msisdn,
                    foundation_account_number,
                    billing_account_number,
                    customer_rate_pool_name,
                    customer_name,username,
                    carrier_rate_plan,
                    rate_plan_name,
                    integration_id,
                    sms_usage,
                    data_usage_mb,
                    status_display_name,
                    date_activated,ip_address,cost_center,
                    tenant_id
                from usp_report_customer_historyusagebyline_rmf(%s,%s,%s)
                """
                params = [service_provider, tenant_id, billing_cycle_period]
                df_result = tenant_database.execute_query(query_main, params=params)
                if df_result is None:
                    data_frame = pd.DataFrame()
                elif isinstance(df_result, pd.DataFrame):
                    data_frame = df_result
                elif len(df_result) == 0:
                    data_frame = pd.DataFrame()
                else:
                    data_frame = pd.DataFrame(df_result)

                # Apply same pivot/merge logic as above
                if not data_frame.empty:
                    data_frame['customer_cycle_end_date'] = pd.to_datetime(data_frame['customer_cycle_end_date'])
                    unique_cycles = sorted(data_frame['customer_cycle_end_date'].unique())
                    
                    base_columns = ['service_provider_display_name', 'iccid', 'msisdn', 
                                'foundation_account_number', 'billing_account_number', 
                                'customer_rate_pool_name', 'customer_name', 'username', 
                                'carrier_rate_plan', 'rate_plan_name', 
                                'sms_usage', 'status_display_name', 'date_activated']
                    
                    df_base = data_frame.drop_duplicates(subset=['iccid'])[base_columns].copy()
                    df_pivot_usage = data_frame.pivot_table(
                        index='iccid',
                        columns='customer_cycle_end_date',
                        values='data_usage_mb',
                        aggfunc='first'
                    ).reset_index()
                    
                    usage_columns = {cycle: cycle.strftime("%m/%d/%y") + " MB Usage" 
                                for cycle in unique_cycles}
                    df_pivot_usage = df_pivot_usage.rename(columns=usage_columns)
                    
                    data_frame = df_base.merge(df_pivot_usage, on='iccid', how='left')
                    mb_cols = [col for col in data_frame.columns if 'MB Usage' in col]
                    reordered_cols = [c for c in base_columns if c not in ['sms_usage', 'status_display_name']] + mb_cols + ['sms_usage', 'status_display_name', 'date_activated']
                    data_frame = data_frame[reordered_cols]
                    
                    for col in mb_cols:
                        data_frame[col] = data_frame[col].apply(lambda x: '' if pd.isna(x) or x == 0 else x)
        
        if data_frame.empty:
            data_frame = pd.DataFrame(columns=["Service Provider", "ICCID", "MSISDN"])
        # logging.info total record count
        record_count = len(data_frame)
        logging.info(f"### new_usage_by_line_report_export Total Records in New Usage By Line Report: {record_count}")
        # Generate Unique File Name (Parallel Safe)
        # timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        current_date = datetime.now().strftime("%m_%d_%Y")
        file_name = f"New_Usage_By_Line_Report_{current_date}.xlsx"
        file_path = f"{file_name}"

        # Write Excel
        data_frame.to_excel(file_path, index=False)

        logging.info(f"New Usage By Line Report file created at {file_path}")
        records_len = len(data_frame)
        end_time = time.time()
        time_consumed = end_time - start_time
        time_consumed = int(round(time_consumed))
        audit_data_user_actions = {
            "service_name": "new_usage_by_line_report_export",
            "created_by": "System",
            "status": True,
            "time_consumed_secs": time_consumed,
            "session_id": None,
            "tenant_name": data.get("tenant_name",""),
            "comments": f"{records_len} Records Exported successfully with file_path {file_path}",
            "module_name": "New Usage By Line Report"
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        return {
            "flag": True,
            "message": "Export completed successfully",
            "file_path": file_path,
            "total_records": records_len
        }
    except Exception as e:
        logging.info(f'## new_usage_by_line_report_export Error occured in Usage By Line Report as {e}')

        error_data = {
            "service_name": "new_usage_by_line_report_export",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Failed to fetch New Usage By Line Report: {str(e)}",
            "module_name": "New Usage By Line Report"
        }

        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {'flag':False, 'message':'Failed to fetch Usage By Line Report data','data':{}}



def daily_usage_report_export(data):
    """
        Generates and exports the Daily Usage Report for a specific tenant and date.

        This function retrieves daily SIM-level usage data for the specified
        usage date, applies tenant timezone conversion, formats column headers,
        generates an Excel report, and records audit logs.

        Behavior:
            - Filters data by tenant_id and selected_date_time.
            - Retrieves data from vw_daily_usage_report_export.
            - Applies tenant-specific timezone conversion.
            - Renames columns to user-friendly report headers.
            - Fills null values with blank.
            - If no records exist, generates a header-only Excel file.
            - Logs audit entries on successful export.
            - Logs errors into error_log_table on failure.

        Args:
            data (dict): Input payload containing:
                - tenant_id (int): Tenant ID
                - db_name (str): Tenant database name
                - selected_date_time (str/datetime): Usage date
                - tenant_name (str, optional)
                - username (str, optional)
                - session_id (str, optional)
    """
    try:
        logging.info(f"### daily_usage_report_export called with data: {data}")
        
        # Start Time to track action
        start_time = time.time()

        # Extract Inputs from Payload
        tenant_id = data.get("tenant_id", None)
        selected_date_time = data.get("selected_date_time", "")
        tenant_database_name = data.get("db_name", "")

        # DB Connections
        try:
            tenant_database = DB(tenant_database_name, **db_config)
            common_utils_db = data.get('common_utils_db')
        except Exception as e:
            logging.info(f'## Failed to connect data base with error as {e}')
            return {'flag':False, 'message':'Failed to Connect to Database'}
        

        # Tenant ID Validation
        if not tenant_id:
            logging.info(f"### daily_usage_report_export Missing tenant_id")
            error_data = {
                "service_name": "daily_usage_report_export",
                "error_message": "Missing tenant_id",
                "users": "System",
                "tenant_name": data.get("tenant_name", ""),
                "comments": "Missing tenant_id",
                "module_name": "Daily Usage Report"
                }

            common_utils_db.log_error_to_db(error_data, "error_log_table")
            return {"flag": False, "message": "Missing tenant_id", "data": {}}


        # Fetch Tenant Timezone
        tenant_time_zone = fetch_tenant_timezone(common_utils_db, data)

        # Query build for data
        query = '''
            SELECT service_provider_display_name, iccid, msisdn, 
                   foundation_account_number, billing_account_number, 
                   customer_rate_pool_name, customer_name, username, 
                   carrier_rate_plan, rate_plan_name, 
                   status_display_name, data_usage_mb 
            FROM vw_daily_usage_report_export
            WHERE tenant_id = %s 
              AND usage_date >= %s 
              AND usage_date < %s::timestamp + INTERVAL '1 day';
        '''

        # Query Execution
        df = tenant_database.execute_query(
            query,
            params=[tenant_id, selected_date_time, selected_date_time]
        )
        
        # Reuired columns for Report
        expected_columns = [
            "service_provider_display_name",
            "iccid",
            "msisdn",
            "foundation_account_number",
            "billing_account_number",
            "customer_rate_pool_name",
            "customer_name",
            "username",
            "carrier_rate_plan",
            "rate_plan_name",
            "status_display_name",
            "data_usage_mb"
        ]

        # Dataframe is Empty and Need to provide the Header's in Excel
        if df is None or df.empty:
            logging.info("### daily_usage_report_export No records found - generating header-only report")
            df = pd.DataFrame(columns=expected_columns)
        # Data Exist for the provided Usage Range
        else:
            df = pd.DataFrame(
                convert_timestamp(df.to_dict(orient="records"), tenant_time_zone)
            )

        # Rename Columns with Actual Header's
        df = df.rename(columns={
            "service_provider_display_name": "service_provider",
            "customer_rate_pool_name": "customer_pool",
            "rate_plan_name": "customer_rate_plan",
            "status_display_name": "sim_status",
            "data_usage_mb": "data_usage"
        })

        # Clean Null Values
        df = df.fillna("")

        logging.info(f"### daily_usage_report_export Daily Usage Report Columns: {df.columns.tolist()}")

        # Generate Unique File Name
        # timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        current_date = datetime.now().strftime("%m_%d_%Y")

        # File Name
        file_name = f"Daily_Usage_Report_{current_date}.xlsx"
        file_path = f"{file_name}"

        # Write Excel
        df.to_excel(file_path, index=False)

        logging.info(f"Daily Usage Report file created at {file_path}")

        # Records Length
        records_len = len(df)

        end_time = time.time()
        time_consumed = end_time - start_time  
        time_consumed = int(round(time_consumed))
        # Audit the Action
        audit_data_user_actions = {
            "service_name": "daily_usage_report_export",
            "created_by": "System",
            "status": True,
            "time_consumed_secs": time_consumed,
            "session_id": None,
            "tenant_name": data.get("tenant_name",""),
            "comments": f"{records_len} Records Exported successfully with file_path {file_path}",
            "module_name": "Daily Usage Report"
            }
        common_utils_db.update_audit(audit_data_user_actions, "audit_user_actions")

        # Response Return
        return {
            "flag": True,
            "message": "Daily usage report generated successfully",
            "file_path": file_path,
            "total_records": records_len,
            "time_consumed_secs": time_consumed
        }

    # Exception Handler
    except Exception as e:
        logging.info(f"### daily_usage_report_export unexpected error: {e}")

        # Error Data to track the action
        error_data = {
            "service_name": "daily_usage_report_export",
            "error_message": str(e),
            "error_type": type(e).__name__,
            "users": data.get("username", ""),
            "session_id": data.get("session_id", ""),
            "tenant_name": data.get("tenant_name", ""),
            "comments": f"Failed to fetch Daily usage report: {str(e)}",
            "module_name": "Daily Usage Report",
            "request_received_at": data.get("request_received_at", "")
        }

        common_utils_db.log_error_to_db(error_data, "error_log_table")

        # Error Response Return
        return {
            "flag": False,
            "message": "Failed to fetch Daily usage report",
            "data": {}
        }


# To Generate the Fernet Pass key
def generate_key():
    pass_key = Fernet.generate_key()

# Password Encrypt
def encrypt_password(raw_password):
    sftp_secret_key = os.environ['SFTP_SECRET_KEY']
    f = Fernet(sftp_secret_key)
    encrypted = f.encrypt(raw_password.encode())
    return encrypted

# Password Descrypt
def decrypt_password(encrypted_password):
    logging.info(f'## decrypt_password encrypted_password {encrypted_password}')
    sftp_secret_key = os.environ['SFTP_SECRET_KEY'].encode()
    logging.info(f'## decrypt_password sftp_secret_key {sftp_secret_key}')
    f = Fernet(sftp_secret_key)
    decrypted = f.decrypt(encrypted_password)
    return decrypted.decode()
