"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
from decimal import Decimal
import xml.etree.ElementTree as ET
import json
import logging
import os
import ast
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
import psycopg2
from pandas import Timestamp
from datetime import datetime
from dotenv import load_dotenv
from dateutil.relativedelta import relativedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import concurrent.futures
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random
import xml.etree.ElementTree as ET
from collections import defaultdict

# Database configuration
common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }


##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    # Access global db_config variable
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    # Route to appropriate endpoint handler
    
        
    if path == "/webbing_bc_change_customer_rate_plan":
        result = webbing_bc_change_customer_rate_plan(data)
    elif path== "/webbing_bc_assign_customer":
        result = webbing_bc_assign_customer(data)
    elif path== "/webbing_bc_change_carrier_rate_plan":
        result = webbing_bc_change_carrier_rate_plan(data)
    elif path== "/webbing_bc_create_rev_service":
        result = webbing_bc_create_rev_service(data)
    elif path== "/webbing_bc_update_device_status":
        result = webbing_bc_update_device_status(data)
    elif path== "/webbing_bc_line_sync":
        result = webbing_bc_line_sync(data)
    elif path== "/syncing_webbing_data":
        result = syncing_webbing_data(data)
    elif path== "/webbing_bc_edit_username_cost_center":
        result = webbing_bc_edit_username_cost_center(data)
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
   
    #carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
   
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url

## function to call get activate api for payload
def get_activate_payload(iccid, db, ssid=None, eid=None):
    """
    Generate SOAP 1.2 payload to activate a device.
    """
    try:
        webbing_details_query = f"SELECT imei, service_device_id FROM webbing_devices_staging WHERE iccid='{iccid}'"
        webbing_details = db.execute_query(webbing_details_query, True)

        imei = webbing_details.iloc[0]['imei'] if not webbing_details.empty else None
        service_device_id = webbing_details.iloc[0]['service_device_id'] if not webbing_details.empty else None
        username=os.getenv("WEBBING_API_USERNAME","")
        password=os.getenv("WEBBING_API_PASSWORD","")
        wskey=os.getenv("WEBBING_WS_KEY","")
        logging.info(f"### Webbing details userame password wskey {username}, {password}, {wskey}")
        payload = f"""<?xml version="1.0" encoding="utf-8"?>
        <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                        xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                        xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
            <soap12:Header>
                <Credentials xmlns="http://wws.iamwebbing.com/">
                    <Username>{os.getenv("WEBBING_API_USERNAME","")}</Username>
                    <Password>{os.getenv("WEBBING_API_PASSWORD","")}</Password>
                    <WSKey>{os.getenv("WEBBING_WS_KEY","")}</WSKey>
                </Credentials>
            </soap12:Header>
            <soap12:Body>
                <ActivateServiceDevice xmlns="http://wws.iamwebbing.com/">
                    <ActivateServiceDeviceRequest>
                        <ServiceDeviceIdentifier>
                            {f"<ServiceDeviceID>{service_device_id}</ServiceDeviceID>" if service_device_id else ""}
                            {f"<IMEI>{imei}</IMEI>" if imei else ""}
                            {f"<SSID>{ssid}</SSID>" if ssid else ""}
                            <ICCID>{iccid}</ICCID>
                            {f"<EID>{eid}</EID>" if eid else ""}
                        </ServiceDeviceIdentifier>
                    </ActivateServiceDeviceRequest>
                </ActivateServiceDevice>
            </soap12:Body>
        </soap12:Envelope>"""
        return payload
    except Exception as e:
        logging.exception(f"### Exception in get_activate_payload: {e}")
        return None

## function to call get suspend api for payload\
def suspend_service_device_payload(iccid):
    """
    Generate SOAP payload to suspend a device.
    """
    try:
        payload = f"""<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
            <soap:Header>
                <Credentials xmlns="http://wws.iamwebbing.com/">
                    <Username>{os.getenv("WEBBING_API_USERNAME","")}</Username>
                    <Password>{os.getenv("WEBBING_API_PASSWORD","")}</Password>
                    <WSKey>{os.getenv("WEBBING_WS_KEY","")}</WSKey>
                </Credentials>
            </soap:Header>
            <soap:Body>
                <SuspendServiceDevice xmlns="http://wws.iamwebbing.com/">
                    <SuspendServiceDeviceRequest>
                        <ServiceDeviceIdentifier>
                            <ICCID>{iccid}</ICCID>
                        </ServiceDeviceIdentifier>
                    </SuspendServiceDeviceRequest>
                </SuspendServiceDevice>
            </soap:Body>
        </soap:Envelope>"""
        return payload
    except Exception as e:
        logging.exception(f"### Exception in suspend_service_device_payload: {e}")
        return None



## function to send payload to webbing api

def post_webbing_api(payload,service_provider,change_type,common_utils_database):
    """
    Send SOAP 1.1 payload to Webbing API.
    """
    url, *_ = get_carrier_api_details(service_provider, change_type, common_utils_database)
    logging.info(f"### Webbing API URL: {url}")
    logging.info(f"### Webbing API Payload: {payload}")
    logging.info(f"### Webbing API Service Provider: {service_provider}, Change Type: {change_type}")

    # Detect operation name
    if "<ActivateServiceDevice" in payload:
        operation = "ActivateServiceDevice"
    elif "<SuspendServiceDevice" in payload:
        operation = "SuspendServiceDevice"
    else:
        operation = None

    # SOAP 1.1 headers
    headers = {
        "Content-Type": "text/xml; charset=utf-8"
    }
    if operation:
        headers["SOAPAction"] = f"http://wws.iamwebbing.com/{operation}"

    try:
        resp = requests.post(url, data=payload.encode("utf-8"), headers=headers, timeout=60)
        resp.raise_for_status()

        root = ET.fromstring(resp.text)
        ns = {
            "soap": "http://schemas.xmlsoap.org/soap/envelope/",
            "ns": "http://wws.iamwebbing.com/"
        }
        success = root.find(".//ns:Success", ns)
        response_code = root.find(".//ns:ResponseCode", ns)
        response_description = root.find(".//ns:ResponseDescription", ns)

        flag = success is not None and success.text.strip().lower() == "true"
        return {
            "flag": flag,
            "operation": operation or "Unknown",
            "response_code": response_code.text if response_code is not None else None,
            "response_description": response_description.text if response_description is not None else None
        }

    except Exception as e:
        logging.exception(f"### Exception in post_webbing_api: {e}")
        return {"flag": False, "error": str(e)}


## Change customer rate plan function
def webbing_bc_change_customer_rate_plan(data):
    """
    Change the customer rate plan for the given devices as part of a bulk change operation.
   
    this function is typically triggered during a bulk change operation where a list of SIM cards needs to have their customer rate plans updated.
    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs used to identify devices.
            -changed_data (dict): Dictionary containing the rate plan changes.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
        dict: Result of the operation with flags, messages, and details.
        
    """
    logging.info(f"### Received data for changing customer rate plan: %s", data)
    # Start timing the function execution
    start_time = time.time()
    # Extract all required fields from input data
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id= data.get("tenant_id", "")
    source=data.get("source","")
    service_provider = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    invalid_iccids = data.get("invalid_iccids", [])
    parent_tenant_id=data.get('parent_tenant_id',None)
    # Validate required fields
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} time is {now}")
    try:
        # Connect to main and audit databases
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        logging.error(f"### DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    parent_tenant_id = None
    try:
        parent_tenant_id=common_utils_database.get_data('tenant',{"id":tenant_id},["parent_tenant_id"])["parent_tenant_id"].to_list()[0]
    except Exception as e:
        logging.exception(f"Exception while fetching parent_tenant_id{e}")
        parent_tenant_id = None
    try:
        # Audit - Start
        bulk_change_audit_action(
            data, common_utils_database,
            action="Bulk Change Process Initiated"
        )
        live_progress_percentage_tracker(database, bulk_change_id,20)
        
        # Fetch bulk change request entries for valid ICCIDs
        bulk_change_requests = database.get_data(
            'sim_management_bulk_change_request',
            {"bulk_change_id": bulk_change_id},
            ['id', 'iccid','change_request']
        )
        if not bulk_change_requests.empty:
            change_request_json = bulk_change_requests.iloc[0]["change_request"]
            if not change_request_json:
                message="Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "webbing_bc_change_customer_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### webbing_bc_change_customer_rate_plan and tenant name : {tenant_name} Audit logging failed: {e}")
                return response
            
        live_progress_percentage_tracker(database, bulk_change_id,25)
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        customer_rate_plan_update=change_request_json.get("CustomerRatePlanUpdate","")
        customer_rate_plan_id=customer_rate_plan_update.get("CustomerRatePlanId","")
        customer_rate_pool_id=customer_rate_plan_update.get("CustomerPoolId","")
        effective_date=customer_rate_plan_update.get("EffectiveDate","")
        customer_name = customer_rate_plan_update.get("customerName", "")
        rate_plan_db_name=None
        rate_pool_db_name=None
        plan_mb=None
        rev_customer_name=None
        rev_customer_id=None
        customer_id=None

        # Validate input data
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_name","plan_mb"]   
            )
            if not rate_plan_data.empty:
                rate_plan_db_name = rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb = rate_plan_data["plan_mb"].to_list()[0]

        if customer_rate_pool_id and str(customer_rate_pool_id)!="-1":
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                rate_pool_db_name = rate_pool_data["name"].to_list()[0]
        
        update_fields={}
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_rate_plan_name"]
            ).to_dict(orient="records")
        # Extract valid ICCIDs
        # Prepare an update dict dynamically
        if customer_rate_plan_id is None:
            update_fields["customer_rate_plan_id"] = None
            update_fields["customer_rate_plan_name"] = None
        elif str(customer_rate_plan_id).strip() != "-1":
            update_fields["customer_rate_plan_id"] = customer_rate_plan_id
            update_fields["customer_rate_plan_name"] = rate_plan_db_name
        if not customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(customer_rate_pool_id) != "-1":
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id	
            update_fields["customer_rate_pool_name"] = rate_pool_db_name

        if effective_date:
            update_fields["effective_date"] = effective_date
        if customer_name:  
            update_fields["customer_name"] = customer_name
            rev_data = database.get_data(
                "revcustomer",
                {"customer_name": customer_name, "is_active": True,"tenant_id": tenant_id},
                ["customer_name", "rev_customer_id"]
            )
            if not rev_data.empty:
                rev_customer_name = rev_data["customer_name"].to_list()[0]
                rev_customer_id = rev_data["rev_customer_id"].to_list()[0]
                update_fields["rev_customer_id"] = rev_customer_id
                update_fields["rev_customer_name"] = rev_customer_name
            customer_data = pd.DataFrame()
            if rev_customer_name:
                customer_data=database.get_data(
                    "customers",
                    {"customer_name":rev_customer_name,"is_active": True},
                    ["id","customer_name"]
                )
            if not customer_data.empty:
                customer_id=customer_data["id"].to_list()[0]
                update_fields["customer_id"]=customer_id
        if plan_mb is not None:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
        update_fields["modified_by"] = username 
 
        # Map ICCID to request ID for logging
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        log_entries = []
        invalid_log_entries=[]
        inventory_update = False # defulat 
        live_progress_percentage_tracker(database, bulk_change_id,40)
        
        # Update the SIM management inventory with the new rate plan
        if iccids:
            logging.info(f"### webbing_bc_change_customer_rate_plan and tenant name : {tenant_name} Updating SIM management inventory with updated fields: {update_fields}")
            inventory_update =  database.update_dict(
            "sim_management_inventory",update_fields,
            and_conditions={"tenant_id":tenant_id,"is_active": True, "service_provider_id": service_provider_id},
            in_conditions={"iccid": iccids},
            
            )
            if not parent_tenant_id  and "customer_rate_plan_name" in update_fields:
                logging.info(f"sub tenant carrier rate plan update {update_fields}")
                if iccids:
                    database.update_dict("sim_management_inventory", 
                                        {
                                            "sub_tenant_carrier_rate_plan_name": update_fields.get("customer_rate_plan_name"),
                                            "sub_tenant_carrier_rate_plan_name_id":update_fields.get("customer_rate_plan_id")
                                        },in_conditions={"iccid": iccids})
                    logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} updated customer rate plan for {len(iccids)} devices in inventory") 
            logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Inventory update status: {inventory_update}")
            if inventory_update:  # success case
                logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} customer rate plan updated for {len(iccids)} devices in inventory")
            else:    # failure case 
                logging.info(f"### webbing_bc_change_customer_rate_planive_devices and {tenant_name} Error updating inventory for ICCIDs: {iccids}")
                for iccid in iccids:
                    request_id = iccid_to_request_id.get(iccid)
                    if request_id:
                        log_entries.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": request_id,
                        "log_entry_description": f"Change Customer Rate Plan for iccid : {iccid} failed",
                        "request_text": "Update AMOP",
                        "has_errors": not inventory_update,
                        "response_status": "ERROR",
                        "response_text":  "Customer Rate plan is not updated",
                        "error_text": "Rate plan not found or inactive",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                    })
                if log_entries:
                    database.insert_data(log_entries,"sim_management_bulk_change_log")
                    #  insert the log entries into detailed logs table
                    database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
            
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","errors": len(iccids),"is_processed": True,"has_errors": True,"processed_date": now,"status_details":"Customer Rate plan is not updated"},
                    and_conditions={"bulk_change_id": bulk_change_id},in_conditions={"iccid": iccids},)
            
            # Also update main bulk change record
                database.update_dict(
                    "sim_management_bulk_change",
                    {"status": "ERROR","errors": len(iccids),"processed_date": now},and_conditions={"bulk_change_id": bulk_change_id},
                )
                return {"flag": False,"message": "Inventory update failed","bulk_change_id": bulk_change_id}
                
            
        # Log valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Change Customer Rate Plan for iccid : {iccid} successful",
                "request_text": "Update AMOP",
                "has_errors": False,
                "response_status": "PROCESSED",
                "response_text": "Updated Customer Rate Plan Succesfully",
                "error_text": "",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        #update       
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now , "status_details":"OK" },
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Prepare payload for history table update
        if iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            #api call to update the history table
            try:
                logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Customer Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Exception in action history thread: {e}")
            
        live_progress_percentage_tracker(database, bulk_change_id,70)    
            
        if invalid_iccids:
            logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                invalid_log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan Failed",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid ICCID - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now , "status_details":"Invalid ICCID - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        if invalid_log_entries : 
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_detailed_logs")
            
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        # Update bulk change status to PROCESSED
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "success": len(iccids),
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call to update the 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "webbing_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action="Sync To 1.0 Tables"
        )
        try:
            if iccids:
                data["customername"]= customer_name
                logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        live_progress_percentage_tracker(database, bulk_change_id,85)
        try:
            logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### webbing_bc_change_customer_rate_plan: Exception while scheduling sync call for tenant '{tenant_name}': {e}")

        # Return success
        logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        # Prepare success response
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the auditing log
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "webbing_bc_change_customer_rate_plan",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing customer rate plan for devices : {bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")
        except Exception as e:
            logging.exception(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        return response
 
    except Exception as e:
        # Main exception block
        logging.exception(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = "Error during bulk change processing"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "webbing_bc_change_customer_rate_plan",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": now,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### webbing_bc_change_customer_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response


def webbing_bc_edit_username_cost_center(data):
    """
    Edits the username or cost center associated with devices in bulk.
    
    This function processes a bulk change request to update username and/or cost center
    information for multiple devices. It handles both devices with and without Rev.io
    service IDs, making appropriate API calls for Rev.io integrated devices and direct
    database updates for others.
    
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs to process
            - bulk_change_id (str): ID of the bulk change request
            - created_by (str): User who initiated the request  
            - service_provider (str): Service provider name
            - service_provider_id (str): Service provider identifier
            - change_type (str): Type of change being made
            - tenant_id (str): Tenant identifier
            - invalid_iccids (list): List of invalid ICCIDs that cannot be processed

    Returns:
        dict: Response object with keys:
            - flag (bool): Indicates success or failure of the bulk change
            - processed (int): Number of successfully processed records
            - remaining (int): Number of records remaining to process
            - message (str): Human-readable status message
            - iccids (list): Original list of ICCIDs processed
            - invalid_iccids (list): List of invalid ICCIDs encountered
            - bulk_change_id (str): ID of the bulk change operation
    """

    logging.info(f"### Recevied data for webbing_bc_edit_username_cost_center :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    service_provider_id = data.get("service_provider_id", "")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    username1= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Validate required fields
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### webbing_bc_edit_username_cost_center and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### webbing_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request","subscriber_number"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "webbing_bc_edit_username_cost_center",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### webbing_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,20)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
           username=change_request_json.get("ContactName", "")
           cost_center=change_request_json.get("CostCenter1", "") 
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))

        msisdns = bulk_requests_df["msisdn"].tolist()
        headers = fetch_headers(database, tenant_id, app_id, app_secret)
        headers["Content-Type"] = "application/json-patch+json"
        logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Final headers: {headers}")
        ## Prepare headers for API call
        # headers = {
        #     "Authorization": app_id,
        #     "Ocp-Apim-Subscription-Key": app_secret,
        #     "Content-Type": "application/json-patch+json"
        # }
        
        # Prepare an update dict 
        rev_data=pd.DataFrame()
        revid=None
        update_fields = {}
        successfull_iccids = []
        if username:
           update_fields["username"] = username
        if cost_center:
            update_fields["cost_center"]=cost_center
        # Validate MSISDNs
        rev_data = database.get_data(
                            "rev_service",
                            {"number": iccids, "is_active": True},
                            ["number","rev_service_id"]
                          )
        #rev_series = rev_data.set_index("number")["rev_service_id"]
        # Align column name for merging
        rev_data = rev_data.rename(columns={"number": "iccid"}).drop_duplicates(subset=["iccid"], keep="last")
        #  Merge msisdns with rev_service
        df = bulk_requests_df[["iccid"]].merge(rev_data, on="iccid", how="left")
        with_revid = df[df["rev_service_id"].notnull()]
        without_revid = df[df["rev_service_id"].isnull()]
        rev_iccids=with_revid["iccid"].tolist()
        remaining = list(rev_iccids)        
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### webbing_bc_edit_username_cost_center and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","username","cost_center"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        # costcenter_labels = ["CostCenter1", "CostCenter2", "CostCenter3"]
        rev_map = dict(zip(with_revid["iccid"], with_revid["rev_service_id"]))
        nonrev_iccids = without_revid["iccid"].tolist()
        if nonrev_iccids:
            # 1. Bulk update sim_management_inventory (all missing iccids in one query)
            rev_service_log = database.update_dict(
                "sim_management_inventory",
                update_fields,
                and_conditions={"is_active": True, "service_provider_id": service_provider_id},
                in_conditions={"iccid": nonrev_iccids}  # bulk update
            )
            successfull_iccids.extend(nonrev_iccids)

            # 2. Bulk update sim_management_bulk_change_request
            database.update_dict(
                "sim_management_bulk_change_request",
                {
                    "status": "PROCESSED",
                    "is_processed": True,
                    "has_errors": False,
                    "processed_date": now,
                    "status_details":"OK",
                }, 
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": nonrev_iccids},
            )

            # 3. Loop only for logs
            data_log=[]
            if rev_service_log:
                for iccid in nonrev_iccids:
                    data_log.append( {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update AMOP",
                        "request_text": "Edit Username/Cost Center processed",
                        "has_errors": False,
                        "response_status": "PROCESSED",
                        "response_text": "OK",
                        "error_text": "",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True,
                    })
                database.insert_data(data_log, "sim_management_bulk_change_log")
                #  insert the log entries into detailed logs table
                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
            else:
                for iccid in nonrev_iccids:
                    data_log.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update AMOP",
                        "request_text": "Edit Username/Cost Center processed",
                        "has_errors": True,
                        "response_status": "ERROR",
                        "response_text": "Failed to update inventory",
                        "error_text": "",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True,
                    })
                database.insert_data(data_log, "sim_management_bulk_change_log")
                #  insert the log entries into detailed logs table
                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
        
            logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
        # Chunking ICCIDs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(rev_iccids), batch_size):
                # Create a batch of ICCIDs
                batch = rev_iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each ICCID in the batch
                logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    # Prepare the URL and payload for the API call
                    
                    revid = rev_map.get(iccid)
                    if revid is not None:
                        revid = int(float(revid))
                        url = f"{carrier_api_url}/{revid}"
                    payload = []
                    def task(iccid=iccid, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        username_index = None
                        costcenter_index = None
                        
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.get(
                                    url, headers=headers, timeout=60)
                                logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Response Text: {result}")
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    response_data = resp.json()
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### webbing_bc_edit_username_cost_center and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            label_to_index = {f["label"]: i for i, f in enumerate(response_data["fields"])}
                            username_index = label_to_index.get("User Name")
                            #costcenter_index = next((label_to_index[label] for label in costcenter_labels if label in label_to_index), None)
                            costcenter_index = [
                                    index for label, index in label_to_index.items() if label.startswith("CostCenter")
                                ]
                            logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Username index: {username_index}, Cost Center index: {costcenter_index} for ICCID: {iccid}")
                                
                        #update the request status
                        if username_index  or costcenter_index:
                            if username_index:
                                payload.append({
                                    "op": "replace",
                                    "path": f"/fields/{username_index}/value",
                                    "value": username
                                })

                            if costcenter_index:
                                payload.append({
                                    "op": "replace",
                                    "path": f"/fields/{costcenter_index}/value",
                                    "value": cost_center
                                })

                            logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} API Payload: {payload}, URL: {url}")

                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    get_resp = requests.patch(url,json=payload, headers=headers, timeout=60)
                                    api_success = 200 <= get_resp.status_code < 300
                                    api_result = get_resp.text
                                    logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Response Code: {get_resp.status_code}")
                                    logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Response Text: {api_result}")
                                    status = "PROCESSED" if api_success else "API_FAILED"
                                    
                                    if api_success:
                                        response_data = get_resp.json()
                                        successfull_iccids.append(iccid)
                                    
                                        break
                                except Exception as e:
                                    result = str(e)
                                    status = "API_EXCEPTION"
                                    time.sleep(RETRY_DELAY)

                            if api_success:
                                update_data = {
                                    "status": status,
                                    "has_errors": False,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":" Edit Username/Cost Center via webbing API" 
                                }
                            else:
                                update_data = {
                                    "status": status,
                                    "has_errors": True,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":"Edit Username/Cost Center via webbing API"
                                }  
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                update_data,
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"iccid":[iccid]},
                                )             
                                #inserting values into revservice product table 
                            rev_service_log=database.update_dict(
                                "sim_management_inventory",update_fields,
                                and_conditions={"service_provider_id": service_provider_id,"is_active": True},
                                in_conditions={"iccid": [iccid]}
                            )
                            #constracting logs 
                            log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Edit Username/Cost Center via webbing API",
                                    "request_text": json.dumps(payload),
                                    "has_errors": status == "API_FAILED",
                                    "response_status": "PROCESSED" if api_success else "API_Failed",
                                    "response_text": api_result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
            
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Inserting log for Edit Username/Cost Center: {log}") 
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Update AMOP",
                                    "request_text": json.dumps(payload),
                                    "has_errors":False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK" ,
                                    "error_text": "",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        else:
                            rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"service_provider_id": service_provider_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                            successfull_iccids.append(iccid)
                                
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"iccid":[iccid]},
                                )

                                #constracting logs
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Edit Username/Cost Center via webbing API",
                                    "request_text": "Update AMOP",
                                    "has_errors": False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK",
                                    "error_text": "" ,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        return iccid


                    # Submit the task to the executor
                    logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Submitting task for ICCID: {iccid}")
                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### webbing_bc_edit_username_cost_center and {tenant_name} Error processing ICCID: {e}")

              
        if interval and i + batch_size < len(rev_iccids):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Processed {len(iccids) - len(remaining)} ICCIDS, {len(remaining)} remaining")
        ## Handle invalid MSISDNs
        #api call to upadte the history tables
        if successfull_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": [],
                                        "msisdns":successfull_iccids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the API to update device history tables
            try:
                logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### webbing_bc_edit_username_cost_center and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username1,
                        "path": "/sim_management_action_history_update",
                        "iccids": successfull_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Edit Username/Cost Center",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "username" if username else "cost_center",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### webbing_bc_edit_username_cost_center and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"webbing_bc_edit_username_cost_center and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #suny url to update inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "webbing_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### webbing_bc_edit_username_cost_center and {tenant_name} sync call has started')
            
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f'### webbing_bc_edit_username_cost_center and {tenant_name} sync call has ended')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### webbing_bc_edit_username_cost_center and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### webbing_bc_edit_username_cost_center and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "webbing_bc_edit_username_cost_center",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                    data, common_utils_database,
                    action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### webbing_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### webbing_bc_edit_username_cost_center and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### webbing_bc_edit_username_cost_center and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
      

def decode_password(encoded_pwd: str) -> str:
    """
    Decode the stored password. Replace with your actual decode logic.
    """
    # Example: if it was base64-encoded in the DB:
    return base64.b64decode(encoded_pwd).decode("utf-8")

def decode_token(encoded_token: str) -> str:
    """
    Decode the stored token_value. Replace with your actual decode logic.
    """
    return base64.b64decode(encoded_token).decode("utf-8")

def fetch_headers(database,tenant_id,app_id,app_secret):
    """Fetch and prepare headers for Telegence API requests.
    This function retrieves the necessary authentication details from the database,
    decodes them, and constructs the headers required for API requests.
    Args:

        database (object): Database connection or handler object.
        tenant_id (int): The tenant ID to fetch the integration authentication details.
    Returns:
        dict: Headers containing 'Authorization' and 'Ocp-Apim-Subscription-Key'.
    """
    try:
        rev_io_data_query=f'''SELECT username,password,token_value FROM public.integration_authentication
        where integration_id in (select id from integration where name='Rev.IO'
        ) and tenant_id={tenant_id}'''
        rev_io_dataframe=database.execute_query(rev_io_data_query,True)
        revio_username = rev_io_dataframe["username"].to_list()[0]
        encoded_pwd = rev_io_dataframe["password"].to_list()[0]
        encoded_token = rev_io_dataframe["token_value"].to_list()[0]
        password = decode_password(encoded_pwd)
        token_value = decode_token(encoded_token)
        # 3. Re-encode username:password into Basic
        user_pass = f"{revio_username}:{password}"
        # base64 encode
        b64 = base64.b64encode(user_pass.encode("utf-8")).decode("utf-8")
        rev_app_id = f"Basic {b64}"

        # 4. app_secret is the decoded token_value
        rev_app_secret = token_value

        headers = {
            "Authorization": rev_app_id,
            "Ocp-Apim-Subscription-Key": rev_app_secret,
        }  

        return headers
    except Exception as e:
        logging.error(f"### fetch_headers Error occurred while fetching headers: {e}")
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }  
        return headers
 

## Assign customer function
def webbing_bc_assign_customer(data):
    """Assign a customer to the selected devices or services.
    This function processes a list of iccids and assign a customer account with the iccids in the webbing system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - ICCIDs (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the webbing API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for assign customer: %s", data)
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    if iccids:
        iccids = list(set(iccids))
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    source=data.get("source","")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    parent_tenant_id=data.get('parent_tenant_id',None)
    # Initialize for log entries
    log_entries = []
    rev_service_type_id=None
    service_type_id=None
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### webbing_bc_assign_customer and {tenant_name} time is {now}")

    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### webbing_bc_assign_customer and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### webbing_bc_assign_customer and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}


        # Fetch bulk change rows
       
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request"]
        )
        # Validate input data 
       
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "webbing_bc_assign_customer",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###webbing_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        logging.info(f"change_request_json is {change_request_json}")
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        rev_service_type_id=change_request_json.get("ServiceTypeId","")
        if rev_service_type_id:
            service_type_data=database.get_data(
                    "rev_service_type",
                    {"service_type_id": rev_service_type_id, "is_active": True},
                    ["id"]
                )
            if not service_type_data.empty:
                service_type_id = service_type_data["id"].to_list()[0]
            else:
                service_type_id = None
        logging.info(f"### webbing_bc_assign_customer and {tenant_name} service_type_id is {service_type_id}")
        effective_date=change_request_json.get("EffectiveDate","")
        generate_proration=change_request_json.get("Prorate",None)
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[])
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate_list= change_request_json.get("RateList", [])
        revpackageid=change_request_json.get("RevPackageId", None)
        site_id=change_request_json.get("SiteId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
        plan_mb=None
        customer_data=pd.DataFrame()
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name","plan_mb"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb=rate_plan_data["plan_mb"].to_list()[0]
        if customer_rate_pool_id and customer_rate_pool_id != "No options":
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer or site_id:
            if rev_customer:
                # Use rev_customer if provided
                customer_data = database.get_data(
                    "customers",
                    {"customer_name": rev_customer, "is_active": True,"tenant_id": tenant_id},
                    ["id", "customer_name"]
                )
            elif site_id:
                # Fallback: use site_id as customer_name when rev_customer is absent
                customer_data = database.get_data(
                    "customers",
                    {"id": site_id, "is_active": True,"tenant_id": tenant_id},
                    ["id", "customer_name"]
                )
                if not customer_data.empty:
                    customer_name=customer_data["customer_name"].to_list()[0]
                    rev_dataframe = database.get_data(
                        "revcustomer",
                        {"customer_name": customer_name, "is_active": True,"tenant_id": tenant_id},
                        ["customer_name", "rev_customer_id","id"]
                    )
                    if not rev_dataframe.empty:
                        rev_customer = rev_dataframe["customer_name"].to_list()[0]
                        rev_customer_uuid = rev_dataframe["id"].to_list()[0]
                        rev_customer_id = rev_dataframe["rev_customer_id"].to_list()[0]

            else:
                customer_data = pd.DataFrame()
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields ={}
        if customer_rate_plan_id and customer_rate_plan:
            update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        update_fields["modified_by"] = username 
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if plan_mb is not None:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        # if device_id:
        #     update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_request_id = dict(zip(bulk_requests.iccid, bulk_requests.id))
        iccid_to_changerequest = dict(zip(bulk_requests.iccid, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = fetch_headers(database,tenant_id,app_id,app_secret)
        logging.info(f"###webbing_bc_assign_customer and {tenant_name} Headers prepared for API call{headers}")
        # headers = {
        #     "Authorization": app_id,
        #     "Ocp-Apim-Subscription-Key": app_secret,
        # }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        # Validate iccids
        remaining = iccids.copy()
        logs = []
        successful_iccids = []
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"###webbing_bc_assign_customer and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_name"]
            ).to_dict(orient="records")
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of ICCIDs
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f"### webbing_bc_assign_customer and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"### webbing_bc_assign_customer and {tenant_name} Processing ICCID: {iccid}")
                    
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    #task function
                    def task(iccid=iccid):
                        """ 1. If CreateRevService is True:
                            - Step 1: Call API to create RevService (POST with retries)
                            - Step 2: On success, extract RevService ID from response
                            - Step 3: Use RevService ID to create Service Product (POST)
                        
                           2. If CreateRevService is False:
                            - Skip RevService creation and directly insert into DB"""
                        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Task started for ICCID: {iccid}")
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                        productid = None
                        rev_service_log=False
                        payload_str = iccid_to_changerequest.get(iccid)
                        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Payload for ICCID {iccid}: {payload_str}")
                        request_payload = json.loads(payload_str)
                        service_number=request_payload.get('Number')
                        iccid_from_request=request_payload.get('ICCID')
                        #extract the create rev service flag
                        rev_service = request_payload.get("CreateRevService", False)
                        # Build payloads for all APIs
                        rev_api_payload = {
                            "customer_id": rev_customer_id,
                            "provider_id": provider_id,
                            "number2":iccid_from_request,
                            "service_type_id": rev_service_type_id,
                            "number": service_number,
                            "activated_date": activated_date,

                        }
                        product_api_payload={
                            "CustomerId": rev_customer_id,
                            "service_type_id": rev_service_type_id,
                            "number": service_number,
                            "effective_date": effective_date,
                            "activated_date": activated_date,
                            }
                        if revpackageid:
                            product_api_payload.update({"revpackageid": revpackageid})
                        else:
                            product_api_payload.update({"RevProductIdList": revproductidlist,"RateList": rate_list,"UsagePlanGroupId": usageplangroupid})
                        try:
                            if rev_service:
                                # Step 1:  First API Call to create the revservice
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        logging.info(f"###webbing_bc_assign_customer and {tenant_name} Attempt {attempt} - URL: {url}, Payload: {rev_api_payload}")
                                        
                                        resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                        success = 200 <= resp.status_code < 300
                                        result = resp.text
                                        logging.info(f"###webbing_bc_assign_customer and {tenant_name} Response Code: {resp.status_code}")
                                        logging.info(f"###webbing_bc_assign_customer and {tenant_name} Response Text: {result}")
                                        status = "PROCESSED" if success else "API_Failed"
                                        if success:
                                            try:
                                                response_data = resp.json()
                                                id = response_data.get("id")
                                                successful_iccids.append(iccid)
                                            except Exception:
                                                id = None
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Exception in API call: {e}")
                                        time.sleep(RETRY_DELAY) 
                                if success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result    
                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"iccid": [iccid]},
                                    )             
                                if success:  
                                    #inserting values in rev service 
                                    rev_data={
                                    "rev_customer_id":rev_customer_uuid,
                                    "number":service_number,
                                    "rev_service_id":id,
                                    "activated_date":activated_date,
                                    "is_active":True,
                                    "integration_authentication_id":integration_authentication_id,
                                    "rev_provider_id":rev_provider_id,
                                    "rev_service_type_id":service_type_id
                                    }
                                    rev_insert_id=database.insert_data(rev_data,"rev_service")
                                    if rev_insert_id:
                                        update_fields["rev_service_id"]=rev_insert_id
                                    logging.info(f"### webbing_bc_assign_customer and {tenant_name} update_fields: {update_fields}")
                                    #updating inventory table
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                # Inserting logs based on api result
                                rev_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Rev.io API",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": status == "PROCESSED",
                                        "response_status": "PROCESSED" if success else "API_Failed",
                                        "response_text": result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                database.insert_data(rev_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(rev_log,"sim_management_bulk_change_detailed_logs") 
                                logging.info(f"### webbing_bc_assign_customer and {tenant_name} Inserting log for rev service creation: {rev_log}")
                                #inserting logs after updating inventory table
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### webbing_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                                # Step 2:  Second API Call
                                logging.info(f"### webbing_bc_assign_customer and {tenant_name} Creating Rev.io Service Product for ICCID: {iccid} with ID: {id}")
                                if id:
                                    # Multiple API calls for each product & rate
                                    for product_id, rate in zip(revproductidlist, rate_list):
                                        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Creating product_id {product_id} with rate {rate} for service_id {id}")
                                        if not product_id:
                                            continue  # Skip invalid product IDs

                                        # Build payload for each product
                                        product_api_payload_single = {
                                            "CustomerId": rev_customer_id,
                                            "service_type_id": rev_service_type_id,
                                            "number": service_number,
                                            "effective_date": effective_date,
                                            "activated_date": activated_date,
                                            "product_id": product_id,
                                            "rate": rate,
                                            "service_id": id
                                        }
                                        if generate_proration:
                                            product_api_payload_single["generate_proration"] = str(generate_proration).lower()  # "true" or "false"

                                        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Product API Payload: {product_api_payload_single}, URL: {alternative_api_url}")

                                        for attempt in range(1, MAX_RETRIES + 1):
                                            try:
                                                get_resp = requests.post(alternative_api_url, json=product_api_payload_single, headers=headers, timeout=60)
                                                api_success = 200 <= get_resp.status_code < 300
                                                api_result = get_resp.text
                                                logging.info(f"### Response Code: {get_resp.status_code}")
                                                logging.info(f"### Response Text: {api_result}")

                                                if api_success:
                                                    response_data = get_resp.json()
                                                    productid = response_data.get("id")
                                                    break
                                            except Exception as e:
                                                logging.info(f"API exception on attempt {attempt}: {str(e)}")
                                                time.sleep(RETRY_DELAY)

                                        if api_success:
                                            product_record = {
                                                "service_product_id": productid,
                                                "customer_id": rev_customer_id,
                                                "service_id": id,
                                                "description": description,
                                                "activated_date": activated_date,
                                                "status": "ACTIVE",
                                                "created_by": created_by,
                                                "created_date": now,
                                                "is_active": True,
                                                "is_deleted": False,
                                                "integration_authentication_id": integration_authentication_id,
                                                "product_id": product_id,
                                                "rate": rate
                                            }

                                            database.insert_data(product_record, "rev_service_product")
                                            logging.info(f"Inserted rev_service_product with product_id {product_id}, rate {rate} for tenant {tenant_name}")
                                        #constracting logs 
                                        log = {
                                                "bulk_change_id": bulk_change_id,
                                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                                "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                                "request_text": json.dumps(product_api_payload_single),
                                                "has_errors": status == "API_FAILED",
                                                "response_status": "PROCESSED" if api_success else "API_Failed",
                                                "response_text": api_result,
                                                "error_text": "" if status == "PROCESSED" else result,
                                                "processed_date": now,
                                                "processed_by": created_by,
                                                "created_by": created_by,
                                                "created_date": now,
                                                "is_deleted": False,
                                                "is_active": True
                                            }
                        
                                        if log:
                                            database.insert_data(log,"sim_management_bulk_change_log")
                                            #  insert the log entries into detailed logs table
                                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                                                                        
                                    logging.info(f"### webbing_bc_assign_customer and {tenant_name} Inserting log for rev service product creation: {product_data} and update fields are {update_fields}")
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                    try:
                                        # Preparing fields for sub-tenant update
                                        sub_tenant_update = {}
                                        if "customer_rate_plan_name" in update_fields and "customer_rate_plan_id" in update_fields and not parent_tenant_id:
                                            sub_tenant_update["sub_tenant_carrier_rate_plan_name"] = update_fields["customer_rate_plan_name"]
                                            sub_tenant_update["sub_tenant_carrier_rate_plan_name_id"] = update_fields["customer_rate_plan_id"]
                                            database.update_dict(
                                                "sim_management_inventory",
                                                sub_tenant_update,
                                                and_conditions={"is_active": True},
                                                in_conditions={"iccid": [iccid]},
                                            )
                                    except Exception as e:
                                        logging.exception("Error updating sub-tenant rate plan fields for SIM management inventory")
                                    
                                    logging.info(f"### webbing_bc_assign_customer and {tenant_name} Inserting log for product creation: {log}") 
                                    if rev_service_log:
                                        data_log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service: Update AMOP",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors":False,
                                            "response_status": "PROCESSED",
                                            "response_text": "OK" ,
                                            "error_text": "",
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                                        database.insert_data(data_log,"sim_management_bulk_change_log")
                                        #  insert the log entries into detailed logs table
                                        database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                #if createrevservice flag false then directly updating values into table
                                rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                try:
                                    # Preparing fields for sub-tenant update
                                    sub_tenant_update = {}
                                    if "customer_rate_plan_name" in update_fields and "customer_rate_plan_id" in update_fields and not parent_tenant_id:
                                        sub_tenant_update["sub_tenant_carrier_rate_plan_name"] = update_fields["customer_rate_plan_name"]
                                        sub_tenant_update["sub_tenant_carrier_rate_plan_name_id"] = update_fields["customer_rate_plan_id"]
                                        database.update_dict(
                                            "sim_management_inventory",
                                            sub_tenant_update,
                                            and_conditions={"is_active": True},
                                            in_conditions={"iccid": [iccid]},
                                        )
                                except Exception as e:
                                    logging.exception("Error updating sub-tenant rate plan fields for SIM management inventory")
                                successful_iccids.append(iccid)
                                database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK" },
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": [iccid]},
                                    )

                                #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### webbing_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")

                        except Exception as e:
                            logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Unexpected error for ICCID {iccid}: {str(e)}")
                        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Completed processing ICCID: {iccid}, Success: {success}, ID: {id}, Product ID: {productid}")
                        return iccid
                    futures[executor.submit(task)] = iccid
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.error(f"### webbing_bc_assign_customer and {tenant_name} Error processing iccid: {e}")
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
       
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        #logging.info("Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        if successful_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successful_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table update API
            try:
                logging.info(f"### webbing_bc_assign_customer and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        
        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": successful_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Assign Customer",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### webbing_bc_assign_customer and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Exception in action history thread: {e}")

        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            logging.info(f"### webbing_bc_assign_customer and {tenant_name} Invalid iccids found: {invalid_iccids}")
            # Log invalid IDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Assign customer ",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids},
            )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f"### webbing_bc_assign_customer and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below syncs url is used to sync the 1.0 inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "webbing_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### webbing_bc_assign_customer and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### webbing_bc_assign_customer and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Exception in thread: {e}")

        try:
            if successful_iccids:
                data["iccids"]=successful_iccids
                logging.info(f"### webbing_bc_assign_customer and {tenant_name} sync call for billing  has started")
                billing_integrtion_new(data)
        except Exception as e:
            logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
       
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Assign customer for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.warning(f"### webbing_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Error during bulk change processing: {e}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_msisdns": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### webbing_bc_assign_customer and {tenant_name} Logging error to DB failed: {e}")
 
        return response
 


##SYNC API call function
def call_sync_api(api_url, api_payload):
    '''
    Call the sync API with the provided URL and payload.
    This function is designed to be run in a separate thread after a delay.
    '''
    try:
        # Make the API call
        logging.info(f"### Calling sync API: {api_url} with payload: {api_payload}")
        response = requests.post(api_url, json=api_payload)
        if response.status_code == 200:
            logging.info(f"### Bulk Change API call successful. Data sync call successfully done.")
        else:
            logging.error(f"### API call failed with status code: {response.status_code}")
    except Exception as e:
        logging.error(f"### Error making API call: {e}")



## Function to audit user actions in bulk change processing
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
   
    request_received_at = data.get("request_received_at", "") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
        logging.info(" ### User action audited successfully.")
    except Exception as e:
        logging.exception(f"### Error logging user actions: {e}")


def live_progress_percentage_tracker(database, bulk_change_id,progress_percent):
    """
    Updates the live_progress_percentage column in sim_management_bulk_change_request table.
    """
    try:
        update_fields={}
        #updating sync status when progress percentage reached 100
        if progress_percent==100:
            update_fields["live_progress_percentage"]=progress_percent
            update_fields["progress"]="Sync Completed"
        else:
            update_fields["live_progress_percentage"]=progress_percent

        database.update_dict(
            "sim_management_bulk_change",
            update_fields,
            and_conditions={"id": bulk_change_id}
        )
        return True
    except Exception as e:
        logging.error(f"### Error updating live progress: {e}")
        return False


## create rev service update function
def webbing_bc_create_rev_service(data):
    """
    Create Rev Serivice in Rev.IO for the provided MSISDNs, update inventory,
    and update device_tenant and rev_service_product tables accordingly.
    
    This function handles bulk requests with batching and parallelism, 
    updates the database, logs the results, and performs retries on API failures.

    Args:
        data (dict): Input data containing the following keys:
            - msisdns (list): List of msisdns to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to Rev.IO API.
            - created_by (str): User who initiated the request.
            - tenant_id (str): Tenant ID for DB operations.
            - db_name (str): DB name for tenant.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            - invalid_msisdns (list): msisdns to mark as invalid if required.
            - username (str): Username of the user initiating the request
            - tenant_name (str): Name of the tenant
            - role_name (str): Role of the user
            - access_token (str): Access token for sync API

    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Received data for Create Rev Serivice {data} ")
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    msisdns = data.get("msisdns", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_iccids= data.get("invalid_iccids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    # Initialize for log entries
    log_entries = []
    successful_msisdns = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### webbing_bc_create_rev_service and {tenant_name} time is {now}")

    # Check for missing required fields
    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### webbing_bc_create_rev_service and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### webbing_bc_create_rev_service and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch bulk change rows
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number", "change_request"]
        )
        # Validate input data 
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(msisdns),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "pod19_bc_create_rev_service",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### webbing_bc_create_rev_service and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        service_type_id=change_request_json.get("ServiceTypeId","")
        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[])
        product_id = revproductidlist[0] if revproductidlist else None
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate= change_request_json.get("RateList", [])
        revpackageid=change_request_json.get("RevPackageId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer:
            customer_data=database.get_data(
                "customers",
                {"customer_name":rev_customer,"is_active": True},
                ["id","customer_name"]
            )
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        if device_id:
            update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        bulk_requests = bulk_requests.rename(columns={"subscriber_number": "msisdn"})
        msisdn_to_request_id = dict(zip(bulk_requests.msisdn, bulk_requests.id))
        msisdn_to_changerequest = dict(zip(bulk_requests.msisdn, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        if rate:
            product_data["rate"] = rate
        if product_id:
            product_data["product_id"] = product_id
        # Validate msisdns
        remaining = msisdns.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"### webbing_bc_create_rev_service and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking msisdns and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of msisdns
            for i in range(0, len(msisdns), batch_size):
                # Create a batch of msisdns
                batch = msisdns[i:i + batch_size]
                # create a dictionary to hold futures
                futures = {}
                logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} MSISDNs")
                for msisdn in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Processing msisdn: {msisdn}")
                    payload_str = msisdn_to_changerequest.get(msisdn)
                    logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Payload for MSISDN {msisdn}: {payload_str}")
                    
                    # Build payloads for all APIs
                    rev_api_payload = {
                        "customer_id": rev_customer_id,
                        "provider_id": provider_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "activated_date": activated_date,
                    }
                   
                    bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
                    #task function
                    def task(msisdn=msisdn):
                        """
                            - Step 1: Call RevService API with retries
                            - Step 2: Extract RevService ID from API response
                            - Step 3: Insert into rev_service table & update inventory"""
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                       
                        try:                           
                            #  API Call to create the revservice
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Attempt {attempt} - URL: {url}")
                                    
                                    resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Response Code: {resp.status_code} for Create Rev Service")
                                    logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Response Text: {result}")
                                    status = "PROCESSED" if success else "API_Failed"
                                    if success:
                                        try:
                                            response_data = resp.json()
                                            id = response_data.get("id")
                                            successful_msisdns.append(msisdn)
                                        except Exception:
                                            id = None
                                        break
                                except Exception as e:
                                    result = str(e)
                                    status = "API_EXCEPTION"
                                    logging.exception(f"### webbing_bc_create_rev_service and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                    time.sleep(RETRY_DELAY)                
                            if success:
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":result},
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"subscriber_number": msisdns},
                                )
                                #inserting values in rev service 
                                rev_data={
                                "rev_customer_id":rev_customer_uuid,
                                "number":msisdn,
                                "rev_service_id":id,
                                "activated_date":activated_date,
                                "is_active":True,
                                "integration_authentication_id":integration_authentication_id,
                                "rev_provider_id":rev_provider_id,
                                "rev_service_type_id":service_type_id,
                                "rev_service_line_status":"PROCESSED",
                                "bulk_change_id":bulk_change_id,
                                }
                                rev_insert_id=database.insert_data(rev_data,"rev_service")
                                if rev_insert_id:
                                    update_fields["rev_service_id"]=rev_insert_id
                                #updating inventory table
                                rev_service_log=database.update_dict(
                                    "sim_management_inventory",update_fields,
                                    and_conditions={"tenant_id":tenant_id,"is_active": True},
                                    in_conditions={"msisdn": [msisdn]}
                                )
                            # Inserting logs based on api result
                            rev_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Create Rev.io Service: Rev.io API",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors": status == "PROCESSED",
                                    "response_status": "PROCESSED" if success else "API_Failed",
                                    "response_text": result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                            database.insert_data(rev_log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(rev_log,"sim_management_bulk_change_detailed_logs") 
                            logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Rev Service created successfully for MSISDN: {msisdn}")
                            #inserting logs after updating inventory table
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": msisdn_to_request_id.get(msisdn),
                                    "log_entry_description": "Create Rev.io Service: Update AMOP",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors":False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK" ,
                                    "error_text": "",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Inventory updated successfully for MSISDN: {msisdn}")       
                        except Exception as e:
                            logging.exception(f"### webbing_bc_create_rev_service and {tenant_name} Unexpected error for msisdn {msisdn}: {str(e)}")
                        logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Completed processing for MSISDN: {msisdn}")
                        return msisdn
                    futures[executor.submit(task)] = msisdn
                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                    except Exception as e:
                        logging.exception(f"### webbing_bc_create_rev_service and {tenant_name} Error processing MSISDN in thread: {e}")
        if interval and i + batch_size < len(msisdns):
            time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Processed %d msisdns, %d remaining", len(msisdns) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "iccids": [],
                                    "msisdns":successful_msisdns,
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        if effective_date:
            payload_history_table["data"]["effective_date"] = effective_date
        # Call sync API for history table
        try:
            logging.info(f"### webbing_bc_create_rev_service and {tenant_name} sync call has started for history table")
            threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### webbing_bc_create_rev_service and {tenant_name} Exception in thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Invalid msisdns found: %s", invalid_iccids)
            # Log invalid IDs
            for request_id in invalid_iccids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Create Rev Serivice ",
                    "request_text": "Update AMOP",
                    "has_errors": True, 
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_iccids:
            database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","is_processed":True,"has_errors":True,"status_details":"Invalid SIM - could not be processed"},
                    and_conditions={"bulk_change_id": bulk_change_id},
                    in_conditions={"id": invalid_iccids},
                )
        # Insert log entries into DB
        if log_entries: 
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Bulk Change ID: {bulk_change_id}")
        logging.info(f"### webbing_bc_create_rev_service and {tenant_name} Processed %d msisdns, %d remaining", len(msisdns) - len(remaining), len(remaining))
        response={"flag": True, "processed": len(msisdns)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "msisdns": msisdns, "invalid_msisdns": invalid_msisdns, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token, 
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call for inventory table
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "webbing_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### webbing_bc_create_rev_service and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### webbing_bc_create_rev_service and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### webbing_bc_create_rev_service  and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            audit_data_user_actions = {
                "service_name": "webbing_bc_create_rev_service",
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Create Rev Serivice for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### webbing_bc_create_rev_service and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### webbing_bc_create_rev_service and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{msisdns}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### webbing_bc_create_rev_service and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response

   

## Change Carrier Rate Plan function
def webbing_bc_change_carrier_rate_plan(data):
    """Change the carrier rate plan for the given devices.
    This function processes a list of ICCIDS and updates their carrier rate plan in  Webbing.
    It handles bulk requests, updates the database, and logs the results.   
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs to be processed.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Telegence API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Received data for change carrier rate plan :{data}")
    start_time = time.time()
    
    # Extract required fields
    #msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    invalid_iccids = data.get("invalid_iccids", [])
    provider_parent_name=data.get("parent_provider_name", "")
    
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entries = []
    success_ids = []
    remaining = iccids.copy()

    # Validate required fields
    if not bulk_change_id:
        logging.error(f"### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}

    # Connect to databases
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config) 
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Audit logging and initial progress
    try:
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id, 10)
    except Exception as e:
        logging.error(f"### Audit logging failed: {e}")
    try:
        try:
            # Fetch carrier API details
            provider = provider_parent_name if provider_parent_name else service_provider
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
        except Exception as e:
            logging.error(f"### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} Carrier API lookup failed: {e}")
            return {"flag": False, "message": "Missing carrier_api_url"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        # Validate input data 
       
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "webbing_bc_change_carrier_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)

                except Exception as e:
                    logging.warning(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,25)        
 
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
            change_request_json = json.loads(change_request_json)

        # Extract rate plan, effective date, optimization group
        carrier_rate_plan_name = change_request_json.get("CarrierRatePlanUpdate", {}).get("CarrierRatePlan", "")
        effective_date = change_request_json.get("EffectiveDate", "")
       
        # Map ICCID to request_id
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
       
        rate_plan_id=None
        rate_plan_code=None
        # Validate input data for rateplan and optimization
        logging.info(f"### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} Validating input data for rate plan and optimization group")
        if carrier_rate_plan_name:
            rate_plan_data = database.get_data(
                "carrier_rate_plan",
                {"rate_plan_code": carrier_rate_plan_name, "is_active": True},
                ["id", "friendly_name"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            # friendly_name = rate_plan_data["friendly_name"].to_list()[0]
        logging.info(f"### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} Rate plan ID: {rate_plan_id} ")
        if carrier_rate_plan_name:
           update_fields = {"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": carrier_rate_plan_name}   
        
        if effective_date:
            update_fields["effective_date"] = effective_date
            
        # Get product_id for API
        product_id_query = f"SELECT product_id FROM webbing_service_products_staging WHERE product_name='{carrier_rate_plan_name}'"
        product_id_df = database.execute_query(product_id_query, True)
        if product_id_df.empty:
            #{"flag": False, "message": f"No product found for Rate Plan: {carrier_rate_plan_name}"}
            logging.info(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} No product found for Rate Plan: {carrier_rate_plan_name}, proceeding with null product_id")
            product_id = None
        else:
            product_id = product_id_df['product_id'].to_list()[0]

        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","carrier_rate_plan_name"]
            ).to_dict(orient="records")

        # Parse carrier limits
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60

        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))

        headers = {"Content-Type": "text/xml; charset=utf-8"}
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        # Process ICCIDs in batches using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(iccids), batch_size):
                batch = iccids[i:i + batch_size]
                futures = {}
                logging.info(f"### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")

                for iccid in batch:
                    payload = f"""<?xml version="1.0" encoding="utf-8"?>
                    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                        <soap:Header>
                            <Credentials xmlns="http://wws.iamwebbing.com/">
                                <Username>spectrotel_api</Username>
                                <Password>4AcO#Fo2HZyn</Password>
                                <WSKey>cx0kJtwRwlFaKY5WoyuHxjN1gtM=</WSKey>
                            </Credentials>
                        </soap:Header>
                        <soap:Body>
                            <ChangeServiceDeviceProduct xmlns="http://wws.iamwebbing.com/">
                                <ChangeServiceDeviceProductRequest>
                                    <ServiceDeviceIdentifier>
                                        <ICCID>{iccid}</ICCID>
                                    </ServiceDeviceIdentifier>
                                    <ProductID>{product_id}</ProductID>
                                </ChangeServiceDeviceProductRequest>
                            </ChangeServiceDeviceProduct>
                        </soap:Body>
                    </soap:Envelope>"""  

                    def task(iccid=iccid, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                resp = requests.post(carrier_api_url, data=payload, headers=headers, timeout=60)
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    success_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### tenant:{tenant_name} AddPackage Exception Attempt {attempt} ICCID={iccid}: {result}")

                                time.sleep(RETRY_DELAY)

                        update_data = {
                            "status": status,
                            "has_errors": not success,
                            "is_processed": True,
                            "processed_date": now,
                            "status_details": result
                        }

                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"bulk_change_id": bulk_change_id},
                        )

                        if success:
                            update_fields["modified_by"] = created_by
                            database.update_dict(
                                "sim_management_inventory",
                                update_fields,
                                and_conditions={"is_active": True},
                                in_conditions={"iccid": [iccid]}
                            )

                        # Log
                        log = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update webbing Subscriber: webbing API",
                        "request_text": json.dumps(payload),
                        "has_errors": status == "API_FAILED",
                        "response_status": "PROCESSED" if success else "API_Failed",
                        "response_text": result,
                        "error_text": "" if status == "PROCESSED" else result,
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                        }
                           
                        database.insert_data(log, "sim_management_bulk_change_log")
                        #  insert the log entries into detailed logs table
                        database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        if iccid in iccids:
                            remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### Error processing ICCID: {e}")

        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
         #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        logging.info(f"### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} Processed {len(iccids) - len(remaining)} iccids, {len(remaining)} remaining")
        
        #prepare the payload for history table
        if success_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": success_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": success_ids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Carrier Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "carrier_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Exception in action history thread: {e}") 

        # Mark bulk change as processed
        database.update_dict(
            "sim_management_bulk_change",
            {"status": "PROCESSED", "processed_date": now},
            {"id": bulk_change_id}
        )
        
        # Mark invalid request IDs as processed
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Invalid ICCID",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if log_entries:
            database.insert_data(log_entries, "sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
                
        #prepare the payload for history table
        
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "errors":len(invalid_iccids),"is_processed": True, "has_errors": True,
                    "processed_date": now ,"status_details": "Invalid ICCID - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )
        # call sync api to update the 1.0 tables
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # api call to sync the bulk change inventory table data with 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        
        try:
            logging.info(f'### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f'### webbing_bc_change_carrier_rate_plan and tenant : {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### webbing_bc_change_carrier_rate_plan: Exception while scheduling sync call for tenant '{tenant_name}': {e}")

        # Return success
        try:
            if success_ids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "changed_data": {
                            "iccid": success_ids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="iccid"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        logging.info(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")

        logging.info(f"### Bulk change request completed in {time.time() - start_time:.1f} seconds")
          
        response = {
            "flag": True,
            "processed": len(success_ids),
            "remaining": len(iccids),
            "message": "Bulk change request processed successfully.",
            "iccids": success_ids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the auditing log
        # Attempt to audit the action
        live_progress_percentage_tracker(database, bulk_change_id,95)

        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "webbing_bc_change_carrier_rate_plan",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")


        except Exception as e:
            logging.exception(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")

        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Auditing")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processingg: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "webbing_bc_change_carrier_rate_plan",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### webbing_bc_change_carrier_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
    


## Update device status function
def webbing_bc_update_device_status(data):
    """
   Update the device status using the Webbing API.

    This function processes a list of iccids and updates their device status in Webbing .
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps iccids to their respective request payloads.
        - Iteratively calls the Telegence API for each iccid with retry logic.
        - Updates status in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid iccids or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the Telegence API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., SIM status or device status).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_iccids (list): Request IDs associated with invalid rows.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict:Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Received data for Update device status :{data}")
    start_time = time.time()
    
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    request_received_at=data.get("request_received_at", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    provider_parent_name=data.get("parent_provider_name", "")
    #request = data.get("changed_data", {}).get("Request", {})
    updated_status = (
        data.get("changed_data", {}).get("UpdateStatus")
        or data.get("sim_status") 
    )

    device_status_id = data.get("device_status_id", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entries = []
    success_ids = []
    remaining = iccids.copy()

    # Validate required fields
    if not bulk_change_id:
        logging.error(f"### Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}

    # Connect to databases
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config) 
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id, 25)
    
    try:
        # Fetch carrier API details
        provider = provider_parent_name if provider_parent_name else service_provider
        carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
            provider, change_type, common_utils_database
        )
        if not carrier_api_url:
            logging.error(f"### webbing_bc_update_device_status and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### Carrier API URL: {carrier_api_url}, Limits: {carrier_limits}")
        
        # Fetch bulk change requests
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json=bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message="Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "webbing_bc_update_device_status",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### webbing_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response

        if isinstance(change_request_json, str):
            change_request_json = json.loads(change_request_json)
        change_request_json = bulk_requests_df.iloc[0]["change_request"]

        #if source == "Inventory":
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": iccids,"tenant_id": tenant_id}
        ).to_dict(orient="records")
        # Validate input data
        inventory_lookup = {rec["iccid"]: rec for rec in old_inventory_data}
        # Map ICCID to request_id
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        # Parse carrier limits
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        batch_size = carrier_limits.get("batch_size", 100)
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")

        if PARALLEL_REQUESTS>10:
           logging.info(f"###webbing_bc_update_device_status and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        interval = carrier_limits.get("interval_minutes", 0) * 60

        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))

        #headers = {"Content-Type": "text/xml; charset=utf-8"}
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs") 
        live_progress_percentage_tracker(database, bulk_change_id,40)
        # Process ICCIDs in batches using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), batch_size):
                batch = iccids[i:i + batch_size]
                futures = {}

                for iccid in batch:
                    payload = get_activate_payload(iccid, database) if updated_status == "Active" else suspend_service_device_payload(iccid)
                    record = inventory_lookup.get(iccid, {})
                    if record:
                        sim_status = record.get("sim_status")
                        device_id = record.get("device_id")
                        msisdn_number = record.get("msisdn", "")
                    else:
                        sim_status = None
                        device_id = None
                        msisdn_number = None    

                    def task(iccid=iccid, payload=payload):
                            success = False
                            status_details = None
                            status_history={}
                            status = "API_FAILED"
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    
                                    
                                    response_api = post_webbing_api(payload,service_provider,change_type,common_utils_database)
                                    
                                    logging.info(f"### webbing_bc_update_device_status and {tenant_name} Webbing API Response: {response_api}")
                                    
                                    
                                    success = response_api.get("flag", False)
                                    logging.info(f"### Webbing API Success Flag: {success}")
                                    status = "PROCESSED" if success else "API_FAILED"
                                    logging.info(f"###  Status after API call: {status}")
                                    
                                    
                                   
                                    status_details = json.dumps({
                                        "flag": success,
                                        "response_code": response_api.get("response_code"),
                                        "response_description": response_api.get("response_description")
                                    })
                                    if success:
                                        success_ids.append(iccid)
                                        break
                                except Exception as e:
                                    success = False
                                    status = "API_FAILED"
                                    
                                    status_details = str(e)
                                    logging.warning(f"### tenant:{tenant_name} UpdateDeviceStatus Exception Attempt {attempt} ICCID={iccid}: {status_details}")
                                    time.sleep(RETRY_DELAY)
                                
                            if success:
                                update_data = {
                                    "status": status,
                                    "has_errors": False,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":status_details   
                                }
                            else:
                                update_data = {
                                    "status": status,
                                    "has_errors": True,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":status_details
                                }
                            # Update request
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                
                                update_data,
                                and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                            )
                            if success:
                                # Before updating inventory
                                update_data = {
                                        "device_status_id": device_status_id,
                                        "sim_status": updated_status,
                                        "modified_by": created_by
                                }
                                if updated_status.lower() in ["deactivated", "terminate"]:
                                    update_data["last_deactivation_date"] = now
                                    update_data["last_status_modified_date"]=now

                                elif updated_status.lower() in ["active", "activate"]:
                                    update_data["last_activation_date"] = now
                                    update_data["last_status_modified_date"]=now
                                else:
                                    update_data["last_status_modified_date"]=now
                                database.update_dict(
                                    "sim_management_inventory",
                                    update_data,
                                    and_conditions={ "is_active": True},
                                    in_conditions={"iccid": [iccid]}
                                )
                                try:
                                    status_history={
                                        "iccid": iccid,
                                        "sim_management_inventory_id": record.get("id", None)if record else None,
                                        "msisdn": record.get("msisdn", None) if record else None,
                                        "username": record.get("username", None) if record else None,
                                        "previous_status": record.get("sim_status", None) if record else None,
                                        "current_status": updated_status,
                                        "bulk_change_id": bulk_change_id,
                                        "change_event_type": change_type,
                                        "date_of_change": request_received_at,
                                        "tenant_id": tenant_id,
                                        "customer_name": record.get("customer_name", None) if record else None,
                                        "customer_account_number": record.get("account_number", None) if record else None,
                                        "customer_rate_plan": record.get("customer_rate_plan_name", None) if record else None,
                                        "customer_rate_pool": record.get("customer_rate_pool_name", None) if record else None,
                                        "service_provider_display_name": service_provider,
                                        "service_provider_id":  record.get("service_provider_id", None) if record else None,
                                        "device_id": record.get("device_id", None) if record else None,
                                        "mobility_device_id": record.get("mobility_device_id", None) if record else None,
                                        "date_of_change": now,
                                        "customer_name_with_revio":(f"{record.get('rev_customer_name')} ({record.get('rev_customer_id')})"
                                            if record.get("rev_customer_name") and record.get("rev_customer_id")
                                            else None),
                                        "changed_by": created_by,
                                        "is_deleted": False,
                                    }

                                    if status_history:   
                                        inserted_id = database.insert_data(status_history, "device_status_history")
                                        if inserted_id:
                                            device_status_history_id = inserted_id
                                        
                                        #preparing for updating smi_device_detail_history table
                                        status_history.pop("device_id") 
                                        status_history.pop("bulk_change_id")   
                                        status_history["module_name"] = "Bulk Change" 
                                        status_history["is_active"] = record.get("is_active", None) if record else None
                                        status_history["dshid"] =device_status_history_id if device_status_history_id else None

                                        #insert into smi_device_detail_history
                                        logging.info(f"### webbing_bc_update_device_status inserting  record data : {status_history}")
                                        database.insert_data(status_history, "smi_device_detail_history")
                                except Exception as e:
                                    ## audit if insert failed history
                                    error_message = f"Error during inserting history table: {str(e)}"
                                    error_type = type(e).__name__
                                    try:
                                        error_data = {
                                            "service_name": "webbing_bc_update_device_status",
                                            "error_message": error_message,
                                            "error_type": error_type,
                                            "users": username,
                                            "tenant_name": tenant_name,
                                            "comments": f"Error while inserting into the history table for ICCID: {iccid}",
                                            "module_name": "Bulk Change",
                                            "request_received_at": data.get("request_received_at") or now
                                        }
                                        common_utils_database.log_error_to_db(error_data, "error_log_table")
                                    except Exception as log_e:
                                        logging.error(f"### webbing_bc_update_device_status and {tenant_name} Exception in logging error data: {log_e}")
                            #device_status_history
                                # Log
                                log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Update webbing Subscriber: SOAP API",
                                    "request_text": payload,
                                    "has_errors": status == "API_FAILED",
                                    "response_status": status,
                                    "response_text": status_details,
                                    "error_text": "" if success else status_details,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                           
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        if iccid in iccids:
                            remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### Error processing ICCID: {e}")

        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
        # Handle and log invalid iccid
        # Mark the bulk change as processed
        database.update_dict(
            "sim_management_bulk_change",
            {"status": "PROCESSED", "processed_date": now},
            {"id": bulk_change_id}
        )
        if success_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": success_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### webbing_bc_update_device_status and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### webbing_bc_update_device_status and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            action_history_payload = {
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": success_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Update Device Status",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_field": "sim_status"
                }
            }
            
            # API call to update action history
            try:
                logging.info(f"### webbing_bc_update_device_status and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"### webbing_bc_update_device_status and {tenant_name} Exception in action history thread: {e}") 
    # Mark invalid request IDs as processed
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Invalid ICCID",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if log_entries:
            database.insert_data(log_entries, "sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
                
        #prepare the payload for history table
        
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "errors":len(invalid_iccids),"is_processed": True, "has_errors": True,
                    "processed_date": now ,"status_details": "Invalid ICCID - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )
        # Mark bulk change as processed  
              
        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # api call to sync the bulk change inventory table data with 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "telegence_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
 
        try:
            logging.info(f"### webbing_bc_update_device_status and {tenant_name} sync call has started")        

            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### webbing_bc_update_device_status and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### webbing_bc_update_device_status and {tenant_name} Exception in thread: {e}")

        try:
            if success_ids:
                data["iccids"]=success_ids
                logging.info(f"### webbing_bc_update_device_status and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### webbing_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        # Return success
        try:
            if success_ids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "changed_data": {
                            "iccid": success_ids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="iccid"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### webbing_bc_update_device_status and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### webbing_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        logging.info(f"### webbing_bc_update_device_status and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### webbing_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        response = {
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": success_ids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the auditing log
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "webbing_bc_update_device_status",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for update device status.{bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            live_progress_percentage_tracker(database, bulk_change_id,95)
            bulk_change_audit_action(
                data, common_utils_database,
                action="Auditing"
            )
        except Exception as e:
            logging.exception(f"### webbing_bc_update_device_status and {tenant_name} Audit logging failed: {e}")

        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### webbing_bc_update_device_status and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processingg: {str(e)}"
        error_type = str(type(e).__name__)
        
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "webbing_bc_update_device_status",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### webbing_bc_update_device_status and {tenant_name} Exception in logging error data to DB: {e}")
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response
    

##Update Line Sync function
def webbing_bc_line_sync(data):
    """
    Sync SIM inventory and bulk change requests with the webbing API.

    This function processes a list of ICCIDs for a given bulk change operation
    and updates their details by calling the carrier's webbing API. It includes
    retry logic, database updates, inventory synchronization, error handling,
    and audit logging.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains request payload and UpdateStatus information.
            - service_provider (str): Name of the carrier/service provider.
            - change_type (str): Type of update (e.g., SIM/device status).
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant (for logs/audit).
            - db_name (str): Tenant-specific database name.
            - service_provider_id (str): Identifier for the service provider.
            - invalid_iccids (list): ICCIDs that failed validation before processing.

    Returns:
        dict: Response object summarizing the processing result:
            - flag (bool): True if operation completed without unhandled errors.
            - message (str): Summary of result (success or failure).
            - processed (int): Number of ICCIDs successfully processed.
            - remaining (int): Number of ICCIDs not processed.
            - iccids (list): List of ICCIDs attempted.
            - invalid_iccids (list): ICCIDs skipped due to invalid input.
            - bulk_change_id (str): Bulk change request ID.
            - error (str, optional): Error message if processing failed.
    """
    logging.info(f"### Received data for line sync: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source = data.get("source", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_iccids = data.get("invalid_iccids", [])

    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### webbing_bc_line_sync and {tenant_name} time is {now}")
    successfull_ids = []
    
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### webbing_bc_line_sync and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    
    tenant_database = data.get("db_name", "")
    access_token = data.get("access_token", "")
    role_name = data.get("role_name", "")
    
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        logging.error(f"### webbing_bc_line_sync and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id, 20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### webbing_bc_line_sync and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### webbing_bc_line_sync and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid"]
        ).rename(columns={"iccid": "iccid"})
        
        if bulk_requests_df.empty:
            message = f"Bulk Change Request data is empty"
            response = {"flag": False, "message": message}
            error_update_data = {"errors": len(iccids), "status": "ERROR"}
            database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
            )
            
            # Attempt to audit the action
            try:
                end_time = time.time()
                time_consumed = end_time - start_time
                time_consumed = int(round(time_consumed))
                audit_data_user_actions = {
                    "service_name": "webbing_bc_line_sync",
                    "created_by": username,
                    "status": json.dumps(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": message,
                    "request_received_at": now,
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### webbing_bc_line_sync and {tenant_name} Audit logging failed: {e}")
            return response
        
        # Fetch existing inventory data
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": iccids, "tenant_id": tenant_id}
        ).to_dict(orient="records")

        # CREATE A SET OF EXISTING ICCIDS
        existing_iccids = {item["iccid"] for item in old_inventory_data}
        new_iccids = [iccid for iccid in iccids if iccid not in existing_iccids]
        existing_iccids_list = [iccid for iccid in iccids if iccid in existing_iccids]

        logging.info(f"### webbing_bc_line_sync and {tenant_name} Found {len(existing_iccids_list)} existing ICCIDs and {len(new_iccids)} new ICCIDs")

        # Fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        
        if PARALLEL_REQUESTS > 10:
            logging.info(f"### webbing_bc_line_sync and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS = 10
        
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        changed_data = []
        remaining = list(iccids)
        
        headers = {
            "Content-Type": "text/xml; charset=utf-8",
            "SOAPAction": "http://wws.iamwebbing.com/GetServiceDevices"
        }
        
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}"    
                    payload = f"""<?xml version="1.0" encoding="utf-8"?>
                                    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                                                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                                                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                                    <soap:Header>
                                        <Credentials xmlns="http://wws.iamwebbing.com/">
                                        <Username>spectrotel_api</Username>
                                        <Password>4AcO#Fo2HZyn</Password>
                                        <WSKey>cx0kJtwRwlFaKY5WoyuHxjN1gtM=</WSKey>
                                        </Credentials>
                                    </soap:Header>
                                    <soap:Body>
                                        <GetServiceDevices xmlns="http://wws.iamwebbing.com/">
                                        <GetServiceDevicesRequest>
                                            <DeviceIdentifier>
                                            <ICCID>{iccid}</ICCID>
                                            </DeviceIdentifier>
                                            <OnlyActivePlansDevices>true</OnlyActivePlansDevices>
                                            <PaginationRequest>
                                            <PageSize>10</PageSize>
                                            <PageNumber>1</PageNumber>
                                            </PaginationRequest>
                                        </GetServiceDevicesRequest>
                                        </GetServiceDevices>
                                    </soap:Body>
                                    </soap:Envelope>"""            

                    def task(iccid=iccid, url=url):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        updated = None
                        inserted = None
                        api_data = {}
                        is_new_iccid = iccid in new_iccids  # Check if this is a new ICCID
                        
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### webbing_bc_line_sync and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                            
                                resp = requests.post(url, 
                                    headers=headers, data=payload, timeout=60)
                                logging.info(f"### webbing_bc_line_sync and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### webbing_bc_line_sync and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                            "processed_date": now, "status_details": resp.text if success else result},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                          
                            try:
                                root = ET.fromstring(resp.text)
                                # Navigate to the XML path for the ServiceDeviceRecord
                                ns = {
                                    "soap": "http://schemas.xmlsoap.org/soap/envelope/",
                                    "ns": "http://wws.iamwebbing.com/"
                                }

                                record = root.find(".//ns:ServiceDeviceRecord", ns)

                                if record is not None:
                                    api_data = {
                                        "ICCID": record.findtext("ns:ICCID", default="", namespaces=ns),
                                        "MSISDN": record.findtext("ns:MSISDN", default="", namespaces=ns),
                                        "StatusName": record.findtext("ns:StatusName", default="", namespaces=ns),
                                        "AccountID": record.findtext("ns:AccountID", default="", namespaces=ns),
                                    }
                                else:
                                    logging.warning(f"### webbing_bc_line_sync and {tenant_name} No ServiceDeviceRecord found for ICCID: {iccid}")
                                    api_data = {}
                            except Exception as e:
                                logging.error(f"### webbing_bc_line_sync and {tenant_name} Failed to parse XML for ICCID {iccid}: {e}")
                                api_data = {}

                            if api_data and api_data.get("ICCID"):
                                if is_new_iccid:
                                    # INSERT new ICCID - create full record
                                    try:
                                        to_insert = {
                                            "iccid": api_data.get("ICCID"),
                                            "msisdn": api_data.get("MSISDN"),
                                            "sim_status": api_data.get("StatusName"),
                                            "account_number": api_data.get("AccountID"),
                                            "modified_by": username,
                                            "tenant_id": tenant_id,
                                            "created_by": username,
                                            "created_date": now,
                                            "is_active": True,
                                            "is_deleted": False,
                                            "tenant_is_active": True,
                                            "tenant_is_deleted": False,
                                            "service_provider_is_active": True,
                                            "service_provider_display_name": service_provider,
                                            "service_provider_id": service_provider_id
                                        }
                                        
                                        inserted_id = database.insert_data(to_insert, "sim_management_inventory")
                                        if inserted_id:
                                            inserted = True
                                            logging.info(f"### webbing_bc_line_sync and {tenant_name} Inserted new ICCID: {iccid} with ID: {inserted_id}")
                                            
                                            # For new ICCIDs, all fields are considered as changes
                                            field_changes = {}
                                            for field, new_value in to_insert.items():
                                                if field not in ["id", "created_date", "modified_by", "tenant_id", "created_by", "is_active", "is_deleted"]:
                                                    field_changes[field] = {
                                                        "old_value": None,
                                                        "new_value": new_value
                                                    }
                                            
                                            if field_changes:
                                                changed_data.append({
                                                    "field_changes": field_changes, 
                                                    "id": inserted_id,
                                                    "iccid": api_data.get("ICCID"),
                                                    "msisdn": api_data.get("MSISDN"),
                                                    "old_record": {}  # Empty for new ICCID
                                                })
                                    except Exception as insert_error:
                                        logging.error(f"### webbing_bc_line_sync and {tenant_name} Failed to insert new ICCID {iccid}: {insert_error}")
                                        inserted = False
                                        
                                else:
                                    # UPDATE existing ICCID
                                    old_record = next((item for item in old_inventory_data if item.get("iccid") == api_data.get("ICCID")), {})
                                    
                                    if old_record:
                                        to_update = {
                                            "iccid": api_data.get("ICCID"),
                                            "msisdn": api_data.get("MSISDN"),
                                            "sim_status": api_data.get("StatusName"),
                                            "modified_by": username
                                        }
                                        
                                        exclude_fields = ["iccid"]
                                        keys_to_check = [key for key in to_update.keys() if key not in exclude_fields]
                                        to_update, field_changes = build_detailed_update_dict(to_update, old_record, keys_to_check)
                                        
                                        if to_update:
                                            # Include the ID for update
                                            # to_update["id"] = old_record["id"]
                                            to_update["modified_by"] = username
                                            updated = database.update_dict(
                                                "sim_management_inventory",
                                                values=to_update,
                                                and_conditions={"id": old_record["id"]},
                                            )
                                        
                                        # Store field changes for batch processing
                                        if field_changes:
                                            changed_data.append({
                                                "field_changes": field_changes, 
                                                "id": old_record["id"],
                                                "iccid": api_data.get("ICCID"),
                                                "msisdn": api_data.get("MSISDN"),
                                                "old_record": old_record  # Add the old data for history
                                            })
                            else:
                                logging.warning(f"### webbing_bc_line_sync and {tenant_name} No valid API data for ICCID: {iccid}")

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update webbing Subscriber: webbing API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            # Insert the log entries into detailed logs table
                            database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                            
                        # Prepare inventory log entry based on operation type
                        inventory_success = updated if not is_new_iccid else inserted
                        operation_type = "Inserted" if is_new_iccid else "Updated"
                        
                        inventory_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": f"{operation_type} Inventory Record",
                            "request_text": None,
                            "has_errors": not inventory_success,
                            "response_status": "PROCESSED" if inventory_success else "ERROR",
                            "response_text": f"Inventory {operation_type.lower()} successfully" if inventory_success else f"Inventory {operation_type.lower()} failed",
                            "error_text": "" if inventory_success else f"Inventory {operation_type.lower()} failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }

                        if inventory_log:
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")
                            # Insert the log entries into detailed logs table
                            database.insert_data(inventory_log, "sim_management_bulk_change_detailed_logs")
                            
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### webbing_bc_line_sync and {tenant_name} Error processing ICCID: {e}")

                if INTERVAL and i + BATCH_SIZE < len(iccids):
                    time.sleep(INTERVAL)
        
        # Handle and log invalid ICCIDs
        # Prepare the payload for history table
        if successfull_ids:
            url_history_table = os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                "data": {
                    "tenant_name": tenant_name,
                    "username": username,
                    "path": "/update_device_history_tables",
                    "change_type": change_type,
                    "iccids": successfull_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                }
            }
            # API call to update the history table
            try:
                logging.info(f"### webbing_bc_line_sync and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### webbing_bc_line_sync and {tenant_name} Exception in thread: {e}")

        if source == "Inventory" and changed_data:
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            
            # Use json.dumps with default=str for the entire payload
            action_history_payload = json.loads(json.dumps({
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": successfull_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Line Sync",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_data": changed_data
                }
            }, default=str))
            # API call to update action history
            try:
                logging.info(f"### webbing_bc_line_sync and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"### webbing_bc_line_sync and {tenant_name} Exception in action history thread: {e}")
                
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update webbing Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs, "sim_management_bulk_change_log")
            # Insert the log entries into detailed logs table
            database.insert_data(logs, "sim_management_bulk_change_detailed_logs")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        # Sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {
                    "bulk_change_id": bulk_change_id
                },
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        
        # Sync API to update the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
            "data": {
                "access_token": access_token,
                "key_name": "webbing_bulkchange_sync",
                "path": "/bulk_change_sync_10_updated",
                "tenant_name": tenant_name,
                "bulk_change_id": bulk_change_id
            }
        }
        
        try:
            logging.info(f"### webbing_bc_line_sync and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id, 80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### webbing_bc_line_sync and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### webbing_bc_line_sync and {tenant_name} Exception in thread: {e}")
        
        # Return success
        logging.info(f"### webbing_bc_line_sync and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### webbing_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        
        # Prepare response
        response = {
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": f"Bulk change request processed successfully. {len(new_iccids)} new ICCIDs inserted, {len(existing_iccids_list)} existing ICCIDs updated.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id,
            "new_iccids_inserted": len(new_iccids),
            "existing_iccids_updated": len(existing_iccids_list)
        }
       
        live_progress_percentage_tracker(database, bulk_change_id, 95)
        
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "webbing_bc_line_sync",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for line sync. {len(new_iccids)} new ICCIDs inserted, {len(existing_iccids_list)} existing ICCIDs updated. Bulk Change ID: {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            
            # Auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### webbing_bc_line_sync and {tenant_name} Audit logging failed: {e}")
        
        # Final auditing the success log
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Completed"
        )
        live_progress_percentage_tracker(database, bulk_change_id, 100)
        
        # Prepare success response
        logging.info(f"### webbing_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### webbing_bc_line_sync and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data = {"errors": len(remaining), "status": "ERROR", "status_details": "Something went wrong while processing!"}
        
        database.update_dict(
            "sim_management_bulk_change",
            error_update_data,
            and_conditions={"id": bulk_change_id},
        )
        
        # Prepare error response
        try:
            error_data = {
                "service_name": "webbing_bc_line_sync",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### webbing_bc_line_sync and {tenant_name} Exception in logging error data to DB: {log_e}")
        
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response   

def build_detailed_update_dict(api_record, inventory_row, keys_to_check):
    """
    Build update dictionary with detailed field-level change tracking
   
    Args:
        api_record (dict): Data from carrier API
        inventory_row (pd.Series): Current inventory data
        keys_to_check (list): Fields to compare
   
    Returns:
        tuple: (to_update_dict, field_changes_list)
    """
    to_update = {}
    field_changes = []
   
    for key in keys_to_check:
        api_value = api_record.get(key)
        current_value = inventory_row.get(key)
       
        # Handle different data types and None values
        if pd.isna(current_value) or current_value is None:
            current_value = ""
        if pd.isna(api_value) or api_value is None:
            api_value = ""
           
        # Convert to string for comparison
        str_current = str(current_value).strip() if current_value is not None else ""
        str_api = str(api_value).strip() if api_value is not None else ""
       
        if str_current != str_api:
            to_update[key] = api_value
            field_changes.append({
                'field': key,
                'previous_value': str_current,
                'current_value': str_api
            })
            logging.info(f"### Field changed: {key}, From: '{str_current}', To: '{str_api}'")
   
    return to_update, field_changes
 

def billing_platform_bulk_change_20_sync(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    customername= data.get("customername","")
    use_carrier_activation=data.get("use_carrier_activation")


    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}

        path_map = {
            "Update Device Status": "/bulk_update_device_status",
            "Change Customer Rate Plan": "/bulk_update_customer_rate_plan_service_line_creation",
            "Assign Customer": "/bulk_update_assign_customer_service_line_creation",
            "Change ICCID/IMEI": "/bulk_update_iccid_imei_service_line_creation"
        }
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        billing_flag=False
        billing_platform_flag=common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["billing_platform_flag"]
        )
        if not billing_platform_flag.empty:
            billing_flag= bool(billing_platform_flag.iloc[0]["billing_platform_flag"])
        
        if change_type in path_map:
            logging.info(f"Processing change request type: {change_type}")

            path = path_map[change_type]
            data['path'] = path
        columns = [
                "iccid",
                "subscriber_number",
                "m2m_id",
                "bulk_change_id",
                "tenant_name",
                "created_by",
                "processed_by",
                "status",
                "device_id",
                "is_active",
                "is_deleted",
                "change_request",
                "id"
            ]
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            columns
        )
        bulk_change_requests = []
        if not request_data.empty:
            bulk_change_requests = request_data.to_dict(orient="records")
        for rec in bulk_change_requests:
            rec["device_change_request_id"] = rec["iccid"]
        change_columns = [
            "service_provider",
            "change_request_type_id",
            "change_request_type",
            "service_provider_id",
            "modified_by",
            "status",
            "uploaded",
            "is_active",
            "is_deleted",
            "created_by",
            "processed_by",
            "tenant_id",
            "id_10"
        ]
        change_data = database.get_data(
            "sim_management_bulk_change",
            {"id": bulk_change_id,"status":"PROCESSED"},
            change_columns
        )
        bulk_change_records = []
        if not change_data.empty:
            bulk_change_records = change_data.to_dict(orient="records")
        
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
                "path":path,
                "data": {
                    "tenant_name":tenant_name,
                    "username": username,
                    "firstLastName": username,
                    "path": path,
                    "role_name": role_name,
                    "module_name": "Bulk Change",
                    "mod_pages": {
                    "start": 0,
                    "end": 100
                    },
                    "access_token": access_token,
                    "db_name": db_name,
                    "sessionID": None,
                    "request_received_at": now,
                    "Partner": tenant_name,
                    "service_provider_id":service_provider_id,
                    "bulkchange_id": bulk_change_id,
                    "customername": customername,
                    "data": {
                    "sim_management_bulk_change": bulk_change_records,         
                    "sim_management_bulk_change_request": bulk_change_requests
                    },
                    "bulk_chnage_id_20": bulk_change_id,
                    "use_carrier_activation": use_carrier_activation,
                    "carrier_api_status": True,
                    "billing_platform_flag": billing_flag
                }
                }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": data.get("Partner",""),
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "Sim Management",
                "request_received_at": data.get("request_received_at",""),
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": data.get("username",""),
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}


def update_for_partner_to_provider(data, primary_key):
    """
    Updates inventory data for a partner becoming a provider.
    Supports multiple MSISDNs/ICCID, source DBs, and target DBs.

    Parameters:
        data (dict): Input data including db info, changed_data, target_details, etc.
        primary_key (str): Either 'msisdn' or 'iccid'.

    Returns:
        dict: Response dict with 'flag' and 'message'.
    """
    logging.info(f"### Starting update_for_partner_to_provider with data: {data}")
    start_time = time.time()
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    changed_data = data.get('changed_data', [])
    change_type = data.get('change_event_type')
    provider_parent_name = data.get('provider_parent_name')
    db_name = data.get('db_name', '')
    tenant_id = data.get('tenant_id', '')
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    bulk_change_id = data.get("bulk_change_id")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    service_provider= data.get("service_provider","")
    column_map = {
        "Update PPU address": ["user_address", "modified_by"],
        "Update Features": ["telegence_features", "modified_by"],
        "Change Phone Number": ["msisdn", "modified_by"],
        "Change Carrier Rate Plan": ["carrier_rate_plan_name", "modified_by"],
        "Update Device Status": ["sim_status", "modified_by"],
        "Archive": ["is_active", "is_deleted"],
        "Change ICCID/IMEI":["imei","iccid","modified_by"],
        "Edit Username/Cost Center": ["username", "cost_center", "modified_by"],
        "Activate New Service":["iccid","msisdn","imei","billing_account_number","tenant_id",
                                "is_active","is_deleted","tenant_is_active","tenant_is_deleted",
                                "service_provider_is_active","created_by","created_date",
                                "service_provider_display_name","sim_status","service_provider_id",
                                "device_status_id","foundation_account_number","modified_by"],
        "Refresh A Line": ["modified_by", "effective_date", "carrier_rate_plan_id", 
                           "carrier_rate_plan_name", "service_zip_code", "billing_account_number", 
                           "username", "iccid", "imei", "next_bill_cycle_date", "telegence_features"]
    }
    if not changed_data or not primary_key:
        logging.error("### changed_data or primary_key is missing.")
        message=f"changed_data or primary_key is missing for bulk change id {bulk_change_id}."
        response={"flag":False,"message":message}
        #return {"flag": False, "message": "changed_data or primary_key is missing."}
        try:
                end_time = time.time()
                time_consumed = end_time - start_time
                time_consumed = int(round(time_consumed))
                audit_data_user_actions = {
                    "service_name": "update_for_partner_to_provider",
                    "created_by": username,
                    "status": json.dumps(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": message,
                    "request_received_at": now,
                }
            
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"###update_for_partner_to_provider and {tenant_name} Audit logging failed: {e}")
        return response

    try:
        # DB connections
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_db = DB(db_name, **db_config)
    except Exception as e:
        logging.exception("### Failed to connect to databases")
        return {"flag": False, "message": "Database connection error"}

    try:
        if isinstance(changed_data, dict):
            changed_data = [changed_data]

        # Flatten primary key values
        key_values = list(set(
            str(v)
            for entry in changed_data
            if primary_key in entry
            for v in (entry[primary_key] if isinstance(entry[primary_key], list) else [entry[primary_key]])
        ))
        logging.info(f"### Normalized key_values: {key_values}")

        # if not key_values:
        #     return {"flag": False, "message": f"No valid {primary_key} values provided."}
        if not key_values:
                message=f"No valid {primary_key} values provided for bulk change id {bulk_change_id}."
                response={"flag":False,"message":message}
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "update_for_partner_to_provider",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###update_for_partner_to_provider and {tenant_name} Audit logging failed: {e}")
                return response

        # Fetch source  and target details
        details_df = tenant_db.get_data(
            "sim_management_inventory",
            {"is_active": True, primary_key: key_values, "tenant_id": tenant_id,"service_provider_display_name": service_provider},
            ["source_id", "source_db", "target_details", primary_key]
        )
        # Build details map
        details_map = {}
        if not details_df.empty:
            details_map = {
                row[primary_key]: {
                    "source_id": row["source_id"],
                    "source_db": row["source_db"],
                    "target_details": row["target_details"]
                }
                for _, row in details_df.iterrows()
            }
        logging.info(f"### details_map: {details_map}")        
        source_db_map = defaultdict(list)
        for key_val in key_values:
            if key_val in details_map and details_map[key_val].get("source_db"):
                source_db_map[details_map[key_val]["source_db"]].append(key_val)
        # Get DB configs for all involved DBs
        dbconfig_details=common_utils_database.get_data(
            "tenant",
            {"is_active":True,"db_config":"not Null","parent_tenant_id":"Null"},
            ["db_name","db_config","tenant_name"]
        )
        # handling multi rds configs
        dbname_config_mapping=dict(zip(dbconfig_details.db_name ,dbconfig_details.db_config))
        dbname_tenant_mapping = dict(zip(dbconfig_details.db_name, dbconfig_details.tenant_name))
        db_config_per_db = {
            db_name: {
                "host": conf.get("hostname") or conf.get("host"),
                "port": conf.get("port"),
                "user": conf.get("user"),
                "password": conf.get("password"),
                "multi_schema":False
            }
            for db_name, conf in dbname_config_mapping.items()
        }
        # enter if block if source dbs are present
        if source_db_map:
            def update_source_db(source_db, msisdn_list):
                db_config = db_config_per_db.get(source_db)
                logging.info(f"### Updating source DB: {source_db} for keys: {msisdn_list} with config: {db_config}")
                db_instance = DB(source_db, **db_config)
                records_to_update = []
                for key_val in msisdn_list:
                    record_data = [rec for rec in changed_data if key_val in (rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]])]
                    record_data = fetching_the_changed_data(
                        record_data,
                        db_instance,
                        column_map,
                        change_type,
                        provider_parent_name,
                        tenant_db,
                        primary_key,
                        tenant_id
                    )
                    for rec in record_data:
                        records_to_update.append({primary_key: key_val, **{k:v for k,v in rec.items() if k != primary_key}})

                if records_to_update and change_type != "Activate New Service":
                    db_instance.bulk_update_data("sim_management_inventory", records_to_update, search_column=primary_key)
                    logging.info(f"Updated source DB {source_db}, rows: {records_to_update}")
                else:
                    db_instance.insert_data(records_to_update, "sim_management_inventory")
                    logging.info(f"Inserted into source DB {source_db}, rows: {records_to_update}")
                # Trigger sync API for source DB
                try:
                    api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
                    call_data_sync_for_source = {
                            "data": {
                            "key_name": "m2m_inventory_live_sync_from_20",
                            "path": "/lambda_sync_jobs_",
                            "tenant_db_name": source_db,
                            "service_provider_name": provider_parent_name,
                            "msisdn_list": msisdn_list,
                            "target_tenant_id":tenant_id,
                            "target_tenant_name":tenant_name,
                            "pbp_flag":True,
                            "primary_key":primary_key
                            }
                    }
                    logging.info(f"### Scheduling additional sync API call  with payload: {call_data_sync_for_source}")
                    threading.Timer(1.0, call_sync_api, args=(api_sync_url, call_data_sync_for_source)).start()
                    logging.info(f"### Source DB API call scheduled for DB: {source_db}")
                except Exception as e:
                    logging.exception(f"### Exception during source DB API trigger: {e}")

            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures = [executor.submit(update_source_db, db_name, msisdn_list) for db_name, msisdn_list in source_db_map.items()]
                for future in concurrent.futures.as_completed(futures):
                    future.result()
        per_db_changed = defaultdict(list)
        for key_val, details in details_map.items():
            target_list = details.get("target_details") or []            
            if target_list:  # Only include if target_details exist
                for target_map in target_list:
                    if isinstance(target_map, dict):
                        for db_name, target_id in target_map.items():
                            per_db_changed[db_name].append({
                                primary_key: key_val,
                                "targetid": target_id  
                            })
        logging.info(f"### per_db_changed: {dict(per_db_changed)}") 
        futures = {}  # ✅ MUST be defined upfront
        target_id=None
        # Update target DBs       
        if per_db_changed:   
            changed_lookup = {}
            for rec in changed_data:
                vals = rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]]
                for v in vals:
                    changed_lookup[str(v).strip()] = rec
            # Determine required columns
            required_columns = column_map.get(change_type, [])
            required_columns = [primary_key] + required_columns 
            key_values = list(changed_lookup.keys())
            if not key_values:
                logging.warning(f"### No valid {primary_key} values in changed_data")
                return []
            # Fetch inventory data from target_database
            inventory_df = tenant_db.get_data(
                "sim_management_inventory",
                {primary_key: key_values,"tenant_id":tenant_id, "is_active": True},
                required_columns
            )     
            def update_target_db(db_name, changed_list):
                db_config = db_config_per_db.get(db_name)
                target_db = DB(db_name, **db_config)
                if per_db_changed:
                    target_ids=per_db_changed[db_name]
                    if target_ids:
                        target_id = per_db_changed[db_name][0]["targetid"]
                logging.info(f"target_id is {target_id} and db_name is {db_name}")
                updated_data = fetching_the_changed_data_source_to_target_updates(
                    changed_list,
                    target_db,
                    change_type,
                    primary_key,
                    inventory_df,
                    changed_lookup,
                    required_columns,db_name,target_id
                )
                if updated_data:
                    updated_rows =target_db.bulk_update_data(
                        "sim_management_inventory",
                        updated_data,
                        search_column=primary_key
                    )
                    logging.info(f"Updated target DB {db_name}, rows: {len(updated_data)},updated_rows :{updated_rows }")
            # Run updates concurrently per target DB
            with concurrent.futures.ThreadPoolExecutor() as executor:
                for db_name, data_list in per_db_changed.items():
                    logging.info(
                        f"Scheduling update for target DB: {db_name} with {len(data_list)} records"
                    )
                    future = executor.submit(update_target_db, db_name, data_list)
                    futures[future] = db_name
                logging.info(f"Futures is  {futures} with {db_name} db_name")

                for future in concurrent.futures.as_completed(futures):
                    db_name = futures[future]
                    try:
                        future.result()
                        logging.info(f"Successfully updated target DB: {db_name}")
                    except Exception:
                        logging.exception(f"Error updating target DB: {db_name}")
        try:
            # Prefer source DBs if any exist
            if source_db_map:
                db_list = list(source_db_map.keys())
            else:
                # fallback to target DBs
                db_list = list(per_db_changed.keys())
                for db_name in db_list:
                    tenant_for_api = dbname_tenant_mapping.get(db_name)
                    logging.info(f"### Preparing API for DB: {db_name}, tenant: {tenant_for_api}")

                    # Main API payload
                    api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
                    api_payload = {
                        "data": {
                            "access_token": access_token,
                            "data": {"bulk_change_id": bulk_change_id},
                            "db_name": db_name,
                            "is_update": True,
                            "module_name": "Bulk Change",
                            "Partner": tenant_name,
                            "path": "/update_bulk_change_tables_10",
                            "request_received_at": now,
                            "role_name": role_name,
                            "tenant_name": tenant_for_api,
                            "username": username
                        }
                    }

                    # Sync API payload
                    api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
                    api_sync_payload = {
                        "data": {
                            "access_token": access_token,
                            "key_name": "telegence_bulkchange_sync",
                            "path": "/bulk_change_sync_10_updated",
                            "tenant_name": tenant_for_api,
                            "bulk_change_id": bulk_change_id
                        }
                    }
                    if change_type == "Activate New Service":
                        # Additional data sync payload
                        data_sync = {
                            "data": {
                                "data": {
                                    "key_name": "verizon_inventory",
                                    "path": "/lambda_sync_jobs_",
                                    "tenant_name": tenant_for_api
                                }
                            }
                        }
                        logging.info(f"### Scheduling additional sync API call for Activate New Service to {api_sync_url} with payload: {data_sync}")
                        threading.Timer(10.0, call_sync_api, args=(api_sync_url, data_sync)).start()
                    # Trigger both APIs (10s delay)
                    threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
                    threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()


        except Exception as e:
            logging.exception(f"### Exception during API trigger: {e}")
        
        response = {"flag": True, "message": "Inventory data update executed successfully"}
        try:
            audit_data = {
                "service_name": "update_for_partner_to_provider",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully executed inventory update, data: {json.dumps(data)}",
                "request_received_at": request_received_at
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception in auditing: {e}")

        return response

    except Exception as e:
        logging.error(f"### Exception: {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "update_for_partner_to_provider",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"Failed executing inventory update, data: {json.dumps(data)}",
                "module_name": "Partner Becoming Provider",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error executing inventory data update: {e}"}

def fetching_the_changed_data_source_to_target_updates(changed_data, target_database, 
                              change_type,primary_key,inventory_df,
                              changed_lookup,required_columns,db_name,target_id):
    """
    Fetches inventory data from target_database and rebuilds changed_data with required fields.
    Optimized for bulk/threaded updates.

    Parameters:
        changed_data (list[dict]): List of changed records.
        source_database (DB): Source database connection.
        change_column_map (dict): Columns to fetch for each change_type.
        change_type (str): Type of change event.
        parent_provider_name (str): Provider name.
        target_database (DB): Target database connection.
        map_id_field (str): Field name to map source/target ID ('source_id'/'target_id').
        primary_key (str): Primary key to fetch data by ('id', 'msisdn', 'iccid').

    Returns:
        list[dict]: Updated changed_data with mapped IDs and required fields.
    """
    logging.info(f"### fetching_the_changed_data called target_id {target_id} for change_type:{db_name}db_name: {change_type}, primary_key: {primary_key}")

    if not changed_data:
        return []
    integration_id = None
    integration_df = target_database.get_data(
        'sim_management_inventory', {'id': target_id}, ['integration_id','service_provider_display_name']
    )
    if not integration_df.empty:
        integration_id = int(integration_df.iloc[0]["integration_id"])
        service_provider = integration_df.iloc[0]["service_provider_display_name"]
    else:
        integration_id = None
        service_provider = None
    logging.info(f"### fetching_the_changed_data called for {target_id} target_id change_type {integration_id} and service_provider is {service_provider}")
    rate_plan_map = {}
    if change_type in ('Change Carrier Rate Plan', 'Refresh A Line'):
        carrier_rate_plan_df = target_database.get_data(
            "carrier_rate_plan",
            {"service_provider": service_provider, "is_active": True},
            ["id", "rate_plan_short_name"]
        )
        if isinstance(carrier_rate_plan_df, pd.DataFrame) and not carrier_rate_plan_df.empty:
            rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()}
    # Device status mapping
    device_status_map = {}
    if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and integration_id:
        device_status_df = target_database.get_data(
            "device_status",
            {"integration_id": integration_id,'is_active':True},
            ["id", "status", "description", "display_name"]
        )
        for _, row in device_status_df.iterrows():
            for col in ["status", "description", "display_name"]:
                val = row.get(col)
                if val:
                    device_status_map[val.lower()] = row["id"]
    # Rebuild changed_data with required fields
    updated_data = []
    for _, row in inventory_df.iterrows():
        key_val = str(row[primary_key]).strip()
        entry = changed_lookup.get(key_val)
        if not entry:
            continue

        # Carrier rate plan mapping
        plan_name = row.get("carrier_rate_plan_name")
        new_entry = {}
        if plan_name:
            if plan_name in rate_plan_map:
                new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
            new_entry["carrier_rate_plan_name"] = plan_name

        # Device status mapping
        if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and "sim_status" in row:
            sim_status_val = str(row["sim_status"]).lower()
            if sim_status_val in device_status_map:
                new_entry["device_status_id"] = device_status_map[sim_status_val]
        # Build new entry with required columns
        for col in required_columns:
            if col in row and col not in new_entry:
                new_entry[col] = row[col]
        # Add modified_by if exists
        if "modified_by" in row:
            new_entry["modified_by"] = row["modified_by"]

        updated_data.append(new_entry)

    logging.info(f"### fetched {updated_data} records in fetching_the_changed_data")
    return updated_data


def fetching_the_changed_data(changed_data, source_database, change_column_map,
                              change_type, parent_provider_name, target_database,
                              primary_key,tenant_id):
    """
    Fetches inventory data from target_database and rebuilds changed_data with required fields.
    Optimized for bulk/threaded updates.

    Parameters:
        changed_data (list[dict]): List of changed records.
        source_database (DB): Source database connection.
        change_column_map (dict): Columns to fetch for each change_type.
        change_type (str): Type of change event.
        parent_provider_name (str): Provider name.
        target_database (DB): Target database connection.
        map_id_field (str): Field name to map source/target ID ('source_id'/'target_id').
        primary_key (str): Primary key to fetch data by ('id', 'msisdn', 'iccid').

    Returns:
        list[dict]: Updated changed_data with mapped IDs and required fields.
    """
    logging.info(f"### fetching_the_changed_data called for change_type: {change_type}, primary_key: {primary_key}")

    if not changed_data:
        return []
    integration_id = None
    integration_df = source_database.get_data(
        'serviceprovider', {'service_provider_name': parent_provider_name}, ['integration_id']
    )
    if not integration_df.empty:
        integration_id = int(integration_df['integration_id'].iloc[0])
    changed_lookup = {}
    for rec in changed_data:
        vals = rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]]
        for v in vals:
            changed_lookup[str(v).strip()] = rec
    # Determine required columns
    required_columns = change_column_map.get(change_type, [])
    required_columns = [primary_key] + required_columns 
    key_values = list(changed_lookup.keys())
    if not key_values:
        logging.warning(f"### No valid {primary_key} values in changed_data")
        return []
    # Fetch inventory data from target_database
    inventory_df = target_database.get_data(
        "sim_management_inventory",
        {primary_key: key_values,"tenant_id":tenant_id, "is_active": True},
        required_columns
    )
    rate_plan_map = {}
    if change_type in ('Change Carrier Rate Plan', 'Refresh A Line'):
        carrier_rate_plan_df = source_database.get_data(
            "carrier_rate_plan",
            {"service_provider": parent_provider_name, "is_active": True},
            ["id", "rate_plan_short_name"]
        )
        if isinstance(carrier_rate_plan_df, pd.DataFrame) and not carrier_rate_plan_df.empty:
            rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()}
    # Device status mapping
    device_status_map = {}
    if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and integration_id:
        device_status_df = source_database.get_data(
            "device_status",
            {"integration_id": integration_id},
            ["id", "status", "description", "display_name"]
        )
        for _, row in device_status_df.iterrows():
            for col in ["status", "description", "display_name"]:
                val = row.get(col)
                if val:
                    device_status_map[val.lower()] = row["id"]
    # Rebuild changed_data with required fields
    updated_data = []
    for _, row in inventory_df.iterrows():
        key_val = str(row[primary_key]).strip()
        entry = changed_lookup.get(key_val)
        if not entry:
            continue

        # Carrier rate plan mapping
        plan_name = row.get("carrier_rate_plan_name")
        new_entry = {}
        if plan_name:
            if plan_name in rate_plan_map:
                new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
            new_entry["carrier_rate_plan_name"] = plan_name

        # Device status mapping
        if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and "sim_status" in row:
            sim_status_val = str(row["sim_status"]).lower()
            if sim_status_val in device_status_map:
                new_entry["device_status_id"] = device_status_map[sim_status_val]
        # Build new entry with required columns
        for col in required_columns:
            if col in row and col not in new_entry:
                new_entry[col] = row[col]
        # Add modified_by if exists
        if "modified_by" in row:
            new_entry["modified_by"] = row["modified_by"]

        updated_data.append(new_entry)

    logging.info(f"### fetched {updated_data} records in fetching_the_changed_data")
    return updated_data

def billing_integrtion_new(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    revcustomername = data.get("changed_data",{}).get("RevCustomerId", "")
    customerrateplan = data.get("changed_data",{}).get("CustomerRatePlanId", "")


    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            ["change_request"]
        )
        bulk_change_requests = {}
        if not request_data.empty:
            bulk_change_requests = request_data.iloc[0]["change_request"]
        if isinstance(bulk_change_requests, str):
           bulk_change_requests = json.loads(bulk_change_requests)
        logging.info(f"change_request_json is {bulk_change_requests}")
        #Extract relevant fields from the change request 
        rev_customer_id = bulk_change_requests.get("RevCustomerId", "")
        if not rev_customer_id:
            rev_customer_id = bulk_change_requests.get("customerId", "")
        logging.info("Using rev_customer_id: %s", rev_customer_id)

        # First check the rev_customer table
        rev_customer_data = database.get_data(
            "rev_customer",                         # assuming table name
            {"rev_customer_id": rev_customer_id, "is_active": True},
            ["customer_name"]
        )
        if isinstance(rev_customer_data, pd.DataFrame) and not rev_customer_data.empty:
            customer_name = rev_customer_data["customer_name"].iloc[0]
            logging.info("Found customer_name in rev_customer: %s", customer_name)
        else:
            # fallback to customers table
            customer_data = database.get_data(
                "customers",
                {"id": rev_customer_id, "is_active": True},
                ["customer_name"]
            )
            if not customer_data.empty:
                customer_name = customer_data["customer_name"].to_list()[0]
                logging.info("Found customer_name in customers: %s", customer_name)
            else:
                customer_name = None
                logging.info("No active customer found for id: %s", rev_customer_id)
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
            "tenant_name": tenant_name,
            "path": "/bulk_update_assign_customer_service_line_creation",
            "role_name": role_name,
            "request_received_at": now,
            "access_token": access_token,
            "db_name": db_name,
            "sessionID": None,
            "service_provider": service_provider,
            "change_type": change_type,
            "created_by": created_by,
            "iccids": iccids,
            "RevCustomerName": customer_name,
            "CustomerRatePlanName": customerrateplan,
            "changed_data": bulk_change_requests,         
            }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": tenant_name,
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "bulk Change",
                "request_received_at": now,
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": username,
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}



from datetime import datetime
from psycopg2.extras import execute_values
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
from sqlalchemy import create_engine, text
import numpy as np
from psycopg2.extras import execute_values
from concurrent.futures import ThreadPoolExecutor, as_completed
import pandas as pd
import numpy as np
##webbing code this is one of the carrier in the project
import os
import psycopg2
import requests
from psycopg2 import extras

import xml.etree.ElementTree as ET
import json
from psycopg2.extras import execute_values
##service products
import xmltodict
import logging
import json
import psycopg2
from datetime import datetime, timedelta
import os
import pandas as pd
import io
import openpyxl


def fetch_data_from_db(query, connection):
    """ Fetch data from the database using the provided query """
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        data = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]  # Get column names
        return [dict(zip(columns, row)) for row in data]  # Return data as a list of dictionaries
    except Exception as e:
        print(f"Error fetching data: {e}")
        return []
    finally:
        cursor.close()


def connect_to_webbing_db(db_name):
    """ Connect to PostgreSQL database """
    try:
        connection = psycopg2.connect(
            host='amoppostgresdb.c3qae66ke1lg.us-east-1.rds.amazonaws.com',
            port=5432,
            user='root',
            password='AmopTeam123',
            dbname=db_name
        )
        return connection
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

import pandas as pd
import numpy as np
from datetime import datetime

def syncing_webbing_data(data):
    print('started the webbing data sync function')
    try:
        print("Starting the webbing data sync process...")
        username='spectrotel_api'
        password='4AcO#Fo2HZyn'
        ws_key='cx0kJtwRwlFaKY5WoyuHxjN1gtM='
        # Define date range for usage data
        start_date_str = data.get('start_date', '10/01/2025')  # Default to '10/01/2025' if not found
        end_date_str = data.get('end_date', '10/10/2025')      # Default to '10/10/2025' if not found

        # Convert string dates to datetime objects
        start_date = datetime.strptime(start_date_str, "%m/%d/%Y")
        end_date = datetime.strptime(end_date_str, "%m/%d/%Y")
        
        # Loop through each date in the range
        current_date = start_date
        while current_date <= end_date:
            formatted_date = current_date.strftime("%m/%d/%Y")
            print(f"Processing data for: {formatted_date}")
            
            # Fetch and process data
            # (Assuming fetch_and_update_usage_bulk and other functions are defined elsewhere)
            fetch_and_update_usage_bulk(username, password, ws_key, formatted_date, formatted_date)
            
            # Assuming connection and queries are set up correctly
            connection = connect_to_webbing_db('spectrotel')
            sim_inventory_query = """
                SELECT DISTINCT ON (iccid) id AS sim_management_inventory_id, iccid, device_status_id, device_id AS m2m_device_id
                FROM sim_management_inventory
                WHERE service_provider_display_name = 'Webbing' AND is_active = TRUE
                ORDER BY iccid, id DESC;
            """
            sim_inventory_data = fetch_data_from_db(sim_inventory_query, connection)
            sim_inventory_df = pd.DataFrame(sim_inventory_data)
            
            usage_query = """
                SELECT iccid, total_usage AS data_usage
                FROM webbing_devices_staging;
            """
            usage_data = fetch_data_from_db(usage_query, connection)
            usage_df = pd.DataFrame(usage_data)
            
            # Merge dataframes on 'iccid'
            merged_df = pd.merge(sim_inventory_df, usage_df, on='iccid', how='inner')
            merged_df = merged_df[merged_df['sim_management_inventory_id'].notna()]
            
            # Add necessary columns
            merged_df['device_status_id'] = merged_df['device_status_id'].astype('Int64')
            merged_df['created_by'] = 'Webbing_Container'
            merged_df['usage_date'] = pd.to_datetime(formatted_date)  # Set usage_date for each iteration
            merged_df['created_date'] = pd.to_datetime(formatted_date)  # Set created_date for each iteration
            merged_df['data_usage'] = pd.to_numeric(merged_df['data_usage'], errors='coerce')
            merged_df['data_usage'] = merged_df['data_usage'].apply(np.ceil)
            merged_df['data_usage'] = merged_df['data_usage'].fillna(0).astype(int)
            print(merged_df.head(10),'checking the data of webbing')
            # Step 7: Perform the bulk insert
            if not merged_df.empty:
                insert_webbing_device_usage_bulk_(merged_df, connection)
                insert_webbing_device_usage_bulk_staging(merged_df, connection)
            else:
                print(f"No matching usage data found for {formatted_date}.")
            
            # Close the connection after insertion
            connection.close()
            
            # Move to the next date
            current_date += timedelta(days=1)
        print("Webbing data sync process completed.")
        return {"flag": True, "message": "Webbing data sync completed successfully."}
    except Exception as e:
        print(f"Error during webbing data sync: {e}")
        logging.exception(f"Error during webbing data sync: {e}")
        return {"flag": False, "message": f"Error: {e}"}

def insert_webbing_device_usage_bulk_(df, conn):
    cursor = conn.cursor()
    values = [
        cursor.mogrify("(%s,%s,%s,%s,%s,%s,%s)", tuple(row))
        for row in df[['m2m_device_id','sim_management_inventory_id','device_status_id', 'data_usage','created_date','usage_date','created_by']].values
    ]
    sql = b"INSERT INTO device_usage (m2m_device_id,sim_management_inventory_id, device_status_id,data_usage, created_date,usage_date, created_by) VALUES " + b",".join(values)
    cursor.execute(sql)
    conn.commit()

def insert_webbing_device_usage_bulk_staging(df, conn):
    cursor = conn.cursor()
    values = [
        cursor.mogrify("(%s,%s,%s,%s,%s,%s,%s)", tuple(row))
        for row in df[['m2m_device_id','sim_management_inventory_id','device_status_id', 'data_usage','created_date','usage_date','created_by']].values
    ]
    sql = b"INSERT INTO device_usage_stagging_for_webbing (m2m_device_id,sim_management_inventory_id, device_status_id,data_usage, created_date,usage_date, created_by) VALUES " + b",".join(values)
    cursor.execute(sql)
    conn.commit()

# Function to fetch API data and update DB in bulk
def fetch_and_update_usage_bulk(username,password,ws_key,start_date,end_date):
    # API details
    API_URL = "https://wws.iamwebbing.com/usage/Usage.asmx"
    HEADERS = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://wws.iamwebbing.com/GetDeviceUsage",
    }
    print('Fetching usage data from', start_date, 'to', end_date)
    # start_date='10/09/2025'
    # end_date='10/09/2025'
    page_number = 1
    page_size = 1000
    bulk_data = []  # Store records for bulk update

    # Connect to database
    conn = connect_to_webbing_db('spectrotel')
    if conn is None:
        return

    cursor = conn.cursor()

    while True:
        # SOAP Request Body
        soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                       xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                       xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
        <soap:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
        <Username>{username}</Username>
        <Password>{password}</Password>
        <WSKey>{ws_key}</WSKey>
        </Credentials>
        </soap:Header>
        <soap:Body>
        <GetDeviceUsage xmlns="http://wws.iamwebbing.com/">
        <GetDeviceUsageRequest>
        <StartDate>{start_date}</StartDate>
        <EndDate>{end_date}</EndDate>
        <PaginationRequest>
        <PageSize>{page_size}</PageSize>
        <PageNumber>{page_number}</PageNumber>
        </PaginationRequest>
        </GetDeviceUsageRequest>
        </GetDeviceUsage>
        </soap:Body>
        </soap:Envelope>"""

        # API Call
        response = requests.post(API_URL, data=soap_body, headers=HEADERS)
        if response.status_code != 200:
            print(f"Error: {response.status_code}\n{response.text}")
            break

        # Parse XML Response
        response_dict = xmltodict.parse(response.text)
        json_data = json.loads(json.dumps(response_dict))  # Convert to JSON

        # Extract DeviceUsageRecord data
        device_usage_records = json_data.get("soap:Envelope", {}).get("soap:Body", {}).get(
            "GetDeviceUsageResponse", {}).get("GetDeviceUsageResult", {}).get("Usage", {}).get("DeviceUsageRecord", [])

        if not isinstance(device_usage_records, list):
            device_usage_records = [device_usage_records]  # Convert single record to list
        MB_TO_BYTES = 1024 * 1024 # 1 MB = 1,048,576 bytes
        # Prepare bulk update data
        for record in device_usage_records:
            iccid = record.get("ICCID", "")
            imei = record.get("IMEI", "")
            total_usage_days = record.get("TotalUsageDays", "")
            total_usage = record.get("TotalUsage", "")
           # total_usage_bytes = int(total_usage * MB_TO_BYTES)
            if total_usage:
                try:
                    # Convert total_usage to a float and then to an integer
                    total_usage_bytes = int(float(total_usage) * MB_TO_BYTES)
                except ValueError:
                    # Handle the case where total_usage is not a valid number
                    total_usage_bytes = 0  # or handle as needed

            if iccid:
                bulk_data.append((total_usage_days, total_usage_bytes, imei, iccid))

        # Break loop if records are less than page_size
        if len(device_usage_records) < page_size:
            break

        # Move to next page
        page_number += 1

    # Perform bulk update in one query
    if bulk_data:
        update_query = """
        UPDATE public.webbing_devices_staging AS wds
        SET
            total_usage_days = data.total_usage_days,
            total_usage = data.total_usage,
            imei = data.imei
        FROM (VALUES %s) AS data(total_usage_days, total_usage, imei, iccid)
        WHERE wds.iccid = data.iccid;
        """
        execute_values(cursor, update_query, bulk_data)
        conn.commit()

    cursor.close()
    conn.close()
    print("Updated the device Usage successfully in bulk.")

























































