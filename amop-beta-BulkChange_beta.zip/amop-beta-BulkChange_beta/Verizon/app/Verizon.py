"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
import copy
from decimal import Decimal
import json
import logging
import os
import ast
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
import psycopg2
from pandas import Timestamp
from datetime import datetime
from dotenv import load_dotenv
from dateutil.relativedelta import relativedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import concurrent.futures
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
from pytz import timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random
from collections import defaultdict

# Database configuration
common_utils_database_config = {
        "host": os.environ["HOST"],
        "port": os.environ["PORT"],
        "user": os.environ["USER"],
        "password": os.environ["PASSWORD"],
        "multi_schema":False
    }





##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Access global db_config variable
    db_config_details = None
    # 1. Try to extract encoded config
    # Access global db_config variable
    encoded = data.get('db_config_details', None)
    if encoded:
        try:
            if isinstance(encoded, dict):
                # It’s already a dict, no need to decode
                db_config_details = encoded
            else:
                # It’s a base64-encoded string
                db_config_details = json.loads(base64.b64decode(encoded.encode()).decode())
        except (base64.binascii.Error, UnicodeDecodeError, json.JSONDecodeError) as e:
            logging.info(f"Error decoding/parsing db_config_details: {e}")
            db_config_details = common_utils_database_config
    else:
        db_config_details = common_utils_database_config
    global db_config
    # Initialize base database configuration from environment variables
    db_config = {
        "host": db_config_details.get("hostname") or db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    global db_config_withoutfilter
    db_config_withoutfilter = {
        "host": db_config_details.get("hostname") or  db_config_details.get("host"),
        "port": db_config_details.get("port"),
        "user": db_config_details.get("user"),
        "password": db_config_details.get("password"),
        "multi_schema":False
    }
    # Route to appropriate endpoint handler
    if path == "/verizon_bc_archive_devices":
        result = verizon_bc_archive_devices(data)
    elif path == "/verizon_bc_change_customer_rate_plan":
        result = verizon_bc_change_customer_rate_plan(data)
    elif path == "/verizon_bc_change_carrier_rate_plan":
        result = verizon_bc_change_carrier_rate_plan(data)
    elif path== "/verizon_bc_update_device_status":
        result = verizon_bc_update_device_status(data)
    elif path== "/verizon_bc_change_iccid_imei":
        result = verizon_bc_change_iccid_imei(data)
    elif path== "/verizon_bc_assign_customer":
        result = verizon_bc_assign_customer(data)
    elif path== "/verizon_bc_line_sync":
        result = verizon_bc_line_sync(data)
    elif path== "/verizon_bc_edit_username_cost_center":
        result = verizon_bc_edit_username_cost_center(data)
    elif path== "/verizon_bc_private_network_ip":
        result = verizon_bc_private_network_ip(data)    
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
    ##carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
    logging.info(f"carrier_details: {carrier_details}")
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url

##Archive devices function 
def verizon_bc_archive_devices(data):
    """
    Archives devices from the system based on the provided ICCIDs.

    This function is typically triggered during a bulk change operation, where a list of SIM cards
    (identified by their ICCIDs) needs to be marked as archived in the system. Archiving a device
    means it is no longer considered active or in use, and its status is updated accordingly
    in relevant tables (e.g., inventory, assignment logs, usage tracking).

    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs to be archived.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.

    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
    """
    logging.info(f"Received data for archiving devices: %s", data)
    start_time = time.time()
    # Validate required fields
    iccids = data.get("iccids", [])
    invalid_iccids = data.get("invalid_iccids", [])
    change_type=data.get('change_type')
    tenant_id = data.get("tenant_id", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by=data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    service_provider = data.get("service_provider", "")
    role_name= data.get("role", "")
    service_provider_id = data.get("service_provider_id", "")
    username= data.get("username", "")
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_archiving devices and {tenant_name} time is {now}")
    #database connection
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        logging.error(f"### verizon_bc_archive_devices and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed", "details": str(e)}
    # Audit - start
    bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Initiated"
                )
    live_progress_percentage_tracker(database, bulk_change_id,25)
    try:
        bulk_change_requests = database.get_data(
                'sim_management_bulk_change_request',
                {"bulk_change_id": bulk_change_id},
                ['id', 'iccid','subscriber_number']
        )
        if bulk_change_requests.empty:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_archive_devices",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_archive_devices rate plan and {tenant_name} Audit logging failed: {e}")
                return response
        ##main login to archive the devices
        # Map ICCID to request ID for fast access
        live_progress_percentage_tracker(database, bulk_change_id,40)
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        msisdn_to_request_id = dict(zip(bulk_change_requests["subscriber_number"], bulk_change_requests["id"]))

        # Step 2: Archive valid ICCIDs in inventory
        database.update_dict(
            "sim_management_inventory",
            {"is_active": False,"is_deleted": True},
            and_conditions={"tenant_id": tenant_id},
            in_conditions={"iccid": iccids},
        )
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} archived {len(iccids)} devices in inventory")

        # Prepare logs
        log_entries = []
        invalid_log_entries = []


        # Valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            if request_id:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Archive Device: {iccid}",
                    "request_text": "Update AMOP",
                    "has_errors": False,
                    "response_status": "PROCESSED",
                    "response_text": "Device archived successfully",
                    "error_text": "",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        #updating bulk change request tables     
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Device archived successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # preparing the payload for history table update
        url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
        payload_history_table = {
                            "data": {
                                    "tenant_name": tenant_name,
                                    "username":username,
                                    "path": "/update_device_history_tables",
                                    "change_type":change_type,
                                    "iccids": iccids,
                                    "msisdns":[],
                                    "service_provider":service_provider,
                                    "Partner": tenant_name,
                                    "access_token": access_token,
                                    "db_name": tenant_database,
                                    }
                                }
        # Call the history table update API  
        try:
            logging.info(f"### verizon_bc_archive_devices and {tenant_name} sync call has started for history table")
            threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
        except Exception as e:
            logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Exception in thread: {e}")  
        
        # Invalid SIMs
        live_progress_percentage_tracker(database, bulk_change_id,70)

        invalid_iccids = data.get("invalid_iccids", [])
        for iccid in invalid_iccids:
            request_id = iccid_to_request_id.get(iccid) or msisdn_to_request_id.get(iccid)
            invalid_log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Archive Device Failed: {iccid}",
                "request_text": "Update AMOP",
                "has_errors": True,
                "response_status": "ERROR",
                "response_text": "Invalid SIM - could not be processed",
                "error_text": "Invalid ICCID",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"subscriber_number": invalid_iccids},
        )
        #  Step 3: Bulk insert all logs
        if invalid_log_entries:
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} archived {len(iccids)} devices successfully")


        # Update the status of the bulk change request to PROCESSED
        database.update_dict(
                'sim_management_bulk_change',
                {
                    "status": "PROCESSED",
                    "success": len(iccids),
                    "processed_date": now
                },
                {'id': bulk_change_id}
            )
        ##Future Upudates will be done here 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below sync url and payload used to sync the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Sync To 1.0 Tables"
                )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### verizon_bc_archive_devices and {tenant_name} sync call has started")

            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### verizon_bc_archive_devices and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # Attempt to audit the actionn
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_archive_devices",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for archive devices.{bulk_change_id}",
                "request_received_at": now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database,
                 action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Audit logging failed: {e}")
        # Attempt to audit the actionn
        bulk_change_audit_action(data, common_utils_database,
                 action=f"Bulk Change Process Completed"
                )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### verizon_bc_archive_devices and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )

        return response
    except Exception as e:
        logging.exception(f"verizon_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status verizon_bc_archive_devices: {str(e)}")
        # Update the status of the bulk change request to ERROR
        # Log the error
        error_message = f"Error during bulk change processing for archive status verizon_bc_archive_devices: {str(e)}"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        logging.error(f"### verizon_bc_archive_devices and {tenant_name} Error during bulk change processing for archive status verizon_bc_archive_devices: {str(e)}")
        # Prepare error response
        response = {
            "flag": False,
            "message": "Bulk change request processing failed for verizon_bc_archive_devices.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        try:
            # Log error to database
            error_data = {
                "service_name": "verizon_bc_archive_devices",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for verizon_bc_archive_devices:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Exception in logging error data to DB: {e}")
        return response

## Change customer rate plan function
def verizon_bc_change_customer_rate_plan(data):
    """
    Change the customer rate plan for the given devices as part of a bulk change operation.
   
    this function is typically triggered during a bulk change operation where a list of SIM cards needs to have their customer rate plans updated.
    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs used to identify devices.
            -changed_data (dict): Dictionary containing the rate plan changes.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
            - other metadata as needed for auditing or tracking.
 
    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
 
    Returns:
        dict: Result of the operation with flags, messages, and details.
    """
    logging.info(f"### Received data for changing customer rate plan: %s", data)
    # Start timing the function execution
    start_time = time.time()
    # Extract all required fields from input data
    iccids = data.get("iccids", [])
    provider_parent_name=data.get('provider_parent_name','')
    change_type=data.get('change_type','')
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id= data.get("tenant_id", "")
    source=data.get("source","")
    service_provider = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    invalid_iccids = data.get("invalid_iccids", [])
    invalid_ids=data.get('invalid_ids','')
    parent_tenant_id=data.get('parent_tenant_id',None)
    # Validate required fields
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_change_customer_rate_plan and {tenant_name} time is {now}")
    try:
        # Connect to main and audit databases
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        logging.error(f"### DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    parent_tenant_id = None
    try:
        parent_tenant_id=common_utils_database.get_data('tenant',{"id":tenant_id},["parent_tenant_id"])["parent_tenant_id"].to_list()[0]
    except Exception as e:
        logging.exception(f"Exception while fetching parent_tenant_id{e}")
        parent_tenant_id = None
    try:
        # Audit - Start
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Initiated"
        )
        live_progress_percentage_tracker(database, bulk_change_id,25)
        
        # Fetch bulk change request entries for valid ICCIDs
        bulk_change_requests = database.get_data(
            'sim_management_bulk_change_request',
            {"bulk_change_id": bulk_change_id},
            ['id', 'iccid','change_request']
        )
        if not bulk_change_requests.empty:
            change_request_json = bulk_change_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_change_customer_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
            
        # Map iccids to request IDs
        live_progress_percentage_tracker(database, bulk_change_id,40)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        customer_rate_plan_update=change_request_json.get("CustomerRatePlanUpdate","")
        customer_rate_plan_id=customer_rate_plan_update.get("CustomerRatePlanId","")
        customer_rate_pool_id=customer_rate_plan_update.get("CustomerPoolId","")
        effective_date=customer_rate_plan_update.get("EffectiveDate","")
        customer_name = customer_rate_plan_update.get("customerName", "")
        rate_plan_db_name=None
        rate_pool_db_name=None
        plan_mb=None
        rev_customer_name=None
        rev_customer_id=None
        customer_id=None
        # Validate input data
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_name","plan_mb"]   
            )
            if not rate_plan_data.empty:
                rate_plan_db_name = rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb = rate_plan_data["plan_mb"].to_list()[0]

        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                rate_pool_db_name = rate_pool_data["name"].to_list()[0]
        
        update_fields={}
        fields_to_update=[]

        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_rate_plan_name"]
            ).to_dict(orient="records")
        # Extract valid ICCIDs
        # Prepare an update dict dynamically
        if customer_rate_plan_id is None:
            update_fields["customer_rate_plan_id"] = None
            update_fields["customer_rate_plan_name"] = None
        elif str(customer_rate_plan_id).strip() != "-1":
            update_fields["customer_rate_plan_id"] = customer_rate_plan_id
            update_fields["customer_rate_plan_name"] = rate_plan_db_name
            fields_to_update.extend([
                    "customer_rate_plan_id",
                    "sub_tenant_carrier_rate_plan_name",
                    "sub_tenant_carrier_rate_plan_name_id"
                ])
        if not customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(customer_rate_pool_id) != "-1":
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id	
            update_fields["customer_rate_pool_name"] = rate_pool_db_name
            fields_to_update.append("customer_rate_pool_id")


        if effective_date:
            update_fields["effective_date"] = effective_date
        if customer_name:  
            update_fields["customer_name"] = customer_name
            rev_data = database.get_data(
                "revcustomer",
                {"customer_name": customer_name, "is_active": True,"tenant_id": tenant_id},
                ["customer_name", "rev_customer_id"]
            )
            if not rev_data.empty:
                rev_customer_name = rev_data["customer_name"].to_list()[0]
                rev_customer_id = rev_data["rev_customer_id"].to_list()[0]
                update_fields["rev_customer_id"] = rev_customer_id
                update_fields["rev_customer_name"] = rev_customer_name
                fields_to_update.append("account_number")
            customer_data = pd.DataFrame()
            if rev_customer_name:
                customer_data=database.get_data(
                    "customers",
                    {"customer_name":rev_customer_name,"is_active": True},
                    ["id","customer_name"]
                )
            if not customer_data.empty:
                customer_id=customer_data["id"].to_list()[0]
                update_fields["customer_id"]=customer_id
                fields_to_update.append("customer_id")
        if plan_mb is not None:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None

        # Update the SIM management inventory with the new rate plan
        if update_fields.items():
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Updating SIM management inventory with updated fields: {update_fields}")
            database.update_dict(
            "sim_management_inventory",update_fields,
            and_conditions={"tenant_id":tenant_id,"is_active": True},
            in_conditions={"iccid": iccids},
            
            )
        if not parent_tenant_id  and "customer_rate_plan_name" in update_fields:
                logging.info(f"sub tenant carrier rate plan update {update_fields}")
                if iccids:
                    database.update_dict("sim_management_inventory", 
                                        {
                                            "sub_tenant_carrier_rate_plan_name": update_fields.get("customer_rate_plan_name"),
                                            "sub_tenant_carrier_rate_plan_name_id":update_fields.get("customer_rate_plan_id")
                                        },in_conditions={"iccid": iccids})
                    logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} updated customer rate plan for {len(iccids)} devices in inventory") 
        # Map ICCID to request ID for logging
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entries = []
        invalid_log_entries = []
 
        # Log valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Change Customer Rate Plan",
                "request_text": "Update AMOP",
                "has_errors": False,
                "response_status": "PROCESSED",
                "response_text": "Changed customer rate plan successfully",
                "error_text": "",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        #update       
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now,"status_details":"Changed customer rate plan successfully"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Prepare payload for history table update
        if iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        "fields_updated": fields_to_update,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table update API  
            try:
                logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}") 

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Customer Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in action history thread: {e}") 
        
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                invalid_log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan Failed",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if invalid_log_entries:
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} inserted {len(invalid_log_entries)} log entries for bulk change request")
        # Update bulk change status to PROCESSED
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "success": len(iccids),
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Below sync url and payload used to sync the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Sync To 1.0 Tables"
        )
        try:
            if iccids:
                data["customername"]= customer_name
                data["CustomerRatePlanId"]= customer_rate_plan_id
                data["customerId"] = rev_customer_id if rev_customer_id else customer_id
                logging.info(f"### telegence_bc_change_customer_rate_plan and {tenant_name} sync call for billing  has started")
                data["effective_date"]= effective_date
                billing_integration_change_rate_plan(data)
        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        live_progress_percentage_tracker(database, bulk_change_id,80)
        try:
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        # Prepare success response
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the auditing log
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            if iccids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "service_provider": service_provider,
                    "customer_rate_plan_name":update_fields.get('customer_rate_plan_name',''),
                    "changed_data": {
                            "iccid": iccids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="iccid"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_change_customer_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing customer rate plan for devices.{bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")

        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        return response
 
    except Exception as e:
        # Main exception block
        logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processingg: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "verizon_bc_change_customer_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_customer_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
 
##Update Device Status function
def verizon_bc_update_device_status(data):
    """
   Update the device status using the Verizon API.

    This function processes a list of MSISDNs and updates their device status in the Verizon system.
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps MSISDNs to their respective request payloads.
        - Iteratively calls the Verizon API for each MSISDN with retry logic.
        - Updates status in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid MSISDNs or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - msisdns (list): List of MSISDNs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the Verizon API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., SIM status or device status).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_msisdns (list): MSISDNs that failed validation before processing.
            - invalid_ids (list): Request IDs associated with invalid rows.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict: A response object indicating the result of the operation, containing:
            - flag (bool): True if processing completed without unhandled exceptions.
            - message (str): Summary message indicating the result.
            - processed (int): Number of MSISDNs processed.
            - msisdns (list): List of MSISDNs attempted.
            - invalid_msisdns (list): List of MSISDNs skipped due to invalid state.
            - bulk_change_id (str): ID of the bulk change request.
            - error (str, optional): Error message in case of failure.
    """
    logging.info(f"### Received data for updating device status: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    invalid_iccids = data.get("invalid_iccids", [])
    account_number=data.get("account_number","")
    request_received_at = data.get("request_received_at", "")
    source=data.get("source","")
    status_update = data.get("changed_data", {}).get("UpdateStatus", {})
    integration_id=data.get("integration_id", "")
    service_provider_id = data.get("service_provider_id", "")
    device_status_id = data.get("device_status_id","")
    ip_address=data.get("changed_data", {}).get("Request", {}).get("ipAddress")
    ip_restriction = data.get("publicIpRestriction", "")
    provider_parent_name=data.get("parent_provider_name", "")
    iccid_ip_map=data.get("iccid_ip_map",{})

 

    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_update_device_status and {tenant_name} time is {now}")

    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### verizon_bc_update_device_status and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        logging.error(f"### verizon_bc_update_device_status and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        provider = provider_parent_name if provider_parent_name else service_provider
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid","subscriber_number", "change_request"]
        )
        remaining = list(iccids)
        if not bulk_requests_df.empty:
            change_request_json=bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_update_device_status",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### verizon_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response
        requests_map = dict(zip(bulk_requests_df["iccid"], bulk_requests_df["change_request"]))
        if isinstance(change_request_json, str):
            change_request_json = json.loads(change_request_json)
        # update_status=change_request_json.get("UpdateStatus","")
        # sim_status=update_status
        # logging.info(f"### verizon_bc_update_device_status and {tenant_name} Update status: {update_status}")
        request_json=change_request_json.get("Request","")
        #new_iccid=request_json.get("ICCID","")
        #new_imei=request_json.get("IMEI","")
        rateplancode=request_json.get("RatePlanCode","")
        reasoncode=request_json.get("ReasonCode","")
        mdnzipcode=request_json.get("MdnZipCode","")
        ppu_data = request_json.get("thingSpacePPU", {})
        first_name = ppu_data.get("FirstName", "")
        last_name = ppu_data.get("LastName", "")
        address_line = ppu_data.get("AddressLine", "")
        city = ppu_data.get("City", "")
        state = ppu_data.get("State", "")
        zip_code = ppu_data.get("ZipCode", "")
        country = ppu_data.get("Country", "")
        thing_space_ppu = request_json.get("thingSpacePPU", {})
        public_ip_restriction = change_request_json.get("publicIpRestriction", "")
        default_msisdn=change_request_json.get("subscriber_number",None)


        updated_data= {}
        updated_data = {
            "user_address": json.dumps(thing_space_ppu)
        }
        inventory_update={}
        rate_plan_id = None
        rate_plan_code = None
        rate_plan_data = pd.DataFrame()
        update_fields = {}
        carrier_plan=None
        customer_rate_plan_data=None
        if role_name not in ('Super Admin','Partner Admin'):
            logging.info(f"### verizon_bc_update_device_status and {tenant_name} User role is {role_name}, fetching rate plan details for rate plan code: {rateplancode}")
            if rateplancode:
                customer_rate_plan_data = database.get_data(
                    "customerrateplan",
                    {"rate_plan_name": rateplancode, "is_active": True},
                    ["id","carrier_rate_plan"]
                    )
            if not customer_rate_plan_data.empty:
                carrier_plan=customer_rate_plan_data["carrier_rate_plan"].to_list()[0]
            if carrier_plan:
                rateplancode=carrier_plan
                logging.info(f"### verizon_bc_update_device_status and {tenant_name} Mapped customer rate plan {carrier_plan} to carrier rate plan code: {rateplancode}")
        # fetching the rate plan details based on the rate plan code to get the rate plan id and friendly name to update in inventory 
        if rateplancode:
            rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": rateplancode, "is_active": True},
            ["id","rate_plan_code"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            rate_plan_code=rate_plan_data["rate_plan_code"].to_list()[0]#friendly_name
        if rate_plan_id:
            update_fields["carrier_rate_plan_id"] = rate_plan_id
        if rate_plan_code:
            update_fields["carrier_rate_plan_name"] = rate_plan_code
        else:
            update_fields["carrier_rate_plan_name"] = rateplancode

        inventory_update_fileds = dict(update_fields)
        inventory_update_fileds.update({
            "tenant_id": tenant_id,
            "is_active": True,
            "is_deleted":False,
            "tenant_is_active":True,
            "tenant_is_deleted":False,
            "created_by": created_by,
            "created_date": now,
            "service_provider_display_name": service_provider,                               
            "service_provider_id":service_provider_id,
            "service_provider_is_active":True,
            "device_status_id":device_status_id,
            "sim_status":status_update 

        })
        # Validate required fields            
        account_data= database.get_data(
            "integration_authentication",
            {"integration_id": integration_id, "service_provider_id": service_provider_id,},
            ["oauth2_custom1","username","password"]
        )
        if not account_data.empty:
            accountname = account_data.iloc[0]["oauth2_custom1"]
            username_value=account_data.iloc[0]["username"]
            password_value=account_data.iloc[0]["password"]
        else:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Account name not found for integration ID: {integration_id}")
            accountname = None
            username_value=None
            password_value=None
        if account_number:
            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Using provided account number: {account_number} and accountname taken is {accountname}")
            accountname=account_number

        device_status_data = pd.DataFrame()
        if device_status_id:
            device_status_data = database.get_data(
                "device_status",
                {"id": device_status_id, "is_active": True},
                ["id", "status"]
            )    
        if not device_status_data.empty:
            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Found device status data: {device_status_data}")
            device_status = device_status_data["status"].iloc[0]
            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Mapped device status ID {device_status_id} to status '{device_status}'")
        else:
            # if status not found
            device_status = None
        if device_status_id:
            inventory_update["device_status_id"]= int(device_status_id)
            inventory_update["sim_status"]= device_status
        else:
            inventory_update["sim_status"]=status_update

        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
        ).to_dict(orient="records")
        # Validate input data
        inventory_lookup = {rec["iccid"]: rec for rec in old_inventory_data}
        if source == "Inventory":
            old_inventory_data = old_inventory_data
            
        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        # MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        MAX_RETRIES=20
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        succesfull_iccids=[]
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Fetching access token and session ID")
        access_id,session_id=get_verizon_token_details(app_id,app_secret,username_value,password_value)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        #constracting header 
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }
        url=None
        payload=None
        update_status = str(device_status)
        logging.info(f"### verizon_bc_update_device_status update_status : {update_status}")
        if update_status.lower() == "inventory":
            if invalid_iccids:
               iccids.extend(invalid_iccids)
               remaining=list(iccids)
            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Inventory update for ICCIDs: {iccids}")
        if update_status.lower()=="deactive":
            update_status="deactivate"
        # elif update_status.lower() == "pending activation": 
        #     update_status = "preactive"   
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")

        # Execute API calls in parallel using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}
                for iccid in batch:
                    

                    def task(iccid, update_status):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        api_success = False
                        json_request=requests_map.get(iccid)
                        if iccid_ip_map:
                            ip_address=iccid_ip_map.get(iccid,"")
                        else:
                            ip_address=""
                        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Processing ICCID: {iccid} with request: {json_request}")
                        if isinstance(json_request, str):
                            json_request = json.loads(json_request)
                        req = json_request.get("Request", {})
                        new_iccid=req.get("ICCID","")
                        new_imei=req.get("IMEI","")
                        update_status = update_status.strip().lower()
                        if update_status in ("restore","suspend"):
                            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Processing restore and suspend")
                            url = f"{carrier_api_url}/{update_status}"
                            payload ={   
                                "devices": [
                                    {
                                    "deviceIds": [
                                        {
                                        "id": new_iccid,
                                        "kind": "iccid"
                                        }
                                    ]
                                    }
                                ]
                            }
                        elif update_status == "deactivate":
                            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Processing deactivate")
                            url = f"{carrier_api_url}/{update_status}"
                            # if update_status.lower() == "preactive":
                            #     url = f"{carrier_api_url}/add"
                            payload = {
                                        "devices": [
                                        {
                                            "deviceIds": [
                                            {
                                                "id": new_iccid,
                                                "kind": "iccid"
                                            }
                                            ]
                                        }
                                        ],
                                        "reasonCode": reasoncode,
                                    }
                        else:
                            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Processing activate and inventory")
                            if update_status.lower() == "active" and update_status.lower() != "inventory":
                                update_status = "activate"
                                url = f"{carrier_api_url}/{update_status}"
                                payload={
                                    "devices": [
                                            {
                                            "deviceIds": [
                                                {
                                                "kind": "iccid",
                                                "id": new_iccid
                                                },
                                                {
                                                "kind": "imei",
                                                "id": new_imei
                                                }
                                            ],
                                            "ipAddress": ip_address
                                            }
                                        ],
                                        "accountName": accountname,
                                        "servicePlan": rateplancode,
                                        "publicIpRestriction":public_ip_restriction,
                                        "mdnZipCode": mdnzipcode,
                                        "primaryPlaceOfUse": {
                                            "customerName": {
                                            "firstName": first_name,
                                            "lastName": last_name
                                            },
                                            "address": {
                                            "addressLine1": address_line,
                                            "city": city,
                                            "state": state,
                                            "zip": zip_code,
                                            "country":country
                                            }
                                        }
                                    }
                        # Retry logic
                        if update_status.lower() != "inventory":
                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                    resp = requests.post(url, json=payload, headers=headers, timeout=60)
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                    success = 200 <= resp.status_code < 300
                                    result = resp.text
                                    status = "PROCESSING" if success else "API_FAILED"
                                    if success:
                                        succesfull_iccids.append(iccid)
                                        response_data=resp.json()
                                        break
                                except Exception as e:
                                    result = str(e)
                                    logging.warning(f"### verizon_bc_update_device_status and {tenant_name} Attempt {attempt} failed for iccid: {iccid}: {result}")
                                    time.sleep(RETRY_DELAY)

                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": status, "has_errors": not success, "is_processed": True,
                            "processed_date": now,"status_details":result},
                                and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                            )
                            
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                "request_text": json.dumps(payload),
                                "has_errors": not success,
                                "response_status":"PROCESSED" if success else "API_Failed",
                                "response_text": result,
                                "error_text": "" if success else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            RETRY_INTERVAL = 120 
                            if success:
                                api_success = False
                                fault_string = "No callback received from carrier within retry limit"
                                new_msisdn = None
                                new_state = None
                                resp_status= None
                                status = "API_FAILED"  # default until proven otherwise

                                request_id_data = response_data.get("requestId", None)
                                logging.info(f"### verizon_bc_update_device_status and {tenant_name} Verizon API call successful for iccid: {response_data}, request_id: {request_id_data}")
                                if request_id_data:
                                    time.sleep(RETRY_INTERVAL) # Initial wait before checking for callback
                                    for attempt in range(MAX_RETRIES):
                                        callback_df =common_utils_database.get_data(
                                            "bulk_change_verizon_callback",
                                            {"request_id": request_id_data},
                                            ["fault_code", "fault_string", "msisdn", "sim_status","status"]
                                        )

                                        if isinstance(callback_df, pd.DataFrame) and not callback_df.empty:
                                            fault_code = callback_df.iloc[0]["fault_code"]
                                            fault_string = callback_df.iloc[0]["fault_string"]
                                            raw_msisdn = callback_df.iloc[0]["msisdn"]
                                            new_msisdn = raw_msisdn if raw_msisdn not in (None, "", "null") else default_msisdn

                                          #  new_msisdn = callback_df.iloc[0]["msisdn"] 
                                            
                                            new_state = callback_df.iloc[0]["sim_status"]
                                            resp_status = (callback_df.iloc[0]["status"] or "").strip()
                                            logging.info(f"### verizon_bc_update_device_status and {tenant_name} Callback received for request_id: {request_id_data} with status: {new_state}, MSISDN: {new_msisdn}, fault_code: {fault_code}, fault_string: {fault_string}")
                                            break 
                                        else:
                                            logging.info(f"[Retry {attempt+1}/{MAX_RETRIES}] No callback yet for request_id: {request_id_data}")
                                            if attempt < MAX_RETRIES - 1:   
                                                time.sleep(RETRY_INTERVAL)
                                # After retries, check if we got the status
                                if new_state or (resp_status and resp_status.lower() == "success"):
                                    status = "PROCESSED"
                                    api_success = True
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Updating SIM status to active for iccid: {iccid}")

                                    if update_status.lower() in ("restore", "suspend", "deactivate"):
                                        logging.info(f"### Updating SIM status for iccid: {update_status}")
                                        database.update_dict(
                                            "sim_management_inventory",
                                            inventory_update,
                                            and_conditions={    
                                                "is_active": True,
                                                "service_provider_display_name": service_provider
                                            },
                                            in_conditions={"iccid": [iccid]}
                                        )
                                    # For activate
                                    else:
                                        updated_data["sim_status"] = status_update
                                        updated_data["ip_address"] = ip_address
                                        updated_data["imei"] = new_imei
                                        updated_data["username"] = f"{first_name} {last_name}"
                                        if new_msisdn:
                                            updated_data["msisdn"] = new_msisdn

                                        database.update_dict(
                                            "sim_management_inventory",
                                            updated_data,
                                            and_conditions={
                                                "is_active": True,
                                                "service_provider_display_name": service_provider
                                            },
                                            in_conditions={"iccid": [iccid]}
                                        )
                                    record = inventory_lookup.get(iccid, {})
                                    try:
                                        status_history={
                                            "iccid": iccid,
                                            "sim_management_inventory_id": record.get("id", "")if record else None,
                                            "msisdn": record.get("msisdn", "")if record else None,
                                            "username": record.get("username", None),
                                            "previous_status": record.get("sim_status", "") if record else None,
                                            "current_status": update_status,
                                            "bulk_change_id": bulk_change_id,
                                            "change_event_type": change_type,
                                            "date_of_change": request_received_at,
                                            "tenant_id": tenant_id,
                                            "customer_name": record.get("customer_name", "") if record else None,
                                            "customer_account_number": record.get("account_number", "") if record else None,
                                            "customer_rate_plan": record.get("customer_rate_plan_name", "") if record else None,
                                            "customer_rate_pool": record.get("customer_rate_pool_name", "") if record else None,
                                            "service_provider_display_name": service_provider,
                                            "service_provider_id": record.get("service_provider_id", "") if record else None,
                                            "device_id": record.get("device_id", None) if record else None,
                                            "mobility_device_id": record.get("mobility_device_id", None) if record else None,
                                            "date_of_change": now,
                                            "changed_by": created_by,
                                            "customer_name_with_revio":(f"{record.get('rev_customer_name')} ({record.get('rev_customer_id')})"
                                                        if record.get("rev_customer_name") and record.get("rev_customer_id")
                                                        else None),
                                            "is_deleted": False,
                                        }
                                        if status_history:   
                                            logging.info(f"### device_status_history inserting  record data : {status_history}")
                                            inserted_id = database.insert_data(status_history, "device_status_history")
                                            if inserted_id:
                                                device_status_history_id = inserted_id
                                            #preparing for updating smi_device_detail_history table
                                            status_history.pop("device_id") 
                                            status_history.pop("bulk_change_id")   
                                            status_history["module_name"] = "Bulk Change" 
                                            status_history["is_active"] = record.get("is_active", "") if record else None
                                            status_history["dshid"] =device_status_history_id if device_status_history_id else None

                                            #insert into smi_device_detail_history
                                            logging.info(f"### verizon_bc_update_device_status inserting  record data : {status_history}")
                                            database.insert_data(status_history, "smi_device_detail_history")
                                    except Exception as e:
                                        ## audit if insert failed history
                                        error_message = f"Error during inserting history table: {str(e)}"
                                        error_type = type(e).__name__
                                        try:
                                            error_data = {
                                                "service_name": "verizon_bc_update_device_status",
                                                "error_message": error_message,
                                                "error_type": error_type,
                                                "users": username,
                                                "tenant_name": tenant_name,
                                                "comments": f"Error while inserting into the history table for ICCID: {iccid}",
                                                "module_name": "Bulk Change",
                                                "request_received_at": data.get("request_received_at") or now
                                            }
                                            common_utils_database.log_error_to_db(error_data, "error_log_table")
                                        except Exception as log_e:
                                            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Exception in logging error data: {log_e}")        
                                else:
                                    status = "API_FAILED"
                                    api_success = False
                                
                                p = {
                                        "status": status,
                                        "has_errors": not api_success,
                                        "is_processed": True,
                                        
                                        "processed_date": now,
                                        "status_details": f"status {new_state if new_state else (fault_string if fault_string else resp_status)}"
                                    }
                                
                                if new_msisdn:
                                    p["subscriber_number"] = new_msisdn
                                    

                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    p,
                                    and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                                )

                                
                                log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                    "request_text": json.dumps(payload),
                                    "has_errors": not api_success,
                                    "response_status": status,
                                    "response_text": new_state if new_state else fault_string,
                                    "error_text": "" if api_success else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                if log:
                                    database.insert_data(log, "sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        # Handle inventory update without API call
                        else:
                            message = None
                            insert_id=None
                            if iccid in invalid_iccids:
                                logging.info(f"### verizon_bc_update_device_status and {tenant_name}  inventory update for iccid: {iccid} as update_status is 'inventory'")
                                current_data = dict(inventory_update_fileds)  # safe copy
                                #current_data = copy.deepcopy(inventory_update_fileds)
                                current_data["iccid"] = iccid
                                insert_id=database.insert_data(current_data, "sim_management_inventory")
                                message=f"Inventory updated successfully with ID {insert_id}"
                                logging.info(f"### verizon_bc_update_device_status and {tenant_name} Inventory updated for iccid: {iccid} with data: {update_fields}")
                                
                            else:
                              message=f"ICCID {iccid} is already present in inventory"
                            database.update_dict(
                                            "sim_management_bulk_change_request",
                                            {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":message},
                                            and_conditions={"bulk_change_id": bulk_change_id},
                                            in_conditions={"iccid": [iccid]},
                                        )
                            record = inventory_lookup.get(iccid, {})
                            try:

                                status_history={
                                    "iccid": iccid,
                                    "sim_management_inventory_id": record.get("id", None)if record else None,
                                    "msisdn": record.get("msisdn", None)if record else None,
                                    "username": record.get("username", None)if record else None,
                                    "previous_status": record.get("sim_status", None) if record else None,
                                    "current_status": update_status,
                                    "bulk_change_id": bulk_change_id,
                                    "change_event_type": change_type,
                                    "date_of_change": request_received_at,
                                    "tenant_id": tenant_id,
                                    "customer_name": record.get("customer_name", None) if record else None,
                                    "customer_account_number": record.get("account_number", None) if record else None,
                                    "customer_rate_plan": record.get("customer_rate_plan_name", None) if record else None,
                                    "customer_rate_pool": record.get("customer_rate_pool_name", None) if record else None,
                                    "service_provider_display_name": service_provider,
                                    "service_provider_id": record.get("service_provider_id", None) if record else None,
                                    "device_id": record.get("device_id", None) if record else None,
                                    "mobility_device_id": record.get("mobility_device_id", None) if record else None,
                                    "date_of_change": now,
                                    "changed_by": created_by,
                                    "customer_name_with_revio":(f"{record.get('rev_customer_name')} ({record.get('rev_customer_id')})"
                                                if record.get("rev_customer_name") and record.get("rev_customer_id")
                                                else None),
                                    "is_deleted": False,
                                }
                                if status_history:   
                                    logging.info(f"### device_status_history inserting  record data : {status_history}")
                                    inserted_id = database.insert_data(status_history, "device_status_history")
                                    if inserted_id:
                                        device_status_history_id = inserted_id
                                    
                                    #preparing for updating smi_device_detail_history table
                                    status_history.pop("device_id") 
                                    status_history.pop("bulk_change_id")   
                                    status_history["module_name"] = "Bulk Change" 
                                    status_history["is_active"] = record.get("is_active", None) if record else None
                                    status_history["dshid"] =device_status_history_id if device_status_history_id else None

                                    #insert into smi_device_detail_history
                                    logging.info(f"### verizon_bc_update_device_status inserting  record data : {status_history}")
                                    database.insert_data(status_history, "smi_device_detail_history")
                            except Exception as e:
                                ## audit if insert failed history
                                error_message = f"Error during inserting history table: {str(e)}"
                                error_type = type(e).__name__
                                try:
                                    error_data = {
                                        "service_name": "verizon_bc_update_device_status",
                                        "error_message": error_message,
                                        "error_type": error_type,
                                        "users": username,
                                        "tenant_name": tenant_name,
                                        "comments": f"Error while inserting into the history table for ICCID: {iccid}",
                                        "module_name": "Bulk Change",
                                        "request_received_at": data.get("request_received_at") or now
                                    }
                                    common_utils_database.log_error_to_db(error_data, "error_log_table")
                                except Exception as log_e:
                                    logging.error(f"### verizon_bc_update_device_status and {tenant_name} Exception in logging error data: {log_e}")
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Verizon Subscriber: Inventory Update",
                                "request_text": "Update AMOP",
                                "has_errors": False,
                                "response_status": "PROCESSED",
                                "response_text": f"Inventory updated successfully with ID {insert_id}" if insert_id else message,
                                "error_text": "",
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        return iccid

                    # futures[executor.submit(task)] = iccid    
                    futures[executor.submit(task, iccid, update_status)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Error processing MSISDN: {e}")

        if INTERVAL and i + BATCH_SIZE < len(iccids):
            time.sleep(INTERVAL)
        # Handle and log invalid MSISDNs
        if update_status.lower() != "inventory":
            if invalid_iccids:
                for iccid in invalid_iccids:
                    request_id = iccid_to_request_id.get(iccid)
                    logs.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": request_id,
                        "log_entry_description": "Update Verizon Subscriber: Invalid MSISDN",
                        "request_text": "N/A",
                        "has_errors": True,
                        "response_status": "ERROR",
                        "response_text": "Invalid SIM - could not be processed",
                        "error_text": "Invalid ICCID",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                    })

            if logs:
                database.insert_data(logs,"sim_management_bulk_change_log")
                #  insert the log entries into detailed logs table
                database.insert_data(logs,"sim_management_bulk_change_detailed_logs")

            # Mark invalid request IDs as processed
            if invalid_iccids:
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR", "is_processed": True, "has_errors": True,
                        "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                    and_conditions={"bulk_change_id": bulk_change_id},
                    in_conditions={"iccid": invalid_iccids}
                )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )
        # preparing the payload for history table update
        if succesfull_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": succesfull_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API  
            try:
                logging.info(f"### verizon_bc_archive_devices and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_archive_devices and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            action_history_payload = {
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": succesfull_iccids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Update Device Status",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_field": "sim_status"
                }
            }
            
            # API call to update action history
            try:
                logging.info(f"### verizon_bc_update_device_status and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Exception in action history thread: {e}")  
    
        #  sync API trigger 
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Below sync url and payload used to sync the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            logging.info(f"### verizon_bc_update_device_status and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f"### verizon_bc_update_device_status and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Exception in thread: {e}")

        try:
            if succesfull_iccids:
                data["iccids"]=succesfull_iccids
                logging.info(f"### verizon_bc_update_device_status and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        
        try:
            if succesfull_iccids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "changed_data": {
                            "iccid": succesfull_iccids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="iccid"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### verizon_bc_update_device_status and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "msisdns": iccids,
            "invalid_msisdns": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the final bulk change log
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_update_device_status",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk change",
                "comments": f"Successfully processed bulk change request for updating device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### verizon_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### verizon_bc_update_device_status and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "verizon_bc_update_device_status",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": iccids,
            "invalid_msisdns": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response


## Change Carrier Rate Plan function
def verizon_bc_change_carrier_rate_plan(data):
    """Change the carrier rate plan for the given devices.
    This function processes a list of iccids and updates their carrier rate plan in the Verizon system.
    It handles bulk requests, updates the database, and logs the results.   
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDS to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Verizon API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Recevied data for change carrier rate plan :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    changed_data = data.get("changed_data")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    provider_parent_name=data.get("parent_provider_name", "")
    integration_id=data.get("integration_id", "")
    service_provider_id = data.get("service_provider_id", "")
    # Initialize for log entries
    log_entries = []
    succesful_iccids=[]
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_change_carrier_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
                return response
            live_progress_percentage_tracker(database, bulk_change_id,20)
                
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        carrier_rate_plan_update=change_request_json.get("CarrierRatePlanUpdate","")
        carrie_rate_plan=carrier_rate_plan_update.get("CarrierRatePlan","")
        effective_date=carrier_rate_plan_update.get("EffectiveDate","")
        communication_plan = carrier_rate_plan_update.get("CommPlan","")

        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        ## Prepare headers for API call
        rate_plan_id=None
        rate_plan_code=None
        # Validate input data for rateplan and optimization
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Validating input data for rate plan and optimization group")
        if carrie_rate_plan:
           rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrie_rate_plan, "is_active": True},
            ["id","rate_plan_code"]
            )
        if not rate_plan_data.empty:
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            rate_plan_code=rate_plan_data["rate_plan_code"].to_list()[0]
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Rate plan ID: {rate_plan_id} Rate Plan Code: {rate_plan_code}")
        # Prepare an update dict 
        fields_to_update=[]
        if carrie_rate_plan:
           update_fields = {"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": carrie_rate_plan} 
           fields_to_update.extend(["rate_plan","carrier_rate_plan_id"])      
        if effective_date:
           update_fields["effective_date"] = effective_date
        if communication_plan:
           update_fields["communication_plan"] = communication_plan
           fields_to_update.extend(["communication_plan","sub_tenant_communication_plan","sub_tenant_communication_plan_id"])
        # Validate iccids
        remaining = iccids.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
        account_data= database.get_data(
            "integration_authentication",
            {"integration_id": integration_id, "service_provider_id": service_provider_id,},
            ["oauth2_custom1","username","password"]
        )
        if not account_data.empty:
            accountname = account_data.iloc[0]["oauth2_custom1"]
            username_value=account_data.iloc[0]["username"]
            password_value=account_data.iloc[0]["password"]
        else:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Account name not found for integration ID: {integration_id}")
            accountname = None
            username_value=None
            password_value=None
   
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","carrier_rate_plan_name"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###verizon_bc_change_carrier_rate_plan and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        remaining = list(iccids) 
        # Get access token and session ID
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Fetching access token and session ID")
        access_id,session_id=get_verizon_token_details(app_id,app_secret,username_value,password_value)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        #constracting header 
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")

        # Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each iccid in the batch
                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} iccids")
                for iccid in batch:
                    # Prepare the URL and payload for the API call
                    def task(iccid=iccid):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        response_data=None
                        url = f"{carrier_api_url}"
                        payload = {
                            "devices": [
                                {
                                    "deviceIds": [
                                        {"kind": "iccid", "id": iccid},
                                    ]
                                }
                            ],
                        "servicePlan" :carrie_rate_plan
                        }
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                resp = requests.put(
                                    url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSING" if success else "API_FAILED"
                                if success:
                                    response_data=resp.json()
                                    succesful_iccids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Attempt {attempt} failed for iccids: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            update_data = {
                                "status": status,
                                "has_errors": False,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":result   
                            }
                        else:
                            update_data = {
                                "status": status,
                                "has_errors": True,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details":result
                            }
                        #update the request status
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id},
                            )                        
                        # Constructing the log entry
                        log = {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update Verizon Subscriber: Verizon API",
                        "request_text": json.dumps(payload),
                        "has_errors": status == "API_FAILED",
                        "response_status": "PROCESSED" if success else "API_Failed",
                        "response_text": result,
                        "error_text": "" if status == "PROCESSED" else result,
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                        }
            
                        if log:
                            database.insert_data(log,"sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs") 
                        if success:
                            request_id_data = response_data.get("requestId", None)
                            RETRY_INTERVAL = 60
                            api_result = False
                            fault_string = "No callback received from carrier within retry limit"
                            time.sleep(RETRY_INTERVAL) # Initial wait before checking for callback
                            for attempt in range(MAX_RETRIES):
                                callback_df = common_utils_database.get_data(
                                    "bulk_change_verizon_callback",
                                    {"request_id": request_id_data},
                                    ["fault_code", "fault_string"]
                                )

                                if not callback_df.empty:
                                    fault_string = callback_df.iloc[0]["fault_string"]
                                    logging.info(f"### verizon_bc_update_device_status and {tenant_name} Callback received for request_id: {request_id_data} with status fault_string: {fault_string}")
                                    break

                                else:
                                    logging.info(f"[Retry {attempt+1}/{MAX_RETRIES}] No callback yet for request_id: {request_id_data}")
                                    if attempt < MAX_RETRIES - 1:   
                                        time.sleep(RETRY_INTERVAL)  
                            if fault_string == carrie_rate_plan:
                                    database.update_dict(
                                        "sim_management_inventory", update_fields,
                                        and_conditions={ "is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                    status = "PROCESSED"
                                    api_result = True
                            else:
                                status = "API_FAILED"
                                api_result = False
                            database.update_dict(
                                    "sim_management_bulk_change_request",
                                    {
                                        "status": status,
                                        "has_errors": not api_result,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details": fault_string
                                    },
                                    and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                                )
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                "request_text": json.dumps(payload),
                                "has_errors": not api_result,
                                "response_status": status,
                                "response_text": fault_string,
                                "error_text": "",
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")

                                            
                        return iccid
                    
                    # Submit the task to the executor
                    logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Submitting task for ICCID: {iccid}")
                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Error processing ICCIDS: {e}")

              
        if interval and i + batch_size < len(iccids):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # preparing the payload for history table update
        if succesful_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": succesful_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        "fields_updated": fields_to_update,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            # Call the history table update API  
            try:
                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")  
            
        # Update the bulk change request status   
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Processed {len(iccids) - len(remaining)} iccids, {len(remaining)} remaining")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": succesful_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Carrier Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "carrier_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"verizon_bc_change_carrier_rate_plan and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API URL and payload are used to sync inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info('### verizon_bc_change_carrier_rate_plan and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info('### verizon_bc_change_carrier_rate_plan and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        # Return success
        try:
            if succesful_iccids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "changed_data": {
                            "iccid": succesful_iccids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="iccid"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_change_carrier_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"bulk_change_id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "verizon_bc_change_carrier_rate_plan",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_change_carrier_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response



def verizon_bc_change_iccid_imei(data):
    """
     Update ICCID or IMEI for multiple subscribers using Verizon API.

    This function performs the following steps:
        - Validates required input values.
        - Establishes DB connections.
        - Fetches API credentials and carrier limits.
        - Builds and sends PATCH requests per MSISDN in parallel with retry logic.
        - Updates status in DB and logs results.
        - Handles invalid MSISDNs and triggers sync API.

    Args:
        data (dict): Input dictionary containing:
            - new_iccid (str): New ICCID to assign (if applicable).
            - new_imei (str): New IMEI to assign (if applicable).
            - bulk_change_id (str): Unique ID of the bulk change job.
            - service_provider (str): Carrier/service provider name.
            - change_type (str): Type of operation.
            - created_by (str): User initiating the request.
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant.
            - db_name (str): Database name for the tenant.
            - username (str): Username for error/audit tracking.
            - changed_data (dict): Contains serviceCharacteristic array.
            - invalid_msisdns (list): Optional invalid MSISDNs before processing.
            - request_received_at (str): Optional timestamp.

    Returns:
        dict: Result object with success flag, count, and error info
    """
    logging.info(f"Received data for ICCID/IMEI change: {data}")
    start_time = time.time()
    
    # Extract input data
    msisdns = list(data.get("msisdns", []))
    bulk_change_id = data.get("bulk_change_id")
    tenant_id = data.get("tenant_id", "")
    invalid_ids = data.get("invalid_ids", "")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name")
    db_name = data.get("db_name", "")
    invalid_msisdns = data.get("invalid_msisdns", [])
    request_received_at = data.get("request_received_at")
    tenant_database = db_name
    access_token = data.get("access_token", "")
    role_name = data.get("role", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    integration_id=data.get("integration_id", "")
    service_provider_id=data.get("service_provider_id", "")
    provider_parent_name=data.get("parent_provider_name", "")
    logs = []
    successful_msisdns=[]
    processed = 0

    # DB Connections
    try:
        database = DB(db_name, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        logging.error(f"### verizon_bc_change_iccid_imei and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
       

    # Audit log - start processing
    try:
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id, 20)
    except Exception as e:
        logging.error(f"### verizon_bc_change_iccid_imei and {tenant_name} Audit logging failed while inserting logs: {e}")

    try:
        # Get carrier config
        provider = provider_parent_name if provider_parent_name else service_provider
        logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
            provider, change_type, common_utils_database
        )
        
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        ##fetching carrier url  
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}

        # Fetch request rows
        request_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "subscriber_number","change_request"]
        )
        logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Fetched {len(request_df)} records from bulk change request table")
        
        updated_data = {}
        
        # Validate input data
        if not request_df.empty:
            change_request_json = request_df.iloc[0]["change_request"]
            if not change_request_json:
                message = "Bulk Change Request data is empty"
                response = {"flag": False, "message": message}
                error_update_data = {"errors": len(msisdns), "status": "ERROR"}
                database.update_dict(
                    "sim_management_bulk_change",
                    error_update_data,
                    and_conditions={"bulk_change_id": bulk_change_id},
                )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_change_iccid_imei",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_change_iccid_imei and {tenant_name} Audit logging failed: {e}")
                return response
                
            if isinstance(change_request_json, str):
                change_request_json = json.loads(change_request_json)
            # Handle Verizon-specific fields
            service_chars = change_request_json.get("Request", {})
            if service_chars:
                ##fetching the customer rate plan and customer rate pool details
                customer_rate_plan_id = service_chars.get("CustomerRatePlan", "")
                customer_rate_pool_id = service_chars.get("CustomerRatePool", "")
                
                if customer_rate_plan_id:
                    rate_plan_data = database.get_data(
                        "customerrateplan",
                        {"id": customer_rate_plan_id, "is_active": True},
                        ["rate_plan_name"]
                    )
                    if not rate_plan_data.empty:
                        customer_rate_plan_name = rate_plan_data["rate_plan_name"].to_list()[0]
                        updated_data['customer_rate_plan_name'] = customer_rate_plan_name
                        updated_data['customer_rate_plan_id'] = customer_rate_plan_id
                        
                if customer_rate_pool_id:
                    rate_plan_data = database.get_data(
                        "customer_rate_pool",
                        {"id": customer_rate_pool_id, "is_active": True},
                        ["name"]
                    )
                    if not rate_plan_data.empty:
                        customer_rate_pool_name = rate_plan_data["name"].to_list()[0]
                        updated_data['customer_rate_pool_name'] = customer_rate_pool_name
                        updated_data['customer_rate_pool_id'] = customer_rate_pool_id

        # Create mappings
        request_df = request_df.rename(columns={"subscriber_number": "msisdn"})
        id_map = dict(zip(request_df["msisdn"], request_df["id"]))
        msisdns_to_change_request = dict(zip(request_df["msisdn"], request_df["change_request"]))
        logging.info(f"Mapped {len(msisdns_to_change_request)} ICCIDs to change requests")

        # Carrier limits defaults
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        BATCH_SIZE = carrier_limits.get("batch_size", 50)
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests", 10)
        if PARALLEL_REQUESTS>10:
            logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        remaining = list(msisdns)
        account_data= database.get_data(
            "integration_authentication",
            {"integration_id": integration_id, "service_provider_id": service_provider_id,},
            ["oauth2_custom1","username","password"]
        )
        if not account_data.empty:
            accountname = account_data.iloc[0]["oauth2_custom1"]
            username_value=account_data.iloc[0]["username"]
            password_value=account_data.iloc[0]["password"]
        else:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Account name not found for integration ID: {integration_id}")
            accountname = None
            username_value=None
            password_value=None
        # Get Verizon access token and session ID
        logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Fetching access token and session ID")
        access_id, session_id = get_verizon_token_details(app_id, app_secret,username_value,password_value)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_change_iccid_imei and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        #constracting header
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }

        # Chunking MSISDNs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")

        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(msisdns), BATCH_SIZE):
                batch = msisdns[i:i + BATCH_SIZE]
                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Processing batch {i // BATCH_SIZE + 1} with {len(batch)} MSISDNs")
                futures = {}

                for msisdn in batch:
                    payload_str = msisdns_to_change_request.get(msisdn)

                    if not payload_str:
                        logging.warning(f"### verizon_bc_change_iccid_imei and {tenant_name} Skipping MSISDN {msisdn}: missing change_request payload")
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": id_map.get(msisdn),
                            "log_entry_description": f"Missing change_request payload for {msisdn}",
                            "request_text": "N/A",
                            "has_errors": True,
                            "response_status": "ERROR",
                            "response_text": "Missing payload",
                            "error_text": "No change_request found",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        logs.append(log)
                        continue

                    request_payload = json.loads(payload_str)
                    payload = request_payload.get("Request")
                    # Extract Verizon-specific fields
                    new_id = payload.get("NewIMEI", "")
                    old_id = payload.get("OldIMEI", "")
                    iccid_old = payload.get("OldICCID")

                    # Construct Verizon payload
                    verizon_payload = None
                    change_description = ""
                    if old_id and new_id:
                        kind = "imei"
                        change_option = "changeIMEI"
                    else:
                        kind = "iccid"
                        change_option = "changeICCID"
                        old_id = payload.get("OldICCID")
                        new_id = payload.get("NewICCID")
                        iccid_old = payload.get("OldICCID")

                    verizon_payload = {
                        "deviceIds": [{"kind": kind, "id": old_id}],
                        "deviceIdsTo": [{"kind": kind, "id": new_id}],
                        "change4gOption": change_option
                    }
                    updated_data[kind]=new_id
                    logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Processing MSISDN: {msisdn} with payload: {verizon_payload}")
                    url = carrier_api_url

                    def task(msisdn=msisdn, url=url, payload=verizon_payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        request_id = id_map.get(msisdn)
                        response_data=None

                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Attempt {attempt} - URL: {url}")
                                resp = requests.put(url, json=payload, headers=headers, timeout=30)
                                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Response Code: {resp.status_code} for MSISDN: {msisdn}")
                                
                                if 200 <= resp.status_code < 300:
                                    success = True
                                    status = "PROCESSING"
                                    result = resp.text
                                    response_data=resp.json()
                                    break
                                else:
                                    result = resp.text
                                    time.sleep(RETRY_DELAY)
                            except Exception as e:
                                result = str(e)
                                logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Attempt {attempt} failed for {msisdn}: {e}")
                                time.sleep(RETRY_DELAY)

                        # DB update
                        database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": status,"is_processed":True,"has_errors":False,"processed_date": now,"status_details":result},
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"subscriber_number": [msisdn]},
                                    )
                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": request_id,
                            "log_entry_description": f"Change {change_description} via Verizon API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": "PROCESSED" if success else "API_Failed",
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        # If successful, proceed to second API call with retries
                        RETRY_INTERVAL = 60  
                        if success:
                            # second API call to fetch device details
                            api_success = False
                            rate_plan_status = False
                            new_msisdn = None
                            status = "API_FAILED"
                            resp_status = ""      
                            fault_string = ""      
                            request_id_data = response_data.get("requestId", None)

                            if request_id_data:
                                time.sleep(RETRY_INTERVAL) # Initial wait before checking for callback
                                for attempt in range(MAX_RETRIES):
                                    callback_df = common_utils_database.get_data(
                                        "bulk_change_verizon_callback",
                                        {"request_id": request_id_data},
                                        ["fault_code", "fault_string", "status"]
                                    )

                                    if not callback_df.empty:
                                        fault_code = callback_df.iloc[0]["fault_code"]
                                        fault_string = callback_df.iloc[0]["fault_string"]
                                        resp_status = (callback_df.iloc[0]["status"] or "").strip()
                                        break   
                                    else:
                                        logging.info(
                                            f"[Retry {attempt+1}/{MAX_RETRIES}] No callback yet for request_id: {request_id_data}"
                                        )
                                        if attempt < MAX_RETRIES - 1:
                                            time.sleep(RETRY_INTERVAL)

                            #  Process after retries
                            if resp_status.lower() == "success":
                                rate_plan_status = True
                                status = "PROCESSED"
                                api_success = True
                                successful_msisdns.append(msisdn)

                                logging.info(
                                    f"### verizon_bc_change_iccid_imei and {tenant_name} "
                                    f"updated_data: {updated_data} for MSISDN: {msisdn} before updating inventory"
                                )
                                database.update_dict(
                                    "sim_management_inventory",
                                    updated_data,
                                    {"is_active": True, "msisdn": msisdn, "tenant_id": tenant_id}
                                )
                            else:
                                status = "API_FAILED"
                                api_success = False

                            # Always update request table after retries
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {
                                    "status": status,
                                    "has_errors": not api_success,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details": f"{resp_status if rate_plan_status else fault_string}"
                                },
                                and_conditions={"subscriber_number": msisdn, "bulk_change_id": bulk_change_id}
                            )
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": request_id,
                                "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                "request_text": json.dumps(payload),
                                "has_errors": not resp_status,
                                "response_status": status,
                                "response_text": resp_status if resp_status else fault_string,
                                "error_text": "",
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            
                        return msisdn

                    futures[executor.submit(task)] = msisdns

                for fut in as_completed(futures):
                    try:
                        msisdn = fut.result()
                        remaining.remove(msisdn)
                        processed += 1
                    except Exception as e:
                        logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Error processing msisdn in thread: {e}")
        if INTERVAL and i + BATCH_SIZE < len(msisdns):
            time.sleep(INTERVAL)
        # preparing the payload for history table update
        if successful_msisdns:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":successful_msisdns,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API  
            try:
                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}")  
        

        # Handle invalid MSISDNs
        if invalid_msisdns:
           for msisdn in invalid_msisdns:
                request_id = msisdns_to_change_request.get(msisdn)
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Invalid MSISDN during ICCID/IMEI change",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid msisdn - could not be processed",
                    "error_text": "Invalid identifier",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if invalid_msisdns:
            database.update_dict(
                "sim_management_bulk_change_request",
                {
                    "status": "ERROR",
                    "errors": len(invalid_msisdns),
                    "is_processed": True,
                    "has_errors": True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"
                },
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"subscriber_number": invalid_msisdns},
            )

        if logs:
            database.insert_data(logs, "sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(logs,"sim_management_bulk_change_detailed_logs")

        # Update bulk change summary
        database.update_dict(
            "sim_management_bulk_change",
            {
                "status": "PROCESSED",
                "success": processed,
                "processed_date": now
            },
            {"id": bulk_change_id}
        )

        # Trigger sync APIs to 1.0 for bulk change  tables
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {"bulk_change_id": bulk_change_id},
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        # calling sync API to update inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
            "data": {
                "access_token": access_token,
                "key_name": "verizon_bulkchange_sync",
                "path": "/bulk_change_sync_10_updated",
                "tenant_name": tenant_name,
                "bulk_change_id": bulk_change_id
            }
        }

        try:
            live_progress_percentage_tracker(database, bulk_change_id, 80) 
            logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} sync call has started")
            bulk_change_audit_action(data, common_utils_database, action="Sync To 1.0 Tables")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
        except Exception as e:
            logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}")

        try:
            if successful_msisdns:
                data["msisdns"]=successful_msisdns
                logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Exception in thread: {e}")

        # Final audit logging
        live_progress_percentage_tracker(database, bulk_change_id, 95)
        
        logging.info(f"###verizon_bc_change_iccid_imei bulk change completed in {time.time() - start_time:.2f} seconds | Processed: {processed}")
        
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "iccids": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }

        try:
            end_time = time.time()
            time_consumed = end_time - start_time 
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_change_iccid_imei",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change for {len(msisdns)} devices with bulk_change_id: {bulk_change_id}",
                "request_received_at": now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action="Auditing")

        except Exception as e:
            logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id, 100)
        
        logging.info(f"### verizon_bc_change_iccid_imei and {tenant_name} Processed {len(msisdns)} ICCIDs, {len(remaining)} remaining")
        return response

    except Exception as e:
        logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Error during bulk change processing: {str(e)}")
        error_type = str(type(e).__name__)
        error_message = f"Error during bulk change processing: {str(e)}"
        
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "msisdns": msisdns,
            "invalid_msisdns": invalid_msisdns,
            "bulk_change_id": bulk_change_id
        }
        
        error_update_data = {"errors": len(msisdns), "status": "ERROR"}
        database.update_dict(
            "sim_management_bulk_change",
            error_update_data,
            and_conditions={"bulk_change_id": bulk_change_id},
        )
        
        try:
            error_data = {
                "service_name": "verizon_bulk_change_iccid_imei",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk ICCID/IMEI change with bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": request_received_at or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
           logging.exception(f"### verizon_bc_change_iccid_imei and {tenant_name} Exception in logging error data to DB: {log_e}")
            
        return response  

 
    

def decode_password(encoded_pwd: str) -> str:
    """
    Decode the stored password. Replace with your actual decode logic.
    """
    # Example: if it was base64-encoded in the DB:
    return base64.b64decode(encoded_pwd).decode("utf-8")

def decode_token(encoded_token: str) -> str:
    """
    Decode the stored token_value. Replace with your actual decode logic.
    """
    return base64.b64decode(encoded_token).decode("utf-8")

def fetch_headers(database,tenant_id,app_id,app_secret):
    """Fetch and prepare headers for Telegence API requests.
    This function retrieves the necessary authentication details from the database,
    decodes them, and constructs the headers required for API requests.
    Args:

        database (object): Database connection or handler object.
        tenant_id (int): The tenant ID to fetch the integration authentication details.
    Returns:
        dict: Headers containing 'Authorization' and 'Ocp-Apim-Subscription-Key'.
    """
    try:
        rev_io_data_query=f'''SELECT username,password,token_value FROM public.integration_authentication
        where integration_id in (select id from integration where name='Rev.IO'
        ) and tenant_id={tenant_id}'''
        rev_io_dataframe=database.execute_query(rev_io_data_query,True)
        revio_username = rev_io_dataframe["username"].to_list()[0]
        encoded_pwd = rev_io_dataframe["password"].to_list()[0]
        encoded_token = rev_io_dataframe["token_value"].to_list()[0]
        password = decode_password(encoded_pwd)
        token_value = decode_token(encoded_token)
        # 3. Re-encode username:password into Basic
        user_pass = f"{revio_username}:{password}"
        # base64 encode
        b64 = base64.b64encode(user_pass.encode("utf-8")).decode("utf-8")
        rev_app_id = f"Basic {b64}"

        # 4. app_secret is the decoded token_value
        rev_app_secret = token_value

        headers = {
            "Authorization": rev_app_id,
            "Ocp-Apim-Subscription-Key": rev_app_secret,
        }  

        return headers
    except Exception as e:
        logging.error(f"### fetch_headers Error occurred while fetching headers: {e}")
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }  
        return headers

## Assign customer function
def verizon_bc_assign_customer(data):
    """Assign a customer to the selected devices or services.
    This function processes a list of iccids and assign a customer account with the iccids in the Verizon system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - ICCIDs (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the Verizon API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for assign customer: %s", data)
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    if iccids:
        iccids = list(set(iccids))
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    source=data.get("source","")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    provider_parent_name=data.get("parent_provider_name", "")
    parent_tenant_id=data.get('parent_tenant_id',None)
    # Initialize for log entries
    log_entries = []
    successful_iccids=[]
    rev_service_type_id=None
    service_type_id=None
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###verizon_bc_assign_customer and {tenant_name} time is {now}")

    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        logging.error(f"### verizon_bc_assign_customer and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,20)
    except Exception as e:
        logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
            logging.info(f"### verizon_bc_assign_customer and {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}


        # Fetch bulk change rows
       
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},#iccid
            ["id", "iccid", "change_request"]
        )
        # Validate input data 
       
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"bulk_change_id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_assign_customer",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
                return response
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        logging.info(f"change_request_json is {change_request_json}")
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        rev_service_type_id=change_request_json.get("ServiceTypeId","")
        if rev_service_type_id:
            service_type_data=database.get_data(
                    "rev_service_type",
                    {"service_type_id": rev_service_type_id, "is_active": True},
                    ["id"]
                )
            if not service_type_data.empty:
                service_type_id = service_type_data["id"].to_list()[0]
            else:
                service_type_id = None
        logging.info(f"### telegence_bc_create_rev_service and {tenant_name} service_type_id is {service_type_id}")
        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        generate_proration=change_request_json.get("Prorate",None)
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[])
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate_list= change_request_json.get("RateList", [])
        revpackageid=change_request_json.get("RevPackageId", None)
        site_id=change_request_json.get("SiteId", None)
        # Initialize variables for customer and rate plan details
        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
        plan_mb=None
        customer_data=pd.DataFrame()
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name","plan_mb"]
            )
            if not rate_plan_data.empty:
                rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb=rate_plan_data["plan_mb"].to_list()[0]
        if customer_rate_pool_id and customer_rate_pool_id != "No options":
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        if rev_customer or site_id:
            if rev_customer:
                # Use rev_customer if provided
                customer_data = database.get_data(
                    "customers",
                    {"customer_name": rev_customer, "is_active": True,"tenant_id": tenant_id},
                    ["id", "customer_name"]
                )
            elif site_id:
                # Fallback: use site_id as customer_name when rev_customer is absent
                customer_data = database.get_data(
                    "customers",
                    {"id": site_id, "is_active": True,"tenant_id": tenant_id},
                    ["id", "customer_name"]
                )
                if not customer_data.empty:
                    customer_name=customer_data["customer_name"].to_list()[0]
                    rev_dataframe = database.get_data(
                        "revcustomer",
                        {"customer_name": customer_name, "is_active": True,"tenant_id": tenant_id},
                        ["customer_name", "rev_customer_id","id"]
                    )
                    if not rev_dataframe.empty:
                        rev_customer = rev_dataframe["customer_name"].to_list()[0]
                        rev_customer_uuid = rev_dataframe["id"].to_list()[0]
                        rev_customer_id = rev_dataframe["rev_customer_id"].to_list()[0]

            else:
                customer_data = pd.DataFrame()
        if not customer_data.empty:
            customer_id=customer_data["id"].to_list()[0]
            customer_name=customer_data["customer_name"].to_list()[0]
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields ={}
        fields_to_update = []
        if customer_rate_plan_id and customer_rate_plan:
            update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
            fields_to_update.extend(["customer_rate_plan_id","sub_tenant_carrier_rate_plan_name","sub_tenant_carrier_rate_plan_name_id"])
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
            fields_to_update.extend(["customer_rate_pool_id"])

        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
            fields_to_update.extend(["account_number"])
        if effective_date:
            update_fields["effective_date"] = effective_date
        if plan_mb is not None:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        # if device_id:
        #     update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        if customer_id:
            fields_to_update.extend(["customer_id"])
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_request_id = dict(zip(bulk_requests.iccid, bulk_requests.id))
        iccid_to_changerequest = dict(zip(bulk_requests.iccid, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = fetch_headers(database,tenant_id,app_id,app_secret)
        logging.info(f"###verizon_bc_assign_customer and {tenant_name} Headers prepared for API call{headers}")
        # headers = {
        #     "Authorization": app_id,
        #     "Ocp-Apim-Subscription-Key": app_secret,
        # }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        # Validate iccids
        remaining = iccids.copy()
        logs = []
        successful_iccids = []
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"###verizon_bc_assign_customer and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_name"]
            ).to_dict(orient="records")
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of ICCIDs
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f"###verizon_bc_assign_customer and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"###verizon_bc_assign_customer and {tenant_name} Processing ICCID: {iccid}")
                    #task function
                    def task(iccid=iccid):
                        """ 1. If CreateRevService is True:
                            - Step 1: Call API to create RevService (POST with retries)
                            - Step 2: On success, extract RevService ID from response
                            - Step 3: Use RevService ID to create Service Product (POST)
                        
                           2. If CreateRevService is False:
                            - Skip RevService creation and directly insert into DB"""
                        logging.info(f"###verizon_bc_assign_customer and {tenant_name} task function started for ICCID: {iccid}")
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                        productid = None
                        rev_service_log=False
                        payload_str = iccid_to_changerequest.get(iccid)
                        logging.info(f"###verizon_bc_assign_customer and {tenant_name} Payload for ICCID {iccid}: {payload_str}")
                        request_payload = json.loads(payload_str)
                        service_number=request_payload.get('Number')
                        iccid_from_request=request_payload.get('ICCID')
                        #extract the create rev service flag
                        rev_service = request_payload.get("CreateRevService", False)
                        # Build payloads for all APIs
                        rev_api_payload = {
                            "customer_id": rev_customer_id,
                            "provider_id": provider_id,
                            "number2":iccid_from_request,
                            "service_type_id": rev_service_type_id,
                            "number": service_number,
                            "activated_date": activated_date,

                        }
                        product_api_payload={
                            "CustomerId": rev_customer_id,
                            "service_type_id": rev_service_type_id,
                            "number": service_number,
                            "effective_date": effective_date,
                            "activated_date": activated_date,
                            }
                        if revpackageid:
                            product_api_payload.update({"revpackageid": revpackageid})
                        else:
                            product_api_payload.update({"RevProductIdList": revproductidlist,"RateList": rate_list,"UsagePlanGroupId": usageplangroupid})
                        try:
                            if rev_service:
                                # Step 1:  First API Call to create the revservice
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        logging.info(f"###verizon_bc_assign_customer and {tenant_name} Attempt {attempt} - URL: {url}, Payload: {rev_api_payload}")
                                        
                                        resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                        success = 200 <= resp.status_code < 300
                                        result = resp.text
                                        logging.info(f"###verizon_bc_assign_customer and {tenant_name} Response Code: {resp.status_code}")
                                        logging.info(f"###verizon_bc_assign_customer and {tenant_name} Response Text: {result}")
                                        status = "PROCESSED" if success else "API_Failed"
                                        if success:
                                            try:
                                                response_data = resp.json()
                                                id = response_data.get("id")
                                                successful_iccids.append(iccid)
                                            except Exception:
                                                id = None
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Exception in API call: {e}")
                                        time.sleep(RETRY_DELAY) 
                                if success:
                                    update_data = {
                                        "status": status,
                                        "has_errors": False,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result    
                                    }
                                else:
                                    update_data = {
                                        "status": status,
                                        "has_errors": True,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details":result
                                    }  
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"iccid": [iccid]},
                                    )             
                                if success:  
                                    #inserting values in rev service 
                                    rev_data={
                                    "rev_customer_id":rev_customer_uuid,
                                    "number":service_number,
                                    "rev_service_id":id,
                                    "activated_date":activated_date,
                                    "is_active":True,
                                    "integration_authentication_id":integration_authentication_id,
                                    "rev_provider_id":rev_provider_id,
                                    "rev_service_type_id":service_type_id
                                    }
                                    rev_insert_id=database.insert_data(rev_data,"rev_service")
                                    if rev_insert_id:
                                        update_fields["rev_service_id"]=rev_insert_id
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} update_fields: {update_fields}")
                                    #updating inventory table
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                # Inserting logs based on api result
                                rev_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Rev.io API",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": status == "PROCESSED",
                                        "response_status": "PROCESSED" if success else "API_Failed",
                                        "response_text": result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                database.insert_data(rev_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(rev_log,"sim_management_bulk_change_detailed_logs") 
                                logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for rev service creation: {rev_log}")
                                #inserting logs after updating inventory table
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                                # Step 2:  Second API Call
                                logging.info(f"### verizon_bc_assign_customer and {tenant_name} Creating Rev.io Service Product for ICCID: {iccid} with ID: {id}")
                                if id:
                                    # Multiple API calls for each product & rate
                                    for product_id, rate in zip(revproductidlist, rate_list):
                                        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Creating product_id {product_id} with rate {rate} for service_id {id}")
                                        if not product_id:
                                            continue  # Skip invalid product IDs

                                        # Build payload for each product
                                        product_api_payload_single = {
                                            "CustomerId": rev_customer_id,
                                            "service_type_id": rev_service_type_id,
                                            "number": service_number,
                                            "effective_date": effective_date,
                                            "activated_date": activated_date,
                                            "product_id": product_id,
                                            "rate": rate,
                                            "service_id": id
                                        }
                                        if generate_proration:
                                            product_api_payload_single["generate_proration"] = str(generate_proration).lower()  # "true" or "false"

                                        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Product API Payload: {product_api_payload_single}, URL: {alternative_api_url}")

                                        for attempt in range(1, MAX_RETRIES + 1):
                                            try:
                                                get_resp = requests.post(alternative_api_url, json=product_api_payload_single, headers=headers, timeout=60)
                                                api_success = 200 <= get_resp.status_code < 300
                                                api_result = get_resp.text
                                                logging.info(f"### Response Code: {get_resp.status_code}")
                                                logging.info(f"### Response Text: {api_result}")

                                                if api_success:
                                                    response_data = get_resp.json()
                                                    productid = response_data.get("id")
                                                    break
                                            except Exception as e:
                                                logging.info(f"API exception on attempt {attempt}: {str(e)}")
                                                time.sleep(RETRY_DELAY)

                                        if api_success:
                                            product_record = {
                                                "service_product_id": productid,
                                                "customer_id": rev_customer_id,
                                                "service_id": id,
                                                "description": description,
                                                "activated_date": activated_date,
                                                "status": "ACTIVE",
                                                "created_by": created_by,
                                                "created_date": now,
                                                "is_active": True,
                                                "is_deleted": False,
                                                "integration_authentication_id": integration_authentication_id,
                                                "product_id": product_id,
                                                "rate": rate
                                            }

                                            database.insert_data(product_record, "rev_service_product")
                                            logging.info(f"Inserted rev_service_product with product_id {product_id}, rate {rate} for tenant {tenant_name}")
                                        #constracting logs 
                                        log = {
                                                "bulk_change_id": bulk_change_id,
                                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                                "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                                "request_text": json.dumps(product_api_payload_single),
                                                "has_errors": status == "API_FAILED",
                                                "response_status": "PROCESSED" if api_success else "API_Failed",
                                                "response_text": api_result,
                                                "error_text": "" if status == "PROCESSED" else result,
                                                "processed_date": now,
                                                "processed_by": created_by,
                                                "created_by": created_by,
                                                "created_date": now,
                                                "is_deleted": False,
                                                "is_active": True
                                            }
                        
                                        if log:
                                            database.insert_data(log,"sim_management_bulk_change_log")
                                            #  insert the log entries into detailed logs table
                                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                                                                        
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for rev service product creation: {product_data} and update fields are {update_fields}")
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                    try:
                                        # Preparing fields for sub-tenant update
                                        sub_tenant_update = {}
                                        if "customer_rate_plan_name" in update_fields and "customer_rate_plan_id" in update_fields and not parent_tenant_id:
                                            sub_tenant_update["sub_tenant_carrier_rate_plan_name"] = update_fields["customer_rate_plan_name"]
                                            sub_tenant_update["sub_tenant_carrier_rate_plan_name_id"] = update_fields["customer_rate_plan_id"]
                                            database.update_dict(
                                                "sim_management_inventory",
                                                sub_tenant_update,
                                                and_conditions={"is_active": True},
                                                in_conditions={"iccid": [iccid]},
                                            )
                                    except Exception as e:
                                        logging.exception("Error updating sub-tenant rate plan fields for SIM management inventory")
                                    
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for product creation: {log}") 
                                    if rev_service_log:
                                        data_log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service: Update AMOP",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors":False,
                                            "response_status": "PROCESSED",
                                            "response_text": "OK" ,
                                            "error_text": "",
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                                        database.insert_data(data_log,"sim_management_bulk_change_log")
                                        #  insert the log entries into detailed logs table
                                        database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                #if createrevservice flag false then directly updating values into table
                                rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                try:
                                    # Preparing fields for sub-tenant update
                                    sub_tenant_update = {}
                                    if "customer_rate_plan_name" in update_fields and "customer_rate_plan_id" in update_fields and not parent_tenant_id:
                                        sub_tenant_update["sub_tenant_carrier_rate_plan_name"] = update_fields["customer_rate_plan_name"]
                                        sub_tenant_update["sub_tenant_carrier_rate_plan_name_id"] = update_fields["customer_rate_plan_id"]
                                        database.update_dict(
                                            "sim_management_inventory",
                                            sub_tenant_update,
                                            and_conditions={"is_active": True},
                                            in_conditions={"iccid": [iccid]},
                                        )
                                except Exception as e:
                                    logging.exception("Error updating sub-tenant rate plan fields for SIM management inventory")
                                successful_iccids.append(iccid)
                                database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK" },
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": [iccid]},
                                    )

                                #constracting logs
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK",
                                        "error_text": "" ,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    #  insert the log entries into detailed logs table
                                    database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserting log for inventory update: {data_log}")

                        except Exception as e:
                            logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Unexpected error for ICCID {iccid}: {str(e)}")
                        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Completed processing ICCID: {iccid}, Success: {success}, ID: {id}, Product ID: {productid}")
                        return iccid
                    futures[executor.submit(task)] = iccid
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.error(f"### verizon_bc_assign_customer and {tenant_name} Error processing iccid: {e}")
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
       
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        #logging.info("Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        # Check for any invalid ICCIDs
        if successful_iccids:
                url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
                payload_history_table = {
                                    "data": {
                                            "tenant_name": tenant_name,
                                            "username":username,
                                            "path": "/update_device_history_tables",
                                            "change_type":change_type,
                                            "iccids": successful_iccids,
                                            "msisdns":[],
                                            "service_provider":service_provider,
                                            "Partner": tenant_name,
                                            "access_token": access_token,
                                            "db_name": tenant_database,
                                            "fields_updated": fields_to_update,
                                            }
                                        }
                if effective_date:
                    payload_history_table["data"]["effective_date"] = effective_date
                # Call the history table update API  
                try:
                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} sync call has started for history table")
                    threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
                except Exception as e:
                    logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Exception in thread: {e}") 

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": successful_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Assign Customer",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### verizon_bc_assign_customer and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Exception in action history thread: {e}") 
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            logging.info(f"### verizon_bc_assign_customer and {tenant_name} Invalid iccids found: {invalid_iccids}")
            # Log invalid IDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Assign customer ",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR","is_processed":True,"has_errors":True,"processed_date": now,"status_details":"Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids},
            )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f"### verizon_bc_assign_customer and {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #below syncs url is used to sync the 1.0 inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### verizon_bc_assign_customer and {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### verizon_bc_assign_customer and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        try:
            if successful_iccids:
                data["iccids"]=successful_iccids
                logging.info(f"### verizon_bc_assign_customer and {tenant_name} sync call for billing  has started")
                billing_integrtion_new(data)
        except Exception as e:
            logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Exception in thread: {e}")
        ##auditing the sync completion
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
       
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "verizon_bc_assign_customer",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Assign customer for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.warning(f"### verizon_bc_assign_customer and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Error during bulk change processing: {e}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_msisdns": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "verizon_bc_assign_customer",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_assign_customer and {tenant_name} Logging error to DB failed: {e}")
 
        return response
       

    
##Update Line Sync function
def verizon_bc_line_sync(data):
    """
    Sync SIM inventory and bulk change requests with the verizon API.

    This function processes a list of ICCIDs for a given bulk change operation
    and updates their details by calling the carrier's verizon API. It includes
    retry logic, database updates, inventory synchronization, error handling,
    and audit logging.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains request payload and UpdateStatus information.
            - service_provider (str): Name of the carrier/service provider.
            - change_type (str): Type of update (e.g., SIM/device status).
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant (for logs/audit).
            - db_name (str): Tenant-specific database name.
            - service_provider_id (str): Identifier for the service provider.
            - invalid_iccids (list): ICCIDs that failed validation before processing.

    Returns:
        dict: Response object summarizing the processing result:
            - flag (bool): True if operation completed without unhandled errors.
            - message (str): Summary of result (success or failure).
            - processed (int): Number of ICCIDs successfully processed.
            - remaining (int): Number of ICCIDs not processed.
            - iccids (list): List of ICCIDs attempted.
            - invalid_iccids (list): ICCIDs skipped due to invalid input.
            - bulk_change_id (str): Bulk change request ID.
            - error (str, optional): Error message if processing failed.
    """
    logging.info(f"### Received data for line sync: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source = data.get("source", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
    integration_id=data.get("integration_id", "")

   
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### verizon_bc_line_sync and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### verizon_bc_line_sync and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    
    tenant_database = data.get("db_name", "")
    access_token = data.get("access_token", "")
    role_name = data.get("role_name", "")
    
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        logging.error(f"### verizon_bc_line_sync and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id, 20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### verizon_bc_line_sync and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### verizon_bc_line_sync and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid"]
        ).rename(columns={"iccid": "iccid"})
        
        if bulk_requests_df.empty:
            message = f"Bulk Change Request data is empty"
            response = {"flag": False, "message": message}
            error_update_data = {"errors": len(iccids), "status": "ERROR"}
            database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
            )
            
            # Attempt to audit the action
            try:
                end_time = time.time()
                time_consumed = end_time - start_time
                time_consumed = int(round(time_consumed))
                audit_data_user_actions = {
                    "service_name": "verizon_bc_line_sync",
                    "created_by": username,
                    "status": json.dumps(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": message,
                    "request_received_at": now,
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### verizon_bc_line_sync and {tenant_name} Audit logging failed: {e}")
            return response
        
        # Fetch existing inventory data
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": iccids, "tenant_id": tenant_id}
        ).to_dict(orient="records")

        # CREATE A SET OF EXISTING ICCIDS
        existing_iccids = {item["iccid"] for item in old_inventory_data}
        new_iccids = [iccid for iccid in iccids if iccid not in existing_iccids]
        existing_iccids_list = [iccid for iccid in iccids if iccid in existing_iccids]

        logging.info(f"### verizon_bc_line_sync and {tenant_name} Found {len(existing_iccids_list)} existing ICCIDs and {len(new_iccids)} new ICCIDs")

        # Fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        
        if PARALLEL_REQUESTS > 10:
            logging.info(f"### verizon_bc_line_sync and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            PARALLEL_REQUESTS = 10
        
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        changed_data = []
        remaining = list(iccids)
        
        # Get account credentials
        account_data = database.get_data(
            "integration_authentication",
            {"integration_id": integration_id, "service_provider_id": service_provider_id},
            ["oauth2_custom1", "username", "password"]
        )
        
        if not account_data.empty:
            accountname = account_data.iloc[0]["oauth2_custom1"]
            username_value = account_data.iloc[0]["username"]
            password_value = account_data.iloc[0]["password"]
        else:
            logging.error(f"### verizon_bc_line_sync and {tenant_name} Account name not found for integration ID: {integration_id}")
            accountname = None
            username_value = None
            password_value = None
        
        # Get Verizon authentication tokens
        access_id, session_id = get_verizon_token_details(app_id, app_secret, username_value, password_value)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_line_sync and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        
        # Construct headers
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }
        
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}"
                    payload = {
                        "deviceId": {
                            "id": iccid,
                            "kind": "iccid"
                        }
                    }

                    def task(iccid=iccid, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        updated = None
                        inserted = None
                        is_new_iccid = iccid in new_iccids  # Check if this is a new ICCID
                        
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### verizon_bc_line_sync and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                
                                resp = requests.post(url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### verizon_bc_line_sync and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### verizon_bc_line_sync and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                            "processed_date": now, "status_details": resp.text if success else result},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            api_data = resp.json()

                            # Extract required fields from API response
                            device = api_data.get("devices", [])[0] if api_data.get("devices") else {}

                            billing_cycle_end_date = device.get("billingCycleEndDate")
                            sim_status = None
                            service_plan = None
                            imei = iccid_val = msisdn_val = None

                            # Extract sim_status from carrierInformations
                            carrier_info = device.get("carrierInformations", [])
                            if carrier_info:
                                sim_status = carrier_info[0].get("state")
                                service_plan = carrier_info[0].get("servicePlan")

                            # Extract imei & iccid from deviceIds
                            for dev_id in device.get("deviceIds", []):
                                kind = dev_id.get("kind")
                                if dev_id.get("kind") == "imei":
                                    imei = dev_id.get("id")
                                elif dev_id.get("kind") == "iccId":
                                    iccid_val = dev_id.get("id")
                                elif kind == "msisdn":
                                    msisdn_val = dev_id.get("id")
                            
                            if is_new_iccid:
                                # INSERT new ICCID - create full record
                                try:
                                    to_insert = {
                                        "iccid": iccid_val or iccid,
                                        "msisdn": msisdn_val,
                                        "imei": imei,
                                        "sim_status": sim_status,
                                        "carrier_rate_plan_name": service_plan,
                                        "billing_cycle_end_date": billing_cycle_end_date,
                                        "modified_by": username,
                                        "tenant_id": tenant_id,
                                        "created_by": username,
                                        "created_date": now,
                                        "is_active": True,
                                        "is_deleted": False,
                                        "tenant_is_active": True,
                                        "tenant_is_deleted": False,
                                        "service_provider_is_active": True,
                                        "service_provider_display_name": service_provider,
                                        "service_provider_id": service_provider_id,
                                        "account_number": accountname  # Use accountname from integration
                                    }
                                    
                                    inserted_id = database.insert_data(to_insert, "sim_management_inventory")
                                    if inserted_id:
                                        inserted = True
                                        logging.info(f"### verizon_bc_line_sync and {tenant_name} Inserted new ICCID: {iccid} with ID: {inserted_id}")
                                        
                                        # For new ICCIDs, all fields are considered as changes
                                        field_changes = {}
                                        for field, new_value in to_insert.items():
                                            if field not in ["id", "created_date", "modified_by", "tenant_id", "created_by", "is_active", "is_deleted"]:
                                                field_changes[field] = {
                                                    "old_value": None,
                                                    "new_value": new_value
                                                }
                                        
                                        if field_changes:
                                            changed_data.append({
                                                "field_changes": field_changes, 
                                                "id": inserted_id,
                                                "iccid": iccid_val or iccid,
                                                "msisdn": msisdn_val,
                                                "old_record": {}  # Empty for new ICCID
                                            })
                                except Exception as insert_error:
                                    logging.error(f"### verizon_bc_line_sync and {tenant_name} Failed to insert new ICCID {iccid}: {insert_error}")
                                    inserted = False
                                    
                            else:
                                # UPDATE existing ICCID
                                # Use iccid_val if available, otherwise use original iccid
                                lookup_iccid = iccid_val or iccid
                                old_record = next((item for item in old_inventory_data if item.get("iccid") == lookup_iccid), {})
                                
                                if old_record:
                                    # Prepare update values
                                    to_update = {
                                        "iccid": iccid_val or iccid,
                                        "msisdn": msisdn_val,
                                        "imei": imei,
                                        "sim_status": sim_status,
                                        "carrier_rate_plan_name": service_plan,
                                        "billing_cycle_end_date": billing_cycle_end_date,
                                        "modified_by": username
                                    }
                                    
                                    exclude_fields = ["iccid"]  
                                    keys_to_check = [key for key in to_update.keys() if key not in exclude_fields]
                                    to_update, field_changes = build_detailed_update_dict(to_update, old_record, keys_to_check)
                                    
                                    if to_update:
                                        # Include the ID for update
                                        # to_update["id"] = old_record["id"]
                                        to_update["modified_by"] = username
                                        updated = database.update_dict(
                                            "sim_management_inventory",
                                            values=to_update,
                                            and_conditions={"id": old_record["id"]},
                                        )
                                    
                                    # Store field changes for batch processing
                                    if field_changes:
                                        changed_data.append({
                                            "field_changes": field_changes, 
                                            "id": old_record["id"],
                                            "iccid": iccid_val or iccid,
                                            "msisdn": msisdn_val,
                                            "old_record": old_record  # Add the old data for history
                                        })

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update verizon Subscriber: verizon API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            # Insert the log entries into detailed logs table
                            database.insert_data(log, "sim_management_bulk_change_detailed_logs")
                            
                        # Prepare inventory log entry based on operation type
                        inventory_success = updated if not is_new_iccid else inserted
                        operation_type = "Inserted" if is_new_iccid else "Updated"
                        
                        inventory_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": f"{operation_type} Inventory Record",
                            "request_text": None,
                            "has_errors": not inventory_success,
                            "response_status": "PROCESSED" if inventory_success else "ERROR",
                            "response_text": f"Inventory {operation_type.lower()} successfully" if inventory_success else f"Inventory {operation_type.lower()} failed",
                            "error_text": "" if inventory_success else f"Inventory {operation_type.lower()} failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }

                        if inventory_log:
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")
                            # Insert the log entries into detailed logs table
                            database.insert_data(inventory_log, "sim_management_bulk_change_detailed_logs")
                            
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### verizon_bc_line_sync and {tenant_name} Error processing ICCID: {e}")

                if INTERVAL and i + BATCH_SIZE < len(iccids):
                    time.sleep(INTERVAL)
        
        # Handle and log invalid ICCIDs
        # Prepare the payload for history table
        if successfull_ids:
            url_history_table = os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                "data": {
                    "tenant_name": tenant_name,
                    "username": username,
                    "path": "/update_device_history_tables",
                    "change_type": change_type,
                    "iccids": successfull_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                }
            }
            # API call to update the history table
            try:
                logging.info(f"### verizon_bc_line_sync and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_line_sync and {tenant_name} Exception in thread: {e}")

        if source == "Inventory" and changed_data:
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            
            # Use json.dumps with default=str for the entire payload
            action_history_payload = json.loads(json.dumps({
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": successfull_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Line Sync",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_data": changed_data
                }
            }, default=str))
            # API call to update action history
            try:
                logging.info(f"### verizon_bc_line_sync and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_line_sync and {tenant_name} Exception in action history thread: {e}")
                
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update verizon Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs, "sim_management_bulk_change_log")
            # Insert the log entries into detailed logs table
            database.insert_data(logs, "sim_management_bulk_change_detailed_logs")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        # Sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
            "data": {
                "access_token": access_token,
                "data": {
                    "bulk_change_id": bulk_change_id
                },
                "db_name": tenant_database,
                "is_update": True,
                "module_name": "Bulk Change",
                "Partner": tenant_name,
                "path": "/update_bulk_change_tables_10",
                "request_received_at": now,
                "role_name": role_name,
                "tenant_name": tenant_name,
                "username": username
            }
        }
        
        # Sync API to update the inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
            "data": {
                "access_token": access_token,
                "key_name": "verizon_bulkchange_sync",
                "path": "/bulk_change_sync_10_updated",
                "tenant_name": tenant_name,
                "bulk_change_id": bulk_change_id
            }
        }
        
        try:
            logging.info(f"### verizon_bc_line_sync and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id, 80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### verizon_bc_line_sync and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### verizon_bc_line_sync and {tenant_name} Exception in thread: {e}")
        
        # Return success
        logging.info(f"### verizon_bc_line_sync and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        
        # Prepare response
        response = {
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": f"Bulk change request processed successfully. {len(new_iccids)} new ICCIDs inserted, {len(existing_iccids_list)} existing ICCIDs updated.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id,
            "new_iccids_inserted": len(new_iccids),
            "existing_iccids_updated": len(existing_iccids_list)
        }
       
        live_progress_percentage_tracker(database, bulk_change_id, 95)
        
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_line_sync",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for line sync. {len(new_iccids)} new ICCIDs inserted, {len(existing_iccids_list)} existing ICCIDs updated. Bulk Change ID: {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            
            # Auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### verizon_bc_line_sync and {tenant_name} Audit logging failed: {e}")
        
        # Final auditing the success log
        bulk_change_audit_action(
            data, common_utils_database,
            action=f"Bulk Change Process Completed"
        )
        live_progress_percentage_tracker(database, bulk_change_id, 100)
        
        # Prepare success response
        logging.info(f"### verizon_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### verizon_bc_line_sync and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data = {"errors": len(remaining), "status": "ERROR", "status_details": "Something went wrong while processing!"}
        
        database.update_dict(
            "sim_management_bulk_change",
            error_update_data,
            and_conditions={"id": bulk_change_id},
        )
        
        # Prepare error response
        try:
            error_data = {
                "service_name": "verizon_bc_line_sync",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### verizon_bc_line_sync and {tenant_name} Exception in logging error data to DB: {log_e}")
        
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response   

# ##Edit username or cost center function
def verizon_bc_edit_username_cost_center(data):
    """
    Edits the username or cost center associated with devices in bulk.
    
    This function processes a bulk change request to update username and/or cost center
    information for multiple devices. It handles both devices with and without Rev.io
    service IDs, making appropriate API calls for Rev.io integrated devices and direct
    database updates for others.
    
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs to process
            - bulk_change_id (str): ID of the bulk change request
            - created_by (str): User who initiated the request  
            - service_provider (str): Service provider name
            - service_provider_id (str): Service provider identifier
            - change_type (str): Type of change being made
            - tenant_id (str): Tenant identifier
            - invalid_iccids (list): List of invalid ICCIDs that cannot be processed

    Returns:
        dict: Response object with keys:
            - flag (bool): Indicates success or failure of the bulk change
            - processed (int): Number of successfully processed records
            - remaining (int): Number of records remaining to process
            - message (str): Human-readable status message
            - iccids (list): Original list of ICCIDs processed
            - invalid_iccids (list): List of invalid ICCIDs encountered
            - bulk_change_id (str): ID of the bulk change operation
    """

    logging.info(f"### Recevied data for verizon_bc_edit_username_cost_center :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    service_provider_id = data.get("service_provider_id", "")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    username1= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    provider_parent_name=data.get("parent_provider_name", "")
    # Validate required fields
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### verizon_bc_edit_username_cost_center and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### verizon_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            provider = provider_parent_name if provider_parent_name else service_provider
            logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request","subscriber_number"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                ##update errors
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_edit_username_cost_center",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### verizon_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,20)
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
           username=change_request_json.get("ContactName", "")
           cost_center=change_request_json.get("CostCenter1", "") 
        bulk_requests_df = bulk_requests_df.rename(columns={"subscriber_number": "msisdn"})
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        msisdn_to_request_id = dict(zip(bulk_requests_df.msisdn, bulk_requests_df.id))

        msisdns = bulk_requests_df["msisdn"].tolist()
        ## Prepare headers for API call
        headers = fetch_headers(database, tenant_id, app_id, app_secret)
        headers["Content-Type"] = "application/json-patch+json"
        logging.info(f"### pondiot_bc_edit_username_cost_center and {tenant_name} Final headers: {headers}")
        # headers = {
        #     "Authorization": app_id,
        #     "Ocp-Apim-Subscription-Key": app_secret,
        #     "Content-Type": "application/json-patch+json"
        # }
        
        # Prepare an update dict 
        rev_data=pd.DataFrame()
        revid=None
        update_fields = {}
        successfull_iccids = []
        if username:
           update_fields["username"] = username
        if cost_center:
            update_fields["cost_center"]=cost_center
        # Validate MSISDNs
        rev_data = database.get_data(
                            "rev_service",
                            {"number": iccids, "is_active": True},
                            ["number","rev_service_id"]
                          )
        #rev_series = rev_data.set_index("number")["rev_service_id"]
        # Align column name for merging
        rev_data = rev_data.rename(columns={"number": "iccid"}).drop_duplicates(subset=["iccid"], keep="last")
        #  Merge msisdns with rev_service
        df = bulk_requests_df[["iccid"]].merge(rev_data, on="iccid", how="left")
        with_revid = df[df["rev_service_id"].notnull()]
        without_revid = df[df["rev_service_id"].isnull()]
        rev_iccids=with_revid["iccid"].tolist()
        remaining = list(rev_iccids)        
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### verizon_bc_edit_username_cost_center and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","username","cost_center"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")
        # costcenter_labels = ["CostCenter1", "CostCenter2", "CostCenter3"]
        rev_map = dict(zip(with_revid["iccid"], with_revid["rev_service_id"]))
        nonrev_iccids = without_revid["iccid"].tolist()
        if nonrev_iccids:
            # 1. Bulk update sim_management_inventory (all missing iccids in one query)
            rev_service_log = database.update_dict(
                "sim_management_inventory",
                update_fields,
                and_conditions={"is_active": True, "service_provider_id": service_provider_id},
                in_conditions={"iccid": nonrev_iccids}  # bulk update
            )
            successfull_iccids.extend(nonrev_iccids)

            # 2. Bulk update sim_management_bulk_change_request
            database.update_dict(
                "sim_management_bulk_change_request",
                {
                    "status": "PROCESSED",
                    "is_processed": True,
                    "has_errors": False,
                    "processed_date": now,
                    "status_details":"OK",
                }, 
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": nonrev_iccids},
            )

            # 3. Loop only for logs
            data_log=[]
            if rev_service_log:
                for iccid in nonrev_iccids:
                    data_log.append( {
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update AMOP",
                        "request_text": "Edit Username/Cost Center processed",
                        "has_errors": False,
                        "response_status": "PROCESSED",
                        "response_text": "OK",
                        "error_text": "",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True,
                    })
                database.insert_data(data_log, "sim_management_bulk_change_log")
                #  insert the log entries into detailed logs table
                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
            else:
                for iccid in nonrev_iccids:
                    data_log.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                        "log_entry_description": "Update AMOP",
                        "request_text": "Edit Username/Cost Center processed",
                        "has_errors": True,
                        "response_status": "ERROR",
                        "response_text": "Failed to update inventory",
                        "error_text": "",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True,
                    })
                database.insert_data(data_log, "sim_management_bulk_change_log")
                #  insert the log entries into detailed logs table
                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
        
            logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
        # Chunking ICCIDs and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(rev_iccids), batch_size):
                # Create a batch of ICCIDs
                batch = rev_iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each ICCID in the batch
                logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    # Prepare the URL and payload for the API call
                    
                    revid = rev_map.get(iccid)
                    if revid is not None:
                        revid = int(float(revid))
                        url = f"{carrier_api_url}/{revid}"
                    payload = []
                    def task(iccid=iccid, url=url, payload=payload):  
                        success = False
                        result = ""
                        status = "API_FAILED"
                        username_index = None
                        costcenter_index = None
                        
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.get(
                                    url, headers=headers, timeout=60)
                                logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Response Text: {result}")
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    response_data = resp.json()
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### verizon_bc_edit_username_cost_center and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)
                        if success:
                            label_to_index = {f["label"]: i for i, f in enumerate(response_data["fields"])}
                            username_index = label_to_index.get("User Name")
                            #costcenter_index = next((label_to_index[label] for label in costcenter_labels if label in label_to_index), None)
                            costcenter_index = [
                                    index for label, index in label_to_index.items() if label.startswith("CostCenter")
                                ]
                            logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Username index: {username_index}, Cost Center index: {costcenter_index} for ICCID: {iccid}")
                                
                        #update the request status
                        if username_index  or costcenter_index:
                            if username_index:
                                payload.append({
                                    "op": "replace",
                                    "path": f"/fields/{username_index}/value",
                                    "value": username
                                })

                            if costcenter_index:
                                payload.append({
                                    "op": "replace",
                                    "path": f"/fields/{costcenter_index}/value",
                                    "value": cost_center
                                })

                            logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} API Payload: {payload}, URL: {url}")

                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    get_resp = requests.patch(url,json=payload, headers=headers, timeout=60)
                                    api_success = 200 <= get_resp.status_code < 300
                                    api_result = get_resp.text
                                    logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Response Code: {get_resp.status_code}")
                                    logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Response Text: {api_result}")
                                    status = "PROCESSED" if api_success else "API_FAILED"
                                    
                                    if api_success:
                                        response_data = get_resp.json()
                                        successfull_iccids.append(iccid)
                                    
                                        break
                                except Exception as e:
                                    result = str(e)
                                    status = "API_EXCEPTION"
                                    time.sleep(RETRY_DELAY)

                            if api_success:
                                update_data = {
                                    "status": status,
                                    "has_errors": False,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":" Edit Username/Cost Center via verizon API" 
                                }
                            else:
                                update_data = {
                                    "status": status,
                                    "has_errors": True,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details":"Edit Username/Cost Center via verizon API"
                                }  
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                update_data,
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"iccid":[iccid]},
                                )             
                                #inserting values into revservice product table 
                            rev_service_log=database.update_dict(
                                "sim_management_inventory",update_fields,
                                and_conditions={"service_provider_id": service_provider_id,"is_active": True},
                                in_conditions={"iccid": [iccid]}
                            )
                            #constracting logs 
                            log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Edit Username/Cost Center via verizon API",
                                    "request_text": json.dumps(payload),
                                    "has_errors": status == "API_FAILED",
                                    "response_status": "PROCESSED" if api_success else "API_Failed",
                                    "response_text": api_result,
                                    "error_text": "" if status == "PROCESSED" else result,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
            
                            if log:
                                database.insert_data(log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                            logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Inserting log for Edit Username/Cost Center: {log}") 
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Update AMOP",
                                    "request_text": json.dumps(payload),
                                    "has_errors":False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK" ,
                                    "error_text": "",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        else:
                            rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"service_provider_id": service_provider_id,"is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                            successfull_iccids.append(iccid)
                                
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details":"OK"},
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"iccid":[iccid]},
                                )

                                #constracting logs
                            if rev_service_log:
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Edit Username/Cost Center via verizon API",
                                    "request_text": "Update AMOP",
                                    "has_errors": False,
                                    "response_status": "PROCESSED",
                                    "response_text": "OK",
                                    "error_text": "" ,
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(data_log,"sim_management_bulk_change_detailed_logs")
                                logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Inserting log for inventory update: {data_log}")
                        return iccid


                    # Submit the task to the executor
                    logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Submitting task for ICCID: {iccid}")
                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### verizon_bc_edit_username_cost_center and {tenant_name} Error processing ICCID: {e}")

              
        if interval and i + batch_size < len(rev_iccids):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Processed {len(iccids) - len(remaining)} ICCIDS, {len(remaining)} remaining")
        ## Handle invalid MSISDNs
        #api call to upadte the history tables
        if successfull_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": [],
                                        "msisdns":successfull_iccids,
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the API to update device history tables
            try:
                logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_edit_username_cost_center and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username1,
                        "path": "/sim_management_action_history_update",
                        "iccids": successfull_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Edit Username/Cost Center",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "username" if username else "cost_center",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### verizon_bc_edit_username_cost_center and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": f"Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"verizon_bc_edit_username_cost_center and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread 
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #suny url to update inventory tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### verizon_bc_edit_username_cost_center and {tenant_name} sync call has started')
            
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()

            logging.info(f'### verizon_bc_edit_username_cost_center and {tenant_name} sync call has ended')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### verizon_bc_edit_username_cost_center and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_edit_username_cost_center and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            if successfull_iccids:
                payload_data = {
                    "db_name": tenant_database,
                    "target_db": "",
                    "username": username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "sessionID":"" ,
                    "request_received_at": now,
                    "access_token": access_token,
                    "source_db": None,
                    "role_name": role_name,
                    "bulk_change_id": bulk_change_id,
                    "provider_parent_name": provider_parent_name if provider_parent_name else service_provider,
                    "changed_data": {
                            "msisdn": successfull_iccids,       
                            "change_event_type": change_type
                    },
                    "change_event_type": change_type,  
                    "target_details": {}
                }
                primary_key="msisdn"
                result=update_for_partner_to_provider(payload_data,primary_key)
                logging.info(f"### telegence_bc_change_carrier_rate_plan and {tenant_name} Notifying Partner and Provider completed with result: {result}")
        except Exception as e:
            logging.exception(f"### telegence_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_edit_username_cost_center",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                    data, common_utils_database,
                    action=f"Auditing"
                )
        except Exception as e:
            logging.exception(f"### verizon_bc_edit_username_cost_center and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### verizon_bc_edit_username_cost_center and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "Bulk Change Processor",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_edit_username_cost_center and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
   
    
## Change Carrier Rate Plan function private_network_ip
def verizon_bc_private_network_ip(data):
    """
    Change Private Network IP Address for Verizon IoT Devices.

    This function processes bulk change requests to update the private network IP address 
    for Verizon IoT devices. It interacts with the Verizon Carrier API, handles retries, 
    logs all actions, updates the inventory and bulk change tables, and performs synchronization 
    with 1.0 and module management systems. The function also supports progress tracking, 
    audit logging, and error handling for invalid ICCIDs or failed API calls.
    
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - created_by (str): Username of the user who initiated the request.
            - service_provider (str): Name of the carrier (Verizon IoT in this case).
            - change_type (str): Type of bulk change being performed (Private Network IP Change).
            - tenant_id (str): Unique identifier of the tenant.
            - tenant_name (str): Name of the tenant.

    Returns:
        dict: A dictionary containing the result of the bulk change operation with the following keys:
            - flag (bool): True if processing was successful, False otherwise.
            - message (str): Summary of the operation result.
    """
    logging.info(f"### verizon_bc_private_network_ip Recevied data :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    integration_id=data.get("integration_id", "")
    service_provider_id = data.get("service_provider_id", "")
    iccid_ip_map=data.get("iccid_ip_map",{})
    # Initialize for log entries
    log_entries = []
    succesful_iccids=[]
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### verizon_bc_private_network_ip and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### verizon_bc_private_network_ip and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

    except Exception as e:
        return {"flag": False, "message": f"DB connection failed: {e}"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### verizon_bc_private_network_ip and {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            return {"flag": False, "message": f"Carrier API lookup failed: {e}"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                live_progress_percentage_tracker(database, bulk_change_id,100)
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_bc_private_network_ip",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###verizon_bc_private_network_ip and {tenant_name} Audit logging failed: {e}")
                return response
            live_progress_percentage_tracker(database, bulk_change_id,20)


        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)

        #ip_address= change_request_json.get("changedData",{}).get("ipAddress","")
        
        
        #account_number = change_request_json.get("account_number","")
        account_data= database.get_data(
            "integration_authentication",
            {"integration_id": integration_id, "service_provider_id": service_provider_id,},
            ["oauth2_custom1","username","password"]
        )
        if not account_data.empty:
            accountname = account_data.iloc[0]["oauth2_custom1"]
            username_value=account_data.iloc[0]["username"]
            password_value=account_data.iloc[0]["password"]
        else:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Account name not found for integration ID: {integration_id}")
            accountname = None
            username_value=None
            password_value=None

           

        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        remaining = iccids.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### verizon_bc_private_network_ip and {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","ip_address"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###verizon_bc_private_network_ip and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        remaining = list(iccids) 
        # Get access token and session ID
        logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Fetching access token and session ID")
        access_id,session_id=get_verizon_token_details(app_id,app_secret,username_value,password_value)
        if not access_id or not session_id:
            logging.error(f"### verizon_bc_update_device_status and {tenant_name} Failed to fetch access token or session ID")
            return {"flag": False, "message": "Failed to fetch access token or session ID"}
        #constracting header 
        headers = {
            "Authorization": f"Bearer {access_id}",
            "VZ-M2M-Token": session_id,
            "Content-Type": "application/json",
        }
        live_progress_percentage_tracker(database, bulk_change_id,40)
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")

        # Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # Create a dictionary to hold futures
                futures = {}
                # Process each iccid in the batch
                logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} iccids")
                for iccid in batch:
                    # Prepare the URL and payload for the API call
                    def task(iccid=iccid): 
                        api_success = False
                        api_result = "" 
                        success = False
                        result = ""
                        status = "API_FAILED"
                        url = f"{carrier_api_url}"
                        if iccid_ip_map:
                            ip_address=iccid_ip_map.get(iccid,"") 
                        if ip_address : 
                            update_fields = {"ip_address":ip_address}
                        else:
                            logging.info("### Ip verizon_bc_private_network_ip Address is missing in change_request data")
                        payload = {
                                    "accountName": accountname,
                                    "deviceList": [
                                    {
                                        "deviceIds": [
                                        {
                                            "id": iccid,
                                            "kind": "iccid"
                                        }
                                        ],
                                        "ipAddress": ip_address  
                                    }
                                    ]
                                }
                        # Making the API call with retries        
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                logging.info(f"PUT Request -> URL: {url}, Payload: {payload}, Headers: {headers}")
                                resp = requests.put(
                                    url, json=payload, headers=headers, timeout=60)
                                logging.info(f"PUT Request -> URL: {url}, Payload: {payload}, Headers: {headers}, Response: {resp.text}")
                                logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                api_success = 200 <= resp.status_code < 300
                                api_result = resp.text
                                if api_success:
                                    response_data=resp.json()
                                    status = "PROCESSED"
                                    break
                                else:
                                    logging.warning(f"### verizon_bc_private_network_ip and {tenant_name} Attempt {attempt} failed for iccid: {iccid} with status code {resp.status_code} and response: {resp.text}") 
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### verizon_bc_private_network_ip and {tenant_name} Attempt {attempt} failed for iccids: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)
                        database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": status,"is_processed":True,"has_errors":False,"processed_date": now,"status_details":result},
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": [iccid]},
                                    )
                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": f"Update Verizon Subscriber: Verizon API",
                            "request_text": json.dumps(payload),
                            "has_errors": not api_success,
                            "response_status": "PROCESSED" if api_success else "API_Failed",
                            "response_text": api_result,
                            "error_text": "" if api_success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            #  insert the log entries into detailed logs table
                            database.insert_data(log,"sim_management_bulk_change_detailed_logs")      
                        if api_success :
                            request_id_data = response_data.get("requestId", None)
                            RETRY_INTERVAL = 100
                            result = False
                            ip_status = False
                            resp_status = "" 
                            fault_string = "No callback received from carrier within retry limit"
                            time.sleep(RETRY_INTERVAL) # Initial wait before checking for callback
                            for attempt in range(MAX_RETRIES):
                                callback_df = common_utils_database.get_data(
                                    "bulk_change_verizon_callback",
                                    {"request_id": request_id_data},
                                    ["fault_code", "fault_string","status"]
                                )

                                if not callback_df.empty:
                                    fault_string = callback_df.iloc[0]["fault_string"]
                                    resp_status = (callback_df.iloc[0]["status"] or "").strip()

                                    logging.info(f"### verizon_bc_private_network_ip  and {tenant_name} Callback received for request_id: {request_id_data} with status fault_string: {fault_string}")
                                    break

                                else:
                                    logging.info(f"[Retry {attempt+1}/{MAX_RETRIES}] No callback yet for request_id: {request_id_data}")
                                    if attempt < MAX_RETRIES - 1:   
                                        time.sleep(RETRY_INTERVAL)   
                            if resp_status.lower() == "success":
                                    ip_status = True
                                    status = "PROCESSED"
                                    api_success = True
                                    succesful_iccids.append(iccid)
                                    database.update_dict(
                                        "sim_management_inventory", update_fields,
                                        and_conditions={"tenant_id": tenant_id, "is_active": True},
                                        in_conditions={"iccid": [iccid]}
                                    )
                            else:
                                status = "API_FAILED"
                                api_success = False

                                # Always update request table after retries
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                {
                                    "status": status,
                                    "has_errors": not api_success,
                                    "is_processed": True,
                                    "processed_date": now,
                                    "status_details": f"{resp_status if ip_status else fault_string}"
                                },
                                and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                            )
                            # Prepare log entry
                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "Update Verizon Subscriber: Verizon API",
                                "request_text": json.dumps(payload),
                                "has_errors": not resp_status,
                                "response_status": status,
                                "response_text": resp_status if resp_status else fault_string,
                                "error_text": "",
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            if log:
                                database.insert_data(log, "sim_management_bulk_change_log")
                                #  insert the log entries into detailed logs table
                                database.insert_data(log,"sim_management_bulk_change_detailed_logs")
                        
                                          
                        return iccid
                    
                    # Submit the task to the executor
                    logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Submitting task for ICCID: {iccid}")
                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    # Process the result of each future
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### verizon_bc_private_network_ip and {tenant_name} Error processing ICCIDS: {e}")

              
        if interval and i + batch_size < len(iccids):
                    time.sleep(interval)
        
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # preparing the payload for history table update
        if succesful_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "change_type":change_type,
                                        "iccids": succesful_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            # Call the history table update API  
            try:
                logging.info(f"### verizon_bc_private_network_ip and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### verizon_bc_private_network_ip and {tenant_name} Exception in thread: {e}")  
            
        # Update the bulk change request status   
        logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Processed {len(iccids) - len(remaining)} iccids, {len(remaining)} remaining")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": succesful_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": change_type,
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "ipaddress",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### verizon_bc_private_network_ip and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### verizon_bc_private_network_ip and {tenant_name} Exception in action history thread: {e}")
        ## Handle invalid ICCIDs
        live_progress_percentage_tracker(database, bulk_change_id,75)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Update private network IP address",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","is_processed":True,"has_errors":True,
                    "processed_date": now,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
            #  insert the log entries into detailed logs table
            database.insert_data(log_entries,"sim_management_bulk_change_detailed_logs")
        logging.info(f"verizon_bc_private_network_ip and {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        # Call sync API in separate thread
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        # Sync API URL and payload are used to sync inventory tables 
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "verizon_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f'### verizon_bc_private_network_ip and {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f'### verizon_bc_private_network_ip and {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### verizon_bc_private_network_ip and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### verizon_bc_private_network_ip and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        ##auditing the sync completion
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_bc_private_network_ip",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"### verizon_bc_private_network_ip and {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### verizon_bc_private_network_ip and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = f"Error during bulk change processing: {str(e)}"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "verizon_bc_private_network_ip",
                "created_date": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### verizon_bc_private_network_ip and {tenant_name} Exception in logging error data to DB: {e}")
        return response
    
        
def build_detailed_update_dict(api_record, inventory_row, keys_to_check):
    """
    Build update dictionary with detailed field-level change tracking
   
    Args:
        api_record (dict): Data from carrier API
        inventory_row (pd.Series): Current inventory data
        keys_to_check (list): Fields to compare
   
    Returns:
        tuple: (to_update_dict, field_changes_list)
    """
    to_update = {}
    field_changes = []
   
    for key in keys_to_check:
        api_value = api_record.get(key)
        current_value = inventory_row.get(key)
       
        # Handle different data types and None values
        if pd.isna(current_value) or current_value is None:
            current_value = ""
        if pd.isna(api_value) or api_value is None:
            api_value = ""
           
        # Convert to string for comparison
        str_current = str(current_value).strip() if current_value is not None else ""
        str_api = str(api_value).strip() if api_value is not None else ""
       
        if str_current != str_api:
            to_update[key] = api_value
            field_changes.append({
                'field': key,
                'previous_value': str_current,
                'current_value': str_api
            })
            logging.info(f"### Field changed: {key}, From: '{str_current}', To: '{str_api}'")
   
    return to_update, field_changes
 
        

def billing_platform_bulk_change_20_sync(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    customername= data.get("customername","")
    use_carrier_activation=data.get("use_carrier_activation")


    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)

        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}

        path_map = {
            "Update Device Status": "/bulk_update_device_status",
            "Change Customer Rate Plan": "/bulk_update_customer_rate_plan_service_line_creation",
            "Assign Customer": "/bulk_update_assign_customer_service_line_creation",
            "Change ICCID/IMEI": "/bulk_update_iccid_imei_service_line_creation"
        }
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        billing_flag=False
        billing_platform_flag=common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["billing_platform_flag"]
        )
        if not billing_platform_flag.empty:
            billing_flag= bool(billing_platform_flag.iloc[0]["billing_platform_flag"])
        
        if change_type in path_map:
            logging.info(f"Processing change request type: {change_type}")

            path = path_map[change_type]
            data['path'] = path
        columns = [
                "iccid",
                "subscriber_number",
                "m2m_id",
                "bulk_change_id",
                "tenant_name",
                "created_by",
                "processed_by",
                "status",
                "device_id",
                "is_active",
                "is_deleted",
                "change_request",
                "id"
            ]
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            columns
        )
        bulk_change_requests = []
        if not request_data.empty:
            bulk_change_requests = request_data.to_dict(orient="records")
        for rec in bulk_change_requests:
            rec["device_change_request_id"] = rec["iccid"]
        change_columns = [
            "service_provider",
            "change_request_type_id",
            "change_request_type",
            "service_provider_id",
            "modified_by",
            "status",
            "uploaded",
            "is_active",
            "is_deleted",
            "created_by",
            "processed_by",
            "tenant_id",
            "id_10"
        ]
        change_data = database.get_data(
            "sim_management_bulk_change",
            {"id": bulk_change_id,"status":"PROCESSED"},
            change_columns
        )
        bulk_change_records = []
        if not change_data.empty:
            bulk_change_records = change_data.to_dict(orient="records")
        
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
                "path":path,
                "data": {
                    "tenant_name":tenant_name,
                    "username": username,
                    "firstLastName": username,
                    "path": path,
                    "role_name": role_name,
                    "module_name": "Bulk Change",
                    "mod_pages": {
                    "start": 0,
                    "end": 100
                    },
                    "access_token": access_token,
                    "db_name": db_name,
                    "sessionID": None,
                    "request_received_at": now,
                    "Partner": tenant_name,
                    "service_provider_id":service_provider_id,
                    "bulkchange_id": bulk_change_id,
                    "customername": customername,
                    "data": {
                    "sim_management_bulk_change": bulk_change_records,         
                    "sim_management_bulk_change_request": bulk_change_requests
                    },
                    "bulk_chnage_id_20": bulk_change_id,
                    "use_carrier_activation": use_carrier_activation,
                    "carrier_api_status": True,
                    "billing_platform_flag": billing_flag
                }
                }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": data.get("Partner",""),
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "Sim Management",
                "request_received_at": data.get("request_received_at",""),
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": data.get("username",""),
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}



##SYNC API call function
def call_sync_api(api_url, api_payload):
    '''
    Call the sync API with the provided URL and payload.
    This function is designed to be run in a separate thread after a delay.
    '''
    try:
        # Make the API call
        logging.info(f"### Calling sync API: {api_url} with payload: {api_payload}")
        response = requests.post(api_url, json=api_payload)
        if response.status_code == 200:
            logging.info("Bulk Change API call successful. Data sync call successfully done.")
        else:
            logging.error(f"API call failed with status code: {response.status_code}")
    except Exception as e:
        logging.error(f"Error making API call: {e}")

## Function to audit user actions in bulk change processing
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
   
    request_received_at = data.get("request_received_at", "") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
        logging.info("User action audited successfully.")
    except Exception as e:
        logging.exception(f"### Error logging user actions: {e}")


def live_progress_percentage_tracker(database, bulk_change_id,progress_percent):
    """
    Updates the live_progress_percentage column in sim_management_bulk_change_request table.
    """
    try:
        update_fields={}
        #updating sync status when progress percentage reached 100
        if progress_percent==100:
            update_fields["live_progress_percentage"]=progress_percent
            update_fields["progress"]="Sync Completed"
        else:
            update_fields["live_progress_percentage"]=progress_percent

        database.update_dict(
            "sim_management_bulk_change",
            update_fields,
            and_conditions={"id": bulk_change_id}
        )
        return True
    except Exception as e:
        logging.error(f"Error updating live progress: {e}")
        return False

def get_verizon_token_details(app_id,app_secret,username_value,password_value):
    """
    Obtain an OAuth access token and session token from Verizon  API.

    Args:
        app_id (str): The client ID (application ID) for Verizon API.
        app_secret (str): The client secret associated with the app_id.

    Returns:
        tuple[str, str]: A tuple containing the access token and the session token.

    Raises:
        requests.exceptions.HTTPError: If any of the HTTP requests fail.
        Exception: For unexpected decoding or response format issues.
    """
    main_url = "https://thingspace.verizon.com"
    client_id = app_id
    client_secret = app_secret
    username = username_value
    password_encoded = password_value
    logging.info(f"### get_verizon_token_details: with credentials {client_id}, {username},")
    # Decode password from base64
    password = base64.b64decode(password_encoded).decode('utf-8')

    token_url = f"{main_url}/api/ts/v1/oauth2/token"
    session_url = f"{main_url}/api/m2m/v1/session/login"

    # Prepare Basic Auth header
    auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

    # Get OAuth access token
    token_response = requests.post(
        token_url,
        headers={
            "Authorization": f"Basic {auth_header}",
            "Accept": "application/json",
        },
        data={"grant_type": "client_credentials"},
    )
    token_response.raise_for_status()
    access_token_id = token_response.json().get("access_token")
    logging.info(f"### get_verizon_token_details Access token: {access_token_id}")

    # Get session token
    session_response = requests.post(
        session_url,
        headers={
            "Authorization": f"Bearer {access_token_id}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        },
        json={"username": username, "password": password},
    )
    session_response.raise_for_status()
    session_token = session_response.json().get("sessionToken")
    logging.info(f"## get_verizon_token_details Session token: {session_token}")
    return access_token_id,session_token


def update_for_partner_to_provider(data, primary_key):
    """
    Updates inventory data for a partner becoming a provider.
    Supports multiple MSISDNs/ICCID, source DBs, and target DBs.

    Parameters:
        data (dict): Input data including db info, changed_data, target_details, etc.
        primary_key (str): Either 'msisdn' or 'iccid'.

    Returns:
        dict: Response dict with 'flag' and 'message'.
    """
    logging.info(f"### Starting update_for_partner_to_provider with data: {data}")
    start_time = time.time()
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    session_id = data.get("sessionID", "")
    request_received_at = data.get("request_received_at", "")
    changed_data = data.get('changed_data', [])
    change_type = data.get('change_event_type')
    provider_parent_name = data.get('provider_parent_name')
    db_name = data.get('db_name', '')
    tenant_id = data.get('tenant_id', '')
    carrie_rate_plan=data.get('carrie_rate_plan','')
    customer_rate_plan_name=data.get('customer_rate_plan_name','')
    role_name = data.get("role_name", "")
    access_token = data.get("access_token", "")
    bulk_change_id = data.get("bulk_change_id")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    service_provider= data.get("service_provider","")
    column_map = {
        "Update PPU address": ["user_address", "modified_by"],
        "Update Features": ["telegence_features", "modified_by"],
        "Change Phone Number": ["msisdn", "modified_by"],
        "Change Carrier Rate Plan": ["carrier_rate_plan_name", "modified_by"],
        "Change Customer Rate Plan": ["modified_by"],
        "Update Device Status": ["sim_status", "modified_by"],
        "Archive": ["is_active", "is_deleted"],
        "Change ICCID/IMEI":["imei","iccid","modified_by"],
        "Edit Username/Cost Center": ["username", "cost_center", "modified_by"],
        "Activate New Service":["iccid","msisdn","imei","billing_account_number","tenant_id",
                                "is_active","is_deleted","tenant_is_active","tenant_is_deleted",
                                "service_provider_is_active","created_by","created_date",
                                "service_provider_display_name","sim_status","service_provider_id",
                                "device_status_id","foundation_account_number","modified_by"],
        "Refresh A Line": ["modified_by", "effective_date", "carrier_rate_plan_id", 
                           "carrier_rate_plan_name", "service_zip_code", "billing_account_number", 
                           "username", "iccid", "imei", "next_bill_cycle_date", "telegence_features"]
    }
    if not changed_data or not primary_key:
        logging.error("### changed_data or primary_key is missing.")
        message=f"changed_data or primary_key is missing for bulk change id {bulk_change_id}."
        response={"flag":False,"message":message}
        #return {"flag": False, "message": "changed_data or primary_key is missing."}
        try:
                end_time = time.time()
                time_consumed = end_time - start_time
                time_consumed = int(round(time_consumed))
                audit_data_user_actions = {
                    "service_name": "update_for_partner_to_provider",
                    "created_by": username,
                    "status": json.dumps(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "tenant_name": tenant_name,
                    "module_name": "Bulk Change",
                    "comments": message,
                    "request_received_at": now,
                }
            
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"###update_for_partner_to_provider and {tenant_name} Audit logging failed: {e}")
        return response

    try:
        # DB connections
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        tenant_db = DB(db_name, **db_config)
    except Exception as e:
        logging.exception("### Failed to connect to databases")
        return {"flag": False, "message": "Database connection error"}

    try:
        if isinstance(changed_data, dict):
            changed_data = [changed_data]

        # Flatten primary key values
        key_values = list(set(
            str(v)
            for entry in changed_data
            if primary_key in entry
            for v in (entry[primary_key] if isinstance(entry[primary_key], list) else [entry[primary_key]])
        ))
        logging.info(f"### Normalized key_values: {key_values}")

        # if not key_values:
        #     return {"flag": False, "message": f"No valid {primary_key} values provided."}
        if not key_values:
                message=f"No valid {primary_key} values provided for bulk change id {bulk_change_id}."
                response={"flag":False,"message":message}
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "update_for_partner_to_provider",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"###update_for_partner_to_provider and {tenant_name} Audit logging failed: {e}")
                return response

        # Fetch source  and target details
        details_df = tenant_db.get_data(
            "sim_management_inventory",
            {"is_active": True, primary_key: key_values, "tenant_id": tenant_id,"service_provider_display_name": service_provider},
            ["source_id", "source_db", "target_details", primary_key]
        )
        # Build details map
        details_map = {}
        if not details_df.empty:
            details_map = {
                row[primary_key]: {
                    "source_id": row["source_id"],
                    "source_db": row["source_db"],
                    "target_details": row["target_details"]
                }
                for _, row in details_df.iterrows()
            }
        logging.info(f"### details_map: {details_map}")        
        source_db_map = defaultdict(list)
        for key_val in key_values:
            if key_val in details_map and details_map[key_val].get("source_db"):
                source_db_map[details_map[key_val]["source_db"]].append(key_val)
        # Get DB configs for all involved DBs
        dbconfig_details=common_utils_database.get_data(
            "tenant",
            {"is_active":True,"db_config":"not Null","parent_tenant_id":"Null"},
            ["db_name","db_config","tenant_name"]
        )
        # handling multi rds configs
        dbname_config_mapping=dict(zip(dbconfig_details.db_name ,dbconfig_details.db_config))
        dbname_tenant_mapping = dict(zip(dbconfig_details.db_name, dbconfig_details.tenant_name))
        db_config_per_db = {
            db_name: {
                "host": conf.get("hostname") or conf.get("host"),
                "port": conf.get("port"),
                "user": conf.get("user"),
                "password": conf.get("password"),
                "multi_schema":False
            }
            for db_name, conf in dbname_config_mapping.items()
        }
        # enter if block if source dbs are present
        if source_db_map:
            def update_source_db(source_db, msisdn_list):
                db_config = db_config_per_db.get(source_db)
                logging.info(f"### Updating source DB: {source_db} for keys: {msisdn_list} with config: {db_config}")
                db_instance = DB(source_db, **db_config)
                records_to_update = []
                for key_val in msisdn_list:
                    record_data = [rec for rec in changed_data if key_val in (rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]])]
                    record_data = fetching_the_changed_data(
                        record_data,
                        db_instance,
                        column_map,
                        change_type,
                        provider_parent_name,
                        tenant_db,
                        primary_key,
                        tenant_id,
                        common_utils_database,
                        username,
                        source_db,carrie_rate_plan
                    )
                    for rec in record_data:
                        records_to_update.append({primary_key: key_val, **{k:v for k,v in rec.items() if k != primary_key}})

                if records_to_update and change_type != "Activate New Service":
                    db_instance.bulk_update_data("sim_management_inventory", records_to_update, search_column=primary_key)
                    logging.info(f"Updated source DB {source_db}, rows: {records_to_update}")
                else:
                    db_instance.insert_data(records_to_update, "sim_management_inventory")
                    logging.info(f"Inserted into source DB {source_db}, rows: {records_to_update}")
                # Trigger sync API for source DB
                try:
                    api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
                    call_data_sync_for_source = {
                            "data": {
                            "key_name": "m2m_inventory_live_sync_from_20",
                            "path": "/lambda_sync_jobs_",
                            "tenant_db_name": source_db,
                            "service_provider_name": provider_parent_name,
                            "msisdn_list": msisdn_list,
                            "target_tenant_id":tenant_id,
                            "target_tenant_name":tenant_name,
                            "pbp_flag":True,
                            "primary_key":primary_key
                            }
                    }
                    logging.info(f"### Scheduling additional sync API call  with payload: {call_data_sync_for_source}")
                    threading.Timer(1.0, call_sync_api, args=(api_sync_url, call_data_sync_for_source)).start()
                    logging.info(f"### Source DB API call scheduled for DB: {source_db}")
                except Exception as e:
                    logging.exception(f"### Exception during source DB API trigger: {e}")

            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures = [executor.submit(update_source_db, db_name, msisdn_list) for db_name, msisdn_list in source_db_map.items()]
                for future in concurrent.futures.as_completed(futures):
                    future.result()
        per_db_changed = defaultdict(list)
        for key_val, details in details_map.items():
            target_list = details.get("target_details") or []            
            if target_list:  # Only include if target_details exist
                for target_map in target_list:
                    if isinstance(target_map, dict):
                        for db_name, target_id in target_map.items():
                            per_db_changed[db_name].append({
                                primary_key: key_val,
                                "targetid": target_id  
                            })
        logging.info(f"### per_db_changed: {dict(per_db_changed)}") 
        futures = {}  # ✅ MUST be defined upfront
        target_id=None
        # Update target DBs       
        if per_db_changed:   
            changed_lookup = {}
            for rec in changed_data:
                vals = rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]]
                for v in vals:
                    changed_lookup[str(v).strip()] = rec
            # Determine required columns
            required_columns = column_map.get(change_type, [])
            required_columns = [primary_key] + required_columns 
            key_values = list(changed_lookup.keys())
            if not key_values:
                logging.warning(f"### No valid {primary_key} values in changed_data")
                return []
            # Fetch inventory data from target_database
            inventory_df = tenant_db.get_data(
                "sim_management_inventory",
                {primary_key: key_values,"tenant_id":tenant_id, "is_active": True},
                required_columns
            ) 
            if customer_rate_plan_name:
                customer_rate_plan_data=tenant_db.get_data('customerrateplan',{'rate_plan_name':customer_rate_plan_name,"tenant_id":tenant_id,"is_active":True})
                if customer_rate_plan_data.empty:
                    customer_rate_plan_data=None
                else:
                    customer_rate_plan_data=customer_rate_plan_data.to_dict(orient='records')[0]
            else:
                customer_rate_plan_data=None
            tenant_data = common_utils_database.get_data(
                "tenant",
                {"is_active": True},
                ["id", "parent_tenant_id"]
            )    
            def update_target_db(db_name, changed_list):
                db_config = db_config_per_db.get(db_name)
                target_db = DB(db_name, **db_config)
                if per_db_changed:
                    target_ids=per_db_changed[db_name]
                    if target_ids:
                        target_id = per_db_changed[db_name][0]["targetid"]
                logging.info(f"target_id is {target_id} and db_name is {db_name}")
                updated_data = fetching_the_changed_data_source_to_target_updates(
                    changed_list,
                    target_db,
                    change_type,
                    primary_key,
                    inventory_df,
                    changed_lookup,
                    required_columns,db_name,
                    target_id,customer_rate_plan_name,
                    common_utils_database,
                    username,customer_rate_plan_data,tenant_data
                )
                if updated_data:
                    updated_rows =target_db.bulk_update_data(
                        "sim_management_inventory",
                        updated_data,
                        search_column=primary_key
                    )
                    logging.info(f"Updated target DB {db_name}, rows: {len(updated_data)},updated_rows :{updated_rows }")
            # Run updates concurrently per target DB
            with concurrent.futures.ThreadPoolExecutor() as executor:
                for db_name, data_list in per_db_changed.items():
                    logging.info(
                        f"Scheduling update for target DB: {db_name} with {len(data_list)} records"
                    )
                    future = executor.submit(update_target_db, db_name, data_list)
                    futures[future] = db_name
                logging.info(f"Futures is  {futures} with {db_name} db_name")

                for future in concurrent.futures.as_completed(futures):
                    db_name = futures[future]
                    try:
                        future.result()
                        logging.info(f"Successfully updated target DB: {db_name}")
                    except Exception:
                        logging.exception(f"Error updating target DB: {db_name}")
        try:
            # Prefer source DBs if any exist
            if source_db_map:
                db_list = list(source_db_map.keys())
            else:
                # fallback to target DBs
                db_list = list(per_db_changed.keys())
                for db_name in db_list:
                    tenant_for_api = dbname_tenant_mapping.get(db_name)
                    logging.info(f"### Preparing API for DB: {db_name}, tenant: {tenant_for_api}")

                    # Main API payload
                    api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
                    api_payload = {
                        "data": {
                            "access_token": access_token,
                            "data": {"bulk_change_id": bulk_change_id},
                            "db_name": db_name,
                            "is_update": True,
                            "module_name": "Bulk Change",
                            "Partner": tenant_name,
                            "path": "/update_bulk_change_tables_10",
                            "request_received_at": now,
                            "role_name": role_name,
                            "tenant_name": tenant_for_api,
                            "username": username
                        }
                    }

                    # Sync API payload
                    api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
                    api_sync_payload = {
                        "data": {
                            "access_token": access_token,
                            "key_name": "telegence_bulkchange_sync",
                            "path": "/bulk_change_sync_10_updated",
                            "tenant_name": tenant_for_api,
                            "bulk_change_id": bulk_change_id
                        }
                    }
                    if change_type == "Activate New Service":
                        # Additional data sync payload
                        data_sync = {
                            "data": {
                                "data": {
                                    "key_name": "verizon_inventory",
                                    "path": "/lambda_sync_jobs_",
                                    "tenant_name": tenant_for_api
                                }
                            }
                        }
                        logging.info(f"### Scheduling additional sync API call for Activate New Service to {api_sync_url} with payload: {data_sync}")
                        threading.Timer(10.0, call_sync_api, args=(api_sync_url, data_sync)).start()
                    # Trigger both APIs (10s delay)
                    threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
                    threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()


        except Exception as e:
            logging.exception(f"### Exception during API trigger: {e}")
        
        response = {"flag": True, "message": "Inventory data update executed successfully"}
        try:
            audit_data = {
                "service_name": "update_for_partner_to_provider",
                "created_by": username,
                "status": str(response['flag']),
                "session_id": session_id,
                "tenant_name": tenant_name,
                "module_name": "Partner Becoming Provider",
                "comments": f"Successfully executed inventory update, data: {json.dumps(data)}",
                "request_received_at": request_received_at
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Exception in auditing: {e}")

        return response

    except Exception as e:
        logging.error(f"### Exception: {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "update_for_partner_to_provider",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": username,
                "session_id": session_id,
                "tenant_name": tenant_name,
                "comments": f"Failed executing inventory update, data: {json.dumps(data)}",
                "module_name": "Partner Becoming Provider",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error executing inventory data update: {e}"}

def fetching_the_changed_data_source_to_target_updates(changed_data, target_database, 
                              change_type,primary_key,inventory_df,
                              changed_lookup,required_columns,db_name,target_id,customer_rate_plan_name,
                              common_utils_database,
                                username,customer_rate_plan_data,tenant_data):
    """
    Fetches inventory data from target_database and rebuilds changed_data with required fields.
    Optimized for bulk/threaded updates.

    Parameters:
        changed_data (list[dict]): List of changed records.
        source_database (DB): Source database connection.
        change_column_map (dict): Columns to fetch for each change_type.
        change_type (str): Type of change event.
        parent_provider_name (str): Provider name.
        target_database (DB): Target database connection.
        map_id_field (str): Field name to map source/target ID ('source_id'/'target_id').
        primary_key (str): Primary key to fetch data by ('id', 'msisdn', 'iccid').

    Returns:
        list[dict]: Updated changed_data with mapped IDs and required fields.
    """
    logging.info(f"### fetching_the_changed_data called target_id {target_id} for change_type:{db_name}db_name: {change_type}, primary_key: {primary_key}")

    if not changed_data:
        return []
    integration_id = None
    target_carrier_rate_plan_id=None
    target_carrier_rate_plan_name=None
    parent_tenant_id=None
    integration_df = target_database.get_data(
        'sim_management_inventory', {'id': target_id}, ['integration_id','service_provider_display_name','tenant_id','service_provider_id']
    )
    if not integration_df.empty:
        integration_id = int(integration_df.iloc[0]["integration_id"])
        service_provider = integration_df.iloc[0]["service_provider_display_name"]
        tenant_id = int(integration_df.iloc[0]["tenant_id"])
        service_provider_id = int(integration_df.iloc[0]["service_provider_id"])
    else:
        integration_id = None
        service_provider = None
        tenant_id=None
    if tenant_id:
        # Filter the row for the given tenant_id
        tenant_row = tenant_data[tenant_data["id"] == tenant_id]
        if not tenant_row.empty:
            parent_tenant_id = tenant_row["parent_tenant_id"].iloc[0]
            if parent_tenant_id:
                parent_tenant_id=int(parent_tenant_id)
        else:
            parent_tenant_id=None
    logging.info(f"fetching_the_changed_data_source_to_target_updates parent_tenant_id {parent_tenant_id}")
    if change_type in ('Change Customer Rate Plan') and not parent_tenant_id: 
        if not parent_tenant_id:
            carrier_rate_plan_df = target_database.get_data(
                "carrier_rate_plan",
                {"friendly_name": customer_rate_plan_name, "is_active": True},
                ["id"]
            )
            logging.info(f"fetching_the_changed_data_source_to_target_updates customer rate plan to carrier rate plan flow")
            if not carrier_rate_plan_df.empty:
                target_carrier_rate_plan_id=carrier_rate_plan_df['id'].to_list()[0]
                target_carrier_rate_plan_name=customer_rate_plan_name
            else:
                carrier_rate_plan_payload = {
                    "rate_plan_code": customer_rate_plan_data["rate_plan_code"],
                    "friendly_name": customer_rate_plan_data["rate_plan_name"],
                    "service_provider": service_provider,
                    "service_provider_id": service_provider_id,
                    "base_rate": customer_rate_plan_data["base_rate"],
                    "plan_mb": customer_rate_plan_data["plan_mb"],
                    "overage_rate_cost": customer_rate_plan_data["overage_rate_cost"],
                    "surcharge_3g": customer_rate_plan_data["surcharge_3g"],
                    "rate_charge_amt": customer_rate_plan_data["rate_charge_amt"],
                    "display_rate": customer_rate_plan_data["display_rate"],
                    "base_rate_per_mb": customer_rate_plan_data["base_rate_per_mb"],
                    "data_per_overage_charge": customer_rate_plan_data["data_per_overage_charge"],
                    "is_active": customer_rate_plan_data["is_active"],
                    "is_deleted": customer_rate_plan_data["is_deleted"],
                    "created_by": username,
                    "modified_by": username,
                    "allows_sim_pooling": customer_rate_plan_data["allows_sim_pooling"],
                    "rate_plan_short_name": customer_rate_plan_data["soc_code"],
                    "assigned":False,
                    "source_id":customer_rate_plan_data["id"],
                    "is_retired":False,   
                }
                target_carrier_rate_plan_id=target_database.insert_data(carrier_rate_plan_payload,
                            'carrier_rate_plan'
                        )
                target_carrier_rate_plan_name=customer_rate_plan_name

            
    logging.info(f"### fetching_the_changed_data called for {target_id} target_id change_type {integration_id} and service_provider is {service_provider}")
    rate_plan_map = {}
    if change_type in ('Change Carrier Rate Plan', 'Refresh A Line'):
        carrier_rate_plan_df = target_database.get_data(
            "carrier_rate_plan",
            {"service_provider": service_provider, "is_active": True},
            ["id", "rate_plan_short_name"]
        )
        if isinstance(carrier_rate_plan_df, pd.DataFrame) and not carrier_rate_plan_df.empty:
            rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()}
    # Device status mapping
    device_status_map = {}
    if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and integration_id:
        device_status_df = target_database.get_data(
            "device_status",
            {"integration_id": integration_id,"is_active":True},
            ["id", "status", "description", "display_name"]
        )
        for _, row in device_status_df.iterrows():
            for col in ["status", "description", "display_name"]:
                val = row.get(col)
                if val:
                    device_status_map[val.lower()] = row["id"]
    # Rebuild changed_data with required fields
    updated_data = []
    for _, row in inventory_df.iterrows():
        key_val = str(row[primary_key]).strip()
        entry = changed_lookup.get(key_val)
        if not entry:
            continue

        # Carrier rate plan mapping
        plan_name = row.get("carrier_rate_plan_name")
        new_entry = {}
        if change_type in ('Change Customer Rate Plan') and not parent_tenant_id: 
            if target_carrier_rate_plan_id:
                new_entry["carrier_rate_plan_id"] = target_carrier_rate_plan_id
                new_entry["carrier_rate_plan_name"] = target_carrier_rate_plan_name
        elif change_type in ('Change Customer Rate Plan') and  parent_tenant_id: 
            new_entry["sub_tenant_carrier_rate_plan_name"] = customer_rate_plan_name
            if plan_name:
                if plan_name in rate_plan_map:
                    new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
                    new_entry["carrier_rate_plan_name"] = plan_name
        else:
            if plan_name:
                if plan_name in rate_plan_map:
                    new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
                    new_entry["carrier_rate_plan_name"] = plan_name
        # Device status mapping
        if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and "sim_status" in row:
            sim_status_val = str(row["sim_status"]).lower()
            if sim_status_val in device_status_map:
                new_entry["device_status_id"] = device_status_map[sim_status_val]
        # Build new entry with required columns
        for col in required_columns:
            if col in row and col not in new_entry:
                new_entry[col] = row[col]
        # Add modified_by if exists
        if "modified_by" in row:
            new_entry["modified_by"] = row["modified_by"]

        updated_data.append(new_entry)

    logging.info(f"### fetched {updated_data} records in fetching_the_changed_data")
    return updated_data


def fetching_the_changed_data(changed_data, source_database, change_column_map,
                              change_type, parent_provider_name, target_database,
                              primary_key,tenant_id,common_utils_database,username,source_db,carrie_rate_plan):
    """
    Fetches inventory data from target_database and rebuilds changed_data with required fields.
    Optimized for bulk/threaded updates.

    Parameters:
        changed_data (list[dict]): List of changed records.
        source_database (DB): Source database connection.
        change_column_map (dict): Columns to fetch for each change_type.
        change_type (str): Type of change event.
        parent_provider_name (str): Provider name.
        target_database (DB): Target database connection.
        map_id_field (str): Field name to map source/target ID ('source_id'/'target_id').
        primary_key (str): Primary key to fetch data by ('id', 'msisdn', 'iccid').

    Returns:
        list[dict]: Updated changed_data with mapped IDs and required fields.
    """
    logging.info(f"### fetching_the_changed_data called for change_type: {change_type}, primary_key: {primary_key} and carrie_rate_plan  {carrie_rate_plan}")
    source_customer_rate_plan_insertion_id=None
    try:
        if not changed_data:
            return []
        parent_tenant_id=None
        parent_tenant_dataframe=common_utils_database.get_data('tenant',{'id':tenant_id},['parent_tenant_id'])
        if not parent_tenant_dataframe.empty:
            parent_tenant_id=parent_tenant_dataframe['parent_tenant_id'].to_list()[0]
        integration_id = None
        integration_df = source_database.get_data(
            'serviceprovider', {'service_provider_name': parent_provider_name}, ['integration_id','id']
        )
        if not integration_df.empty:
            integration_id = int(integration_df['integration_id'].iloc[0])
            parent_service_provider_id = int(integration_df['id'].iloc[0])
        changed_lookup = {}
        for rec in changed_data:
            vals = rec[primary_key] if isinstance(rec[primary_key], list) else [rec[primary_key]]
            for v in vals:
                changed_lookup[str(v).strip()] = rec
        # Determine required columns
        required_columns = change_column_map.get(change_type, [])
        required_columns = [primary_key] + required_columns 
        key_values = list(changed_lookup.keys())
        if not key_values:
            logging.warning(f"### No valid {primary_key} values in changed_data")
            return []
        # Fetch inventory data from target_database
        inventory_df = target_database.get_data(
            "sim_management_inventory",
            {primary_key: key_values,"tenant_id":tenant_id, "is_active": True},
            required_columns
        )
        rate_plan_map = {}
        if change_type in ('Change Carrier Rate Plan') and not parent_tenant_id:
            logging.info(f"fetching_the_changed_data carrire_rate_plan_name is {carrie_rate_plan}")
            source_tenant_id=common_utils_database.get_data('tenant',{'db_name':source_db,'parent_tenant_id':'Null'},['id'])['id'].to_list()[0]
            carrier_rate_plan_data=target_database.get_data('carrier_rate_plan',{'rate_plan_code':carrie_rate_plan})
            # If not found using friendly_name, try with rate_plan_short_name
            if carrier_rate_plan_data.empty:
                carrier_rate_plan_data = target_database.get_data(
                    'carrier_rate_plan',
                    {'friendly_name': carrie_rate_plan}
                )

            # Proceed only if data is found
            if not carrier_rate_plan_data.empty:
                row = carrier_rate_plan_data.iloc[0]
                # ✅ Take friendly_name from carrier_rate_plan table
                friendly_name = row.get("friendly_name")
                customer_rate_plan_data=source_database.get_data('customerrateplan',{'rate_plan_name':friendly_name,'tenant_id':source_tenant_id},['id','rate_plan_name'])
                if not customer_rate_plan_data.empty:
                    source_customer_rate_plan_insertion_id=customer_rate_plan_data['id'].to_list()[0]
                    source_customer_rate_plan=customer_rate_plan_data['rate_plan_name'].to_list()[0]
                else:
                    customer_rate_plan_payload = {
                        "tenant_id": int(source_tenant_id),
                        "rate_plan_name": row["friendly_name"],
                        "rate_plan_code": row["rate_plan_code"],
                        "service_provider_name":parent_provider_name,
                        "service_provider_id":parent_service_provider_id,
                        "base_rate": clean_value(row["base_rate"]),
                        "sms_rate": clean_value(row["base_rate"]),
                        "plan_mb": clean_value(row["plan_mb"]),
                        "overage_rate_cost": clean_value(row["overage_rate_cost"]),
                        "surcharge_3g": clean_value(row["surcharge_3g"]),
                        "created_by": username,
                        "modified_by": username,
                        "rate_charge_amt": clean_value(row["rate_charge_amt"]),
                        "display_rate": clean_value(row["display_rate"]),
                        "base_rate_per_mb": clean_value(row["base_rate_per_mb"]),
                        "is_active": True,
                        "is_deleted": False,
                        "soc_code": row["rate_plan_short_name"],
                        "service_provider_id": int(row["service_provider_id"]),
                        "data_per_overage_charge": clean_value(row["data_per_overage_charge"]),
                        "allows_sim_pooling": bool(row["allows_sim_pooling"]),
                        "pbp_flag": True
                    }
                    source_customer_rate_plan_insertion_id=source_database.insert_data(customer_rate_plan_payload,
                        'customerrateplan'
                    )
                    source_customer_rate_plan=customer_rate_plan_payload.get('rate_plan_name','')
        if change_type in ('Refresh A Line'):
            carrier_rate_plan_df = source_database.get_data(
                "carrier_rate_plan",
                {"service_provider": parent_provider_name, "is_active": True},
                ["id", "rate_plan_short_name"]
            )
            if isinstance(carrier_rate_plan_df, pd.DataFrame) and not carrier_rate_plan_df.empty:
                rate_plan_map = {row["rate_plan_short_name"]: row["id"] for _, row in carrier_rate_plan_df.iterrows()}
        # Device status mapping
        device_status_map = {}
        if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and integration_id:
            device_status_df = source_database.get_data(
                "device_status",
                {"integration_id": integration_id},
                ["id", "status", "description", "display_name"]
            )
            for _, row in device_status_df.iterrows():
                for col in ["status", "description", "display_name"]:
                    val = row.get(col)
                    if val:
                        device_status_map[val.lower()] = row["id"]
        # Rebuild changed_data with required fields
        updated_data = []
        for _, row in inventory_df.iterrows():
            key_val = str(row[primary_key]).strip()
            entry = changed_lookup.get(key_val)
            if not entry:
                continue
            new_entry = {}
            if change_type in ('Refresh A Line'):
                # Carrier rate plan mapping
                plan_name = row.get("carrier_rate_plan_name")
                if plan_name:
                    if plan_name in rate_plan_map:
                        new_entry["carrier_rate_plan_id"] = rate_plan_map[plan_name]
                    new_entry["carrier_rate_plan_name"] = plan_name
            if change_type in ('Change Carrier Rate Plan') and not parent_tenant_id:
                if source_customer_rate_plan_insertion_id:
                    new_entry["customer_rate_plan_id"] = source_customer_rate_plan_insertion_id
                    new_entry["customer_rate_plan_name"] = source_customer_rate_plan
                    logging.info(f"source_customer_rate_plan {source_customer_rate_plan} and source_customer_rate_plan_insertion_id {source_customer_rate_plan_insertion_id}")
            # Device status mapping
            if change_type in ('Update Status', 'Refresh A Line', 'Update Device Status') and "sim_status" in row:
                sim_status_val = str(row["sim_status"]).lower()
                if sim_status_val in device_status_map:
                    new_entry["device_status_id"] = device_status_map[sim_status_val]
            # Build new entry with required columns
            for col in required_columns:
                if col in row and col not in new_entry:
                    new_entry[col] = row[col]
            # Add modified_by if exists
            if "modified_by" in row:
                new_entry["modified_by"] = row["modified_by"]

            updated_data.append(new_entry)

        logging.info(f"### fetched {updated_data} records in fetching_the_changed_data")
        return updated_data
    except Exception as e:
        logging.exception(f"### Exception in fetching_the_changed_data: {e}")
        return []

def clean_value(val):
    if isinstance(val, (np.bool_,)):
        return bool(val)
    if isinstance(val, (np.integer,)):
        return int(val)
    if isinstance(val, (np.floating,)):
        return float(val)
    return val


def billing_integrtion_new(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    revcustomername = data.get("changed_data",{}).get("RevCustomerId", "")
    customerrateplan = data.get("changed_data",{}).get("CustomerRatePlanId", "")


    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            ["change_request"]
        )
        bulk_change_requests = {}
        if not request_data.empty:
            bulk_change_requests = request_data.iloc[0]["change_request"]
        if isinstance(bulk_change_requests, str):
           bulk_change_requests = json.loads(bulk_change_requests)
        logging.info(f"change_request_json is {bulk_change_requests}")
        #Extract relevant fields from the change request 
        rev_customer_id = bulk_change_requests.get("RevCustomerId", "")
        if not rev_customer_id:
            rev_customer_id = bulk_change_requests.get("customerId", "")
        logging.info("Using rev_customer_id: %s", rev_customer_id)

        # First check the rev_customer table
        rev_customer_data = database.get_data(
            "rev_customer",                         # assuming table name
            {"rev_customer_id": rev_customer_id, "is_active": True},
            ["customer_name"]
        )
        if isinstance(rev_customer_data, pd.DataFrame) and not rev_customer_data.empty:
            customer_name = rev_customer_data["customer_name"].iloc[0]
            logging.info("Found customer_name in rev_customer: %s", customer_name)
        else:
            # fallback to customers table
            customer_data = database.get_data(
                "customers",
                {"id": rev_customer_id, "is_active": True},
                ["customer_name"]
            )
            if not customer_data.empty:
                customer_name = customer_data["customer_name"].to_list()[0]
                logging.info("Found customer_name in customers: %s", customer_name)
            else:
                customer_name = None
                logging.info("No active customer found for id: %s", rev_customer_id)
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
            "tenant_name": tenant_name,
            "path": "/bulk_update_assign_customer_service_line_creation",
            "role_name": role_name,
            "request_received_at": now,
            "access_token": access_token,
            "db_name": db_name,
            "sessionID": None,
            "service_provider": service_provider,
            "change_type": change_type,
            "created_by": created_by,
            "iccids": iccids,
            "RevCustomerName": customer_name,
            "CustomerRatePlanName": customerrateplan,
            "changed_data": bulk_change_requests,         
            }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": tenant_name,
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "bulk Change",
                "request_received_at": now,
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": username,
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}
    
def billing_integration_change_rate_plan(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data    
    """
    logging.info(f"billing_integration_change_rate_plan in telegence function is called with data: {data}")
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    customerrateplan = data.get("CustomerRatePlanId", "")
    use_carrier_activation=data.get("use_carrier_activation")
    sessionid=data.get("sessionID","")
    customerid=data.get("customerId","")
    customer_name=data.get("customer_name","")
    #efdate=data.get("effective_date","")
    changed_data=data.get("changed_data",{})
    efdate=changed_data.get("effective_date","") or data.get("effective_date","")
    try:

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_database_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}   
        billing_flag=False
        billing_platform_flag=common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["billing_platform_flag"]
        )
        if not billing_platform_flag.empty:
            billing_flag = bool(billing_platform_flag.iloc[0]["billing_platform_flag"])
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
            "tenant_id": tenant_id,
            "tenant_name": tenant_name,
            "username": username,
            "firstLastName": created_by,
            "path": "/bulk_update_customer_rate_plan_service_line_creation",
            "role_name": role_name,
            "module_name": "Bulk Change",
            "mod_pages": {
                "start": 0,
                "end": 100
            },
            "access_token": access_token,
            "db_name": db_name,
            "sessionID": sessionid,
            "request_received_at":now,
            "Partner": tenant_name,
            "service_provider_id": service_provider_id,
            "service_provider": service_provider,
            "EffectiveDate": efdate,
            "customername": customer_name,
            "bulkchange_id": bulk_change_id,
            "bulk_chnage_id_20":bulk_change_id,
            "use_carrier_activation": use_carrier_activation,
            "carrier_api_status": True,
            "billing_platform_flag":billing_flag,
            "modified_by": username,
            "created_by": created_by,
            "iccids": iccids,
            "msisdns": msisdns,
            "customerId":customerid,
            "CustomerRatePlanId":customerrateplan
            }         
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "billing_integration_change_rate_plan",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": tenant_name,
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "bulk Change",
                "request_received_at": now,
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for billing_integration_change_rate_plan")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": username,
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}
